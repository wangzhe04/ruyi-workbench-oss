// Root execution authority. MCP children never open this ledger; they need the root service.
const DesktopExecutionRuntime = (() => {
  let state = null;
  const admissions = new Map();
  const contexts = new WeakMap(), peers = new WeakMap(), pendingMain = new Map();
  const sendPermits = new WeakMap();
  const modelScope = new (require('async_hooks').AsyncLocalStorage)();
  const enabled = () => process.platform === 'darwin' && process.env.RUYI_DESKTOP_EXECUTION_RECEIPTS === '1';
  const fail = (code, message) => Object.assign(new Error(message), { code, status: 409 });
  const generation = session => session.rewindGen === undefined ? 0 : session.rewindGen;
  function rootOwned() {
    if (!state || !state.dataIdentity || !state.ownership.isHeld() || !state.ownership.isRootCurrent(state.canonicalRoot)) return false;
    try {
      const named = fs.statSync(paths.data, { bigint: true }), canonical = fs.statSync(state.canonicalRoot, { bigint: true });
      return [named, canonical].every(stat => stat.isDirectory() && stat.dev === state.dataIdentity.dev
        && stat.ino === state.dataIdentity.ino && stat.birthtimeNs === state.dataIdentity.birthtimeNs);
    } catch { return false; }
  }
  function authority() {
    if (!state || state.phase !== 'ready' || !rootOwned()) {
      throw fail('execution_owner_lost', '桌面执行记录的服务所有权不可用，已停止继续执行。');
    }
    return state;
  }
  function current(scope) {
    const admitted = admissions.get(scope.sessionId);
    return !!admitted && !!state && state.phase === 'ready' && rootOwned()
      && admitted.id === scope.admissionId && admitted.turnSeq === scope.turnSeq && admitted.rewindGen === scope.rewindGen
      && admitted.session.turnSeq === scope.turnSeq && generation(admitted.session) === scope.rewindGen
      && turnSettlers.get(scope.sessionId) === admitted.owner && !admitted.owner.cancelRequested
      && admitted.owner.driverRunId === admitted.driverRunId;
  }
  async function initialize(ownership) {
    if (process.platform !== 'darwin') return;
    if (state) throw fail('execution_runtime_initialized', '桌面执行记录已经初始化；本进程不能再次接管。');
    if (!ownership || typeof ownership.isHeld !== 'function' || !ownership.isHeld()) {
      throw fail('execution_owner_required', '桌面执行记录需要实际的服务所有权。');
    }
    state = { phase: 'opening', ownership, ledger: null, dataIdentity: null, canonicalRoot: null };
    try {
      state.canonicalRoot = await ServerOwnership.canonicalRoot(paths.data);
      if (!ownership.isHeld() || !ownership.roots.includes(state.canonicalRoot) || !ownership.isRootCurrent(state.canonicalRoot)) {
        throw fail('execution_owner_lost', '服务没有持有当前数据目录的实际所有权。');
      }
      await fsp.mkdir(paths.data, { recursive: true });
      await ownership.confirmRoot(paths.data);
      state.dataIdentity = await fsp.stat(paths.data, { bigint: true });
      if (!rootOwned()) throw fail('execution_owner_lost', '数据目录在初始化期间发生变化。');
      const ledger = DesktopExecutionLedger.create({ directory: path.join(paths.data, 'desktop-executions-v1'),
        isOwner: rootOwned, isTurnCurrent: current });
      await ledger.open();
      if (!rootOwned()) throw fail('execution_owner_lost', '服务所有权在恢复期间失效。');
      state.ledger = ledger;
      state.phase = 'ready';
    } catch (error) { state.phase = 'failed'; throw error; }
  }
  async function guard(sessionId) {
    // Non-serve consumers do not acquire or mutate shared execution state.
    if (!state) return;
    const root = authority(), observed = await root.ledger.guard(sessionId);
    authority();
    if (!observed.ok) throw fail('execution_reconciliation_required',
      '上次桌面操作的执行或结果保存尚未确认，已暂停本会话的自动继续，请先核实执行记录。');
  }
  function admit(session, owner) {
    if (!state) return null;
    authority();
    if (!owner || turnSettlers.get(session.id) !== owner || owner.cancelRequested
        || typeof owner.driverRunId !== 'string' || !owner.driverRunId
        || !Number.isSafeInteger(session.turnSeq) || session.turnSeq < 1
        || !Number.isSafeInteger(generation(session)) || generation(session) < 0) {
      throw fail('execution_admission_lost', '桌面执行需要当前服务实际持有的回合身份。');
    }
    const old = admissions.get(session.id), rewindGen = generation(session);
    if (old && old.session === session && old.owner === owner && old.turnSeq === session.turnSeq && old.rewindGen === rewindGen) return old.id;
    const entry = { id: crypto.randomBytes(32).toString('hex'), session, owner,
      driverRunId: owner.driverRunId, turnSeq: session.turnSeq, rewindGen };
    admissions.set(session.id, entry);
    return entry.id;
  }
  function release(sessionId, owner) {
    if (admissions.get(sessionId)?.owner === owner) admissions.delete(sessionId);
    for (const [session, calls] of pendingMain) {
      for (const call of calls) if (session.id === sessionId && call.owner === owner) calls.delete(call);
      if (!calls.size) pendingMain.delete(session);
    }
  }
  function canWriteStartupError() {
    return process.platform !== 'darwin' || rootOwned();
  }
  // Preparation uses this exact admitted session object, never caller-provided turn numbers.
  async function prepare({ session, owner, callId, toolName, args, client }) {
    const root = authority(), admitted = admissions.get(session.id);
    if (!admitted || admitted.session !== session || admitted.owner !== owner || typeof callId !== 'string' || !callId) {
      throw fail('execution_admission_lost', '工具调用没有当前回合的实际准入身份。');
    }
    return root.ledger.prepare({ sessionId: session.id, turnSeq: admitted.turnSeq, rewindGen: admitted.rewindGen,
      admissionId: admitted.id, callIdHash: crypto.createHash('sha256').update(admitted.driverRunId + '\0' + callId).digest('hex'),
      toolName, args, client });
  }
  function desktopClient(client) {
    return client?.id === 'ai-computer-control' || isEquivalentDesktopAccServer(client)
      || typeof client?.serverInfo?.name === 'string'
        && client.serverInfo.name.toLowerCase().replace(/[\s_-]/g, '') === 'aicomputercontrol';
  }
  function callRefusal(client, toolName, args, options = {}) {
    if (!enabled() || !desktopClient(client) || toolName === 'execution_receipt') return null;
    const permit = sendPermits.get(options.executionCheck);
    if (client instanceof McpStdioClient && permit && !permit.used && permit.client === client
        && permit.toolName === toolName && permit.args === args && permit.meta === options.meta && permit.verify()) return null;
    return { ok: false, code: 'execution_metadata_required', outcome: 'not_dispatched', action_sent: false,
      error: '桌面组件业务调用需要当前服务已保存的派发许可，未派发。' };
  }
  function clientEnvironment(id, env, descriptor = { id }) {
    if (!enabled() || !desktopClient(descriptor)) return env;
    authority();
    return { ...env, RUYI_EXECUTION_CONTEXT_REQUIRED: '1' };
  }
  function liveClient(client, child) {
    return rootOwned() && client instanceof McpStdioClient && desktopClient(client)
      && mcpClients.get(client.id) === client && !client.dead && !!child && client.child === child
      && client.executionContextRequired === true;
  }
  async function peerFor(client) {
    authority();
    const child = client?.child;
    if (!liveClient(client, child)) throw fail('execution_client_unverified', '桌面组件不是当前服务持有的必要上下文实例。');
    let pending = peers.get(client);
    if (!pending) {
      pending = (async () => {
        const probe = await probeDesktopExecutionReceipts(client);
        if (!probe.ok || !liveClient(client, child)) throw fail('execution_client_unverified', '桌面组件未确认执行回执协议。');
        return Object.freeze({ clientId: crypto.randomBytes(16).toString('hex'), accWorkerId: probe.accWorkerId,
          accPid: probe.accPid, contextRequired: true, child });
      })();
      peers.set(client, pending);
    }
    try { const peer = await pending;
      if (!liveClient(client, peer.child)) throw fail('execution_client_changed', '桌面组件实例已更换。');
      return peer;
    } catch (error) { if (peers.get(client) === pending) peers.delete(client); throw error; }
  }
  async function readiness(client) {
    const peer = await peerFor(client);
    const result = await client.callTool('execution_receipt', { invocation_id: '0'.repeat(32), control: 'readiness' });
    if (!liveClient(client, peer.child) || result?.ok !== true || result.readiness?.ok !== true) {
      throw fail('execution_control_unavailable', '桌面组件的只读状态检查失败。');
    }
    return result.readiness;
  }
  function context(session, owner, callId) {
    if (!enabled()) return null;
    const id = admit(session, owner);
    if (!id || typeof callId !== 'string' || !callId || callId.length > 1024) throw fail('execution_admission_lost', '工具调用缺少实际回合身份。');
    const key = Object.freeze(Object.create(null));
    contexts.set(key, { session, owner, callId, admissionId: id, invocationId: null, staged: null });
    return key;
  }
  async function invoke(client, toolName, args, options = {}, key = null) {
    const guardedSession = contexts.get(key)?.session.id || options.executionSessionId;
    if (enabled() && guardedSession) await guard(guardedSession);
    if (!enabled() || !desktopClient(client)) return client.callTool(toolName, args, undefined, options);
    const call = contexts.get(key);
    if (!call || call.invocationId || admissions.get(call.session.id)?.id !== call.admissionId) {
      throw fail('execution_admission_lost', '桌面调用没有当前主回合的执行身份，未派发。');
    }
    const root = authority(), peer = await peerFor(client);
    const facts = { clientId: peer.clientId, accWorkerId: peer.accWorkerId, accPid: peer.accPid, contextRequired: true };
    const prepared = await prepare({ session: call.session, owner: call.owner, callId: call.callId, toolName, args, client: facts });
    call.invocationId = prepared.invocationId;
    const verify = () => liveClient(client, peer.child) && current({ sessionId: call.session.id,
      turnSeq: prepared.metadata.turn_seq, rewindGen: generation(call.session), admissionId: call.admissionId });
    try {
      await root.ledger.markDispatch(prepared.invocationId, verify);
      const meta = copyOrdinaryJsonData({ 'org.ruyi.workbench/execution-v1': prepared.metadata });
      const metaJson = JSON.stringify(meta);
      const permit = { client, toolName, args: prepared.snapshot, meta, verify, used: false };
      const executionCheck = packet => {
          if (sendPermits.get(executionCheck) !== permit || permit.used) throw fail('execution_permit_invalid', '派发许可已失效。');
          if (!verify() || packet.method !== 'tools/call' || packet.params?.name !== toolName
              || JSON.stringify(packet.params.arguments) !== prepared.json
              || JSON.stringify(packet.params._meta) !== metaJson) {
            throw fail('execution_packet_changed', '实际发送的参数、元数据或执行身份发生变化，未发送。');
          }
          permit.used = true;
      };
      sendPermits.set(executionCheck, permit);
      let result;
      try { result = await client.callTool(toolName, prepared.snapshot, undefined, { ...options, meta, executionCheck }); }
      finally { sendPermits.delete(executionCheck); }
      const receipt = await client.callTool('execution_receipt', { invocation_id: prepared.invocationId });
      const observed = await root.ledger.recordResult(prepared.invocationId, result, receipt);
      if (observed.phase !== 'returned') throw fail('execution_reconciliation_required', '桌面结果的执行回执未确认，已停止自动继续。');
      let list = pendingMain.get(call.session);
      if (!list) { list = new Set(); pendingMain.set(call.session, list); }
      list.add(call);
      return result;
    } catch (error) {
      try { await root.ledger.recordUnknown(prepared.invocationId, 'host_call_incomplete'); } catch { /* durable gate already holds on storage/result failure */ }
      throw error;
    }
  }
  function stageMain(key, index, images = []) {
    if (!enabled() || !key) return;
    const call = contexts.get(key);
    if (!call?.invocationId || !pendingMain.get(call.session)?.has(call)) return;
    const row = call.session.providerHistory[index];
    if (!Number.isSafeInteger(index) || row?.role !== 'tool') throw fail('execution_delivery_invalid', '工具结果没有进入实际历史。');
    call.staged = { index, row: JSON.stringify(copyOrdinaryJsonData(row)),
      images: images.map(parts => JSON.stringify(copyOrdinaryJsonData(parts))) };
  }
  function appendMainTool(history, batch, row) {
    if (!enabled()) { history.push(row); return history.length - 1; }
    const anchor = history.indexOf(batch?.assistant);
    if (anchor < 0 || anchor !== batch.start - 1 || row?.role !== 'tool'
        || !batch.assistant.tool_calls?.some(call => String(call.id) === String(row.tool_call_id))) {
      throw fail('execution_history_changed', '工具批次的历史位置或请求身份发生变化。');
    }
    let index = batch.start;
    while (history[index]?.role === 'tool') index++;
    history.splice(index, 0, row);
    return index;
  }
  function mainDeliveryMatches(history, staged) {
    try {
      if (JSON.stringify(copyOrdinaryJsonData(history[staged.index])) !== staged.row || !Array.isArray(staged.images)) return false;
      return staged.images.every(image => Array.from(history).slice(staged.index + 1).some(row => row?.role === 'user'
        && JSON.stringify(copyOrdinaryJsonData(row.content)) === image));
    } catch { return false; }
  }
  async function flushMain(session, saveOptions) {
    const list = pendingMain.get(session);
    if (!list?.size) return;
    const root = authority(), calls = Array.from(list);
    if (calls.some(call => !call.staged)) throw fail('execution_delivery_invalid', '尚有桌面结果未进入历史。');
    const snapshot = copyOrdinaryJsonData(session.providerHistory), json = JSON.stringify(snapshot);
    for (const call of calls) if (!mainDeliveryMatches(snapshot, call.staged)) {
      throw fail('execution_delivery_changed', '待保存的工具结果或图像不完整，已停止自动继续。');
    }
    const turnSeq = session.turnSeq, rewindGen = generation(session);
    await saveSession(session, { ...saveOptions, requirePersisted: true, writer: 'desktop-execution-delivery' });
    const disk = await loadSession(session.id);
    if (!disk || disk.turnSeq !== turnSeq || generation(disk) !== rewindGen || JSON.stringify(copyOrdinaryJsonData(disk.providerHistory)) !== json) {
      throw fail('execution_delivery_unverified', '无法核实实际保存的工具历史，已停止自动继续。');
    }
    const digest = crypto.createHash('sha256').update(json).digest('hex');
    for (const call of calls) { await root.ledger.markDelivered(call.invocationId, digest); list.delete(call); }
    if (!list.size) pendingMain.delete(session);
  }
  function run(session, work) { return enabled() ? modelScope.run(session.id, work) : work(); }
  async function beforeModelRequest(explicitSessionId) {
    const sessionId = modelScope.getStore() || explicitSessionId;
    if (enabled() && sessionId) await guard(sessionId);
  }
  return Object.freeze({ initialize, guard, admit, release, prepare, canWriteStartupError,
    enabled, clientEnvironment, readiness, context, invoke, stageMain, flushMain, run, beforeModelRequest,
    mainDeliveryMatches, callRefusal, appendMainTool });
})();
Object.assign(DesktopExecutionHooks, DesktopExecutionRuntime);
ProviderHttpHooks.beforeModelRequest = DesktopExecutionRuntime.beforeModelRequest;
