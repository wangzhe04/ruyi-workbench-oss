"""Synthetic image payloads through the real ACC SDK/context/journal, never desktop I/O."""
import hashlib
import json
import os
from pathlib import Path

from ai_computer_control import server
from ai_computer_control.utils.execution_context import _request

PNG = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aWQAAAABJRU5ErkJggg=="


@server.mcp.tool()
def fixture_image(label: str) -> dict:
    """Return a fixed one-pixel PNG; this is not a screenshot."""
    return {"ok": True, "label": label, "image_base64": PNG, "format": "png", "width": 1, "height": 1}


@server.mcp.tool()
def fixture_observe(label: str) -> dict:
    """Observe only the fixture's own durable history before the next tool body."""
    root = Path(os.environ["RUYI_FIXTURE_DATA"])
    request = _request.get()
    # The trusted SDK scope owns the session metadata; no model path argument is accepted.
    state = json.loads((root / "desktop-executions-v1/state.json").read_text())
    invocation = request.journal.invocation_id
    current = next(row for row in state["entries"] if row["invocationId"] == invocation)
    session_id = current["sessionId"]
    raw = (root / "sessions" / (session_id + ".provider.ndjson")).read_bytes()
    lines = raw.splitlines()
    history = [json.loads(line) for line in lines]
    digest = hashlib.sha256(b"[" + b",".join(lines) + b"]").hexdigest()
    images = [row for row in history if row.get("role") == "user" and isinstance(row.get("content"), list)
              and any(part.get("type") == "image_url" for part in row["content"])]
    delivered = [row for row in state["entries"] if row["sessionId"] == session_id
                 and row["toolName"] == "fixture_image" and row.get("deliverySha256")]
    return {"ok": True, "label": label, "images": len(images), "deliveredImages": len(delivered),
            "lastImageDeliveryMatchesSnapshot": bool(delivered) and delivered[-1]["deliverySha256"] == digest,
            "roles": [row["role"] for row in history]}


server.main()
