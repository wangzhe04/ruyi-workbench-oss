'use strict';
require('./lib/self-isolate-home');
// Actual root/provider -> ACC -> negotiated native capture/Vision -> saved model history.
// Owned OCR window only. No input posting, clipboard changes, TCC changes or deliberate lock.
const fs = require('node:fs'), path = require('node:path'), os = require('node:os'), cp = require('node:child_process');
const { createRunner } = require('./lib/harness');
const { fixtureChildEnv } = require('./lib/fixture-home');
const { killOwnTree, snapshotProcessTable } = require('./lib/kill-own-tree');
const { startFakeProvider, textFrames, toolCallFrames } = require('./lib/fake-openai-provider');
const { getFreePort } = require('./free-port');
const { decodePng } = require('./lib/png-grid');
const t = createRunner('MACOS EXECUTION CAPTURE');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'rec-'));
const data = path.join(root, 'data'), work = path.join(root, 'work');
const env = { ...fixtureChildEnv(), HOME: path.join(root, 'home'), USERPROFILE: path.join(root, 'home'),
  APPDATA: path.join(root, 'appdata'), LOCALAPPDATA: path.join(root, 'localappdata'), TMPDIR: root,
  RUYI_HOME: data, WIN_CLAUDE_WORKBENCH_HOME: data, RUYI_DESKTOP_EXECUTION_RECEIPTS: '1' };
for (const dir of [data, work, env.HOME, env.APPDATA, env.LOCALAPPDATA]) fs.mkdirSync(dir, { recursive: true });
Object.assign(process.env, env);
let server, provider, fixture, port, token, output = '';
const reports = [], proof = [], continuations = [], specs = [];
const app = path.resolve(__dirname, '../ruyi-workbench/app/server.js');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function until(read, label, timeout = 20000) {
  const end = Date.now() + timeout;
  while (Date.now() < end) { const value = await read(); if (value) return value; await sleep(25); }
  throw new Error('Timed out ' + label + '\n' + output.slice(-3000));
}
function check(value, label) { t.ok(value, label); if (!value) throw new Error('Stopped after ' + label); }
async function api(route, body) {
  const res = await fetch(`http://127.0.0.1:${port}${route}`, { method: body === undefined ? 'GET' : 'POST',
    headers: { 'content-type': 'application/json', 'x-wcw-token': token },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw new Error(route + ': ' + res.status + ' ' + await res.text());
  return res.json();
}
async function start() {
  port = await getFreePort(); token = '';
  server = cp.spawn(process.execPath, [app, 'serve', '--port', String(port)], { env, cwd: work, stdio: ['ignore', 'pipe', 'pipe'] });
  server.stdout.on('data', bytes => { output += bytes; }); server.stderr.on('data', bytes => { output += bytes; });
  await until(async () => {
    try { const runtime = JSON.parse(fs.readFileSync(path.join(data, 'runtime.json')));
      if (runtime.pid !== server.pid || !runtime.token) return false;
      token = runtime.token; port = runtime.port; return (await api('/health')).ok;
    } catch { return false; }
  }, 'root ready');
}
async function stop(child, label) {
  if (!child) return;
  const identity = snapshotProcessTable()?.find(row => row.pid === child.pid);
  if (!identity) { if (child.exitCode !== null) return; throw new Error('Missing owned identity ' + label); }
  killOwnTree(child);
  await until(() => { const rows = snapshotProcessTable(); return rows && !rows.some(row => row.pid === identity.pid && row.created === identity.created); }, label + ' exit');
}
const history = sid => fs.readFileSync(path.join(data, 'sessions', sid + '.provider.ndjson'), 'utf8').trim().split('\n').map(JSON.parse);
const ledgerRows = sid => JSON.parse(fs.readFileSync(path.join(data, 'desktop-executions-v1/state.json'))).entries.filter(row => row.sessionId === sid);
const invoke = (name, args, id) => ({ name: 'tool_invoke_read', args: { name: 'ai_computer_control__' + name, arguments: args }, id });
async function run(spec) {
  spec.sessionId = (await api('/api/sessions', { title: spec.label, cwd: work })).session.id; specs.push(spec);
  const res = await fetch(`http://127.0.0.1:${port}/api/chat/stream`, { method: 'POST',
    headers: { 'content-type': 'application/json', 'x-wcw-token': token }, body: JSON.stringify({ sessionId: spec.sessionId, message: spec.label, cwd: work }),
    signal: AbortSignal.timeout(90000) });
  if (!res.ok) throw new Error('turn HTTP ' + res.status);
  const events = (await res.text()).split('\n').filter(Boolean).map(JSON.parse);
  await until(async () => (await api('/api/sessions/' + spec.sessionId)).execution === null, 'driver finally');
  const saved = history(spec.sessionId), rows = ledgerRows(spec.sessionId);
  const traces = rows.map(row => ({ invocationId: row.invocationId, records: fs.readFileSync(path.join(root, 'acc-data/logs/execution-receipts', row.invocationId, 'events.ndjson'), 'utf8').trim().split('\n').map(JSON.parse) }));
  const result = { spec, events, saved, rows, traces }; proof.push(result);
  check(!events.some(row => row.type === 'error') && JSON.stringify(events).includes('NATIVE_CHAIN_COMPLETE'), spec.label + ' actual root turn completes');
  check(rows.length === spec.calls.length && rows.every(row => row.phase === 'returned' && row.deliverySha256 && row.observed?.receipt), spec.label + ' all actual SDK results have strict receipts and saved deliveries');
  check(continuations.some(row => row.label === spec.label && row.rows.every(entry => entry.deliverySha256)), spec.label + ' actual next model request follows durable deliveries');
  for (let i = 0; i < rows.length; i++) {
    const trace = traces[i].records, accepted = trace[0];
    check(accepted.stage === 'acc_request_accepted' && accepted.session_id === spec.sessionId && accepted.turn_seq === rows[i].turnSeq
      && accepted.call_id_hash === rows[i].callIdHash && accepted.received_semantic_sha256 === rows[i].argsSemanticSha256,
    spec.label + ' native chain is bound to actual root preparation ' + rows[i].toolName);
    const entered = trace.filter(row => row.stage === 'native_entered');
    check(entered.length === spec.nativeOps[i].length && entered.every((row, j) => row.op === spec.nativeOps[i][j]), spec.label + ' real native handlers enter exact requested operations ' + rows[i].toolName);
    check(entered.every(row => trace.filter(end => end.stage === 'native_terminal' && end.operation_id === row.operation_id).length === 1
      && trace.some(start => start.stage === 'native_prepared' && start.operation_id === row.operation_id && start.frame_sha256 === row.frame_sha256))
      && trace.at(-1).stage === 'acc_request_terminal', spec.label + ' exact native frames have terminal receipts before SDK completion ' + rows[i].toolName);
  }
  return result;
}
(async () => {
  try {
    if (process.platform !== 'darwin' || process.env.RUYI_EXECUTION_CAPTURE_REQUIRED !== '1') { console.log('SKIP opt-in owned native capture/Vision receipt qualification'); return; }
    const helper = process.env.RUYI_EXECUTION_CONTEXT_HELPER, python = process.env.RUYI_ACC_PYTHON;
    if (!helper || !python) throw new Error('Explicit candidate helper and Python required');
    const binary = path.join(root, 'ocr-fixture'), localImage = path.join(work, 'bilingual.png');
    const built = cp.spawnSync('/usr/bin/xcrun', ['clang', '-fobjc-arc', '-fblocks', '-Wall', '-Wextra', '-Werror', '-mmacosx-version-min=14.0',
      '-framework', 'AppKit', '-framework', 'ApplicationServices', path.join(__dirname, 'fixtures/macos-ocr-window.m'), '-o', binary], { encoding: 'utf8', timeout: 60000 });
    if (built.error || built.status !== 0) throw new Error(built.error?.message || built.stderr);
    const image = cp.spawnSync(binary, ['--image', localImage], { env, encoding: 'utf8', timeout: 10000 });
    if (image.error || image.status !== 0) throw new Error(image.error?.message || image.stderr);
    fixture = cp.spawn(binary, [], { env, stdio: ['pipe', 'pipe', 'pipe'] });
    let lines = '';
    fixture.stdout.on('data', bytes => { lines += bytes; let end; while ((end = lines.indexOf('\n')) >= 0) { const line = lines.slice(0, end); lines = lines.slice(end + 1); try { reports.push(JSON.parse(line)); } catch { output += line; } } });
    fixture.stderr.on('data', bytes => { output += bytes; });
    const ready = await until(() => reports.find(row => row.event === 'ready'), 'owned OCR scene ready');
    check(ready.counts.every(count => count === 0), 'owned OCR scene starts without injected input');
    provider = await startFakeProvider({ handler(req) {
      const spec = specs.find(row => req.messages.some(message => message.role === 'user' && typeof message.content === 'string' && message.content.includes(row.label)));
      if (!spec) return textFrames('metadata fixture');
      if (spec.calls.every(call => req.messages.some(row => row.role === 'tool' && row.tool_call_id === call.id))) {
        continuations.push({ label: spec.label, messages: req.messages, rows: ledgerRows(spec.sessionId) }); return textFrames('NATIVE_CHAIN_COMPLETE');
      }
      return toolCallFrames(spec.calls);
    } });
    const acc = path.resolve(__dirname, '../mcp/ai-computer-control');
    fs.writeFileSync(path.join(data, 'config.json'), JSON.stringify({ configSchema: 9, permissionMode: 'bypass', defaultWorkspace: work,
      providers: [{ id: 'fake', type: 'openai-compat', baseUrl: provider.url, apiKey: 'synthetic-key', model: 'fake-model', vision: true }], activeProvider: 'fake',
      includeWorkbenchMcp: false, autoImportClaudeCodeMcp: false, enableMcpDropIn: false, schedulerEnabledV1: false, stewardEnabledV1: false,
      allowDesktopTools: true, allowCommandTools: true, desktopMcp: { enabled: false, autodetect: false }, bridgeExternalToolsToProvider: true,
      externalMcpServers: [{ id: 'ai-computer-control', enabled: true, command: python, args: ['-X', 'utf8', '-m', 'ai_computer_control.server'], cwd: acc,
        env: { ...env, PYTHONPATH: path.join(acc, 'src'), PYTHONDONTWRITEBYTECODE: '1', WCW_DATA_DIR: path.join(root, 'acc-data'),
          ACC_TOOLSETS: 'desktop,ocr,vision', ACC_HIDE_TOOLS: '', RUYI_MACOS_AUTOMATION_HELPER: helper } }] }));
    await start();
    const captured = await run({ label: 'NATIVE_WINDOW_CAPTURE', calls: [invoke('screenshot', { window_title: ready.title, max_width: 0 }, 'native_image'), invoke('get_screen_info', {}, 'native_status')], nativeOps: [['capture'], ['status']] });
    const imageRows = captured.saved.filter(row => row.role === 'user' && Array.isArray(row.content) && row.content.some(part => part.type === 'image_url'));
    check(imageRows.length === 1, 'real native screenshot reaches exactly one saved image row');
    const url = imageRows[0].content.find(part => part.type === 'image_url').image_url.url;
    check(url.startsWith('data:image/png;base64,'), 'actual screenshot retains PNG image transport');
    const png = Buffer.from(url.slice(url.indexOf(',') + 1), 'base64'), decoded = decodePng(png);
    check(decoded.width >= ready.content.width && decoded.height >= ready.content.height, 'independently decoded screenshot dimensions cover the owned window');
    const capturePath = path.join(work, 'captured-window.png'); fs.writeFileSync(capturePath, png);
    if (process.env.RUYI_EXECUTION_CAPTURE_EVIDENCE) fs.writeFileSync(process.env.RUYI_EXECUTION_CAPTURE_EVIDENCE.replace(/\.json$/, '') + '-window.png', png);
    const recognized = await run({ label: 'NATIVE_IMAGE_OCR', calls: [invoke('ocr_image', { path: localImage }, 'native_local_ocr'), invoke('ocr_image', { path: capturePath }, 'native_capture_ocr'), invoke('ocr_available_languages', {}, 'native_languages')], nativeOps: [['ocr.image'], ['ocr.image'], ['ocr.languages']] });
    for (const id of ['native_local_ocr', 'native_capture_ocr']) {
      const value = JSON.parse(recognized.saved.find(row => row.role === 'tool' && row.tool_call_id === id).content);
      check(value.ok === true && value.text.includes('INVOICE 42') && value.text.includes('中文测试'), 'real Vision recognizes English and Chinese through saved root result ' + id);
    }
    const negative = await run({ label: 'NATIVE_CAPTURE_REFUSAL', calls: [invoke('screenshot', { window_title: ready.title + ' missing' }, 'native_missing_window')], nativeOps: [['capture']] });
    const refused = JSON.parse(negative.saved.find(row => row.role === 'tool' && row.tool_call_id === 'native_missing_window').content);
    check(refused.ok === false && !negative.saved.some(row => row.role === 'user' && Array.isArray(row.content) && row.content.some(part => part.type === 'image_url')), 'missing owned window produces a real native failure with no invented image');
    fixture.stdin.write('status\n');
    const final = await until(() => reports.find(row => row.event === 'status'), 'owned scene final state');
    check(final.counts.every(count => count === 0) && final.counterText === ready.counterText, 'capture and OCR leave owned controls unchanged');
  } catch (error) { t.fail(error.stack || String(error)); }
  finally {
    try { await stop(server, 'owned root'); } catch (error) { t.fail(error.message); }
    try { if (fixture && fixture.exitCode === null) { fixture.stdin.write('quit\n'); await until(() => fixture.exitCode !== null, 'owned scene normal exit', 5000); } } catch { try { await stop(fixture, 'owned scene'); } catch (error) { t.fail(error.message); } }
    if (provider) await provider.close();
    if (process.env.RUYI_EXECUTION_CAPTURE_EVIDENCE) fs.writeFileSync(process.env.RUYI_EXECUTION_CAPTURE_EVIDENCE, JSON.stringify({ scope: 'actual root/ACC/native owned screenshot and Vision receipts and actual saved image history; no input, Stop/fault, background/CLI or wholeP5 acceptance', root, reports, proof, continuations, output }, null, 2));
    fs.rmSync(root, { recursive: true, force: true }); t.done();
  }
})();
