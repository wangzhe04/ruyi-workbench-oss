// ===== v1.9 会话存储 v2(head JSON + append-only NDJSON 正文)=====================================
// 背景:旧格式把整个 messages+providerHistory 塞进单个 <id>.json,saveSession 每轮全量序列化+原子重写
// —— 写放大 O(会话总历史)/轮:5MB 会话 = 每轮重写 5MB。v2 拆分为:
//   <id>.json              「头」:全部标量/小字段 + messageCount/providerHistoryCount + storageVersion:2(小,每次重写)
//   <id>.messages.ndjson   展示消息正文,一行一条 JSON,append-only
//   <id>.provider.ndjson   provider 引擎历史正文,同上
// 快路径(saveSession):两个数组只在尾部增长 → 每文件一次 append,O(增量)/轮。
// 慢路径(全量重写正文):任何前缀变化自动触发 —— rewind(slice)/compaction(reseed)/pop/蒸发改写。
// 检测机制【不靠调用方自觉打标记】:进程内状态表记着盘上每一行(行原文;内存预算不够时退成每行 sha1-16),
// save 时把前缀逐条重新序列化、逐行比对;任何对不上(含未来新代码忘了声明的中间改写)都安全降级为全量重写
// —— 失配只可能损失性能,不可能丢数据。(perf:比对用的是行原文,见 sessionBodyState 头注。)
// 崩溃语义:头是提交点(正文先写、头后写)。append 崩溃中途 → 无 \n 终结的撕裂尾行,读取时物理截断;
// append 完成但头写未完成 → 正文比头声明的多出「未提交尾巴」,读取时按头计数截断;慢路径(全量重写)
// 崩溃 → .prevbody 快照(重写前旧正文)恢复与旧头重新配对;正文比头声明的短 / 中间行损坏且无快照可退
// = 真损坏 → v1bak 回退(迁移期)或隔离为 .corrupt(与旧单文件损坏同纪律)。
// 迁移:legacy <id>.json 首次 load 时原样备份 <id>.json.v1bak 再落 v2;v2 下次成功读取后自动删 v1bak。
const SESSION_STORAGE_VERSION = 2;
// 架构还债批 3·B: 会话级内存覆盖表(sessionEngineRouteOverrides/权限档/桌面工具)与其归一、应用函数抽至 02d-session-overrides.js。

function sessionBodyPaths(id) {
  assertSessionIdForPath(id);
  return {
    messages: path.join(paths.sessions, `${id}.messages.ndjson`),
    provider: path.join(paths.sessions, `${id}.provider.ndjson`),
  };
}

// ── 105b: session-notes.md 状态外置(旁车副本)─────────────────────────────────
// L2 摘要成功后,把结构化摘要中的【已确认的决定】/【未完成事项】/【关键文件与上下文】三节确定性
// 切出整写到本文件。默认每次 L2 成功整体重写(摘要本身即最新权威状态);105d 的
// runtimeSessionNotesMergeV1(默认关)开启时改为 read→merge→write 增量合并,合并逻辑在
// 10-context-governance.js 的 mergeSessionNotes,本层只负责原子写与尾部截断兜底。
// 纪律:与 interventions/changes 旁车同层同规 —— 独立 per-session 写链 + 原子写;notes 是易失副本,
// 读失败/缺文件一律 null,绝不阻断回合。105b 真实历史门通过后默认开启；显式关时零文件读写。
const SESSION_NOTES_MAX_CHARS = 64000;
const sessionNotesWriteChains = new Map();
function sessionNotesPath(id) {
  return path.join(paths.sessions, `${String(id)}.session-notes.md`);
}
async function writeSessionNotes(id, markdown) {
  const file = sessionNotesPath(id);
  let body = String(markdown == null ? '' : markdown);
  if (body.length > SESSION_NOTES_MAX_CHARS) {
    body = body.slice(0, SESSION_NOTES_MAX_CHARS) + `\n\n<!-- truncated: exceeded ${SESSION_NOTES_MAX_CHARS} chars -->\n`;
  }
  return runKeyedChain(sessionNotesWriteChains, file, async () => {
    await fsp.mkdir(paths.sessions, { recursive: true }); // 旁车写不依赖 server 启动期建目录
    await atomicWriteJson(file, body);                    // 字符串直写,同 25.1 md 先例
  });
}
async function readSessionNotes(id) {
  try { return await fsp.readFile(sessionNotesPath(id), 'utf8'); }
  catch { return null; } // ENOENT 与其他读错同处理:notes 是旁车副本,缺文件不是错误
}

// ── C2(61 号文):会话草稿本 sessions/<id>.scratchpad.json ──────────────────────────────────────
// 模型自己「写即生效、不进长期库」的短笔记:按 key 写/覆盖,text 为空即删。只发给模型服务商引擎普通会话的主回合
// (工具 scratchpad_write:schema 在 13f、发放在 07 buildOpenAiTools 的 opts.scratchpadEnabled、handler 在 12);
// 09 每回合把快照贴到末条 user 尾部(非持久,见那里的缓存账)。与 session-notes 分工:notes 由运行时在 L2 压缩后
// 从摘要写出,模型没有写入口;草稿本只有模型写。长期偏好与项目约定仍走 workbench_memory_propose(确认制)。
// 落盘走 DurableJsonStore(01):schema 1、清洗(限额对手改过的文件同样成立)、坏文件当空(quarantine:false ——
// 草稿是易失副本,下一次写自愈,不留 .corrupt)、原子写。cache:false:每会话一个文件,store 按调用现建(构造只是
// 几个闭包),读永远读盘 —— 删会话后不会有进程缓存把旧条目「复活」进下一次注入。同一会话的读-改-写由 runKeyedChain
// 按会话 id 串行(store 自带的写链按实例,不跨实例,这里不依赖它)。
const SESSION_SCRATCHPAD_SCHEMA = 1;
const SESSION_SCRATCHPAD_LIMITS = Object.freeze({ maxEntries: 32, maxKeyChars: 40, maxTextChars: 2000, maxTotalChars: 12000 });
const sessionScratchpadChains = new Map();
function sessionScratchpadPath(id) {
  return path.join(paths.sessions, `${assertSessionIdForPath(id)}.scratchpad.json`);
}
// key:控制字符换空格、折叠空白、trim。不截断 —— 截断会让两个不同的 key 悄悄撞成一个,超长由调用方拒绝。
function normalizeScratchpadKey(raw) {
  return String(raw == null ? '' : raw).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim();
}
// text:统一换行、去掉 \n \t 以外的控制字符、trim(保留多行)。
function normalizeScratchpadText(raw) {
  return String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, '').trim();
}
// 总长只数正文(key 另有单条上限,20 × 40 有界)。
function scratchpadTotalChars(entries) {
  return (Array.isArray(entries) ? entries : []).reduce((n, e) => n + String((e && e.text) || '').length, 0);
}
// 盘上形状 { schema:1, updatedAt, entries:[{ key, text, at }] }。用数组保序:对象键里的 "1"、"42" 这类整数键会被 JS 重排。
// 清洗丢掉手改坏的条目、同 key 留最后一条、超长正文截断、超出条目数 / 总长从最早的条目丢起 —— 于是注入块的大小
// 只取决于限额,一份手改的大文件撑不大它。
function sanitizeSessionScratchpad(value) {
  const L = SESSION_SCRATCHPAD_LIMITS;
  const byKey = new Map();
  for (const raw of Array.isArray(value && value.entries) ? value.entries : []) {
    if (!raw || typeof raw !== 'object') continue;
    const key = normalizeScratchpadKey(raw.key);
    const text = normalizeScratchpadText(raw.text).slice(0, L.maxTextChars);
    if (!key || key.length > L.maxKeyChars || !text) continue;
    byKey.delete(key);
    byKey.set(key, { key, text, at: typeof raw.at === 'string' ? raw.at.slice(0, 40) : '' });
  }
  let entries = [...byKey.values()];
  if (entries.length > L.maxEntries) entries = entries.slice(-L.maxEntries);
  while (entries.length && scratchpadTotalChars(entries) > L.maxTotalChars) entries.shift();
  return { schema: SESSION_SCRATCHPAD_SCHEMA, updatedAt: typeof (value && value.updatedAt) === 'string' ? value.updatedAt.slice(0, 40) : '', entries };
}
function sessionScratchpadStore(id) {
  return DurableJsonStore.create({
    id: 'session-scratchpad',
    file: sessionScratchpadPath(id),   // 不合形的 id 在这里就抛(assertSessionIdForPath)
    schemaVersion: SESSION_SCRATCHPAD_SCHEMA,
    cache: false,
    quarantine: false,
    defaultValue: () => ({ schema: SESSION_SCRATCHPAD_SCHEMA, updatedAt: '', entries: [] }),
    sanitize: sanitizeSessionScratchpad,
    validate: value => value.schema === SESSION_SCRATCHPAD_SCHEMA && Array.isArray(value.entries),
    onCorrupt(error) {
      try { logEvent({ kind: 'session_scratchpad_corrupt', sessionId: String(id), error: String((error && error.message) || error).slice(0, 200) }); } catch { /* 诊断绝不阻断 */ }
    },
  });
}
// 读:缺文件 / 坏文件 / 读不动 / 不合形的 id 一律空表 —— 草稿是旁车副本,绝不阻断回合。
async function readSessionScratchpad(id) {
  try { return (await sessionScratchpadStore(id).read()).entries; }
  catch { return []; }
}
// 读-改-写(按会话串行)。mutate 拿到条目副本,返回 { entries, changed, ...其余字段原样带回 };changed 为假 = 不落盘。
// 会话已删除(墓碑,见 markSessionDeleted)时拒写:垂死回合里迟到的一次写不得在 unlink 之后把旁车写回来。
async function updateSessionScratchpad(session, mutate) {
  const id = String((session && session.id) || '');
  const store = sessionScratchpadStore(id);
  return runKeyedChain(sessionScratchpadChains, id, async () => {
    if (sessionSaveIsTombstoned(session)) return { refused: 'session-deleted' };
    const current = (await store.read()).entries.map(e => ({ ...e }));
    const out = mutate(current) || {};
    if (out.refused || !out.changed) return { entries: current, ...out };
    const saved = await store.write({ schema: SESSION_SCRATCHPAD_SCHEMA, updatedAt: nowIso(), entries: out.entries });
    return { ...out, entries: saved.entries };
  });
}

// ── 第71波 EC-E 切片二:未决事项 Intervention 持久化(append-only NDJSON)──────────────────────────
// permission/question/plan 三类未决事项此前是纯内存 Map(04-permission-runtime:191/194/199),进程重启即消失
// -- 无审计、无终态化,/api/missions 的 missionPendingCounts(13d:59)前三类读空 Map 归零,与前端 stale 卡片
// 不一致。本波把它们旁路持久化为 Intervention 记录:注册时 append 一行(pending),决策/超时/清理时 append 一行
// (终态),读时按 id 后写胜折叠。**不参与 promise resolve 链** -- 超时自动拒绝、权限默认不放宽语义完全不动,
// Intervention 只是审计/读模型/重启终态化的旁路记录(执行权威源仍是内存 Map)。
// 第71b波:task-pool proposed 统一进来(第四类 type:'pool')——提案注册/审批/拒绝/过期全部旁路记账,
// missionPendingCounts 四源统一从本店读;pool 与前三类的重启语义不同(提案随 run 快照存活,paused run
// 恢复后仍可审批),故 markInterruptedInterventions 对 pool 型按 run 状态分流(见下),不一刀切 cancelled_restart。
//
// 崩溃语义:同 messages.ndjson -- append 永远「整行 + 尾随 \n」一次写,撕裂尾行(无 \n 终结)读取时 JSON.parse
// 失败被跳过(append-only,丢一条审计记录不致命:执行语义走内存 Map,读模型少一条不阻断)。后写胜折叠保证
// 同一 ivId 的多条记录(request -> settle -> cancel_restart)取最后一条为权威终态。
function interventionFilePath(sessionId) {
  return path.join(paths.sessions, `${sessionId}.interventions.ndjson`);
}
// per-session 写链:串行化同会话的 append,防两条 line 交错(注册在流式期、决策在用户点击,可能并发)。
// 独立于 sessionWriteChains(saveSession 的链),互不影响;链错误吞掉(下一写自愈)。
const interventionWriteChains = new Map();
const interventionAppendCounts = new Map(); // 75c: cheap cadence trigger for bounded journal compaction checks
// 75a (Pretender P1): in-memory cache of the last COMPLETE Intervention record per (sessionId, ivId).
// Populated by registerIntervention; refreshed by settleIntervention. Lets settleIntervention write a
// complete state row (preserving type/requestedAt/toolName/questions from the register row) without a
// disk read. On cache miss (e.g. a pool proposal settled after a process restart where the register
// happened last lifecycle), settle writes what it has and readInterventions' merge-fold still preserves
// the register row's fields from disk. The cache is a VIEW of the journal (journal stays authoritative
// on disk); it is empty on boot and re-populated as interventions register in this lifecycle.
// 缓存条目只活到这条 Intervention 结算(settleIntervention / transitionInterventionState 落终态时摘掉)或会话被删
// (dropInterventionSessionState)—— 修前从不删,每条介入留一份完整记录(含 input)在内存里,长跑进程只增不减。
const interventionRecordCache = new Map();
function ivCacheKey(sid, ivId) { return String(sid) + '\x00' + String(ivId); }
// 会话被删:摘掉它名下的介入缓存与压实节拍计数(deleteSession 调)。
function dropInterventionSessionState(sid) {
  const prefix = String(sid) + '\x00';
  for (const key of interventionRecordCache.keys()) if (key.startsWith(prefix)) interventionRecordCache.delete(key);
  interventionAppendCounts.delete(String(sid));
}
// 75a-2b (S3): per-session in-memory high-water mark of mission.changeSeq -- the max value written to disk
// within this process lifecycle. Lets saveSession preserve disk-side bumps from intervention transitions
// via max(in-memory, highWater) WITHOUT re-reading the head (prevents the turn's in-memory session object
// from clobbering an intervention's changeSeq bump). Seeded by loadSession; reset on crash (re-seeded on load).
const missionChangeSeqHighWater = new Map();
// 107-F7b(撤回被陈旧快照盖回):会话的【撤回代数】高水位 —— 与上面 missionChangeSeqHighWater 同一个模具,
// 被护住的是正文而不是账本计数。症状:用户递话后立刻点「撤回」,撤回回 ok:true,消息却还在。取证(红轮
// 日志):撤回那一存无条件写 providerHistoryCursor=0,盘上却是 2 —— 撤回那一存被一个【撤回之前就攥在手里】
// 的会话对象整份盖回了。这类写者不止垂死回合一个(回合 settle 之后才动手的 updateSessionMeta 读改写、
// 收工补写 threadBrief、手动压缩等等都能恰好把 load 落在撤回之前、把 save 落在撤回之后),69 波那道
// 「自动停回合 + 等 settle」的闸只管得住垂死回合自己。
// 机制:会话头上一个单调整数 rewindGen(缺省视为 0);撤回那一存在【入写链的同一拍】把自己那份对象的
// rewindGen 加一,并抬高本表。saveSession 在写链里、真正落盘之前比对:对象的
// rewindGen 低于高水位 = 这是撤回之前的快照 = 整次写丢弃(正文与头都不写),落 session_stale_save_dropped。
// 只在进程内:重启后表为空,所有对象都从盘上新读(loadSession 每次都 JSON.parse 新解析,没有对象缓存),
// 不会误丢。loadSession 另有一道自愈:读到的代数低于高水位 = 这次读恰好落在「代数已抬、撤回那一存还没
// 落盘」的窗口里 → 等写链跑完再读一次,所以撤回【之后】才读的人永远拿到撤回之后的状态。
const sessionRewindGenHighWater = new Map();
// 第79波:changeSeq 不再只有一个计数器。每次事实推进同时写一条 append-only change record，
// 让回来摘要可以严格消费 (lastSeenRevision,currentRevision]，并保留可追溯的原始 source cursor。
// 老任务可能已有 changeSeq、却没有本流水：首条记录的前缀被视为 migration baseline；前端首读
// 从当前 revision 建基线。若已读游标落在 baseline 之前、或流水内部/尾部缺号，则显式 degraded。
const MISSION_CHANGE_TYPES = new Set([
  'mission_started', 'progress', 'failure', 'budget', 'intervention_pending',
  'intervention_resolved', 'result', 'rewind', 'run_deleted',
  // 116-2b(27 号文 §11.6「116b 登记的缺口」):停滞与预算触顶此前只走 SSE 与审计日志,没有任何
  // 带 seq 的持久记录 —— 收件箱(它只读三条 seq 日志)因此永远拿不到这两类信号。这里【只加不改】
  // 两个新 type:'stalled'(语义死循环纠偏/节点无进展等"还在跑但没往前走")与 'budget_tripped'
  // (回合 token 预算保护触顶)。既有九种的形状、顺序、语义一律不动。
  'stalled', 'budget_tripped',
  // 116g(27 号文 §3.1「事项跨会话升格」):线程加入/移出事项、事项合并/拆分。只加不改 —— 既有
  // 十一种的形状、顺序、语义一律不动。它【不】属于收件箱五类(它是归属变更,不是"需要你/失败/收工/
  // 停滞/预算"),故 13g 的 STEWARD_SOURCE_EVENT_MAP 把它登记为 null(显式丢弃,不是漏登)。
  'mission_membership',
]);
const missionChangeWriteChains = new Map();
function missionChangeFilePath(sessionId) {
  return path.join(paths.sessions, `${sessionId}.changes.ndjson`);
}
function boundedChangeText(value, max = 240) {
  return String(value == null ? '' : value).replace(/\s+/g, ' ').trim().slice(0, max);
}
function normalizeMissionChangePayload(payload) {
  const input = payload && typeof payload === 'object' ? payload : {};
  const type = MISSION_CHANGE_TYPES.has(input.type) ? input.type : 'progress';
  const cursor = input.cursor && typeof input.cursor === 'object' && !Array.isArray(input.cursor)
    ? Object.fromEntries(Object.entries(input.cursor).slice(0, 12).map(([key, value]) => [boundedChangeText(key, 40), typeof value === 'number' ? value : boundedChangeText(value, 160)]))
    : {};
  const detail = input.detail && typeof input.detail === 'object' && !Array.isArray(input.detail)
    ? Object.fromEntries(Object.entries(input.detail).slice(0, 20).map(([key, value]) => {
      if (typeof value === 'number' || typeof value === 'boolean' || value === null) return [boundedChangeText(key, 40), value];
      if (Array.isArray(value)) return [boundedChangeText(key, 40), value.slice(0, 20).map(item => boundedChangeText(item, 240))];
      return [boundedChangeText(key, 40), boundedChangeText(value, 480)];
    }))
    : {};
  return { type, cursor, detail };
}
// 117q-B6(30 号文 P2-11):此前 repairMissionChangeTornTail(本函数)与 repairInterventionTornTail(旧
// 71a 撕裂尾修复,02:344 一带)是同一算法的两份手写——真身是本函数(已被 13g/13i 两处共用),旧函数
// 只有 appendIntervention 一个调用点,已删,该调用点改调本函数(见下方 appendIntervention)。
// 读取原语收编进 01-config.js 的 readFileTail(30 号文 P2-10)——原实现用 Buffer.allocUnsafe 且不检查
// fd.read 的 bytesRead,直接对整段已分配 buffer 取最后一字节 / lastIndexOf;若实际读到的字节数少于
// 请求的 65536(stat 与 read 之间文件被截短等罕见竞态),就是在对未初始化/陈旧内存算截断点——而这个
// 截断点会被拿去 fsp.truncate()。这里【一律按 bytesRead 定界】(不用 buf.length/请求的窗口大小),
// 这就是修 bug 的那一步;尾窗起点 start 仍按原请求窗口(size - 65536)计算,与原逻辑一致。
async function repairMissionChangeTornTail(file) {
  const TAIL = 65536;
  const { buf, bytesRead, size } = await readFileTail(file, TAIL);
  if (size <= 0 || !bytesRead) return; // 不存在(-1)/空文件(0)/尾窗读到 0 字节(无数据可判)
  if (buf[bytesRead - 1] === 0x0a) return; // 按 bytesRead 定界:只看已实际读到的最后一个字节
  const lastNl = buf.lastIndexOf(0x0a, bytesRead - 1); // 搜索起点同样钉在 bytesRead-1,不扫未读区
  const start = Math.max(0, size - TAIL);
  await fsp.truncate(file, lastNl === -1 ? start : start + lastNl + 1);
}
function appendMissionChangeRecord(sessionId, record) {
  const sid = String(sessionId || '');
  if (!sid) return Promise.resolve();
  const file = missionChangeFilePath(sid);
  return runKeyedChain(missionChangeWriteChains, sid, async () => {
    await repairMissionChangeTornTail(file);
    await fsp.appendFile(file, JSON.stringify(record) + '\n', 'utf8');
    markPretenderIndexDirty(sid, 'source');
  });
}
function foldMissionChangeJournalText(txt, currentRevision = 0) {
  const records = [];
  let corruptLines = 0;
  for (const line of String(txt || '').split('\n')) {
    if (!line) continue;
    let record;
    try { record = JSON.parse(line); } catch { corruptLines++; continue; }
    const seq = Number(record && record.seq);
    if (!record || !Number.isSafeInteger(seq) || seq < 1 || !MISSION_CHANGE_TYPES.has(record.type)) { corruptLines++; continue; }
    records.push(record);
  }
  records.sort((a, b) => Number(a.seq) - Number(b.seq));
  const baseRevision = records.length ? Number(records[0].seq) - 1 : Math.max(0, Number(currentRevision) || 0);
  let gap = null;
  for (let i = 1; i < records.length; i++) {
    const expected = Number(records[i - 1].seq) + 1;
    const actual = Number(records[i].seq);
    if (actual !== expected) { gap = { expected, actual }; break; }
  }
  const lastRevision = records.length ? Number(records[records.length - 1].seq) : baseRevision;
  const current = Math.max(0, Number(currentRevision) || 0);
  if (!gap && lastRevision < current) gap = { expected: lastRevision + 1, actual: current + 1, tail: true };
  if (!gap && lastRevision > current) gap = { expected: current + 1, actual: lastRevision, ahead: true };
  return { records, baseRevision, currentRevision: current, lastRevision, corruptLines, gap, degraded: corruptLines > 0 || Boolean(gap) };
}
async function readMissionChangesWithMeta(sessionId, currentRevision = null) {
  const sid = String(sessionId || '');
  let current = currentRevision == null ? NaN : Number(currentRevision);
  if (!Number.isSafeInteger(current) || current < 0) {
    try {
      const head = JSON.parse(await fsp.readFile(sessionPath(sid), 'utf8'));
      current = Math.max(0, Number(head && head.mission && head.mission.changeSeq) || 0);
    } catch { current = 0; }
  }
  let txt = '';
  try { txt = await fsp.readFile(missionChangeFilePath(sid), 'utf8'); } catch { /* missing journal = migration baseline */ }
  return foldMissionChangeJournalText(txt, current);
}
// Persist a head advance and its record in one per-session chain. The head commits first; a crash between
// head and journal creates a detectable tail gap instead of a silently false summary. Existing callers may
// keep fire-and-forget semantics; routes that need the returned revision can await the promise.
function bumpMissionChangeSeq(sessionId, payload = {}) {
  const sid = String(sessionId || '');
  if (!sid) return Promise.resolve(null);
  const next = (missionChangeSeqHighWater.get(sid) || 0) + 1;
  missionChangeSeqHighWater.set(sid, next); // sync: visible to concurrent saveSession before disk write
  const prev = sessionWriteChains.get(sid) || Promise.resolve();
  const w = prev.catch(() => {}).then(async () => {
    let txt; try { txt = await fsp.readFile(sessionPath(sid), 'utf8'); } catch { if (missionChangeSeqHighWater.get(sid) === next) missionChangeSeqHighWater.delete(sid); return null; }
    let head; try { head = JSON.parse(txt); } catch { if (missionChangeSeqHighWater.get(sid) === next) missionChangeSeqHighWater.delete(sid); return null; }
    if (!head || !head.mission || typeof head.mission !== 'object') { if (missionChangeSeqHighWater.get(sid) === next) missionChangeSeqHighWater.delete(sid); return null; }
    const revision = Math.max(next, Number(head.mission.changeSeq) + 1 || 1);
    missionChangeSeqHighWater.set(sid, revision);
    head.mission.changeSeq = revision;
    head.mission.updatedAt = nowIso();
    bumpSessionDiskWriteSeq(sid);   // 头被改写:在此之前读到头的装载不得再回写旧副本
    await atomicWriteJson(sessionPath(sid), JSON.stringify(head, null, 2));
    const normalized = normalizeMissionChangePayload(payload);
    await appendMissionChangeRecord(sid, {
      schemaVersion: 1,
      missionId: sessionMissionId(head) || sid,
      sessionId: sid,
      seq: revision,
      type: normalized.type,
      occurredAt: nowIso(),
      cursor: normalized.cursor,
      detail: normalized.detail,
    });
    return revision;
  }).catch(() => null);
  sessionWriteChains.set(sid, w);
  w.then(() => { if (sessionWriteChains.get(sid) === w) sessionWriteChains.delete(sid); }, () => { if (sessionWriteChains.get(sid) === w) sessionWriteChains.delete(sid); });
  return w;
}

// ── 116-2b:停滞/预算信号的【写入端频控】────────────────────────────────────────────────────
// 为什么频控放在写入端而不是读取端(收件箱):loop_recovery 每纠偏一次就是一条信号,一个卡住的
// 回合几分钟内能刷十几条 —— 让它们全都落进 append-only 账本,等于用噪声把账本本身撑坏,读取端
// 再怎么去重也救不回已经写进去的字节。故:同一 run/会话的 stalled 五分钟内只落一条;
// budget_tripped 每回合最多一条(触顶后回合就 break 了,同一 turnSeq 不该有第二条)。
//
// 表只在内存(进程重启 = 窗口重开)。这是刻意的:重启后第一条信号值得记 —— 崩溃续跑本身就是
// 用户该知道的事,宁可多一条也不要把"重启后仍然卡住"这条静音掉。
const MISSION_STALL_SIGNAL_WINDOW_MS = 5 * 60 * 1000;
const missionSignalThrottleAt = new Map();     // key -> 上次落账时间(ms)
const missionBudgetTripTurns = new Map();      // sessionId -> 已落过 budget_tripped 的 turnSeq
// 窗口内已经落过就返回 false(并保留旧时间戳);允许就记下本次时间并返回 true。表超过 500 条时
// 顺带清一遍过期项(信号稀疏,清理成本可忽略;不设 timer 以免开关关时也有后台活动)。
function missionSignalThrottleAllow(key, windowMs) {
  const k = String(key || '');
  if (!k) return false;
  const now = Date.now();
  const window = Number(windowMs) || MISSION_STALL_SIGNAL_WINDOW_MS;
  const last = missionSignalThrottleAt.get(k);
  if (Number.isFinite(last) && now - last < window) return false;
  if (missionSignalThrottleAt.size > 500) {
    for (const [key2, at] of missionSignalThrottleAt) if (now - at >= window) missionSignalThrottleAt.delete(key2);
  }
  missionSignalThrottleAt.set(k, now);
  return true;
}
// 普通回合的停滞信号 → change type 'stalled'。detail 只带摘要与计数(reason/tool/count),永不带
// 工具输出正文 —— 与 'failure' 的 detail 纪律同口径。无 mission 的会话由 bumpMissionChangeSeq
// 自己 no-op(它读会话头,没有 head.mission 就直接返回 null),这里不重复判断。
function recordMissionStalledChange(sessionId, detail) {
  const sid = String(sessionId || '');
  if (!sid) return Promise.resolve(null);
  if (!missionSignalThrottleAllow('mission:' + sid, MISSION_STALL_SIGNAL_WINDOW_MS)) return Promise.resolve(null);
  const d = (detail && typeof detail === 'object') ? detail : {};
  return bumpMissionChangeSeq(sid, {
    type: 'stalled',
    cursor: { turnSeq: Number(d.turnSeq) || 0, engine: String(d.engine || '') },
    detail: {
      reason: String(d.reason || ''),
      tool: String(d.tool || ''),
      count: Number(d.count) || 0,
      remaining: Number(d.remaining) || 0,
    },
  });
}
// 回合 token 预算保护触顶 → change type 'budget_tripped'(注意与既有 'budget' 区别:后者是每回合
// 用量入账的心跳,116b 已判定为心跳丢弃;真正的"触顶"从本波起有自己的 type)。
function recordMissionBudgetTrippedChange(sessionId, detail) {
  const sid = String(sessionId || '');
  if (!sid) return Promise.resolve(null);
  const d = (detail && typeof detail === 'object') ? detail : {};
  const turnSeq = Number(d.turnSeq) || 0;
  if (missionBudgetTripTurns.get(sid) === turnSeq) return Promise.resolve(null); // 每回合最多一条
  missionBudgetTripTurns.set(sid, turnSeq);
  if (missionBudgetTripTurns.size > 500) {
    for (const [key2] of missionBudgetTripTurns) { missionBudgetTripTurns.delete(key2); if (missionBudgetTripTurns.size <= 400) break; }
  }
  return bumpMissionChangeSeq(sid, {
    type: 'budget_tripped',
    cursor: { turnSeq, engine: String(d.engine || '') },
    detail: {
      axis: String(d.axis || ''),
      spent: Number(d.spent) || 0,
      budget: Number(d.budget) || 0,
      reserveEstimate: Number(d.reserveEstimate) || 0,
    },
  });
}
// 75a: before appending, ensure the NDJSON file ends with '\n'. A torn tail (a previous append crashed
// mid-write, leaving bytes with no terminating '\n') would otherwise weld the new line into the partial
// tail, silently losing both records. Same discipline as readSessionBodyFile for messages.ndjson.
// 117q-B6(30 号文 P2-11):此前这里是独立一份 repairInterventionTornTail,与上面 repairMissionChangeTornTail
// 算法逐字节相同。该函数只有本处一个调用点,已删除旧函数,改调真身。
// 117q-B6fix:B6 的自证「外层 .catch(() => {}) 兜住,对外可见行为不变」是错的——那个 catch 在
// fsp.appendFile *之后* 才接住,救不了这一行。真身 repairMissionChangeTornTail 内部没有 catch,修复
// 失败(如 readFileTail/fsp.truncate 之间的罕见竞态或权限错误)就会在 appendFile *之前* 抛出,整个
// then 块中断,这一条 intervention 记录被静默丢弃、没有任何痕迹。被删的旧函数最后一行是
// `catch { /* best-effort repair; a failed repair leaves the torn tail for the next append to retry */ }`——
// intervention 这一路本来就是 best-effort:内存态(interventionRecordCache 等)才是执行权威源,落盘
// 失败不该阻断执行;修复失败就把撕裂尾留给下一次 append 重试。这里补回同等语义的 try/catch,不改
// 真身本身的抛出行为(appendMissionChangeRecord 与 13g/13i 三个消费者仍然需要它抛)。
function appendIntervention(sessionId, record) {
  const sid = String(sessionId || '');
  if (!sid) return;
  const line = JSON.stringify(record) + '\n';
  const file = interventionFilePath(sid);
  const prev = interventionWriteChains.get(sid) || Promise.resolve();
  const next = prev.catch(() => {}).then(async () => {
    try { await repairMissionChangeTornTail(file); } catch { /* best-effort repair; a failed repair leaves the torn tail for the next append to retry (117q-B6fix) */ }
    for (let attempt = 0; ; attempt++) {   // Windows 瞬时锁有界重试;仍失败就抛给下面的 catch → next 解析为 undefined(= 没落盘)
      try { await fsp.appendFile(file, line, 'utf8'); break; }
      catch (e) { if (attempt >= 3 || !/^(EPERM|EBUSY|EACCES)$/.test(String(e && e.code))) throw e; await new Promise(r => setTimeout(r, 10 + attempt * 20)); }
    }
    markPretenderIndexDirty(sid, 'source'); // 75c: authority changed; materialized view is disposable
    return true;
  }).catch(() => {});
  interventionWriteChains.set(sid, next);
  next.then(() => {
    // 128f-⑫:待决的每一次结算(允许/拒绝/回答/批准/驳回/超时/回合收尾取消)都从 appendIntervention 过。修前只有
    // 「产生」那一刻有推送(registerIntervention 的 thread.needs_you),结算那一刻没有 —— 用户在中栏点了「允许」,
    // 左栏那枚「等你」要等回合收尾才消失。写链落定之后派,订阅者现算的待决计数才是结算之后的。放在写入块【外面】:
    // 那一块被 readfiletail-torntail (c2) 原样抠出来单独执行,块里只许有它传进去的那几样。
    if (record && record.status !== 'pending') RUYI_EVENTS.emit('thread.state', { sessionId: sid });
    if (interventionWriteChains.get(sid) === next) interventionWriteChains.delete(sid);
    const count = (interventionAppendCounts.get(sid) || 0) + 1;
    interventionAppendCounts.set(sid, count);
    if (count % 128 === 0) void compactInterventionJournal(sid).catch(() => {});
  });
  return next; // 75a-2: expose write promise so transitionInterventionState can await (authoritative write-before-advance); resolves true only when the row landed
}
// 注册一个 pending Intervention。type: 'permission'|'question'|'plan'|'pool'(71b)。ivId 复用 requestId/questionId/planId/poolId(执行权威源的同一 id)。
function registerIntervention(sessionId, type, ivId, extra) {
  const sid = String(sessionId || ''), id = String(ivId || '');
  const rec = { id, type, sessionId: sid, status: 'pending', requestedAt: nowIso(), decidedAt: '', decidedBy: '', interventionVersion: 0, ...(extra || {}) };
  interventionRecordCache.set(ivCacheKey(sid, id), rec); // 75a: cache complete record for settle's complete-state merge
  // 121-K2a(§6.1 第 2 条 / §6.3 指标 c):待决产生的那一刻。不等落盘 —— 内存态(interventionRecordCache)
  // 才是执行权威源(见 appendIntervention 头注),落盘是 best-effort;推送要的是「此刻有人在等你」。
  // 只带 id / 类型 / 一句问题 / 选项:参数与正文不进事件面(§6.1 红线)。
  RUYI_EVENTS.emit('thread.needs_you', {
    sessionId: sid, interventionId: id, kind: String(type || ''),
    question: String((extra && (extra.questionSummary || extra.planSummary || extra.task || extra.summary || extra.toolName)) || '').slice(0, 200),
    options: Array.isArray(extra && extra.questions)
      ? extra.questions.map(q => String((q && q.question) || '').slice(0, 120)).slice(0, 8)
      : [],
  });
  appendIntervention(sessionId, rec).then(() => bumpMissionChangeSeq(sid, {
    type: 'intervention_pending',
    cursor: { interventionId: id, interventionVersion: rec.interventionVersion },
    detail: { interventionType: type },
  })).catch(() => {});
}
// 结算一个 Intervention(append 一条终态记录,后写胜)。status: allowed/denied/answered/cancelled/approved/rejected/cancelled_restart。
// 重复结算(竞态)会 append 多条,读时后写胜折叠取最后一条 -- 状态仍可区分,不致命。
function settleIntervention(sessionId, ivId, status, extra) {
  const sid = String(sessionId || ''), id = String(ivId || '');
  const cached = interventionRecordCache.get(ivCacheKey(sid, id)); // 75a: complete-state merge (preserve type/requestedAt/toolName/...)
  const prevVer = (cached && Number.isFinite(Number(cached.interventionVersion))) ? Number(cached.interventionVersion) : 0;
  // 这条旧路径(权限/提问/计划的超时、清理、经典端点)仍写【完整状态行】:interventions-persist 的 (f) 钉着「settle 保留 type /
  // requestedAt」,直读日志末行的旧读者也靠它。写放大的治理只落在 transitionInterventionState(CAS 路径的 applying/terminal 增量行)。
  const rec = { ...(cached || {}), id, sessionId: sid, status, decidedAt: nowIso(), decidedBy: '', interventionVersion: prevVer + 1, ...(extra || {}) };
  // 结算都是终态:缓存条目用完即摘(修前从不删,每条介入留一份完整记录在内存里);重复结算的竞态照旧是多追一行、读时后写胜。
  if (INTERVENTION_TERMINAL.has(status)) interventionRecordCache.delete(ivCacheKey(sid, id));
  else interventionRecordCache.set(ivCacheKey(sid, id), rec);
  appendIntervention(sessionId, rec).then(() => bumpMissionChangeSeq(sid, {
    type: 'intervention_resolved',
    cursor: { interventionId: id, interventionVersion: rec.interventionVersion },
    detail: { status, interventionType: rec.type || '' },
  })).catch(() => {});
}
// 75c: journal fold returns facts plus integrity evidence. Invalid non-empty rows must not disappear behind a
// successful index rebuild: callers surface `degraded`, while the valid prefix remains readable.
function foldInterventionJournalText(txt) {
  const byId = new Map();
  const rowCount = new Map(); // 75a: id -> journal row count (authoritative interventionVersion = rows - 1)
  const lines = txt.split('\n');
  let validRows = 0, corruptLines = 0;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line) continue; // 空行(文件以 \n 结尾的尾元 / 段间空行)
    let rec;
    try { rec = JSON.parse(line); } catch { corruptLines++; continue; }
    if (!rec || !rec.id) { corruptLines++; continue; }
    validRows++;
    const idKey = String(rec.id);
    rowCount.set(idKey, (rowCount.get(idKey) || 0) + 1);
    const prev = byId.get(idKey);
    byId.set(idKey, prev ? { ...prev, ...rec } : rec); // 75a: merge-fold (prior fields preserved, rec wins) -- fixes settle overwriting register
  }
  const out = Array.from(byId.values());
  for (const rec of out) {
    // 75a: authoritative version = rows - 1 (every transition appends one row); robust to cache misses.
    const cnt = rowCount.get(String(rec.id)) || 1;
    rec.interventionVersion = Math.max(cnt - 1, Number(rec.interventionVersion) || 0);
  }
  out.sort((a, b) => String(a.requestedAt || '').localeCompare(String(b.requestedAt || '')));
  return {
    interventions: out,
    rowCount: validRows,
    corruptLines,
    degraded: corruptLines > 0,
    bytes: Buffer.byteLength(txt, 'utf8'),
  };
}

async function readInterventionsWithMeta(sessionId) {
  const sid = String(sessionId || '');
  // 读自己的写:registerIntervention / settleIntervention 是「发出去不等」地排进这条会话的写链的。待决事件
  // (permission_request / ask_user)在排队那一刻就推给了前端,用户(或 e2e)紧接着作答时,决定核心
  // (13d decideIntervention)从这里读账 —— 修前不等写链,注册那一行还没落盘就判 not_found,作答 404、
  // 回合干等到超时(Windows CI kimi-agent-cli「permission_request 之后 30 s 无事件」的根因:
  // 决定 POST 回的是 404 unknown or expired request)。写链只做 append,不回头读账,这里等它不会自锁。
  const pending = interventionWriteChains.get(sid);
  if (pending) { try { await pending; } catch { /* append 失败已在写链里吞掉:照读盘上现有的 */ } }
  let txt;
  for (let attempt = 0; ; attempt++) {
    try { txt = await fsp.readFile(interventionFilePath(sid), 'utf8'); break; }
    catch (e) {
      // 每 128 次 append 一次的压实是「写临时文件 + rename」;Windows 上 rename 那一瞬读会撞 EPERM/EBUSY。
      // 修前任何读错都当成「这条会话没有待决」—— 同样判 not_found。瞬时锁有界重试,其余(ENOENT 等)照旧当空。
      if (attempt < 3 && /^(EPERM|EBUSY|EACCES)$/.test(String(e && e.code))) { await new Promise(r => setTimeout(r, 10 + attempt * 20)); continue; }
      return { interventions: [], rowCount: 0, corruptLines: 0, degraded: false, bytes: 0 };
    }
  }
  return foldInterventionJournalText(txt);
}

// 读一个会话的全部 Intervention,按 id 后写胜折叠。返回 Intervention[](按 requestedAt 稳定排序)。
async function readInterventions(sessionId) {
  return (await readInterventionsWithMeta(sessionId)).interventions;
}

// 压实判据(compactInterventionJournal 与 13e 索引重建共用):日志 ≥ 64 KB、行数 > 256,且行数超过存活条数的 1.5 倍。
// 修前是「行数 > 存活条数 × 3」—— 每条介入走完 register → applying → terminal 恰好 3 行,等号不过,永远压不动
// (2000 条已决介入的日志只增不减)。1.5 倍 = 冗余行超过存活行的一半,压完后日志要再长出一截才会再压,摊还 O(1)。
// meta 要有 bytes / rowCount / interventions(foldInterventionJournalText 与 readInterventionsWithMeta 的返回都满足)。
function interventionJournalWorthCompacting(meta) {
  const rowsAfter = Array.isArray(meta && meta.interventions) ? meta.interventions.length : 0;
  return Number(meta && meta.bytes) >= 65536 && Number(meta && meta.rowCount) > Math.max(256, rowsAfter * 1.5);
}
// 75c: NDJSON compaction is an atomic, reconstructible cache-neutral rewrite. One complete latest-state row per
// intervention preserves terminal responses and explicit interventionVersion; corrupt authority is NEVER
// compacted (that would hide damage behind a clean-looking file). Interrupted rewrites leave the old journal.
async function compactInterventionJournal(sessionId, opts = {}) {
  const sid = String(sessionId || '');
  if (!sid) return { ok: false, skipped: 'invalid_session' };
  const file = interventionFilePath(sid);
  return runKeyedChain(interventionWriteChains, sid, async () => {
    let txt = '';
    try { txt = await fsp.readFile(file, 'utf8'); } catch { return { ok: true, compacted: false, rowsBefore: 0, rowsAfter: 0, bytesBefore: 0, bytesAfter: 0 }; }
    const folded = foldInterventionJournalText(txt);
    if (folded.degraded) return { ok: false, compacted: false, degraded: true, corruptLines: folded.corruptLines };
    const rowsAfter = folded.interventions.length;
    const worthwhile = interventionJournalWorthCompacting(folded);
    if (!opts.force && !worthwhile) return { ok: true, compacted: false, rowsBefore: folded.rowCount, rowsAfter, bytesBefore: folded.bytes, bytesAfter: folded.bytes };
    const payload = folded.interventions.map(rec => JSON.stringify(rec)).join('\n') + (rowsAfter ? '\n' : '');
    await atomicWriteJson(file, payload);
    markPretenderIndexDirty(sid, 'source');
    return {
      ok: true, compacted: true,
      rowsBefore: folded.rowCount, rowsAfter,
      bytesBefore: folded.bytes, bytesAfter: Buffer.byteLength(payload, 'utf8'),
    };
  });
}
// boot 终态化:进程重启后,内存 Map 清空,但磁盘上可能留有 pending Intervention(上次生命周期注册后未结算 --
// 进程被杀时超时 timer/clearPending 来不及跑)。与 markInterruptedAgentRuns(08:357)对称:重启 = 上次生命周期
// 结束,pending 的 Intervention **不重挂**(原回合的 promise 已无处 resolve,重挂需先 autoResume 续跑回合 +
// re-wire intervention promise,复杂且危险),而是诚实标 cancelled_restart + decidedAt。下次读模型读到的是终态,
// 不永挂。用户若想重新决策,开新回合即可(新回合注册新 Intervention)。
async function markInterruptedInterventions() {
  let files = [];
  try { files = await fsp.readdir(paths.sessions); } catch { return; }
  const stamp = nowIso();
  for (const f of files) {
    if (!f.endsWith('.interventions.ndjson')) continue;
    const sessionId = f.slice(0, -'.interventions.ndjson'.length);
    if (!/^sess_[A-Za-z0-9_-]+$/.test(sessionId)) continue; // 跳过非法名(防穿越/脏文件)
    const ivs = await readInterventions(sessionId).catch(() => []);
    const pending = ivs.filter(iv => iv && iv.status === 'pending');
    const applying = ivs.filter(iv => iv && iv.status === 'applying'); // 75a-2: crash mid-transition (SCHEMA §7)
    if (!pending.length && !applying.length) continue;
    // 71b: pool 型 pending 不一刀切 —— 池提案随 run 快照存活,paused run 恢复后仍可审批(13d pool_approve),
    // 标 cancelled_restart 会与 run 快照里的 proposed 直接矛盾(读模型说已取消、实际仍可决策 = 撒谎)。
    // interrupted/终态 run 的提案由 markInterruptedAgentRuns(boot 先于本函数,13:961)顺手 settle 'expired';
    // 这里只需兜「run 非 paused 但 settle 丢失」(崩溃窗口)与「run 已不存在」的孤儿。paused → 保留 pending(诚实)。
    let poolRuns = null;
    for (const iv of pending) {
      if (iv.type === 'pool') {
        if (!poolRuns) poolRuns = await listAgentRuns(sessionId).catch(() => []);
        const run = poolRuns.find(r => r && r.id === iv.runId);
        if (run && run.status === 'paused') continue; // 恢复后可决策,保留 pending
      }
      appendIntervention(sessionId, { ...iv, id: iv.id, sessionId, type: iv.type || '', status: 'cancelled_restart', decidedAt: stamp, decidedBy: 'restart', interventionVersion: (Number(iv.interventionVersion) || 0) + 1 }); // 75a: complete row (preserve type/requestedAt/toolName) + version bump
    }
    // 75a-2 (SCHEMA §7 崩溃语义): applying = crash during a transition (写 applying 后/resolve 前|后/terminal 前).
    // 重启遇到 applying 不自动重放高风险动作 -- 对照执行审计后进入诚实终态 indeterminate(动作副作用是否发生未知)。
    for (const iv of applying) {
      appendIntervention(sessionId, { ...iv, id: iv.id, sessionId, type: iv.type || '', status: 'indeterminate', decidedAt: stamp, decidedBy: 'restart', interventionVersion: (Number(iv.interventionVersion) || 0) + 1 });
    }
  }
}

// 75a-2 (Pretender P1, SCHEMA §7 S1/S2): 原子 CAS 原语 -- Intervention 权威状态转换的单一核心。
// pending -> applying -> terminal,以 interventionVersion 做 CAS(expectedVersion 不匹配 = 版本冲突)。
// 落盘顺序(74 波冻结):先落 applying -> 执行 action -> 落 terminal + 审计 -> 返回。每步同步落盘后再推进
// (authoritative write-before-advance,消灭「内存已删/账上 pending」漂移窗)。重启遇到 applying 不自动重放,
// 由 markInterruptedInterventions 标 indeterminate(诚实终态)。75b 的 decideIntervention() 与统一契约端点
// POST /api/missions/:missionId/interventions/:id/decision 将调用本原语;经典四端点适配也走同一核心(S2)。
//
// crashAt(失败注入,SCHEMA §7 六窗口):'before_applying'|'after_applying'|'before_resolve'|'after_resolve'|
// 'before_terminal'|'after_terminal' -- 命中即抛 __cas_crash(模拟崩溃,磁盘停在对应状态,供 boot 恢复验证)。
// per-ivId 串行锁(interventionTransitionLocks)保证同一 Intervention 并发决策只发生一次状态转换(C3/S2)。
const interventionTransitionLocks = new Map();
const INTERVENTION_TERMINAL = new Set(['allowed', 'denied', 'answered', 'cancelled', 'approved', 'rejected', 'cancelled_restart', 'indeterminate', 'expired']); // 'expired' = 08/09 pool-expiry 终态(75b 契约路径遇它按 already_terminal)
async function transitionInterventionState(sessionId, ivId, expectedVersion, toStatus, opts = {}) {
  const sid = String(sessionId || ''), id = String(ivId || '');
  if (!sid || !id) return { ok: false, reason: 'bad_args' };
  // per-ivId 串行:同一 ivId 的并发转换排队,第二个读到第一个的终态 -> already_terminal(version_conflict 不会误判)
  const key = ivCacheKey(sid, id);
  return runKeyedChain(interventionTransitionLocks, key, () => runTransition());

  async function runTransition() {
    const crashAt = String(opts.crashAt || '');
    // 1. 读权威当前态(journal 磁盘 + readInterventions 的 rows-1 version,对缓存未命中稳健)
    const ivs = await readInterventions(sid);
    const cur = ivs.find(x => String(x.id) === id);
    if (!cur) return { ok: false, reason: 'not_found', interventionVersion: 0 };
    const curStatus = String(cur.status || '');
    const curVer = Number(cur.interventionVersion) || 0;
    if (INTERVENTION_TERMINAL.has(curStatus)) {
      // 75b (S1): the retry key identifies the same request, not the business object. A byte-equivalent
      // retry returns the response persisted on the terminal row; reusing the key for a different payload
      // is a conflict. A different key still observes the authoritative terminal state and must not execute.
      const retryKey = String(opts.idempotencyKey || '');
      const storedKey = String(cur.idempotencyKey || '');
      if (retryKey && storedKey && retryKey === storedKey) {
        const requestedFingerprint = String(opts.decisionFingerprint || '');
        const storedFingerprint = String(cur.decisionFingerprint || '');
        if (requestedFingerprint && storedFingerprint && requestedFingerprint !== storedFingerprint) {
          return { ok: false, reason: 'idempotency_conflict', status: curStatus, interventionVersion: curVer };
        }
        if (cur.decisionResponse && typeof cur.decisionResponse === 'object') {
          return { ok: true, replayed: true, status: curStatus, interventionVersion: curVer, response: cur.decisionResponse };
        }
      }
      const expired = curStatus === 'expired' || String(cur.decidedBy || '') === 'timeout';
      return {
        ok: false,
        reason: expired ? 'expired' : 'already_terminal',
        status: curStatus,
        decidedBy: String(cur.decidedBy || ''),
        interventionVersion: curVer,
      };
    }
    // pending 之外的非终态(理论上只有 applying,但 applying 在锁内不应并发 -- 防御性拒绝)
    if (curStatus !== 'pending') {
      return { ok: false, reason: 'not_pending', status: curStatus, interventionVersion: curVer };
    }
    // 2. CAS:expectedVersion 必须等于当前 interventionVersion(未传 expectedVersion = 不检查,仅 75b 契约路径传)
    if (Number.isFinite(Number(expectedVersion)) && Number(expectedVersion) !== curVer) {
      return { ok: false, reason: 'version_conflict', expectedVersion: Number(expectedVersion), actualVersion: curVer };
    }
    // 75b: delivery checks run while holding the same per-Intervention lock as the CAS. This prevents
    // "preflight said live, another legacy path consumed it, then we wrote applying" split-brain.
    if (typeof opts.preflight === 'function') {
      const preflight = await opts.preflight(cur);
      if (preflight && preflight.ok === false) {
        return { ...preflight, ok: false, interventionVersion: curVer };
      }
    }
    // 3. 落 applying(pending -> applying)。authoritative:await 落盘后再推进。
    if (crashAt === 'before_applying') throw new Error('__cas_crash:before_applying');
    // 落盘只写增量行(迁移改了的字段),不再整份重抄 cur —— 修前 register/applying/terminal 三行各带一份完整 input,
    // 写放大 3 倍。读侧 foldInterventionJournalText 是后写覆盖的合并折叠,input / questions / planSummary 这类大字段由 register 行带着;
    // 行首只多带几枚【短标量身份】(type / requestedAt / toolName / tier):直读日志末行的读者(interventions-persist (f)
    // 「settle 保留 type / requestedAt」)与人眼排查都认「每行自己说得清是谁」,而它们加起来不过几十字节。
    const identity = {
      ...(cur.type ? { type: cur.type } : {}),
      ...(cur.requestedAt ? { requestedAt: cur.requestedAt } : {}),
      ...(cur.toolName ? { toolName: cur.toolName } : {}),
      ...(cur.tier ? { tier: cur.tier } : {}),
    };
    const applyingRow = {
      id,
      sessionId: sid,
      ...identity,
      status: 'applying',
      decidedAt: '',
      decidedBy: '',
      interventionVersion: curVer + 1,
      source: String(opts.source || 'contract'),
      ...(opts.idempotencyKey ? { idempotencyKey: String(opts.idempotencyKey) } : {}),
      ...(opts.decisionFingerprint ? { decisionFingerprint: String(opts.decisionFingerprint) } : {}),
    };
    const applyingRec = { ...cur, ...applyingRow };   // 完整视图只在内存里用(缓存、audit/afterTerminal 回调)
    // 「执行中」没落盘就不执行:否则重启时账上仍是 pending,会把已经执行过的动作报成「因重启取消」。
    // 缓存不动(仍是 pending),用户可以再点一次。
    if (await appendIntervention(sid, applyingRow) !== true) {
      logEvent({ kind: 'intervention_persist_failed', sessionId: sid, interventionId: id, phase: 'applying' });
      return { ok: false, reason: 'persist_failed', status: curStatus, interventionVersion: curVer };
    }
    interventionRecordCache.set(ivCacheKey(sid, id), applyingRec);
    if (crashAt === 'after_applying') throw new Error('__cas_crash:after_applying');
    // 4. 执行 action(75b 契约路径在此 resolve promise / 跑工具;75a-2 测试可空)
    if (crashAt === 'before_resolve') throw new Error('__cas_crash:before_resolve');
    let result;
    if (typeof opts.action === 'function') {
      const actionResult = opts.action();
      // Keep synchronous waiter resolution and terminal persistence in the same event-loop turn. Native
      // permission/question/plan continuations must not run teardown between resolve() and the terminal row.
      result = actionResult && typeof actionResult.then === 'function' ? await actionResult : actionResult;
    }
    if (crashAt === 'after_resolve') throw new Error('__cas_crash:after_resolve');
    // 5. 落 terminal(applying -> terminal)。authoritative:await。
    if (crashAt === 'before_terminal') throw new Error('__cas_crash:before_terminal');
    const resolvedStatus = typeof opts.resolveStatus === 'function'
      ? String(opts.resolveStatus(result, toStatus) || toStatus)
      : toStatus;
    const dynamicExtra = typeof opts.extra === 'function' ? await opts.extra(result) : (opts.extra || {});
    const response = typeof opts.buildResponse === 'function'
      ? opts.buildResponse(result, { status: resolvedStatus, interventionVersion: curVer + 2 })
      : undefined;
    // 终态行同样只写增量。重放身份(idempotencyKey / decisionFingerprint)在终态行上再带一份:它们很小,而直读日志末行的读者
    // (steward-exempt-no-swap 读 allowed 行上的指纹)认的就是终态行本身;其余字段(type / toolName / input …)由 register 行带着。
    const termRow = {
      id,
      sessionId: sid,
      ...identity,
      status: resolvedStatus,
      decidedAt: nowIso(),
      decidedBy: String(opts.decidedBy || 'user'),
      interventionVersion: curVer + 2,
      source: String(opts.source || 'contract'),
      ...(opts.idempotencyKey ? { idempotencyKey: String(opts.idempotencyKey) } : {}),
      ...(opts.decisionFingerprint ? { decisionFingerprint: String(opts.decisionFingerprint) } : {}),
      ...(dynamicExtra || {}),
      ...(response && typeof response === 'object' ? { decisionResponse: response } : {}),
    };
    const termRec = { ...applyingRec, ...termRow };   // 完整视图给 audit / afterTerminal / 事件载荷用
    // 动作已经执行,终态没落盘也收不回:记一笔;盘上停在 applying,重启时如实标 indeterminate(见头注)。
    if (await appendIntervention(sid, termRow) !== true) logEvent({ kind: 'intervention_persist_failed', sessionId: sid, interventionId: id, phase: 'terminal' });
    interventionRecordCache.delete(ivCacheKey(sid, id));   // 终态:缓存条目不再有用(见 interventionRecordCache 头注)
    bumpMissionChangeSeq(sid, {
      type: 'intervention_resolved',
      cursor: { interventionId: id, interventionVersion: termRec.interventionVersion },
      detail: { status: resolvedStatus, interventionType: termRec.type || '' },
    });
    // Audit belongs to the terminal commit: never claim a decision before its authoritative row exists.
    if (typeof opts.audit === 'function') await opts.audit(result, termRec);
    // Registry cleanup is intentionally after terminal persistence. Delivery may already have resolved a
    // waiter, but a competing path cannot observe a missing runtime entry while the journal still says pending.
    if (typeof opts.afterTerminal === 'function') {
      try { await opts.afterTerminal(result, termRec); } catch { /* terminal state is authoritative; cleanup retries on lifecycle teardown */ }
    }
    if (crashAt === 'after_terminal') throw new Error('__cas_crash:after_terminal');
    return { ok: true, status: resolvedStatus, interventionVersion: curVer + 2, result, response };
  }
}
// ── perf(会话正文逐行 sha1 的去重):进程内确定性计数器 ───────────────────────────────────────────────────
// perfCounters.sessionBody(unit/session-body-line-cache 读):只数「做了多少活」,不计时,断言不受机器快慢影响。
//   lineHashes           单行 sha1 算了几次。修前:每次装载 = 两个正文的总行数,每次保存 = 两个数组的总条数(外加
//                        严格前缀判定那一遍);现在只在行原文被挤出内存预算、退成 hash 时才算(见 sessionBodyState 头注)。
//   bodyReads            正文文件读了几次(messages / provider 各算一次)。
//   providerBodySkips    增量取的装载有几次证明了 provider 正文没变、没去读它(loadSession 的 omitProviderHistory 视图)。
//   deltaStampFromBytes  增量取的前缀戳有几次是直接对盘上字节算的(不逐条 JSON.stringify)。
//   deltaStampSerialized 同上,逐条序列化算的(修前的算法;字节路径的前提不成立时仍走它)。
const sessionBodyPerfStats = { lineHashes: 0, bodyReads: 0, providerBodySkips: 0, deltaStampFromBytes: 0, deltaStampSerialized: 0, stateEvictions: 0, stateRecoveries: 0 };
// 当前条目数(只读;见 sessionBodyState 头注的条目上限)。getter:随 perfCounters.sessionBody 一起被展开取值。
Object.defineProperty(sessionBodyPerfStats, 'stateEntries', { enumerable: true, get: () => sessionBodyState.size });
function sessionLineHash(line) {
  sessionBodyPerfStats.lineHashes++;
  return crypto.createHash('sha1').update(line).digest('hex').slice(0, 16);
}

// ── perf(前端长会话):展示消息的【前缀戳】与增量取(GET /api/sessions/:id?fromIndex=N&prefixStamp=S)──────────────
// 经典壳在自己起的回合收尾时要把会话换成落盘后的那一份。修前是整份重取(2000 条消息 7.8–19 MB,主线程 1.1–1.7 s),
// 而前 N 条它手上早就有了。增量取只回 messages[N..];前提是服务端能证明「客户端手上那 N 条 === 服务端此刻的前 N 条」。
// 戳 = 'm1.<N>.<sha1(JSON(m0) + '\n' + … + JSON(m[N-1]) + '\n')>' —— 对【实际下发的内容】逐条取哈希,而不是对盘上的行、
// 消息 id 或某个修订号。理由:历史被改写的路径很多且分散(撤回/回溯的截断、压缩、慢路径整份重写、蒸发改写中间行的
// content、loadSession 里的 normalize 补字段与残留 pending 叙事段的惰性清理、后台任务账本合并、编辑),其中几条是
// 装载时才发生、而且未必落盘的;对下发内容取哈希就不必逐条认领它们 —— 前 N 条有任何一个字节不同,戳就对不上,
// 调用方落回全量,与修前逐字节一致。JSON 往返是稳定的(stringify(parse(stringify(x))) === stringify(x)),所以
// 客户端从一次下发里解析出来的那份,与服务端下次装载再算出来的那份,内容相同就一定同戳。
// 代价:O(前缀字节数) 的 stringify + sha1(15 MB 约 60 ms),只在带了参数的请求与经典壳回合起点那一发上付。
const SESSION_MESSAGES_STAMP_VERSION = 'm1';
function sessionMessageStampLine(message) {
  const line = JSON.stringify(message);
  return line === undefined ? 'null' : line; // 与数组元素的序列化同口径(undefined/函数在数组里写成 null)
}
// 整份 messages 的戳;不可序列化 → null(调用方不发戳,下次自然走全量)。
function sessionMessagesStamp(messages) {
  const list = Array.isArray(messages) ? messages : [];
  try {
    const hash = crypto.createHash('sha1');
    for (const message of list) hash.update(sessionMessageStampLine(message) + '\n');
    return `${SESSION_MESSAGES_STAMP_VERSION}.${list.length}.${hash.digest('hex')}`;
  } catch { return null; }
}
// 增量取的判定。fromRaw / stampRaw 是查询串原样;任何一处不成立(不是非负整数、N 超出现有条数、戳的版本或条数
// 对不上、前 N 条的哈希对不上、有条目不可序列化)都返回 null = 调用方回全量。成立时返回尾巴与新整份的戳
// (同一趟哈希接着算下去,不再多走一遍)。
// perf:第四参 body(可选)只由 loadSession 的 omitProviderHistory 视图给出(sessionOmittedProviderHistory(s).body):
// 盘上 messages 正文的原始字节 buf + 行尾偏移 lineEndBytes + 行数 count,并且装载时已经证明了两件事 ——
// ① messages[0..count) 就是这 count 行逐行 JSON.parse 的结果、装载没有改过它们(normalize/惰性清理一旦要改,
// 那个视图整个让位给完整装载);② 每一行都是 JSON.stringify 的原样输出(canonical,见 sessionBodyState 头注)。
// 于是「JSON(m[i]) + '\n'」逐字节就是盘上第 i 行加换行,前缀戳直接对字节取 sha1,不再逐条 stringify + 转 utf8
// (2000 条 / 15 MB:≈ 45 ms → ≈ 9 ms)。count 之后的条目(装载时合并进来的后台任务回执)照旧逐条序列化。
// 两条路算出的是同一个 sha1 输入,结果逐字节相同(unit/session-body-line-cache 在形状表上逐格比对)。
function sessionMessagesDelta(messages, fromRaw, stampRaw, body = null) {
  const list = Array.isArray(messages) ? messages : [];
  const text = String(fromRaw == null ? '' : fromRaw);
  if (!/^\d{1,9}$/.test(text)) return null;
  const from = Number(text);
  const claimed = String(stampRaw == null ? '' : stampRaw);
  if (from > list.length || !claimed.startsWith(`${SESSION_MESSAGES_STAMP_VERSION}.${from}.`)) return null;
  const disk = body && Buffer.isBuffer(body.buf) && Array.isArray(body.lineEndBytes)
    && Number.isInteger(body.count) && body.count <= list.length && body.lineEndBytes.length >= body.count ? body : null;
  if (disk) sessionBodyPerfStats.deltaStampFromBytes++; else sessionBodyPerfStats.deltaStampSerialized++;
  try {
    const hash = crypto.createHash('sha1');
    const byteEnd = k => (k > 0 ? disk.lineEndBytes[k - 1] : 0);
    const feed = (a, b) => {   // 把 list[a..b) 喂进哈希:盘上那一段按字节,其后逐条序列化
      if (disk && a < disk.count) {
        const upto = Math.min(b, disk.count);
        hash.update(disk.buf.subarray(byteEnd(a), byteEnd(upto)));
        a = upto;
      }
      for (let i = a; i < b; i++) hash.update(sessionMessageStampLine(list[i]) + '\n');
    };
    feed(0, from);
    if (`${SESSION_MESSAGES_STAMP_VERSION}.${from}.${hash.copy().digest('hex')}` !== claimed) return null;
    feed(from, list.length);
    return { from, count: list.length, tail: list.slice(from), stamp: `${SESSION_MESSAGES_STAMP_VERSION}.${list.length}.${hash.digest('hex')}` };
  } catch { return null; }
}
// 进程内「已落盘正文」状态:id → { msg: 记录, prov: 记录, bodiesOk }。
// 用途只有三处:① saveSession 判「内存数组的前缀 === 盘上的行」→ 快路径只 append 增量,否则全量重写;
// ② saveSession 判「调用方手里是盘上正文的严格前缀(旧副本)」→ 先补齐尾巴(rebaseStaleSessionBody);
// ③ 增量取不读 provider 正文(loadSession 的 omitProviderHistory 视图)。
// 记录 = { count, lines, hashes, chars, stamp, canonical, dangling }:
//   · lines     盘上每一行的原文。前缀比对是 JSON.stringify(entry) === lines[i](字符串比较,15 MB ≈ 2 ms),
//               修前是对每行算 sha1-16 再比(≈ 20 ms,外加装载时对整个文件再算一遍)。行原文是白来的:save 刚序列化
//               出来、load 刚解码出来、本来就要丢给 GC 的那一份留下来而已。
//   · hashes    行原文占内存(≈ 正文字符数),所以全进程有预算 SESSION_BODY_LINE_CACHE_CHARS,按最近写/读淘汰;
//               被淘汰或单条会话就超预算的记录退成每行 sha1-16(与修前同一个口径:sha1(行的 utf8)),比对照旧逐行 hash。
//               两种形态只经 sessionBodyLineMatches 比对,调用方不分辨。
//   · stamp     正文文件的 size|mtimeNs|ino(bigint stat):save 写完取;load 在读的前后各取一次,相等且与读到的字节数
//               相符才记,读完又截断过就记 null。只有两处信它:退成 hashes 时同一个戳的上一份 hashes 直接沿用(不重算);
//               增量取凭 provider 正文的戳没变就不去读它(与条件 GET 的 ETag 用同一类戳:size + mtime + inode)。
//   · canonical 每一行都是 JSON.stringify 的原样输出:save 写下的行天然是;load 读到的行只有与上一份 canonical 记录的
//               行原文逐行相等(字符串比较,不信戳)才继承。增量取按字节算前缀戳要它(见 sessionMessagesDelta)。
//   · dangling  只在 provider 记录上:detectDanglingTurn 对这份正文的判定 { dangling, kind },增量取不读正文也能回 resumable。
// 这张表只可能让事情变慢、不可能让数据变错:比对失配 → 全量重写;记录缺失 / bodiesOk=false → 全量重写;
// 增量取的任何一个前提不成立 → 落回完整装载。
// bodiesOk=false 表示上次正文写失败(可能半成品)→ 下次 save 强制全量重写自愈。进程重启后由 loadSession 重建。
// 条目数也有上限 SESSION_BODY_STATE_MAX_ENTRIES:行原文有字符预算,可退成的 hashes(每行一个 16 字符串)修前却
// 没有任何上限 —— 进程活多久,摸过的每一条会话就在这里挂多久。超出时按最近写/读序整条淘汰最旧的(Map 插入序,
// setSessionBodyState 每次都把本条挪到末尾)。淘汰只丢「快」:下次 save 先在写链里按盘上的头与正文把记录重建
// 回来(recoverSessionBodyState,②的旧副本补齐因此不失效),重建不了就全量重写;增量取落回完整装载。
const SESSION_BODY_LINE_CACHE_CHARS = 32 * 1024 * 1024;
const SESSION_BODY_STATE_MAX_ENTRIES = 128;
const sessionBodyState = new Map();
const sessionBodyLineCache = new Map();   // id → 该会话记录里行原文的字符数(Map 插入序 = 最近写/读序,最旧的先被淘汰)
let sessionBodyLineCacheChars = 0;
function sessionBodyStamp(st) { return st ? `${st.size}|${st.mtimeNs}|${st.ino}` : null; }
async function sessionBodyFileStamp(file) {
  try { return sessionBodyStamp(await fsp.stat(file, { bigint: true })); } catch { return null; }
}
function sessionBodyRecord(lines, { stamp = null, canonical = false, dangling = null } = {}) {
  let chars = 0;
  for (const line of lines) chars += line.length;
  return { count: lines.length, lines, hashes: null, chars, stamp, canonical, dangling };
}
// 盘上第 i 行是不是 line。记录两种形态(行原文 / 行 hash)在这里统一。
function sessionBodyLineMatches(record, i, line) {
  if (typeof line !== 'string') return false;
  return record.lines ? record.lines[i] === line : record.hashes[i] === sessionLineHash(line);
}
// 行原文 → 每行 sha1-16(就地改,同步完成,读者任何时刻看到的都是完整的一种形态)。
// prev 是同一会话的上一份记录:同一个文件戳、同样行数 = 同一份正文,直接沿用它的 hashes,不重算。
function demoteSessionBodyRecord(record, prev) {
  if (!record || !record.lines) return;
  record.hashes = (prev && prev.hashes && record.stamp && prev.stamp === record.stamp && prev.count === record.count)
    ? prev.hashes
    : record.lines.map(sessionLineHash);
  record.lines = null;
}
function releaseSessionBodyLineCache(id) {
  const held = sessionBodyLineCache.get(id);
  if (held == null) return;
  sessionBodyLineCacheChars -= held;
  sessionBodyLineCache.delete(id);
}
function setSessionBodyState(id, state) {
  const prev = sessionBodyState.get(id);
  releaseSessionBodyLineCache(id);
  sessionBodyState.delete(id);   // 先删再放:本条挪到插入序末尾(= 最近用过),淘汰从最旧的那头开始
  sessionBodyState.set(id, state);
  evictSessionBodyStateOverflow(id);
  const held = [state.msg, state.prov].reduce((n, rec) => n + (rec && rec.lines ? rec.chars : 0), 0);
  if (held > SESSION_BODY_LINE_CACHE_CHARS) {   // 单条会话就超预算:不占缓存,直接退成 hash(与修前同样的活)
    demoteSessionBodyRecord(state.msg, prev && prev.msg);
    demoteSessionBodyRecord(state.prov, prev && prev.prov);
    return;
  }
  if (held > 0) { sessionBodyLineCache.set(id, held); sessionBodyLineCacheChars += held; }
  for (const [otherId] of sessionBodyLineCache) {
    if (sessionBodyLineCacheChars <= SESSION_BODY_LINE_CACHE_CHARS) break;
    if (otherId === id) continue;
    const other = sessionBodyState.get(otherId);
    if (other) { demoteSessionBodyRecord(other.msg, null); demoteSessionBodyRecord(other.prov, null); }
    releaseSessionBodyLineCache(otherId);
  }
}
function dropSessionBodyState(id) {
  releaseSessionBodyLineCache(id);
  sessionBodyState.delete(id);
}
// 条目数超上限 → 从最旧的开始整条丢。正在写盘的会话(写链在跑)跳过:写者收尾会把准确的记录放回来,
// 丢了它也只是让那一次 save 多做一遍重建。keep 是刚放进来的那一条。
function evictSessionBodyStateOverflow(keep) {
  if (sessionBodyState.size <= SESSION_BODY_STATE_MAX_ENTRIES) return;
  for (const otherId of sessionBodyState.keys()) {
    if (sessionBodyState.size <= SESSION_BODY_STATE_MAX_ENTRIES) break;
    if (otherId === keep || sessionWriteChains.has(otherId)) continue;
    dropSessionBodyState(otherId);
    sessionBodyPerfStats.stateEvictions++;
  }
}
// 写链内、记录缺失时(被上面淘汰过;或进程重启后没装载就直接存)按盘上的真内容重建记录 —— 与 loadSession 读完交出的
// 那一份同形。前提:头是 v2、两个正文都读得出且行数与头声明的计数【完全相等】(多出的是未提交尾巴,要 loadSession
// 截断;少了是坏)。任何一条不成立就不给,调用方照旧全量重写。只在写链里调:此刻没有别的写者,盘上就是已提交的状态。
async function recoverSessionBodyState(id, bp) {
  const head = await readSessionHeadResilient(id);
  if (!head || typeof head !== 'object' || head.storageVersion !== SESSION_STORAGE_VERSION) return null;
  const msg = await readSessionBodyFile(bp.messages);
  const prov = await readSessionBodyFile(bp.provider);
  const whole = (body, count) => body && !body.corrupt && !body.unreadable && body.tornAt == null
    && Number.isInteger(count) && body.entries.length === count;
  if (!whole(msg, head.messageCount) || !whole(prov, head.providerHistoryCount)) return null;
  if (!sessionBodiesMatchCommit(head, msg, prov)) return null;
  const state = {
    msg: sessionBodyRecordFromRead(msg, null),
    prov: sessionBodyRecordFromRead(prov, null, { dangling: danglingTurnState(prov.entries.length, i => prov.entries[i]) }),
    bodiesOk: true,
  };
  setSessionBodyState(id, state);
  sessionBodyPerfStats.stateRecoveries++;
  return state;
}
// 装载读到的正文 → 记录。与上一份 canonical 记录逐行相等(字符串比较)就继承 canonical,并沿用那一份的行对象(新解码的丢给 GC)。
function sessionBodyRecordFromRead(body, prev, { stampOk = true, dangling = null } = {}) {
  let lines = body.lines, canonical = false;
  if (prev && prev.lines && prev.canonical && prev.count === lines.length) {
    let same = true;
    for (let i = 0; i < lines.length; i++) if (lines[i] !== prev.lines[i]) { same = false; break; }
    if (same) { lines = prev.lines; canonical = true; }
  }
  return sessionBodyRecord(lines, { stamp: stampOk ? body.stamp : null, canonical, dangling });
}
// provider 正文行 → detectDanglingTurn 的判定。只从尾巴往回解析用得着的那几行;解析不了就不给(增量取随之落回完整装载)。
function sessionBodyDanglingFromLines(lines) {
  const parsed = new Map();
  try {
    return danglingTurnState(lines.length, i => {
      if (!parsed.has(i)) parsed.set(i, JSON.parse(lines[i]));
      return parsed.get(i);
    });
  } catch { return null; }
}
// 进程内「这条会话被写过几次盘」:saveSession 落盘前后各 +1。loadSession 开读时记下它,读完后仍相等才说明
// 这一眼期间没有写者 —— 只有那时才许把读到的正文状态交给 sessionBodyState、把补齐默认字段后的副本回写、
// 截断撕裂尾行。否则拿旧快照去做这三件事,都会把并发 save 刚写进去的消息盖掉/截掉(Windows CI 上
// session-head-read 那条「并发 save 后只剩 1 条」就是这么丢的)。
const sessionDiskWriteSeq = new Map();
function bumpSessionDiskWriteSeq(id) { sessionDiskWriteSeq.set(id, (sessionDiskWriteSeq.get(id) || 0) + 1); }
function sessionDiskWriteSeqOf(id) { return sessionDiskWriteSeq.get(id) || 0; }
// 读一个 NDJSON 正文文件。返回 { entries, lines, lineEndBytes, tornAt, stamp, buf } | null(文件缺失) | { corrupt:true }(中间行坏)。
// 崩溃语义:写入侧永远「整行 + 尾随 \n」一次 append,所以【无 \n 终结的尾行 = 撕裂】(append 崩溃中途,
// 其所属的头写未完成,等于那次 save 没发生)—— 发现即【物理截断】到最后一个好行边界,而不是只在内存里
// 容忍:否则磁盘上留着半行,下次快路径 append 会接在撕裂字节之后,把新的真消息焊进坏行 → 中间坏行 →
// 整个会话被判 corrupt 隔离(真丢数据)。中间空行/坏行一律 corrupt(不应发生,发生即数据事故)。
// hunt2-P3:只有 ENOENT 才是「文件缺失」(null)。EBUSY/EPERM/EACCES(Windows 杀软/索引器短暂持锁)、
// EMFILE/ENFILE(句柄一时耗尽)这类读失败先有界重试;仍失败回 { unreadable:true } —— 修前一律 null,
// loadSession 把它当「正文丢了」,整条会话连头带正文改名 .corrupt(一次瞬时锁 = 会话从列表里消失)。
// perf:按字节读、在字节上找 '\n'、逐行解码再 JSON.parse。修前是整份解码成一个大字符串再 split:正文里只要有一个
// 中文字符,整份(连同 split 出来的每一行)就都是双字节串,解码、解析都慢一截;行尾字节偏移还要每行再 Buffer.byteLength
// 一遍。现在偏移直接就是字节下标(对非法 utf8 字节也精确 —— 修前按解码后的 U+FFFD 计 3 字节,截断点会偏)。
// 不再在这里算每行 hash:要比对的人拿 lines(行原文)比,见 sessionBodyState 头注。
// 分行判据与修前逐字节相同:'\n' 不会出现在任何 utf8 多字节序列里,按字节切与按字符切切在同一处。
const SESSION_BODY_READ_TRANSIENT = new Set(['EPERM', 'EBUSY', 'EACCES', 'EMFILE', 'ENFILE', 'EAGAIN']);
async function readSessionBodyFile(p) {
  let buf, before = null;
  for (let attempt = 0; ; attempt++) {
    try {
      before = await fsp.stat(p, { bigint: true }).catch(() => null);
      buf = await fsp.readFile(p);
      break;
    } catch (error) {
      const code = String((error && error.code) || '');
      if (code === 'ENOENT') return null;
      if (!SESSION_BODY_READ_TRANSIENT.has(code) || attempt >= SESSION_HEAD_READ_RETRIES) return { unreadable: true, code: code || 'EREAD' };
      await new Promise(resolve => setTimeout(resolve, 5 + attempt * 10));
    }
  }
  sessionBodyPerfStats.bodyReads++;
  if (!Buffer.isBuffer(buf)) buf = Buffer.from(String(buf), 'utf8');
  const after = await fsp.stat(p, { bigint: true }).catch(() => null);
  const stampBefore = sessionBodyStamp(before);
  const stamp = stampBefore && stampBefore === sessionBodyStamp(after) && after.size === BigInt(buf.length) ? stampBefore : null;
  const entries = [], lines = [], lineEndBytes = [];
  let start = 0; // 已确认好行的字节数(含每行结尾 \n),撕裂截断点
  for (;;) {
    const nl = buf.indexOf(10, start);
    if (nl < 0) break;   // 其后若还有字节 = 无 \n 终结的尾行(撕裂)
    if (nl === start) return { corrupt: true }; // 中间空行 = 坏
    const line = buf.toString('utf8', start, nl);
    try { entries.push(JSON.parse(line)); }
    catch { return { corrupt: true }; } // 中间坏行 = 坏
    lines.push(line);
    start = nl + 1;
    lineEndBytes.push(start);
  }
  // 撕裂尾行【只报告、不就地截断】:读的这一瞬可能正有 saveSession 在 append(Windows 上并发读能看到写了一半
  // 的行),在这里截断等于删掉正在落盘的那一行。截断交给 loadSession 在确认「没有写者」之后做。
  return { entries, lines, lineEndBytes, tornAt: start < buf.length ? start : null, stamp, buf };
}
// 快路径判定:entries 的前 record.count 条逐条序列化后与盘上的行全等 → 返回 { appendLines, allLines };
// 否则(前缀变/缩短/无记录/有条目不可序列化)返回 null → 调用方全量重写。注意:必须逐条重新序列化比对,不能只比
// 长度+尾行 —— 蒸发(evaporateHistory)会在保持长度不变的情况下原地改写中间行的 content;也不能凭对象身份跳过,
// 活回合、惰性清理都是就地改对象(见文件头「检测机制不靠调用方自觉打标记」)。省掉的只是「再对每行算一遍 sha1」。
function planSessionBodyAppend(entries, record) {
  if (!record || record.count > entries.length) return null;
  const allLines = new Array(entries.length);
  for (let i = 0; i < entries.length; i++) {
    let line;
    try { line = JSON.stringify(entries[i]); } catch { return null; } // 不可序列化 → 全量重写兜底
    if (typeof line !== 'string') return null;                        // undefined/函数:同上(全量重写那里会拒绝落盘)
    if (i < record.count && !sessionBodyLineMatches(record, i, line)) return null; // 前缀变 → 全量重写
    // 前缀行与记录里那一份逐字相同:沿用记录里的旧串,刚序列化出来的这份当场可回收(review:否则每次 save 都把
    // 整份正文的新串留进下一份记录,长会话一次 12 MB 升进老生代,Mark-Compact 次数 4 → 1)。
    allLines[i] = i < record.count && record.lines ? record.lines[i] : line;
  }
  return { appendLines: allLines.slice(record.count), allLines };
}
// 全量重写用的整体序列化(行数组)。返回 null = 有条目不可序列化(调用方拒绝这次写并标 bodiesOk=false ——
// 宁可下次再试,绝不写出半个正文文件)。
function serializeSessionBody(entries) {
  const lines = new Array(entries.length);
  for (let i = 0; i < entries.length; i++) {
    let line;
    try { line = JSON.stringify(entries[i]); } catch { return null; }
    if (typeof line !== 'string') return null;
    lines[i] = line;
  }
  return lines;
}
function sessionBodyText(lines) { return lines.length ? lines.join('\n') + '\n' : ''; }
function sessionBodyDigest(lines) {
  const hash = crypto.createHash('sha256');
  for (const line of lines) hash.update(line, 'utf8').update('\n');
  return hash.digest('hex');
}
function sessionBodyCommitValid(head) {
  const commit = head.providerHistoryCommit;
  return Number.isSafeInteger(head.providerHistoryRevision) && head.providerHistoryRevision >= 0
    && commit?.schema === 1 && commit.revision === head.providerHistoryRevision
    && /^[a-f0-9]{64}$/.test(commit.messagesSha256 || '') && /^[a-f0-9]{64}$/.test(commit.providerSha256 || '');
}
function sessionBodiesMatchCommit(head, msg, prov) {
  if (!Object.hasOwn(head, 'providerHistoryRevision') && !Object.hasOwn(head, 'providerHistoryCommit')) return true;
  if (!sessionBodyCommitValid(head)) return false;
  const commit = head.providerHistoryCommit;
  const matches = (body, count, digest) => {
    if (!body || body.corrupt || body.unreadable || !Number.isSafeInteger(count) || count < 0 || body.entries.length < count) return false;
    const end = count ? body.lineEndBytes[count - 1] : 0;
    return crypto.createHash('sha256').update(body.buf.subarray(0, end)).digest('hex') === digest;
  };
  return matches(msg, head.messageCount, commit.messagesSha256) && matches(prov, head.providerHistoryCount, commit.providerSha256);
}
// entries 是否为 record 所记盘上正文的【严格】前缀(更短且逐行相同)。
function isStrictSessionBodyPrefix(entries, record) {
  if (!record || entries.length >= record.count) return false;
  for (let i = 0; i < entries.length; i++) {
    let line;
    try { line = JSON.stringify(entries[i]); } catch { return false; }
    if (!sessionBodyLineMatches(record, i, line)) return false;
  }
  return true;
}
// saveSession 写链内调用（见调用点注释）。只在消息是严格前缀时动手；providerHistory 只在它也是严格前缀
// 时一并补齐 —— 它会被合法地缩短（被停止的回合弹掉悬空的 user 行、压缩），消息更短才是
// 「这是一份旧副本」的证据。就地往调用方的数组里补，返回 true 表示补过（头计数要重算）。
// 盘上正文是现读的、逐行拿原文与记录比(不信文件戳):行数相同且最后一行相同才补。
async function rebaseStaleSessionBody(id, bp, state, messages, providerHistory) {
  const msgRec = state.msg, provRec = state.prov;
  if (!isStrictSessionBodyPrefix(messages, msgRec)) return false;
  const disk = await readSessionBodyFile(bp.messages);
  if (!disk || disk.corrupt || disk.unreadable || disk.lines.length !== msgRec.count
    || !sessionBodyLineMatches(msgRec, msgRec.count - 1, disk.lines[msgRec.count - 1])) return false;
  const addedMessages = disk.entries.length - messages.length;
  messages.push(...disk.entries.slice(messages.length));
  let addedProvider = 0;
  if (isStrictSessionBodyPrefix(providerHistory, provRec)) {
    const prov = await readSessionBodyFile(bp.provider);
    if (prov && !prov.corrupt && !prov.unreadable && prov.lines.length === provRec.count) {
      addedProvider = prov.entries.length - providerHistory.length;
      providerHistory.push(...prov.entries.slice(providerHistory.length));
    }
  }
  logEvent({ kind: 'session_stale_copy_rebased', sessionId: id, addedMessages, addedProvider });
  return true;
}

// ===== PF2: session metadata index (sessions/index.json) =====================================================
// listSessions used to JSON.parse EVERY session file in full just to show 7 sidebar fields, and saveSession
// rewrote each session whole; both costs grow with session count/size. We keep a lightweight index of just
// those 7 fields, incrementally maintained by saveSession/deleteSession. CRITICAL SAFETY INVARIANT: the index
// is ONLY a cache; each per-session JSON file remains the single source of truth. listSessions trusts the
// index only when its id-set EXACTLY matches the session files on disk; on any mismatch/missing/corrupt index
// it falls back to scanning the real files (and rebuilds the index). On any index write failure we DELETE the
// index so the next read rebuilds from truth. Sessions are single-writer (the serve process only; the MCP
// child never writes session files), so a process-global write lock is enough to serialize index mutations.
const SESSION_INDEX_FILE = 'index.json';
function sessionIndexPath() { return path.join(paths.sessions, SESSION_INDEX_FILE); }

// 第70波(EC-E):会话类型显式标识 —— 'quick_ask'(纯问答,默认) | 'mission'(任务会话,mission start 时显式翻转,
// 非启发式文本猜测)。旧会话(第70波前落盘)无 kind 字段:有 mission 派生 'mission',否则 'quick_ask'。
// 迁移契约:只读派生,绝不把派生结果回写磁盘(无破坏性批量改写)。
function sessionKind(o) {
  const k = o && o.kind;
  if (k === 'mission' || k === 'quick_ask') return k;
  return (o && o.mission) ? 'mission' : 'quick_ask';
}

// 75a (Pretender P1, D1 plan B): Mission stable identity primary key `missionId`.
// In 3.0 missionId === sessionId (written explicitly for new sessions at createSession).
// Legacy (pre-75a) session heads lack this key -> read-only derive at projection/response time,
// NEVER writeback to disk (same discipline as `kind`: do NOT set it in normalizeSession, or the
// next saveSession would persist it = destructive batch rewrite). 3.1's 1:N multi-session is the
// first place missionId may diverge from sessionId; 3.0 only guarantees existing identity needs
// no remapping (S5). Consumers (sessionMeta / buildMissionCard / interventions list) call this.
function sessionMissionId(o) {
  const m = o && o.missionId;
  if (typeof m === 'string' && m) return m;
  const id = o && o.id;
  return (typeof id === 'string' && id) ? id : '';
}

// ── 116-5a(27 号文 §11.8「线程自动摘要」)────────────────────────────────────────────────
// 名字与概括的字数上限。在【落盘时】就夹死(见 applySessionMetaPatch),不是显示时才截:
// 上限一旦调整,存量数据仍是按当时上限存的,显示层再截一次只会掩盖这件事。
const SESSION_BRIEF_TITLE_CHARS = 24;
const SESSION_BRIEF_GIST_CHARS = 80;
// 117l-A1-fix (2)(27 号文 §11.9;用户真机天天看见):占位标题不是名字,它是「还没有名字」。
// 未命名线程在第一回合结束、摘要(threadBrief)生成之前,raw 逐字就是后端占位符 'New session'
// (createSession 写的),于是收件箱事件行写成「线程「New session」(sess_x)」、routeHint 块与
// humanize 出来的 say/why 也全是「New session」—— 用户真机上管家说「十几条 New session 还在交办中」。
// 补一档兜底:占位标题 + 【手上真有正文】时,用首条用户消息的前 24 个字顶上(与 SESSION_BRIEF_TITLE_CHARS
// 同一个上限,摘要落盘后自然被生成的名字接管)。
// 纪律三条:
//   · 用户手改的标题(titleSource === 'user')在函数第一行就返回了,永远不受这一档影响;
//   · 只在入参【自己带着正文】时才走(完整会话对象:GET /api/sessions/:id 的 loadSession 结果)。
//     只有会话头 / 索引条目的调用面拿不到正文,那就仍旧保留占位 —— 这个函数在总览里每条线程都要跑
//     一遍,为了一个名字去多读一次正文文件是不能接受的代价;
//   · 优先级顺序一个字不动:人起的 > 生成的 > 原话,摘录只是【占位符这一种原话】的兜底。
function sessionFirstUserExcerpt(o) {
  const rows = (o && Array.isArray(o.messages)) ? o.messages : null;
  if (!rows) return '';
  for (const m of rows) {
    if (!m || m.role !== 'user' || typeof m.content !== 'string') continue;
    const text = m.content.replace(/\s+/g, ' ').trim();   // 标题是一行:换行折成空格
    if (!text) continue;
    const chars = [...text];   // 按字符切,不按 UTF-16 码元(别把一个 emoji 劈成两半)
    return chars.length > SESSION_BRIEF_TITLE_CHARS ? chars.slice(0, SESSION_BRIEF_TITLE_CHARS).join('') + '…' : text;
  }
  return '';
}
// 「这条线程该显示什么名字」的【唯一】判据。优先级:人起的名字 > 自动生成的名字 > 原话
// (原话是占位符且手上有正文时,退一档用首条用户消息的摘录,见上面 sessionFirstUserExcerpt 的头注)。
// 服务端一处装配、多处消费(sessionMeta / 113b 会话搜索 / 13g 线程搜索 / 117 的抽屉看板递送候选),
// 判据绝不许在前端各算一遍 —— 那正是 112 波摸底里「服务端发 54 种、前端认 34 种」那类分叉的起点。
// 入参两形态都要认:会话头(有 threadBrief)与索引条目(sessionMeta 带出的 brief)。
// 117s-A D2(§11.13 ⑤a):titleSource 多了一个字面量 'steward'(管家开线程时抄进来的那句话)。
// 本函数【一行没改】—— 它本来就只在 'user' 那一档提前返回,'steward' 自然落在第二档之后,
// 于是优先级如实是:人起的 > 生成的名字 > 管家给的那句(它就是 raw 本身)> 原话。
// Titles share the live-turn metadata override path; transcript persistence still waits for settle.
const sessionTitleOverrides = new Map();
function applySessionTitleOverride(session) {
  const live = session && sessionTitleOverrides.get(session.id);
  if (!live) return session;
  if (live.titleSource === 'user') { session.title = live.title; session.titleSource = 'user'; }
  else {
    const gen = Math.max(Number(session.rewindGen) || 0, sessionRewindGenHighWater.get(session.id) || 0);
    if (gen !== live.rewindGen) sessionTitleOverrides.delete(session.id);
    else if (session.titleSource !== 'user') session.threadBrief = live.threadBrief;
  }
  return session;
}

function sessionDisplayTitle(o) {
  const raw = String((o && o.title) || '');
  if (!o || o.titleSource === 'user') return raw;
  const brief = (o.threadBrief && typeof o.threadBrief === 'object') ? o.threadBrief : ((o.brief && typeof o.brief === 'object') ? o.brief : null);
  const generated = String((brief && brief.title) || '').trim();
  if (generated || !isUntitledSessionTitle(raw)) return generated || raw;
  return sessionFirstUserExcerpt(o) || raw;
}

// The 7 sidebar fields. Accepts a full session (has .messages) OR an index entry (has .messageCount), so the
// same shaper builds index entries and normalizes them on read.
// 116-2a: 可选第二参 config —— 给了(且是对象)就额外带出派生的 effectivePermissionMode。索引条目
// 【不】传(listSessions 建索引时保持精简;它那条 `.map(sessionMeta)` 还会把数组下标当第二参喂进来,
// 故这里必须严格判 typeof === 'object',否则下标 1、2… 会被当成 config 而算出一个假的生效档)。
function sessionRecentUserRequest(o) {
  // Derive from surviving display messages, never from compaction's synthetic user messages.
  const messages = o && Array.isArray(o.messages) ? o.messages : null;
  const recent = messages ? messages.findLast(message => message && message.role === 'user' && !(message.meta && message.meta.origin === 'agent_wake')) : (o && o.recentUserRequest);
  if (!recent) return null;
  const content = recent.content == null ? recent.text : recent.content;
  const text = (Array.isArray(content) ? content.map(part => typeof part === 'string' ? part : part && part.text || '').join('\n') : String(content || '')).replace(/\s+/g, ' ').trim().slice(0, 240);
  if (!text) return null;
  return { text, ...(Number(recent.turnSeq) > 0 ? { turnSeq: Number(recent.turnSeq) } : {}), ...(recent.at || recent.createdAt ? { at: String(recent.at || recent.createdAt) } : {}) };
}
function sessionMeta(o, config) {
  // Idle index entries are authoritative; pending/in-flight index batches already overlay their writes.
  if (activeChildren.has(o.id) || turnSettlers.has(o.id) || sessionMetaDeferChains.has(o.id)) o = applySessionTitleOverride({ ...o });
  const cfg = (config && typeof config === 'object') ? config : null;
  const recentUserRequest = sessionRecentUserRequest(o);
  return {
    id: o.id,
    missionId: sessionMissionId(o), // 75a: stable Mission identity (== sessionId in 3.0; read-only derive for legacy)
    title: o.title,
    ...(safeSessionId(o.relatedSessionId) ? { relatedSessionId: safeSessionId(o.relatedSessionId) } : {}),
    summary: o.summary || '',
    ...(recentUserRequest ? { recentUserRequest } : {}),
    cwd: o.cwd,
    pinned: Boolean(o.pinned),
    createdAt: o.createdAt,
    updatedAt: o.updatedAt,
    messageCount: Number.isFinite(o.messageCount) ? o.messageCount : (o.messages?.length || 0),
    promptPack: PROMPT_PACK_VERSION, // 51c-b(04 Phase B):提示词包版本,为 A/B 实验与问题回溯奠基
    kind: sessionKind(o), // 第70波:Quick Ask / Mission 显式标识(旧索引条目只读派生,见 sessionKind)
    // 116f: 会话头的【原始】 kind 只在它是管家会话时随条目带出。sessionKind() 只归一为 mission/quick_ask,
    // 索引条目一旦生成就再也认不出管家会话 —— 而 listSessions 的快路径读的正是索引,没有这个字段就没法
    // 把管家排除在会话列表(以及走同一份 metas 的 113b 内容搜索)之外。普通会话【零新增字段】,
    // /api/sessions 的载荷逐字节不变。两个入参形态都要认:会话头(o.kind)与【已归一过的索引条目】
    // (o.rawKind)—— 快路径会把索引条目再喂一次 sessionMeta,只认 o.kind 的话这个字段在那一趟就丢了。
    ...(o && (o.kind === 'steward' || o.rawKind === 'steward') ? { rawKind: 'steward' } : {}),
    // 116-2a(§3.3/§8.6「每条线程一个权限 chip」):会话级权限档。缺省是 **null**,不是全局值 ——
    // chip 要能分清「这条线程自己定了档」(显示实底)与「跟着全局默认走」(显示浅底),填全局值就分不清了。
    // 存量会话读到没有该字段 → null,零迁移。
    permissionMode: sessionPermissionModeOf(o),
    // 116-5a(§11.8.5):线程的名字与一句概括。**缺席时这两个键根本不出现** —— 存量会话的
    // /api/sessions 载荷逐字节不变。两个入参形态都要认:会话头(threadBrief)与已归一过的索引条目
    // (brief) —— 快路径会把索引条目再喂一次 sessionMeta,只认前者的话这个字段在那一趟就丢了
    // (与上面 rawKind 那条同一个坑)。
    ...(sessionBriefOf(o) ? { brief: sessionBriefOf(o) } : {}),
    // 117s-A D2:'steward' 也如实带出(索引条目要能说出「这个标题是谁给的」)。
    // 显示不靠它 —— sessionDisplayTitle 只在 'user' 那一档提前返回,'steward' 走的是与缺席
    // 逐字相同的那条路(brief.title > 原话);带出它是为了不让索引条目比会话头少说一句实话。
    ...(o && (o.titleSource === 'user' || o.titleSource === 'steward') ? { titleSource: o.titleSource } : {}),
    // 派生的【生效】档(会话级 > 全局)。只在调用方给了 config 时输出:索引条目保持精简,而 API 层
    // 拿得到 config,给 UI 与管家一个不用自己再解析一遍的现成值。
    ...(cfg ? { effectivePermissionMode: resolvePermissionMode({ session: o, config: cfg }) } : {}),
  };
}
// 116f: 管家会话不是「一个会话」,它是工作台本身的那张脸 —— 会话列表、内容搜索、投影、收件箱四个面
// 都必须看不见它。判定读【原始】 kind,不经 sessionKind()(那会把它说成 quick_ask)。
// 116-5a:从两种入参形态里取出摘要(会话头的 threadBrief / 索引条目的 brief),形状归一成
// {title, gist} —— 索引条目只带显示要用的两个字段,at/model/stage 留在会话头上供事后对账。
function sessionBriefOf(o) {
  const b = o && ((o.threadBrief && typeof o.threadBrief === 'object') ? o.threadBrief : ((o.brief && typeof o.brief === 'object') ? o.brief : null));
  if (!b) return null;
  const title = String(b.title || '').trim();
  const gist = String(b.gist || '').trim();
  return (title || gist) ? { title, gist } : null;
}
function sessionMetaIsSteward(meta) {
  return !!(meta && (meta.rawKind === 'steward' || meta.kind === 'steward'));
}
function sortSessionMetas(arr) {
  return arr.slice().sort((a, b) => (Number(b.pinned) - Number(a.pinned)) || String(b.updatedAt).localeCompare(String(a.updatedAt)));
}
// Read the index array, or null when missing/corrupt/not-an-array (caller falls back to a full scan).
async function readSessionIndex() {
  try {
    const raw = await fsp.readFile(sessionIndexPath(), 'utf8');
    const arr = safeJsonParse(raw, null);
    return Array.isArray(arr) ? arr : null;
  } catch { return null; }
}
// 索引的【内存镜像】(perf):flushSessionIndex 每个 200 ms 去抖窗口都要「读 → 解析 → 合并 → 整份写」一遍 index.json
// (3000 条会话 ≈ 1.3 MB,每次 ~25 ms,回合进行中每个窗口都在跑)。我们自己刚写下的那份内容就是合并后的 map,
// 下一窗口再读回来解析一遍纯属重复。这里把「刚写下的 map + 写完后立刻取的文件戳」留在内存里:下一次 flush 先取当前文件戳,
// 与镜像的戳相同 = 磁盘上仍是我们写的那一份,直接在镜像 map 上合并,跳过读与解析;戳不同(外部改写/被 invalidate/被
// listSessions 重建覆盖/flushSessionIndexSync 写过/文件不在)一律作废镜像走原来的读盘路径。戳 = 路径 + size + mtimeNs + ino
// (写入是 tmp + rename,每次换 inode)。只有 flushSessionIndex 那一处产生镜像;所有别的写口都不给 map → 镜像作废。
// 镜像只在 withSessionIndexLock 里读写(与索引写同一把锁),无并发。
let sessionIndexMemo = null;   // { stamp, map }
async function sessionIndexFileStamp() {
  try {
    const st = await fsp.stat(sessionIndexPath(), { bigint: true });
    return `${sessionIndexPath()}|${st.size}|${st.mtimeNs}|${st.ino}`;
  } catch { return null; }
}
// Atomic index write (tmp + rename, same discipline as saveSession). Caller wraps failures.
// 第二参 map(可选)= 这份 entries 对应的合并结果,给了就登记成内存镜像(见 sessionIndexMemo)。
async function writeSessionIndex(entries, map = null) {
  sessionIndexMemo = null;   // 写之前先作废:写到一半失败/被别的写口接着覆盖,镜像都不该再被信
  await fsp.mkdir(paths.sessions, { recursive: true });
  await atomicWriteJson(sessionIndexPath(), entries);   // 25.1 收编
  if (map) {
    const stamp = await sessionIndexFileStamp();
    if (stamp) sessionIndexMemo = { stamp, map };
  }
}
async function invalidateSessionIndex() { sessionIndexMemo = null; await fsp.unlink(sessionIndexPath()).catch(() => {}); }
// Serialize all index mutations (single global chain) so concurrent saveSession calls can't lose updates or
// tear the file. Session FILES are still written concurrently; only the shared index write is serialized.
let sessionIndexChain = Promise.resolve();
async function withSessionIndexLock(work) {
  const previous = sessionIndexChain || Promise.resolve();
  const current = previous.catch(() => {}).then(work);
  sessionIndexChain = current;
  try { return await current; }
  finally { if (sessionIndexChain === current) sessionIndexChain = Promise.resolve(); }
}
// COALESCED index maintenance. saveSession/deleteSession call scheduleSessionIndexUpdate synchronously (a cheap
// in-memory Map.set); the actual read-modify-write of index.json is DEBOUNCED and batched. This matters two ways:
//  (1) it keeps the saveSession critical path free of index I/O (turns/workflows call it constantly), and
//  (2) a burst of N saves (e.g. a DAG workflow) collapses into ONE index write instead of N, so the background
//      I/O never floods the event loop and delays incoming request handling.
// Durability: the pending batch is in-memory only. Losing it on crash is harmless — the session FILES are the
// source of truth and listSessions rebuilds the index whenever its id-set drifts from disk.
const SESSION_TOMBSTONE = Symbol('session-deleted');
const SESSION_INDEX_FLUSH_MS = 200;
let pendingSessionIndex = new Map(); // id -> meta entry | SESSION_TOMBSTONE (last write per id wins)
// 107-F9a: the IN-FLIGHT table. flushSessionIndex takes the pending batch before it does the I/O (so saves made
// during the write queue up for the next flush); before F9a that batch was then visible NOWHERE until the rename
// landed — not in pendingSessionIndex any more, not on disk yet — and a listSessions landing in those few ms read
// the old index. User-visible (F8, measured): a second split within ~200 ms of the first built a duplicate empty
// mission (split's idempotency check reads listSessions), and a just-attached thread flashed back to "unfiled" in
// the mission list. Every read therefore overlays disk -> in-flight -> pending (newest last); a flush retires its
// entries only after its write settled (landed, dropped or invalidated), and only the entries that are still ITS
// OWN — a later flush may have taken a newer value for the same id, which must stay visible until it lands too.
// Entry shape: id -> { val, flush } where `flush` is the identity token of the flush that owns it.
let inflightSessionIndex = new Map();
// Bumped every time a flush retires its in-flight entries. listSessions compares it across its disk read: a retire
// in between means the file it read may predate the write whose entries just left the table (see listSessions).
let sessionIndexRetireSeq = 0;
let sessionIndexFlushTimer = null;
// 128f-⑧(Brief §4.2 第 22 条前半「扫盘重建路径有一处既有竞态」):扫盘重建是一条条读会话文件、最后整份写回索引 ——
// 扫到 X 之后 X 又被存了一次,而那次存的索引刷新先落了地(或者索引此刻不在、那次刷新直接把批次丢了),重建写回的
// 就是 X 的旧值;之后 id 集合与磁盘对得上,快路径一直信它,直到 X 再被存一次。修:每一次排进索引的写记一个全局序号
// 与最新值(每个 id 只留最新一条);重建在开扫前记下序号,写回时(同一把索引锁里)把开扫之后的写一条条叠上去。
// 只在有重建在扫的时候记(没人扫就没人要叠),最后一个重建收尾时清空 —— 否则这张表会随会话总数只增不减。
let sessionIndexWriteSeq = 0;
let sessionIndexRebuildsActive = 0;
const sessionIndexLatestWrite = new Map();   // id -> { seq, val }(val 与 pendingSessionIndex 同形:meta 或 SESSION_TOMBSTONE)
// 测试口(unit/session-index-rebuild-race 用):扫盘重建每读完一个会话文件调一次,可以在那一刻插一次保存、确定性地造出竞态。
let sessionIndexRebuildScanHook = null;
function setSessionIndexRebuildScanHookForTest(fn) { sessionIndexRebuildScanHook = typeof fn === 'function' ? fn : null; return sessionIndexLatestWrite.size; }
function scheduleSessionIndexUpdate(id, valueOrTombstone) {
  pendingSessionIndex.set(String(id), valueOrTombstone);
  sessionIndexWriteSeq += 1;
  if (sessionIndexRebuildsActive > 0) sessionIndexLatestWrite.set(String(id), { seq: sessionIndexWriteSeq, val: valueOrTombstone });
  if (sessionIndexFlushTimer) return; // a flush is already pending; this entry rides along with it
  sessionIndexFlushTimer = setTimeout(() => { sessionIndexFlushTimer = null; void flushSessionIndex(); }, SESSION_INDEX_FLUSH_MS);
  if (sessionIndexFlushTimer.unref) sessionIndexFlushTimer.unref(); // a cache flush must never keep the process alive
}
// Apply the whole pending batch in a single locked read-modify-write. Best-effort: if there is no valid index
// we drop the batch (listSessions rebuilds from truth); on any error we invalidate so the next read falls back.
async function flushSessionIndex() {
  if (!pendingSessionIndex.size) return;
  // Take the batch so saves made during the I/O queue up for the NEXT flush — but move it into the in-flight table
  // in the same synchronous step, so there is no instant at which a read can miss it (107-F9a, see the table's note).
  const batch = pendingSessionIndex; pendingSessionIndex = new Map();
  const flush = {};   // identity token: which in-flight entries are this flush's to retire
  for (const [id, val] of batch) inflightSessionIndex.set(id, { val, flush });
  try {
    await withSessionIndexLock(async () => {
      try {
        // 镜像命中(文件戳与我们上次写完时一致)就不读盘不解析,直接在镜像 map 上合并;否则走原来的读盘路径。
        const stamp = await sessionIndexFileStamp();
        let map = null;
        if (stamp && sessionIndexMemo && sessionIndexMemo.stamp === stamp) map = sessionIndexMemo.map;
        else {
          sessionIndexMemo = null;
          const index = await readSessionIndex();
          if (!index) return; // no valid index → don't fabricate a partial one; listSessions will rebuild
          map = new Map(index.map(e => [String(e && e.id), e]));
        }
        sessionIndexMemo = null;   // 下面要就地改 map:改到一半失败它就是脏的,写成功后 writeSessionIndex 再登记回来
        for (const [id, val] of batch) { if (val === SESSION_TOMBSTONE) map.delete(id); else map.set(id, val); }
        await writeSessionIndex([...map.values()], map);
      } catch { await invalidateSessionIndex(); }
    }).catch(() => {});
  } finally {
    // The write has settled: it landed (disk now carries the batch), or there was no index to update / the index
    // was invalidated (both send the next listSessions to the authoritative file scan). Either way the entries are
    // no longer needed for read-your-writes. Retire only the ones still owned by THIS flush.
    for (const id of batch.keys()) {
      const entry = inflightSessionIndex.get(id);
      if (entry && entry.flush === flush) inflightSessionIndex.delete(id);
    }
    sessionIndexRetireSeq++;
  }
}
// Apply the not-yet-durable index changes onto a map built from the disk index, oldest first: in-flight (taken by a
// running flush) and then pending (not taken yet, therefore newer). Last write per id wins, tombstones delete.
function overlayUnflushedSessionIndex(map) {
  for (const [id, entry] of inflightSessionIndex) { if (entry.val === SESSION_TOMBSTONE) map.delete(id); else map.set(id, entry.val); }
  for (const [id, val] of pendingSessionIndex) { if (val === SESSION_TOMBSTONE) map.delete(id); else map.set(id, val); }
  return map;
}
// PF2 fix: SYNCHRONOUS flush for the exit path. process.exit() (the SIGINT/SIGTERM handlers, uncaughtException)
// runs 'exit' listeners synchronously, so the async debounced flushSessionIndex above can never complete there —
// a graceful shutdown would silently drop the last ~200ms of metadata updates. Persist the pending batch with
// fs.*Sync using the SAME tmp+rename atomic discipline. Best-effort: on a missing/corrupt index or any error we
// bail (the boot-time invalidateSessionIndex + fallback file scan rebuild from truth regardless).
// 107-F9a: the IN-FLIGHT batch is persisted too. Exiting while an async flush is mid-write abandons that write (its
// rename never runs), and before F9a that batch was already gone from pendingSessionIndex — so it was silently lost.
// Neither table is cleared here: this is a pure "persist everything not yet durable" step, idempotent against the
// async flush that owns the in-flight entries (if the process somehow keeps running, that flush lands the same values).
function flushSessionIndexSync() {
  try {
    if (!pendingSessionIndex.size && !inflightSessionIndex.size) return;
    let index = null;
    try { const arr = safeJsonParse(fs.readFileSync(sessionIndexPath(), 'utf8'), null); index = Array.isArray(arr) ? arr : null; } catch { index = null; }
    if (!index) return; // no valid index → don't fabricate a partial one; boot rebuild + fallback scan self-heal
    const map = overlayUnflushedSessionIndex(new Map(index.map(e => [e && String(e.id), e]).filter(([id]) => id)));
    // 25.1: 这是全文件唯一豁免 atomicWriteJson 的 JSON 写点 —— exit 监听器里只能同步 I/O(async 版永远跑不完)。
    // tmp 名仍按统一纪律取唯一名(pid+随机),防与并行的 async 写者互踩;失败清 tmp。
    const finalPath = sessionIndexPath();
    const tmpPath = finalPath + '.' + process.pid + '.' + crypto.randomBytes(4).toString('hex') + '.tmp';
    try {
      fs.writeFileSync(tmpPath, JSON.stringify([...map.values()], null, 2), 'utf8');
      fs.renameSync(tmpPath, finalPath);
      noteSessionsDirOwnWrite(finalPath);   // 13e:这次目录变化是自己写的
    } catch (e) { try { fs.unlinkSync(tmpPath); } catch { /* best-effort */ } throw e; }
  } catch { /* best-effort; boot invalidation rebuilds from truth regardless */ }
}

// 「已知坏头」:盘上有 <id>.json,但它读出来不是合法会话(JSON 截断/写坏、不是对象、里面的 id 与文件名对不上)。
// 这种文件永远进不了重建的索引,而快路径比的是「索引 id 集 == 磁盘 id 集」—— 修前一个坏头就让每次 listSessions
// 都判漂移、全量扫盘重建(2000 条会话 ≈ 240–380 ms,侧栏每次刷新都付一遍),而且永不自愈。
// 现在全量扫描时把【确定性判坏】的 id 连同当时的文件戳记在这里,快路径比对时把它们从磁盘 id 集里扣掉。
// 只记确定性的坏(语法错 / 形状错 / id 不符);读文件本身失败(EBUSY/EPERM/被杀毒锁)不记 —— 那是这一次没读到,
// 文件可能是好的,记了会让一条好会话从侧栏消失。文件戳变了(用户把备份拷回去、别的进程重写)就作废、重新扫一遍。
// 只在内存里(进程重启后第一次全量扫描会把它记回来);条目只会因「文件没了 / 索引收下了它 / 文件戳变了」而摘掉。
const sessionIndexKnownBadHeads = new Map();   // id -> 文件戳(size|mtimeMs|ctimeMs)
function sessionHeadStampOf(st) { return `${st.size}|${st.mtimeMs}|${st.ctimeMs}`; }
// 判一份会话头文本:好的返回 meta 源对象,坏的(确定性)返回 null。与全量扫描、记坏头共用同一判据。
function parseSessionHeadForIndex(raw, id) {
  let item;
  try { item = JSON.parse(raw); } catch { return null; }
  // A valid JSON cache or a damaged/misnamed head is not a session. Keep its file untouched,
  // but never publish an entry whose id cannot be opened at this filename.
  if (!item || !safeSessionId(item.id) || item.id !== id) return null;
  return item;
}
// 全量扫描读到一个坏头:先取文件戳、再读一遍重新判(取戳在读之前 → 戳只会比内容老,之后文件再变戳就对不上,保守地重扫)。
async function noteSessionIndexBadHead(id) {
  try {
    const file = path.join(paths.sessions, id + '.json');
    const st = await fsp.stat(file);
    const raw = await fsp.readFile(file, 'utf8');
    if (parseSessionHeadForIndex(raw, id)) return;   // 取戳与重读之间被换成了好文件:不记
    sessionIndexKnownBadHeads.set(id, sessionHeadStampOf(st));
  } catch { /* 读不到(瞬时锁/刚被删):不记,下一次扫描再判 */ }
}
// 快路径用:返回「应当与索引 id 集对得上」的磁盘 id 集 = 磁盘 id 集扣掉仍然有效的已知坏头。
async function sessionDiskIdsExpectedInIndex(diskIds, indexIds) {
  if (!sessionIndexKnownBadHeads.size) return diskIds;
  const out = new Set(diskIds);
  for (const [id, stamp] of [...sessionIndexKnownBadHeads]) {
    // 文件没了 / 索引已经收下它(被重新存成了好会话):不再是「坏头」。
    if (!diskIds.has(id) || indexIds.has(id)) { sessionIndexKnownBadHeads.delete(id); continue; }
    let same = false;
    try { same = sessionHeadStampOf(await fsp.stat(path.join(paths.sessions, id + '.json'))) === stamp; } catch { same = false; }
    if (same) out.delete(id);
    else sessionIndexKnownBadHeads.delete(id);   // 文件变了:不再信旧结论,留在比对里 → 判漂移 → 重新扫一遍
  }
  return out;
}

// List sessions for the sidebar (7 meta fields each). FAST PATH: a valid index whose id-set matches the
// session files on disk exactly. FALLBACK: scan every real session file (source of truth) and rebuild the index.
async function listSessions() {
  await ensureDirs();
  const all = await fsp.readdir(paths.sessions).catch(() => []);
  // Search metadata lives beside session heads. It is not a session and must not enter either
  // the disk id-set or the rebuilt sidebar index (otherwise boot tries to open an undefined id).
  // 判据与 loadSession / 全量扫描同一个 safeSessionId(01):它拒绝 index、`_` 前缀这些保留名,也拒绝不合形的
  // 文件名 —— 修前这里只点名排除两个文件,别的保留名/怪名进了 diskIds、却永远进不了重建的索引,列表每次都判漂移全量扫。
  const files = all.filter(f => f.endsWith('.json') && safeSessionId(f.slice(0, -5)) !== null);
  const diskIds = new Set(files.map(f => f.slice(0, -5))); // strip '.json'
  // PF2 fix + 107-F9a: overlay everything not yet durable onto the disk index BEFORE trusting it. The index write
  // is debounced ~200ms, so without the overlay a read would serve a stale title / messageCount / pin / missionId
  // (or miss a brand-new session, or still show a just-deleted one). Two tables, because a batch lives in two
  // places before it is on disk: PENDING (queued, debounce not fired yet) and IN-FLIGHT (taken by a flush whose
  // write has not landed). PF2 overlaid only the first, so for the few ms of every flush's write the batch was in
  // neither and reads went stale — the ~200 ms-after-a-save window F8 measured. Overlaying both, and doing it in the
  // same synchronous step as the check below, is what makes a live read never staler than the most recent
  // saveSession/deleteSession that completed before it began.
  // The check: a flush retires its in-flight entries right after its write settles. If that happened while our
  // readFile was in progress we cannot tell whether we got the file from before or after that write, and the
  // entries that would have covered the difference are gone — so read again (a few times; racing flushes that
  // long means the index is being rewritten continuously, and the authoritative file scan below is the answer).
  let map = null;
  for (let attempt = 0; attempt < 4; attempt++) {
    const retireSeq = sessionIndexRetireSeq;
    const index = await readSessionIndex();
    if (retireSeq !== sessionIndexRetireSeq) continue;
    if (index) map = overlayUnflushedSessionIndex(new Map(index.map(e => [e && String(e.id), e]).filter(([id]) => id)));
    break;
  }
  if (map) {
    const indexIds = new Set(map.keys());
    const expectedIds = await sessionDiskIdsExpectedInIndex(diskIds, indexIds);   // 扣掉已知坏头,否则它让快路径永远对不上
    if (indexIds.size === expectedIds.size && [...expectedIds].every(id => indexIds.has(id))) {
      // 116f: 管家会话【只】在返回值里被滤掉,索引本身仍然收录它 —— 否则上面这个「索引 id 集 == 磁盘
      // id 集」的漂移判据永远不成立,每次 listSessions 都会退化成全量扫盘重建。
      return sortSessionMetas([...map.values()].map(sessionMeta).filter(meta => !sessionMetaIsSteward(meta))); // trust cache+in-flight+pending: id-set matches disk exactly
    }
  }
  // Index missing / corrupt / drifted from disk → authoritative scan of the real files, then rebuild the index.
  const scanSeq = sessionIndexWriteSeq;   // 128f-⑧:开扫之后排进来的写,写回时要叠上去(见 sessionIndexWriteSeq 头注)
  sessionIndexRebuildsActive += 1;
  const sessions = [];
  let rebuilt = sessions;
  const badSeen = new Set();   // 这一趟确定性判坏的 id(扫完用它换掉已知坏头表里对应的条目)
  try {
    for (const file of files) {
      const fileId = file.slice(0, -5);
      let raw;
      try { raw = await fsp.readFile(path.join(paths.sessions, file), 'utf8'); }
      catch { continue; }   // 读不到(瞬时锁/刚被删):跳过,不记坏头(见 sessionIndexKnownBadHeads 头注)
      const item = parseSessionHeadForIndex(raw, fileId);
      let meta = null;
      if (item) { try { meta = sessionMeta(item); } catch { meta = null; } }
      if (!meta) { badSeen.add(fileId); await noteSessionIndexBadHead(fileId); continue; }   // Ignore corrupt session files (记下,别让它拖死快路径)
      sessions.push(meta);
      if (sessionIndexRebuildScanHook) { try { await sessionIndexRebuildScanHook(String(item.id || '')); } catch { /* 测试钩子的异常不影响重建 */ } }
    }
    // 这一趟判好的、或盘上已没有的 id 不该留在已知坏头表里(坏头被修好 / 被删)。
    for (const id of [...sessionIndexKnownBadHeads.keys()]) if (!badSeen.has(id)) sessionIndexKnownBadHeads.delete(id);
    await withSessionIndexLock(() => {
      const byId = new Map(sessions.map(meta => [String(meta && meta.id), meta]));
      for (const [id, write] of sessionIndexLatestWrite) {
        if (!write || write.seq <= scanSeq) continue;
        if (write.val === SESSION_TOMBSTONE) byId.delete(id); else byId.set(id, write.val);
      }
      rebuilt = [...byId.values()];
      return writeSessionIndex(rebuilt);
    }).catch(() => {}); // best-effort rebuild
  } finally {
    sessionIndexRebuildsActive -= 1;
    if (sessionIndexRebuildsActive === 0) sessionIndexLatestWrite.clear();
  }
  return sortSessionMetas(rebuilt.map(sessionMeta).filter(meta => !sessionMetaIsSteward(meta))); // 116f: 同上,只滤返回值
}

// 计划条(session.todos)的指纹:管家「没做完就续」只认【这一回合里动过的】计划(13p stewardContinueUnfinishedGate)——
// 回合开头记一笔、收尾写进 stewardLastTurn.todosStartSig,与收尾时的现值不同才算这一回合在推进这份计划。
// 早就搁下、用户已经换了话题的旧计划不该让每个新回合都被当成「没做完」。
function sessionTodosSignature(todos) {
  const items = (Array.isArray(todos) ? todos : []).filter(t => t && typeof t === 'object')
    .map(t => [String(t.content || t.title || t.text || ''), String(t.status || '')]);
  return crypto.createHash('sha1').update(JSON.stringify(items)).digest('hex').slice(0, 16);
}

// 116-2a: patch 的应用规则单列一处 —— 立即落盘路径与「延后到回合 settle 之后」的重做路径必须逐字
// 一致(重做时是在一份【重新装载的新副本】上再应用一次同一个 patch)。
function applySessionMetaPatch(session, patch) {
  const id = session.id;
  // 116-5a(27 号文 §11.8.3):走这条通道改标题的只有两个调用面 —— PATCH /api/sessions/:id(用户
  // 在界面上改名)与 steward_thread_rename(管家替用户改名)。两者都是【有意起的名字】,应当压过
  // 116-5 自动生成的 threadBrief.title。会话头上本来分不出「标题是自动派生的原话」还是「人起的名字」
  // (两者都只是 session.title),不记这一笔的话「线程改名后不再被摘要覆盖」这条需求无法实现。
  if (typeof patch.title === 'string') { session.title = patch.title.slice(0, 200); session.titleSource = 'user'; if (patch.titleSource !== 'steward') sessionTitleOverrides.set(id, { title: session.title, titleSource: 'user' }); }
  if (typeof patch.pinned === 'boolean') session.pinned = patch.pinned;
  if (Object.prototype.hasOwnProperty.call(patch, 'engineRoute')) {
    const route = normalizeSessionEngineRoute(patch.engineRoute);
    if (route) {
      session.engineRoute = route;
      // 显式「仅此任务」跨回合保留，不能在下次用户发消息时又写成新任务的“上次用的”。
      if (patch.engineRouteScope === 'thread') session.engineRouteScope = 'thread';
      else delete session.engineRouteScope;
      sessionEngineRouteOverrides.set(id, route);
      sessionEngineRouteScopeOverrides.set(id, session.engineRouteScope || '');
      // 123-N2 写入点①:用户在线程头上亲手换了引擎/模型。这条通道【只有】用户走得到 ——
      // PATCH /api/sessions/:id(线程头 chip)与进程内改会话头的调用方;管家给新线程定档走的
      // 是 13q stewardApplyThreadTier,它直接写 session.engineRoute,根本不经过本函数。
      // 本函数是同步的(它有两条调用路径:立即落盘与活回合 settle 之后重放),不能 await;
      // 记账是旁路,fire-and-forget 且内部整段 try —— 见 rememberLastUsedEngineRoute 头注第三条。
      // 重放那条路会再记一次:同值第二次是 mutateConfig 锁内的一次 abort,无副作用。
      if (session.engineRouteScope !== 'thread') void rememberLastUsedEngineRoute(route);
    }
  }
  // 116-2a(§3.3/§8.6):线程级权限档,形状与 engineRoute 这个既有的会话级先例对齐(同端点、同覆盖表
  // 纪律)。null/''/非法值 = 清除会话级设置回落全局(白名单校验在 API 层已经把非法值挡成 400,这里
  // 是第二道:任何内部调用方写进来的垃圾都只会退化成「跟随全局」,绝不会写出一个野档)。
  if (Object.prototype.hasOwnProperty.call(patch, 'permissionMode')) {
    const mode = normalizeSessionPermissionMode(patch.permissionMode);
    sessionPermissionModeOverrides.set(id, mode);
    if (mode) session.permissionMode = mode; else delete session.permissionMode;
  }
  // 117z-E2 提交①(§11.21.3):会话级桌面工具覆盖。形状与上面 permissionMode 那条逐字对齐(同覆盖表
  // 纪律、同延后落盘防护)。三态:true / false / null(= 清除会话级设置,回落全局 allowDesktopTools)。
  // 【它是状态,不是出身】—— 所以它进白名单,而下面那条 createdBy 不进。
  // 如实记两件事:① 这条通道也接 PATCH /api/sessions/:id,所以【用户】可以经界面/脚本改自己线程的
  // 这一项(与「桌面权限在设置里改」同一语义,§11.21.2);管家【碰不到这条路】——它手里只有 steward_*
  // 工具,没有任何一个能发 HTTP PATCH,放宽那一侧的闸在 13k 的工具实现里。② 与 permissionMode 切
  // 「全自动」不同,这里【没有】confirm:true 那道二次确认门(那道门在 13d 的路由层,不在本函数);
  // 已登记为债。
  if (Object.prototype.hasOwnProperty.call(patch, 'desktopTools')) {
    const desk = normalizeSessionDesktopTools(patch.desktopTools);
    sessionDesktopToolsOverrides.set(id, desk);
    if (desk === null) delete session.desktopTools; else session.desktopTools = desk;
  }
  // 117z-E2 提交①(§11.21.3):`createdBy` 【故意不在这张白名单里】,一个分支都不给它。
  // 它记的是【出身】(这条线程是不是管家开的),不是状态 —— 只在 13k 的两处 createSession 调用点
  // (thread_new / quick_ask)写一次,此后终身不变。放宽桌面权限的目标合法性判据读的正是它:
  // 一旦它能经 PATCH 改,任何调用方都能把自己的普通会话刷成「管家开的」,再去要桌面权限,
  // §11.21.3 的「只能开给管家自己开的线程」就成了一句空话。本函数是白名单语义,不写分支
  // 即拒绝(patch.createdBy 静默丢弃),这条注释是给日后加分支的人看的锚。
  // 116g(§3.1 事项跨会话升格):线程归属。**只认合法 id,且只由 06e 的 missionAttachThread /
  // missionDetachThread 写** —— 它们成对维护「会话头 missionId」与「事项文件 sessionIds」两侧。
  // 走这条 patch 通道(而不是直接 loadSession+saveSession)是为了白拿 116-2a 的活回合竞态防护:
  // 活回合期间延后到回合 settle 之后、在【重新装载的副本】上重放同一个 patch,绝不用陈旧正文
  // 盖掉回合刚写的消息。非法值一律忽略(绝不写出一个野 missionId,那会让线程从投影里凭空消失)。
  if (Object.prototype.hasOwnProperty.call(patch, 'missionId')) {
    const missionId = safeSessionId(patch.missionId);
    if (missionId) session.missionId = missionId;
  }
  // 116-2e(27 号文 §11.1 第 2 项「速查线程自动收工」):速查会话头上的 stewardQuick 标。走这条 patch
  // 通道与 missionId 同理 —— 收工恰好发生在回合刚结束的窗口里,白拿 116-2a 的活回合竞态防护(延后到
  // settle 之后在【重新装载的副本】上重放,绝不用陈旧正文盖掉回合刚写的答案)。
  // 严格归一成固定六个字段:这条通道也接 PATCH /api/sessions/:id 的请求体,不能让任意形状写进会话头。
  // 116-3 P1-6 加第六个 closedTurnSeq:收工那一刻的回合数。之后会话每多一个用户回合 turnSeq 就会
  // 超过它 = 用户在经典 2.0 视窗里把这条速查线程继续用起来了,收工标记应当自动失效(判据单点在 13g 的
  // stewardQuickClosed)。不写进白名单的话它会被这段归一化静默丢掉,重开判据永远拿不到锚点。
  if (patch.stewardQuick && typeof patch.stewardQuick === 'object' && !Array.isArray(patch.stewardQuick)) {
    const q = patch.stewardQuick;
    const closedTurnSeq = Number(q.closedTurnSeq);
    session.stewardQuick = {
      schema: 1,
      askedAt: String(q.askedAt || ''),
      question: String(q.question || '').slice(0, 1000),
      stewardTurnKey: String(q.stewardTurnKey || ''),
      closedAt: q.closedAt ? String(q.closedAt) : null,
      ...(Number.isFinite(closedTurnSeq) && closedTurnSeq >= 0 ? { closedTurnSeq: Math.round(closedTurnSeq) } : {}),
    };
  }
  // 116-4（27 号文 §11.7「第四源 sessionTurns 与唤醒链」）：管家线程的两个标。
  //   · launchedBy:'steward' —— 这条线程的回合是管家发起的（thread_new / quick_ask / 递话）。
  //     收件箱第四源只对【管家关心的会话】入箱，它就是「关心」的机器痕迹之一
  //     （另两个是 stewardQuick 与「线程在别人的事项里」）。只认 'steward' 这一个字面量：
  //     其它值一律当没写，不让 PATCH /api/sessions/:id 的调用方拿它给自己的普通会话
  //     挂上管家的注意力。
  //   · stewardLastTurn —— 管家发起的那一回合 settle 之后的成败（13g stewardLaunchTurn 写）。
  //     会话头上本来【没有】任何回合成败字段（116-4 实测：回合失败后头上只有 summary
  //     里那句人话，那是渲染不是信号），而收件箱只读磁盘 —— 所以第四源要分得出
  //     done / failed，就必须有这一条落盘的账。严格归一成固定五字段，与 stewardQuick 同纪律。
  if (patch.launchedBy === 'steward') session.launchedBy = 'steward';
  // 121-K3(34 号文 §4.4「交接」):「交给管家盯 / 别盯了」那枚开关。**只认两个布尔字面量** ——
  // 其它任何值(字符串 'true'、1、null、对象)一律当没写,不让调用方拿它往会话头上写野值。
  // 它是【状态】不是出身,所以进白名单(与 launchedBy 同一条理由);而它的一对孪生字段
  //   · origin    —— 【故意不在这张白名单里】,一个分支都不给它。它记的是「这条线程是谁开的」,
  //                  只在 createSession 写一次、此后终身不变。一旦能经 PATCH 改,任何调用方都能把
  //                  自己的普通会话刷成「管家开的」,来源图形(环/人形/钟)就成了一句空话 ——
  //                  与本函数上方 createdBy 那条注释是同一个模具,理由也是同一个。
  //   · createdBy —— 见本函数上方 117z-E2 那段注释锚。
  // 判据侧:stewardWatchedThread(06i)把 true/false 都当【显式意愿】,排在原来三条判据之前 ——
  // 写 false 对管家自己开的线程同样生效(= 用户接手,别再盯了)。
  if (patch.stewardWatch === true) session.stewardWatch = true;
  else if (patch.stewardWatch === false) session.stewardWatch = false;
  // 成败账只进不退:turnSeq 单调(rewind 也不回退它),两笔写入乱序落盘时(10 的收尾写与 13k/13s 的写不在一条链上)
  // 旧回合那笔不能盖掉新回合那笔;同号允许覆盖(同一回合的后写者带的是更完整的那份)。
  const prevLastTurnSeq = session.stewardLastTurn && typeof session.stewardLastTurn === 'object' ? Number(session.stewardLastTurn.seq) : NaN;
  if (patch.stewardLastTurn && typeof patch.stewardLastTurn === 'object' && !Array.isArray(patch.stewardLastTurn)
      && !(Number.isFinite(prevLastTurnSeq) && Number(patch.stewardLastTurn.seq) < prevLastTurnSeq)) {
    const t = patch.stewardLastTurn;
    const seq = Number(t.seq);
    session.stewardLastTurn = {
      seq: Number.isFinite(seq) && seq >= 0 ? Math.round(seq) : 0,
      ok: t.ok === true,
      aborted: t.aborted === true,
      errorClass: String(t.errorClass || '').slice(0, 64),
      at: String(t.at || ''),
      todosStartSig: String(t.todosStartSig || '').slice(0, 64),
    };
  }
  // 116-5a(27 号文 §11.8「线程自动摘要」):线程的名字与一句概括。严格归一成固定六字段,与
  // stewardQuick / stewardLastTurn 同纪律 —— 这条通道也接 PATCH /api/sessions/:id,不能让任意形状
  // 写进会话头。title/gist 在这里就夹到上限:显示层不必再截一次,存量数据也不会因为上限调整而变形。
  if (patch.threadBrief && typeof patch.threadBrief === 'object' && !Array.isArray(patch.threadBrief)
      && (patch.threadBriefRewindGen === undefined || (Number(session.rewindGen) || 0) === patch.threadBriefRewindGen)) {
    const b = patch.threadBrief;
    const stage = String(b.stage || '');
    session.threadBrief = {
      schema: 1,
      title: String(b.title || '').replace(/\s+/g, ' ').trim().slice(0, SESSION_BRIEF_TITLE_CHARS),
      gist: String(b.gist || '').replace(/\s+/g, ' ').trim().slice(0, SESSION_BRIEF_GIST_CHARS),
      at: String(b.at || ''),
      model: String(b.model || '').slice(0, 160),
      stage: (stage === 'first_turn' || stage === 'settled') ? stage : 'first_turn',
    };
  }
  // 116-5a:只认白名单里的字面量(同 116-4 的 launchedBy)。别的值一律当没写 —— 调用方拿它
  // 给自己刷一个假的「人起的名字」没有意义,但白名单该有的严格一分不能少。
  // 117s-A D2(§11.13 ⑤a;用户第九轮走查「线程标题概括就是管家发的提示词本身,太长了」):
  // 白名单多一个字面量 'steward' —— `steward_thread_new` 传进来的 title 【不是】人起的名字。
  // §11.8.4 当年的假设是「args.title 是管家有意起的名字,与改名同一性质」,用户真机上两条线程
  // (sess_e97b… 大A / sess_8bb0… 博纳)证明这条假设不成立:模型把用户那句话原样抄进了 title,
  // 而 createSession 见非占位标题就写 titleSource:'user'(见下方 createSession),于是 116-5 的
  // 自动摘要判据(06-provider-engine:「titleSource === 'user' 就跳过」)永远短路,threadBrief 恒为 null。
  // 'steward' 这一档的语义:标题有,但它排在生成的名字【后面】—— 显示优先级于是如实是
  // 人起的 > 生成的 > 管家抄来的那句(它就是 session.title 本身)> 原话,sessionDisplayTitle
  // 一个字都不用改就已经是这条顺序(它只在 'user' 那一档提前返回)。
  if (patch.titleSource === 'user' || patch.titleSource === 'steward') session.titleSource = patch.titleSource;
  // v0.9-S3 (C3): the top-bar working-folder picker + folder-drag switch persist the session's cwd here.
  // Resolve to an absolute path (mirrors normalizeCwd); a blank/non-string value is ignored (never clears
  // an existing cwd). The turn engine reads `cwd || session.cwd`, so this becomes the working dir for the
  // next turn. No existence check — a stale/moved folder simply resolves at run time like any manual entry.
  if (typeof patch.cwd === 'string' && patch.cwd.trim()) {
    const cwd = process.platform === 'darwin' && patch.cwd.startsWith('/') ? patch.cwd : patch.cwd.trim();
    session.cwd = path.resolve(cwd);
  }
  return session;
}

// 116-2a(116c 登记的既有根因:「updateSessionMeta 读改写与活回合收尾 save 的竞态」)。
// 症状:活回合期间 loadSession 拿到的是【磁盘上那一刻】的副本;回合把新消息写进它自己的内存副本、
// 在收尾时整份落盘。两份副本互相覆盖 —— 元数据改动被回合盖回,或更糟:元数据这份陈旧正文把回合刚
// 写的消息盖没(会话正文缩水 = 头计数与正文行数错位)。
// 策略【延后落盘】,不是拒绝。理由:
//   ① §8.6 要求权限 chip「点开即换、立即生效」,而一个回合可以跑几分钟 —— 在最该收紧权限的那几分钟
//      里让 chip 失效是本末倒置;拒绝(session.busy)把这个竞态从「会丢数据」变成「用不了」,不是修。
//   ② 延后并不牺牲「立即生效」:permissionMode 先进内存覆盖表,loadSession/saveSession 两侧都应用它,
//      对所有读者(含下一个回合的档位解析)立刻是新值;而且活回合自己的下一次 saveSession 就会把它
//      带上磁盘 —— 那份副本拿的是最新正文,不会盖消息。
//   ③ 重做时【重新 loadSession】再应用同一个 patch,任何时刻都不会拿陈旧正文覆盖。
// 保留 steward_thread_rename 自己的 steward.busy 忙锁(116c):那是【自动】改名,对管家来说立刻失败比
// 静默延后更诚实(「不要重试,等它停」写在 schema 里),且其断言已冻结。
const sessionMetaDeferChains = new Map(); // id -> Promise(每会话一条串行链,落盘后自清)
const SESSION_META_DEFER_TIMEOUT_MS = 180000; // 回合真楔死时的兜底:超时后照样按【重新装载】的副本写一次
// 121-K6a(34 号文 §4.4「交接」):委托一句。只在【同一发 PATCH 里 stewardWatch===true】时才有效——
// 不是会话状态,是一次性的交接话,所以【不落会话头】:applySessionMetaPatch 不认它,它只活在这一次
// 请求的 thread.adopted 事件里,管家读完这一条就完了,不会在会话头上留下第二份「委托」字段。
const STEWARD_WATCH_NOTE_MAX = 200;
function stewardWatchNoteFrom(p) {
  if (!p || p.stewardWatch !== true) return '';
  const raw = typeof p.stewardWatchNote === 'string' ? p.stewardWatchNote : '';
  return raw.trim().slice(0, STEWARD_WATCH_NOTE_MAX);
}

// 107-F7b:元数据补丁撞上撤回时的重放上限。updateSessionMeta 是读改写 —— 它 load 落在撤回之前、save 落在
// 撤回之后时,那份副本带着撤回删掉的消息,代数闸会整份丢掉它(否则就是把撤回盖回去,F7b 那条缺陷本身:
// 13k stewardRecordLaunchOutcome 在回合 settle 那一刻发的正是这一发 —— 负载复现里被闸丢掉的那一存
// 日志为 writer:'session_meta'、keys:[launchedBy, stewardLastTurn])。丢掉的是正文,补丁本身
// (改名、权限档、stewardLastTurn、threadBrief……)是真数据,不能跟着丢:在【新读】的副本上重放一次。
// 有界:连着撞上三次撤回才会放弃,那时把 SESSION_STALE_SAVE 如实抛给调用方(与 save 失败同一条语义)。
const SESSION_META_STALE_REPLAYS = 2;
async function updateSessionMeta(id, patch) {
  return updateSessionMetaAttempt(id, patch, 0);
}
async function updateSessionMetaAttempt(id, patch, replayDepth) {
  const p = (patch && typeof patch === 'object') ? patch : {};
  const watchNote = stewardWatchNoteFrom(p);
  // hunt2-P4:读-改-存进 mutateSession 同一条 per-id 链(与它互斥,见 withSessionMutateLock 头注)。
  // 链内只做这一次 load→patch→save;撤回重放的递归与延后通道都在链【外】,不会自己等自己。
  const step = await withSessionMutateLock(id, async () => {
    const loaded = await loadSession(id);
    if (!loaded) return { session: null };
    applySessionMetaPatch(loaded, p);
    // 活回合(activeChildren)或 dying turn 收尾窗口(turnSettlers,第69波 rewind 同款判据)之外:原路不变。
    if (activeChildren.has(id) || turnSettlers.has(id)) return { session: loaded, deferred: true };
    try { await saveSession(loaded, { throwIfStale: true, writer: 'session_meta' }); }
    catch (error) { return { session: loaded, error }; }
    return { session: loaded };
  });
  const session = step.session;
  if (!session) return null; // missing/corrupt — caller maps to 404
  if (!step.deferred) {
    if (step.error) {
      const error = step.error;
      if (!(error && error.code === 'SESSION_STALE_SAVE') || replayDepth >= SESSION_META_STALE_REPLAYS) throw error;
      // 107-F7b:从头再走一遍(重新 load、重新判活回合),而不是只在原地重试 save —— 撤回之后可能已经
      // 起了新回合,那时补丁该走下面那条延后通道,不能拿新副本去跟活回合抢写。
      logEvent({ kind: 'session_meta_replayed', sessionId: id, keys: Object.keys(p).slice(0, 8), attempt: replayDepth + 1 });
      return updateSessionMetaAttempt(id, patch, replayDepth + 1);
    }
    RUYI_EVENTS.emit('thread.state', { sessionId: id });   // 121-K2a:会话头刚变过,五态由订阅者现算
    // 121-K3(§4.4「工作台 → 管家」):用户刚按下「交给管家盯」。复用 missionAttachThread 已经在派的
    // 同名事件,只多一个 by:'user' 把两条来路分开(那一条是归并到事项,这一条是用户交接)。
    // 121-K6a:附带的一句委托话(有的话)随同一发事件带上,note 只在这一发里,不重复读取。
    if (p.stewardWatch === true) RUYI_EVENTS.emit('thread.adopted', { sessionId: id, missionId: String(session.missionId || ''), title: String(session.title || ''), by: 'user', ...(watchNote ? { note: watchNote } : {}) });
    return session;
  }
  logEvent({ kind: 'session_meta_deferred', sessionId: id, keys: Object.keys(p).slice(0, 8) });
  const previous = sessionMetaDeferChains.get(id) || Promise.resolve();
  const chain = previous.catch(() => {}).then(async () => {
    let forced = false;
    const settler = turnSettlers.get(id);
    if (settler && settler.promise) {
      const settled = await Promise.race([
        settler.promise.then(() => true, () => true),
        new Promise(r => setTimeout(() => r(false), SESSION_META_DEFER_TIMEOUT_MS)),
      ]);
      if (!settled) { forced = true; logEvent({ kind: 'session_meta_defer_timeout', sessionId: id }); }
    }
    // hunt2-P4:settle 已在上面(链外)等过;读-改-存这一段进 per-id 读改写链,与 mutateSession 互斥。
    const fresh = await withSessionMutateLock(id, async () => {
      let copy = await loadSession(id).catch(() => null);
      if (!copy) return null;                 // 会话在窗口内被删了:什么都不做(删除已清覆盖表)
      applySessionMetaPatch(copy, p);
      // 107-F7b:「重新装载的副本」在 load 与 save 之间同样可能撞上一次撤回(settle 之后正是撤回动手的
      // 时刻),被代数闸丢掉时在更新的副本上重放补丁,有界(SESSION_META_STALE_REPLAYS)。
      // 其它失败沿用旧语义:吞掉(旁路写,不反噬调用方)。
      for (let attempt = 0; ; attempt++) {
        try { await saveSession(copy, { throwIfStale: true, writer: 'session_meta_deferred' }); break; }
        catch (error) {
          if (!(error && error.code === 'SESSION_STALE_SAVE') || attempt >= SESSION_META_STALE_REPLAYS) break;
          logEvent({ kind: 'session_meta_replayed', sessionId: id, keys: Object.keys(p).slice(0, 8), attempt: attempt + 1, deferred: true });
          copy = await loadSession(id).catch(() => null);
          if (!copy) return null;
          applySessionMetaPatch(copy, p);
        }
      }
      return copy;
    });
    if (!fresh) return;
    RUYI_EVENTS.emit('thread.state', { sessionId: id });   // 121-K2a:延后那条路落盘之后同样要派
    // 121-K3:延后那条路同样要派交接事件(用户完全可能在一个回合跑着的时候按下那枚开关)。
    // 121-K6a:note 算在 patch 到来那一刻(watchNote,外层闭包变量),不是等到这里才重算——委托话是
    // 那一刻说的那句,不该被延后窗口期间任何变化影响。
    if (p.stewardWatch === true) RUYI_EVENTS.emit('thread.adopted', { sessionId: id, missionId: String(fresh.missionId || ''), title: String(fresh.title || ''), by: 'user', ...(watchNote ? { note: watchNote } : {}) });
    // 116-3 data-safety P1-3(登记项转已记录):超时兜底那条路是【明知有残留竞态】仍然写下去 ——
    // 等待窗口过了不等于收尾 save 真的落盘完成,此刻拿到的 fresh 可能还不含最新一轮消息,两边互相
    // 覆盖谁赢看时序。行为不改(拒绝会把「会丢字段」换成「用不了」,§8.6 要求 chip 点开即换),
    // 但必须【留痕】:落一条审计事件,写清楚这次强制写发生在什么状态下,事后能对账。
    if (forced) {
      logEvent({
        kind: 'session_meta_defer_forced', sessionId: id, keys: Object.keys(p).slice(0, 8),
        stillActive: activeChildren.has(id), stillSettling: turnSettlers.has(id),
      });
    }
  });
  // 自清,避免长驻会话把链表越挂越长;只清自己那一条(后来者可能已经顶上)。
  const wrapped = chain.then(() => {}, () => {});
  sessionMetaDeferChains.set(id, wrapped);
  wrapped.then(() => { if (sessionMetaDeferChains.get(id) === wrapped) sessionMetaDeferChains.delete(id); });
  // 返回值是「投影」:磁盘上的会话 + 本次 patch,与落盘后的结果一致(调用方据此回 200)。
  return session;
}

// hunt2-P2:删除墓碑。id → { at, purgeAssociated }。stopSession 只是 abort,被停回合的收尾 saveSession(以及任何
// 手里还攥着旧会话对象的旁路写者)会在 unlink 之后把头与正文整份写回 —— 会话「复活」,列表里又出现、GET 200。
// saveSession 在【写链内】查墓碑:createdAt 不晚于删除时刻的对象 = 删除之前就存在的那条会话的副本,整次写丢弃。
// 用 createdAt 而不是「有墓碑就拒」:固定 id 的会话(管家 STEWARD_SESSION_ID)删掉后会以同一个 id 重建,
// 新对象的 createdAt 晚于删除时刻,照常落盘;createSession 另外显式清墓碑。条目只活在本进程(重启后没有
// 在飞的旧对象),有上限防长驻进程无界增长。
const SESSION_DELETE_TOMBSTONE_MAX = 5000;
const SESSION_DELETE_SETTLE_TIMEOUT_MS = 8000;   // 与 rewindSession 等垂死回合 settle 的窗口同值
const sessionDeleteTombstones = new Map();
function markSessionDeleted(id, purgeAssociated = false) {
  const previous = sessionDeleteTombstones.get(id);
  sessionDeleteTombstones.delete(id);
  sessionDeleteTombstones.set(id, { at: Date.now(), purgeAssociated: Boolean(purgeAssociated || (previous && previous.purgeAssociated)) });
  while (sessionDeleteTombstones.size > SESSION_DELETE_TOMBSTONE_MAX) sessionDeleteTombstones.delete(sessionDeleteTombstones.keys().next().value);
}
function sessionSaveIsTombstoned(session) {
  const deleted = sessionDeleteTombstones.get(session && session.id);
  if (!deleted) return false;
  const createdMs = Date.parse(String((session && session.createdAt) || ''));
  return !Number.isFinite(createdMs) || createdMs <= deleted.at;
}
function sessionAssociatedSaveIsTombstoned(id) {
  const deleted = sessionDeleteTombstones.get(id);
  return !!(deleted && deleted.purgeAssociated);
}
// Delete the persisted chat itself. `purgeAssociated` is deliberately opt-in: a normal single-chat
// delete keeps its previous, conservative behavior, while the batch-cleanup flow can also reclaim
// the per-chat recovery and workflow records that otherwise have their own GC lifecycle.
// 工具截图附件(10 boundToolResultForDisplay)落在 uploads/toolimg_<tag>_<hash>/,tag 由会话 id 派生;删会话时按前缀整批清,
// 否则长时间的桌面操控会话会在 uploads/ 里留下成百上千个永不回收的文件。
function toolImageSessionTag(sessionId) { return crypto.createHash('sha1').update(String(sessionId)).digest('hex').slice(0, 10); }
async function removeSessionToolImages(sessionId) {
  const prefix = `toolimg_${toolImageSessionTag(sessionId)}_`;
  let names = [];
  try { names = await fsp.readdir(paths.uploads); } catch { return 0; }
  let n = 0;
  for (const name of names) {
    if (!name.startsWith(prefix)) continue;
    await fsp.rm(path.join(paths.uploads, name), { recursive: true, force: true }).then(() => { n += 1; }).catch(() => {});
  }
  return n;
}
async function deleteSession(id, { purgeAssociated = false } = {}) {
  // 不合形/保留名(index、`_` 前缀 …,见 01 safeSessionId)先拒:修前 DELETE /api/sessions/index 一路走到 unlink index.json。
  assertSessionIdForPath(id);
  // hunt2-P2:先立墓碑(同步,先于 stopSession 触发的任何收尾),再等垂死回合 settle 与已在跑的那一截写链
  // 落完,最后才 unlink —— 否则 unlink 与正在进行的 append/头写交错,删完还会剩下半份文件。
  markSessionDeleted(id, purgeAssociated);
  stopSession(id, 'deleted');
  // 后台班组不在 activeChildren 里。删除线程同样要停它们,否则它们仍会派发后续节点。
  // 停止只请求 abort,不是等待收尾;清关联数据时还要等已在飞的快照/事件写完,迟到写由同一墓碑拒掉。
  const deletedRunIds = new Set([...activeAgentRuns.values()].filter(live => live && live.run && live.run.sessionId === id).map(live => live.run.id));
  await stopMissionAgentRuns(id);
  {
    const settler = turnSettlers.get(id);
    if (settler && settler.promise) {
      const settled = await Promise.race([
        settler.promise.then(() => true, () => true),
        new Promise(r => { const t = setTimeout(() => r(false), SESSION_DELETE_SETTLE_TIMEOUT_MS); if (t.unref) t.unref(); }),
      ]);
      if (!settled) logEvent({ kind: 'session_delete_settle_timeout', sessionId: id });
    }
    const inFlight = sessionWriteChains.get(id);
    if (inFlight) await inFlight.catch(() => {});
    // C2:草稿本那一截写链同样先落完再 unlink(墓碑已立,之后排进来的写会被 updateSessionScratchpad 拒掉)。
    const scratchpadInFlight = sessionScratchpadChains.get(id);
    if (scratchpadInFlight) await scratchpadInFlight.catch(() => {});
  }
  try { revokeAllGrants(id, 'session-deleted'); } catch { /* best-effort */ } // 第27波:会话销毁 → 授权书全清
  // 116g:删线程 = 从它所在事项的反向索引里摘掉。**必须在删会话头之前读**(头没了就不知道它属于谁)。
  // 漏掉这一步不会让读模型说错话(读侧一律与会话头对账,死 id 天然不进任何视图),但会让事项文件里
  // 留一条永远对不上的 id —— 索引是权威,权威里不该有垃圾。尽力而为,任何失败都不阻断删除。
  try {
    const head = await readMissionSessionHead(id);
    const owner = head && sessionMissionId(head);
    if (owner && owner !== id) await missionIndexRemove(owner, id);
  } catch { /* best-effort: 读侧对账兜底 */ }
  await fsp.unlink(sessionPath(id)).catch(() => {}); // idempotent
  // v1.9 存储 v2:正文/迁移备份/损坏隔离副本一并清(用户删会话 = 删除其全部数据载体)。
  const bp = sessionBodyPaths(id);
  const proposalSessionId = safeSessionId(id);
  await Promise.all([
    fsp.unlink(bp.messages).catch(() => {}),
    fsp.unlink(bp.provider).catch(() => {}),
    fsp.unlink(sessionPath(id) + '.v1bak').catch(() => {}),
    fsp.unlink(sessionPath(id) + '.corrupt').catch(() => {}),
    fsp.unlink(bp.messages + '.corrupt').catch(() => {}),
    fsp.unlink(bp.provider + '.corrupt').catch(() => {}),
    fsp.unlink(bp.messages + '.prevbody').catch(() => {}),
    fsp.unlink(bp.provider + '.prevbody').catch(() => {}),
    fsp.unlink(interventionFilePath(id)).catch(() => {}),
    fsp.unlink(missionChangeFilePath(id)).catch(() => {}),
    // hunt2-P9:会话笔记旁车与每会话 MCP 配置(内含 loopback token 与外部 MCP 的 env)同属这条会话的数据载体。
    fsp.unlink(sessionNotesPath(id)).catch(() => {}),
    fsp.unlink(sessionScratchpadPath(id)).catch(() => {}),   // C2:会话草稿本旁车
    proposalSessionId ? fsp.unlink(path.join(paths.generated, `workbench.mcp.${proposalSessionId}.json`)).catch(() => {}) : Promise.resolve(),
    proposalSessionId ? fsp.unlink(path.join(paths.memory, 'proposals', proposalSessionId + '.json')).catch(() => {}) : Promise.resolve(),
    // hunt2 #19:后台任务账本(11 backgroundJobFile,同一 safeSessionId 闸)—— 含命令输出/代理信封,随会话一起删。
    proposalSessionId ? fsp.unlink(path.join(paths.sessions, 'background-jobs', proposalSessionId + '.json')).catch(() => {}) : Promise.resolve(),
  ]);
  await removeSessionToolImages(id);
  dropSessionBodyState(id);
  bumpSessionDiskWriteSeq(id);   // 删除前开读的装载不得把旧副本回写成「复活」的会话
  sessionTitleOverrides.delete(id);
  sessionEngineRouteOverrides.delete(id);
  sessionEngineRouteScopeOverrides.delete(id);
  sessionPermissionModeOverrides.delete(id); // 116-2a: 会话销毁 = 覆盖表条目一并销毁(否则同名新会话会继承)
  sessionDesktopToolsOverrides.delete(id);   // 117z-E2 提交①: 同上(桌面覆盖绝不能被同名新会话继承)
  dropInterventionSessionState(id);          // 介入记录缓存 + 压实节拍计数:会话没了,内存里的这两份也不留
  if (purgeAssociated) {
    if (EventStreamHooks.flushSessionAgentRuns) await EventStreamHooks.flushSessionAgentRuns(id, deletedRunIds);
    await Promise.all([
      fsp.rm(journalDir(id), { recursive: true, force: true }).catch(() => {}),
      fsp.rm(agentRunDir(id), { recursive: true, force: true }).catch(() => {}),
    ]);
  }
  scheduleSessionIndexUpdate(id, SESSION_TOMBSTONE); // PF2: queue removal from the metadata index (debounced; see saveSession)
  markPretenderIndexDirty(id, 'source'); // 75c: remove from disposable Mission/Intervention projection index
  // 128f-⑫(用户 2026-09-19「删除线程没有及时的界面反馈」):删完告诉所有在看的人「这一条没了」。
  // 修前一帧都不派,管家视角的左栏要等 15 s 那一拍轮询或用户点别处(13r 的 thread.removed 头注)。
  RUYI_EVENTS.emit('thread.removed', { sessionId: id });
  return { ok: true, id, purgedAssociated: Boolean(purgeAssociated) };
}

// Safety-first bulk history cleanup. It can only delete UNPINNED chats, preserves the explicitly
// supplied current chat, and refuses to tear down a currently-running chat. This keeps the UI action
// useful for clearing history without turning a single misclick into a "delete everything" operation.
async function bulkDeleteUnpinnedSessions({ preserveSessionId, purgeAssociated = false } = {}) {
  const preserveId = safeSessionId(preserveSessionId);
  const sessions = await listSessions();
  const deleted = [];
  const skipped = { pinned: 0, preserved: 0, active: 0 };
  for (const meta of sessions) {
    if (!meta || !meta.id) continue;
    if (meta.pinned) { skipped.pinned++; continue; }
    if (preserveId && meta.id === preserveId) { skipped.preserved++; continue; }
    if (activeChildren.has(meta.id)) { skipped.active++; continue; }
    await deleteSession(meta.id, { purgeAssociated });
    deleted.push(meta.id);
  }
  return { ok: true, deleted, deletedCount: deleted.length, skipped, purgedAssociated: Boolean(purgeAssociated) };
}

// 架构还债批 3·B: 会话引擎路由的纯函数(normalizeSessionEngineRoute/sessionEngineRouteFromConfig/inferSessionEngineRoute/configForSessionEngineRoute)抽至 02e-session-engine-route.js。

// ── 123-N2「新线程默认上一次用的引擎」(用户 2026-09-13 真机原话:「现在新开线程会默认开 Kimi
// code cli,我希望改成默认上一次用的或者别的方式,不要设定死」)────────────────────────────────
//
// 病根:createSession 的缺省【只有】 sessionEngineRouteFromConfig(config) 这一条路 —— 全局
// activeProvider/agentCliType/model 三项设置。用户在线程头上把引擎切成别的,那个选择只活在
// 那一条线程头上,下一条新线程照旧回到全局那一项(用户机器上 agentCliType 是 kimi),这就是
// 「写死」。修法不是改全局默认值(那只是把写死换了个值),而是给新线程的缺省【加一层可选来源】。
//
// 记(rememberLastUsedEngineRoute)与读(newSessionEngineRoute)分两处,共用 config 上的一个字段。
// ────────────────────────────────────────────────────────────────────────────────────────
// 记:**两个写入点共用这一个函数**,不许各写一遍。
//   ① 用户在线程头上换引擎/模型 → PATCH /api/sessions/:id → applySessionMetaPatch;
//   ② 用户自己发起的回合 → 10 的 runSessionTurn 且 source === 'http'。
// 三条纪律:
//   · 只记【用户自己的意思表示】。管家(source 'steward')与将来的调度器(source 'scheduler')
//     派出去的回合一概不记 —— 判据在调用点那个 if,不在这里(这里拿到的就是「该记的那一条」);
//   · 【与现值不同才落盘】,否则每个回合都要写一次 config.json;权威比对在 mutateConfig 的锁内
//     再做一次(锁外那一次只是拿调用方手上的现成副本做便宜短路,可能已经陈旧);
//   · 【失败静默】。这是旁路记账 —— 写不进去最多是下一条新线程回落全局,绝不能弄坏回合或 PATCH。
async function rememberLastUsedEngineRoute(nextRoute, knownConfig) {
  try {
    const clean = normalizeSessionEngineRoute(nextRoute);
    if (!clean) return false;
    const wanted = JSON.stringify(clean);
    if (knownConfig && typeof knownConfig === 'object'
      && JSON.stringify(normalizeSessionEngineRoute(knownConfig.lastUsedEngineRoute)) === wanted) return false;
    let wrote = false;
    await mutateConfig(async current => {
      if (JSON.stringify(normalizeSessionEngineRoute(current.lastUsedEngineRoute)) === wanted) return { abort: 'unchanged' };
      current.lastUsedEngineRoute = clean;
      wrote = true;
    });
    return wrote;
  } catch { return false; }
}

// 「上一次用的」现在还能不能用。只有两条判据,都对应【用户换过环境】这一件事:
//   · openai 路由 —— 那个端点还在不在 config.providers 里。删掉端点后再开新线程必须回落,
//     否则新线程一开口就撞 10 的「会话绑定的 Provider 不可用」,用户完全不知道发生了什么;
//   · agent 路由 —— 那个 CLI 还检不检得到。判据【复用】01 的 selectedAgentCli(它同时看用户手填
//     的路径与探测结果,且带缓存),不另写第二套探测 —— 第二套判据迟早与第一套判出不同答案。
function lastUsedEngineRouteUsable(route, config) {
  if (!route) return false;
  if (route.engine === 'openai') {
    return ((config && config.providers) || []).some(item => item && item.id === route.providerId);
  }
  const cli = selectedAgentCli({ ...(config || {}), agentCliType: route.agentCliType });
  return Boolean(cli && cli.path);
}

// 读:新线程的缺省引擎。优先级固定四层,**第三层是本波新增的那一层**,上下两层一字未动:
//   ① 显式入参 engineRoute(POST /api/sessions 的请求体带的,或进程内调用方指定的)——
//      「这一条线程就要这个」压过一切;
//   ② 从导入进来的消息里推断 —— 导入历史对话时沿用它原来的引擎(既有行为);
//   ③ newThreadEngine === 'last' 且 lastUsedEngineRoute 【仍可用】→ 用它(本波新增);
//   ④ 全局设置 —— 老行为,同时也是 ③ 的回落去处。
// ③ 因「不可用」回落到 ④ 时必须留痕:用户明明设了「跟上次用的」却拿到别的引擎,不记一条
// 审计事件就无从解释。**「还没有上一次」不算回落**(那是首次使用,不记)。
function newSessionEngineRoute(config, explicitRoute, initialMessages, sessionId) {
  const explicit = normalizeSessionEngineRoute(explicitRoute);
  if (explicit) return explicit;
  const inferred = inferSessionEngineRoute({ messages: initialMessages });
  if (inferred) return inferred;
  const fromGlobal = sessionEngineRouteFromConfig(config);
  if (!config || config.newThreadEngine !== 'last') return fromGlobal;
  const last = normalizeSessionEngineRoute(config.lastUsedEngineRoute);
  if (!last) return fromGlobal;
  if (lastUsedEngineRouteUsable(last, config)) return last;
  logEvent({
    kind: 'new_thread_engine_fallback',
    sessionId: String(sessionId || ''),
    reason: last.engine === 'openai' ? 'provider_missing' : 'agent_cli_missing',
    last,
    to: fromGlobal,
  });
  return fromGlobal;
}

// v0.8-S0: fold an older/partial session onto the current schema. Mirrors normalizeConfig's shape:
// returns { session, changed }. Backfills schemaVersion + turnSeq and guarantees the array fields so
// no downstream code has to defend against missing/typo'd properties.
function normalizeSession(raw) {
  const session = (raw && typeof raw === 'object') ? raw : {};
  let changed = false;
  if (session.schemaVersion !== SESSION_SCHEMA) { session.schemaVersion = SESSION_SCHEMA; changed = true; }
  // turnSeq is the session-level monotonic turn counter (checkpoint/rewind/summary primary key). Old
  // sessions predate it → backfill 0. A non-finite value is treated as absent.
  if (!Number.isFinite(session.turnSeq)) { session.turnSeq = 0; changed = true; }
  if (!Array.isArray(session.messages)) { session.messages = []; changed = true; }
  if (!Array.isArray(session.providerHistory)) { session.providerHistory = []; changed = true; }
  // Cursor into display `messages` that has already been mirrored into providerHistory. It is optional on
  // legacy sessions; runOpenAiTurn derives a safe migration point before the first new Provider turn.
  if (session.providerHistoryCursor !== undefined &&
      (!Number.isInteger(session.providerHistoryCursor) || session.providerHistoryCursor < 0)) {
    delete session.providerHistoryCursor;
    changed = true;
  }
  if (!Array.isArray(session.attachments)) { session.attachments = []; changed = true; }
  {
    const route = inferSessionEngineRoute(session);
    if (route && JSON.stringify(route) !== JSON.stringify(session.engineRoute)) { session.engineRoute = route; changed = true; }
    else if (!route && session.engineRoute !== undefined) { delete session.engineRoute; changed = true; }
  }
  // 116-2a: 会话级权限档(session.permissionMode)是【可选】字段,这里【刻意不做任何归一】——
  //   ① 缺省不写就是「跟随全局」,回填默认值 = 给全部存量会话做一次破坏性批量重写(与 `kind` 同纪律),
  //      而且从此分不清「这条线程自己定了档」与「跟着全局走」;
  //   ② 也不删非白名单值:管家会话的头上正是一个不在 PERMISSION_MODES 里的独立值 'steward'(116f),
  //      在这里做白名单清洗会把它抹掉。野值本身无害 —— 读侧(sessionPermissionModeOf/
  //      resolvePermissionMode)一律只认白名单,不合法就当没设、回落下一层。
  // v0.8-S3: todo list (TodoWrite). Old sessions predate it → backfill empty array.
  if (!Array.isArray(session.todos)) { session.todos = []; changed = true; }
  // 第26波b: 任务账本(MissionSpec)。默认 null(无任务)。旧会话无此键 → 保持 null。
  if (session.mission !== null && session.mission !== undefined && typeof session.mission !== 'object') { session.mission = null; changed = true; }
  if (session.mission === undefined) { session.mission = null; changed = true; }
  // v1 技能体系: 会话启用的技能数组(上限 8)。P2-2: 元素为 {id, source} 对象 —— source 锁定「启用当时的注册表
  // 来源」(builtin/user/project),据此在解析时校验来源未被调包(防换 cwd 后同 id 项目技能静默顶替内置技能)。
  // 向后兼容: 旧裸字符串 id 视为 {id, source:''}(source 空 = 宽松匹配一次),本次 normalize 即固化为对象结构。
  {
    const cleaned = [];
    const seenIds = new Set();
    for (const raw of (Array.isArray(session.skills) ? session.skills : [])) {
      let id = '', source = '';
      if (typeof raw === 'string') { id = raw.trim(); } // 旧裸字符串 → source 空(宽松,下次启用时才锁定来源)
      else if (raw && typeof raw === 'object') { id = String(raw.id || '').trim(); source = String(raw.source || '').trim(); }
      if (!SKILL_ID_RE.test(id) || seenIds.has(id)) continue;
      seenIds.add(id);
      cleaned.push({ id, source });
      if (cleaned.length >= 8) break;
    }
    if (JSON.stringify(cleaned) !== JSON.stringify(session.skills)) { session.skills = cleaned; changed = true; }
  }
  // 工作台记忆:memoriesExplicit=true 时 session.memories 是固定选择(上限由 memoryFixedSelectionMaxV1 配置,见 01c;
  // 此处是落盘清洗,取钳位上界 MEMORY_FIXED_SELECTION_HARD_MAX,具体按配置的截断在保存路由与注入侧做)；false 时项目+全局均进入
  // 默认相关性检索，session.memoryExclusions 保存当前会话在默认模式下明确排除的条目。
  {
    const cleaned = [];
    const seen = new Set();
    for (const raw of (Array.isArray(session.memories) ? session.memories : [])) {
      const id = String((raw && typeof raw === 'object' && raw.id) || '').trim();
      if (!SKILL_ID_RE.test(id)) continue;
      const scope = (raw && raw.scope === 'global') ? 'global' : 'project';
      const key = scope + ':' + id;
      if (seen.has(key)) continue;
      seen.add(key);
      // P3-3: 保留 project 条目启用时锁定的 projectKey(渐进迁移:旧数据无此字段→保持缺省=宽松匹配,下次经
      // POST /api/session/memories 固化;同 Skills P2-2 的 source 渐进迁移)。仅接受 16-hex 合法值,防脏字段注入。
      const entry = { id, scope };
      if (scope === 'project') { const pk = String((raw && raw.projectKey) || '').trim(); if (/^[a-f0-9]{16}$/.test(pk)) entry.projectKey = pk; }
      cleaned.push(entry);
      if (cleaned.length >= MEMORY_FIXED_SELECTION_HARD_MAX) break;
    }
    if (JSON.stringify(cleaned) !== JSON.stringify(session.memories)) { session.memories = cleaned; changed = true; }
    if (typeof session.memoriesExplicit !== 'boolean') { session.memoriesExplicit = false; changed = true; }
    const excluded = [];
    const excludedSeen = new Set();
    for (const raw of (Array.isArray(session.memoryExclusions) ? session.memoryExclusions : [])) {
      const id = String((raw && typeof raw === 'object' && raw.id) || '').trim();
      if (!SKILL_ID_RE.test(id)) continue;
      const scope = raw && raw.scope === 'global' ? 'global' : 'project';
      const key = scope + ':' + id;
      if (excludedSeen.has(key)) continue;
      excludedSeen.add(key);
      const entry = { id, scope };
      if (scope === 'project') { const pk = String((raw && raw.projectKey) || '').trim(); if (/^[a-f0-9]{16}$/.test(pk)) entry.projectKey = pk; }
      excluded.push(entry);
      if (excluded.length >= 256) break;
    }
    if (JSON.stringify(excluded) !== JSON.stringify(session.memoryExclusions)) { session.memoryExclusions = excluded; changed = true; }
  }
  return { session, changed };
}

// v0.8-S3: sanitize a todo_write items payload (full-replace semantics; the SAME normalizer is used by
// the provider-engine special-case, the /api/todo endpoint, and the generic toolCall path). Rules: array
// capped at 50 entries; text coerced to string and capped at 200 chars; status defaults to 'pending' when
// missing/invalid; id defaults to t1..tN when absent. Non-array input yields an empty list.
const TODO_MAX_ITEMS = 50;
const TODO_MAX_TEXT = 200;
// 状态同义词:模型多半带着 Claude Code TodoWrite 的习惯(status:'completed'、字段名 content),也常写成
// in-progress / DONE。修前这些一律落成 pending、文本落成空串 —— 计划条永远 0/N,「没做完就续」也跟着误判。
// 三个引擎(provider 闭包 / Kimi 桥 / 回环 /api/todo)都经这里,所以在数据层认一次就全覆盖。
function canonicalTodoStatus(raw) {
  const v = String(raw == null ? '' : raw).trim().toLowerCase().replace(/[\s-]+/g, '_');
  if (v === 'done' || v === 'completed' || v === 'complete' || v === 'finished' || v === 'success' || v === 'succeeded') return 'done';
  if (v === 'in_progress' || v === 'inprogress' || v === 'doing' || v === 'active' || v === 'running' || v === 'started') return 'in_progress';
  if (v === 'blocked') return 'blocked';
  return v === 'pending' || v === 'todo' || v === 'not_started' || v === 'open' || v === '' ? 'pending' : '';
}
// todo_write 入参的同义词归一(分发前的 schema 校验之前用,13f 只认 text/三种状态):content/title/activeForm → text,
// 状态同义词 → 规范值,纯字符串条目 → {text}。不认识的状态原样留着,让校验报出允许值。
function normalizeTodoWriteArgs(args) {
  if (!args || typeof args !== 'object' || !Array.isArray(args.items)) return args;
  return { ...args, items: args.items.map(it => {
    if (typeof it === 'string') return { text: it };
    if (!it || typeof it !== 'object') return it;
    const o = { ...it };
    if (o.text == null) { const alt = o.content != null ? o.content : (o.title != null ? o.title : o.activeForm); if (alt != null) o.text = alt; }
    if (o.status != null) { const c = canonicalTodoStatus(o.status); if (c && c !== 'blocked') o.status = c; }
    return o;
  }) };
}
// mission_update 的里程碑状态同理(13f 只认 pending/done/blocked;in-progress 一类在账本里就是 pending)。
function normalizeMissionUpdateArgs(args) {
  if (!args || typeof args !== 'object' || !Array.isArray(args.milestones)) return args;
  return { ...args, milestones: args.milestones.map(m => {
    if (!m || typeof m !== 'object' || m.status == null) return m;
    const c = canonicalTodoStatus(m.status);
    return c ? { ...m, status: c === 'in_progress' ? 'pending' : c } : m;
  }) };
}
// C2 scratchpad_write 的字段同义词(13f 只认 op/key/text,additionalProperties:false):content/note/value → text,
// name/title → key。只在规范字段缺席时补,补完把同义词拿掉(否则校验仍按多余字段拒)。
function normalizeScratchpadWriteArgs(args) {
  if (!args || typeof args !== 'object' || Array.isArray(args)) return args;
  const o = { ...args };
  for (const [canon, alts] of [['text', ['content', 'note', 'value']], ['key', ['name', 'title']]]) {
    for (const alt of alts) {
      if (!Object.prototype.hasOwnProperty.call(o, alt)) continue;
      if (o[canon] == null) o[canon] = o[alt];
      delete o[alt];
    }
  }
  return o;
}
// 分发前统一入口(12 toolCall 与 09 闭包特例共用)。
function normalizeMetaToolArgs(name, args) {
  if (name === 'todo_write') return normalizeTodoWriteArgs(args);
  if (name === 'mission_update') return normalizeMissionUpdateArgs(args);
  if (name === 'scratchpad_write') return normalizeScratchpadWriteArgs(args);
  return args;
}
function normalizeTodoItems(raw) {
  const arr = Array.isArray(raw) ? raw.slice(0, TODO_MAX_ITEMS) : [];
  return arr.map((it, i) => {
    const o = (it && typeof it === 'object') ? it : (typeof it === 'string' ? { text: it } : {});
    const canon = canonicalTodoStatus(o.status);
    const status = (canon === 'in_progress' || canon === 'done') ? canon : 'pending';
    const textRaw = o.text != null ? o.text : (o.content != null ? o.content : (o.title != null ? o.title : o.activeForm));
    const text = String(textRaw == null ? '' : textRaw).slice(0, TODO_MAX_TEXT);
    const id = (o.id != null && String(o.id).trim()) ? String(o.id).slice(0, 64) : `t${i + 1}`;
    return { id, text, status };
  });
}

// ============================================================================
// 第26波b(AUTONOMY-PLAN §26b):任务账本(MissionSpec)—— 长任务的「目标—验收—预算」权威状态,存 session.mission
// (随会话走,免疫压缩:账本不在 messages 里),驱动 until-done 续跑。规范器同款三路复用(工具/API/驱动器)。
//  · milestones[].check:机器可判定优先(command 跑进程判退出码/输出、file_exists 判文件在)、'none' 由模型自报;
//  · budget.maxAutoTurns:无人值守自动续跑硬上限;spent 累计;autoMode:off|until-done|supervised;
//  · stall:digest K 轮不变即停滞;replans:重规划次数(硬限)。
const MISSION_MAX_MILESTONES = 16;
const MISSION_MAX_TEXT = 400;
const MISSION_MAX_CONSTRAINTS = 12;
const MISSION_DEFAULT_MAX_TURNS = 12;
const MISSION_REPLAN_LIMIT = 2;
const MISSION_STALL_LIMIT = 3;
// 对抗轮 P1(第26波b): check.cmd 是【驱动器每轮无提示 shell 执行】的输入 —— 绝不能被【模型】设置,否则
// 提示注入 = 绕过整个权限系统的任意命令执行。`trusted` 门:仅用户(经 UI header token 的 /api/mission)可定义
// command 检查;不可信来源(模型 mission_update 工具 / body-token loopback)的 command 检查一律降级为 'none'。
// file_exists(纯 fsp.access 只读)风险低,但路径可越工作区探测,故也仅 trusted 可设 —— 不可信一律 'none'。
function normalizeMissionCheck(raw, trusted) {
  const o = (raw && typeof raw === 'object') ? raw : {};
  let type = (o.type === 'command' || o.type === 'file_exists') ? o.type : 'none';
  if (!trusted && type !== 'none') type = 'none'; // 不可信来源禁设任何机器检查(只能自报 status/evidence)
  const check = { type };
  if (type === 'command') { check.cmd = String(o.cmd == null ? '' : o.cmd).slice(0, 500); if (o.expect != null) check.expect = String(o.expect).slice(0, 200); }
  else if (type === 'file_exists') check.path = String(o.path == null ? '' : o.path).slice(0, 500);
  return check;
}
// ── 124-P1(40 号文 §2 ①):机器验收的【落章】与验收四态的【唯一】判据 ────────────────────
// 派单稿 §4 的裁决是「一个字段都不加,四态现算」,推导是:② 里 check.type!=='none' 且跑过 ⇒ 机器检查。
// 取证之后这条推导在【机器】那一档不成立,所以本刀只在这一处证伪它:机器检查的【定义权】确实只属于
// 可信来源(normalizeMissionCheck 的 trusted 门,本刀一个字不动),但里程碑的 status 模型改得动 ——
// applyMissionUpdate 只挡 done→pending(P3),不挡 pending→done。于是「用户定义了 check 的里程碑」
// 被模型一句 mission_update{status:'done'} 标完成时,按 check.type 推出来的标签会说「机器检查」,
// 而机器一次都没跑过 —— 那正是 41 号方案 §9 J08 要挡的谎(「产物生成但测试失败/文件随后缺失」
// 却声称验收通过)。「跑过没有、结果是什么」今天全仓没有任何地方落盘:driver 与 action:'check'
// 都只把 pass 的结果写进 evidence(自由文本,模型同样写得动),HTTP 回执里那份 results 不落盘。
// 故补一枚【只有机器写得了】的章:
//   · 写入口只有 recordMissionCheckResult 一个函数,调用点只有两处跑检查的地方(06e 驱动器每轮、
//     /api/mission action:'check');
//   · 任何输入侧都进不来 —— normalizeMission 只从 prev 深拷里按 id 捞,applyMissionUpdate 不认
//     uo.lastCheck,start 全量新建一律清空(新账本没有旧章);
//   · 于是「机器检查」这块牌子只可能由真跑过的机器挂上,模型与 loopback 都伪造不了。
function normalizeMissionLastCheck(raw) {
  const o = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : null;
  if (!o) return null;
  const at = String(o.at == null ? '' : o.at).slice(0, 40);
  if (!at) return null;   // 没有时间 = 不是章(J08:宁可说「没跑过」,不许说一个说不出时间的「通过」)
  return { at, pass: o.pass === true, detail: String(o.detail == null ? '' : o.detail).slice(0, 200) };
}
// 机器验收结果的【唯一】写入口(静态锁 acceptance-provenance.e2e.js 按「全仓只有这里写 lastCheck」钉)。
// 不 pass 的结果同样落章:J08 要的是「显示实际验证状态」,一次失败的检查比没有检查更该被说出来。
function recordMissionCheckResult(milestone, result) {
  if (!milestone || typeof milestone !== 'object' || !result || typeof result !== 'object') return false;
  milestone.lastCheck = normalizeMissionLastCheck({ at: nowIso(), pass: result.pass === true, detail: result.detail });
  return true;
}
// trusted 默认 true:内部深拷(applyMissionUpdate 的 normalizeMission({}, prev))必须原样保留 prev 里【已在可信
// 来源校验过】的检查;仅当里程碑来自【新输入 o.milestones】时才按调用方 trusted 门控(见 fromRaw 判定)。
function normalizeMission(raw, prev, trusted = true) {
  if (raw === null) return null; // 显式清空
  const o = (raw && typeof raw === 'object') ? raw : {};
  const p = (prev && typeof prev === 'object') ? prev : {};
  const goal = String(o.goal != null ? o.goal : (p.goal || '')).slice(0, 2000);
  const fromRaw = Array.isArray(o.milestones);
  const rawMs = fromRaw ? o.milestones : (Array.isArray(p.milestones) ? p.milestones : []);
  // 124-P1:机器验收的章只从【prev】按 id 捞 —— 深拷那条路 mo 本身就是 prev 的里程碑(原样带走),
  // 新输入那条路(start / 全量替换)一律查 prev,查不到就是没有章。输入里带 lastCheck 的一律无视:
  // 这个字段不是输入面的东西(见 recordMissionCheckResult 的头注)。
  const prevMilestoneById = new Map((Array.isArray(p.milestones) ? p.milestones : [])
    .map(item => [String((item && item.id) || ''), item]));
  const seen = new Set();
  const milestones = rawMs.slice(0, MISSION_MAX_MILESTONES).map((m, i) => {
    const mo = (m && typeof m === 'object') ? m : {};
    let id = (mo.id != null && String(mo.id).trim()) ? String(mo.id).trim().slice(0, 64) : `m${i + 1}`;
    while (seen.has(id)) id = id + '_'; seen.add(id);
    const status = (mo.status === 'done' || mo.status === 'blocked') ? mo.status : 'pending';
    const rawDesc = String(mo.desc == null ? '' : mo.desc).slice(0, MISSION_MAX_TEXT);
    const desc = (id === 'delivery' && rawDesc.trim() === goal.trim())
      ? followupAcceptanceCriterion(rawDesc, false)
      : (/^followup_/.test(id) ? followupAcceptanceCriterion(rawDesc, true) : rawDesc);
    // 新输入的 check 按 trusted 门控;prev 深拷的 check 视为已可信(原样保留)。
    const lastCheck = normalizeMissionLastCheck(fromRaw ? ((prevMilestoneById.get(id) || {}).lastCheck) : mo.lastCheck);
    return { id, desc, status, check: normalizeMissionCheck(mo.check, fromRaw ? trusted : true), evidence: mo.evidence ? String(mo.evidence).slice(0, MISSION_MAX_TEXT) : '', ...(lastCheck ? { lastCheck } : {}) };
  });
  const budgetIn = (o.budget && typeof o.budget === 'object') ? o.budget : (p.budget || {});
  const maxAutoTurns = Math.max(1, Math.min(50, Math.round(Number(budgetIn.maxAutoTurns) || MISSION_DEFAULT_MAX_TURNS)));
  const spentIn = (p.spent && typeof p.spent === 'object') ? p.spent : {};
  const autoMode = ['off', 'until-done', 'supervised'].includes(o.autoMode) ? o.autoMode : (['off', 'until-done', 'supervised'].includes(p.autoMode) ? p.autoMode : 'off');
  return {
    goal,
    milestones,
    constraints: (Array.isArray(o.constraints) ? o.constraints : (Array.isArray(p.constraints) ? p.constraints : [])).slice(0, MISSION_MAX_CONSTRAINTS).map(c => String(c || '').slice(0, MISSION_MAX_TEXT)).filter(Boolean),
    budget: { maxAutoTurns, maxTokens: Number.isFinite(Number(budgetIn.maxTokens)) ? Math.max(0, Math.round(Number(budgetIn.maxTokens))) : 0 },
    spent: { autoTurns: Math.max(0, Number(spentIn.autoTurns) || 0), tokens: Math.max(0, Number(spentIn.tokens) || 0) },
    autoMode,
    stall: { lastDigest: String((p.stall && p.stall.lastDigest) || ''), sameCount: Math.max(0, Number(p.stall && p.stall.sameCount) || 0) },
    replans: Math.max(0, Number(p.replans) || 0),
    // 对抗轮 P2(#6): 保留 budgetExhaustedAt —— 它是"本任务预算已耗尽并记过账"的持久标记,update 再武装(prev 深拷)
    // 必须保住它,否则再耗尽会二次落 mission_budget_exhausted 使超支率 >100%;全新 start(prev=null → p={})自然清空,
    // 新任务的耗尽正常重记。budget 无法经 update 抬高(applyMissionUpdate 不碰 budget),故不需"抬预算才清"的额外逻辑。
    budgetExhaustedAt: String(p.budgetExhaustedAt || ''),
    // 第84波:Mission 的第一回合游标。整单回退必须回到「任务开始前」而不是猜整个会话的第 1 回合；
    // 老会话没有该字段时只在 missionRollbackTarget 中基于真实消息/检查点保守推导，绝不盲回到 1。
    startedTurnSeq: Math.max(0, Number(p.startedTurnSeq) || Number(o.startedTurnSeq) || 0),
    // 75a-2b (S3): Mission-level persistent monotone change sequence. turn/run/Intervention/预算/result/
    // rewind/删除 all advance it (75a-2b wires Intervention transitions; broader wiring lands with each
    // subsystem). Deep-copy preserved (same as budgetExhaustedAt); legacy sessions derive start value 0.
    changeSeq: Math.max(0, Number(p.changeSeq) || 0),
    // 第72波:任务结果快照(终态时由 maybeFinalizeMission 盖章;再武装由它清理)。深拷必须携带,
    // 否则每次 applyMissionUpdate(normalizeMission({}, prev))都把已盖章的结果静默抹掉。
    result: (p.result && typeof p.result === 'object') ? p.result : null,
    // 历史轮次验收报告归档:next_turn/retry/rollback/再武装/盖新章前把旧 result 推入,有界 last 10。
    // 深拷同样必须携带,否则 applyMissionUpdate 会把历史轮次静默抹掉(同 result 的再武装坑)。
    resultHistory: Array.isArray(p.resultHistory) ? p.resultHistory.slice(-10) : [],
    createdAt: p.createdAt || nowIso(),
    updatedAt: nowIso(),
  };
}
// 第26波b: 增量更新账本(mission_update 工具 / API update)—— 按 id 【合并】里程碑,不整表替换。
// 已存在的 id → 更新 status/evidence/desc(只更新提供的字段);新 id → 追加(受 16 上限);goal 提供才改。
// 关键:与 normalizeMission(full-replace,用于 start)语义相反 —— 模型只报"m2 done"时不能抹掉 m1/m3。
// trusted:是否可信来源(用户经 UI header token)。不可信(模型 mission_update / body-token loopback)时:
//  ① 不得设置/修改任何机器 check(P1 关键——防模型注入 check.cmd 让驱动器无提示 shell 执行);
//  ② 不得把已 done 的里程碑回退为 pending(P3——防模型靠 done→pending 抖动无限拖住 until-done 循环)。
function applyMissionUpdate(prev, patch, trusted = false) {
  if (!prev) return prev;
  const p = (patch && typeof patch === 'object') ? patch : {};
  const next = normalizeMission({}, prev); // 深拷现有(经规范化;prev 的 check 视为已可信,原样保留)
  if (p.goal != null) next.goal = String(p.goal).slice(0, 2000);
  const ups = Array.isArray(p.milestones) ? p.milestones : [];
  const byId = new Map(next.milestones.map(m => [m.id, m]));
  for (const u of ups) {
    const uo = (u && typeof u === 'object') ? u : {};
    const id = String(uo.id || '').trim().slice(0, 64);
    if (!id) continue;
    const existing = byId.get(id);
    if (existing) {
      const uoStatus = canonicalTodoStatus(uo.status);   // completed / in-progress 等同义词(见 canonicalTodoStatus)
      if (uoStatus === 'done' || uoStatus === 'blocked' || uoStatus === 'pending') {
        // 对抗轮 P3: 不可信来源不得把 done 回退为 pending/blocked(防抖动拖住循环);pending↔blocked、→done 允许。
        if (!(existing.status === 'done' && uoStatus !== 'done' && !trusted)) existing.status = uoStatus;
      }
      if (uo.desc != null) existing.desc = String(uo.desc).slice(0, MISSION_MAX_TEXT);
      if (uo.evidence != null) existing.evidence = String(uo.evidence).slice(0, MISSION_MAX_TEXT);
      // 对抗轮 P1: check 仅 trusted(用户 UI)可改;不可信(模型/loopback)的 uo.check 一律忽略 —— 保留原检查。
      if (uo.check && trusted) existing.check = normalizeMissionCheck(uo.check, true);
    } else if (next.milestones.length < MISSION_MAX_MILESTONES) {
      // 新里程碑的 check 同样按 trusted 门控:模型新增里程碑不能自带机器检查(降级 'none')。
      const nm = { id, desc: String(uo.desc || '').slice(0, MISSION_MAX_TEXT), status: (canonicalTodoStatus(uo.status) === 'done' || canonicalTodoStatus(uo.status) === 'blocked') ? canonicalTodoStatus(uo.status) : 'pending', check: normalizeMissionCheck(uo.check, trusted), evidence: uo.evidence ? String(uo.evidence).slice(0, MISSION_MAX_TEXT) : '' };
      next.milestones.push(nm); byId.set(id, nm);
    }
  }
  next.updatedAt = nowIso();
  return next;
}
// 账本进度指纹(停滞检测用)。对抗轮 P3: 除 status 外并入 evidence 长度桶 —— 一个粗粒度大里程碑上模型持续
// 工作、经 mission_update 更新 evidence 但尚未翻 status,也算「有进展」不误判停滞;真正原地打转(账本零变化)
// 才连续 K 轮同指纹触发降级。桶而非全文,避免 evidence 微小抖动被当进展(仍需实质增长才换桶)。
function missionProgressDigest(mission) {
  if (!mission || !Array.isArray(mission.milestones)) return '';
  return mission.milestones.map(m => m.id + ':' + m.status + ':' + Math.floor(String(m.evidence || '').length / 20)).join(' ');
}

// ── 124-P1:验收只读投影(三套数据面接起来,零改写) ────────────────────────────────────────
// 今天「验收」有三套数据面各写各的(40 号文 §1):① 事项容器验收项(唯一写入口是 13d 那条 UI token
// 的 PATCH —— 勾上 = 人工复核)、② 会话账本里程碑(模型自报 status / 机器落章)、③ 结果快照。
// 本函数【只读】前两套,把「这条是谁判的」算出来给界面,一处判据,谁都不回写谁:
//   · 'machine' 自报完成之外的唯一一档:有可信机器检查【且】有通过的章(recordMissionCheckResult);
//   · 'self'    模型/用户在账本上标的 done —— 带 checkState 说清「有检查但没跑过/没通过」(J08);
//   · 'human'   事项容器里用户亲手勾的那一条;
//   · 'open'    还没完成。
// 「这条线程有没有账本」用的是【与 06i ledgerless 同一条判据】(会话头有没有 mission 容器),
// 不是 milestones.length —— 后者会把「立了单还没定里程碑」的 2.0 任务单误判成无账本线程。
function missionAcceptanceItemView(milestone, humanCheckedTexts) {
  const m = (milestone && typeof milestone === 'object') ? milestone : {};
  const status = (m.status === 'done' || m.status === 'blocked') ? m.status : 'pending';
  const checkType = (m.check && m.check.type) || 'none';
  const stamp = normalizeMissionLastCheck(m.lastCheck);
  const machine = status === 'done' && checkType !== 'none' && !!stamp && stamp.pass === true;
  // 「人工复核」这一档是【接】出来的,不是猜的:事项容器里有一条【逐字同文】且用户已勾的验收项 ——
  // 那条勾只可能出自 13d 那条 UI header token 的 PATCH(全仓唯一写入口),所以它是真人看过的证据。
  // 文本逐字相等才算,不做模糊匹配:宁可这条牌子少出现一次,不许把两条不同的验收当成一条。
  const humanChecked = status === 'done' && !!(humanCheckedTexts && humanCheckedTexts.has(String(m.desc || '').trim()));
  return {
    id: m.id, desc: m.desc, status, checkType, evidence: m.evidence || '',
    // 强弱序 machine > human > self:三者都可能同时为真,牌子只印最硬的那一份证据。
    provenance: status === 'done' ? (machine ? 'machine' : (humanChecked ? 'human' : 'self')) : 'open',
    // 机器检查这一格的实情:没有检查 / 有检查但一次没跑过 / 最近一次通过 / 最近一次没通过。
    checkState: checkType === 'none' ? 'none' : (!stamp ? 'never' : (stamp.pass ? 'pass' : 'fail')),
    checkedAt: stamp ? stamp.at : '',
    checkDetail: stamp ? stamp.detail : '',
  };
}
// 事项容器里【与验收有关的那部分】的指纹。给详情 ETag 用:容器是另一份文件,它变了不会动会话
// 投影的 revision —— 不把它写进 ETag,勾完验收项再带 If-None-Match 来读就会拿到 304 + 陈旧验收
// (与 /api/missions 列表当年那条教训同一个模具,见 buildMissionAggregateRows 的 stamp 注释)。
function missionContainerAcceptanceStamp(container) {
  if (!container || typeof container !== 'object') return '-';
  const rows = Array.isArray(container.acceptance) ? container.acceptance : [];
  return String(container.updatedAt || '') + ':' + rows.length + ':'
    + rows.map(row => String((row && row.id) || '') + ((row && row.done) ? '1' : '0')).join(',').slice(0, 400);
}
function buildMissionAcceptanceProjection(mission, container) {
  const ledger = !!(mission && typeof mission === 'object');
  const ms = (ledger && Array.isArray(mission.milestones)) ? mission.milestones : [];
  const rows = (container && Array.isArray(container.acceptance)) ? container.acceptance : [];
  const humanCheckedTexts = new Set(rows
    .filter(row => row && row.done === true)
    .map(row => String((row && row.text) || '').trim())
    .filter(Boolean));
  const items = ms.map(milestone => missionAcceptanceItemView(milestone, humanCheckedTexts));
  // 同一句话在两套面上各写一遍是常态(事项验收项与账本里程碑本来就可能同文案),界面不印两遍:
  // 判据是去掉首尾空白后的文本逐字相等 —— 不做模糊匹配(宁可多印一条,不许悄悄合并两条不同的验收)。
  const ledgerTexts = new Set(items.map(item => String(item.desc || '').trim()).filter(Boolean));
  const containerItems = rows.map(row => {
    const text = String((row && row.text) || '');
    return {
      id: String((row && row.id) || ''), text, done: !!(row && row.done === true),
      doneAt: String((row && row.doneAt) || ''), provenance: 'human',
      duplicate: !!text.trim() && ledgerTexts.has(text.trim()),
    };
  });
  const extra = containerItems.filter(row => !row.duplicate);
  const byProvenance = { machine: 0, self: 0, human: 0, open: 0 };
  for (const item of items) byProvenance[item.provenance] += 1;
  for (const row of extra) byProvenance[row.done ? 'human' : 'open'] += 1;
  const done = items.filter(item => item.status === 'done').length;
  // 界面上画的是哪几条,a/b 就数哪几条(merged):
  //   · 线程有自己的账本 → 数账本(事项级验收项是【整个事项】的,挂到每条线程上会一份账印好几遍);
  //   · 线程没有账本 → 退到事项级那一套 —— 这正是 40 号文 §1 结论 3 那种「普通线程问不出答案」的处境:
  //     此前它只能说「暂无」,现在至少说得出「这个事项定了 N 条,你勾过 M 条」。
  return {
    // 既有五个键的形状与口径一个字不动(消费者:抽屉验收块、mission-state.js fromSnapshot、既有 e2e)。
    total: ms.length,
    done,
    blocked: items.filter(item => item.status === 'blocked').length,
    pending: items.filter(item => item.status === 'pending').length,
    items,
    // 124-P1 新增的只读投影:
    ledger,
    container: container ? { total: containerItems.length, done: containerItems.filter(row => row.done).length, items: containerItems } : null,
    merged: ledger
      ? { total: items.length, done }
      : { total: containerItems.length, done: containerItems.filter(row => row.done).length },
    byProvenance,
  };
}

// ── 第72波(EC-E 切片三):任务结果模型 ─────────────────────────────────────────────────────
// 跨回合 turnSummary 折叠(单一实现,13d /api/missions 详情与本波 buildMissionResult 共用):
// filesChanged 按 path 后写胜(最新 op/revertible 为当前态),artifacts 按 path 先去重(首次产出记回合),
// irreversible 逐条拼接(回合序),legacyCommands = 第72波前旧回合(无 irreversible 字段)的 commands 计数 ——
// 旧回合的不可逆操作只有计数没有明细,诚实单列,不混进新账假装有据。
function foldTurnSummaries(session) {
  const filesChanged = new Map(), artifacts = new Map();
  const irreversible = [];
  let commands = 0, legacyCommands = 0;
  let irreversibleIncomplete = false;
  for (const msg of ((session && session.messages) || [])) {
    const ts = msg && msg.turnSummary;
    if (!ts) continue;
    irreversibleIncomplete ||= ts.irreversibleIncomplete === true;
    for (const f of (ts.filesChanged || [])) {
      if (f && f.path) filesChanged.set(f.path, { path: f.path, op: f.op || '', revertible: f.revertible === true, turnSeq: ts.turnSeq, entrySeq: f.entrySeq });
    }
    for (const a of (ts.artifacts || [])) {
      if (a && a.path && !artifacts.has(a.path)) artifacts.set(a.path, { path: a.path, kind: a.kind || '', turnSeq: ts.turnSeq });
    }
    commands += (ts.commands || []).length || Number(ts.commands) || 0;
    if (Array.isArray(ts.irreversible)) {
      if (irreversible.length + ts.irreversible.length > 200) irreversibleIncomplete = true;
      for (const iv of ts.irreversible) {
        if (iv && iv.name && irreversible.length < 200) irreversible.push({ turnSeq: ts.turnSeq, kind: iv.kind || 'exec', name: String(iv.name), detail: String(iv.detail || ''), ok: iv.effectStatus === 'unknown' ? false : iv.ok !== false, ...irreversibleEntryMetadata(iv) });
      }
    } else {
      legacyCommands += (ts.commands || []).length || Number(ts.commands) || 0;
    }
  }
  const byKind = {};
  for (const iv of irreversible) byKind[iv.kind] = (byKind[iv.kind] || 0) + 1;
  return {
    filesChanged: [...filesChanged.values()], artifacts: [...artifacts.values()], commands,
    irreversible: { total: irreversible.length, byKind, items: irreversible, legacyCommands, ...(irreversibleIncomplete ? { incomplete: true } : {}) },
  };
}
// 任务结果快照(EC-E 立项:验收状态 + 成果引用 + 未完成项 + 变更摘要 + 真实回滚能力 + 不可逆显式标注)。
// 终态盖章时现算并持久化进 mission.result —— 盖章时刻的数字是历史证据,不随后续回合漂移。
async function buildMissionResult(session, opts) {
  const o = (opts && typeof opts === 'object') ? opts : {};
  const m = session.mission;
  const ms = (m && Array.isArray(m.milestones)) ? m.milestones : [];
  const fold = foldTurnSummaries(session);
  const cpEntries = await journalReadIndex(session.id).catch(() => []);
  const cpTurnSeqs = [...new Set(cpEntries.map(e => e && e.turnSeq).filter(Number.isFinite))].sort((a, b) => a - b);
  const byOp = {};
  for (const f of fold.filesChanged) byOp[f.op || 'unknown'] = (byOp[f.op || 'unknown'] || 0) + 1;
  // 交付成果正文:取本会话最后一条 assistant content(盖章时该消息已在 session.messages 内存)。
  // 随 result 持久化 + 下发,收工卡不再依赖 SSE 流到达时序;刷新读磁盘 result 已落盘,不截断当前输出。
  let deliverableText = '';
  const msgs = Array.isArray(session.messages) ? session.messages : [];
  for (let i = msgs.length - 1; i >= 0; i -= 1) {
    const msg = msgs[i];
    if (msg && msg.role === 'assistant' && typeof msg.content === 'string' && msg.content.trim()) {
      deliverableText = msg.content.slice(0, 16000);
      break;
    }
  }
  return {
    status: o.status === 'stopped' ? 'stopped' : 'complete',
    how: String(o.how || '').slice(0, 32),
    finishedAt: nowIso(),
    deliverableText,
    acceptance: {
      total: ms.length,
      done: ms.filter(x => x && x.status === 'done').length,
      blocked: ms.filter(x => x && x.status === 'blocked').length,
      pending: ms.filter(x => !x || x.status === 'pending').length,
    },
    unfinished: ms.filter(x => !x || x.status !== 'done').map(x => ({ id: x && x.id, desc: String((x && x.desc) || '').slice(0, 200), status: (x && x.status) || 'pending' })),
    todosOpen: ((session.todos) || []).filter(t => t && t.status !== 'done').length,
    artifacts: fold.artifacts.slice(0, 50),
    usage: {
      autoTurns: Math.max(0, Number(m && m.spent && m.spent.autoTurns) || 0),
      tokens: Math.max(0, Number(m && m.spent && m.spent.tokens) || 0),
    },
    changes: {
      filesChanged: fold.filesChanged.length, byOp,
      irreversibleFiles: fold.filesChanged.filter(f => f.revertible !== true).length,
      commands: fold.commands,
    },
    checkpoints: { entries: cpEntries.length, turnSeqs: cpTurnSeqs.slice(0, 50), rollbackAvailable: cpEntries.length > 0 },
    audit: { commands: fold.commands, irreversible: fold.irreversible.total, checkpoints: cpEntries.length, openTodos: ((session.todos) || []).filter(t => t && t.status !== 'done').length },
    irreversible: { total: fold.irreversible.total, byKind: fold.irreversible.byKind, items: fold.irreversible.items.slice(-30), legacyCommands: fold.irreversible.legacyCommands, ...(fold.irreversible.incomplete ? { incomplete: true } : {}) },
  };
}
// 终态盖章/再武装清理。在【任何 mission 突变点】调用(/api/mission check/update、09 回合内 mission_update):
// 全部里程碑 done 且尚无 complete 章 → 盖章;否则有旧章 → 清理(再武装 = 结果不再是终态,章会撒谎)。
// 返回是否改变了 mission(调用方负责 saveSession)。stop 不走这里 —— 它直接盖 stopped 章(13-http-router)。
function archiveMissionResult(mission) {
  if (!mission || !mission.result) return;
  const history = Array.isArray(mission.resultHistory) ? mission.resultHistory.slice() : [];
  const archived = { ...mission.result };
  // 第97波:历史轮次保留完整 deliverableText,支持收工卡「在新窗口打开全文」;条数由 last 10 有界防膨胀。
  history.push(archived);
  if (history.length > 10) history.splice(0, history.length - 10);
  mission.resultHistory = history;
}

async function maybeFinalizeMission(session, how) {
  const m = session && session.mission;
  if (!m || !Array.isArray(m.milestones)) return false;
  const allDone = m.milestones.length > 0 && m.milestones.every(x => x && x.status === 'done');
  if (allDone) {
    if (m.result && m.result.status === 'complete') return false; // 已盖章,不重复
    archiveMissionResult(m); // 旧 stopped 章归档,再盖 complete
    m.result = await buildMissionResult(session, { status: 'complete', how });
    m.updatedAt = nowIso();
    return true;
  }
  if (m.result) { archiveMissionResult(m); m.result = null; m.updatedAt = nowIso(); return true; } // 再武装:归档旧章再清
  return false;
}

// A model can mark the last acceptance item done before it emits the final assistant text. In that case the
// route has already produced a complete result from the previous assistant message. Rebuild that provisional
// result once the current turn has appended its assistant message; do not archive it as a real prior round.
async function finalizeMissionAfterTurn(session, how) {
  const mission = session && session.mission;
  if (mission && mission.result && mission.result.status === 'complete') {
    mission.result = await buildMissionResult(session, { status: 'complete', how: how || mission.result.how || 'update' });
    mission.updatedAt = nowIso();
    return true;
  }
  return maybeFinalizeMission(session, how);
}

// ── 122-§2.4:回合收尾的【落盘前合并】(mission) ───────────────────────────────────────────
// 现象:管家开线程后立刻派第一回合,再 POST /api/mission {action:'start'};回合收尾一存,里程碑账本没了。
// 病根:/api/mission 落盘后只在 activeChildren.get(sessionId) 命中时才把 mission 同步进活回合内存(C4)。
// 而 09-workflow 从「路由 loadSession 出会话」到「activeChildren.set(reg)」之间隔着 providerHistory 同步、
// 配对/参数自愈、turnSeq 落盘、onTurnStart 钩子与 captureWorkspaceTurnBaseline —— 这一整段里到达的 start
// 已经落了盘,却谁也同步不进回合内存;回合收尾 saveSession(内存 session)把整份 mission 覆盖回「没有」。
// 修法(与 P2-3「skills/memories 的 pre-save disk-merge」同一形状,三个引擎共用本函数):落盘前重读磁盘,
//   ① 磁盘有账本而内存没有  → 以磁盘为准(顺带把 start 翻过的 kind:'mission' 接回来);
//   ② 同一本账本(createdAt 相同)且磁盘 changeSeq 更高 → 以磁盘为底,把本回合内存里的增量
//      (goal / 里程碑 status·desc·evidence)用 applyMissionUpdate 语义重放上去 —— provider 引擎的
//      mission_update 是 in-process 改内存的(09),不重放就把本回合的进度丢了;
//   ③ 其余情况(内存不比磁盘旧,或磁盘换了另一本账本而内存那本已被 start 顶替)保持现状/以磁盘为准。
// 返回是否改过 session.mission(仅供调用方判断,收尾流程不依赖)。
function mergeMissionBeforeSave(session, onDisk) {
  if (!session) return false;
  const disk = onDisk && onDisk.mission && typeof onDisk.mission === 'object' ? onDisk.mission : null;
  const mem = session.mission && typeof session.mission === 'object' ? session.mission : null;
  if (!disk) return false;                       // 磁盘没有账本 -> 内存说了算(与合并前逐字节等价)
  if (!mem) {                                    // ① 回合中途才被 start:整份接过来
    session.mission = disk;
    if (onDisk.kind === 'mission') session.kind = 'mission';
    return true;
  }
  const diskSeq = Number(disk.changeSeq) || 0;
  const memSeq = Number(mem.changeSeq) || 0;
  if (diskSeq <= memSeq) return false;           // ③ 内存不比磁盘旧
  if (String(disk.createdAt || '') !== String(mem.createdAt || '')) {
    // ③ 磁盘上已经是【另一本】账本(回合中途 start 全量新建):内存那本是被顶替的旧账,不许重放回去。
    session.mission = disk;
    if (onDisk.kind === 'mission') session.kind = 'mission';
    return true;
  }
  // ② 同一本账本:以磁盘为底重放内存增量。补丁里【只带】id/status/desc/evidence,绝不带 check ——
  // 机器验收的定义权只属于磁盘那一份(用户经 header token 设的)。trusted=false 是刻意的:它顺带挡住
  // 「磁盘刚把 m1 判 done(action:'check' / 用户 UI),内存里那份还是 pending」被重放成回退」。
  session.mission = applyMissionUpdate(disk, {
    goal: mem.goal,
    milestones: (Array.isArray(mem.milestones) ? mem.milestones : []).map(item => ({
      id: item && item.id, status: item && item.status, desc: item && item.desc, evidence: item && item.evidence,
    })),
  }, false);
  if (onDisk.kind === 'mission') session.kind = 'mission';
  return true;
}

// ── 第84波:Mission 控制面单一 command core ───────────────────────────────────────────────
// 74 波冻结语义在这里落成唯一状态机：pause/takeover 只停当前回合+驱动，stop 覆盖整单并请求停止
// 同 Mission 的所有活 Run；continue/retry 只再武装，真正的新 provider 回合由 UI 在用户点击后显式发起。
function missionRollbackTarget(session, checkpointEntries) {
  const mission = session && session.mission;
  const explicit = Number(mission && mission.startedTurnSeq);
  if (Number.isSafeInteger(explicit) && explicit > 0) return explicit;
  const missionStartedAt = Date.parse(String(mission && mission.createdAt || ''));
  if (!Number.isFinite(missionStartedAt)) return 0; // 旧数据边界不明时宁可不给整单回退，也不越界撤销前一项工作
  const candidates = [];
  for (const entry of (checkpointEntries || [])) {
    const seq = Number(entry && entry.turnSeq);
    const occurredAt = Date.parse(String(entry && entry.ts || ''));
    if (Number.isSafeInteger(seq) && seq > 0 && Number.isFinite(occurredAt) && occurredAt >= missionStartedAt - 1000) candidates.push(seq);
  }
  for (const message of ((session && session.messages) || [])) {
    const direct = Number(message && message.turnSeq);
    const summary = Number(message && message.turnSummary && message.turnSummary.turnSeq);
    const occurredAt = Date.parse(String(message && (message.createdAt || message.ts) || ''));
    if (!Number.isFinite(occurredAt) || occurredAt < missionStartedAt - 1000) continue;
    if (Number.isSafeInteger(direct) && direct > 0) candidates.push(direct);
    if (Number.isSafeInteger(summary) && summary > 0) candidates.push(summary);
  }
  return candidates.length ? Math.min(...candidates) : 0;
}

function missionBudgetRemaining(mission) {
  if (!mission) return false;
  const budget = mission.budget || {};
  const spent = mission.spent || {};
  if ((Number(spent.autoTurns) || 0) >= Math.max(1, Number(budget.maxAutoTurns) || MISSION_DEFAULT_MAX_TURNS)) return false;
  if ((Number(budget.maxTokens) || 0) > 0 && (Number(spent.tokens) || 0) >= Number(budget.maxTokens)) return false;
  return true;
}

// 117m-A3（审查报回）：控制面的【判据侧】要和【执行侧】看到同一个事实。
// missionControlCommand 已经会惰性补账本，但交办台的按钮是拿 GET /api/missions/:id 里的
// controls.actions 画的 —— 那一面走的是本函数，它七个动作都以 Boolean(mission) 开头，
// 于是「没账本的管家线程」七个按钮全灰、点都点不下去，执行侧的修复根本走不到。
// 这里给 kind==='mission' 且账本为空的会话一份【只读的空账本视图】（不落盘、不改会话），
// 让判据与惰性补出来的账本一致：在跑 -> 可暂停/可接管，不终态 -> 可停止；
// 需要里程碑/结果/检查点的那几个（继续、重试、回滚）自然仍然不可用。
// 非 mission 会话 mission 仍为 null，七个动作照旧全部不可用（普通对话没有任务控制面）。
const MISSION_EMPTY_LEDGER_VIEW = Object.freeze({ autoMode: 'off', milestones: [], result: null, budget: null, spent: null });
function missionControlView(session, opts = {}) {
  const mission = (session && session.mission)
    || (session && String(session.kind || '') === 'mission' ? MISSION_EMPTY_LEDGER_VIEW : null);
  const checkpointEntries = Array.isArray(opts.checkpointEntries) ? opts.checkpointEntries : [];
  const runs = Array.isArray(opts.runs) ? opts.runs : [];
  const activeTurn = Boolean(session && activeChildren.has(session.id));
  const liveRuns = runs.filter(run => run && (run.live === true || activeAgentRuns.has(run.id)));
  const terminal = Boolean(mission && mission.result);
  const milestones = mission && Array.isArray(mission.milestones) ? mission.milestones : [];
  const unfinished = milestones.some(item => !item || item.status !== 'done');
  const completed = milestones.length > 0 && !unfinished;
  // A completed autonomous Mission keeps its historical autoMode value. Treat
  // it as an armed driver only while the Mission is still unsettled; otherwise
  // an auto-completed task could never accept a user follow-up.
  const driverArmed = Boolean(mission && mission.autoMode === 'until-done' && !terminal && !completed);
  const followupCapacity = unfinished || milestones.length < MISSION_MAX_MILESTONES;
  const budgetRemaining = missionBudgetRemaining(mission);
  const rollbackTargetTurnSeq = missionRollbackTarget(session, checkpointEntries);
  const action = (enabled, scope, reason = '') => ({ enabled: Boolean(enabled), scope, reason: enabled ? '' : reason });
  return {
    activeTurn, liveRuns: liveRuns.length, terminal, unfinished, budgetRemaining,
    rollbackTargetTurnSeq,
    actions: {
      pause: action(Boolean(mission) && !terminal && (activeTurn || mission.autoMode === 'until-done'), 'turn_driver', !mission ? 'mission_missing' : (terminal ? 'terminal' : 'already_paused')),
      continue: action(Boolean(mission) && !terminal && unfinished && !activeTurn && mission.autoMode !== 'until-done' && budgetRemaining,
        'turn_driver', terminal ? 'terminal' : (!unfinished ? 'complete' : (activeTurn ? 'turn_active' : (!budgetRemaining ? 'budget_exhausted' : 'already_running')))),
      stop: action(Boolean(mission) && !terminal, 'mission', terminal ? 'terminal' : 'mission_missing'),
      retry: action(Boolean(mission) && Boolean(mission.result) && mission.result.status === 'stopped' && unfinished && !activeTurn && budgetRemaining,
        'mission', !terminal ? 'not_terminal' : (mission.result && mission.result.status !== 'stopped' ? 'complete' : (activeTurn ? 'turn_active' : (!unfinished ? 'complete' : (!budgetRemaining ? 'budget_exhausted' : 'unavailable'))))),
      // 第95波:再开一回合 —— 任务已收工/已停工/预算内暂停后,用户追加新提示继续推进。
      // 与 retry 的区别:next_turn 不依赖 result.status===stopped,complete 也可用,且携带用户新提示。
      next_turn: action(Boolean(mission) && !activeTurn && liveRuns.length === 0 && !driverArmed && budgetRemaining && followupCapacity,
        'mission', activeTurn ? 'turn_active' : (liveRuns.length ? 'run_active' : (driverArmed ? 'already_running' : (!budgetRemaining ? 'budget_exhausted' : (!followupCapacity ? 'milestone_limit' : 'unavailable'))))),
      takeover: action(Boolean(mission) && !terminal && (activeTurn || mission.autoMode !== 'off'), 'turn_driver', !mission ? 'mission_missing' : (terminal ? 'terminal' : 'already_manual')),
      rollback: action(Boolean(mission) && rollbackTargetTurnSeq > 0 && checkpointEntries.length > 0 && !activeTurn && liveRuns.length === 0,
        'mission', activeTurn ? 'turn_active' : (liveRuns.length ? 'run_active' : (!rollbackTargetTurnSeq ? 'target_unknown' : 'no_checkpoints'))),
    },
  };
}

async function waitMissionTurnSettled(sessionId) {
  const settler = turnSettlers.get(sessionId);
  if (!settler || !settler.promise) return true;
  return Promise.race([settler.promise.then(() => true), new Promise(resolve => setTimeout(() => resolve(false), 8000))]);
}

async function stopMissionAgentRuns(sessionId) {
  let count = 0;
  const saves = [];
  for (const live of activeAgentRuns.values()) {
    if (!live || !live.run || live.run.sessionId !== sessionId || live.closing || live.stopRequested) continue;
    count++;
    live.stopRequested = true;
    live.paused = false;
    try { if (live.ctrl) live.ctrl.abort(); } catch { /* best-effort */ }
    const waiters = Array.isArray(live.resumeWaiters) ? live.resumeWaiters.splice(0) : [];
    for (const wake of waiters) { try { wake(); } catch { /* best-effort */ } }
    bumpRunIntervention(live.run, 'mission_stop');
    appendAgentRunEvent(live.run, { type: 'run_stop_requested', data: { reason: 'mission_stop' } });
    saves.push(saveAgentRun(live.run).catch(() => {}));
  }
  await Promise.all(saves);
  return count;
}

// 撤回(rewindSession)用:被丢弃回合里【模型自己起的】、仍在跑的后台 run 一并停掉 —— 起它的那句话对模型已经没发生过,跑完的信封只会让
// 下一回合凭空多出一份通知(并且唤醒会把改写过的线程叫醒)。停法与托盘 / mission 里停一件同一个(stopRequested + abort + 记干预 + 追事件),
// 并打 cancelledByRewind:09 deliverAgentRunEnvelope 据此不再给它投信封。用户在面板里自己起的 run 不动(不是被撤回的那句话起的);
// 起它的回合没被撤回的 run 也不动(照常跑完,信封随用户下一句话送达)。返回停掉的件数。同步,零 await。
function cancelModelRunsOfDiscardedTurns(sessionId, discardedTurnSeqs) {
  const discarded = discardedTurnSeqs instanceof Set ? discardedTurnSeqs : new Set(Array.isArray(discardedTurnSeqs) ? discardedTurnSeqs : []);
  let cancelled = 0;
  for (const live of activeAgentRuns.values()) {
    if (!live || !live.run || live.run.sessionId !== sessionId || live.closing || live.stopRequested) continue;
    if (live.run.launchedByModel !== true || !discarded.has(Number(live.run.turnSeq))) continue;
    try {
      live.run.cancelledByRewind = true;
      live.stopRequested = true;
      live.paused = false;
      try { if (live.ctrl) live.ctrl.abort(); } catch { /* best-effort */ }
      for (const wake of (Array.isArray(live.resumeWaiters) ? live.resumeWaiters.splice(0) : [])) { try { wake(); } catch { /* best-effort */ } }
      bumpRunIntervention(live.run, 'rewind_stop');
      appendAgentRunEvent(live.run, { type: 'run_stop_requested', data: { reason: 'rewind' } });
      saveAgentRun(live.run).catch(() => {});
      cancelled++;
    } catch { /* 停不掉也不挡撤回 */ }
  }
  if (cancelled) logEvent({ kind: 'rewind_cancel_agent_runs', sessionId, cancelled });
  return cancelled;
}

function missionControlFailure(reason, status = 409, message = '') {
  return { status, body: { ok: false, reason, error: message || reason } };
}

function followupAcceptanceCriterion(prompt, followup = true) {
  const source = String(prompt || '');
  const chinese = /[\u3400-\u9fff]/.test(source);
  if (/(?:分析|研究|调研|趋势|走势|比较|对比|报告|数据|市场|股票|美股|A股|research|analy[sz]e|trend|compare|market|stock)/i.test(source)) {
    return chinese
      ? (followup ? '追加结论覆盖新问题点名的对象与范围，并附有可核验的数据、事实或来源' : '结论直接回答目标问题、覆盖点名范围，并附有可核验的数据、事实或来源')
      : (followup ? 'The follow-up conclusions cover the newly named subjects and scope with verifiable data, facts, or sources' : 'The conclusions directly answer the goal, cover its named scope, and include verifiable data, facts, or sources');
  }
  if (/(?:实现|开发|修复|重构|代码|接口|页面|组件|测试|bug|fix|implement|refactor|code|api|ui|test)/i.test(source)) {
    return chinese
      ? (followup ? '追加改动符合新要求，并通过相关检查或测试且未引入无关行为变化' : '请求的改动按约定范围落地，通过相关检查或测试且未引入无关行为变化')
      : (followup ? 'The follow-up change meets the new requirements, passes relevant checks, and introduces no unrelated behavior changes' : 'The requested change is implemented within scope, passes relevant checks, and introduces no unrelated behavior changes');
  }
  return chinese
    ? (followup ? '追加结果完整回应新要求，并提供可核验的交付、事实或检查结果' : '最终结果完整回应任务目标，并提供可核验的交付、事实或检查结果')
    : (followup ? 'The follow-up result fully addresses the new request with a verifiable deliverable, fact, or check result' : 'The final result fully addresses the task goal with a verifiable deliverable, fact, or check result');
}

async function missionControlCommand(sessionId, rawAction, rawPrompt = '') {
  const action = String(rawAction || '').trim();
  const prompt = String(rawPrompt || '').trim();
  if (!['pause', 'continue', 'stop', 'retry', 'takeover', 'rollback', 'next_turn'].includes(action)) {
    return missionControlFailure('action_invalid', 400, 'unknown mission control action');
  }
  if (action === 'next_turn' && !prompt) {
    return missionControlFailure('prompt_required', 400, 'next_turn requires a prompt');
  }
  // 回合收尾的原子头文件换名窗口里，磁盘读可能短暂看不到头；活回合注册表持有同一权威 session，
  // 控制动作必须仍可送达，不能让用户在最需要 Pause 时撞瞬态 404。
  const registered = activeChildren.get(sessionId);
  let session = await loadSession(sessionId) || (registered && registered.session) || null;
  if (!session) return missionControlFailure('not_found', 404, 'session not found');
  // 117m-A3（用户第六轮走查④ 的同一个模具，第二处）：管家开的线程是 kind:'mission' 而
  // mission:null（steward_thread_new 只竖了 kind，从来不建账本）。修前这里一律 404 'mission not found'，
  // 于是交办台上的「暂停/停止/接管」对【每一条管家开的线程】都失败，而用户看到的只是一句 404。
  // 账本改成【惰性建】：真要用到它时就地补一份最小账本（goal 取会话标题、里程碑为空），然后走原路 ——
  // 不为一个 null 再写一套「没有账本时怎么办」的平行控制逻辑（下面整段都直接解引用 mission）。
  // 只对 kind==='mission' 的会话补：普通对话不会因为被调了一次控制面就升格成事项。
  // 补账本写成一个局部函数：下面 pause/stop/takeover 那一支会先 stopSession 再【从磁盘重读】会话，
  // 内存里刚补的账本会跟着没。117m-A6（审查报回 P0-2）：修前只在入口补一次，重读后
  // `mission.autoMode = ...` 就对 null 赋值抛 TypeError —— 而那正是本波要修的最典型场景
  //（暂停一条【正在跑】的、还没账本的管家线程）：回合已经被真停掉，接口却报 500。
  const ensureMissionLedger = target => {
    if (!target || target.mission) return true;
    if (String(target.kind || '') !== 'mission') return false;
    target.mission = normalizeMission({ goal: String(target.title || '').slice(0, 2000) }, null);
    return true;
  };
  if (!session.mission) {
    if (!ensureMissionLedger(session)) return missionControlFailure('mission_missing', 404, 'mission not found');
    logEvent({ kind: 'mission_ledger_seeded', sessionId, action, source: 'mission_control' });
  }

  let cpEntries = await journalReadIndex(sessionId).catch(() => []);
  let runs = await listAgentRuns(sessionId).catch(() => []);
  let controls = missionControlView(session, { checkpointEntries: cpEntries, runs });
  const capability = controls.actions[action];
  if (!capability || !capability.enabled) return missionControlFailure(capability && capability.reason || 'unavailable');

  const mustStopTurn = ['pause', 'stop', 'takeover'].includes(action) && activeChildren.has(sessionId);
  if (mustStopTurn) {
    // 先改活回合持有的同一 Mission 引用，再中止 fetch/子进程。否则 dying turn 的当前轮 settler
    // resolve 后，until-done driver 可能在控制路由落盘前抢先开启下一轮，Pause 响应仍显示 activeTurn。
    const liveTurn = activeChildren.get(sessionId);
    if (liveTurn && liveTurn.session && liveTurn.session.mission) {
      liveTurn.session.mission.autoMode = action === 'pause' ? 'supervised' : 'off';
      liveTurn.session.mission.updatedAt = nowIso();
    }
    stopSession(sessionId, `mission_${action}`);
    const settled = await waitMissionTurnSettled(sessionId);
    if (!settled) logEvent({ kind: 'mission_control_settle_timeout', sessionId, action });
    session = await loadSession(sessionId) || session;
    // 重读回来的那份又是磁盘上的 mission:null，在这里再补一次（下面整段直接解引用 mission）。
    ensureMissionLedger(session);
  }

  let requiresTurn = false;
  let rollback = null;
  let stoppedRuns = 0;
  const mission = session.mission;
  if (action === 'pause') {
    mission.autoMode = 'supervised';
  } else if (action === 'continue') {
    mission.autoMode = 'until-done';
    mission.stall = { lastDigest: '', sameCount: 0 };
    requiresTurn = true;
  } else if (action === 'takeover') {
    mission.autoMode = 'off';
    try { revokeAllGrants(sessionId, 'mission-takeover'); } catch { /* best-effort */ }
  } else if (action === 'stop') {
    stoppedRuns = await stopMissionAgentRuns(sessionId);
    try { revokeAllGrants(sessionId, 'mission-stop'); } catch { /* best-effort */ }
    mission.autoMode = 'off';
    archiveMissionResult(mission); // 旧 complete 章归档,再盖 stopped
    mission.result = await buildMissionResult(session, { status: 'stopped', how: 'stop' });
  } else if (action === 'retry') {
    for (const item of mission.milestones || []) {
      if (item && item.status === 'blocked') { item.status = 'pending'; item.evidence = ''; }
    }
    archiveMissionResult(mission); // 旧 stopped 章归档
    mission.result = null;
    mission.autoMode = 'until-done';
    mission.stall = { lastDigest: '', sameCount: 0 };
    requiresTurn = true;
  } else if (action === 'next_turn') {
    // 第95波:再开一回合 —— 完成/停工/暂停后,用户追加新提示继续推进。
    // 用户消息和 turnSeq 仍只由随后唯一的 /api/chat/stream 写入；控制面若也预写会产生重复提示与跳号。
    // 已收工任务的旧里程碑全为 done，必须为追加目标建立新的 pending 验收项，否则下一次回合收尾会
    // 被 maybeFinalizeMission 立即重新盖 complete 章。停工/暂停任务已有未完项，只需用新提示继续推进。
    const milestones = Array.isArray(mission.milestones) ? mission.milestones : [];
    const allDone = milestones.length > 0 && milestones.every(item => item && item.status === 'done');
    if (allDone) {
      if (milestones.length >= MISSION_MAX_MILESTONES) {
        return missionControlFailure('milestone_limit', 409, 'mission milestone limit reached');
      }
      mission.milestones.push({
        id: makeId('accept_followup'), desc: followupAcceptanceCriterion(prompt).slice(0, MISSION_MAX_TEXT), status: 'pending',
        check: normalizeMissionCheck(null, true), evidence: '',
      });
    }
    archiveMissionResult(mission); // 旧 complete 章归档,新轮再盖
    mission.result = null;
    mission.autoMode = 'until-done';
    mission.stall = { lastDigest: '', sameCount: 0 };
    requiresTurn = true;
  } else if (action === 'rollback') {
    const targetTurnSeq = controls.rollbackTargetTurnSeq;
    rollback = await rewindSession(sessionId, targetTurnSeq, true);
    if (!rollback || !rollback.ok) return missionControlFailure('rollback_failed', 409, rollback && rollback.error || 'mission rollback failed');
    session = await loadSession(sessionId) || session;
    for (const item of session.mission.milestones || []) {
      if (!item) continue;
      item.status = 'pending';
      item.evidence = '';
    }
    archiveMissionResult(session.mission); // 归档回退前的终态章(rewindSession 不触碰 mission.result)
    session.mission.result = null;
    session.mission.autoMode = 'off';
    session.mission.stall = { lastDigest: '', sameCount: 0 };
  }
  session.mission.updatedAt = nowIso();
  // 128b(48 号文 §2-b):这一存修前是裸 saveSession —— 撤回落在 load 与 save 之间(中间还有停子代理、盖章这些慢活)时,
  // 账本改动被闸静默丢掉、下面照样记变更流水、回 ok:true。副作用(停回合、停子代理、撤授权、回退)都已经发生、
  // 不能重做;要落盘的只是「账本现在该是什么样」—— 撤回不动账本,所以把这份账本整份重放到新读的副本上。
  try { await saveSession(session, { throwIfStale: true, writer: 'mission_control' }); }
  catch (error) {
    if (!(error && error.code === 'SESSION_STALE_SAVE')) throw error;
    const intended = session.mission;
    let written;
    try { written = await mutateSession(sessionId, fresh => { fresh.mission = intended; }, { writer: 'mission_control_replay' }); }
    catch (replayError) {
      if (replayError && replayError.code === 'session.rewound_during_write') return missionControlFailure('rewound_during_write', 409, replayError.message);
      throw replayError;
    }
    if (!written.session) return missionControlFailure('not_found', 404, 'session not found');
    session = written.session;
  }
  const revision = await bumpMissionChangeSeq(sessionId, {
    type: action === 'stop' ? 'result' : 'progress',
    cursor: { action, ...(rollback ? { targetTurnSeq: controls.rollbackTargetTurnSeq } : {}) },
    detail: { status: session.mission.result && session.mission.result.status || '', autoMode: session.mission.autoMode, stoppedRuns, rollback: Boolean(rollback) },
  });
  if (revision) session.mission.changeSeq = revision;
  const reg = activeChildren.get(sessionId);
  if (reg && reg.session && reg.session !== session) reg.session.mission = session.mission;
  if (reg && reg.onEvent) { try { reg.onEvent({ type: 'mission', mission: session.mission }); } catch { /* stream gone */ } }

  cpEntries = await journalReadIndex(sessionId).catch(() => []);
  runs = await listAgentRuns(sessionId).catch(() => []);
  controls = missionControlView(session, { checkpointEntries: cpEntries, runs });
  return { status: 200, body: { ok: true, action, mission: session.mission, controls, requiresTurn, stoppedRuns, ...(rollback ? { rollback } : {}) } };
}
// 执行一条里程碑的机器验收(command 判退出码+可选输出包含;file_exists 判在)。'none' 返回 null(交模型自报)。
// 只读判定,不改文件;command 走工作区 cwd,复用 runProcess 基建;绝不用于副作用。
async function evaluateMissionCheck(check, cwd) {
  if (!check || check.type === 'none') return null;
  try {
    if (check.type === 'file_exists') {
      const p = path.resolve(cwd || '.', String(check.path || ''));
      // 对抗轮 P3: 限定在工作区内 —— file_exists 路径可为绝对/../ 穿越,即便只读(fsp.access)也是任意路径存在性
      // 探测(信息泄露)。仅当解析后落在 cwd 内才判定,越界一律「不适用」(不泄露)。
      const base = path.resolve(cwd || '.');
      if (p !== base && !p.startsWith(base + path.sep)) return { pass: false, detail: '路径超出工作区,已跳过验收' };
      try { await fsp.access(p); return { pass: true, detail: '文件存在: ' + check.path }; }
      catch { return { pass: false, detail: '文件不存在: ' + check.path }; }
    }
    if (check.type === 'command') {
      if (!String(check.cmd || '').trim()) return { pass: false, detail: '空命令' };
      // shell:true 让整条命令串按用户书写执行(判定性只读用途;超时 60s;工作区 cwd)。
      const r = await DesktopShell.runProcess(String(check.cmd), [], { timeoutMs: 60000, cwd: cwd || process.cwd(), shell: true }).catch(e => ({ code: -1, stdout: '', stderr: String(e && e.message || e) }));
      const out = String((r.stdout || '') + (r.stderr || ''));
      const codeOk = Number(r.code) === 0;
      const expectOk = check.expect ? out.includes(String(check.expect)) : true;
      return { pass: codeOk && expectOk, detail: `退出码=${r.code}${check.expect ? (expectOk ? ' · 命中期望' : ' · 未命中期望「' + check.expect + '」') : ''}` };
    }
  } catch (e) { return { pass: false, detail: '验收异常: ' + String(e && e.message || e).slice(0, 200) }; }
  return null;
}

// 110-3b: createTurnSegmentBuilder 回合分段构建器抽至 02c-turn-segments.js。

// v0.8-S3/S4a: derive a turn_summary from the turn's tool records + checkpoint journal. Both engines call
// this with their own toolCalls array (provider: {name,input,result}; claude: {name,input,result} where
// result is the raw MCP text) AND this turn's journal entries (index rows for this turnSeq). DATA SOURCE:
//  - journal entries (S4a) are the authoritative source for file changes: merged into filesChanged by
//    path, their `op` (create/modify/delete) is used (more accurate than the tool record's guess), and
//    they are `revertible:true` (skipped:true entries stay revertible:false — no `before` was stored);
//  - tool records supply files NOT covered by the journal (e.g. CLI-native tools) at revertible:false,
//    and the command count. When a path appears in BOTH, the journal entry wins.
//  Rules:
//  - file_write → op create/modify; file_edit → modify; file_delete → delete; path=input.path
//  - powershell_run/script_run/shell_send (and, for the claude engine, any non-workbench-file tool) → commands+1
//  - artifacts is always [] (field established for C4/v0.9).
// 架构还债批 3·B: 回合摘要的工具分类表(TURN_SUMMARY_*/ARTIFACT_OUTPUT_PATH_KEYS/桥接写族判定)与不可逆操作账分类(IRREVERSIBLE_*/irreversibleToolKind/irreversibleDetail)抽至 02f-turn-effect-kinds.js。
// v0.9-S4 (C4): classify an artifact by file-name suffix. img/md/csv/txt/html/xlsx/docx/pdf → distinct
// kinds (drive the gallery's per-kind preview branch); everything else → 'other'. Extension-only (no I/O).
const ARTIFACT_IMG_EXTS = new Set(['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg']);
function kindForPath(p) {
  const ext = String(path.extname(String(p || '')).replace(/^\./, '')).toLowerCase();
  if (ARTIFACT_IMG_EXTS.has(ext)) return 'img';
  if (ext === 'md' || ext === 'markdown') return 'md';
  if (ext === 'csv') return 'csv';
  if (ext === 'txt') return 'txt';
  if (ext === 'html' || ext === 'htm') return 'html';
  if (ext === 'xlsx') return 'xlsx';
  if (ext === 'docx') return 'docx';
  if (ext === 'pdf') return 'pdf';
  return 'other';
}
// Best-effort: coerce a tool result into a plain object. Handles (a) an object already; (b) a JSON string;
// (c) an MCP content array [{type:'text',text:'{...}'}] (the shape the Claude CLI reports for workbench
// tools) — parse the concatenated text as JSON. Returns null when nothing parses.
function asResultObject(result) {
  if (result == null) return null;
  if (Array.isArray(result)) {
    const text = result.map(p => (p && typeof p.text === 'string') ? p.text : '').join('');
    try { return JSON.parse(text); } catch { return null; }
  }
  if (typeof result === 'object') return result;
  if (typeof result === 'string') { try { return JSON.parse(result); } catch { return null; } }
  return null;
}
// A small result-derived ledger survives display shrinking. These are tool-reported effects,
// not a durable native dispatch receipt, nor proof that the target application accepted input.
// Never infer a macro's completed children from requested arguments (saved recordings may rewrite them).
const IRREVERSIBLE_COMPOUND_TOOLS = new Set(['macro_run', 'batch_actions']);
const IRREVERSIBLE_RESULT_TEXT_MAX = 2 * 1024 * 1024;
function irreversibleResultObject(result) {
  if (typeof result === 'string' && (result.length > IRREVERSIBLE_RESULT_TEXT_MAX || Buffer.byteLength(result, 'utf8') > IRREVERSIBLE_RESULT_TEXT_MAX)) return null;
  if (Array.isArray(result)) {
    if (result.length > 200) return null;
    let text = '', bytes = 0;
    for (const part of result.slice(0, 200)) {
      if (typeof part?.text !== 'string') continue;
      if (part.text.length > IRREVERSIBLE_RESULT_TEXT_MAX) return null;
      bytes += Buffer.byteLength(part.text, 'utf8');
      if (bytes > IRREVERSIBLE_RESULT_TEXT_MAX) return null;
      text += part.text;
    }
    try { return JSON.parse(text); } catch { return null; }
  }
  return asResultObject(result);
}
function irreversibleReportedState(bare, r, depth = 0) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return 'unknown';
  // Positive prefix evidence survives enclosing cancellation/failure. Contradictory receipts
  // remain unknown. action_sent:false on its own is not proof that no prefix ran.
  if (r.action_sent === true || r.acted === true) return r.outcome === 'not_dispatched' ? 'unknown' : 'reported';
  if (r.outcome === 'unknown' || r.outcome === 'unconfirmed' || r.outcome === 'rolled_back') return 'unknown';
  if (r.outcome === 'not_dispatched') return 'none';
  if (bare === 'act_and_verify' && r.action_result && depth < 2) return irreversibleReportedState('input_sequence', r.action_result, depth + 1);
  if (bare === 'input_sequence' || bare === 'act_and_verify') return 'unknown';
  if (bare === 'ocr_click' || bare === 'vision_click' || bare === 'ocr_find_text') {
    if (r.clicked === true || (r.clicked && typeof r.clicked === 'object' && !Array.isArray(r.clicked))) return 'reported';
    if (r.click_error) return 'unknown';
    if (bare === 'ocr_find_text' && r.ok === true && r.clicked === undefined) return 'none';
    if (r.clicked === false || r.clicked === null || r.found === false || r.not_found === true) return 'none';
    return 'unknown';
  }
  if (r.acted === false && (r.ok === true || r.success === true)) return 'none';
  return r.ok === true || r.success === true ? 'reported' : 'unknown';
}
function irreversibleEntryMetadata(row) {
  const out = {};
  if (row?.effectStatus === 'reported' || row?.effectStatus === 'unknown') out.effectStatus = row.effectStatus;
  for (const key of ['callId', 'callIdHash', 'parentTool', 'reason', 'outcome']) {
    if (typeof row?.[key] === 'string') out[key] = row[key].slice(0, key === 'parentTool' ? 200 : 120);
  }
  if (Number.isInteger(row?.step) && row.step >= 0 && row.step < 200) out.step = row.step;
  return out;
}
function projectBridgedIrreversible(tc0, invocationAttempted) {
  const tc = unwrapToolInvokeCall(tc0);
  const name = typeof tc?.name === 'string' ? tc.name : '';
  const bare = unprefixedBridgedName(name);
  const compound = IRREVERSIBLE_COMPOUND_TOOLS.has(bare);
  // Bare CLI/native names must not acquire bridge semantics by collision.
  if (bare === name || (!compound && !Object.hasOwn(IRREVERSIBLE_BRIDGED_KIND, bare))) return null;
  const projection = { schemaVersion: 1, items: [], incomplete: false };
  // This flag comes from the actual local call boundary, never from model arguments.
  if (invocationAttempted === false) return projection;
  const r = irreversibleResultObject(tc.result);
  const callId = typeof tc.id === 'string' && tc.id.length <= 120 ? tc.id : '';
  const callIdHash = typeof tc.id === 'string' && tc.id.length > 120 ? crypto.createHash('sha256').update(tc.id).digest('hex') : '';
  const note = (tool, result, step, kind, reason) => {
    const state = reason ? 'unknown' : irreversibleReportedState(unprefixedBridgedName(tool), result);
    if (state === 'none') return;
    if (projection.items.length >= IRREVERSIBLE_LEDGER_MAX) { projection.incomplete = true; return; }
    projection.items.push({ kind, name: tool.slice(0, 200), detail: '',
      ok: !!result && result.ok !== false && result.success !== false && !result.error && state === 'reported',
      effectStatus: state, ...(callId ? { callId } : {}), ...(callIdHash ? { callIdHash } : {}), ...(step === undefined ? {} : { parentTool: name.slice(0, 200), step }),
      ...(reason ? { reason } : {}), ...(typeof result?.outcome === 'string' ? { outcome: result.outcome.slice(0, 120) } : {}) });
  };
  if (!compound) { note(name, r, undefined, IRREVERSIBLE_BRIDGED_KIND[bare]); return projection; }
  if (r?.step_invocation_schema === 1 && r.invocation_attempted === false && !Array.isArray(r.results)) return projection;
  if (!Array.isArray(r?.results)) {
    if (r?.outcome !== 'not_dispatched') note(name, r, undefined, 'unknown', 'compound_result_unavailable');
    return projection;
  }
  const seen = new Set();
  for (const [index, child] of r.results.slice(0, 200).entries()) {
    // Malformed rows cannot certify either execution or a no-effect result.
    if (!child || !Number.isInteger(child.step) || child.step < 0 || child.step >= 200 || seen.has(child.step) || typeof child.tool !== 'string') {
      projection.incomplete = true; continue;
    }
    seen.add(child.step);
    if (child.step !== index) projection.incomplete = true;
    if (r.step_invocation_schema === 1 && child.invocation_attempted === false) {
      if (Object.hasOwn(child, 'result')) { projection.incomplete = true; note(name, null, child.step, 'unknown', 'conflicting_invocation_result'); }
      continue;
    }
    // Nested compounds are prohibited by ACC. Unexpected nested results stay unknown.
    if (IRREVERSIBLE_COMPOUND_TOOLS.has(child.tool)) {
      note(name, null, child.step, 'unknown', 'unexpected_nested_compound'); continue;
    }
    if (!Object.hasOwn(IRREVERSIBLE_BRIDGED_KIND, child.tool)) continue;
    const prefix = name.slice(0, name.lastIndexOf('__') + 2);
    const result = irreversibleResultObject(child.result);
    note(prefix + child.tool, result, child.step, IRREVERSIBLE_BRIDGED_KIND[child.tool], result ? '' : 'step_result_unavailable');
  }
  // A complete returned prefix may end early on an error. Missing requested suffixes are not
  // presumed to have run. Only malformed/omitted returned rows make this projection incomplete.
  if (r.outcome === 'unknown' || r.outcome === 'unconfirmed' || r.outcome === 'rolled_back') note(name, r, undefined, 'unknown', 'compound_outcome_unknown');
  if (r.outcome === 'not_dispatched' && projection.items.length) projection.incomplete = true;
  if (r.results.length > 200 || (Number.isInteger(r.completed) && Number.isInteger(r.failed)
      && r.completed + r.failed !== r.results.length)) projection.incomplete = true;
  if (projection.incomplete && projection.items.length < IRREVERSIBLE_LEDGER_MAX) note(name, null, undefined, 'unknown', 'compound_results_incomplete');
  return projection;
}

function buildTurnSummary(turnSeq, toolCalls, engine, journalEntries) {
  const byPath = new Map(); // path → {path, op, revertible} — journal entries take precedence over records
  let commands = 0;
  let irreversibleIncomplete = false;
  const irreversible = []; // 第72波:不可逆操作正向账(收录判据见 IRREVERSIBLE_*_KIND 头注)
  const noteIrreversible = (name, input, result) => {
    const kind = irreversibleToolKind(name);
    if (!kind) return;
    if (irreversible.length >= IRREVERSIBLE_LEDGER_MAX) { irreversibleIncomplete = true; return; }
    const r = asResultObject(result);
    irreversible.push({ kind, name: String(name || ''), detail: irreversibleDetail(input), ok: !(r && r.ok === false) });
  };
  for (const tc0 of (Array.isArray(toolCalls) ? toolCalls : [])) {
    const tc = unwrapToolInvokeCall(tc0); // 审计 N1:tool_invoke_* 按真正被调用的工具名进账
    if (!tc || !tc.name) continue;
    const name = String(tc.name);
    const input = (tc.input && typeof tc.input === 'object') ? tc.input : {};
    const projected = tc0.irreversibleProjection?.schemaVersion === 1 && Array.isArray(tc0.irreversibleProjection.items)
      ? tc0.irreversibleProjection : projectBridgedIrreversible(tc0);
    if (projected) {
      irreversibleIncomplete ||= projected.incomplete === true;
      for (const item of projected.items.slice(0, IRREVERSIBLE_LEDGER_MAX)) {
        if (irreversible.length >= IRREVERSIBLE_LEDGER_MAX) { irreversibleIncomplete = true; break; }
        irreversible.push({ kind: String(item.kind || 'unknown').slice(0, 32), name: String(item.name || name).slice(0, 200),
          detail: String(item.detail || '').slice(0, 120), ok: item.ok === true, ...irreversibleEntryMetadata(item) });
      }
    } else noteIrreversible(name, input, tc.result);
    if (TURN_SUMMARY_FILE_TOOLS.has(name)) {
      const r = asResultObject(tc.result);
      // Path: prefer the tool input; fall back to the parsed result (claude workbench tools echo .path).
      const p = input.path ? String(input.path) : (r && r.path ? String(r.path) : '');
      if (!p) continue;
      // Skip failed file ops (e.g. file_edit oldText-not-found) — nothing changed, nothing to revert.
      if (r && r.ok === false) continue;
      let op = 'unknown';
      if (name === 'file_edit') op = 'modify';
      else if (name === 'file_delete') op = 'delete';
      else if (name === 'file_write') {
        // 25.5: 幂等跳过(op:'skip')= 未发生任何改动,不进变更清单(与失败 continue 同款语义)。
        if (r && r.op === 'skip') continue;
        // file_write now echoes op (create/modify) from the journal-aware toolCall; fall back to 'unknown'.
        op = (r && r.op === 'create') ? 'create' : (r && r.op === 'modify') ? 'modify' : 'unknown';
      }
      byPath.set(path.resolve(p), { path: p, op, revertible: false });
    } else if (TURN_SUMMARY_COMMAND_TOOLS.has(name)) {
      commands += 1;
    } else if (engine === 'claude' && !TURN_SUMMARY_KNOWN_TOOLS.has(name)) {
      // Claude CLI native tools (Edit/Write/Bash/etc.) never pass through toolCall — count as a command.
      commands += 1;
    }
  }
  // v0.8-S4a: overlay the journal entries — they carry the accurate op and mark revertible:true (unless
  // the before content was too large to store → skipped → stays false). Keyed on resolved absolute path.
  // v0.8-S4b: also carry `entrySeq` so the UI「本轮变更」card can target a SINGLE file for rollback
  // (POST /api/checkpoints/rollback {turnSeq, entrySeq}). When a path was written more than once in the
  // turn the last journal entry wins here — its entrySeq is the newest `before`, i.e. rolling back that
  // one entry restores the state just prior to the last write (single-file undo semantics).
  for (const je of (Array.isArray(journalEntries) ? journalEntries : [])) {
    if (!je || !je.path) continue;
    byPath.set(path.resolve(String(je.path)), { path: String(je.path), op: je.op || 'unknown', revertible: !je.skipped, entrySeq: Number(je.entrySeq) });
  }
  const filesChanged = [...byPath.values()];
  // v0.9-S4 (C4): artifacts — files this turn PRODUCED, for the右栏「产物」gallery. Two sources, merged
  // by resolved path (last write wins, so kind stays consistent):
  //  (1) journal entries with op:'create' (a genuinely new file) → {path, kind};
  //  (2) any tool result carrying an output_path-style key (bridged doc/screenshot/office tools echo one).
  // Note: modify/delete journal entries are NOT artifacts (nothing new was produced); the file still shows
  // up under filesChanged. Kind is suffix-derived (kindForPath). De-dup keyed on the resolved absolute path.
  const artByPath = new Map();
  const addArtifact = raw => {
    const p = String(raw || '').trim();
    if (!p) return;
    artByPath.set(path.resolve(p), { path: p, kind: kindForPath(p) });
  };
  // v1.0.2-S4 产物判定放宽(产品决策):除 op:'create' 外, op:'modify' 且 kindForPath 命中已知类型
  // (img/md/csv/html/xlsx/docx/pdf) 的也算产物(改一个 xlsx 也是产物)。addArtifact 已按 resolved path
  // 去重, 故 create/modify 同 path 只留一条。'txt' 与 'other' 的 modify 不入(避免把随手改的日志/临时文
  // 本当产物, 与用户「右侧产物页签」的心智一致)。
  const ARTIFACT_MODIFY_KINDS = new Set(['img', 'md', 'csv', 'html', 'xlsx', 'docx', 'pdf']);
  for (const je of (Array.isArray(journalEntries) ? journalEntries : [])) {
    if (!je || !je.path) continue;
    if (je.op === 'create') addArtifact(je.path);
    else if (je.op === 'modify' && ARTIFACT_MODIFY_KINDS.has(kindForPath(je.path))) addArtifact(je.path);
  }
  for (const tc0 of (Array.isArray(toolCalls) ? toolCalls : [])) {
    const tc = unwrapToolInvokeCall(tc0);
    if (!tc) continue;
    const r = asResultObject(tc.result);
    if (!r || r.ok === false) continue; // failed calls produced nothing
    for (const k of ARTIFACT_OUTPUT_PATH_KEYS) {
      if (typeof r[k] === 'string' && r[k].trim()) addArtifact(r[k]);
    }
    // v1.5-W1.5: ACC 兼容层 —— 对写族 bridged 工具额外收割裸 `path`。三条同时满足才收:①工具名是写族;
    // ②结果 success===true(ACC 契约:写成功回 success:true;失败回 {error}, 无 success);③有非空字符串
    // path。与上面 addArtifact 的 resolved-path 去重合并,故新版 ACC(同时回 output_path 与 path)不会重复
    // 登记。仅对 bridged 写族生效,读类工具(read_document 也回 path)因名字不匹配而不会误收。
    if (tc.name && isBridgedWriteTool(tc.name) && r.success === true
        && typeof r.path === 'string' && r.path.trim()) {
      addArtifact(r.path);
    }
  }
  const artifacts = [...artByPath.values()];
  return { turnSeq: Number(turnSeq) || 0, filesChanged, commands, artifacts, irreversible, ...(irreversibleIncomplete ? { irreversibleIncomplete: true } : {}) };
}

// v0.8-S0 A6: detect an interrupted (dangling) turn from providerHistory. Dangling shapes:
//   - the tail is a role:'user' message with no assistant reply after it (turn never got answered);
//   - the tail is a role:'tool' message (turn stopped mid tool-loop, see below);
//   - the tail assistant carries tool_calls but not every tool_call_id has a matching role:'tool' reply
//     (turn was arrested mid tool-loop). Returns { dangling, kind } — kind: 'user'|'tool_calls'|null.
function detectDanglingTurn(session) {
  // perf:不读 provider 正文的装载视图(SESSION_LOAD_OMIT_PROVIDER)带着这份正文的判定与条数,形状与下面逐键相同。
  const omitted = sessionOmittedProviderHistory(session);
  const h = omitted ? null : ((session && Array.isArray(session.providerHistory)) ? session.providerHistory : []);
  // turnSeq + historyLength form a stable UI-dismiss fingerprint: reopening the same interrupted turn stays
  // dismissed, while a later interruption automatically gets a fresh banner instead of inheriting the old ×.
  const meta = { turnSeq: Math.max(0, Number(session && session.turnSeq) || 0), historyLength: omitted ? omitted.count : h.length };
  const state = omitted ? omitted.dangling : danglingTurnState(h.length, i => h[i]);
  return { dangling: state.dangling, kind: state.kind, ...meta };
}
// detectDanglingTurn 的判定本体:只看 providerHistory 的尾巴,at(i) 取第 i 条(数组下标,或 02 正文记录按行惰性解析)。
function danglingTurnState(length, at) {
  if (!length) return { dangling: false, kind: null };
  const last = at(length - 1);
  if (last && last.role === 'user') return { dangling: true, kind: 'user' };
  // A tail of role:'tool' is the persisted shape of Stop-mid-loop (the MOST common interruption): the
  // abort lands after the tool results were pushed but before the next model call (the `if (aborted)
  // break` right after the per-tool-result push in runOpenAiTurn), and the closing assistant text is
  // only pushed on normal completion. Every tool_call_id is answered, yet the turn never concluded.
  if (last && last.role === 'tool') return { dangling: true, kind: 'tool_calls' };
  // Walk back to the most recent assistant message that requested tools; verify each id was answered.
  for (let i = length - 1; i >= 0; i--) {
    const m = at(i);
    if (!m || m.role !== 'assistant') continue;
    if (!Array.isArray(m.tool_calls) || m.tool_calls.length === 0) break; // plain assistant → complete
    const answered = new Set();
    for (let j = i + 1; j < length; j++) {
      const r = at(j);
      if (r && r.role === 'tool' && r.tool_call_id != null) answered.add(String(r.tool_call_id));
    }
    const unanswered = m.tool_calls.some(tc => tc && !answered.has(String(tc.id)));
    return unanswered ? { dangling: true, kind: 'tool_calls' } : { dangling: false, kind: null };
  }
  return { dangling: false, kind: null };
}

// 配对铁律自愈(strict provider 400 永久卡死会话的修复面):detectDanglingTurn 只【检测】悬挂,而
// runOpenAiTurn 回合开始会无条件 push 新 user 消息 —— 若持久化的 providerHistory 里某个
// assistant.tool_calls 有未应答 id(进程在工具块中途被杀/崩溃,abort 路径的 skip 填充来不及跑),
// 下一回合请求体就是 assistant.tool_calls -> user,DeepSeek/DashScope 直接 400
// (insufficient tool messages following tool_calls),且每次重发同一份孤儿历史 -> 会话永久卡死。
// 本函数全历史单遍扫描:对每个带 tool_calls 的 assistant,统计紧随其后的 role:'tool' 块已应答 id,
// 缺的 id 在【块尾原位插入】合成 tool 回复(保持 assistant.tool_calls -> 连续 N 条 tool 的相邻契约,
// 不删不改任何既有消息 —— 与 abort 时 rem skip 填充同一思路,见 09-workflow.js)。
// 返回补的条数(0 = 历史本就配对完整,调用方无需落盘/发事件)。
function repairProviderHistoryPairing(history) {
  if (!Array.isArray(history) || !history.length) return 0;
  let repaired = 0;
  for (let i = 0; i < history.length; i++) {
    const m = history[i];
    if (!m || m.role !== 'assistant' || !Array.isArray(m.tool_calls) || !m.tool_calls.length) continue;
    const answered = new Set();
    let j = i + 1;
    while (j < history.length && history[j] && history[j].role === 'tool') {
      if (history[j].tool_call_id != null) answered.add(String(history[j].tool_call_id));
      j++;
    }
    const missing = m.tool_calls.filter(tc => tc && tc.id != null && !answered.has(String(tc.id)));
    if (!missing.length) continue;
    const fills = missing.map(tc => ({
      role: 'tool', tool_call_id: tc.id,
      content: '[工具结果丢失:上次回合已记录此调用,是否派发、执行及其结果未确认,可能已经产生影响。请勿自动重放此调用;先核实已发生的影响,需要再次执行时请取得明确授权。]',
    }));
    history.splice(j, 0, ...fills);
    repaired += fills.length;
    i = j + fills.length - 1; // 跳过刚插入的填充条,继续扫块后第一条未检查的消息
  }
  return repaired;
}

// ── 工具调用参数铁律(第117波;用户线上事故:Qwen/DashScope HTTP 400 invalid_parameter_error
//    "The \"function.arguments\" parameter of the code model must be in JSON format.")────────────────
// 事故形状与上面的孤儿 tool_calls 是同一个模具,只是毒在【参数】而不是【配对】上:
//   ① 三处回放点(09-workflow.js 的两处 providerHistory.push、08-agent-runs.js 子代理那处)把模型给的
//      rawArgs【逐字节】写成 assistant.tool_calls[].function.arguments,不做任何 JSON 保证;
//   ② 三个 rawArgs 生产者(07-autonomy.js Responses 非流式 / Chat 非流式 / 流式槽收口)只对【假值】
//      兜底 `|| '{}'` —— 空串救得回来,"非空但不合法"救不回来;
//   ③ 流式是纯拼接(07-autonomy.js `slot.args += tc.function.arguments`)。流被截断(客户端断流、
//      供应商截流、触顶 token)时 slot.args 停在半截 JSON 上,非空,直接躲过 ②;
//   ④ 每个执行方却都是 `JSON.parse(tc.rawArgs || '{}') catch → {}` —— 工具【实际按 {} 跑了】,
//      历史却声称那截烂片段。历史与执行各说各话,严校验供应商见到 arguments 不是 JSON 对象即 400;
//   ⑤ 这条毒回合已落盘 → 之后每次请求都重发它 → 会话永久卡死(与孤儿历史一字不差的死法)。
// 判据:arguments 必须能 JSON.parse 成【对象】。数组/标量/空串都不合法 —— 供应商按对象反序列化参数,
// '[1,2]' 能 parse 却填不进 function 的具名参数,同样 400。
function isProviderToolArgsObject(raw) {
  if (typeof raw !== 'string' || raw === '') return false;
  let parsed;
  try { parsed = JSON.parse(raw); } catch { return false; }
  return !!parsed && typeof parsed === 'object' && !Array.isArray(parsed);
}

// 写侧不变量(唯一收口):rawArgs 变成 providerHistory 的 function.arguments 时过一次判据,不合法一律
// 记 '{}' —— 与执行方 catch → {} 【完全一致】,历史从此说的就是实际跑的那份参数。
// 为什么钉在这里、而不是钉在 rawArgs 三个生产者上:rawArgs 本身还有三个【非请求体】读者,改生产者会
// 连坐它们 —— 09-workflow.js:1911 的连击指纹 sha1(name+'\0'+rawArgs)(两截不同的截断片段会塌成同一
// 指纹 → 误判"同签名连击"而 abort)、09-workflow.js:1749 的 econArgsBytes(tc.rawArgs) 经济口径(真实
// 字节数会变成 2)、07-autonomy.js:1042 的动作视图投影(它【故意】对 malformed 拒绝投影)。
// 不变量说的是"发到供应商的 arguments",落点就该在 arguments 生成处,别处的 rawArgs 一个字节不动。
// 日志只带工具名与字节数,绝不带片段本身(截断片段可能含密钥/路径,与本仓库其它脱敏处同规矩)。
function providerHistoryToolCalls(toolCalls, logCtx) {
  return (Array.isArray(toolCalls) ? toolCalls : []).map(tc => {
    if (isProviderToolArgsObject(tc.rawArgs)) return { id: tc.id, type: 'function', function: { name: tc.name, arguments: tc.rawArgs } };
    logEvent({
      kind: 'provider_tool_args_coerced', ...(logCtx && typeof logCtx === 'object' ? logCtx : {}),
      tool: String(tc.name || ''), bytes: Buffer.byteLength(String(tc.rawArgs == null ? '' : tc.rawArgs), 'utf8'),
    });
    return { id: tc.id, type: 'function', function: { name: tc.name, arguments: '{}' } };
  });
}

// 参数铁律自愈(repairProviderHistoryPairing 的同位兄弟):写侧不变量只管【今后】写进去的,用户手上
// 那条【已经卡死】的会话还得就地修 —— 否则每次请求照样重发同一份毒历史、照样 400。全历史单遍扫描:
// 任何 assistant.tool_calls[].function.arguments 过不了对象判据的,原地改写成 '{}'(与当时实际执行用的
// {} 一致);不删不改任何其它字段、不动任何其它消息。返回改写条数(0 = 历史本就干净,调用方无需落盘/
// 发系统消息)—— 故对合法历史是【逐字节】no-op。
function repairProviderHistoryToolArgs(history, sessionId) {
  if (!Array.isArray(history) || !history.length) return 0;
  let repaired = 0;
  for (const m of history) {
    if (!m || m.role !== 'assistant' || !Array.isArray(m.tool_calls) || !m.tool_calls.length) continue;
    for (const tc of m.tool_calls) {
      if (!tc || !tc.function || typeof tc.function !== 'object') continue;
      if (isProviderToolArgsObject(tc.function.arguments)) continue;
      const raw = tc.function.arguments;
      logEvent({
        kind: 'provider_tool_args_repair', ...(sessionId ? { sessionId: String(sessionId) } : {}),
        tool: String(tc.function.name || ''), bytes: Buffer.byteLength(String(raw == null ? '' : raw), 'utf8'),
      });
      tc.function.arguments = '{}';
      repaired++;
    }
  }
  return repaired;
}

// Returns the normalized session, or null when the file is missing/unreadable. A file that exists but
// fails to parse is renamed to <id>.json.corrupt (isolated, not deleted) so a truncated write can't
// keep 500-ing every read; callers treat null as "not found".
// v1.9 存储 v2:头(storageVersion:2)从两个 NDJSON 正文装配 messages/providerHistory;正文缺失/坏 →
// v1bak 回退(迁移备份),无 v1bak 才按损坏隔离。legacy 单文件首次加载后打非枚举 __v1bakPending 标记,
// 由 saveSession 完成「先备份 v1bak、再落 v2」的懒迁移(对调用方完全透明)。
// ── 第71b波:残留 pending 叙事段清理者 ─────────────────────────────────────────────────────────
// permission/plan/question 叙事段在回合流式期以 status:'pending'(权限另有 'paused' 存档暂停)落盘(上方段构建器)。
// 进程重启/回合中断后,内存待决注册表(04 pendingPermissions/pendingQuestions/pendingPlans)已清空,决策永远
// 到不了 —— 段却在每次重进会话时永远显示「待处理」只读 pill(与 Intervention 的 cancelled_restart 同源的残留)。
// 本清理器在 loadSession 全量装载时惰性修复:段的 id 不在活注册表 → 决策不可能再到达,诚实标终态 'cancelled'
// + note(前端 pill 词汇已有 cancelled,见 chat-static-renderer narrativeStateLabel)。惰性而非 boot 全扫:
// messages 正文是大文件,boot 扫全部会话代价不可控;loadSession 时该会话反正要被读,一趟摊销。
// 覆盖 71b 前存量段(无 Intervention 记录)与 71b 后段(boot 已 cancel_restart 但段未动)——活注册表是唯一判据。
// 竞态防护(调用方执行):活回合(activeChildren)或 dying turn 收尾窗口(turnSettlers,第69波 rewind 同款)
// 内绝不调用 —— 此时磁盘 pending 可能是「决策在内存、未落盘」的活段,误标会与回合收尾 save 互相覆盖。
function healStalePendingSegments(session) {
  if (!session || !Array.isArray(session.messages)) return false;
  let healed = false;
  const note = '应用重启或回合中断,该请求已失效;如需请重新发起。';
  const toolNote = '回合中断时该工具仍在运行,已标记为取消;如需请重试。';
  for (const msg of session.messages) {
    const segs = msg && Array.isArray(msg.segments) ? msg.segments : null;
    if (!segs) continue;
    for (const seg of segs) {
      if (!seg || typeof seg !== 'object') continue;
      if (seg.type === 'permission' && (seg.status === 'pending' || seg.status === 'paused')) {
        if (seg.requestId && pendingPermissions.has(String(seg.requestId))) continue; // 活待决:决策仍会到达
        seg.status = 'cancelled'; seg.note = note; healed = true;
      } else if (seg.type === 'plan' && seg.status === 'pending') {
        if (seg.planId && pendingPlans.has(String(seg.planId))) continue;
        seg.status = 'cancelled'; seg.note = note; healed = true;
      } else if (seg.type === 'question' && seg.status === 'pending') {
        if (seg.questionId && pendingQuestions.has(String(seg.questionId))) continue;
        seg.status = 'cancelled'; seg.note = note; healed = true;
      } else if ((seg.type === 'tool' || seg.type === 'subagent') && seg.status === 'running') {
        // 47b/86: 回合被 Stop/看门狗/异常中止时,正在执行的 tool/subagent 段以 'running' 落盘 (finalizeAll
        // 在新回合会兜底,但此会话是修复前落盘的存量) -> 重进会话时诚实标 'cancelled'。
        seg.status = 'cancelled'; seg.note = toolNote; healed = true;
      } else if (seg.type === 'workflow' && (seg.status === 'running' || seg.status === 'paused')) {
        seg.status = 'cancelled'; seg.note = toolNote; healed = true;
      }
    }
  }
  return healed;
}

// ── 117j 收尾（实证定位的一条真 bug，不是测试问题）─────────────────────────────────────────
// Windows 上 `rename(tmp, final)` 替换【已存在】的文件时，并发的读会在「旧文件已解链、新文件还没
// 链入」的那一瞬拿到 **ENOENT**。会话头每保存一次就开一个这样的窗口，而回合跑起来时它一直在写 ——
// 于是一发单打的 readFile 会偶发读空，把「文件正在被原子替换」误判成「这个会话不存在」。
//
// 实证：steward-drawer.e2e 的 E4b 约 1/3 概率红，打点抓到 `decideIntervention` 里那一发
// `readFile(sessionPath(missionId))` 抛的正是 ENOENT，而同一时刻 `pendingQuestions.has(qid)` 仍为
// true（待决好端端在那儿）。用户于是看到「答不进去：answer could not be delivered」——**这不是
// 夹具的问题，是产品在真机上也会偶发的失败**：谁恰好在回合写头的那一瞬点「允许／回答」，谁就中招。
//
// 修法与写侧对称：atomicWriteJson 早就为 EPERM/EBUSY/EACCES/EEXIST 做了重试，这里补上读侧。
// 只重试「瞬时缺席/占用」这几类；**真的不存在的会话最多多花 ~80ms 仍然返回 null**，判据与语义不变。
// 解析失败不在重试之列 —— 那是内容坏了，归 loadSession 的隔离路径管，重试只会把坏内容读四遍。
const SESSION_HEAD_READ_RETRIES = 4;
const SESSION_HEAD_TRANSIENT = new Set(['ENOENT', 'EPERM', 'EBUSY', 'EACCES']);
async function readSessionHeadResilient(id) {
  for (let attempt = 0; ; attempt++) {
    try {
      return safeJsonParse(await fsp.readFile(sessionPath(id), 'utf8'), null);
    } catch (error) {
      const code = String((error && error.code) || '');
      if (!SESSION_HEAD_TRANSIENT.has(code) || attempt >= SESSION_HEAD_READ_RETRIES) return null;
      await new Promise(resolve => setTimeout(resolve, 5 + attempt * 10));
    }
  }
}
// 「这条会话走哪条引擎路由」的只读取法:GET /api/status?sessionId= 与 GET /api/models?sessionId= 用。
// 两条路由都是 auth:'open'(跨站页面也能让浏览器发出来),修前它们调 loadSession —— 装载会补默认字段回写、
// 懒迁移 v1、截断撕裂尾行,开放读口就这样成了能改盘的写口(配合保留名,还能把搜索索引「迁移」成假会话)。
// 这里只读会话头,零副作用;inferSessionEngineRoute 要的 engineRoute 就在头上(v1 单文件头连 messages 一起带着)。
async function readSessionRouteHead(id) {
  if (safeSessionId(id) === null) return null;
  const head = await readSessionHeadResilient(id);
  return head && typeof head === 'object' && !Array.isArray(head) ? head : null;
}
// 正文截断同款有界重试(Windows 上杀软/索引器短暂持锁的 EPERM/EBUSY)。仍失败就如实返回 false:
// 调用方据此不交出 bodiesOk:true —— 否则下次快路径会接在没截掉的残留后面 append,把新行焊进
// 半行(整条会话随后被判损坏隔离),或让旧的未提交尾巴留在真消息前面、下次截断反而截掉真消息。
async function truncateSessionBody(file, len) {
  for (let attempt = 0; ; attempt++) {
    try { await fsp.truncate(file, len); return true; }
    catch (error) {
      const code = String((error && error.code) || '');
      if (code === 'ENOENT' || !SESSION_HEAD_TRANSIENT.has(code) || attempt >= SESSION_HEAD_READ_RETRIES) return false;
      await new Promise(resolve => setTimeout(resolve, 5 + attempt * 10));
    }
  }
}

// 117j 收尾（实证定位的一条真 bug，会【删数据】）：本函数下面两个动作都是破坏性的 ——
// 「未提交尾巴」物理截断正文、以及把头与正文一起隔离成 .corrupt。它们的判据是「头声明的行数 vs
// 正文实际行数」，而这两样是**先后两次**读进来的：先读头，再读两个正文。一次并发的 saveSession
// 完全可以落在这两次读之间，于是我们拿【旧头】去量【新正文】：
//   · 正文比旧头多 → 被当成「崩溃留下的未提交尾巴」物理截断，**真数据被删**；
//   · 反过来（旧正文 + 新头）→ 被当成「已提交数据丢失」，整条会话隔离成 .corrupt，**会话消失**。
// 实证（steward-drawer.e2e 的 E4b 约 1/3 概率红）：打点抓到 messages.ndjson 被截成 0 字节、而头仍
// 声明 1 条、随后整条会话被隔离；用户那一侧的表现是「答待决答不进去（会话不存在）」。真机上同样成立：
// 谁恰好在回合写盘的那一瞬触发一次 loadSession（打开会话、改元数据、投影重建都会），谁就中招。
// 修法：动手之前把头**再读一遍**。头变了 = 刚才那一眼已经旧了，重跑一次 load（有界一次），
// 不做任何破坏动作；头没变才说明两次读之间没有写者，判据才成立。
// ── perf(增量取):不读 provider 正文的装载视图 loadSession(id, 0, 0, SESSION_LOAD_OMIT_PROVIDER) ──────────────
// GET /api/sessions/:id?fromIndex=N&prefixStamp=S 只回 messages[N..] 与信封,从不回 providerHistory;修前它照样整份装载
// (两个正文都读、都解析,heavy 会话 provider 正文 8 MB)。这个视图只在【能证明结果与完整装载的 messages 逐字节相同】时
// 跳过 provider 正文,否则(包括任何一个前提拿不准)原样交给完整装载 —— 调用方拿到的就是一份完整会话。前提:
//   ① 本进程对这条会话的 provider 正文有记录、上次写/读成功(bodiesOk),且此刻没有写者在链上;
//   ② 盘上 provider 正文的文件戳(size|mtimeNs|ino)与记录相同,头声明的条数 = 记录的条数
//      (提交点语义:正文完整、没有未提交尾巴、没有撕裂尾行 —— 这正是完整装载在这一半上会确认的事);
//   ③ messages 正文读得出、没有坏行、没有撕裂尾行、条数与头声明相同(完整装载会动手截断/隔离/回退的情形一律让位);
//   ④ 读的这一段里本进程没有人落过盘(sessionDiskWriteSeq 不变);
//   ⑤ 装载后半段(normalize 补字段、残留 pending 叙事段的惰性清理)不需要回写 —— 要回写就让位给完整装载去写,
//      绝不拿一份没有 providerHistory 的对象去 saveSession(saveSession 见到本视图的对象直接拒绝)。
// 其余步骤(撤回代数自愈、内存覆盖表、changeSeq 水位、后台任务账本合并)与完整装载是同一段代码。
// 返回的对象上 providerHistory 是占位的 [](键序与完整装载相同),另挂一个不可枚举的 __providerHistoryOmitted =
// { count, dangling, body }:resumable 由 detectDanglingTurn 从 dangling/count 给出;body 是 messages 正文的字节视图
// (只在每一行都已证明是 canonical 时给出),sessionMessagesDelta 用它按字节算前缀戳。
// 唯一的信任点是 ② 的文件戳(与条件 GET 的 ETag 同一类判据):同 size、同 mtime、同 inode 的外部改写看不出来。
const SESSION_LOAD_OMIT_PROVIDER = 'omitProviderHistory';
function sessionOmittedProviderHistory(session) {
  return (session && session.__providerHistoryOmitted) || null;
}
function sessionProviderHistoryLength(session) {
  const omitted = sessionOmittedProviderHistory(session);
  if (omitted) return omitted.count;
  return session && Array.isArray(session.providerHistory) ? session.providerHistory.length : 0;
}
async function readSessionBodiesOmittingProvider(id, parsed, bp, writeSeqAtRead) {
  // Protected transcripts must verify the committed body hashes, including same-count rewrites.
  if (Object.hasOwn(parsed, 'providerHistoryRevision') || Object.hasOwn(parsed, 'providerHistoryCommit')) return null;
  const state = sessionBodyState.get(id);
  const provRec = state && state.bodiesOk ? state.prov : null;
  if (!provRec || !provRec.stamp || !provRec.dangling || sessionWriteChains.has(id)) return null;
  if (!Number.isInteger(parsed.providerHistoryCount) || parsed.providerHistoryCount !== provRec.count) return null;
  if (await sessionBodyFileStamp(bp.provider) !== provRec.stamp) return null;
  const msg = await readSessionBodyFile(bp.messages);
  if (!msg || msg.corrupt || msg.unreadable || msg.tornAt != null) return null;
  if (Number.isInteger(parsed.messageCount) && msg.entries.length !== parsed.messageCount) return null;
  if (sessionDiskWriteSeqOf(id) !== writeSeqAtRead || sessionWriteChains.has(id)) return null;
  const cur = sessionBodyState.get(id);
  if (!cur || cur.prov !== provRec || !cur.bodiesOk) return null;
  // 与完整装载同样把读到的 messages 正文交给状态表(同一拍、同一个「没有写者」判据)。
  const msgRec = sessionBodyRecordFromRead(msg, cur.msg);
  setSessionBodyState(id, { msg: msgRec, prov: provRec, bodiesOk: true });
  const body = msgRec.canonical ? { buf: msg.buf, lineEndBytes: msg.lineEndBytes, count: msg.lines.length } : null;
  return { messages: msg.entries, omitted: { count: provRec.count, dangling: provRec.dangling, body } };
}
async function loadSession(id, reloadDepth = 0, staleRetry = 0, view = null) {
  if (safeSessionId(id) === null) return null; // 不合形的 id 就是「没有这个会话」(sessionPath 会拒绝拼路径)
  const writeSeqAtRead = sessionDiskWriteSeqOf(id);
  let raw;
  // hunt2-P3:头读撞上瞬时锁(EBUSY/EPERM/EACCES)先有界重试,别把「一时读不到」答成「会话不存在」。
  for (let attempt = 0; ; attempt++) {
    try { raw = await fsp.readFile(sessionPath(id), 'utf8'); break; }
    catch (error) {
      const code = String((error && error.code) || '');
      if (code === 'ENOENT' || !SESSION_BODY_READ_TRANSIENT.has(code) || attempt >= SESSION_HEAD_READ_RETRIES) return null;
      await new Promise(resolve => setTimeout(resolve, 5 + attempt * 10));
    }
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    await fsp.rename(sessionPath(id), sessionPath(id) + '.corrupt').catch(() => {});
    return null;
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null; // Never normalize a non-object head into a fresh empty session.
  if ((Object.hasOwn(parsed, 'providerHistoryRevision') || Object.hasOwn(parsed, 'providerHistoryCommit'))
      && parsed.storageVersion !== SESSION_STORAGE_VERSION) return null;
  let legacy = true;
  const omitView = view === SESSION_LOAD_OMIT_PROVIDER;
  const lite = omitView && parsed && parsed.storageVersion === SESSION_STORAGE_VERSION
    ? await readSessionBodiesOmittingProvider(id, parsed, sessionBodyPaths(id), writeSeqAtRead) : null;
  if (omitView && !lite) return loadSession(id, reloadDepth, staleRetry);   // 前提拿不准 → 完整装载(见视图头注)
  if (lite) {
    sessionBodyPerfStats.providerBodySkips++;
    parsed.messages = lite.messages;
    parsed.providerHistory = [];   // 占位:与完整装载同一个键位,normalize 不会因「缺数组」判 changed
    delete parsed.storageVersion;
    delete parsed.messageCount;
    delete parsed.providerHistoryCount;
    legacy = false;
  } else if (parsed && parsed.storageVersion === SESSION_STORAGE_VERSION) {
    const bp = sessionBodyPaths(id);
    let msg = await readSessionBodyFile(bp.messages);
    let prov = await readSessionBodyFile(bp.provider);
    // hunt2-P3:正文【在但读不出来】(重试过仍被锁/句柄耗尽)不是「正文丢了」—— 下面的判据会把它当缺失,
    // 走 v1bak 回退或整条隔离成 .corrupt。这一趟诚实地不给结果,盘上什么都不动,下次读自然恢复。
    const unreadable = b => !!(b && b.unreadable);
    if (unreadable(msg) || unreadable(prov)) {
      logEvent({ kind: 'session_body_unreadable', sessionId: id, code: String((unreadable(msg) ? msg : prov).code || '') });
      return null;
    }
    // 头是提交点:正文行数【少于】头声明 = 已提交数据丢失,与 corrupt 同级;【多于】头声明 = 崩溃于
    // 「append 完成、头写未完成」之间,多余行是未提交尾巴,物理截断(见下),不算损坏。
    const shortOf = (body, count) => Number.isInteger(count) && body && !body.corrupt && body.entries.length < count;
    const bodyBad = () => !msg || !prov || msg.corrupt || prov.corrupt
      || shortOf(msg, parsed.messageCount) || shortOf(prov, parsed.providerHistoryCount)
      || !sessionBodiesMatchCommit(parsed, msg, prov);
    const countsDiffer = () => (Number.isInteger(parsed.messageCount) && msg && !msg.corrupt && msg.entries.length !== parsed.messageCount)
      || (Number.isInteger(parsed.providerHistoryCount) && prov && !prov.corrupt && prov.entries.length !== parsed.providerHistoryCount);
    // 117j：只要接下来可能动手（截断或隔离），先确认「头还是刚才读的那一份」。用 updatedAt ＋ 两个
    // 计数当指纹：saveSession 每次落头都会推 updatedAt（nowIso），所以它变了就一定有写者插进来过。
    // （例外是装载回写 keepUpdatedAt：它们不推 updatedAt、不改两个计数，只补头上的默认字段。本进程内的任何写者
    //  —— 包括它们 —— 都由下面的 sessionDiskWriteSeqOf 判出来，那才是权威信号；updatedAt 与计数只是兜底。）
    // 读不到头（正被原子替换的那一瞬）同样按「别动手」处理 —— 破坏性动作绝不建立在一次可疑的读上。
    const torn = () => (msg && msg.tornAt != null) || (prov && prov.tornAt != null);
    if (bodyBad() || countsDiffer() || torn()) {   // 只有要动手(截断/隔离)时才需要确认没有写者
      // 先问最硬的那个信号：**本进程此刻正在给这条会话写盘吗**。saveSession 的 per-id 写链就是
      // 权威答案 —— 链在跑，说明「正文已落、头还没落」这个中间态是【预期内】的，不是崩溃残留。
      // 等它跑完再重读一次，头与正文自然对齐，一个字都不用删。
      // （只重读头是不够的：写链里正文先落、头后落，此刻重读拿到的仍是那份旧头，判据照样成立。
      //  实证——打点抓到 TRUNCATE from=1 to=0 紧跟着 QUARANTINE headMsg=1 body=0，会话就此消失。）
      const inFlight = sessionWriteChains.get(id);
      if (inFlight) {
        await inFlight.catch(() => {});
        if (reloadDepth >= 1) return null;
        return loadSession(id, reloadDepth + 1);
      }
      const again = await readSessionHeadResilient(id);
      const moved = !again
        || sessionDiskWriteSeqOf(id) !== writeSeqAtRead
        || String(again.updatedAt || '') !== String(parsed.updatedAt || '')
        || again.messageCount !== parsed.messageCount
        || again.providerHistoryCount !== parsed.providerHistoryCount;
      const commitMoved = JSON.stringify(again?.providerHistoryCommit) !== JSON.stringify(parsed.providerHistoryCommit)
        || again?.providerHistoryRevision !== parsed.providerHistoryRevision;
      if (moved || commitMoved) {
        if (reloadDepth >= 1) return null;   // 有界：连着两次都在写，这一趟就诚实地不给结果
        return loadSession(id, reloadDepth + 1);
      }
    }
    // .prevbody 快照(saveSession 慢路径重写前的旧正文)在场 + 正文坏/计数与头不符 = 上次慢路径中断
    // (崩溃于「正文重写、头未提交」之间)→ 恢复快照,与磁盘上的旧头重新配对。
    // 注意区分:头计数==正文行数时 prevbody 是「头已提交、清理未完成」的陈旧快照 → 不恢复,随下方清理删掉。
    const pm = bp.messages + '.prevbody', pp = bp.provider + '.prevbody';
    const hasPrev = await fsp.stat(pm).then(() => true).catch(() => false)
      && await fsp.stat(pp).then(() => true).catch(() => false);
    if (hasPrev && (bodyBad() || countsDiffer())) {
      if (Object.hasOwn(parsed, 'providerHistoryRevision') || Object.hasOwn(parsed, 'providerHistoryCommit')) {
        const [previousMessages, previousProvider] = await Promise.all([readSessionBodyFile(pm), readSessionBodyFile(pp)]);
        if (!sessionBodiesMatchCommit(parsed, previousMessages, previousProvider)) return null;
      }
      dropSessionBodyState(id);
      if (Object.hasOwn(parsed, 'providerHistoryRevision') || Object.hasOwn(parsed, 'providerHistoryCommit')) {
        // Keep both verified snapshots until both copies are restored. A partial
        // restore or process death must leave the complete recoverable pair.
        try { await fsp.copyFile(pm, bp.messages); await fsp.copyFile(pp, bp.provider); }
        catch { return null; }
      } else {
        await fsp.rename(pm, bp.messages).catch(() => {});
        await fsp.rename(pp, bp.provider).catch(() => {});
      }
      msg = await readSessionBodyFile(bp.messages);
      prov = await readSessionBodyFile(bp.provider);
      if (unreadable(msg) || unreadable(prov)) return null;   // hunt2-P3:同上,读不出来就不动手
    }
    if (bodyBad()) {
      // 磁盘正文已不可信 → 先作废进程内镜像,否则 save 的快路径会拿旧 hash 往坏正文上 append。
      dropSessionBodyState(id);
      // 正文缺失/损坏 → 迁移备份回退(v1 原文重走迁移,等价于回到迁移前一刻)。
      const bak = Object.hasOwn(parsed, 'providerHistoryRevision') || Object.hasOwn(parsed, 'providerHistoryCommit') ? null : await loadSessionV1Backup(id);
      if (bak) return bak;
      // 无备份可退:坏正文隔离(不删,留取证),头按损坏处理。
      for (const p of [bp.messages, bp.provider]) await fsp.rename(p, p + '.corrupt').catch(() => {});
      await fsp.rename(sessionPath(id), sessionPath(id) + '.corrupt').catch(() => {});
      return null;
    }
    // 撕裂尾行截断(从 readSessionBodyFile 挪到这里):到这一步已确认没有写者,半行是崩溃残留而非正在 append。
    let truncatedOk = true;   // 任何一刀没落地 → 盘上正文与内存不符,只许走全量重写(见 truncateSessionBody)
    for (const body of [msg, prov]) body.cut = false;   // 这一趟动过刀的正文,读时取的文件戳作废(见 sessionBodyState 头注)
    for (const [body, file] of [[msg, bp.messages], [prov, bp.provider]]) {
      if (body.tornAt != null) { body.cut = true; if (!await truncateSessionBody(file, body.tornAt)) truncatedOk = false; }
    }
    // 未提交尾巴截断:不物理截断的话,磁盘上多出的行会在下次快路径 append 后「复活」进会话。
    for (const [body, count, file] of [[msg, parsed.messageCount, bp.messages], [prov, parsed.providerHistoryCount, bp.provider]]) {
      if (Number.isInteger(count) && body.entries.length > count) {
        const cut = count > 0 ? body.lineEndBytes[count - 1] : 0;
        body.cut = true;
        if (!await truncateSessionBody(file, cut)) truncatedOk = false;
        body.entries.length = count; body.lines.length = count;
      }
    }
    parsed.messages = msg.entries;
    parsed.providerHistory = prov.entries;
    // 读完到这里期间有人落过盘 → 这份行记录已旧,交出去会让下一次快路径按旧前缀 append(重复行/丢行)。
    // 写者自己会把准确的状态放进来,这里什么都不放。
    if (!truncatedOk) setSessionBodyState(id, { msg: null, prov: null, bodiesOk: false });
    else if (sessionDiskWriteSeqOf(id) === writeSeqAtRead) {
      const prev = sessionBodyState.get(id);
      // dangling 在这里同步算(交出去的 prov.entries 之后归调用方,可能被就地改)。
      setSessionBodyState(id, {
        msg: sessionBodyRecordFromRead(msg, prev && prev.msg, { stampOk: !msg.cut }),
        prov: sessionBodyRecordFromRead(prov, prev && prev.prov, { stampOk: !prov.cut, dangling: danglingTurnState(prov.entries.length, i => prov.entries[i]) }),
        bodiesOk: true,
      });
    }
    // v2 完整可读 → 迁移残留的 v1bak 与慢路径残留 prevbody 快照一并清掉(备份使命已完成;也防无界堆积)。
    await fsp.unlink(sessionPath(id) + '.v1bak').catch(() => {});
    await fsp.unlink(bp.messages + '.prevbody').catch(() => {});
    await fsp.unlink(bp.provider + '.prevbody').catch(() => {});
    delete parsed.storageVersion; // 运行时对象不携带存储标记(保持与 v1 同形),saveSession 落盘时重新加
    delete parsed.messageCount;        // 计数同理:落盘字段,运行时以真数组为准,带出只会是过期副本
    delete parsed.providerHistoryCount;
    legacy = false;
  }
  const { session, changed } = normalizeSession(parsed);
  if (session.id == null) session.id = id;
  // 107-F7b:读到的撤回代数低于进程内高水位 = 这次读恰好落在「撤回已抬水位、它那一存还没落盘」的窗口里
  // (saveSession 抬水位与入链是同一拍,所以此刻撤回那一存一定已经在写链里)。拿着这份旧副本出去的人,
  // 它之后的每一次 save 都会被代数闸丢掉 —— 对撤回【之后】才来读的人,这就是凭空丢数据。所以不交出去:
  // 等写链跑完再读一次。有界两次(staleRetry);reloadDepth 原样传递、不归零,与上面那道守卫的递归合起来
  // 仍然有界。两次之后仍低(只剩「头上压根没有这个字段、又不是经撤回写出来的」那类对象,例如 v1bak 回退)
  // 就照原样返回,由代数闸兜底。
  if ((Number(session.rewindGen) || 0) < (sessionRewindGenHighWater.get(id) || 0) && staleRetry < 2) {
    const inFlight = sessionWriteChains.get(id);
    if (inFlight) await inFlight.catch(() => {});
    return loadSession(id, reloadDepth, staleRetry + 1, view);
  }
  // 116-2a: 内存权威副本盖到装载结果上 —— 用户刚切、但因活回合而延后落盘的那一档,对读者必须立刻生效。
  // 覆盖表没有本会话条目(= 绝大多数情况,含全部存量会话)时这一行是零操作,不置 changed、不触发回写。
  applySessionTitleOverride(session);
  applySessionPermissionModeOverride(session);
  applySessionDesktopToolsOverride(session);   // 117z-E2 提交①:桌面覆盖同款(见它的头注)
  // 71b: 惰性清理残留 pending 叙事段(见 healStalePendingSegments 头注)。竞态防护:活回合(activeChildren)
  // 或 dying turn 收尾窗口(turnSettlers,第69波 rewind 同款判据)内跳过 —— 此时磁盘 pending 可能是活段,
  // 且本会话的收尾 save 会整份重写正文,清理既多余又有互相覆盖风险;下次数 truly idle 的装载再清。
  let healed = false;
  if (!activeChildren.has(session.id) && !turnSettlers.has(session.id)) {
    try { healed = healStalePendingSegments(session); } catch { healed = false; }
  }
  // 不读 provider 正文的视图(见 SESSION_LOAD_OMIT_PROVIDER 头注 ⑤):要回写就让位给完整装载,由它补齐、由它落盘。
  if (lite && (changed || healed)) return loadSession(id, reloadDepth, staleRetry);
  if (legacy) {
    // 懒迁移:标记后无条件 save —— 老会话首次被真正使用时一次性转 v2,之后读写全走新格式。
    Object.defineProperty(session, '__v1bakPending', { value: true, enumerable: false, configurable: true, writable: true });
    await saveSession(session, { writer: 'load_migrate', ifUnwrittenSince: writeSeqAtRead, keepUpdatedAt: true }).catch(() => {});
  } else if (changed || healed) await saveSession(session, { writer: 'load_normalize', ifUnwrittenSince: writeSeqAtRead, keepUpdatedAt: true }).catch(() => {});
  // 75a-2b (S3): seed the in-memory changeSeq high-water from the loaded mission, so bumpMissionChangeSeq
  // increments from the correct base and saveSession's max-preserve works. Reset on crash; re-seeded here.
  if (session.mission && typeof session.mission === 'object') {
    const sid = String(session.id);
    // A load may interleave with an Intervention append already queued in this lifecycle. Seeding must
    // never lower that in-memory high-water mark to the (briefly older) head-file value.
    missionChangeSeqHighWater.set(sid, Math.max(missionChangeSeqHighWater.get(sid) || 0, Number(session.mission.changeSeq) || 0));
  }
  // 账本合并只往 messages 末尾追加(11 的实现:按 backgroundJobId 去重后 push),从不改已有条目 ——
  // 增量取的字节戳(sessionMessagesDelta 的 body)依赖这一点:盘上那 count 条之后的才逐条序列化。
  if (EventStreamHooks.mergeBackgroundJobs) EventStreamHooks.mergeBackgroundJobs(session);
  if (lite) Object.defineProperty(session, '__providerHistoryOmitted', { value: lite.omitted, enumerable: false, configurable: true });
  return session;
}

// 迁移备份回退:<id>.json.v1bak 是 legacy 单文件原样拷贝(写入侧 COPYFILE_EXCL 保证它永不被覆盖)。
// 读出后走正常 legacy 路径(重打迁移标记,save 时 v1bak 已存在 → EXCL 失败被吞,内容不变 —— 幂等)。
// 防线:v1bak 里若是 v2 头(带 storageVersion 且没有 messages 数组),说明备份已被污染/根本不是备份,
// 宁可回退失败走损坏隔离,也绝不拿一个空正文重建会话(那等于丢历史)。
async function loadSessionV1Backup(id) {
  let raw;
  try { raw = await fsp.readFile(sessionPath(id) + '.v1bak', 'utf8'); }
  catch { return null; }
  const parsed = safeJsonParse(raw, null);
  if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') return null;
  if (parsed.storageVersion === SESSION_STORAGE_VERSION) return null;
  const { session } = normalizeSession(parsed);
  if (session.id == null) session.id = id;
  Object.defineProperty(session, '__v1bakPending', { value: true, enumerable: false, configurable: true, writable: true });
  await saveSession(session, { writer: 'load_v1bak_restore', keepUpdatedAt: true }).catch(() => {});
  return session;
}

// Atomic write: serialize to <id>.json.tmp then rename over the target. rename is atomic within a
// volume, so a crash mid-write leaves the previous good file intact instead of a truncated one.
// v1.9 存储 v2(save 侧):头(小)仍 tmp+rename 原子重写;两个正文数组优先 append-only 快路径
// (前缀逐行 hash 比对,见文件头部「会话存储 v2」块注释),任何前缀变化/状态缺失/上次失败 → 全量重写正文。
// 122-§2.4:opts.mergeMissionFromDisk —— 落盘前在【写链内】重读磁盘头,把路由刚写的 mission 合并进来
// (见 mergeMissionBeforeSave)。为什么必须在链内:回合起跑那一存与 POST /api/mission 的那一存是同一条
// 写链上的两个排队者,「链外先 loadSession 再 saveSession」中间还有若干 await,路由的写可以恰好排到两者
// 之间 —— 实测 0 ms 时点 5 轮里就有 1 轮这样丢账本。链内重读则:排在我前面的写一定已落盘(读得到),
// 排在我后面的写一定后落盘(它自己就是权威),两个方向都不丢。只有回合引擎的起跑存传这个旗子。
// 107-F7b:撤回代数闸(见 sessionRewindGenHighWater 头注)。三个旗子:
//   · opts.rewindBump —— 只有 rewindSession 传:在【入写链的同一拍】(下面 ensureDirs 之后那一整段同步代码)
//     把本对象的 rewindGen 加一并抬高水位;前提是本对象自己不低于水位(低于 = 它本身就是另一次撤回之前的
//     旧副本,不抬,按陈旧丢)。与入链同一拍是有意的:任何人一旦看见抬高了的水位,撤回那一存就一定已经
//     排在写链里,loadSession 的自愈「等写链跑完再读」才有东西可等。
//     这一存自己落盘失败 → 链内把水位退回原值(否则盘上仍是旧代数,之后新读的每一份都会被当成陈旧而被丢)。
//   · opts.throwIfStale —— 这次写被闸丢掉时抛 code:'SESSION_STALE_SAVE'(默认静默丢、记日志、照常返回)。
//     要知道「我的改动没落上」的调用方传它:updateSessionMeta 据此在新读的副本上重放补丁;rewindSession
//     据此如实回「被更新的撤回顶掉」,不说 ok:true。
//   · opts.writer —— 只进丢弃日志,事后对账「是谁拿着旧副本来写」。
//   · opts.shrinkBody —— 有意把消息截成原来的前缀(管家归档)。不传时,消息是盘上正文严格前缀的写被当成旧副本、先补齐尾巴再写。
// 撤回那一存抬代数(同步;只由 saveSession 在入链那一拍调)。返回 { gen, prevHighWater } 供落盘失败时退水位;
// 返回 null = 没资格抬:撤回自己手里那份也得是「最新一代」—— 它若是在另一次撤回【之前】读出来的(两次撤回
// 交错:这一次先读、另一次先落盘),它算出来的截断建在旧正文上,落下去会把另一次撤回删掉的消息带回来。
// 这时不抬,saveSession 的闸按陈旧把它丢掉,rewindSession 如实回 rewind_superseded。
function claimRewindGeneration(session) {
  const id = session.id;
  const prevHighWater = sessionRewindGenHighWater.get(id) || 0;
  const objectGen = Number(session.rewindGen) || 0;
  if (objectGen < prevHighWater) return null;
  const gen = objectGen + 1;
  session.rewindGen = gen;
  sessionRewindGenHighWater.set(id, gen);
  return { gen, prevHighWater };
}
async function saveSession(session, opts) {
  // 不读 provider 正文的装载视图(SESSION_LOAD_OMIT_PROVIDER)给出的对象 providerHistory 是占位的 [] —— 落盘就是把真历史清空。
  if (sessionOmittedProviderHistory(session)) throw new Error('refusing to save a session loaded without its provider history');
  await ensureDirs();
  if (EventStreamHooks.mergeBackgroundJobs) EventStreamHooks.mergeBackgroundJobs(session);
  // opts.keepUpdatedAt —— 只有装载回写(补默认字段 load_normalize / 惰性清理残留段 / 懒迁移 load_migrate /
  // v1bak 回退)传:它们不是这条会话的新活动,不许推 updatedAt。修前「打开看一眼」就把会话顶到列表最上面
  // (列表、任务行、搜索命中都按 updatedAt 排)。头上没有可用的旧值才照常取现在。真编辑一律不传,照旧推。
  const keepUpdatedAt = opts && opts.keepUpdatedAt === true && typeof session.updatedAt === 'string'
    && Number.isFinite(Date.parse(session.updatedAt));
  if (!keepUpdatedAt) session.updatedAt = nowIso();
  const id = session.id;
  // 107-F7b:从这里到 sessionWriteChains.set 是一段同步代码,抬水位与入链因此是原子的。
  const rewindBump = opts && opts.rewindBump === true ? claimRewindGeneration(session) : null;
  const saveGen = Number(session.rewindGen) || 0;   // 入链这一拍的代数
  // A model switch may be saved while an old turn still owns an earlier in-memory session object. Preserve
  // the newer UI route across that turn's later save instead of silently reverting the next-turn choice.
  const routeOverride = sessionEngineRouteOverrides.get(id);
  if (routeOverride) session.engineRoute = { ...routeOverride };
  if (sessionEngineRouteScopeOverrides.has(id)) {
    if (sessionEngineRouteScopeOverrides.get(id) === 'thread') session.engineRouteScope = 'thread';
    else delete session.engineRouteScope;
  }
  // 116-2a: 权限档同款陈旧-save 守卫 —— 活回合手里那份副本没有用户刚切的档,它的收尾 save 会把会话头
  // 写回「没有该字段」的样子。在这里重新盖一次,谁后写都不会丢(见 sessionPermissionModeOverrides 头注)。
  applySessionTitleOverride(session);
  applySessionPermissionModeOverride(session);
  applySessionDesktopToolsOverride(session);   // 117z-E2 提交①:桌面覆盖同款(见它的头注)
  const finalPath = sessionPath(id);
  let messages = Array.isArray(session.messages) ? session.messages : [];
  let providerHistory = Array.isArray(session.providerHistory) ? session.providerHistory : [];
  let protectedHead = null, providerRevision = null, protectedCommit = null;
  // 头 = 运行时对象剥掉两个大数组 + 存储标记 + 计数(计数供 listSessions 兜底扫描/sessionMeta 不读正文)。
  const buildHeadPayload = () => {
    if (protectedHead) return JSON.stringify({ ...protectedHead,
      messageCount: messages.length, providerHistoryCount: providerHistory.length,
      providerHistoryRevision: providerRevision, providerHistoryCommit: protectedCommit }, null, 2);
    const head = { ...session };
    const recentUserRequest = sessionRecentUserRequest(session);
    if (recentUserRequest) head.recentUserRequest = recentUserRequest;
    else delete head.recentUserRequest;
    delete head.messages;
    delete head.providerHistory;
    head.storageVersion = SESSION_STORAGE_VERSION;
    head.messageCount = messages.length;
    head.providerHistoryCount = providerHistory.length;
    // 75a-2b (S3): preserve disk-side mission.changeSeq bumps (intervention transitions write the head
    // directly via bumpMissionChangeSeq). Take max with the in-memory high-water so this save's in-memory
    // session object doesn't clobber an intervention's bump. No auto-bump here (bumps are explicit).
    if (head.mission && typeof head.mission === 'object') {
      const hw = missionChangeSeqHighWater.get(id) || 0;
      const cur = Number(head.mission.changeSeq) || 0;
      if (hw > cur) head.mission.changeSeq = hw;
    }
    return JSON.stringify(head, null, 2);
  };
  // Serialize the payload and snapshot the 7 index fields in the SAME synchronous tick, so the background index
  // write reflects EXACTLY what we persist here (no drift if `session` is mutated during the awaits below).
  // 122-§2.4:mergeMissionFromDisk 命中时,链内合并后按合并结果【重算】这两份快照,两者仍然同一拍取样。
  let payload = buildHeadPayload();
  let metaSnapshot = sessionMeta(session);
  // 第25波 25.1: 写体收编进 atomicWriteJson(唯一 tmp 名防并发互踩 + rename 瞬时锁重试 + 失败清 tmp)。
  // 对抗轮修: 同会话并发写者(回合保存 + 节流 flush + updateSessionMeta)此前不串行 —— 加了 rename 重试后,
  // 旧载荷可在 ~680ms 退避后覆写掉新载荷(stale-overwrites-fresh 窗口从 writeFile 粒度拉宽到 680ms)。
  // 按 saveAgentRun 同款 per-id 写链串行化:链内按提交顺序落盘,窗口归零;链错误吞掉(下一写自愈)。
  // v2:整个「正文 append/重写 + 头写」都在链内 —— 进程内状态表与磁盘正文的一致性靠同一条链保证。
  const prevWrite = sessionWriteChains.get(id) || Promise.resolve();
  let preserveRewindOnFailure = false;
  const writeSessionToDisk = async () => {
    // A revision belongs to one body/head snapshot. In protected sessions take all of
    // them together INSIDE the write chain, after earlier same-object saves committed.
    // Stale copies must reload and reapply their explicit edit; never merge old heads.
    let diskHead = null, diskHeadText = null, headExists = false;
    try { diskHeadText = await fsp.readFile(finalPath, 'utf8'); diskHead = JSON.parse(diskHeadText); headExists = true; }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
    if (headExists && (!diskHead || typeof diskHead !== 'object' || Array.isArray(diskHead))) {
      throw Object.assign(new Error('session head is not an object'), { code: 'SESSION_HEAD_UNREADABLE' });
    }
    const stamped = Object.hasOwn(session, 'providerHistoryRevision') || Object.hasOwn(session, 'providerHistoryCommit');
    const diskStamped = headExists && (Object.hasOwn(diskHead, 'providerHistoryRevision') || Object.hasOwn(diskHead, 'providerHistoryCommit'));
    const protectedBody = DesktopExecutionHooks.enabled() || stamped || diskStamped;
    if (protectedBody) {
      const validRevision = value => Number.isSafeInteger(value) && value >= 0;
      const incomingRevision = stamped ? session.providerHistoryRevision : 0;
      const currentRevision = diskStamped ? diskHead.providerHistoryRevision : 0;
      if (stamped && !headExists || !validRevision(incomingRevision) || !validRevision(currentRevision)
          || incomingRevision !== currentRevision || stamped !== diskStamped
          || diskStamped && diskHead.storageVersion !== SESSION_STORAGE_VERSION
          || stamped && (!sessionBodyCommitValid(session) || !sessionBodyCommitValid(diskHead)
            || JSON.stringify(session.providerHistoryCommit) !== JSON.stringify(diskHead.providerHistoryCommit))
          || (Number(session.rewindGen) || 0) !== saveGen
          || diskHead && ((Number(diskHead.turnSeq) || 0) > (Number(session.turnSeq) || 0)
            || (Number(diskHead.rewindGen) || 0) > saveGen)) {
        throw Object.assign(new Error('session provider history changed; reload before applying this edit'), { code: 'SESSION_PROVIDER_HISTORY_CONFLICT' });
      }
      providerRevision = currentRevision;
      // Validate the committed body on both append and rewrite paths. A cached
      // append plan cannot bless a corrupted on-disk head/body as a new commit.
      if (headExists && diskHead.storageVersion === SESSION_STORAGE_VERSION) {
        const [committedMessages, committedProvider] = await Promise.all([
          readSessionBodyFile(sessionBodyPaths(id).messages), readSessionBodyFile(sessionBodyPaths(id).provider)]);
        if (!committedMessages || !committedProvider || committedMessages.corrupt || committedProvider.corrupt
            || committedMessages.unreadable || committedProvider.unreadable
            || committedMessages.entries.length < diskHead.messageCount
            || committedProvider.entries.length < diskHead.providerHistoryCount
            || !sessionBodiesMatchCommit(diskHead, committedMessages, committedProvider)) {
          throw Object.assign(new Error('committed session body must be recovered before saving'), { code: 'SESSION_BODY_UNVERIFIED' });
        }
        // An unchanged stamped head plus its verified byte prefixes identifies an
        // uncommitted append tail. Recover it inside this write chain before planning
        // the next save, including a stopped turn's final pairing after an IO error.
        for (const [body, count, file] of [[committedMessages, diskHead.messageCount, sessionBodyPaths(id).messages],
          [committedProvider, diskHead.providerHistoryCount, sessionBodyPaths(id).provider]]) {
          if (body.entries.length !== count || body.tornAt != null) {
            if (!diskStamped || !await truncateSessionBody(file, count ? body.lineEndBytes[count - 1] : 0)) {
              throw Object.assign(new Error('uncommitted session tail could not be recovered'), { code: 'SESSION_BODY_UNVERIFIED' });
            }
            dropSessionBodyState(id);
          }
        }
      }
    }
    // 122-§2.4:链内落盘前合并 mission(见本函数头注与 mergeMissionBeforeSave)。只读【头文件】就够 ——
    // mission/kind 都在头上;读不到/解析不了(首存、损坏)一律当「磁盘没有账本」,与不传旗子逐字节等价。
    if (opts && opts.mergeMissionFromDisk) {
      let onDiskHead = null;
      try { onDiskHead = JSON.parse(await fsp.readFile(finalPath, 'utf8')); } catch { onDiskHead = null; }
      if (onDiskHead && typeof onDiskHead === 'object' && mergeMissionBeforeSave(session, onDiskHead)) {
        payload = buildHeadPayload();
        metaSnapshot = sessionMeta(session);
      }
    }
    if (protectedBody) {
      // Re-read the LIVE object's arrays, revision and head in one synchronous section;
      // then sever every array/entry reference before doing further asynchronous IO.
      if ((Object.hasOwn(session, 'providerHistoryRevision') || Object.hasOwn(session, 'providerHistoryCommit')) !== stamped
          || (stamped ? session.providerHistoryRevision : 0) !== providerRevision
          || stamped && (!sessionBodyCommitValid(session)
            || JSON.stringify(session.providerHistoryCommit) !== JSON.stringify(diskHead.providerHistoryCommit))
          || (Number(session.rewindGen) || 0) !== saveGen) {
        throw Object.assign(new Error('session changed while preparing its protected snapshot'), { code: 'SESSION_PROVIDER_HISTORY_CONFLICT' });
      }
      messages = Array.isArray(session.messages) ? session.messages : [];
      providerHistory = Array.isArray(session.providerHistory) ? session.providerHistory : [];
      const msgSnapshot = serializeSessionBody(messages), provSnapshot = serializeSessionBody(providerHistory);
      if (!msgSnapshot || !provSnapshot) throw new Error('session body not serializable');
      messages = msgSnapshot.map(line => JSON.parse(line));
      providerHistory = provSnapshot.map(line => JSON.parse(line));
      protectedHead = JSON.parse(buildHeadPayload());
      payload = buildHeadPayload(); metaSnapshot = sessionMeta(JSON.parse(payload));
    }
    const bp = sessionBodyPaths(id);
    // 懒迁移:legacy 单文件先原样备份 v1bak。必须 COPYFILE_EXCL(已存在则失败被吞)—— v1bak 回退
    // 恢复路径也会走到这里,若允许覆盖会把「 pristine legacy 备份」冲成 v2 头,备份使命直接报废。
    if (session.__v1bakPending === true) {
      await fsp.copyFile(finalPath, finalPath + '.v1bak', fs.constants.COPYFILE_EXCL).catch(() => {});
      session.__v1bakPending = false;
    }
    // 记录缺失(条目上限淘汰过 / 重启后没装载就存)→ 先按盘上已提交的内容重建,旧副本补齐与快路径照常可用。
    const state = sessionBodyState.get(id) || await recoverSessionBodyState(id, bp);
    // 旧副本补齐：调用方手里的消息是盘上正文的【严格前缀】（更短、逐行相同）= 它装载之后别的写者又追加过，
    // 它自己并没有删消息（有意删的只有撤回 rewindBump 与管家归档 opts.shrinkBody）。以前这里走慢路径，用旧数组
    // 整份重写 —— 别人刚追加的消息全丢。现在先把盘上多出来的尾巴补进它的数组再写：两边的改动都留下。
    if (!protectedBody && state && state.bodiesOk && !rewindBump && !(opts && opts.shrinkBody) && await rebaseStaleSessionBody(id, bp, state, messages, providerHistory)) {
      payload = buildHeadPayload();
      metaSnapshot = sessionMeta(protectedBody ? JSON.parse(payload) : session);
    }
    const msgPlan = state && state.bodiesOk ? planSessionBodyAppend(messages, state.msg) : null;
    const provPlan = state && state.bodiesOk ? planSessionBodyAppend(providerHistory, state.prov) : null;
    if (protectedBody) {
      if (!headExists || !msgPlan || msgPlan.appendLines.length || !provPlan || provPlan.appendLines.length) {
        if (providerRevision === Number.MAX_SAFE_INTEGER) throw Object.assign(new Error('provider history revision capacity exhausted'), { code: 'SESSION_PROVIDER_HISTORY_CAPACITY' });
        providerRevision += 1;
      }
      protectedCommit = { schema: 1, revision: providerRevision,
        messagesSha256: sessionBodyDigest(serializeSessionBody(messages)), providerSha256: sessionBodyDigest(serializeSessionBody(providerHistory)) };
      payload = buildHeadPayload();
      metaSnapshot = sessionMeta(JSON.parse(payload));
    }
    let nextMsgLines, nextProvLines, protectedRewrite = false;
    if (msgPlan && provPlan) {
      // 快路径:只 append 增量行(0 增量 = 不动正文文件,仅更新头)。
      if (msgPlan.appendLines.length) await fsp.appendFile(bp.messages, msgPlan.appendLines.join('\n') + '\n', 'utf8');
      if (provPlan.appendLines.length) await fsp.appendFile(bp.provider, provPlan.appendLines.join('\n') + '\n', 'utf8');
      nextMsgLines = msgPlan.allLines;
      nextProvLines = provPlan.allLines;
    } else {
      // 慢路径:全量重写两个正文。【崩溃窗口设防】重写前把旧正文快照为 .prevbody(EXCL:已有快照不覆盖
      // —— 在场快照必属「上一个未干净完成的慢路径」,其配对的头更老,覆盖会把一致态快照冲成未提交内容)。
      // 收缩型重写(rewind/compaction 后行数变少)若崩溃于「正文已重写、头未提交」之间,旧头计数 > 新正文
      // 行数,读取侧本会把会话判 corrupt;有 .prevbody 即可回滚到崩溃前的一致态(loadSession 恢复,见下)。
      const msgSer = serializeSessionBody(messages);
      const provSer = serializeSessionBody(providerHistory);
      if (!msgSer || !provSer) throw new Error('session body not serializable');
      if (protectedBody && headExists) {
        const [currentMessages, currentProvider] = await Promise.all([readSessionBodyFile(bp.messages), readSessionBodyFile(bp.provider)]);
        if (diskHead.storageVersion === SESSION_STORAGE_VERSION && (!currentMessages || !currentProvider
            || currentMessages.corrupt || currentProvider.corrupt || currentMessages.unreadable || currentProvider.unreadable
            || currentMessages.entries.length !== diskHead.messageCount || currentProvider.entries.length !== diskHead.providerHistoryCount)) {
          throw Object.assign(new Error('session bodies must be recovered before rewriting'), { code: 'SESSION_BODY_UNVERIFIED' });
        }
        if (Object.hasOwn(diskHead, 'providerHistoryCommit') && !sessionBodiesMatchCommit(diskHead, currentMessages, currentProvider)) {
          throw Object.assign(new Error('committed session body must be recovered before rewriting'), { code: 'SESSION_BODY_UNVERIFIED' });
        }
        // A verified current body makes any previous snapshot stale. Never use an older
        // EXCL snapshot as rollback for this new rewrite if prior cleanup had failed.
        await fsp.unlink(bp.messages + '.prevbody').catch(error => { if (error.code !== 'ENOENT') throw error; });
        await fsp.unlink(bp.provider + '.prevbody').catch(error => { if (error.code !== 'ENOENT') throw error; });
      }
      if (protectedBody && headExists && diskHead.storageVersion === SESSION_STORAGE_VERSION) {
        await fsp.copyFile(bp.messages, bp.messages + '.prevbody', fs.constants.COPYFILE_EXCL);
        await fsp.copyFile(bp.provider, bp.provider + '.prevbody', fs.constants.COPYFILE_EXCL);
      } else {
        await fsp.copyFile(bp.messages, bp.messages + '.prevbody', fs.constants.COPYFILE_EXCL).catch(() => {});
        await fsp.copyFile(bp.provider, bp.provider + '.prevbody', fs.constants.COPYFILE_EXCL).catch(() => {});
      }
      protectedRewrite = protectedBody;
      try {
        await atomicWriteJson(bp.messages, sessionBodyText(msgSer));
        await atomicWriteJson(bp.provider, sessionBodyText(provSer));
      } catch (werr) {
        // 进程内写失败(非崩溃)→ 立即回滚快照,磁盘回到重写前的一致态;bodiesOk=false 由外层标。
        if (protectedBody) {
          await fsp.copyFile(bp.messages + '.prevbody', bp.messages).catch(() => {});
          await fsp.copyFile(bp.provider + '.prevbody', bp.provider).catch(() => {});
        } else {
          await fsp.rename(bp.messages + '.prevbody', bp.messages).catch(() => {});
          await fsp.rename(bp.provider + '.prevbody', bp.provider).catch(() => {});
        }
        throw werr;
      }
      nextMsgLines = msgSer;
      nextProvLines = provSer;
    }
    // 头最后写:头指向的正文状态必须先于头落盘(头=「正文有效」的声明)。
    // Once publication is attempted, only a confirmed unchanged old head permits
    // rolling the rewind watermark back. Lost acknowledgements may have committed.
    if (protectedBody) preserveRewindOnFailure = true;
    try { await atomicWriteJson(finalPath, payload); }
    catch (error) {
      let published = null;
      if (protectedBody) { try { published = await fsp.readFile(finalPath, 'utf8'); } catch { /* unknown commit: preserve both bodies and snapshots */ } }
      if (protectedBody && published === payload) {
        session.providerHistoryRevision = providerRevision; session.providerHistoryCommit = protectedCommit;
      } else if (protectedBody && published === diskHeadText) {
        preserveRewindOnFailure = false;
        if (protectedRewrite) {
          await fsp.copyFile(bp.messages + '.prevbody', bp.messages).catch(() => {});
          await fsp.copyFile(bp.provider + '.prevbody', bp.provider).catch(() => {});
        }
      }
      throw error;
    }
    // The head is the commit point. Cleanup/stat failures must not roll back this fact.
    if (protectedBody) {
      session.providerHistoryRevision = providerRevision;
      session.providerHistoryCommit = protectedCommit;
    }
    // 头已提交 → prevbody 快照使命完成(崩溃于清理前也无妨:下次读取按「头计数==正文行数」判其为陈旧快照,
    // 顺带清除,见 loadSession)。
    await fsp.unlink(bp.messages + '.prevbody').catch(() => {});
    await fsp.unlink(bp.provider + '.prevbody').catch(() => {});
    // 刚写下的行就是盘上的行(canonical);文件戳在写完之后取(链内,没有别的写者)。
    const [msgStamp, provStamp] = await Promise.all([sessionBodyFileStamp(bp.messages), sessionBodyFileStamp(bp.provider)]);
    setSessionBodyState(id, {
      msg: sessionBodyRecord(nextMsgLines, { stamp: msgStamp, canonical: true }),
      prov: sessionBodyRecord(nextProvLines, { stamp: provStamp, canonical: true, dangling: sessionBodyDanglingFromLines(nextProvLines) }),
      bodiesOk: true,
    });
  };
  const thisWrite = prevWrite.catch(() => {}).then(async () => {
    // Compare the caller's captured owner inside the write chain: two admitted drivers can have
    // prepared the same turnSeq. Cancellation alone does not reject the current driver's stopped
    // final save; only replacement/removal of that owner makes this snapshot obsolete.
    if (opts && opts.executionOwner !== undefined && (typeof SessionExecutionHooks.owns !== 'function'
        || !SessionExecutionHooks.owns(id, opts.executionOwner))) {
      logEvent({ kind: 'session_superseded_execution_save_dropped', sessionId: id,
        turnSeq: Number(session.turnSeq) || 0, writer: String(opts.writer || '') });
      return { dropped: true, supersededTurn: true, executionSuperseded: true };
    }
    // hunt2-P2:删除墓碑闸。同撤回代数闸,必须在【链内】看:删除可能发生在这次 save 入链之后、执行之前
    // (被停回合的收尾存正是这么排的)。删除之前就存在的会话对象一律不许再落盘(见 sessionDeleteTombstones 头注)。
    if (sessionSaveIsTombstoned(session)) {
      logEvent({ kind: 'session_deleted_save_dropped', sessionId: id, writer: String((opts && opts.writer) || ''), messageCount: messages.length });
      return { dropped: true, deleted: true };
    }
    // 107-F7b:撤回代数闸。必须在【链内】比:高水位可能在这次写入链之后、执行之前才被抬高(撤回那一存
    // 排在我后面入链、却抬水位在我执行之前)。对象代数低于高水位 = 撤回之前的快照,整次写丢弃 ——
    // 正文与头都不写、不动 sessionBodyState(它仍如实描述盘上的正文),下面的索引/投影刷新也一并跳过。
    const highWater = sessionRewindGenHighWater.get(id) || 0;
    if (saveGen < highWater) {
      logEvent({
        kind: 'session_stale_save_dropped', sessionId: id, staleGen: saveGen, highWater,
        messageCount: messages.length, writer: String((opts && opts.writer) || ''),
      });
      return { dropped: true, staleGen: saveGen, highWater };
    }
    // 回合代数闸(opts.dropIfTurnSuperseded / throwIfTurnSuperseded,只有回合自己的存盘带):盘上的 turnSeq 已经
    // 比这份对象的大 = 这个回合被一个更新的回合顶替过(旧回合卡在不理会中止的工具里,新回合先跑完)。旧回合手里
    // 那份对象的正文不含新回合的消息,照写就把新回合整段盖掉(messages 与 providerHistory 都回到旧样子)。
    // 与撤回代数闸同理必须在【链内】比:新回合起跑那一存可能排在我入链之后、执行之前。只读头文件(turnSeq 在头上);
    // 读不到/解析不了(首存、损坏)一律放行,与不带旗子逐字节等价。
    if (opts && (opts.dropIfTurnSuperseded || opts.throwIfTurnSuperseded)) {
      let diskTurnSeq = 0;
      try { diskTurnSeq = Number(JSON.parse(await fsp.readFile(finalPath, 'utf8')).turnSeq) || 0; } catch { diskTurnSeq = 0; }
      if (diskTurnSeq > (Number(session.turnSeq) || 0)) {
        logEvent({
          kind: 'session_superseded_turn_save_dropped', sessionId: id, turnSeq: Number(session.turnSeq) || 0, diskTurnSeq,
          messageCount: messages.length, writer: String((opts && opts.writer) || ''),
        });
        return { dropped: true, supersededTurn: true, diskTurnSeq };
      }
    }
    // 装载回写(补默认字段/懒迁移)只在「装载那一眼之后没人写过」时才落:否则它拿的是旧副本,会把刚落盘的
    // 消息整份盖回去。比较在链内做 —— 进程内所有写者都串在这条链上,这里看到的计数就是权威答案。
    if (opts && Number.isInteger(opts.ifUnwrittenSince) && sessionDiskWriteSeqOf(id) !== opts.ifUnwrittenSince) {
      logEvent({ kind: 'session_superseded_save_dropped', sessionId: id, writer: String(opts.writer || ''), messageCount: messages.length });
      return { dropped: true, superseded: true };
    }
    bumpSessionDiskWriteSeq(id);
    try { await writeSessionToDisk(); }
    catch (werr) {
      // 撤回那一存自己没落上:盘上仍是旧代数,把水位退回去(只退自己抬的那一格;期间又有更新的撤回
      // 抬过就不动)。在链内退、先于这条链 reject —— 等这条链的 loadSession 自愈醒来时水位已经对了。
      if (rewindBump && !preserveRewindOnFailure && sessionRewindGenHighWater.get(id) === rewindBump.gen) {
        if (rewindBump.prevHighWater > 0) sessionRewindGenHighWater.set(id, rewindBump.prevHighWater);
        else sessionRewindGenHighWater.delete(id);
      }
      throw werr;
    } finally { bumpSessionDiskWriteSeq(id); }   // 落盘前后各一次:读在写的任何一段都能察觉
    return null;
  });
  sessionWriteChains.set(id, thisWrite);
  let dropped = null;
  try { dropped = await thisWrite; }
  catch (e) {
    // 正文/头任何一步失败:标 bodiesOk=false(下次 save 全量重写自愈),再把错误抛给调用方(与旧语义一致:
    // save 失败对调用方可见,回合层自会 .catch)。
    setSessionBodyState(id, { msg: null, prov: null, bodiesOk: false });
    throw e;
  }
  finally { if (sessionWriteChains.get(id) === thisWrite) sessionWriteChains.delete(id); }
  if (dropped) {
    // Execution barriers must distinguish a committed snapshot from a legacy best-effort return.
    // Other callers retain their existing handling of intentionally discarded stale/deleted saves.
    if (opts && opts.requirePersisted === true) {
      throw Object.assign(new Error('session save was not committed; execution must not continue'), {
        code: 'SESSION_SAVE_NOT_COMMITTED',
        reason: dropped.deleted ? 'deleted' : dropped.executionSuperseded ? 'execution_superseded'
          : dropped.supersededTurn ? 'turn_superseded' : 'stale',
      });
    }
    // 107-F7b:被闸丢掉的写。默认静默(日志已落):垂死回合的收尾存、它的中途存都走这里,它们本来就该丢。
    // hunt2-P2:墓碑丢掉的写同样静默 —— 会话已经没了,不是「撤回之前的旧副本」,不抛 SESSION_STALE_SAVE。
    if (dropped.supersededTurn) {
      if (opts && opts.throwIfTurnSuperseded) {
        throw Object.assign(new Error('stale turn save dropped: a newer turn already ran on this session'), {
          code: 'SESSION_TURN_SUPERSEDED', turnSeq: Number(session.turnSeq) || 0, diskTurnSeq: dropped.diskTurnSeq,
        });
      }
      return session;
    }
    if (opts && opts.throwIfStale && !dropped.deleted) {
      throw Object.assign(new Error('stale session save dropped: this copy was loaded before a rewind'), {
        code: 'SESSION_STALE_SAVE', staleGen: dropped.staleGen, highWater: dropped.highWater,
      });
    }
    return session;
  }
  // PF2: queue the sidebar metadata index update (cheap sync Map.set; the write is debounced + coalesced). The
  // index is only a cache and listSessions falls back to a full file scan whenever its id-set drifts from disk.
  scheduleSessionIndexUpdate(id, metaSnapshot);
  markPretenderIndexDirty(id, 'source'); // 75c: session head/body facts changed; rebuild this Mission slice lazily
  // 128f-⑫:会话头每落一次盘就「碰」一下推送层;那边只在这一行看得见的东西变了才真推(13r thread.touched 头注)。
  // 停自动推进、回退、管家接手、预算熔断……这些写口不必各自再记得派一发。
  RUYI_EVENTS.emit('thread.touched', { sessionId: id });
  // v1.9 P-B: 引擎转录白名单账本(仅记录本工作台 spawn 过的 claudeSessionId;GC 只清「账本内 + 无活会话
  // 引用 + 超保留期」三者同时成立的转录,绝不碰用户自己 Claude Code 的转录)。fire-and-forget,账本写失败
  // 不影响会话保存(大不了 GC 永远不碰这条转录 —— 保守方向)。
  if (typeof session.claudeSessionId === 'string' && session.claudeSessionId) {
    void recordEngineTranscript(session.claudeSessionId, session.cwd).catch(() => {});
  }
  return session;
}

// ── 回合收尾那一存(三个引擎共用):带回合代数闸 ──────────────────────────────────────────────────────
// 现象(审计 t4):回合 1 卡在不理会中止的工具里,用户在同一会话发回合 2,回合 2 跑完;回合 1 的工具稍后返回,
// 收尾那一存拿着回合 1 起跑时的旧对象把整份正文写回去 —— 回合 2 的 user/assistant 消息与 providerHistory 全没了。
// 这里用 saveSession 的 throwIfTurnSuperseded:盘上的 turnSeq 比这份对象大就不写。返回 true = 已落盘;
// false = 本回合已被更新的回合顶替,收尾存被丢弃 —— 调用方据此不再派 thread.done / 任务进度(否则把一个
// 过期回合当成「最新一回合结束」广播出去)。一次普通的停止(没有更新的回合)turnSeq 相等,照常落盘。
async function saveTurnFinalSession(session, writer, options = {}) {
  try {
    await saveSession(session, { ...options, throwIfTurnSuperseded: true, writer: String(writer || 'turn-final') });
    return true;
  } catch (e) {
    if (e && e.code === 'SESSION_TURN_SUPERSEDED') return false;
    throw e;
  }
}

// ── 128b(48 号文 §2-b):会话「读-改-写」的唯一原语 ────────────────────────────────────────────────────
// 被撤回闸丢掉的 saveSession 返回值与成功时一模一样,普查出技能／记忆／todo／任务开始更新核验／任务控制／三个引擎的
// 手动压缩／管家拜访归档／工作流摘要追加／管家回复盖章都是「load → 改一点 → save」,撤回插在中间时它们的改动被
// 整份丢掉、接口照样回成功(Brief §4.2 第 15 条)。与 117n-M2 的 mutateConfig 同一个形状:
//   · mutator(session, { attempt }) 在新读的副本上改(可返回 { abort: X } 不落盘、{ value: X } 随行数据);
//   · 保存带 throwIfStale —— 撞上撤回就重新读、重新应用(mutator 必须能重放:它描述的是「要做什么改动」,
//     不是「改完的样子」),有界;连着撞满仍不行抛 session.rewound_during_write,调用方回可读的错误而不是成功;
//   · opts.expectGen:「先花几秒算、再落盘」的慢活(压缩、任务核验)在算之前记下 rewindGen,这里新读到的代数
//     变了(期间撤回过)就不写 —— 基于撤回之前的历史算出来的东西绝不写回去,也不重算(那是调用方的事)。
// 活回合那一侧的丢失更新(回合收尾存拿着旧对象盖掉这里的改动)不归这里管:路由／权限档／桌面工具靠覆盖表、
// 任务账本靠收尾存的 mergeMissionFromDisk、元数据补丁靠 updateSessionMeta 的延后通道,各有既有守卫。
const SESSION_MUTATE_STALE_REPLAYS = 2;
function sessionRewoundError(id, writer) {
  return Object.assign(new Error('这条会话在写入期间被撤回过,这次改动没有落盘,请重试'), {
    code: 'session.rewound_during_write', statusCode: 409, sessionId: id, writer,
  });
}
// hunt2-P4:同一会话的「load → 改 → save」整段按 id 串行。修前两路并发的 mutateSession(todo 与技能、
// 记忆与 backgroundJobSeen……)各自读到同一份旧头、各改各的字段、后存者整份盖掉先存者 —— 撤回闸管不到这种
// 同代数的丢失更新(实测 20/20 丢一边)。saveSession 自己的 per-id 写链只串「写」,串不了「读-改-写」。
// 不会死锁的理由(改这里之前先读):
//   · 链内只做 loadSession / mutator / saveSession。loadSession 只会【等】写链(sessionWriteChains)、
//     saveSession 只会【排进】写链,写链里跑的只有落盘,从不回头等这条链 —— 两条链之间只有单向等待;
//   · 活回合的收尾存直接走 saveSession,不进这条链,所以回合永远不必等这里;这条链也从不等回合 settle
//     (updateSessionMeta 的延后通道在【进链之前】等 settle);
//   · 约定:mutator 里不得再对【同一个 id】调 mutateSession / updateSessionMeta(会自己等自己)。
//     现有调用方的 mutator 都是纯内存改动加至多一次只读 I/O(unit/session-mutate.test.js 的 [M6] 钉并发)。
const sessionMutateChains = new Map();
function withSessionMutateLock(id, work) {
  return runKeyedChain(sessionMutateChains, String(id == null ? '' : id), work);
}
async function mutateSession(id, mutator, opts = {}) {
  return withSessionMutateLock(id, async () => {
    const writer = String((opts && opts.writer) || 'mutate_session');
    const expectGen = opts && opts.expectGen != null ? Number(opts.expectGen) || 0 : null;
    for (let attempt = 0; ; attempt++) {
      const session = await loadSession(id);
      if (!session) return { ok: false, missing: true, session: null, value: undefined };
      if (expectGen !== null && (Number(session.rewindGen) || 0) !== expectGen) {
        logEvent({ kind: 'session_mutate_rewound', sessionId: id, writer, expectGen, gen: Number(session.rewindGen) || 0 });
        throw sessionRewoundError(id, writer);
      }
      const decision = await mutator(session, { attempt });
      const d = (decision && typeof decision === 'object') ? decision : {};
      if (Object.prototype.hasOwnProperty.call(d, 'abort')) return { ok: false, session, value: d.abort };
      try {
        await saveSession(session, { ...((opts && opts.saveOpts) || {}), throwIfStale: true, writer });
        return { ok: true, session, value: d.value, attempts: attempt + 1 };
      } catch (error) {
        if (!(error && error.code === 'SESSION_STALE_SAVE')) throw error;
        if (expectGen !== null || attempt >= SESSION_MUTATE_STALE_REPLAYS) {
          logEvent({ kind: 'session_mutate_rewound', sessionId: id, writer, attempt: attempt + 1, expectGen });
          throw sessionRewoundError(id, writer);
        }
        logEvent({ kind: 'session_mutate_replayed', sessionId: id, writer, attempt: attempt + 1 });
      }
    }
  });
}
// 一份内存里的会话对象是不是撤回之前读出来的(驱动器、旁车写入用它判「还该不该接着干」)。
function sessionObjectIsStale(session) {
  if (!session || !session.id) return false;
  return (Number(session.rewindGen) || 0) < (sessionRewindGenHighWater.get(session.id) || 0);
}

// 50-fix(标题卡死):未命名标题判定 —— 后端占位 'New session' 与历史前端本地化占位('新会话'/'New chat')
// 均视为未命名,两引擎回合结束据此自动命名(历史会话下一轮补名)。
function isUntitledSessionTitle(title) {
  const v = String(title || '').trim();
  return !v || v === 'New session' || v === '新会话' || v === 'New chat';
}

const IMPORTED_MESSAGE_ROLE_MAX = 32;
// 安全走查 S10:导入来的消息是外来文本(可能是别人分享的会话文件、含伪造的「用户已授权…」对话),每条打来源标记
// meta.imported:true,让这条线程里的内容始终能被认出是导入的。meta【整个替换】而不是合并:文件自带的 meta
// (比如伪造 origin:'agent_wake' / 'inbox' 去走界面里那几条特殊渲染)一律丢掉。
function sanitizeImportedSessionMessages(raw) {
  if (!Array.isArray(raw)) return [];
  return raw.filter(m => m && typeof m === 'object' && !Array.isArray(m)
    && typeof m.role === 'string' && m.role.trim() && m.role.length <= IMPORTED_MESSAGE_ROLE_MAX
    && (m.content == null || typeof m.content === 'string' || Array.isArray(m.content)))
    .map(m => ({ ...m, meta: { imported: true } }));
}

async function createSession({ title, cwd, origin, engineRoute }) {
  const id = makeId('sess');
  sessionDeleteTombstones.delete(id);   // hunt2-P2:新建的会话绝不继承同名旧会话的删除墓碑
  const config = await readConfig();
  // 导入会话(POST /api/sessions 的 messages,来自用户选的 JSON 文件)同样不可信:修前 [null] 让建会话 500
  // (而且半截落了盘),数字/字符串元素原样进正文。只收【普通对象 + 非空字符串 role + content 缺省或为字符串/数组】
  // 的条目,其余丢掉 —— 这就是展示消息的形状(assistant 的 content 可以是 '',正文在 segments 里)。
  const initialMessages = sanitizeImportedSessionMessages(arguments[0]?.messages);
  // title / cwd 来自 POST /api/sessions 与 /api/chat/stream 的请求体,类型不可信:修前 {"cwd":5} 原样落盘,
  // 这条会话此后每一回合都死在 path.resolve(5);对象/数组标题会原样回给列表(前端 .trim() 的雷)。
  // 非字符串或空白一律当没传;标题上限与 applySessionMetaPatch 改名同为 200。
  const safeTitle = typeof title === 'string' && title.trim() ? title.slice(0, 200) : undefined;
  const safeCwd = typeof cwd === 'string' && cwd.trim() ? cwd : undefined;
  const session = {
    id,
    schemaVersion: SESSION_SCHEMA,
    turnSeq: 0,
    title: safeTitle || 'New session',
    summary: '',
    pinned: false,
    cwd: safeCwd || config.defaultWorkspace || os.homedir(),
    createdAt: nowIso(),
    updatedAt: nowIso(),
    claudeSessionId: null,
    messages: initialMessages,
    providerHistory: [],
    providerHistoryCursor: 0,
    privacyHistoryV1: false, // Fresh disabled sessions bypass legacy-reference migration entirely.
    attachments: [],
    // 123-N2:四层优先级搬进 newSessionEngineRoute(见那里的头注)。修前这一行是
    // `inferSessionEngineRoute({messages}) || sessionEngineRouteFromConfig(config)` —— 即今天的
    // ②||④,新增的是最前面的 ①(显式入参)与中间的 ③(上一次用的)。
    engineRoute: newSessionEngineRoute(config, engineRoute, initialMessages, id),
    mission: null, // 第26波b: 任务账本(见 normalizeMission)
    missionId: id, // 75a (D1 plan B): stable Mission identity, written for new sessions (== sessionId in 3.0)
    kind: 'quick_ask', // 第70波(EC-E):显式 Quick Ask 标识;mission start 时翻转 'mission'(见 13-http-router /api/mission)
    // 第 121 波 K3(34 号文 §4.1「来源三值」):这条线程是谁开的。**只在这里写一次,此后终身不变**,
    // 且【不在】 applySessionMetaPatch 的白名单里(理由与 createdBy 同一条,见那里的注释锚)。
    // 三值 'steward' | 'user' | 'schedule':管家族两条建线程的路径(13k thread_new / quick_ask)显式传
    // 'steward';119 波的定时任务落地后由它自己传 'schedule';其余一律 'user'。非法值当没传。
    // 存量会话头没有这个字段:读侧由 06i 的 threadOriginOf 现场派生,**不回写**(索引是纯派生物,
    // 为了补一个字段去改几百个会话文件不值得,而且那会把 sourceStamp 全体打脏)。
    origin: (origin === 'steward' || origin === 'schedule') ? origin : 'user',
    // 116-5a(§11.8.3):建会话时就带了一个【不是占位符】的标题 = 这条线程已经有名字了,不必再花一次
    // 模型调用去起名。判据复用既有的 isUntitledSessionTitle(中英占位集,双引擎自动命名共用同一个),
    // 所以经典壳送来的「新会话」/「New chat」仍然算没名字。与「用户手改标题」写的是同一个字段:
    // 显示优先级只有一条 —— 人给的名字 > 生成的名字 > 原话。
    ...(isUntitledSessionTitle(safeTitle) ? {} : { titleSource: 'user' }),
  };
  // 落盘前就补齐 normalizeSession 的默认字段(todos / skills / memories / memoriesExplicit / memoryExclusions ……)。
  // 修前新会话头缺这几个键,第一次 loadSession 判 changed → load_normalize 回写 —— 光是「点开看一眼」就把
  // updatedAt 推到现在,这条会话跳到列表最上面(rail-session-search 浏览器件在 Windows CI 上偶发红的根因)。
  normalizeSession(session);
  await saveSession(session);
  // 121-K2a(§6.1 第 4 条):新线程。missionId 在 3.0 里建会话时 == sessionId(见上面那一行),
  // 真正归到别的任务是后来 missionAttachThread 的事(它自己派 thread.adopted)。
  RUYI_EVENTS.emit('thread.created', { sessionId: id, missionId: String(session.missionId || ''), title: String(session.title || '') });
  return session;
}

// ============================================================================
// v0.8-S4a — Checkpoint journal (信任层核心). Layout under dataRoot/checkpoints/<sessionId>/:
//   index.json                 [{turnSeq, entrySeq, tool, path, op:'create'|'modify'|'delete', bytes, skipped?, ts}]
//   <turnSeq>-<entrySeq>.gz    zlib.gzipSync(before content) — op:'create' has NO .gz (before never existed)
//   history-<turnSeq>.json.gz  (S5 providerHistory snapshot — only the directory convention is reserved here)
//
// DUAL-PROCESS INVARIANT: the journal is FILESYSTEM-LEVEL shared state. Both engines write the SAME
// dataRoot/checkpoints dir — the provider engine's toolCall() runs in the serve process; the Claude
// engine's workbench tools run in the one-shot MCP child. This is race-free by construction: within one
// session, only ONE engine runs a turn at any instant, so there is never concurrent writing to a given
// session's checkpoints dir. The MCP child must NOT write session files (S3 invariant) but CAN write the
// checkpoints dir (independent of session files → no contention with the serve process's saveSession).
//
// SAFETY-NET, NOT A GATE: any journal failure is swallowed (try/catch) and MUST NOT block tool execution.
// A journal write that throws simply skips its index entry; the tool runs regardless. The trade-off is
// deliberate — a checkpoint is a safety net, and a broken safety net must never stop the user's work.
// ============================================================================
const JOURNAL_MAX_BEFORE_BYTES = 5 * 1024 * 1024;   // >5MB before-content → skipped:true, content not stored
const JOURNAL_KEEP_TURNS = 20;                       // per-session GC: keep the most recent 20 turnSeqs
const JOURNAL_GLOBAL_MAX_BYTES = (() => {
  const n = Number(process.env.RUYI_JOURNAL_GLOBAL_MAX_BYTES); // env override for e2e; default 200MB
  return Number.isFinite(n) && n > 0 ? n : 200 * 1024 * 1024;
})();  // global cap: purge oldest sessions (dir mtime) over this
// PF1: the global size cap used to run a full dirSize() sweep of EVERY session's checkpoint tree on every
// checkpoint-triggering file write (O(all checkpoint files), awaited before the tool returns) - so a single
// tool call's latency grew with the app's TOTAL checkpoint history (a 50-edit workflow = 50 full sweeps).
// We now keep a process-local APPROXIMATE running total of checkpoint bytes and use it only to decide whether
// the authoritative full sweep is worth running. SAFETY: the cache NEVER authorizes a purge - purges always
// run off a fresh full sweep that also recalibrates the cache. The cache can only SKIP the sweep when
// confidently under budget, so a stale or under-counting cache costs at most one extra sweep, never a missed
// cleanup. Recalibrated on cold start, every JOURNAL_GC_RECALIBRATE_EVERY calls, and when the estimate nears
// the cap. Process-local by design: the serve process and the one-shot MCP child each calibrate via their own
// authoritative sweeps (which see ALL sessions on disk regardless of writer), so correctness needs no sharing.
let journalGlobalBytes = null;            // cached approx total bytes of paths.checkpoints (null = uncalibrated)
let journalGcSinceScan = 0;               // journalGc calls since the last authoritative full sweep
const JOURNAL_GC_RECALIBRATE_EVERY = 64;  // force a real sweep at least this often (bounds cache drift)
const JOURNAL_GC_SCAN_HYSTERESIS = 0.9;   // sweep once the estimate reaches this fraction of the hard cap
// Probe (exported) so the PF1 e2e can assert the sweep does NOT run on every call yet still purges over-cap.
const journalGcProbe = { fullScans: 0, calls: 0 };
// PF1 fix: ALL running-total mutations funnel through journalBytesAdjust so byte accounting lives in one place
// and a full sweep can't silently clobber concurrent writers. A sweep measures disk truth across several awaits
// (readdir/stat/dirSize per session); other sessions' writers may `+=` during that window. Recording those
// deltas here lets the sweep replay them onto its recalibrated total instead of overwriting them (an overwrite
// would re-introduce a small under-count -> a possibly-missed sweep). SAFETY: this cache NEVER authorizes a
// purge (purges run off fresh dirSize), so any drift costs at most an extra sweep, never a missed cleanup.
let journalSweeping = 0;                   // in-flight authoritative sweeps (measurement windows currently open)
let journalDeltaDuringSweep = 0;           // net bytes changed by writers while any sweep is measuring
function journalBytesAdjust(delta) {
  if (!delta) return;
  if (journalGlobalBytes != null) journalGlobalBytes = Math.max(0, journalGlobalBytes + delta);
  if (journalSweeping > 0) journalDeltaDuringSweep += delta; // replayed after the sweep recalibrates from truth
}
// Parallel sub-agents may checkpoint different files in the same parent turn. Serialize each session's
// read-modify-write index transaction so entrySeq stays unique and a later write cannot overwrite an
// earlier agent's index entry. Different sessions retain full concurrency.
const journalWriteChains = new Map(); // sessionId -> Promise

async function withJournalWriteLock(sessionId, work) {
  return runKeyedChain(journalWriteChains, String(sessionId || ''), work);
}

function journalDir(sessionId) { return path.join(paths.checkpoints, assertSessionIdForPath(sessionId)); }
function journalIndexPath(sessionId) { return path.join(journalDir(sessionId), 'index.json'); }

// Read a session's checkpoint index (array of entries). Missing/corrupt → []. Never throws.
async function journalReadIndex(sessionId) {
  try {
    const raw = await fsp.readFile(journalIndexPath(sessionId), 'utf8');
    const arr = safeJsonParse(raw, null);
    return Array.isArray(arr) ? arr : [];
  } catch { return []; }
}

// hunt2 #18:写者(record / drop / GC)用的严格读。宽松版把【任何】读错误都当成「没有条目」,下一次 record
// 就用 [新条目] 整份盖掉索引 —— Windows 上杀毒/索引器与双进程(serve + MCP 子进程)撞出的一次 EBUSY/EPERM
// 就把这条会话全部检查点抹掉(entrySeq 还从 0 重来,覆写既有 .gz)。这里只有 ENOENT 才算空;别的读错误照抛,
// 由调用方的安全网 catch 转成 journal_write_error(本次不记,既有条目不动)。内容坏了(非 JSON / 非数组)
// 读重试也好不了,原样改名隔离成 index.json.corrupt-<时间戳> 留作取证,再按空索引继续,检查点功能自愈。
async function journalReadIndexForWrite(sessionId) {
  const file = journalIndexPath(sessionId);
  let raw;
  try { raw = await fsp.readFile(file, 'utf8'); }
  catch (e) { if (e && e.code === 'ENOENT') return []; throw e; }
  const arr = safeJsonParse(raw, null);
  if (Array.isArray(arr)) return arr;
  await fsp.rename(file, `${file}.corrupt-${Date.now()}`);
  logEvent({ kind: 'journal_index_quarantined', sessionId: String(sessionId || '') });
  return [];
}

// Atomic index write. Never throws (caller wraps). 第25波 25.1: 收编进 atomicWriteJson。
// 对抗轮修: retries:0 —— 该文件是【跨进程多写者】(serve 进程 + MCP 子进程各持独立 journalWriteChains,
// 进程间无法串行),rename 重试会让旧载荷在 ~680ms 退避后覆写掉别进程刚落的新条目(丢检查点)。
// 保持旧的 fail-fast 语义:输给并发写者就立刻失败(调用方本就 best-effort 包裹),绝不迟到覆写。
// hunt2 #13:紧凑 JSON(不缩进)—— 索引每记一条就整份重写一次,缩进让体积与序列化时间都翻倍。
async function journalWriteIndex(sessionId, entries) {
  const dir = journalDir(sessionId);
  await fsp.mkdir(dir, { recursive: true });
  await atomicWriteJson(journalIndexPath(sessionId), JSON.stringify(entries), { retries: 0 });
}

// hunt2 #6:本回合下一个 entrySeq = 本回合现有最大值 + 1。修前取「本回合条目数」—— 中间的条目被
// journalDropEntries / 单条回滚删掉之后,条目数会等于某个仍在的 entrySeq,新条目撞号并覆写它的 .gz
// (并行子代理共用父回合的 turnSeq,实测回滚把 p3 还原成了 p4 的内容)。
function journalNextEntrySeq(index, turnSeq) {
  let max = -1;
  for (const e of index) {
    if (e && Number(e.turnSeq) === Number(turnSeq) && Number.isFinite(Number(e.entrySeq))) max = Math.max(max, Number(e.entrySeq));
  }
  return max + 1;
}

// Resolve the current turnSeq for a checkpoint entry.
//  - serve process (provider engine): the caller passes the closure's session.turnSeq (authoritative).
//  - MCP child (Claude engine): read the session file (READ-ONLY, no race) via WCW_SESSION_ID env and take
//    its turnSeq. Missing env / unreadable file → null → the caller skips journaling (tool still runs).
async function journalResolveTurnSeq(sessionId, explicitTurnSeq) {
  if (Number.isFinite(explicitTurnSeq)) return Number(explicitTurnSeq);
  if (!sessionId) return null;
  try {
    const raw = await fsp.readFile(sessionPath(sessionId), 'utf8');
    const parsed = safeJsonParse(raw, null);
    const t = parsed && Number(parsed.turnSeq);
    return Number.isFinite(t) ? t : null;
  } catch { return null; }
}

// Record a `before` checkpoint for a file mutation, BEFORE the tool executes. Returns nothing meaningful;
// all failures are swallowed so the tool proceeds unimpeded. `beforeContent` is a Buffer|string for
// modify/delete, or null for create (nothing to save). op ∈ 'create'|'modify'|'delete'. entrySeq is the
// per-turn running count (derived from how many entries already exist for this turnSeq).
async function journalRecord(sessionId, turnSeq, tool, filePath, op, beforeContent) {
  return withJournalWriteLock(sessionId, () => journalRecordUnlocked(sessionId, turnSeq, tool, filePath, op, beforeContent));
}

async function journalRecordUnlocked(sessionId, turnSeq, tool, filePath, op, beforeContent) {
  const [result] = await journalRecordManyUnlocked(sessionId, turnSeq, [{ tool, filePath, op, beforeContent }]);
  return result;
}

// hunt2 #13:批量记账 —— 一批条目只读一次索引、写一次索引、跑一次 GC。逐条 journalRecord 每条都整份读改写
// 索引,批量调用方(archive_unzip 最多 2000 条、CLI 回合收尾的 turn_baseline 对账)随条目数平方增长:
// 实测 1000 条 ~5s、2000 条 ~22s,期间 JSON 读写同步占着事件循环。返回与 rows 一一对应的结果数组
// (每项同 journalRecord 的返回值,多一个 entrySeq)。任一步失败 = 整批都没记(索引一次写入,不存在半批)。
async function journalRecordMany(sessionId, turnSeq, rows) {
  return withJournalWriteLock(sessionId, () => journalRecordManyUnlocked(sessionId, turnSeq, rows));
}

async function journalRecordManyUnlocked(sessionId, turnSeq, rows) {
  const list = Array.isArray(rows) ? rows : [];
  // b2-P0: 不再静默 no-op —— 返回 { ok:false, reason } 让调用方(file_delete 等不可逆操作)能中止并披露。
  if (!sessionId || !Number.isFinite(turnSeq)) return list.map(() => ({ ok: false, reason: 'no_session_context' }));
  if (!list.length) return [];
  try {
    const dir = journalDir(sessionId);
    await fsp.mkdir(dir, { recursive: true });
    const index = await journalReadIndexForWrite(sessionId);
    let nextSeq = journalNextEntrySeq(index, turnSeq); // per-turn autoincrement (hunt2 #6: max+1)
    const results = [];
    for (const { tool, filePath, op, beforeContent } of list) {
      const entrySeq = nextSeq++;
      let bytes = 0, skipped = false;
      if (op !== 'create' && beforeContent != null) {
        // Workspace turn baselines may discover a pre-change file whose bytes they could not (oversized) or
        // must not (git read failed) load. Such a caller passes a non-Buffer `{ skippedBytes }` marker: always
        // recorded as the honest non-revertible entry, never as a fabricated snapshot (hunt2 #4: 修前只认
        // >5MB 的标记,小于上限的标记会被 String() 成 "[object Object]" 存进 .gz)。Ordinary tool callers
        // continue to pass Buffer|string exactly as before.
        const marker = !Buffer.isBuffer(beforeContent) && typeof beforeContent === 'object'
          && Number.isFinite(Number(beforeContent.skippedBytes));
        const buf = marker ? null : (Buffer.isBuffer(beforeContent) ? beforeContent : Buffer.from(String(beforeContent), 'utf8'));
        bytes = marker ? Number(beforeContent.skippedBytes) : buf.length;
        if (marker || bytes > JOURNAL_MAX_BEFORE_BYTES) {
          // Too large to snapshot — record the entry as skipped (rollback of this entry will fail loudly).
          skipped = true;
        } else {
          const gz = zlib.gzipSync(buf); // built-in zlib — zero npm
          await fsp.writeFile(path.join(dir, `${turnSeq}-${entrySeq}.gz`), gz);
          journalBytesAdjust(gz.length); // PF1: keep the size-cap cache current
        }
      }
      index.push({ turnSeq: Number(turnSeq), entrySeq, tool: String(tool || ''), path: String(filePath || ''), op, bytes, ...(skipped ? { skipped: true } : {}), ts: nowIso() });
      results.push(skipped ? { ok: true, skipped: true, entrySeq } : { ok: true, entrySeq });
    }
    await journalWriteIndex(sessionId, index);
    // v1.4.1 (audit #8):必须 await —— 此前 detached 触发,GC 的 index.json 读改写会与下一条 journalRecord 竞争,
    // 修剪写回时可覆盖刚追加的条目(lost-write → 该文件变更不可撤销)。await 让 GC 在下一条 record 前完成,
    // 消除并发。GC 内部全 try/catch 静默,不抛。hunt2 #13:把刚写下的索引交给 GC,省掉它再读一遍。
    await journalGc(sessionId, index).catch(() => {});
    return results;
  } catch {
    // Safety-net discipline: a failed journal write must NOT abort the tool. Swallow and continue — the
    // index entry simply isn't written, and the file operation runs as if the journal weren't there.
    return list.map(() => ({ ok: false, reason: 'journal_write_error' }));
  }
}

// Turn-level workspace baseline. Ruyi native file tools checkpoint before every mutation, but Claude CLI's
// own Edit/Write/Bash tools run in a separate process and do not pass through TOOL_DISPATCH. Capture the
// workspace before a turn and reconcile it before turn_summary so those edits receive the same exact
// before/current diff and rollback entry. Git workspaces avoid an O(repository bytes) snapshot: only paths
// already dirty at turn start are copied; clean tracked files are reconstructed from the captured HEAD blob.
// Non-Git folders fall back to a bounded source/text snapshot. This remains a safety net, never a turn gate.
const WORKSPACE_BASELINE_EXTS = new Set([
  'txt', 'log', 'md', 'markdown', 'rst', 'adoc', 'csv', 'tsv', 'json', 'jsonc', 'xml', 'yaml', 'yml',
  'toml', 'ini', 'cfg', 'conf', 'editorconfig', 'js', 'mjs', 'cjs', 'jsx', 'ts', 'mts', 'cts', 'tsx',
  'py', 'pyi', 'rb', 'php', 'java', 'kt', 'kts', 'scala', 'groovy', 'go', 'rs', 'swift', 'dart', 'lua',
  'c', 'h', 'cc', 'cpp', 'cxx', 'hpp', 'hxx', 'cs', 'fs', 'fsx', 'vb', 'sql', 'graphql', 'gql',
  'css', 'scss', 'sass', 'less', 'html', 'htm', 'vue', 'svelte', 'astro', 'sh', 'bash', 'zsh', 'fish',
  'ps1', 'psm1', 'bat', 'cmd', 'gradle', 'properties', 'tex', 'proto', 'cmake', 'dockerfile',
]);
const WORKSPACE_BASELINE_NAMES = new Set(['dockerfile', 'makefile', 'gnumakefile', 'rakefile', 'gemfile', 'procfile']);
const WORKSPACE_BASELINE_SKIP_DIRS = new Set([
  '.git', '.hg', '.svn', 'node_modules', 'vendor', 'dist', 'build', 'out', 'target', '.next', '.nuxt',
  '.cache', '.turbo', 'coverage', '__pycache__', '.venv', 'venv', '.idea', '.vs', '.gradle',
]);
const WORKSPACE_BASELINE_MAX_FILES = 8000;
const WORKSPACE_BASELINE_MAX_MEMORY = 40 * 1024 * 1024;
// Turn startup must stay responsive even in very large monorepos. Git index scans and the non-Git tree
// fallback share this wall-clock budget; once it expires, reconciliation is deliberately restricted to
// paths whose "before" state was captured exactly (partial coverage is safer than false attribution).
const WORKSPACE_BASELINE_DEFAULT_BUDGET_MS = 2000;

function workspaceBaselineBudgetMs() {
  const configured = Number(process.env.RUYI_WORKSPACE_BASELINE_BUDGET_MS);
  return Number.isFinite(configured) && configured > 0
    ? Math.max(250, Math.min(15000, Math.floor(configured)))
    : WORKSPACE_BASELINE_DEFAULT_BUDGET_MS;
}

function workspaceBaselineRemainingMs(deadline, cap = 10000) {
  return Math.max(0, Math.min(cap, Math.ceil(Number(deadline) - Date.now())));
}

function workspaceBaselineBudgetOnly(root, budgetMs, startedAt) {
  return { kind: 'budget', root, truncated: true, truncatedReason: 'time_budget', capturedBytes: 0,
    budgetMs, elapsedMs: Math.max(0, Date.now() - startedAt), capturedAt: nowIso() };
}

function workspaceBaselinePathKey(filePath) {
  const resolved = path.resolve(String(filePath || ''));
  return process.platform === 'win32' ? resolved.toLowerCase() : resolved;
}

function workspaceBaselineIsCodePath(filePath) {
  const base = path.basename(String(filePath || '')).toLowerCase();
  if (WORKSPACE_BASELINE_NAMES.has(base)) return true;
  const ext = path.extname(base).replace(/^\./, '');
  return WORKSPACE_BASELINE_EXTS.has(ext);
}

async function workspaceBaselineFileSnapshot(filePath, memoryState) {
  try {
    const st = await fsp.lstat(filePath);
    if (!st.isFile() || st.isSymbolicLink()) return { exists: false };
    const row = { exists: true, size: st.size, mtimeMs: st.mtimeMs };
    if (st.size > JOURNAL_MAX_BEFORE_BYTES || memoryState.bytes + st.size > WORKSPACE_BASELINE_MAX_MEMORY) {
      return { ...row, skippedBytes: st.size };
    }
    const content = await fsp.readFile(filePath);
    memoryState.bytes += content.length;
    return { ...row, content };
  } catch { return { exists: false }; }
}

function workspaceBaselineNulPaths(raw) {
  return String(raw || '').split('\0').filter(Boolean);
}

function workspaceBaselineGitAbs(repoRoot, relativePath, scopeRoot) {
  const abs = path.resolve(repoRoot, String(relativePath || '').replace(/\//g, path.sep));
  return pathWithinRoot(abs, scopeRoot) && workspaceBaselineIsCodePath(abs) ? abs : '';
}

async function workspaceBaselineGitNames(repoRoot, head, deadline = Date.now() + 20000) {
  const paths = [];
  let truncated = false;
  const collect = async args => {
    const remaining = workspaceBaselineRemainingMs(deadline);
    if (!remaining) { truncated = true; return; }
    const result = await runGit(args, repoRoot, remaining);
    if (!result.ok) { truncated = true; return; }
    paths.push(...workspaceBaselineNulPaths(result.stdout));
  };
  // 审计 B:回合开头自动跑的这条 diff 同样会触发仓库自带的 clean 过滤器与子模块递归(比 git_status 还隐蔽:
  // 不需要任何工具调用)—— 与 11 的只读 git 工具共用同一道护栏;护栏读不出配置就当扫描不完整(truncated)。
  const guard = await gitReadOnlyGuard(repoRoot, workspaceBaselineRemainingMs(deadline) || 1000);
  if (!guard.ok) return { paths: [], truncated: true };
  await collect([...guard.flags, '-C', repoRoot, 'diff', '--no-renames', '--no-ext-diff', '--no-textconv', '--ignore-submodules=dirty', '--name-only', '-z', head, '--']);
  await collect(['-C', repoRoot, 'ls-files', '--others', '--exclude-standard', '-z', '--']);
  if (Date.now() >= deadline) truncated = true;
  return { paths: [...new Set(paths)], truncated };
}

async function captureGitWorkspaceBaseline(scopeRoot, deadline) {
  let remaining = workspaceBaselineRemainingMs(deadline, 5000);
  if (!remaining) return null;
  // Canonicalize the scope root once: CI runners may address the temp workspace via an 8.3 short name
  // (RUNNER~1) or a junction, while Git's rev-parse --show-toplevel always returns the long/real spelling.
  // Comparing those two spellings would silently downgrade the git fast path to a full tree scan.
  scopeRoot = await realpathForContainment(scopeRoot);
  const repoProbe = await runGit(['-C', scopeRoot, 'rev-parse', '--show-toplevel'], scopeRoot, remaining);
  if (!repoProbe.ok) return null;
  const repoRoot = path.resolve(String(repoProbe.stdout || '').trim());
  if (!repoRoot || !pathWithinRoot(scopeRoot, repoRoot)) return null;
  remaining = workspaceBaselineRemainingMs(deadline, 5000);
  if (!remaining) return null;
  const headProbe = await runGit(['-C', repoRoot, 'rev-parse', 'HEAD'], repoRoot, remaining);
  if (!headProbe.ok) return null; // unborn repository -> bounded tree fallback
  const head = String(headProbe.stdout || '').trim();
  if (!/^[a-f0-9]{40,64}$/i.test(head)) return null;
  const dirty = new Map();
  const memoryState = { bytes: 0 };
  const names = await workspaceBaselineGitNames(repoRoot, head, deadline);
  let truncated = names.truncated;
  for (const rel of names.paths) {
    if (Date.now() >= deadline) { truncated = true; break; }
    const abs = workspaceBaselineGitAbs(repoRoot, rel, scopeRoot);
    if (!abs) continue;
    dirty.set(workspaceBaselinePathKey(abs), { path: abs, rel: String(rel).replace(/\\/g, '/'), snapshot: await workspaceBaselineFileSnapshot(abs, memoryState) });
  }
  return { kind: 'git', root: scopeRoot, repoRoot, head, dirty, truncated,
    truncatedReason: truncated ? 'time_budget_or_git_scan' : '', capturedBytes: memoryState.bytes, capturedAt: nowIso() };
}

async function captureTreeWorkspaceBaseline(scopeRoot, deadline = Number.POSITIVE_INFINITY) {
  const files = new Map();
  const memoryState = { bytes: 0 };
  const queue = [scopeRoot];
  let visited = 0, truncated = false, truncatedReason = '';
  while (queue.length && visited < WORKSPACE_BASELINE_MAX_FILES) {
    if (Date.now() >= deadline) { truncated = true; truncatedReason = 'time_budget'; break; }
    const dir = queue.shift();
    const rows = await fsp.readdir(dir, { withFileTypes: true }).catch(() => []);
    for (const row of rows) {
      if (Date.now() >= deadline) { truncated = true; truncatedReason = 'time_budget'; break; }
      if (visited >= WORKSPACE_BASELINE_MAX_FILES) { truncated = true; truncatedReason = 'file_limit'; break; }
      const filePath = path.join(dir, row.name);
      if (row.isSymbolicLink()) continue;
      if (row.isDirectory()) {
        if (!WORKSPACE_BASELINE_SKIP_DIRS.has(row.name.toLowerCase())) queue.push(filePath);
        continue;
      }
      if (!row.isFile() || !workspaceBaselineIsCodePath(filePath)) continue;
      visited += 1;
      files.set(workspaceBaselinePathKey(filePath), { path: filePath, snapshot: await workspaceBaselineFileSnapshot(filePath, memoryState) });
    }
  }
  if (queue.length && !truncated) { truncated = true; truncatedReason = 'file_limit'; }
  return { kind: 'tree', root: scopeRoot, files, truncated, truncatedReason,
    capturedBytes: memoryState.bytes, capturedAt: nowIso() };
}

async function captureWorkspaceTurnBaseline(cwd) {
  const startedAt = Date.now();
  const budgetMs = workspaceBaselineBudgetMs();
  const deadline = startedAt + budgetMs;
  try {
    const root = path.resolve(String(cwd || ''));
    const st = await fsp.stat(root);
    if (!st.isDirectory()) return null;
    if (Date.now() >= deadline) return workspaceBaselineBudgetOnly(root, budgetMs, startedAt);
    const gitBaseline = await captureGitWorkspaceBaseline(root, deadline);
    if (gitBaseline) return { ...gitBaseline, budgetMs, elapsedMs: Math.max(0, Date.now() - startedAt) };
    if (Date.now() >= deadline) return workspaceBaselineBudgetOnly(root, budgetMs, startedAt);
    // A session accidentally rooted at the drive or user-home level must not scan thousands of unrelated
    // personal files. Git repositories are handled above; the bounded tree fallback is for actual projects.
    const home = path.resolve(os.homedir());
    if (root === path.parse(root).root || workspaceBaselinePathKey(root) === workspaceBaselinePathKey(home)) return null;
    const treeBaseline = await captureTreeWorkspaceBaseline(root, deadline);
    return { ...treeBaseline, budgetMs, elapsedMs: Math.max(0, Date.now() - startedAt) };
  } catch { return null; }
}

async function workspaceBaselineGitBefore(baseline, absPath, after) {
  const key = workspaceBaselinePathKey(absPath);
  if (baseline.dirty.has(key)) return baseline.dirty.get(key).snapshot;
  const rel = path.relative(baseline.repoRoot, absPath).replace(/\\/g, '/');
  if (!rel || rel.startsWith('../') || path.isAbsolute(rel)) return { exists: false };
  // hunt2 #4:修前 `git show HEAD:rel` 按 utf8 解码再 Buffer.from 回去(GBK 文件的每个汉字都成了 U+FFFD,回滚把
  // 乱码写回盘),且任何 git 失败(10s 超时、blob 超 24MB 输出上限)都被当成「回合前不存在」→ 记成 create,
  // 回滚时直接删掉用户改过的文件。现在:ls-tree 分清「HEAD 里没有」(真·新建)与「git 读失败」;失败给
  // 「存在但内容未知」的标记,journalRecord 记为 skipped(回滚时如实报失败,绝不删文件);blob 按原字节取。
  const unknown = { exists: true, skippedBytes: JOURNAL_MAX_BEFORE_BYTES + 1, unknownBefore: true };
  const listed = await runGit(['-C', baseline.repoRoot, '--literal-pathspecs', 'ls-tree', '-l', '-z', baseline.head, '--', rel], baseline.repoRoot, 10000);
  if (!listed.ok) return unknown;
  const row = String(listed.stdout || '').split('\0').find(Boolean);
  if (!row) return { exists: false }; // HEAD 里确实没有这个路径 → 回合内新建
  const m = /^(\d+) (\S+) ([0-9a-f]+)\s+(-|\d+)\t/i.exec(row);
  if (!m) return unknown;
  // 符号链接 / 子模块:快照器(lstat)一律视为「不存在」,两边同口径才不会凭空记出一条 delete。
  if (m[2] !== 'blob' || m[1] === '120000') return { exists: false };
  const blobSize = Number(m[4]);
  if (Number.isFinite(blobSize) && blobSize > JOURNAL_MAX_BEFORE_BYTES) return { exists: true, size: blobSize, skippedBytes: blobSize };
  // cat-file blob 取原字节、不跑任何过滤器。刻意不用 `cat-file --filters`:它会执行仓库 .git/config 里配置的
  // filter.*.smudge/process 外部程序 —— 与 GIT_SAFE_FLAGS 头注里 fsmonitor / diff.external 同一类「看一眼陌生仓库
  // 即执行它指定的程序」。换行转换改由 workspaceBaselineGitCheckoutCrlf 只按 git 内建的 eol 规则复现。
  const blob = await runGit(['-C', baseline.repoRoot, 'cat-file', 'blob', m[3]], baseline.repoRoot, 10000, { encoding: 'buffer' });
  if (!blob.ok || !Buffer.isBuffer(blob.stdout)) return unknown;
  let content = blob.stdout;
  const crlf = await workspaceBaselineGitCheckoutCrlf(baseline, rel, content);
  if (crlf === null) return unknown;
  // autocrlf=true 下 LF 的工作区文件同样算「干净」(自己写的 LF 文件提交后从没被 git 重新检出过)。回合后的文件
  // 仍是纯 LF(一个 CR 都没有)时,按它原本就是 LF 处理 —— 编辑工具保留原换行,这比 git 的检出规则更贴近回合前。
  const afterIsPureLf = after && Buffer.isBuffer(after.content) && after.content.includes(0x0a) && !after.content.includes(0x0d);
  if (crlf && !afterIsPureLf) content = workspaceBaselineLfToCrlf(content);
  return content.length > JOURNAL_MAX_BEFORE_BYTES
    ? { exists: true, size: content.length, skippedBytes: content.length }
    : { exists: true, size: content.length, content };
}

// hunt2 #4(续):HEAD 里存的是 LF,Git for Windows 默认 core.autocrlf=true,干净的工作区文件是 CRLF。直接把 blob
// 写回会把用户的 CRLF 文件整份改成 LF。这里只复现 git 检出时【内建】的换行转换(text/eol 属性、core.autocrlf、
// core.eol),不执行任何外部过滤器:返回 true = 检出时会转成 CRLF;false = 原样;null = git 查询失败(内容未知)。
async function workspaceBaselineGitCheckoutCrlf(baseline, rel, blob) {
  if (baseline.eolConfig === undefined) {
    const get = async key => {
      const r = await runGit(['-C', baseline.repoRoot, 'config', '--get', key], baseline.repoRoot, 5000);
      return r.ok ? String(r.stdout || '').trim().toLowerCase() : '';
    };
    baseline.eolConfig = { autocrlf: await get('core.autocrlf'), eol: await get('core.eol') };
  }
  const { autocrlf, eol: coreEol } = baseline.eolConfig;
  const attrs = await runGit(['-C', baseline.repoRoot, 'check-attr', '-z', 'text', 'eol', '--', rel], baseline.repoRoot, 5000);
  if (!attrs.ok) return null;
  const parts = String(attrs.stdout || '').split('\0');
  const attr = {};
  for (let i = 0; i + 2 < parts.length; i += 3) attr[parts[i + 1]] = parts[i + 2];
  const text = attr.text || 'unspecified';
  const eol = attr.eol || 'unspecified';
  if (text === 'unset') return false;                                  // -text:二进制,永不转换
  const explicitText = text === 'set' || eol === 'crlf' || eol === 'lf';
  const autoText = !explicitText && (text === 'auto' || autocrlf === 'true' || autocrlf === 'input');
  if (!explicitText && !autoText) return false;                        // 未声明为文本、也没开 autocrlf:原样
  // auto 判定:含 NUL 视为二进制;blob 里已有 CR 的不转换(git 的「安全」规则,避免 \r\r\n)。
  if (autoText && (blob.includes(0) || blob.includes(0x0d))) return false;
  if (eol === 'crlf') return true;
  if (eol === 'lf') return false;
  if (autocrlf === 'true') return true;
  if (autocrlf === 'input') return false;
  return coreEol === 'crlf' || ((coreEol === '' || coreEol === 'native') && process.platform === 'win32');
}

function workspaceBaselineLfToCrlf(buf) {
  const out = [];
  let start = 0;
  for (let i = 0; i < buf.length; i += 1) {
    if (buf[i] === 0x0a && (i === 0 || buf[i - 1] !== 0x0d)) { out.push(buf.subarray(start, i), Buffer.from([0x0d])); start = i; }
  }
  out.push(buf.subarray(start));
  return Buffer.concat(out);
}

function workspaceBaselineSnapshotsEqual(before, after) {
  if (!!(before && before.exists) !== !!(after && after.exists)) return false;
  if (!before || !before.exists) return true;
  if (Buffer.isBuffer(before.content) && Buffer.isBuffer(after.content)) return before.content.equals(after.content);
  return Number(before.size) === Number(after.size) && Number(before.mtimeMs) === Number(after.mtimeMs);
}

async function reconcileWorkspaceTurnBaseline(baseline, sessionId, turnSeq) {
  if (!baseline || !sessionId || !Number.isFinite(Number(turnSeq))) return { recorded: 0, skipped: true };
  try {
    if (baseline.kind === 'budget') {
      logEvent({ kind: 'turn_workspace_reconcile', sessionId, turnSeq: Number(turnSeq), baseline: baseline.kind,
        recorded: 0, truncated: true, truncatedReason: baseline.truncatedReason, budgetMs: baseline.budgetMs,
        elapsedMs: baseline.elapsedMs, capturedBytes: 0 });
      return { recorded: 0, skipped: false, truncated: true, truncatedReason: baseline.truncatedReason };
    }
    const existing = (await journalReadIndex(sessionId))
      .filter(e => e && Number(e.turnSeq) === Number(turnSeq) && e.path)
      .map(e => workspaceBaselinePathKey(e.path));
    const existingPaths = new Set(existing);
    const candidates = new Map();
    let reconcileTruncated = !!baseline.truncated;
    let truncatedReason = baseline.truncatedReason || '';
    if (baseline.kind === 'git') {
      for (const row of baseline.dirty.values()) candidates.set(workspaceBaselinePathKey(row.path), row.path);
      // A partial start scan cannot prove that an unseen path was clean before the turn. Only expand the
      // candidate set when coverage was complete; otherwise keep the exact dirty snapshots already captured.
      if (!baseline.truncated) {
        const names = await workspaceBaselineGitNames(baseline.repoRoot, baseline.head);
        if (names.truncated) { reconcileTruncated = true; truncatedReason = 'git_reconcile_scan'; }
        for (const rel of names.paths) {
          const abs = workspaceBaselineGitAbs(baseline.repoRoot, rel, baseline.root);
          if (abs) candidates.set(workspaceBaselinePathKey(abs), abs);
        }
      }
    } else {
      for (const row of baseline.files.values()) candidates.set(workspaceBaselinePathKey(row.path), row.path);
      const afterTree = await captureTreeWorkspaceBaseline(baseline.root);
      baseline.afterTree = afterTree;
      if (afterTree.truncated) { reconcileTruncated = true; truncatedReason = afterTree.truncatedReason || 'tree_reconcile_scan'; }
      // As above, paths absent from a truncated start baseline have an unknown "before" state. Do not label
      // them as creates. Captured paths remain safe to compare and retain useful partial coverage.
      if (!baseline.truncated) {
        for (const row of afterTree.files.values()) candidates.set(workspaceBaselinePathKey(row.path), row.path);
      }
    }
    let recorded = 0;
    // hunt2 #13:攒批记账(见 journalRecordMany 头注)。按条数/字节分批,免得一个大回合把所有 before 同时攥在内存里。
    let pending = [], pendingBytes = 0;
    const flush = async () => {
      if (!pending.length) return;
      const batch = pending;
      pending = []; pendingBytes = 0;
      const results = await journalRecordMany(sessionId, Number(turnSeq), batch);
      batch.forEach((row, i) => { if (results[i] && results[i].ok) { recorded += 1; existingPaths.add(row.key); } });
    };
    for (const [key, filePath] of candidates) {
      if (existingPaths.has(key) || !workspaceBaselineIsCodePath(filePath)) continue;
      const after = baseline.kind === 'tree' && baseline.afterTree.files.has(key)
        ? baseline.afterTree.files.get(key).snapshot
        : await workspaceBaselineFileSnapshot(filePath, { bytes: 0 });
      const before = baseline.kind === 'git'
        ? await workspaceBaselineGitBefore(baseline, filePath, after)
        : (baseline.files.get(key) || { snapshot: { exists: false } }).snapshot;
      if (workspaceBaselineSnapshotsEqual(before, after)) continue;
      const op = before.exists ? (after.exists ? 'modify' : 'delete') : 'create';
      const beforeContent = op === 'create' ? null
        : (Buffer.isBuffer(before.content) ? before.content : { skippedBytes: Number(before.skippedBytes || before.size || (JOURNAL_MAX_BEFORE_BYTES + 1)) });
      pending.push({ key, tool: 'turn_baseline', filePath, op, beforeContent });
      pendingBytes += Buffer.isBuffer(beforeContent) ? beforeContent.length : 0;
      if (pending.length >= 200 || pendingBytes >= 16 * 1024 * 1024) await flush();
    }
    await flush();
    if (recorded || reconcileTruncated) {
      logEvent({ kind: 'turn_workspace_reconcile', sessionId, turnSeq: Number(turnSeq), baseline: baseline.kind,
        recorded, truncated: reconcileTruncated, truncatedReason, budgetMs: Number(baseline.budgetMs) || undefined,
        elapsedMs: Number(baseline.elapsedMs) || undefined, capturedBytes: Number(baseline.capturedBytes) || 0 });
    }
    return { recorded, skipped: false, truncated: reconcileTruncated, truncatedReason };
  } catch { return { recorded: 0, skipped: true }; }
}

// b3-P2: Drop the journal entries recorded for (turnSeq, tool, path∈paths) — used to roll back
// PHANTOM checkpoints when a multi-step operation (file_move/file_copy) fails AFTER recording
// before-snapshots but BEFORE the actual mutation lands. Without this, a failed move would leave
// rollback entries describing an operation that never happened (a phantom journal), and a later
// rollback would act on files that were never touched. All failures are silent (rollback of the
// phantom is best-effort; the caller already reported the real operation failure to the model).
// entrySeqs(可选):只删这几个 entrySeq 的条目 —— 调用方知道自己刚记了哪几条时传入,同一回合早先涉及同一
// 路径、同一工具的条目(例如本回合先把 X 移到 A、再把 A 移走)不受牵连。空数组 = 一条也不删。
async function journalDropEntries(sessionId, turnSeq, tool, paths, entrySeqs) {
  return withJournalWriteLock(sessionId, () => journalDropEntriesUnlocked(sessionId, turnSeq, tool, paths, entrySeqs));
}

async function journalDropEntriesUnlocked(sessionId, turnSeq, tool, paths, entrySeqs) {
  try {
    if (!sessionId || !Number.isFinite(turnSeq)) return { ok: false, reason: 'no_session_context' };
    const dir = journalDir(sessionId);
    const index = await journalReadIndexForWrite(sessionId);
    if (!index.length) return { ok: true, dropped: 0 };
    const seqSet = Array.isArray(entrySeqs) ? new Set(entrySeqs.map(Number)) : null;
    const pathSet = new Set((paths || []).map(p => String(p)));
    const kept = [];
    let dropped = 0;
    for (const e of index) {
      const hit = e && Number(e.turnSeq) === Number(turnSeq)
        && e.tool === String(tool || '') && pathSet.has(String(e.path || ''))
        && (!seqSet || seqSet.has(Number(e.entrySeq)));
      if (hit) {
        dropped += 1;
        if (!e.skipped && e.op !== 'create') {
          const gzp = path.join(dir, `${e.turnSeq}-${e.entrySeq}.gz`);
          const st = await fsp.stat(gzp).catch(() => null);
          await fsp.unlink(gzp).catch(() => {});
          if (st) journalBytesAdjust(-st.size);
        }
        continue;
      }
      kept.push(e);
    }
    if (dropped) await journalWriteIndex(sessionId, kept);
    return { ok: true, dropped };
  } catch {
    return { ok: false, reason: 'journal_drop_error' };
  }
}

// GC. (1) Per-session: keep only the most recent JOURNAL_KEEP_TURNS turnSeqs; drop older entries + their
// .gz files. (2) Global: if the whole checkpoints/ tree exceeds JOURNAL_GLOBAL_MAX_BYTES, remove entire
// oldest sessions (by dir mtime) until under budget. All failures are silent.
// knownIndex:调用方(持会话写锁)刚写下的索引,传入即不再重读(hunt2 #13)。
async function journalGc(sessionId, knownIndex) {
  let freedBytes = 0; // PF1: bytes reclaimed by the per-session prune below, to decrement the size-cap cache
  try {
    const dir = journalDir(sessionId);
    const index = Array.isArray(knownIndex) ? knownIndex : await journalReadIndexForWrite(sessionId);
    if (index.length) {
      const turns = [...new Set(index.map(e => Number(e.turnSeq)))].sort((a, b) => a - b);
      if (turns.length > JOURNAL_KEEP_TURNS) {
        const keep = new Set(turns.slice(turns.length - JOURNAL_KEEP_TURNS));
        const kept = [];
        for (const e of index) {
          if (keep.has(Number(e.turnSeq))) { kept.push(e); continue; }
          if (!e.skipped && e.op !== 'create') {
            const gzp = path.join(dir, `${e.turnSeq}-${e.entrySeq}.gz`);
            const st = await fsp.stat(gzp).catch(() => null); // real on-disk size (best-effort) for the cache decrement
            await fsp.unlink(gzp).catch(() => {});
            if (st) freedBytes += st.size;
          }
        }
        await journalWriteIndex(sessionId, kept);
      }
    }
  } catch { /* silent */ }
  try {
    journalGcProbe.calls++;
    // PF1: keep the running estimate current with what the per-session prune just reclaimed (never below 0).
    if (freedBytes) journalBytesAdjust(-freedBytes);
    journalGcSinceScan++;
    // Decide whether the authoritative full sweep is worth running. Sweep when: uncalibrated (cold start),
    // periodic recalibration is due (drift correction), or the estimate is near/over the cap. Otherwise the
    // common case (well under budget) SKIPS the O(all-checkpoint-files) sweep entirely - the whole point of PF1.
    const needSweep = journalGlobalBytes == null
      || journalGcSinceScan >= JOURNAL_GC_RECALIBRATE_EVERY
      || journalGlobalBytes >= JOURNAL_GLOBAL_MAX_BYTES * JOURNAL_GC_SCAN_HYSTERESIS;
    if (!needSweep) return; // fast path: confidently under budget, no sweep
    // 上一轮因为【受保护会话自己就超限】而没能清到线下:在冷却期内别每次写都再全量扫一遍(那是 O(全部检查点文件),且清不动)。
    if (Date.now() < journalSweepBackoffUntil) return;
    // 性能批 C3:只是「定期重新校准」(冷启动、每 64 次)而估算明显低于上限时,全量扫描(逐个 stat 所有检查点文件,
    // 6 万个文件要 4 秒多)挪到后台、单飞 —— 修前这一次扫描就压在某一次文件编辑的工具调用上。估算已经接近 / 超过上限
    // (真要删东西)时照旧同步等它做完。例外是冷启动后的第一次(估算还没有):那一轮也在后台跑,首次编辑返回时超额的
    // 旧检查点可能还在,几秒内由这一轮清掉 —— 上限在启动后头一轮扫描结束前是「尽快」而不是「硬」(审查轮如实记下)。
    // 每会话自己的修剪(上面)仍然同步,不碰 v1.4.1 那条竞争。
    const overBudget = journalGlobalBytes != null && journalGlobalBytes >= JOURNAL_GLOBAL_MAX_BYTES * JOURNAL_GC_SCAN_HYSTERESIS;
    // 触发这次清扫的会话就是此刻正在写快照 / 检查点的那一条 —— 清扫不许把它自己的目录当「最旧」清掉(见 journalGlobalSweep)。
    if (overBudget) await journalGlobalSweepOnce(sessionId);
    else void journalGlobalSweepOnce(sessionId);
  } catch { /* silent */ }
}

let journalSweepInFlight = null;
// 清扫期间「别动」的会话(触发它的写者,含单飞期间并进来的后到写者)。清扫在每次 rm 之前现查这张表;清扫结束即清空,
// 所以它只管【这一轮】,不会让陈旧条目长期免疫(上限仍然有效,见 e2e checkpoint-gc-cache ②/④)。
const journalSweepProtect = new Set();
let journalSweepBackoffUntil = 0;          // 受保护会话自己超限、清不到线下时的冷却截止时刻(见 journalGlobalSweep 末尾)
const JOURNAL_SWEEP_BACKOFF_MS = 30 * 1000;
function journalGlobalSweepOnce(protectSessionId) {
  if (protectSessionId) journalSweepProtect.add(String(protectSessionId));
  if (!journalSweepInFlight) {
    journalSweepInFlight = journalGlobalSweep().catch(() => {}).finally(() => { journalSweepInFlight = null; journalSweepProtect.clear(); });
  }
  return journalSweepInFlight;
}
// 受保护会话在整仓仍超上限时,最多再清掉它自己最旧的历史快照(history-*.json.gz),但永远保留最近这么几份:
// 刚写下、模型视图里 rawRef 正指着的快照不能被「瘦身」清掉。检查点原件(<回合>-<序号>.gz,回滚用)一份都不动。
const JOURNAL_KEEP_HISTORY_SNAPSHOTS = 4;
async function journalTrimProtectedSnapshots(dir, bytesToFree) {
  let freed = 0;
  const ents = await fsp.readdir(dir, { withFileTypes: true }).catch(() => []);
  const rows = [];
  for (const ent of ents) {
    if (!ent.isFile() || !/^history-\d+(?:-[a-f0-9]{16})?\.json\.gz$/.test(ent.name)) continue;
    const st = await fsp.stat(path.join(dir, ent.name)).catch(() => null);
    if (st) rows.push({ name: ent.name, size: st.size, mtime: st.mtimeMs });
  }
  rows.sort((a, b) => a.mtime - b.mtime); // 最旧在前
  const removable = rows.slice(0, Math.max(0, rows.length - JOURNAL_KEEP_HISTORY_SNAPSHOTS));
  for (const r of removable) {
    if (freed >= bytesToFree) break;
    await fsp.unlink(path.join(dir, r.name)).then(() => { freed += r.size; }).catch(() => {});
  }
  return freed;
}
async function journalGlobalSweep() {
  journalGcProbe.fullScans++;
  journalGcSinceScan = 0;
  journalSweeping++;
  const deltaMark = journalDeltaDuringSweep; // writer deltas already counted BEFORE this window opened
  try {
    // Authoritative sweep: sum every session dir, purge whole sessions oldest-first when over budget, and
    // RECALIBRATE the cache from measured truth. This is the ONLY writer that resets journalGlobalBytes, so a
    // purge decision is always made against real bytes, never the estimate.
    const root = paths.checkpoints;
    const names = await fsp.readdir(root).catch(() => []);
    const dirs = [];
    let total = 0;
    for (const name of names) {
      const p = path.join(root, name);
      const st = await fsp.stat(p).catch(() => null);
      if (!st || !st.isDirectory()) continue;
      const size = await dirSize(p);
      total += size;
      dirs.push({ p, size, mtime: st.mtimeMs });
    }
    if (total > JOURNAL_GLOBAL_MAX_BYTES) {
      dirs.sort((a, b) => a.mtime - b.mtime); // oldest first
      // 修前这里谁最旧清谁,连【正在写快照的那一条会话】自己也在内:一条会话自己的检查点树超过上限(1M 窗口模型每次压缩都写一份
      // 带内容哈希的整史快照,几十份就是上百 MB),清扫把它整个目录删光 —— 刚返回给上下文压缩的 rawRef 立刻 ENOENT,
      // observation_recall 回 `observation recall failed: ENOENT`,连它的文件回滚点也一并消失。现在:触发清扫的写者与有活回合的会话
      // 不整目录清;其余照旧最旧优先。仍超限时只削受保护会话自己最旧的历史快照(见 journalTrimProtectedSnapshots)。
      const isProtected = d => { const name = path.basename(d.p); return journalSweepProtect.has(name) || activeChildren.has(name); };
      for (const d of dirs) {
        if (total <= JOURNAL_GLOBAL_MAX_BYTES) break;
        if (isProtected(d)) continue;
        await fsp.rm(d.p, { recursive: true, force: true }).catch(() => {});
        total -= d.size;
      }
      let trimmedBytes = 0;
      if (total > JOURNAL_GLOBAL_MAX_BYTES) {
        for (const d of dirs) {
          if (total <= JOURNAL_GLOBAL_MAX_BYTES) break;
          if (!isProtected(d)) continue;
          const freed = await journalTrimProtectedSnapshots(d.p, total - JOURNAL_GLOBAL_MAX_BYTES);
          total -= freed; trimmedBytes += freed;
        }
      }
      // 受保护会话自己仍超限:宁可暂时超上限(下一次它不再是写者时照常按最旧优先清),也不删正在用的回滚点与最近快照。
      // 这一轮一点都削不动(只剩保留份额内的快照 / 回滚点)才进冷却,否则每次写都白扫一遍全仓。
      if (total > JOURNAL_GLOBAL_MAX_BYTES) {
        if (trimmedBytes === 0) journalSweepBackoffUntil = Date.now() + JOURNAL_SWEEP_BACKOFF_MS;
        logEvent({ kind: 'journal_cap_exceeded_protected', totalBytes: total, capBytes: JOURNAL_GLOBAL_MAX_BYTES });
      } else journalSweepBackoffUntil = 0;
    }
    // Recalibrate from measured truth, then replay the writer bytes that landed DURING this window so a
    // concurrent journalRecord's increment isn't clobbered (PF1: without this the cache could drift LOW ->
    // a missed sweep). Double-counting a byte already on disk when measured only inflates the estimate,
    // which is the SAFE direction (an extra sweep that recalibrates, never a skipped cleanup).
    const windowDelta = journalDeltaDuringSweep - deltaMark;
    journalGlobalBytes = Math.max(0, total + windowDelta);
  } finally {
    journalSweeping--;
    if (journalSweeping === 0) journalDeltaDuringSweep = 0; // reset once no sweep is measuring
  }
}

// Sum the byte size of a directory tree (best-effort; errors count as 0).
async function dirSize(dir) {
  let total = 0;
  const entries = await fsp.readdir(dir, { withFileTypes: true }).catch(() => []);
  for (const ent of entries) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) total += await dirSize(p);
    else { const st = await fsp.stat(p).catch(() => null); if (st) total += st.size; }
  }
  return total;
}

// Roll back checkpoint entries for a turn. entrySeq given = single entry; omitted = the whole turn
// (all entries for that turnSeq, in REVERSE order). Inverse ops: delete→write `before` back;
// modify→write `before` back; create→unlink the current file. skipped:true entries fail (no stored
// content) and are listed in `failed` without aborting the rest. Reverted entries are REMOVED from the
// index (idempotent: rolling back the same turn again → {ok:false,error:'no entries'}). The rollback
// action itself is NEVER journaled (anti-recursion). Returns {ok, reverted:[{path,op,turnSeq,entrySeq,tool,ts}], failed:[{path,reason}]}.
async function journalRollback(sessionId, turnSeq, entrySeq) {
  const dir = journalDir(sessionId);
  const index = await journalReadIndex(sessionId);
  const tSeq = Number(turnSeq);
  let targets = index.filter(e => e && Number(e.turnSeq) === tSeq);
  if (entrySeq !== undefined && entrySeq !== null && entrySeq !== '') {
    const eSeq = Number(entrySeq);
    targets = targets.filter(e => Number(e.entrySeq) === eSeq);
  }
  if (!targets.length) return { ok: false, error: 'no entries' };
  // Reverse order so multiple mutations to the same file unwind to the earliest recorded `before`.
  targets = targets.slice().sort((a, b) => b.entrySeq - a.entrySeq);
  // 安全审计 #8:index.json 是盘上的数据,不是可信输入 —— 条目里的 path 会被原样写回(或删掉)。修前不验:谁能改
  // index.json(检查点目录曾是文件工具可写的数据根子树)就能借「回滚」把任意内容落到任意位置。现在每条都按【写】
  // 重过一遍与文件工具同一个闸(三层硬地板 + 受保护数据 + 包含判定;包含判定用读根集合,见 guardFileToolPath
  // 的 rootSet:'read' 注),权限档按会话当前的有效档位(宽写档下工作区外的合法条目照样能回滚)。不过闸的条目
  // 不动盘、记进 failed(原因 path-denied),其余照常回滚;它们留在索引里。序号不是整数的条目同样拒(.gz 文件名由它拼)。
  let guardSession = null, guardConfig = null;
  try { guardSession = await loadSession(sessionId); } catch { guardSession = null; }
  try { guardConfig = await readConfig(); } catch { guardConfig = {}; }
  const guardCtx = {
    session: guardSession, config: guardConfig,
    effectivePermissionMode: resolvePermissionMode({ session: guardSession, config: guardConfig }),
  };
  const reverted = [], failed = [], revertedKeys = new Set();
  for (const e of targets) {
    const key = `${e.turnSeq}-${e.entrySeq}`;
    try {
      if (!Number.isSafeInteger(Number(e.turnSeq)) || !Number.isSafeInteger(Number(e.entrySeq))) {
        failed.push({ path: typeof e.path === 'string' ? e.path : '', reason: 'path-denied: malformed checkpoint entry' });
        continue;
      }
      if (typeof e.path !== 'string' || !e.path || !path.isAbsolute(e.path)) {
        failed.push({ path: typeof e.path === 'string' ? e.path : '', reason: 'path-denied: checkpoint path is not absolute' });
        continue;
      }
      const g = await guardFileToolPath(e.path, guardCtx, { tool: 'checkpoint_rollback', write: true, rootSet: 'read' });
      if (!g || !g.ok) {
        logEvent({ kind: 'checkpoint_rollback_denied', sessionId: String(sessionId || ''), turnSeq: Number(e.turnSeq), entrySeq: Number(e.entrySeq), code: (g && g.code) || '' });
        failed.push({ path: e.path, reason: `path-denied: ${(g && g.error) || 'blocked by the file write guard'}` });
        continue;
      }
      if (e.skipped) { failed.push({ path: e.path, reason: 'before content was not stored (too large)' }); continue; }
      if (e.op === 'create') {
        await fsp.unlink(e.path).catch(() => {}); // idempotent: gone already is fine
      } else {
        // modify | delete → restore the gzipped before content
        const gz = await fsp.readFile(path.join(dir, `${e.turnSeq}-${e.entrySeq}.gz`));
        const before = zlib.gunzipSync(gz);
        await fsp.mkdir(path.dirname(e.path), { recursive: true });
        // Atomic restore (tmp + rename, same discipline as saveSession): the trust layer's own rollback
        // must be lossless — a crash (power loss / kill) mid-writeFile would TRUNCATE the user's file,
        // which is exactly the harm checkpoints exist to prevent. rename is atomic within a volume, so a
        // crash leaves either the pre-rollback file or the fully-restored one, never a torn write.
        const tmpRestore = e.path + '.tmp';
        await fsp.writeFile(tmpRestore, before);
        await fsp.rename(tmpRestore, e.path);
        await fsp.unlink(path.join(dir, `${e.turnSeq}-${e.entrySeq}.gz`)).catch(() => {});
      }
      // C4:turnSeq / entrySeq / tool / ts 是加字段(既有读者只看 path / op)—— 路由据此给 reverts.json 记「哪一回合的哪次修改被撤了」。
      reverted.push({ path: e.path, op: e.op, turnSeq: Number(e.turnSeq), entrySeq: Number(e.entrySeq), tool: typeof e.tool === 'string' ? e.tool : '', ts: typeof e.ts === 'string' ? e.ts : '' });
      revertedKeys.add(key);
    } catch (err) {
      failed.push({ path: e.path, reason: (err && err.message) ? err.message : String(err) });
    }
  }
  // Remove the successfully-reverted entries from the index (idempotency). Failed ones stay so a retry
  // is possible. The rollback is NOT journaled — no new checkpoint entries are created here.
  const remaining = index.filter(e => !revertedKeys.has(`${e.turnSeq}-${e.entrySeq}`));
  await journalWriteIndex(sessionId, remaining).catch(() => {});
  return { ok: reverted.length > 0, reverted, failed };
}

// ── C4(61 号文):检查点对模型可见 —— 「用户在界面撤销了什么」的记录 ──────────────────────────────────────
// journalRollback 撤销成功的条目会从 index.json 里【删掉】:之后既没有地方回答「这一条已被用户撤销」,模型也无从知道用户
// 撤过 —— 下一轮它可能基于已被撤回的内容接着干。这里在检查点目录里另起一个旁车 <checkpoints>/<sid>/reverts.json,记两件事:
//   ① checkpoint_list(12)给撤销过的修改标 reverted:true;
//   ② 「待告知」:announced:false 的记录由 09 在下一个 provider 回合的 user 消息落历史时读走、写成一行告知,会话落盘后 ack。
// 为什么是旁车文件而不是会话头字段:会话头是【整份重写】的 —— 回合手里那份内存副本(以及任何 load→await→save 的旁路写者)
// 收尾时会把头写回「没有该字段」的样子。02d 的覆盖表(权限档/桌面工具/引擎路由)就是为这种陈旧副本写的,但那是给「必须对活回合
// 立即生效」的开关用的;本数据只在没有活回合时写(rollback 路由对活回合回 409,rewind 先停回合再等 settle),下一回合起跑时读,
// 不需要对活回合生效。独立文件从根上与会话头的任何一次保存(含撤回代数闸 SESSION_STALE_SAVE 丢掉的那些)都不相交,也就没有
// 「被回合的陈旧副本吞掉」这一类问题,不必再造一张覆盖表。随会话删除(deleteSession 清整个检查点目录)与全局体积清扫一起走。
// 记录按 (turnSeq, tool, op) 分组而不是一个文件一条:一次解压几千个文件的撤销也只是一条记录,告知一行说得完。
// 读失败/文件坏 = 当空(没有告知、没有已撤销标记,模型下一次读文件就会看到真实状态),不隔离、不抛。
const JOURNAL_REVERT_LOG_MAX = 100;     // 每会话最多留这么多条记录(超出先丢已告知的、再丢最旧的)
const JOURNAL_REVERT_PATHS_MAX = 5;     // 每条记录最多记几个样例路径(files 是真实个数)
const journalRevertChains = new Map();  // sessionId -> Promise(同会话的读改写串行)
function journalRevertLogPath(sessionId) { return path.join(journalDir(sessionId), 'reverts.json'); }
function journalRevertRecordOf(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const seq = Number(raw.seq), turnSeq = Number(raw.turnSeq);
  if (!Number.isSafeInteger(seq) || seq < 1 || !Number.isSafeInteger(turnSeq) || turnSeq < 0) return null;
  const paths = (Array.isArray(raw.paths) ? raw.paths : []).filter(p => typeof p === 'string' && p).slice(0, JOURNAL_REVERT_PATHS_MAX).map(p => p.slice(0, 400));
  const files = Number.isSafeInteger(Number(raw.files)) && Number(raw.files) > 0 ? Number(raw.files) : Math.max(1, paths.length);
  return {
    seq, turnSeq,
    entrySeq: Number.isSafeInteger(Number(raw.entrySeq)) ? Number(raw.entrySeq) : -1,
    tool: typeof raw.tool === 'string' ? raw.tool.slice(0, 64) : '',
    op: raw.op === 'create' || raw.op === 'delete' ? raw.op : 'modify',
    files, paths,
    at: typeof raw.at === 'string' ? raw.at.slice(0, 40) : '',
    revertedAt: typeof raw.revertedAt === 'string' ? raw.revertedAt.slice(0, 40) : '',
    announced: raw.announced === true,
  };
}
// 从不抛;文件不存在 / 读不动 / 不是预期形状 → []。
async function journalRevertLogRead(sessionId) {
  try {
    const parsed = safeJsonParse(await fsp.readFile(journalRevertLogPath(sessionId), 'utf8'), null);
    const rows = parsed && typeof parsed === 'object' && Array.isArray(parsed.items) ? parsed.items : [];
    return rows.map(journalRevertRecordOf).filter(Boolean);
  } catch { return []; }
}
async function journalRevertLogWrite(sessionId, items) {
  await fsp.mkdir(journalDir(sessionId), { recursive: true });
  await atomicWriteJson(journalRevertLogPath(sessionId), JSON.stringify({ schema: 1, items }), { retries: 3 });
}
// 路由在 journalRollback 成功后调:reverted = journalRollback 回的 [{path, op, turnSeq, entrySeq, tool, ts}]。
// 同一次撤销里 (turnSeq, tool, op) 相同的并成一条;已有【还没告知】的同键记录就并进去(用户先撤 a 再撤 b,两次都发生在
// 模型下一回合之前,告知一行说完)。已告知的不并(那次告知已经发出去了,这次是新的事实)。
async function journalRevertLogRecord(sessionId, reverted) {
  const rows = (Array.isArray(reverted) ? reverted : []).filter(r => r && typeof r.path === 'string' && r.path && Number.isSafeInteger(Number(r.turnSeq)));
  if (!rows.length) return;
  return runKeyedChain(journalRevertChains, String(sessionId || ''), async () => {
    const items = await journalRevertLogRead(sessionId);
    const now = nowIso();
    let nextSeq = items.reduce((m, r) => Math.max(m, r.seq), 0) + 1;
    const groups = new Map();
    for (const r of rows.slice().sort((a, b) => (Number(a.entrySeq) || 0) - (Number(b.entrySeq) || 0))) {   // 主路径 = 本组 entrySeq 最小的那条
      const op = r.op === 'create' || r.op === 'delete' ? r.op : 'modify';
      const key = `${Number(r.turnSeq)}|${r.tool || ''}|${op}`;
      let g = groups.get(key);
      if (!g) { g = { turnSeq: Number(r.turnSeq), entrySeq: Number.isSafeInteger(Number(r.entrySeq)) ? Number(r.entrySeq) : -1, tool: String(r.tool || ''), op, paths: [], at: '' }; groups.set(key, g); }
      if (!g.paths.includes(r.path)) g.paths.push(r.path);
      if (typeof r.ts === 'string' && r.ts > g.at) g.at = r.ts;
    }
    for (const g of groups.values()) {
      const open = items.find(r => !r.announced && r.turnSeq === g.turnSeq && r.tool === g.tool.slice(0, 64) && r.op === g.op);
      if (open) {
        open.files += g.paths.length;
        for (const p of g.paths) if (open.paths.length < JOURNAL_REVERT_PATHS_MAX && !open.paths.includes(p)) open.paths.push(p.slice(0, 400));
        if (g.entrySeq >= 0 && (open.entrySeq < 0 || g.entrySeq < open.entrySeq)) open.entrySeq = g.entrySeq;
        if (g.at > open.at) open.at = g.at;
        open.revertedAt = now;
        continue;
      }
      const rec = journalRevertRecordOf({ seq: nextSeq++, turnSeq: g.turnSeq, entrySeq: g.entrySeq, tool: g.tool, op: g.op, files: g.paths.length, paths: g.paths, at: g.at, revertedAt: now, announced: false });
      if (rec) items.push(rec);
    }
    while (items.length > JOURNAL_REVERT_LOG_MAX) {
      const i = items.findIndex(r => r.announced);
      items.splice(i >= 0 ? i : 0, 1);   // 先丢最旧的已告知项,没有才丢最旧的待告知项
    }
    await journalRevertLogWrite(sessionId, items);
  });
}
// 09 在 provider 回合起跑时读:还没告知的记录(回合升序)。读不到 = []。
async function journalRevertNoticesPeek(sessionId) {
  try { return (await journalRevertLogRead(sessionId)).filter(r => !r.announced).sort((a, b) => a.turnSeq - b.turnSeq || a.seq - b.seq); }
  catch { return []; }
}
// 09 在带着告知的那条 user 消息【已落盘】之后调:只把 peek 到的那几条标成已告知(按 seq),期间新记的不动。
// 先 peek、落盘后才 ack 的顺序是有意的:中途失败只会让告知多发一次(无害),不会让模型永远收不到。
async function journalRevertNoticesAck(sessionId, seqs) {
  const wanted = new Set((Array.isArray(seqs) ? seqs : []).map(Number));
  if (!wanted.size) return;
  return runKeyedChain(journalRevertChains, String(sessionId || ''), async () => {
    const items = await journalRevertLogRead(sessionId);
    let touched = false;
    for (const r of items) if (wanted.has(r.seq) && !r.announced) { r.announced = true; touched = true; }
    if (touched) await journalRevertLogWrite(sessionId, items);
  });
}
// rewindSession 截断成功后调:回合号 >= fromTurnSeq 的记录都属于已被丢弃的回合,留着只会给模型一句指向「不存在的回合」的告知。
async function journalRevertLogPrune(sessionId, fromTurnSeq) {
  const from = Number(fromTurnSeq);
  if (!Number.isFinite(from)) return;
  return runKeyedChain(journalRevertChains, String(sessionId || ''), async () => {
    const items = await journalRevertLogRead(sessionId);
    const kept = items.filter(r => r.turnSeq < from);
    if (kept.length !== items.length) await journalRevertLogWrite(sessionId, kept);
  });
}

// v0.8-S4b B2 — conversation REWIND (Claude Code-style "back up to just before this message"). Truncates
// the session to the state right BEFORE `targetTurnSeq` began: removes that turn's user message and
// everything after it, returns the removed user text so the front-end can refill the composer (话还在输入
// 框里可改可重发), and OPTIONALLY rolls back the files of every discarded turn.
//
// Key决策 (locked in this slice):
//  - providerHistory is CLEARED to [] — NOT surgically truncated. The provider engine's lazy-reseed
//    (runOpenAiTurn, seeds from session.messages when providerHistory is empty) rebuilds the user/assistant
//    text context on the very next turn. Simple and ALWAYS correct (including after a compaction, where a
//    surgical truncation of the summarized history would be meaningless). The trade-off is losing the tool
//    trace from prior turns; the reseed carries text only. Documented here.
//  - session.turnSeq is NOT rewound — monotonicity is the journal's primary key; a new turn after a rewind
//    keeps incrementing (never reuses a discarded seq).
//  - session.todos is KEPT — rewinding the CONVERSATION is not abandoning the TASK LIST.
//  - claudeSessionId is nulled — the CLI's --resume context no longer matches the truncated history, so a
//    stale resume would splice removed context back in.
// Returns {ok, removedTurns, lastUserText, filesReverted:[], filesFailed:[]} (or {ok:false,error} when a
// turn is live or the target can't be located; 107-F7b: error 'rewind_superseded' when a newer rewind of the
// same session landed first and this one's truncation was dropped by the rewind-generation gate).
// A guarded rewind owns admission until stopping, settlement, file rollback and persistence all finish.
// This is process-local coordination, never a durable session field or a reusable authorization.
const sessionRewindAdmissions = new Set();
const sessionLegacyRewinds = new Map();
SessionExecutionHooks.admissionBlocked = sessionId => sessionRewindAdmissions.has(sessionId);

async function rewindSession(sessionId, targetTurnSeq, rollbackFiles, options = {}) {
  if (sessionRewindAdmissions.has(sessionId)) return { ok: false, error: 'rewind_in_progress' };
  if (options.guardExecution !== true) {
    sessionLegacyRewinds.set(sessionId, (sessionLegacyRewinds.get(sessionId) || 0) + 1);
    try { return await rewindSessionContents(sessionId, targetTurnSeq, rollbackFiles); }
    finally {
      const remaining = sessionLegacyRewinds.get(sessionId) - 1;
      if (remaining) sessionLegacyRewinds.set(sessionId, remaining); else sessionLegacyRewinds.delete(sessionId);
    }
  }
  if (sessionLegacyRewinds.has(sessionId)) return { ok: false, error: 'rewind_in_progress' };
  sessionRewindAdmissions.add(sessionId);
  try {
    // Missing is not an observation of idle. Old hand-off buttons cannot acquire a new target.
    if (options.expectedExecution === undefined) return { ok: false, error: 'execution_identity_required' };
    if (typeof SessionExecutionHooks.checkRewind !== 'function' || typeof SessionExecutionHooks.stop !== 'function') return { ok: false, error: 'execution_identity_unavailable' };
    const checked = SessionExecutionHooks.checkRewind(sessionId, options.expectedExecution);
    if (!checked || checked.ok !== true) return checked || { ok: false, error: 'execution_identity_unavailable' };
    if (options.expectedExecution === null) {
      const expected = options.expectedIdleState;
      const observation = expected && expected.executionObservation;
      if (!expected || !Number.isSafeInteger(expected.turnSeq) || expected.turnSeq < 0
          || !Number.isSafeInteger(expected.rewindGen) || expected.rewindGen < 0
          || !observation || typeof observation.serverInstanceId !== 'string' || !observation.serverInstanceId
          || !(observation.lastDriverRunId === null || (typeof observation.lastDriverRunId === 'string' && observation.lastDriverRunId))
          || !Number.isSafeInteger(observation.evictionGeneration) || observation.evictionGeneration < 0) {
        return { ok: false, error: 'execution_identity_required' };
      }
      if (typeof SessionExecutionHooks.observation !== 'function') return { ok: false, error: 'execution_identity_unavailable' };
      // A null -> B admitted -> null transition is not the same idle observation, even if B never
      // wrote a turn. The eviction generation also prevents a lost tombstone looking like virgin idle.
      const current = SessionExecutionHooks.observation(sessionId);
      if (!current || current.serverInstanceId !== observation.serverInstanceId
          || current.lastDriverRunId !== observation.lastDriverRunId || current.evictionGeneration !== observation.evictionGeneration) {
        return { ok: false, error: 'execution_changed' };
      }
      const idleSession = await loadSession(sessionId);
      if (!idleSession || (Number(idleSession.turnSeq) || 0) !== expected.turnSeq
          || (Number(idleSession.rewindGen) || 0) !== expected.rewindGen) return { ok: false, error: 'execution_changed' };
    }
    if (checked.execution !== null) {
      const stopped = SessionExecutionHooks.stop(sessionId, options.expectedExecution, 'rewind');
      if (!stopped || stopped.ok !== true) return stopped || { ok: false, error: 'execution_identity_unavailable' };
    }
    if (activeChildren.has(sessionId)) return { ok: false, error: 'execution_changed' };
    return await rewindSessionContents(sessionId, targetTurnSeq, rollbackFiles, { guarded: true });
  } finally {
    sessionRewindAdmissions.delete(sessionId);
  }
}

async function rewindSessionContents(sessionId, targetTurnSeq, rollbackFiles, options = {}) {
  // 117d 波实测竞态(既有缺陷,本波暴露):回合收尾的【原子头文件换名】窗口里磁盘读会短暂看不到头
  // 文件(loadSession 的 ENOENT 分支回 null),而撤回的调用序是「先 /api/stop 再 rewind」—— stop 已经
  // 把 activeChildren 删了,dying turn 的收尾 save 才刚开始写。于是首读回 null,rewind 直接吐
  // 「session not found」,而这条线程明明在。修法:【不在首读就下 not found 的结论】—— 先照常走
  // 停回合与等 settle(收尾 save 完成后 settler 才 resolve),再以 settle 后那次重读为准。
  // 真正不存在的会话在这条路径上没有活回合也没有 settler,两处 await 都是 no-op,仍然如实回 404。
  // 活回合注册表持有同一权威 session,顺带兜住「stop 还没跑」的那一瞬(与 1628 行
  // missionControlCommand 同一处置)。复现:117c 递话后立刻点撤回,约五成命中。
  const registered = activeChildren.get(sessionId);
  // Legacy callers retain their API, but an automatic stop still targets the execution observed
  // before the first asynchronous read, rather than whichever execution happens to be current later.
  const observedExecution = typeof SessionExecutionHooks.snapshot === 'function' ? SessionExecutionHooks.snapshot(sessionId) : undefined;
  let session = await loadSession(sessionId) || (registered && registered.session) || null;
  // 第69波:回合进行中不再拒绝,改为【自动停回合 + 等 settle 再截断】(supersede 语义,与 09-workflow
  // 新回合 stopSession('superseded') 对齐)。原拒绝路径(activeChildren.has → '回合进行中,请先停止')
  // 对非 UI 持有的回合是死锁:页面重载/后台调度回合下前端无停止按钮,用户永远「回不去」。
  // 丢失写竞态:stopSession 立即删 activeChildren,但被停回合的收尾(推 aborted assistant + saveSession)
  // 在其后落盘;若 rewind 在此窗口截断落盘,会被 dying turn 的收尾 save 整份盖回(消息「回来了」)。
  // turnSettlers 在 driver finally(收尾 save 之后)resolve —— 等它即保证截断写在最后。超时兜底:
  // 回合真楔死(.abort 不生效)时按原状截断,残留风险记日志(此时该回合本就在写坏状态)。
  // 107-F7b:上面那句「等它即保证截断写在最后」只对【垂死回合自己】成立,真正兜底的现在是撤回代数闸
  // (sessionRewindGenHighWater 头注;本函数末尾那一存传 rewindBump)。实测挡不住的那条交错(冻结树
  // steward-conversation.e2e G4,负载下 4/20):管家递话后立刻撤回 —— 前端先 /api/stop,它把 activeChildren
  // 删了,所以这里 activeChildren.has 为假(日志里没有 rewind_autostop);settler 在,照常等到了(也没有
  // rewind_settle_timeout)。闸的两个前提都成立,消息却还是回来了:盖回撤回的那一存【不是回合的】。回合
  // settle 的同一刻还有别的写者起跑(13k stewardRecordLaunchOutcome → updateSessionMeta 是读改写;首回合
  // 还有 settleThreadBrief 的补写),它们在 settle 之后才 load,load 落在撤回那一存之前、save 落在之后 ——
  // 等 settle 管不到回合之外的人。代数闸不看是谁写:撤回之前读出来的副本,谁拿着都写不回去。
  if (!options.guarded && (activeChildren.has(sessionId) || observedExecution)) {
    const stopped = typeof SessionExecutionHooks.stop === 'function'
      ? SessionExecutionHooks.stop(sessionId, observedExecution, 'rewind') : null;
    if (!stopped || stopped.ok !== true) return stopped || { ok: false, error: 'execution_identity_unavailable' };
    if (activeChildren.has(sessionId)) return { ok: false, error: 'execution_changed' };
    logEvent({ kind: 'rewind_autostop', sessionId, targetTurnSeq: Number(targetTurnSeq) || null });
  }
  const settler = turnSettlers.get(sessionId);
  if (settler && settler.promise) {
    let settleTimer;
    const settled = await Promise.race([settler.promise.then(() => true), new Promise(r => { settleTimer = setTimeout(() => r(false), 8000); })]).finally(() => clearTimeout(settleTimer));
    if (!settled) {
      logEvent({ kind: 'rewind_settle_timeout', sessionId });
      if (options.guarded) return { ok: false, error: 'rewind_settle_timeout' };
    }
  }
  const live = await loadSession(sessionId); // settle 后重读: dying turn 的收尾(含 aborted assistant)已落盘
  if (live) session = live;
  // not found 的结论挪到这里下(见函数开头注):首读撞上换名窗口不算「不存在」。
  if (!session) return { ok: false, error: 'session not found' };
  const target = Number(targetTurnSeq);
  if (!Number.isFinite(target)) return { ok: false, error: 'targetTurnSeq is required' };
  const messages = Array.isArray(session.messages) ? session.messages : [];
  // Locate the first user message belonging to targetTurnSeq. Primary: the additive `turnSeq` field
  // (S4b stamps every new user message). Fallback for pre-S4b messages without the field: the first user
  // message whose FOLLOWING assistant carries turnSummary.turnSeq === target (assistant messages have
  // carried turnSummary.turnSeq since S3), else an ordinal guess (the `target`-th user message, 1-based).
  let cutIndex = -1;
  for (let i = 0; i < messages.length; i++) {
    const m = messages[i];
    if (m && m.role === 'user' && Number(m.turnSeq) === target) { cutIndex = i; break; }
  }
  if (cutIndex === -1) {
    // Fallback A: user message immediately preceding the assistant whose turnSummary.turnSeq === target.
    for (let i = 0; i < messages.length; i++) {
      const m = messages[i];
      if (m && m.role === 'assistant' && m.turnSummary && Number(m.turnSummary.turnSeq) === target) {
        for (let j = i - 1; j >= 0; j--) { if (messages[j] && messages[j].role === 'user') { cutIndex = j; break; } }
        break;
      }
    }
  }
  if (cutIndex === -1) {
    // Fallback B: ordinal — the `target`-th user message (1-based). Only reached for legacy sessions.
    let n = 0;
    for (let i = 0; i < messages.length; i++) {
      if (messages[i] && messages[i].role === 'user') { n++; if (n === target) { cutIndex = i; break; } }
    }
  }
  if (cutIndex === -1) return { ok: false, error: 'target turn not found in this session' };

  const lastUserText = String((messages[cutIndex] && messages[cutIndex].content) || '');
  // Which turnSeqs are being discarded? Everything from the cut point onward. Prefer the stamped/summary
  // turnSeqs actually present in the tail; fall back to the numeric range target..current.
  const discarded = new Set();
  for (let i = cutIndex; i < messages.length; i++) {
    const m = messages[i];
    if (!m) continue;
    if (m.role === 'user' && Number.isFinite(Number(m.turnSeq))) discarded.add(Number(m.turnSeq));
    if (m.role === 'assistant' && m.turnSummary && Number.isFinite(Number(m.turnSummary.turnSeq))) discarded.add(Number(m.turnSummary.turnSeq));
  }
  const curSeq = Number(session.turnSeq) || target;
  for (let s = target; s <= curSeq; s++) discarded.add(s);

  // Optional file rollback of the discarded turns, newest→oldest (so multiple writes to a file unwind to
  // the earliest recorded `before` across turns). Aggregate into filesReverted / filesFailed.
  // 116-3 data-safety P1-4:`turnsWithoutCheckpoint` —— 哪些被丢弃的回合【压根没有 checkpoint 记录】。
  // 修前「0 条 revert」这一个形状同时代表两件完全不同的事:「这一步没碰过文件,不用回滚」与
  // 「这一步改过文件,但改动没进 journal(引擎用自己的原生编辑能力绕过了 file_* 桥),回滚不了」。
  // 用户看到「文件已回滚」会以为磁盘复原了,实际改动原封不动留着。这里把第二种如实说出来,
  // 让上层能在提示旁边补一句「以下回合的文件改动未被追踪,可能没有被撤销」。只加字段,不改行为。
  const filesReverted = [], filesFailed = [], turnsWithoutCheckpoint = [];
  if (rollbackFiles) {
    const seqs = [...discarded].sort((a, b) => b - a); // newest first
    for (const s of seqs) {
      try {
        const r = await journalRollback(sessionId, s); // whole-turn rollback
        if (r && Array.isArray(r.reverted)) for (const x of r.reverted) filesReverted.push(x);
        if (r && Array.isArray(r.failed)) for (const x of r.failed) filesFailed.push(x);
        if (r && r.ok === false && r.error === 'no entries') turnsWithoutCheckpoint.push(s);
      } catch (e) { filesFailed.push({ path: '', reason: (e && e.message) ? e.message : String(e) }); }
    }
    turnsWithoutCheckpoint.sort((a, b) => a - b);
  }

  const removedTurns = messages.length - cutIndex; // message count removed (user + all following)
  // hunt2 #12:被截掉的后台任务回执从账本里删掉,否则下面这一存的 mergeBackgroundJobs 会把它们原样追加回来。
  const removedJobIds = messages.slice(cutIndex).map(m => m && m.backgroundJobId).filter(Boolean);
  if (removedJobIds.length && EventStreamHooks.forgetBackgroundJobs) EventStreamHooks.forgetBackgroundJobs(sessionId, removedJobIds);
  session.messages = messages.slice(0, cutIndex);
  // providerHistory cleared — lazy-reseed rebuilds it on the next turn (see block comment above).
  session.providerHistory = [];
  session.providerHistoryCursor = 0;
  // turnSeq NOT rewound (monotonic journal key); todos KEPT (rewind ≠ abandon task list).
  session.claudeSessionId = null; // stale --resume context must not splice removed history back in
  // Refresh the derived summary/title tail off the surviving messages (best-effort).
  const lastAssistant = [...session.messages].reverse().find(m => m && m.role === 'assistant');
  session.summary = lastAssistant ? String(lastAssistant.content || '').replace(/\s+/g, ' ').trim().slice(0, 160) : '';
  // 107-F7b:这一存抬撤回代数(见函数开头那段注与 sessionRewindGenHighWater 头注)。之后任何拿着撤回【之前】
  // 那份对象来写的人都会被 saveSession 的代数闸丢掉。它自己被丢只有两种可能,都是两次撤回交错:① 在它入链
  // 之后、执行之前又来了一次更新的撤回;② 它截断用的这份副本本身读在另一次已经抬了代数的撤回之前(照它截
  // 会把那次撤回删掉的消息带回来)。两种都如实回「被顶掉」,不说 ok:true(前端那道诚实门据此不说已撤回)。
  try {
    await saveSession(session, { rewindBump: true, throwIfStale: true, writer: 'rewind' });
  } catch (error) {
    if (error && error.code === 'SESSION_STALE_SAVE') {
      logEvent({ kind: 'rewind_superseded', sessionId, targetTurnSeq: target });
      return { ok: false, error: 'rewind_superseded' };
    }
    throw error;
  }
  // 撤回已落盘:停掉被撤回回合里模型起的仍在跑的后台 run,并让后台代理唤醒(10 onSessionRewound)记「叫停过」—— 别把改写过的线程自动叫醒,
  // 信封留在账本里随用户下一句话送达。旁路,失败不影响撤回本身。
  try { cancelModelRunsOfDiscardedTurns(sessionId, discarded); } catch { /* 旁路 */ }
  if (EventStreamHooks.onSessionRewound) { try { EventStreamHooks.onSessionRewound({ sessionId, discardedTurnSeqs: discarded }); } catch { /* 旁路 */ } }
  // C4:rewind【不】给模型记「用户撤销了文件」的待告知(rollbackFiles 撤的恰恰是被丢弃回合的改动)。理由:截断之后 providerHistory
  // 清空、下一回合从幸存的展示消息重新播种,被丢弃的回合对模型而言根本没发生过;它们碰过的文件又被恢复到了修改前 —— 模型看到的
  // 对话与磁盘是自洽的,再告知「第 N 回合的修改已被撤销」反而是在讲一个它看不到的回合。反过来,截断前已经在待告知里的记录
  // (用户先在界面撤了第 4 回合的文件、没发消息就回退到第 3 回合)指向的回合同样被丢了,一并清掉,不留一句悬空的告知。
  // 截断被代数闸顶掉(上面已 return rewind_superseded)时不走到这里。
  await journalRevertLogPrune(sessionId, target).catch(() => {});
  await bumpMissionChangeSeq(sessionId, {
    type: 'rewind',
    cursor: { targetTurnSeq: target },
    detail: {
      removedTurns, rollbackFiles: Boolean(rollbackFiles),
      filesReverted: filesReverted.length, filesFailed: filesFailed.length,
      turnsWithoutCheckpoint: turnsWithoutCheckpoint.length,   // 116-3 P1-4
    },
  });
  // 128f-⑫:回退改的是对话本身(「它刚说」换成更早那一句),五态与等你数往往不变,13r 的「只在看得见的变了才推」
  // 那一路判不出来 —— 这里显式派一发,焦点栏与中栏据此重读。
  RUYI_EVENTS.emit('thread.state', { sessionId });
  return { ok: true, removedTurns, lastUserText, filesReverted, filesFailed, turnsWithoutCheckpoint };
}

// Resolve the journal {sessionId, turnSeq} for a file-mutating toolCall. Priority:
//  - ctx (provider loop passes its live session.id + session.turnSeq) → authoritative;
//  - else the MCP child reads WCW_SESSION_ID env + the session file's turnSeq (read-only, no race).
// Returns {sessionId, turnSeq} where either may be falsy/null → journalRecord then no-ops gracefully.
async function journalSessionCtx(ctx) {
  if (ctx && ctx.sessionId && Number.isFinite(ctx.turnSeq)) return { sessionId: ctx.sessionId, turnSeq: Number(ctx.turnSeq) };
  const sessionId = (ctx && ctx.sessionId) || process.env.WCW_SESSION_ID || '';
  const turnSeq = await journalResolveTurnSeq(sessionId, ctx && ctx.turnSeq);
  return { sessionId, turnSeq };
}

// v1.5-W1.5 (T3): bridged 写族工具的路径提取表 —— 裸工具名 → args 里的目标路径字段名。ACC 的
// write_document/write_excel/write_pdf 入参都叫 `path`(见 document.py 函数签名);delete 类走 op:delete。
// 表里没有的 bridged 工具不快照(collectBridgedWriteTargets 返回 []),工具照常执行。
//
// v1.2-B:两种条目形状 ——
//   (1) 单目标:{ field:'<argName>', op:'write'|'delete' } —— 一条快照(绝大多数写族)。
//   (2) 多目标:{ multi: [{ field, op }, ...] } —— 一次工具调用动多个文件,逐条独立快照。
//       move_file 是典型:源存在→op:'delete'(回滚=写回原处),目的地→op:'write'(存在→modify,否则 create,
//       回滚=删除)。回滚整回合时 journalRollback 按 entrySeq 逆序展开:后写的 dest 先撤(删掉新文件),
//       再撤 src(把源写回原处)—— 净效果=文件回到移动前的位置与内容。任一目标快照失败静默跳过,不阻断工具、
//       不阻断其它目标(与单目标同一安全网纪律)。
//   ⚠️ 参数名以 ACC 源码实际签名为准(不是本能猜测):filesystem.move_file/copy_file 的入参是
//      `source` / `destination`,不是 src/dest;window_screenshot 是 output_path;get_clipboard_image 是 save_path。
const BRIDGED_WRITE_PATH_ARGS = {
  write_document: { field: 'path', op: 'write' },
  write_docx: { field: 'path', op: 'write' },
  write_excel: { field: 'path', op: 'write' },
  write_pdf: { field: 'path', op: 'write' },
  write_file: { field: 'path', op: 'write' },
  // v1.1 返修(用户真机撞出):ACC v1.6 四个 Office 工具上线时漏进此表 → write_pptx/excel_beautify 全程
  // 零快照,用户「生成的 Excel 和 PPT 不能撤销」。教训:新增 bridged 写族工具时,此表 + toolIsRevertible
  // 徽章是【发布检查项】,不是可选项。四个入参均为 `path`(office_pptx/office_excel/office_chart 签名核对)。
  write_pptx: { field: 'path', op: 'write' },
  excel_beautify: { field: 'path', op: 'write' },
  excel_chart: { field: 'path', op: 'write' },
  chart_image: { field: 'path', op: 'write' },
  // 删除类:存 before 快照(op:delete → 回滚=写回)。ACC filesystem.delete_file 入参叫 `path`。
  delete_file: { field: 'path', op: 'delete' },
  // v1.2-B:move/copy 补齐(W1.5 明确欠账)。ACC filesystem.py 签名:move_file(source, destination)、
  //   copy_file(source, destination)。move = 源删 + 目的写(两条);copy = 只动目的地(一条 write)。
  //   注:源/目的地可能是目录(shutil.move/copytree);journalBridgedWrite 只快照普通文件(读得到字节的),
  //   目录目标读 before 失败按「无 before」处理 → 目录 move 的源侧记 delete 但无内容(回滚会 loudly fail),
  //   这是可接受的降级(整目录快照超出 checkpoint 的字节级设计,和内建 file_move 同保真度)。
  move_file: { multi: [{ field: 'source', op: 'delete' }, { field: 'destination', op: 'write' }] },
  copy_file: { field: 'destination', op: 'write' },
  // v1.2-B:截图/抓图类 —— 仅当调用方显式给了落盘路径参数时才产出磁盘文件(否则回 base64,无文件可撤)。
  //   op:'create' 语义(新 png),快照价值=可回滚删除。参数名:window_screenshot=output_path、
  //   get_clipboard_image=save_path(capture.py / desktop_extra.py 签名核对)。缺参→collectBridgedWriteTargets
  //   返回 [](不快照)。这些路径由调用方给,可能落在工作区内;落在护栏外则 journalBridgedWrite 自然跳过。
  window_screenshot: { field: 'output_path', op: 'write' },
  get_clipboard_image: { field: 'save_path', op: 'write' },
  // ACC v1.8:image_resize —— 真写文件 (缩放后落 output_path),但名字不含写族前缀 (^write_/save_/…),
  //   与 excel_beautify/chart_image 同类:命名审计抓不到,靠 B1 人工盘点入表。参数名 output_path
  //   (image_tools.py: image_resize(path, output_path, …) 签名核对)。落盘可能在工作区内 → 快照可撤;
  //   护栏外 (image_resize 自带 protected_path 护栏兜底) → journalBridgedWrite 自然跳过。
  image_resize: { field: 'output_path', op: 'write' },
  // 第49波(49a):ACC v1.9 edit_file —— in-place 精确替换(path 指向既有文件),op:write 快照 before
  //   → 回滚=写回原内容(与整文件 write_file 同保真度)。入表即获得检查点+撤销能力(03 方案 P0 联动要求)。
  edit_file: { field: 'path', op: 'write' },
};
// 从 bridged 工具名 + args 解析出「该工具将要动的所有目标文件」。返回 [{path, mode}, ...](可能空数组)。
// mode ∈ 'write'|'delete'。纯字符串/查表逻辑,无 I/O。每个目标:path 缺失/非字符串/非绝对路径 → 跳过该目标
// (不快照,不阻断);单目标条目产出 0 或 1 条,多目标条目逐字段产出(move 最多 2 条)。
function collectBridgedWriteTargets(bridgedName, args) {
  const bare = unprefixedBridgedName(bridgedName);
  const spec = BRIDGED_WRITE_PATH_ARGS[bare];
  if (!spec) return [];
  const fields = Array.isArray(spec.multi) ? spec.multi : [spec];
  const out = [];
  for (const f of fields) {
    const raw = args && typeof args === 'object' ? args[f.field] : null;
    if (typeof raw !== 'string' || !raw.trim()) continue; // 该字段缺省(如可选 output_path)→ 跳过
    if (!path.isAbsolute(raw)) continue;                   // 相对路径 → 不快照(护栏也只认绝对路径)
    out.push({ path: raw, mode: f.op });
  }
  return out;
}
// v1.4.1 (audit #9):某桥接【写族】工具带【相对路径】写目标时返回该字段名(否则 null)。工作台无法可靠知道 ACC
// 对相对路径的解析基准(ACC 子进程 cwd ≠ 会话工作区)——既不能正确快照也不能正确回滚 → 会变成【静默不可撤销】
// 的写。分发点据此拒绝并引导改用绝对路径(绝对路径照常快照 + 可撤销)。
function bridgedWriteRelativePathArg(bridgedName, args) {
  const bare = unprefixedBridgedName(bridgedName);
  const spec = BRIDGED_WRITE_PATH_ARGS[bare];
  if (!spec) return null;
  const fields = Array.isArray(spec.multi) ? spec.multi : [spec];
  for (const f of fields) {
    const raw = args && typeof args === 'object' ? args[f.field] : null;
    if (typeof raw === 'string' && raw.trim() && !path.isAbsolute(raw)) return f.field;
  }
  return null;
}
// 单目标兼容层(保留原契约:返回首个目标 {path, mode} 或 null)。既有 e2e 直测此签名;多目标工具(move_file)
// 由此返回其第一条(source delete)。新代码应改用 collectBridgedWriteTargets(复数,全目标)。
function collectBridgedWriteTarget(bridgedName, args) {
  const targets = collectBridgedWriteTargets(bridgedName, args);
  return targets.length ? targets[0] : null;
}

// ============================================================================
// 第 116 波 116g(27 号文 §3.1「事项跨会话升格」):事项(Mission)容器。
//
// 为什么要有这一层:`sessionMeta.missionId` 从 75a 起就在会话头里了,但它一直只是「= sessionId」的
// 稳定主键 —— 一个事项永远只有一条线程。116g 把 mission 升格成【跨会话容器】:一个事项可以有多条
// 线程(会话),线程可以加入/移出事项,事项可以合并与拆分。
//
// 三条边界(改这段前先读):
//   ① **事项级字段的唯一归属在事项文件**。`goal` / `acceptance` / `budget` 只存在 `<data>/missions/
//      <missionId>.json` 里。会话头里那个 `head.mission`(第26波b 的【会话内任务账本】:目标、里程碑、
//      until-done 预算、停滞标记、结果章)**一个字节都不动**,它仍然是「这条线程自己的里程碑」,
//      不再是事项级权威。两者同名不同物,不要互相回写。
//   ② **零迁移**。没有事项文件的 missionId 一律视为「未归类」,按需从会话头【只读派生】一个不落盘的
//      视图(`derived:true`,标题取会话标题)。存量会话不批量重写、不补建文件。
//   ③ **反向索引的权威是事项文件的 `sessionIds`**,但读侧一律与会话头 `missionId` 对账 —— 文件丢了
//      或损坏了,索引就从会话头重建,不需要任何修复流程。
//
// 落点为什么在 02 而不是 06e(事项域):这一节是【持久化面】—— 文件读写、原子写、损坏隔离、写链、
// 反向索引与会话头两侧同写。02 已经是会话头、正文、变更流水、待决流水的唯一持有者,事项容器与它们
// 共用 atomicWriteJson / safeSessionId / updateSessionMeta / bumpMissionChangeSeq 这几件同样的东西;
// 放在 06e 会让引擎层凭空多出一条到 01-config 的边(见 module-dependency-policy.json 的债务上限)。
// 06e 仍然是【会话内任务账本】的域(buildMissionPromptSection / runMissionDriver),两者同名不同物。
//
// 聚合状态的唯一定义在 06i 的 `aggregateMissionState` —— 它与五态判据 `deriveStewardThreadState` /
// `stewardThreadStateFromCard`(mission-state.js 的服务端抄写件)同住一屋,入参是子线程五态数组。
// 13d / 13g / 13h 一律调它,禁止另写一份判据。
// ============================================================================

const MISSIONS_DIR_NAME = 'missions';
const MISSION_CONTAINER_SCHEMA = 1;
// 容量:事项文件数硬上限。超出后拒绝【新建】(合并/拆分里的新建同样受限),既有事项照常读写。
// 2000 个事项 ≈ 每天新建一个连续跑五年半,真到了这个量级该做的是归档而不是继续堆文件。
const MISSION_CONTAINER_MAX_FILES = 2000;
const MISSION_CONTAINER_LIMITS = Object.freeze({
  titleChars: 120, goalChars: 2000, acceptanceItems: 50, acceptanceItemChars: 300,
  sessionIds: 500, currencyChars: 12,
});

function missionsDir() { return path.join(paths.data, MISSIONS_DIR_NAME); }
function missionContainerPath(missionId) { return path.join(missionsDir(), missionId + '.json'); }
// 事项 id 与会话 id 同一字符集(safeSessionId 是全仓唯一那道消毒),新建时取 `mission_<hex>` 前缀 ——
// 与 `sess_` 分开,好在日志里一眼认出;13e 的投影扫描只认 `sess_*.json`,故事项文件天然不进投影。
function safeMissionId(raw) { return safeSessionId(raw); }

function missionClipText(value, max) {
  return String(value == null ? '' : value).replace(/[\r\n]+/g, ' ').trim().slice(0, max);
}

// 验收项 id 稳定:调用方给了就沿用(PATCH 按 id 定位),没给才生成。
function normalizeMissionAcceptance(raw) {
  const rows = Array.isArray(raw) ? raw : [];
  const out = [];
  const seen = new Set();
  for (const item of rows) {
    if (out.length >= MISSION_CONTAINER_LIMITS.acceptanceItems) break;
    const source = (item && typeof item === 'object') ? item : { text: item };
    const acceptanceText = missionClipText(source.text, MISSION_CONTAINER_LIMITS.acceptanceItemChars);
    if (!acceptanceText) continue;
    let id = missionClipText(source.id, 64).replace(/[^A-Za-z0-9_-]/g, '');
    if (!id || seen.has(id)) id = makeId('acc');
    seen.add(id);
    const done = source.done === true;
    const row = { id, text: acceptanceText, done };
    if (done) row.doneAt = source.doneAt ? String(source.doneAt).slice(0, 40) : nowIso();
    out.push(row);
  }
  return out;
}

function normalizeMissionBudget(raw) {
  const src = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
  const budget = {};
  const maxCost = Number(src.maxCost);
  if (Number.isFinite(maxCost) && maxCost >= 0) budget.maxCost = Math.round(maxCost * 1e6) / 1e6;
  const currency = missionClipText(src.currency, MISSION_CONTAINER_LIMITS.currencyChars).toUpperCase();
  if (currency) budget.currency = currency;
  return budget;
}

function normalizeMissionContainer(raw, fallbackId) {
  const src = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
  const missionId = safeMissionId(src.missionId) || safeMissionId(fallbackId);
  if (!missionId) return null;
  const sessionIds = [];
  for (const value of (Array.isArray(src.sessionIds) ? src.sessionIds : [])) {
    if (sessionIds.length >= MISSION_CONTAINER_LIMITS.sessionIds) break;
    const sid = safeSessionId(value);
    if (sid && !sessionIds.includes(sid)) sessionIds.push(sid);
  }
  const record = {
    schema: MISSION_CONTAINER_SCHEMA,
    missionId,
    title: missionClipText(src.title, MISSION_CONTAINER_LIMITS.titleChars),
    goal: String(src.goal == null ? '' : src.goal).slice(0, MISSION_CONTAINER_LIMITS.goalChars),
    acceptance: normalizeMissionAcceptance(src.acceptance),
    budget: normalizeMissionBudget(src.budget),
    cwd: String(src.cwd == null ? '' : src.cwd).slice(0, 400),
    createdAt: String(src.createdAt || nowIso()).slice(0, 40),
    updatedAt: String(src.updatedAt || nowIso()).slice(0, 40),
    sessionIds,
  };
  if (src.archivedAt) record.archivedAt = String(src.archivedAt).slice(0, 40);
  return record;
}

// 损坏隔离:整份 rename 成 `<id>.json.corrupt`(不是 copy —— 留在原地会让下一次读再隔离一次,而且
// 会一直把这个事项报成「存在但读不出」)。隔离之后该 missionId 立刻退化成「未归类派生视图」,反向
// 索引从会话头 `missionId` 重建,不需要任何修复流程。
async function readMissionContainer(missionId) {
  const id = safeMissionId(missionId);
  if (!id) return null;
  const file = missionContainerPath(id);
  let raw;
  try { raw = await fsp.readFile(file, 'utf8'); } catch { return null; }
  let parsed = null;
  try { parsed = JSON.parse(raw); } catch { parsed = null; }
  const schemaOk = parsed && typeof parsed === 'object' && !Array.isArray(parsed)
    && (parsed.schema === undefined || parsed.schema === MISSION_CONTAINER_SCHEMA);
  const normalized = schemaOk ? normalizeMissionContainer(parsed, id) : null;
  if (!normalized || !normalized.title) {
    await fsp.rename(file, file + '.corrupt').catch(() => {});
    logEvent({ kind: 'mission_container_quarantined', missionId: id });
    return null;
  }
  return normalized;
}

// 每事项一条写链(先例:02 的 sessionWriteChains)。读-改-写全部在链内做,防两个路由并发把 sessionIds 写丢。
const missionContainerChains = new Map();
function withMissionContainerLock(missionId, work) {
  return runKeyedChain(missionContainerChains, String(missionId || ''), work);
}

async function writeMissionContainer(record) {
  const normalized = normalizeMissionContainer(record, record && record.missionId);
  if (!normalized) throw new Error('invalid mission container');
  normalized.updatedAt = nowIso();
  await fsp.mkdir(missionsDir(), { recursive: true });
  await atomicWriteJson(missionContainerPath(normalized.missionId), JSON.stringify(normalized, null, 2));
  return normalized;
}

async function listMissionContainerIds() {
  const files = await fsp.readdir(missionsDir()).catch(() => []);
  return files.filter(name => name.endsWith('.json')).map(name => name.slice(0, -5)).filter(id => safeMissionId(id));
}

async function listMissionContainers() {
  const ids = await listMissionContainerIds();
  const out = [];
  for (const id of ids) {
    const record = await readMissionContainer(id);
    if (record) out.push(record);
  }
  out.sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
  return out;
}

// 稳定信封:所有事项写操作统一返回 { ok:true, mission } 或 { ok:false, error, message }。
function missionContainerFail(error, message, extra) {
  const envelope = { ok: false, error: error, message: String(message || error) };
  return extra ? Object.assign(envelope, extra) : envelope;
}

async function createMissionContainer(input) {
  const src = (input && typeof input === 'object') ? input : {};
  const existing = await listMissionContainerIds();
  if (existing.length >= MISSION_CONTAINER_MAX_FILES) {
    return missionContainerFail('capacity_exceeded',
      'mission store is full (' + existing.length + '/' + MISSION_CONTAINER_MAX_FILES + '); archive or merge existing missions before creating another',
      { limit: MISSION_CONTAINER_MAX_FILES, count: existing.length });
  }
  const title = missionClipText(src.title, MISSION_CONTAINER_LIMITS.titleChars);
  if (!title) return missionContainerFail('invalid_request', 'title is required');
  const mission = await writeMissionContainer({
    missionId: makeId('mission'),
    title,
    goal: src.goal,
    acceptance: src.acceptance,
    budget: src.budget,
    cwd: src.cwd,
    createdAt: nowIso(),
    sessionIds: Array.isArray(src.sessionIds) ? src.sessionIds : [],
  });
  logEvent({ kind: 'mission_container_created', missionId: mission.missionId, title: mission.title });
  return { ok: true, mission };
}

// PATCH 只认四个事项级字段。acceptance 的 id 稳定:传回来的项带 id 就按 id 更新(勾选 done 就是这么
// 用的),不带 id 的是新项;传 acceptance 即整表替换(客户端拿到的就是整表,回传整表最不歧义)。
async function patchMissionContainer(missionId, patch) {
  const id = safeMissionId(missionId);
  if (!id) return missionContainerFail('invalid_request', 'invalid missionId');
  const p = (patch && typeof patch === 'object') ? patch : {};
  return withMissionContainerLock(id, async () => {
    const current = await readMissionContainer(id);
    if (!current) return missionContainerFail('not_found', 'mission ' + id + ' not found');
    const next = Object.assign({}, current);
    if (Object.prototype.hasOwnProperty.call(p, 'title')) {
      const title = missionClipText(p.title, MISSION_CONTAINER_LIMITS.titleChars);
      if (!title) return missionContainerFail('invalid_request', 'title must not be empty');
      next.title = title;
    }
    if (Object.prototype.hasOwnProperty.call(p, 'goal')) next.goal = p.goal;
    if (Object.prototype.hasOwnProperty.call(p, 'budget')) next.budget = p.budget;
    if (Object.prototype.hasOwnProperty.call(p, 'acceptance')) {
      const byId = new Map(current.acceptance.map(row => [row.id, row]));
      next.acceptance = normalizeMissionAcceptance(p.acceptance).map(row => {
        // doneAt 只在【由未完成变完成】的那一刻盖章;已完成项保留原时间戳(勾选时间是事实,不是刷新时间)。
        const prev = byId.get(row.id);
        if (row.done && prev && prev.done && prev.doneAt) return Object.assign({}, row, { doneAt: prev.doneAt });
        return row;
      });
    }
    return { ok: true, mission: await writeMissionContainer(next) };
  });
}

// 反向索引维护:只动事项文件的 sessionIds。会话头那侧由调用方经 updateSessionMeta 写(享受 116-2a 的
// 活回合竞态防护);没有事项文件时是 no-op —— 「未归类」按定义就没有索引可维护。两个方向都幂等。
async function missionIndexAdd(missionId, sessionId) {
  const id = safeMissionId(missionId), sid = safeSessionId(sessionId);
  if (!id || !sid) return null;
  return withMissionContainerLock(id, async () => {
    const current = await readMissionContainer(id);
    if (!current) return null;
    if (current.sessionIds.includes(sid)) return current;
    if (current.sessionIds.length >= MISSION_CONTAINER_LIMITS.sessionIds) return current;
    return writeMissionContainer(Object.assign({}, current, { sessionIds: current.sessionIds.concat([sid]) }));
  });
}
async function missionIndexRemove(missionId, sessionId) {
  const id = safeMissionId(missionId), sid = safeSessionId(sessionId);
  if (!id || !sid) return null;
  return withMissionContainerLock(id, async () => {
    const current = await readMissionContainer(id);
    if (!current) return null;
    if (!current.sessionIds.includes(sid)) return current;
    return writeMissionContainer(Object.assign({}, current, { sessionIds: current.sessionIds.filter(x => x !== sid) }));
  });
}

async function archiveMissionContainer(missionId) {
  const id = safeMissionId(missionId);
  if (!id) return null;
  return withMissionContainerLock(id, async () => {
    const current = await readMissionContainer(id);
    if (!current) return null;
    if (current.archivedAt) return current;                               // 幂等
    return writeMissionContainer(Object.assign({}, current, { archivedAt: nowIso() }));
  });
}

// 合并验收项:按【文本】去重(id 是各自文件里的局部主键,跨文件没有可比性;用户看到的是文本)。
function mergeMissionAcceptance(targetRows, sourceRows) {
  const seen = new Set((targetRows || []).map(row => row.text));
  const merged = (targetRows || []).slice();
  for (const row of (sourceRows || [])) {
    if (merged.length >= MISSION_CONTAINER_LIMITS.acceptanceItems) break;
    if (seen.has(row.text)) continue;
    seen.add(row.text);
    merged.push(row);
  }
  return merged;
}


// ── 116g:线程归属操作(加入 / 移出 / 合并 / 拆分)──────────────────────────────
// 会话头那侧一律经 `updateSessionMeta`(享受 116-2a 的活回合竞态防护:活回合期间延后到回合 settle
// 之后在【重新装载的副本】上重放,绝不用陈旧正文盖掉回合刚写的消息);事项文件那侧走 missionIndex*。
// 两侧都幂等,所以「重放一次」永远等于「没重放」。

// 只读会话【头】(不碰 NDJSON 正文):归属操作只需要 id/kind/missionId 三个字段,
// 没必要为此把整条会话的消息装进内存。
async function readMissionSessionHead(sessionId) {
  const sid = safeSessionId(sessionId);
  if (!sid) return null;
  try { return applySessionTitleOverride(safeJsonParse(await fsp.readFile(sessionPath(sid), 'utf8'), null)); } catch { return null; }
}

// 归属变更落一条 Mission Change(收件箱能看见事项级动作)。无 mission 账本的会话由
// bumpMissionChangeSeq 自身 no-op —— 这正是 §11.6 登记过的既有语义,这里不另开旁路。
function noteMissionMembership(sessionId, action, detail) {
  return bumpMissionChangeSeq(sessionId, {
    type: 'mission_membership',
    detail: Object.assign({ action: String(action || '') }, detail || {}),
  }).catch(() => null);
}

// 与会话头对账后的线程集合:事项文件的 sessionIds 是权威索引,但只有会话头 `missionId` 指回来的
// 才算数(文件损坏/回滚/手工删会话之后自愈的唯一入口)。
async function reconcileMissionThreads(missionId, metas) {
  const id = safeMissionId(missionId);
  if (!id) return [];
  const rows = Array.isArray(metas) ? metas : await listSessions().catch(() => []);
  return rows.filter(meta => meta && (meta.missionId || meta.id) === id).map(meta => meta.id);
}

async function missionAttachThread(missionId, sessionId) {
  const id = safeMissionId(missionId), sid = safeSessionId(sessionId);
  if (!id || !sid) return missionContainerFail('invalid_request', 'invalid missionId or sessionId');
  const container = await readMissionContainer(id);
  if (!container) return missionContainerFail('not_found', 'mission ' + id + ' not found');
  const head = await readMissionSessionHead(sid);
  if (!head || !head.id) return missionContainerFail('session_not_found', 'thread ' + sid + ' not found');
  if (head.kind === 'steward') return missionContainerFail('invalid_target', 'the steward session is not a thread and cannot join a mission');
  const previousMissionId = sessionMissionId(head) || sid;
  if (previousMissionId !== id) {
    await updateSessionMeta(sid, { missionId: id });
    if (previousMissionId !== sid) await missionIndexRemove(previousMissionId, sid);   // 旧事项的反向索引同步摘除
    await noteMissionMembership(sid, 'attach', { missionId: id, previousMissionId });
  }
  await missionIndexAdd(id, sid);                                                       // 幂等
  // 121-K2a(§6.1 第 4 条):线程改了归属。只在真的变过时派 —— 幂等的重复 attach 不是一件「发生的事」。
  if (previousMissionId !== id) RUYI_EVENTS.emit('thread.adopted', { sessionId: sid, missionId: id, title: String((head && head.title) || '') });
  return { ok: true, missionId: id, sessionId: sid, changed: previousMissionId !== id, mission: await readMissionContainer(id) };
}

// 移出 = 回到「未归类」(missionId === sessionId)。目标事项必须存在(404),这样「移出一个不存在的
// 事项」不会被静默当成成功。
async function missionDetachThread(missionId, sessionId) {
  const id = safeMissionId(missionId), sid = safeSessionId(sessionId);
  if (!id || !sid) return missionContainerFail('invalid_request', 'invalid missionId or sessionId');
  const container = await readMissionContainer(id);
  if (!container) return missionContainerFail('not_found', 'mission ' + id + ' not found');
  const head = await readMissionSessionHead(sid);
  if (!head || !head.id) return missionContainerFail('session_not_found', 'thread ' + sid + ' not found');
  if (head.kind === 'steward') return missionContainerFail('invalid_target', 'the steward session is not a thread');
  const previousMissionId = sessionMissionId(head) || sid;
  const changed = previousMissionId === id;
  if (changed) {
    await updateSessionMeta(sid, { missionId: sid });
    await noteMissionMembership(sid, 'detach', { missionId: id, previousMissionId });
  }
  await missionIndexRemove(id, sid);                                                    // 幂等
  return { ok: true, missionId: id, sessionId: sid, changed, mission: await readMissionContainer(id) };
}

// 合并:from 的全部线程 attach 到 target、验收项按文本去重并入、from 标 archivedAt。
// 幂等的来源不是标记位,而是三个子操作各自幂等:attach 幂等、验收去重幂等、archive 幂等 ——
// 所以「再合一次」天然零变化,不需要判断「是否已合过」。
async function missionMergeInto(targetMissionId, fromMissionId) {
  const targetId = safeMissionId(targetMissionId), fromId = safeMissionId(fromMissionId);
  if (!targetId || !fromId) return missionContainerFail('invalid_request', 'invalid missionId');
  if (targetId === fromId) return missionContainerFail('invalid_request', 'cannot merge a mission into itself');
  const target = await readMissionContainer(targetId);
  if (!target) return missionContainerFail('not_found', 'mission ' + targetId + ' not found');
  const from = await readMissionContainer(fromId);
  if (!from) return missionContainerFail('not_found', 'mission ' + fromId + ' not found');

  const metas = await listSessions().catch(() => []);
  const threads = new Set(await reconcileMissionThreads(fromId, metas));
  for (const sid of from.sessionIds) threads.add(sid);
  const moved = [];
  for (const sid of threads) {
    const result = await missionAttachThread(targetId, sid);
    if (result && result.ok) moved.push(sid);
  }
  const merged = await patchMissionContainer(targetId, {
    acceptance: mergeMissionAcceptance((await readMissionContainer(targetId) || target).acceptance, from.acceptance),
  });
  await archiveMissionContainer(fromId);
  logEvent({ kind: 'mission_container_merged', missionId: targetId, fromMissionId: fromId, threads: moved.length });
  return {
    ok: true, missionId: targetId, fromMissionId: fromId, movedSessionIds: moved,
    mission: (merged && merged.ok ? merged.mission : await readMissionContainer(targetId)),
    archived: await readMissionContainer(fromId),
  };
}

// 拆分:把源事项的一部分线程拆到一个新事项。幂等键 = 「同一组 sessionIds 已经完整落在一个同名
// 未归档事项里」—— 重复调用返回那个事项而不是再建一个同名空壳。
async function missionSplitThreads(sourceMissionId, sessionIds, title) {
  const sourceId = safeMissionId(sourceMissionId);
  if (!sourceId) return missionContainerFail('invalid_request', 'invalid missionId');
  const source = await readMissionContainer(sourceId);
  if (!source) return missionContainerFail('not_found', 'mission ' + sourceId + ' not found');
  const wantedTitle = missionClipText(title, MISSION_CONTAINER_LIMITS.titleChars);
  if (!wantedTitle) return missionContainerFail('invalid_request', 'title is required');
  const wanted = [];
  for (const value of (Array.isArray(sessionIds) ? sessionIds : [])) {
    const sid = safeSessionId(value);
    if (sid && !wanted.includes(sid)) wanted.push(sid);
  }
  if (!wanted.length) return missionContainerFail('invalid_request', 'sessionIds must contain at least one thread');

  const metas = await listSessions().catch(() => []);
  const sameSet = (a, b) => a.length === b.length && a.slice().sort().join(',') === b.slice().sort().join(',');
  for (const candidate of await listMissionContainers()) {
    if (candidate.archivedAt || candidate.title !== wantedTitle || candidate.missionId === sourceId) continue;
    if (sameSet(await reconcileMissionThreads(candidate.missionId, metas), wanted)) {
      return { ok: true, missionId: candidate.missionId, mission: candidate, created: false, movedSessionIds: [] };
    }
  }

  const created = await createMissionContainer({ title: wantedTitle, cwd: source.cwd, budget: source.budget });
  if (!created.ok) return created;
  const moved = [];
  for (const sid of wanted) {
    const result = await missionAttachThread(created.mission.missionId, sid);
    if (result && result.ok) moved.push(sid);
  }
  logEvent({ kind: 'mission_container_split', missionId: created.mission.missionId, fromMissionId: sourceId, threads: moved.length });
  return { ok: true, missionId: created.mission.missionId, mission: await readMissionContainer(created.mission.missionId), created: true, movedSessionIds: moved };
}
