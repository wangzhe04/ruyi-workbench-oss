// Root execution authority. MCP children never open this ledger; they need the root service.
const DesktopExecutionRuntime = (() => {
  let state = null;
  const admissions = new Map();
  const fail = (code, message) => Object.assign(new Error(message), { code, status: 409 });
  const generation = session => session.rewindGen === undefined ? 0 : session.rewindGen;
  function rootOwned() {
    if (!state || !state.dataIdentity || !state.ownership.isHeld() || !state.ownership.isRootCurrent(state.canonicalRoot)) return false;
    try {
      const named = fs.statSync(paths.data, { bigint: true }), canonical = fs.statSync(state.canonicalRoot, { bigint: true });
      return [named, canonical].every(stat => stat.isDirectory() && stat.dev === state.dataIdentity.dev
        && stat.ino === state.dataIdentity.ino && stat.birthtimeNs === state.dataIdentity.birthtimeNs);
    } catch { return false; }
  }
  function authority() {
    if (!state || state.phase !== 'ready' || !rootOwned()) {
      throw fail('execution_owner_lost', '桌面执行记录的服务所有权不可用，已停止继续执行。');
    }
    return state;
  }
  function current(scope) {
    const admitted = admissions.get(scope.sessionId);
    return !!admitted && !!state && state.phase === 'ready' && rootOwned()
      && admitted.id === scope.admissionId && admitted.turnSeq === scope.turnSeq && admitted.rewindGen === scope.rewindGen
      && admitted.session.turnSeq === scope.turnSeq && generation(admitted.session) === scope.rewindGen
      && turnSettlers.get(scope.sessionId) === admitted.owner && !admitted.owner.cancelRequested
      && admitted.owner.driverRunId === admitted.driverRunId;
  }
  async function initialize(ownership) {
    if (process.platform !== 'darwin') return;
    if (state) throw fail('execution_runtime_initialized', '桌面执行记录已经初始化；本进程不能再次接管。');
    if (!ownership || typeof ownership.isHeld !== 'function' || !ownership.isHeld()) {
      throw fail('execution_owner_required', '桌面执行记录需要实际的服务所有权。');
    }
    state = { phase: 'opening', ownership, ledger: null, dataIdentity: null, canonicalRoot: null };
    try {
      state.canonicalRoot = await ServerOwnership.canonicalRoot(paths.data);
      if (!ownership.isHeld() || !ownership.roots.includes(state.canonicalRoot) || !ownership.isRootCurrent(state.canonicalRoot)) {
        throw fail('execution_owner_lost', '服务没有持有当前数据目录的实际所有权。');
      }
      await fsp.mkdir(paths.data, { recursive: true });
      await ownership.confirmRoot(paths.data);
      state.dataIdentity = await fsp.stat(paths.data, { bigint: true });
      if (!rootOwned()) throw fail('execution_owner_lost', '数据目录在初始化期间发生变化。');
      const ledger = DesktopExecutionLedger.create({ directory: path.join(paths.data, 'desktop-executions-v1'),
        isOwner: rootOwned, isTurnCurrent: current });
      await ledger.open();
      if (!rootOwned()) throw fail('execution_owner_lost', '服务所有权在恢复期间失效。');
      state.ledger = ledger;
      state.phase = 'ready';
    } catch (error) { state.phase = 'failed'; throw error; }
  }
  async function guard(sessionId) {
    // Non-serve consumers do not acquire or mutate shared execution state.
    if (!state) return;
    const root = authority(), observed = await root.ledger.guard(sessionId);
    authority();
    if (!observed.ok) throw fail('execution_reconciliation_required',
      '上次桌面操作的执行或结果保存尚未确认，已暂停本会话的自动继续，请先核实执行记录。');
  }
  function admit(session, owner) {
    if (!state) return null;
    authority();
    if (!owner || turnSettlers.get(session.id) !== owner || owner.cancelRequested
        || typeof owner.driverRunId !== 'string' || !owner.driverRunId
        || !Number.isSafeInteger(session.turnSeq) || session.turnSeq < 1
        || !Number.isSafeInteger(generation(session)) || generation(session) < 0) {
      throw fail('execution_admission_lost', '桌面执行需要当前服务实际持有的回合身份。');
    }
    const old = admissions.get(session.id), rewindGen = generation(session);
    if (old && old.session === session && old.owner === owner && old.turnSeq === session.turnSeq && old.rewindGen === rewindGen) return old.id;
    const entry = { id: crypto.randomBytes(32).toString('hex'), session, owner,
      driverRunId: owner.driverRunId, turnSeq: session.turnSeq, rewindGen };
    admissions.set(session.id, entry);
    return entry.id;
  }
  function release(sessionId, owner) {
    if (admissions.get(sessionId)?.owner === owner) admissions.delete(sessionId);
  }
  function canWriteStartupError() {
    return process.platform !== 'darwin' || rootOwned();
  }
  // Preparation uses this exact admitted session object, never caller-provided turn numbers.
  async function prepare({ session, owner, callId, toolName, args, client }) {
    const root = authority(), admitted = admissions.get(session.id);
    if (!admitted || admitted.session !== session || admitted.owner !== owner || typeof callId !== 'string' || !callId) {
      throw fail('execution_admission_lost', '工具调用没有当前回合的实际准入身份。');
    }
    return root.ledger.prepare({ sessionId: session.id, turnSeq: admitted.turnSeq, rewindGen: admitted.rewindGen,
      admissionId: admitted.id, callIdHash: crypto.createHash('sha256').update(admitted.driverRunId + '\0' + callId).digest('hex'),
      toolName, args, client });
  }
  return Object.freeze({ initialize, guard, admit, release, prepare, canWriteStartupError });
})();
Object.assign(DesktopExecutionHooks, DesktopExecutionRuntime);
