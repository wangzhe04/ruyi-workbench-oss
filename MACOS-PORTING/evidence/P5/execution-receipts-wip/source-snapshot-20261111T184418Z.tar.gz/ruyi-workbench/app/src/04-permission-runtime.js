// 117w-W1 提交②(27 号文 §11.19.2):Windows 文件系统非法字符的【唯一一份】替换表 —— 尖括号、
// 冒号、双引号、两种斜杠、竖线、问号、星号、控制字符,一律换成下划线;中文与其它可见字符原样保留。
// 修前它是 makeAttachmentRecord 里的一条内联正则,提交② 的派生子工作区(13k stewardWorkspaceSlug)
// 要用同一张表 —— 抄第二份迟早分叉(一边补了新字符另一边没补,于是「附件名安全、目录名不安全」)。
// 抽成函数是为了让两处【共用同一个正则字面量】,不是为了复用一行代码。
function sanitizeFsSegmentName(fsSegmentRaw) {
  return String(fsSegmentRaw == null ? '' : fsSegmentRaw).replace(/[<>:"/\\|?*\x00-\x1F]/g, '_');
}

async function makeAttachmentRecord(input) {
  await ensureDirs();
  const id = makeId('file');
  // 代码走查 C8:名字按 Windows 形取文件名(认 \ 与 /);非字符串、空、「.」「..」、全是点和空格(Windows 会吃掉
  // 结尾的点与空格)一律回落 upload.bin。修前「..」会写到目录本身上:EISDIR 500、报错带出数据目录绝对路径。
  const rawName = typeof input.name === 'string' ? input.name : '';
  let safeName = sanitizeFsSegmentName(path.win32.basename(rawName)).replace(/[. ]+$/, '').slice(0, 200);
  if (!safeName || /^[. ]*$/.test(safeName)) safeName = 'upload.bin';
  const targetDir = path.join(paths.uploads, id);
  await fsp.mkdir(targetDir, { recursive: true });
  const target = path.join(targetDir, safeName);
  const base64 = String(input.data || '').includes(',')
    ? String(input.data).split(',').pop()
    : String(input.data || '');
  const buffer = Buffer.from(base64, 'base64');
  try { await fsp.writeFile(target, buffer); }
  catch (error) { await fsp.rm(targetDir, { recursive: true, force: true }).catch(() => {}); throw error; }   // 不留空的 uploads/<id>/

  let textPreview = '';
  // v1.9:svg 是文本(矢量图源码)进 textPreview;像素图(png/jpg/…)不进,打 kind:'image' 走图片预处理。
  const textLike = /\.(txt|md|json|js|ts|tsx|jsx|py|ps1|bat|cmd|csv|xml|svg|html|css|yaml|yml|ini|log)$/i.test(safeName);
  if (textLike && buffer.length <= 256 * 1024) {
    textPreview = decodeTextFileBytes(buffer, true).slice(0, 12000);   // 走查 W1·F4:GBK / UTF-16(带 BOM)按内容判编码,不再一律当 UTF-8
  }
  // 127-114c②(26 号文 §3):音频附件打 kind:'audio'(扩展名白名单)——上传路由凭它触发尽力转写;
  // 非音频不落此字段(与 hiddenModels/caps「空不落字段」同模具,存量记录形状零漂移)。
  const audioLike = /\.(wav|mp3|m4a|webm|ogg|flac)$/i.test(safeName);
  // v1.9:图片附件打 kind:'image'(与 audio 同模具,空不落字段)——上传路由凭它触发图片预处理
  // (OCR 文本兜底 / 超限压缩派生件,见 13b maybeOcrImageAttachment / maybeCompressImageAttachment)。
  const imageLike = /\.(png|jpe?g|gif|webp|bmp)$/i.test(safeName);
  return {
    id,
    name: safeName,
    path: target,
    size: buffer.length,
    createdAt: nowIso(),
    textPreview,
    ...(audioLike ? { kind: 'audio' } : {}),
    ...(imageLike ? { kind: 'image' } : {}),
  };
}

// --- Secret redaction (unconditional, CLI-independent). Redacts DISPLAY copy only, never the
// executed string. Purpose-built patterns, not the quoted-only code_review_scan regex. ---
const REDACT_PATTERNS = [
  // 107-S0(45 号文 §9.6 发现 5):sk- 之后允许 `_`／`-`。修前只认纯字母数字,`sk-proj-…`／`sk-ant-api03-…` 这类
  // 带分段的真 key 在第一个 `-` 处就断到不足 16 字,整把漏掉(真机会话文件里就有一把这样漏的)。
  /\b(sk-[A-Za-z0-9][A-Za-z0-9_-]{15,})/g,
  /\b(gh[pousr]_[A-Za-z0-9]{20,})\b/g,
  /\b(xox[baprs]-[A-Za-z0-9-]{10,})\b/g,
  /\bBearer\s+([A-Za-z0-9._~+/-]{16,}=*)/gi,
  /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{6,}\b/g, // JWT
  /\b((?:api[_-]?key|secret|token|password|passwd|pwd|access[_-]?key)\s*[:=]\s*)([^\s"']{6,})/gi,
  /\b([A-Fa-f0-9]{40,})\b/g, // long hex blobs
  // 127 波 2-quater B1 ③(45 号文 §2-quater.1 取证 7):管家的豁免命令摘录也走这张表(单一来源,不另立一份),
  // 而命令行里的凭据长得和日志里的不一样 —— 下面六种修前全漏。都是「标签 + 值」两组或「整段」一组,沿用上面
  // redact() 按组数决定留不留标签的既有口径;量词都有界或以分隔符收口,长文本上不回溯爆炸。
  /\b([a-z][a-z0-9+.-]{0,20}:\/\/[^\s:@\/]{1,256}:)([^\s@\/]{1,256})(?=@)/gi, // URL 里的 userinfo:https://user:pass@host
  /((?:^|\s)(?:-u|-U|--user|--proxy-user)\s*["']?[^\s:"'@]{2,256}:)([^\s"';&|]+)/g, // curl -u user:pass(用户名至少 2 字:`python -u C:\x.py` 的盘符不算)
  /\b(authorization\s*[:=]\s*basic\s+)([A-Za-z0-9+/=._~-]{4,})/gi, // Authorization: Basic xxx
  /((?:^|\s)--?(?:password|passwd|pwd|pass|token|secret|api[_-]?key)\s+["']?)([^\s"';&|]+)/gi, // --password xxx(空格分隔;值在命令分隔符处收口)
  /((?<=[A-Za-z0-9_])(?:password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key)\s*[:=]\s*)([^\s"'&;|]+)/gi, // 词中:PGPASSWORD= / DB_PASSWORD= / OPENAI_API_KEY=(上面那条的 \b 在词中失效)
  /\b(AKIA[0-9A-Z]{16})\b/g, // AWS access key id
  // 107-S0(45 号文 §9.6 发现 5:真机会话文件里 58 处真 key 值,旧表 redact 后仍剩 39 处):值带引号的「标签 + 值」。
  // 上面那条标签式要求值紧跟在 `:`／`=` 后、且不以引号开头,于是 JSON `"apiKey": "…"`、JS `apiKey: '…'`、
  // Python／TOML／.env／PowerShell `api_key = "…"` 全漏;模型 file_read 过 config.json 之后,会话文件里存的还是
  // 转义过的 `\"apiKey\": \"…\"`(再嵌一层就是 `\\\"`)。
  //   - 标签:以这几个词【结尾】的键(`accessToken`／`client_secret`／`x-api-key`／`OPENAI_API_KEY` 都算),词后面
  //     紧跟(可选的反斜杠＋)引号或直接 `:`／`=` —— 所以 `"maxTokens"`／`"tokenCount"`／`"token_type"` 不算;
  //   - 值:必须以引号开头(数字、null、对象、数组都不碰),`"Bearer ／Basic ／Token "` 前缀留在标签里;
  //   - 值只收可打印 ASCII 且不含空格、引号、反斜杠 —— 遇到转义引号就收口;中文文案(locale 里 `"…ApiKey": "端点密钥…"`)不误伤。
  // 量词全部有界,值之后没有任何需要回溯的成分,长文本线性。
  /((?:api[_-]?key|access[_-]?key|secret[_-]?key|private[_-]?key|secret|token|password|passwd|authorization)\\{0,8}["']?\s{0,8}[:=]\s{0,8}\\{0,8}["'](?:(?:bearer|basic|token)\s{1,8})?)([!#-&(-\[\]-~]{6,4096})/gi,
];
function redact(input) {
  let s = String(input == null ? '' : input);
  for (const re of REDACT_PATTERNS) {
    re.lastIndex = 0;
    // replace passes (match, p1, …, pN, offset, string). For a label+value pattern (2 capture groups: the
    // `apiKey=`-style label and the secret value) we keep the label and redact only the value. For a
    // single-capture secret pattern (sk-…, ghp_…, JWT, hex blob) we replace the WHOLE match with the marker.
    // (Bugfix: the old `(m,a,b)=> b===undefined?…:`${a}…`` treated the numeric offset as a 2nd group, so
    // single-group secrets leaked as `secret«redacted»`. Detecting group count via arguments fixes it.)
    s = s.replace(re, function () {
      const args = Array.from(arguments);
      // Trailing args are offset(number) then optionally the full string; strip them to get capture groups.
      let end = args.length;
      if (typeof args[end - 1] === 'string' && typeof args[end - 2] === 'number') end -= 2; // …, offset, string
      else if (typeof args[end - 1] === 'number') end -= 1;                                  // …, offset
      const groups = args.slice(1, end); // capture groups only (args[0] is the full match)
      // Two capture groups → label + value: keep the label, redact the value.
      if (groups.length >= 2 && groups[1] !== undefined) return `${groups[0]}«redacted»`;
      return '«redacted»';
    });
  }
  return s;
}

// --- Structured NDJSON logging: record lengths/metadata, never raw content. ---
let logStream = null;
let logStreamDay = '';
function logEvent(record) {
  try {
    const day = nowIso().slice(0, 10);
    if (day !== logStreamDay && logStream) {
      logStream.end();
      logStream = null;
    }
    if (!logStream) {
      logStreamDay = day;
      logStream = fs.createWriteStream(path.join(paths.logs, `workbench-${day}.ndjson`), { flags: 'a' });
      logStream.on('error', () => { logStream = null; });
    }
    logStream.write(`${JSON.stringify({ ts: nowIso(), ...record })}\n`);
  } catch {
    // logging must never break a turn
  }
}

// --- Active claude child registry keyed by session id, for stop/restart/interrupt + disconnect kill. ---
const activeChildren = new Map(); // sessionId -> { child, pid, state, startedAt, lastEventAt, interactive, onEvent }
// 第 117 波 117l D4(27 号文 §11.9;用户第四轮走查第 3 条「『它刚说』更新不够及时」):活回合尾巴的累加器。
// 两个引擎(09 的 provider 回合与 05 的 Claude 回合)在各自的 reg.onEvent 包装里调它 —— 同一份口径、
// 同一份预算,不各写一套。三条纪律:
//   ① 只在内存(reg 上),不落盘、不进任何投影 —— 回合一结束 reg 从 activeChildren 里去掉,尾巴随之消失;
//   ② 只留最后 600 字(抖动的是“它正在说什么”,不是全文;全文在回合收尾时才落盘);
//   ③ 工具名只在【工具在跑】期间在:tool_use 记上,tool_result 清掉。
// 发不出事件的回合(引擎不流 delta)就是空尾巴 —— 不编,不拿上一回合的话冒充(§11.2 「诚实」)。
//
// 117m-A5(用户第六轮走查①「现在点开线程的看全文,还是啥也看不到」):把这个累加器从「尾巴」扩成
// 「本回合正文」。根因是助手消息在【回合收尾】才落盘,而管家起的回合没有任何客户端挂在它的流上 ——
// 用户真机上跑了 15 分钟、53 次工具调用,messages.ndjson 只有那条 user 消息一行。经典壳只渲染已落盘的
// messages,于是「看全文」是一片空白。修法不是提前落盘(那会把半截正文写进数据面),而是把内存里这份
// 活文本扩到够看,经既有的 GET /api/sessions/:id 信封下发。四条新纪律,与上面三条并列:
//   ④ text 的语义与 600 字上限【一个字不动】—— 抽屉的「它正在说」在用它,117l 的断言钉着它;
//   ⑤ 新增 full = 本回合从头累加的助手正文,硬顶 12000 字。超顶从【头部】丢弃并置 truncated:true:
//      用户要看的是「它现在在说什么」,砍掉的应该是最早那段,不是刚说的;
//   ⑥ 新增 tools = 最近 ≤20 条工具名 + 起止 + 状态。**只存名字与状态,不存参数、不存结果** ——
//      参数与结果里可能有密钥/路径/整份文件内容,这条信封是给「看一眼它在干嘛」用的,不是审计面;
//   ⑦ 新增 startedAt(回合起点)与 iterations(工具轮次:一批并行工具算一轮)。
// 全部仍然只在内存,回合一结束 reg 从 activeChildren 里去掉,这份东西随之整份消失。
const LIVE_TAIL_CHARS = 600;
const LIVE_FULL_CHARS = 12000;
const LIVE_TOOLS_MAX = 20;
function appendLiveTail(reg, evt) {
  if (!reg || !evt) return;
  // 代理模式 v2:子代理自己的工具事件(带 subagentId)不进父回合的实时工具列表与迭代计数 —— 它们只属于代理卡/代理面板。
  if (evt.subagentId) return;
  const tail = reg.liveTail && typeof reg.liveTail === 'object' ? reg.liveTail : (reg.liveTail = { text: '', tool: '', updatedAt: '' });
  // 05/09 建的仍是 117l 那个三字段裸对象(本波不碰那两个文件),缺的字段在这里就地补齐 —— 累加器是
  // 唯一的写口,补在这里就不会有「某条路径的 reg 少个键」的形状分叉。
  if (typeof tail.full !== 'string') tail.full = '';
  if (typeof tail.truncated !== 'boolean') tail.truncated = false;
  if (!Array.isArray(tail.tools)) tail.tools = [];
  if (typeof tail.startedAt !== 'string') tail.startedAt = '';
  if (!Number.isFinite(tail.iterations)) tail.iterations = 0;
  const type = String(evt.type || '');
  const at = nowIso();
  if (type === 'assistant_delta') {
    const chunk = String(evt.text || '');
    if (!chunk) return;
    tail.text = (tail.text + chunk).slice(-LIVE_TAIL_CHARS);
    const merged = tail.full + chunk;
    if (merged.length > LIVE_FULL_CHARS) { tail.full = merged.slice(merged.length - LIVE_FULL_CHARS); tail.truncated = true; }
    else tail.full = merged;
  } else if (type === 'tool_use') {
    const name = String(evt.name || evt.tool || '').slice(0, 80);
    tail.tool = name;
    // 轮次:provider 路径有 batchId(09 的包装给同一批并行工具打同一个),换批才 +1;Claude 路径没有
    // batchId,退化成「上一个事件不是 tool_use 就算新的一轮」。两条路都不把一批并行工具数成 N 轮。
    const batch = String(evt.batchId || '');
    const sameBatch = batch ? batch === tail.batchMark : tail.lastKind === 'tool_use';
    if (!sameBatch) tail.iterations += 1;
    tail.batchMark = batch;
    tail.tools.push({ id: String(evt.id || ''), name, startedAt: at, endedAt: '', status: 'running' });
    while (tail.tools.length > LIVE_TOOLS_MAX) tail.tools.shift();
  } else if (type === 'tool_result') {
    tail.tool = '';
    const id = String(evt.id || '');
    for (let i = tail.tools.length - 1; i >= 0; i -= 1) {
      const row = tail.tools[i];
      if (!row || row.status !== 'running') continue;
      if (id && row.id && row.id !== id) continue;
      row.endedAt = at;
      row.status = evt.isError ? 'error' : 'done';
      break;
    }
  } else return;
  tail.lastKind = type;
  if (!tail.startedAt) tail.startedAt = Number.isFinite(reg.startedAt) ? new Date(reg.startedAt).toISOString() : at;
  tail.updatedAt = at;
  notifyActiveChildTaps(reg, evt);   // 121-K2a:尾巴刚变过 —— 见下面那段头注
}

// ────────────────────────────────────────────────────────────────────────────
// 第 121 波 K2a(34 号文 §6.1 第 1 条):活回合事件的【旁路订阅者】。
//
// 34 号文摸底把 `reg.onEvent` 写成「唯一的扇出点」。实测不是:05:9-10 与 09:1238-1239 两处头注
// 说得很清楚 —— `reg.onEvent` 只看得见【桥接/MCP 那一路】的事件,引擎自己流出来的
// assistant_delta / tool_use / tool_result 走的是两个引擎各自的【本地 onEvent 包装】。
// 那个包装里两条路唯一的交汇点就是上面的 appendLiveTail(117l D4 为了「同一份口径」才抽出来的)。
// 所以旁路订阅装在【两处】,一份订阅者名单:
//   ① appendLiveTail 末尾 —— 尾巴真的变过之后才通知(thread.live 要的正是这份尾巴);
//   ② installActiveChildEventFanout 包装的 reg.onEvent —— 桥接/MCP 那一路的事件。
// 两条路对同一个事件可能各通知一次(桥接事件会先进 reg.onEvent 再落到本地包装),订阅者按会话
// 节流,重复不产生第二条帧;宁可多通知一次,也不要因为「猜哪条路会到」而漏。
//
// 三条纪律:
//   ① 引擎自己那个订阅者(05:491 / 09:1389 装的 reg.onEvent)行为【逐字不变】且【第一个收到】——
//      旁路一律排在它后面,且不参与它的异常传播(它抛,旁路就不跑,原路径的语义一个字不变);
//   ② 旁路订阅者抛错就地吞掉 —— 观察面绝不反噬回合;
//   ③ 旁路只读 reg,不许改它的任何字段。
const ACTIVE_CHILD_EVENT_TAPS = new Set();
function subscribeActiveChildEvents(fn) {
  if (typeof fn !== 'function') return () => {};
  ACTIVE_CHILD_EVENT_TAPS.add(fn);
  return () => { ACTIVE_CHILD_EVENT_TAPS.delete(fn); };
}
function notifyActiveChildTaps(reg, evt) {
  if (!ACTIVE_CHILD_EVENT_TAPS.size) return;   // 零订阅者 = 零开销(同 RUYI_EVENTS.emit)
  for (const tap of ACTIVE_CHILD_EVENT_TAPS) {
    try { tap(reg, evt); } catch { /* 纪律②:旁路的错不许回流到回合 */ }
  }
}
// 把一份【已经装好引擎订阅者】的 reg 改成多订阅者:原来那个函数原样保留并永远第一个收到,
// 旁路名单排在它后面。两个引擎各在 `reg.onEvent = ...` 之后调一次。
function installActiveChildEventFanout(reg) {
  if (!reg || typeof reg.onEvent !== 'function' || reg.__eventFanout) return reg;
  const engineSubscriber = reg.onEvent;   // 纪律①:它是第一个,也是唯一一个能影响回合的
  reg.__eventFanout = true;
  reg.onEvent = evt => {
    engineSubscriber(evt);                // 原行为逐字不变(含它自己的异常传播)
    notifyActiveChildTaps(reg, evt);
  };
  return reg;
}
// 回合 settle 登记表(第69波 rewind 竞态修复):sessionId -> { promise, resolve }。driver(chat/stream)
// 在回合开始登记、driver finally(收尾 saveSession 已落盘后)resolve 并删除。stopSession 会立即删
// activeChildren,但被停回合的收尾(推 aborted assistant + saveSession)发生在此之后 —— rewindSession
// 若只看 activeChildren 就会在这个窗口截断落盘,然后被 dying turn 的收尾 save 整份盖回(丢失写:
// 「回溯了但消息又回来」)。rewindSession 先等本表 settle 再截断,顺序由此确定。
const turnSettlers = new Map();
// A logical driver owns all of its queued/child turns. Never infer ownership from the current child.
// Bounded evidence for completed-then-undo. A newer admitted driver replaces the old identity.
const sessionLastExecutions = new Map();
let sessionExecutionEvictionGeneration = 0;
function recordSessionExecutionOwner(sessionId, owner) {
  turnSettlers.set(sessionId, owner);
  sessionLastExecutions.delete(sessionId);
  sessionLastExecutions.set(sessionId, owner.driverRunId);
  while (sessionLastExecutions.size > 2048) {
    sessionLastExecutions.delete(sessionLastExecutions.keys().next().value);
    sessionExecutionEvictionGeneration += 1;
  }
}
function sessionExecutionObservation(sessionId) {
  return { serverInstanceId: OVERLAY_ID, lastDriverRunId: sessionLastExecutions.get(sessionId) || null, evictionGeneration: sessionExecutionEvictionGeneration };
}
function sessionExecutionSnapshot(sessionId) {
  const owner = turnSettlers.get(sessionId);
  if (!owner || !owner.driverRunId) return null;
  return { serverInstanceId: OVERLAY_ID, driverRunId: owner.driverRunId, phase: owner.cancelRequested ? 'stopping' : owner.phase || 'starting' };
}
function sessionExecutionCheck(sessionId, expectedExecution) {
  const execution = sessionExecutionSnapshot(sessionId);
  const owner = turnSettlers.get(sessionId) || null;
  if (expectedExecution === undefined && execution) return { ok: false, error: 'execution_identity_required', execution };
  if (expectedExecution == null && !execution) return { ok: true, owner, execution };
  if (!execution || !expectedExecution || typeof expectedExecution !== 'object'
      || expectedExecution.serverInstanceId !== execution.serverInstanceId || expectedExecution.driverRunId !== execution.driverRunId) {
    return { ok: false, error: 'execution_changed', execution };
  }
  return { ok: true, owner, execution };
}
function sessionExecutionCheckRewind(sessionId, expectedExecution) {
  if (!sessionExecutionSnapshot(sessionId) && expectedExecution && typeof expectedExecution === 'object'
      && expectedExecution.serverInstanceId === OVERLAY_ID && typeof expectedExecution.driverRunId === 'string'
      && sessionLastExecutions.get(sessionId) === expectedExecution.driverRunId) {
    return { ok: true, owner: null, execution: null };
  }
  return sessionExecutionCheck(sessionId, expectedExecution);
}
function assertSessionExecutionOwner(sessionId, owner) {
  if (owner && (owner.cancelRequested || turnSettlers.get(sessionId) !== owner)) {
    throw Object.assign(new Error('Execution stopped or superseded'), { code: 'STEWARD_TURN_CANCELLED' });
  }
}
function registerSessionExecutionChild(sessionId, reg, owner) {
  assertSessionExecutionOwner(sessionId, owner);
  reg.executionOwner = owner || null;
  activeChildren.set(sessionId, reg);
  // Event listeners may synchronously request cancellation when registration is announced.
  if (owner) owner.phase = 'running';
  assertSessionExecutionOwner(sessionId, owner);
}
function requestSessionExecutionStop(sessionId, expectedExecution, reason = 'stopped') {
  const checked = sessionExecutionCheck(sessionId, expectedExecution);
  if (!checked.ok) return checked;
  const owner = checked.owner;
  if (!owner || !owner.driverRunId) return { ok: true, stopped: false, queuedStopped: false, execution: null };
  const explicitStop = reason !== 'disconnected';
  const alreadyRequested = explicitStop ? owner.explicitStopRequested === true : owner.cancelRequested === true;
  if (explicitStop) owner.explicitStopRequested = true;
  // Mark first to close launch gates, then capture queue cancellation before AbortSignal listeners remove it.
  owner.cancelRequested = true; owner.phase = 'stopping';
  const queuedStopped = typeof SessionExecutionHooks.cancelQueuedTurn === 'function'
    && SessionExecutionHooks.cancelQueuedTurn(sessionId, owner.driverRunId) === true;
  owner.cancel(reason);
  const reg = activeChildren.get(sessionId);
  if (reg && reg.executionOwner === owner) stopSession(sessionId, reason);
  if (explicitStop && !owner.explicitStopGrantsRevoked && typeof SessionExecutionHooks.revokeGrants === 'function') {
    SessionExecutionHooks.revokeGrants(sessionId);
    owner.explicitStopGrantsRevoked = true;
  }
  return { ok: true, stopped: true, queuedStopped, execution: sessionExecutionSnapshot(sessionId), alreadyRequested };
}
SessionExecutionHooks.owns = (sessionId, owner) => Boolean(owner && turnSettlers.get(sessionId) === owner);
SessionExecutionHooks.observation = sessionExecutionObservation;
SessionExecutionHooks.snapshot = sessionExecutionSnapshot;
SessionExecutionHooks.checkRewind = sessionExecutionCheckRewind;
SessionExecutionHooks.check = sessionExecutionCheck;
SessionExecutionHooks.stop = requestSessionExecutionStop;
// 「回合成败账」正在落盘的会话(10 runSessionTurn 收尾)。turnSettlers 在回合 saveSession 之后就删了,而成败账
// (会话头 stewardLastTurn)是紧跟着再写的 —— 这中间的几毫秒里收件箱第四源读到头会看见「回合跑完、没有成败账」
// 并按「账缺席 = done」报,于是一个失败回合被报成收工(2026-10 真机:network_down 失败回合被管家说成「已收工」)。
// 收件箱收集(13i)把本表与活回合同等对待:在表里就等下一拍。只活在内存。
const turnOutcomePending = new Set();
// --- Pending tool-permission prompts awaiting a UI decision (v3 bridge). ---
const pendingPermissions = new Map(); // requestId -> { resolve, sessionId, timer, deadlineAt }

// 128f-⑪(Brief §4.2 第 7 条前半;用户 2026-09-19 拍板 A「立刻通知你,请求挂 600 秒等你处理」):
// 一条权限请求【等多久】的唯一判据。修前四处各算各的 —— provider 回合(09)与 Kimi 桥(05b)经 07 的
// requestNativePermission 认定时任务那张表,Claude CLI 桥(13d)与两种 CLI 子进程的超时环境变量(05/05b)
// 只认 config.permissionTimeoutMs(定时线程上的 CLI 引擎于是 120 s 就被子进程那一侧放弃,服务端却还在等 30 分钟)。
// 现在四处都问这一个函数;两格【迟绑定】(本文件拼在 07 与 13x 之前,直引它们的符号是前向边):
//   · scheduler —— 07 的 schedulerAskWaitOverrideMs(定时任务派出去的回合,默认 30 分钟);
//   · steward   —— 13k:管家开着、这条线程由管家盯着、用户此刻没坐在它前面 → 600 s。管家要么代批
//                  (真模型实测 37 s),要么说「留给你」并立刻通知(13q 的 steward.deferred);留给用户的
//                  那一件要真的等得到人,120 s 就过期的话「留给你」是一句空话(45 号文 §9.6.5 (b):120.015 s 超时拒)。
// **只改「等多久」,不改「等到了怎么判」**:到时照旧是拒(fail-closed),与定时任务那张表同一条子集律。
const PermissionWaitHooks = {};
// 2026-09-24「不限时」:配置 0(新默认)= 一直等。落到定时器上用一个【有限】的大数 —— setTimeout 超过
// 2^31-1 ms 会当场触发(等于立刻拒),而 CLI 子进程那一侧(12)还要在它上面 +10 s 当 HTTP 预算,所以留足余量。
// 界面按 PROMPT_DEADLINE_HORIZON_MS 判「这是不是一个真截止时刻」:超过一周的一律不显示倒计时。
const PROMPT_WAIT_UNLIMITED_MS = 2147000000;   // ≈24.8 天,< 2^31-1 - 10 s
const PROMPT_DEADLINE_HORIZON_MS = 7 * 24 * 3600 * 1000;
function promptWaitMs(value, floorMs = 5000) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? Math.min(PROMPT_WAIT_UNLIMITED_MS, Math.max(floorMs, n)) : PROMPT_WAIT_UNLIMITED_MS;
}
function promptDeadlineIsReal(deadlineAt, nowMs = Date.now()) {
  const at = Number(deadlineAt);
  return Number.isFinite(at) && at > 0 && at - nowMs <= PROMPT_DEADLINE_HORIZON_MS;
}
function permissionWaitMs(sessionId, config, sessionHead) {
  const base = promptWaitMs(config && config.permissionTimeoutMs);
  const sid = String(sessionId || '');
  try {
    const scheduled = typeof PermissionWaitHooks.scheduler === 'function' ? Number(PermissionWaitHooks.scheduler(sid)) : 0;
    if (Number.isFinite(scheduled) && scheduled > 0) return scheduled;
  } catch { /* 迟绑定缺席或抛错:当没有这一格 */ }
  try {
    const mediated = typeof PermissionWaitHooks.steward === 'function' ? Number(PermissionWaitHooks.steward(sid, config, sessionHead)) : 0;
    if (Number.isFinite(mediated) && mediated > 0) return Math.max(base, mediated);
  } catch { /* 同上 */ }
  return base;
}
// Questions are a real turn boundary, not a fire-and-forget notification. Both the Provider tool loop and
// the Claude MCP bridge wait on this registry; /api/chat/answer settles exactly one matching entry.
const pendingQuestions = new Map(); // questionId -> { sessionId, questions, timer, deliver }
// v0.9-S5: pending PLAN approvals awaiting a UI decision (真流程 plan mode). Mirrors pendingPermissions:
// planId -> { resolve, sessionId, timer }. runOpenAiTurn (plan mode, provider engine) emits a `plan` event
// after the model's first PLAN: message and PAUSES the turn awaiting /api/plan/decision. resolve() settles
// with { decision:'approve'|'reject', note? }; the timeout auto-rejects (same permissionTimeoutMs budget).
const pendingPlans = new Map(); // planId -> { resolve, sessionId, timer }
// 第27f波:当前处于【无人值守(driverAuto)回合】的会话集 —— provider 路径直接用闭包 driverAuto,但 CLI 桥(Claude 子进程
// loopback 的 /api/permission/request)拿不到 driverAuto,故用此集判定。runClaudeTurn 的 driverAuto 回合进出维护。纯内存。
const driverAutoSessions = new Set();

// ── 128i(48 号文 §1):收尸只认自己的子孙 ────────────────────────────────────────────────────────────
// 修前是 `taskkill /PID <pid> /T /F`:/T 按 ParentProcessId 认子孙,而 Windows 的父号在父进程死后【不更新】、进程号
// 又复用得很勤 —— 用户机器上常有父进程早已不在的长命进程(explorer.exe、各种托盘程序),我们要杀的进程若恰好
// 拿到了它们那个过期父号,/T 会不会把它们一起带走,没能取证排除(128c:3 万次 spawn 逼不出撞号)。测试框架里
// 按父号认子孙的自造收尸器真杀过用户的 Ollama(107 波 F8)。所以不赌 /T:
//   · 子孙只认【创建时间不早于父进程】的 —— 撞号的陌生人一定比我们要杀的根更老,按构造排除;
//   · 动手前逐个按启动时间(FILETIME)再核一次,快照到动手之间号若被复用,对不上就不杀;
//   · conhost.exe 不杀(它随最后一个客户端自己走;先杀它会把同控制台上的孙子连带杀掉);深的先杀,根最先。
// 整段逻辑写成一段 PowerShell,用 -EncodedCommand 传(不经任何引号转义),分离启动、不等它 —— 与修前 taskkill 一样
// 是「发出去就算」:服务正在退出时调到这里,收尸也照样跑完(Node 里做异步快照的话,进程一退就没下文了;而
// libuv 的子进程 job 允许孙辈静默脱离,shell 会话里用户起的命令不会随服务一起死)。
// dry 模式(__TABLE__ 给一张合成进程表、只打计划不动手)供单测钉「撞号的陌生人不算子孙」这个真机上逼不出来的形状。
const OWN_TREE_KILL_PS = [
  "$ErrorActionPreference = 'SilentlyContinue'",
  '$rootId = [int]__ROOT__',
  '$dry = __DRY__',
  "$tableJson = '__TABLE__'",
  // PowerShell 5.1:@(ConvertFrom-Json '[…]') 得到的是「一个元素、里面装着整个数组」—— 必须显式展开(128i 单测 P1 逮到)。
  'if ($tableJson) { $all = @((ConvertFrom-Json $tableJson) | ForEach-Object { $_ }) } else {',
  '  $all = @(Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId,CreationDate,Name | Where-Object { $_.CreationDate } | ForEach-Object {',
  '    [pscustomobject]@{ ProcessId = [int]$_.ProcessId; ParentProcessId = [int]$_.ParentProcessId; Created = [int64]$_.CreationDate.ToFileTimeUtc(); Name = [string]$_.Name } })',
  '}',
  '$root = $all | Where-Object { [int]$_.ProcessId -eq $rootId } | Select-Object -First 1',
  "if (-not $root) { 'ROOT-GONE'; exit 0 }",
  '$tree = New-Object System.Collections.ArrayList',
  '$seen = @{}; $seen[[int]$root.ProcessId] = $true',
  '$queue = New-Object System.Collections.Queue; $queue.Enqueue($root)',
  'while ($queue.Count -gt 0) {',
  '  $cur = $queue.Dequeue()',
  '  foreach ($p in $all) {',
  '    if ($seen.ContainsKey([int]$p.ProcessId)) { continue }',
  '    if ([int]$p.ParentProcessId -ne [int]$cur.ProcessId) { continue }',
  '    if ([int64]$p.Created -lt [int64]$cur.Created) { continue }',
  '    $seen[[int]$p.ProcessId] = $true; [void]$tree.Add($p); $queue.Enqueue($p)',
  '  }',
  '}',
  '$tree.Reverse()',
  "$targets = @($root) + @($tree | Where-Object { [string]$_.Name -ne 'conhost.exe' })",
  "if ($dry) { foreach ($t in $targets) { 'PLAN ' + $t.ProcessId }; exit 0 }",
  'foreach ($t in $targets) {',
  '  $g = Get-Process -Id ([int]$t.ProcessId)',
  "  if ($g -and [math]::Abs($g.StartTime.ToFileTimeUtc() - [int64]$t.Created) -lt 10000) { Stop-Process -Id ([int]$t.ProcessId) -Force; 'KILLED ' + $t.ProcessId }",
  '}',
].join('\n');
function ownTreeKillCommand(pid, { dry = false, table = null } = {}) {
  const tableJson = table ? JSON.stringify(table).replace(/'/g, "''") : '';
  const script = OWN_TREE_KILL_PS
    .replace('__ROOT__', String(Math.trunc(Number(pid)) || 0))
    .replace('__DRY__', dry ? '$true' : '$false')
    .replace('__TABLE__', () => tableJson);
  return ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')];
}
// 等它跑完(拿回 PLAN／KILLED 行):freeStalePort 要等旧实例真没了再重试监听;单测走 dry 模式。
function killOwnProcessTree(pid, opts = {}) {
  return new Promise(resolve => {
    if (!pid) return resolve({ lines: [] });
    if (process.platform !== 'win32') { try { process.kill(pid, 'SIGKILL'); } catch { /* already gone */ } return resolve({ lines: [] }); }
    cp.execFile('powershell.exe', ownTreeKillCommand(pid, opts), { windowsHide: true, timeout: 20000, maxBuffer: 1024 * 1024 }, (err, stdout) => {
      resolve({ lines: String(stdout || '').split(/\r?\n/).map(l => l.trim()).filter(Boolean), error: err ? String(err.message || err) : '' });
    });
  });
}
function killPosixChildTree(pid, ownedChild) {
  if (process.platform === 'darwin') {
    if (!(ownedChild instanceof cp.ChildProcess) || ownedChild.pid !== Number(pid)) {
      return { killed: [], scope: 'unknown', incomplete: true, skipped: 'process-handle-required' };
    }
    const helper = path.join(externalRoot(), 'runtime', 'macos', 'ruyi-process-helper');
    const result = cp.spawnSync(helper, ['--terminate-child-tree', String(pid)], {
      encoding: 'utf8', timeout: 5000, maxBuffer: 4 * 1024 * 1024,
    });
    const output = String(result.stdout || '');
    const killed = output.split(/\r?\n/).map(line => /^KILLED (\d+)$/.exec(line))
      .filter(Boolean).map(match => Number(match[1]));
    const counts = /^EXIT-COUNTS (\d+) (\d+) (\d+)$/m.exec(output);
    const exits = counts ? { terminated: Number(counts[1]), alreadyExited: Number(counts[2]), unconfirmed: Number(counts[3]) } : {};
    const observed = /^OBSERVED-TREE (\d+) (\d+)$/m.exec(output);
    const numbers = counts && observed ? [...counts.slice(1), ...observed.slice(1)].map(Number) : [];
    const validCounts = numbers.length === 5 && numbers.every(value => Number.isSafeInteger(value) && value >= 0 && value <= 32768)
      && numbers[3] >= 1 && exits.terminated + exits.alreadyExited + exits.unconfirmed === numbers[3]
      && numbers[4] === killed.length && new Set(killed).size === killed.length
      && exits.terminated <= numbers[4] && numbers[4] - exits.terminated <= exits.unconfirmed;
    const incomplete = !!result.error || result.status !== 0 || !output.startsWith('RUYI-PROCESS-V1\n') || !validCounts || exits.unconfirmed > 0;
    if (incomplete && ownedChild && ownedChild.exitCode === null && ownedChild.signalCode === null) {
      try { if (ownedChild.kill('SIGKILL') && !killed.includes(pid)) killed.push(pid); } catch { /* report incomplete */ }
      return { killed, ...(validCounts ? exits : {}), scope: 'direct-child', incomplete: true };
    }
    return { killed, ...(validCounts ? exits : {}), scope: 'observed-tree', incomplete };
  }
  // hunt2-engines#11:POSIX 修前只杀根 —— CLI 的 Bash 工具、MCP 子进程、ACP 终端拉起的孙辈全成孤儿,回合停了它们还在跑。
  // Linux 按 Windows 那一支同一条判据认子孙(dev-harness/lib/kill-own-tree.js 同款):从 /proc 快照里按父号往下找,
  // 只认启动时刻不早于父亲的(父号过期撞号的陌生进程比「父亲」还老,按构造排除);**先快照再杀根**(根一死子孙就被
  // 过继给 init,父号对不上了),杀每个子孙前再核一次启动时刻,号被复用就不杀。其他没有 /proc 的平台仍只杀根，macOS 由上方原生 helper 处理。
  const readStat = id => {
    try {
      const stat = fs.readFileSync(`/proc/${id}/stat`, 'utf8');
      const tail = stat.slice(stat.lastIndexOf(')') + 2).split(' ');   // tail[1]=ppid(第 4 列) tail[19]=starttime(第 22 列)
      return { pid: Number(id), ppid: Number(tail[1]), created: BigInt(tail[19]) };
    } catch { return null; }
  };
  const descendants = [];
  if (process.platform === 'linux') {
    let table = [];
    try { table = fs.readdirSync('/proc').filter(n => /^\d+$/.test(n)).map(readStat).filter(Boolean); } catch { table = []; }
    const rootRow = table.find(r => r.pid === Number(pid));
    const queue = rootRow ? [rootRow] : [];
    const seen = new Set(queue.map(r => r.pid));
    while (queue.length) {
      const parent = queue.shift();
      for (const r of table) {
        if (seen.has(r.pid) || r.ppid !== parent.pid || r.created < parent.created) continue;
        seen.add(r.pid);
        descendants.push(r);
        queue.push(r);
      }
    }
  }
  try { process.kill(pid, 'SIGKILL'); } catch { /* already gone */ }
  for (const d of descendants.reverse()) {
    const now = readStat(d.pid);
    if (!now || now.created !== d.created) continue;
    try { process.kill(d.pid, 'SIGKILL'); } catch { /* already gone */ }
  }
}
// 发出去就算(修前的调用形状,14 处调用点零改动):不等它。怎么「发出去」是 128i 取证定的:
//   · Node 的 detached(DETACHED_PROCESS,没有控制台)起 powershell.exe:退出码 0、**脚本一行都没跑**(实测 3/3);
//   · 直接 spawn(不 detached)能跑,但它在本进程的 libuv job 里 —— 服务收尸完马上退出时,job 一关它也被杀,
//     收尸做不完(修前 taskkill 约 80 ms、多半抢得赢;这段 PowerShell 要约 0.5 s);
//   · 经 `cmd /c start "" /b powershell …`:PowerShell 成了 cmd 的孩子,libuv 的 job 允许孙辈静默脱离 ⇒ 父进程先退也照样
//     跑完(实测父进程 150 ms 退出、脚本 1.5 s 后照写,2/2)。-EncodedCommand 的参数只含 [A-Za-z0-9+/=],cmd 里没有注入面。
// cmd 的命令行上限 8191 字符;超了(不会,这里留着防以后脚本变长)就退回直接 spawn。
function killChildTree(pid) {
  const ownedChild = pid instanceof cp.ChildProcess ? pid : null;
  const supervised = ownedChild && ProcessRuntime.stopChild(ownedChild);
  if (supervised) return supervised;
  if (ownedChild && (ownedChild.exitCode !== null || ownedChild.signalCode !== null)) {
    return { killed: [], scope: 'observed-tree', incomplete: true, skipped: 'root-exited' };
  }
  if (ownedChild) pid = ownedChild.pid;
  if (!pid) return;
  if (process.platform !== 'win32') return killPosixChildTree(pid, ownedChild);
  try {
    const args = ownTreeKillCommand(pid);
    const inner = `start "" /b powershell.exe ${args.join(' ')}`;
    const child = inner.length < 7800
      ? cp.spawn('cmd.exe', ['/d', '/s', '/c', `"${inner}"`], { windowsHide: true, stdio: 'ignore', windowsVerbatimArguments: true })
      : cp.spawn('powershell.exe', args, { windowsHide: true, stdio: 'ignore' });
    child.on('error', () => { try { process.kill(pid, 'SIGKILL'); } catch { /* already gone */ } });
    child.unref();
  } catch {
    try { process.kill(pid, 'SIGKILL'); } catch { /* already gone */ }
  }
}

ProcessRuntimeHooks.helperPath = () => path.join(externalRoot(), 'runtime', 'macos', 'ruyi-process-helper');
ProcessRuntimeHooks.stopUnsupervised = killChildTree;

// 47b/长工具保活:按工具声明式超时表(裸名小写)。未知工具默认 15min 有界上限;
// 已知工具仍按其自身参数上限收紧 ——
// ACC run_command timeout cap 600s / launch_application wait_timeout cap 600s,桥给 650s(含网络缓冲),
// 消灭"桥先 120s 死、ACC 侧 600s 任务变僵尸"的契约错位(03 方案 Phase A 核心项)。
// WCW_BRIDGED_TIMEOUT_OVERRIDE='name:ms,name:ms' 是测试缝(e2e 把秒级超时打进 fake 工具)。
const BRIDGED_TOOL_TIMEOUTS = {
  run_command: 650000,
  launch_application: 650000,
  macro_run: 300000,
  // ACC `wait` caps at 300s and time.sleep()s it; the old 120s bridge would kill a legitimate
  // wait(300) at 120s and tear down the whole ACC process tree for doing exactly what was asked.
  wait: 310000,
};
// Unknown third-party tools may legitimately render/export/index for several minutes without emitting MCP
// progress. Give them a bounded long-task ceiling; the provider stream now emits token-free liveness events,
// and Stop/steer can cancel the active request immediately, so this no longer creates an unresponsive wait.
const BRIDGED_TOOL_TIMEOUT_DEFAULT_MS = 900000;
function bridgedToolTimeoutMs(name) {
  const bare = String(name || '').toLowerCase();
  const ov = String(process.env.WCW_BRIDGED_TIMEOUT_OVERRIDE || '');
  for (const pair of ov.split(',')) {
    const [k, v] = pair.split(':').map(s => String(s || '').trim());
    if (k && k.toLowerCase() === bare && Number(v) > 0) return Number(v);
  }
  return BRIDGED_TOOL_TIMEOUTS[bare] || BRIDGED_TOOL_TIMEOUT_DEFAULT_MS;
}

// Match the bridge deadline to the concrete ACC run_command request instead of showing a default 60-second
// command as "running" for the old blanket 650-second ceiling. Keep a small protocol/serialization grace;
// explicit WCW_BRIDGED_TIMEOUT_OVERRIDE values remain the harder outer cap used by tests/operators.
function bridgedToolCallTimeoutMs(name, args) {
  const bare = String(name || '').toLowerCase();
  const configured = bridgedToolTimeoutMs(name);
  if (bare !== 'run_command') return configured;
  const requestedSeconds = Number(args && args.timeout);
  const commandSeconds = Number.isFinite(requestedSeconds)
    ? Math.max(1, Math.min(600, requestedSeconds))
    : 60;
  return Math.max(1000, Math.min(configured, commandSeconds * 1000 + 10000));
}

// 75b: automatic timeout/teardown decisions participate in the same per-Intervention CAS as user
// decisions. The fallback is only for storage/core failure and must re-check the registry entry so a
// concurrently applying user command can never be overwritten by a legacy settle.
function runAutomaticInterventionDecision(command, fallback) {
  Promise.resolve()
    .then(() => decideIntervention({ ...command, contractRequest: false, audit: false }))
    .then(result => { if (!result || result.status !== 200) fallback(); })
    .catch(() => fallback());
}

function clearPendingPermissions(sessionId, message) {
  for (const [rid, p] of pendingPermissions) {
    if (p.sessionId === sessionId) {
      if (p.commandApplying) continue; // 75b: command core owns resolve -> terminal -> registry cleanup ordering
      clearTimeout(p.timer);
      const note = String(message || 'session ended').slice(0, 500);
      runAutomaticInterventionDecision({
        missionId: sessionId, interventionId: rid, source: 'clear_permission', decidedBy: 'clear',
        idempotencyKey: `clear:${rid}`, payload: { action: 'deny', message: note },
      }, () => {
        if (pendingPermissions.get(rid) !== p || p.commandApplying) return;
        pendingPermissions.delete(rid);
        try { p.resolve({ behavior: 'deny', message: note }); } catch { /* already settled */ }
        settleIntervention(sessionId, rid, 'denied', { decidedBy: 'clear', note });
      });
    }
  }
}

function normalizeUserQuestions(raw) {
  const source = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.questions) ? raw.questions : [raw]);
  const uniqueId = (value, fallback, seen) => {
    const base = String(value || fallback).trim().slice(0, 80) || fallback;
    let candidate = base;
    for (let attempt = 2; seen.has(candidate); attempt++) {
      const suffix = `_${attempt}`;
      candidate = `${base.slice(0, 80 - suffix.length)}${suffix}`;
    }
    seen.add(candidate);
    return candidate;
  };
  const questionIds = new Set();
  return source.filter(q => q && typeof q === 'object').slice(0, 3).map((q, index) => {
    const questionId = uniqueId(q.id, `question_${index + 1}`, questionIds);
    const optionIds = new Set();
    const options = (Array.isArray(q.options) ? q.options : []).slice(0, 12).map((opt, optionIndex) => {
      const row = typeof opt === 'string' ? { label: opt } : (opt || {});
      const label = String(row.label || row.value || '').trim().slice(0, 200);
      if (!label) return null;
      const optionId = uniqueId(row.id, `option_${optionIndex + 1}`, optionIds);
      return {
        id: optionId,
        label,
        description: String(row.description || '').trim().slice(0, 500),
      };
    }).filter(Boolean);
    const requestedMode = String(q.answerMode || '').trim().toLowerCase();
    let answerMode = ['single', 'multiple', 'text'].includes(requestedMode)
      ? requestedMode
      : (options.length ? (q.multiSelect === true ? 'multiple' : 'single') : 'text');
    if (!options.length && answerMode !== 'text') answerMode = 'text';
    return {
      id: questionId,
      header: String(q.header || '').trim().slice(0, 80),
      question: String(q.question || q.header || `Question ${index + 1}`).trim().slice(0, 1000),
      answerMode,
      multiSelect: answerMode === 'multiple', // legacy clients keep their existing branch
      // Wave 85: finite choices are the primary path; typing stays available behind an explicit Other row.
      // Callers may set false only when a custom answer would be semantically invalid.
      allowOther: answerMode !== 'text' && q.allowOther !== false,
      otherLabel: String(q.otherLabel || '').trim().slice(0, 120),
      otherPlaceholder: String(q.otherPlaceholder || '').trim().slice(0, 300),
      options,
    };
  }).filter(q => q.question);
}

function normalizeQuestionAnswer(body, questions) {
  const source = (Array.isArray(body && body.answers) ? body.answers : []).slice(0, 3);
  const knownQuestions = Array.isArray(questions) ? questions : [];
  const answers = source.map((row, index) => {
    const input = row && typeof row === 'object' ? row : {};
    const questionId = String(input.questionId || '').slice(0, 80);
    const question = knownQuestions.find(q => q && questionId && q.id === questionId) || knownQuestions[index] || null;
    const options = Array.isArray(question && question.options) ? question.options : [];
    const optionById = new Map(options.map(opt => [String(opt.id || ''), opt]));
    const optionByLabel = new Map(options.map(opt => [String(opt.label || ''), opt]));
    const selected = [];
    const selectedSeen = new Set();
    const addSelected = value => {
      const key = String(value == null ? '' : value).trim();
      const opt = optionById.get(key) || optionByLabel.get(key);
      if (!opt || selectedSeen.has(opt.id)) return false;
      selectedSeen.add(opt.id); selected.push(opt); return true;
    };
    const selectedInput = Array.isArray(input.selectedOptionIds) ? input.selectedOptionIds : [];
    selectedInput.slice(0, 12).forEach(addSelected);
    const legacyValues = (Array.isArray(input.answer) ? input.answer : [input.answer])
      .filter(v => v != null && String(v).trim()).slice(0, 12).map(v => String(v).trim().slice(0, 2000));
    let otherText = String(input.otherText || '').trim().slice(0, 4000);
    for (const value of legacyValues) {
      if (addSelected(value)) continue;
      if (!otherText && (!question || question.answerMode === 'text' || question.allowOther === true)) otherText = value;
    }
    const acceptedOther = !!otherText && (!question || question.answerMode === 'text' || question.allowOther === true);
    const answer = selected.map(opt => opt.label);
    if (acceptedOther) answer.push(otherText);
    return {
      questionId: String((question && question.id) || questionId || `question_${index + 1}`).slice(0, 80),
      question: String((question && question.question) || input.question || '').slice(0, 1000),
      answer,
      selectedOptionIds: selected.map(opt => opt.id),
      otherText: acceptedOther ? otherText : '',
    };
  });
  const generatedContent = answers.map(a => `${a.question}: ${a.answer.join(', ')}`).join('\n');
  const fallbackContent = String((body && body.content) || '');
  const content = String(generatedContent || fallbackContent).slice(0, 12000);
  return { ok: !(body && body.isError), answers, content };
}

function formatQuestionGuidance(answer) {
  const text = String((answer && answer.content) || '').trim() || '(user supplied no answer)';
  return `<workbench_user_answer>\n${text}\n</workbench_user_answer>\nContinue the current task using this answer. Do not ask the same question again.`;
}

function normalizeQuestionContext(value) {
  const clean = String(value || '').replace(/\r\n/g, '\n').trim();
  if (clean.length <= 6000) return clean;
  return `…\n${clean.slice(-5998)}`;
}

function registerUserQuestion(sessionId, questionId, questions, onEvent, timeoutMs, deliver, context = '') {
  // Provider call ids are often reused as "call_1" across sessions, so never use them as registry keys.
  const sourceId = String(questionId || '');
  const id = makeId('question');
  const normalized = normalizeUserQuestions(questions);
  if (!normalized.length) return null;
  const questionContext = normalizeQuestionContext(context);
  const entry = { sessionId, questions: normalized, timer: null, deliver: null };
  entry.deliver = (answer, opts = {}) => {
    if (pendingQuestions.get(id) !== entry) return false;
    let accepted = false;
    try { accepted = deliver(answer) !== false; } catch { accepted = false; }
    if (!accepted) return false;
    clearTimeout(entry.timer);
    // 75b: decideIntervention owns the authoritative CAS row. It asks delivery to keep the registry entry
    // until terminal persistence and to skip the legacy side-ledger settle; timeout/teardown callers retain
    // the original self-contained behavior.
    if (opts.preserveRegistry !== true) pendingQuestions.delete(id);
    if (opts.skipInterventionSettle !== true) {
      settleIntervention(sessionId, id, answer && answer.ok !== false ? 'answered' : 'cancelled', { decidedBy: answer && answer.ok !== false ? 'user' : 'auto', note: answer && answer.content ? String(answer.content).slice(0, 500) : '' });
    }
    try {
      const summary = answer && answer.ok !== false
        ? String(answer.content || '').replace(/\s+/g, ' ').trim().slice(0, 500)
        : '';
      onEvent({ type: 'question_answer', questionId: id, ok: answer && answer.ok !== false, summary });
    } catch { /* a closed stream must not prevent the waiter from settling */ }
    return true;
  };
  entry.timer = null;
  // The timeout is re-armable: while the question modal stays open, UI heartbeats
  // (/api/question/heartbeat → extendUserQuestion) reset the deadline so composing a long
  // answer can never be cut off mid-way. The timer firing is the only backstop when the UI is gone.
  entry.armTimeout = () => {
    clearTimeout(entry.timer);
    entry.deadlineAt = Date.now() + entry.timeoutMs;
    entry.timer = setTimeout(() => {
      if (pendingQuestions.get(id) !== entry) return;
      const timeoutAnswer = { ok: false, answers: [], content: '(question timed out)' };
      runAutomaticInterventionDecision({
        missionId: sessionId, interventionId: id, source: 'timeout_question', decidedBy: 'timeout',
        idempotencyKey: `timeout:${id}`, payload: { action: 'answer', normalizedAnswer: timeoutAnswer },
      }, () => {
        if (pendingQuestions.get(id) === entry && !entry.commandApplying) entry.deliver(timeoutAnswer);
      });
    }, entry.timeoutMs);
  };
  entry.timeoutMs = promptWaitMs(timeoutMs);   // 0/缺省 = 不限时(见 promptWaitMs)
  entry.armTimeout();
  pendingQuestions.set(id, entry);
  onEvent({ type: 'ask_user', id, questionId: id, toolUseId: sourceId || undefined, questions: normalized, context: questionContext || undefined, deadlineAt: entry.deadlineAt, timeoutMs: entry.timeoutMs });
  registerIntervention(sessionId, 'question', id, {
    questionSummary: normalized.map(q => String(q.question || '').slice(0, 200)).join(' | '),
    questions: normalized,
    context: questionContext,
  });
  return id;
}

function requestUserQuestion(sessionId, questionId, questions, onEvent, timeoutMs, context = '') {
  return new Promise(resolve => {
    const id = registerUserQuestion(sessionId, questionId, questions, onEvent, timeoutMs, answer => { resolve(answer); return true; }, context);
    if (!id) resolve({ ok: false, answers: [], content: '', error: 'no valid questions' });
  });
}

// Heartbeat extension: the open question modal calls this periodically so a user composing a long
// answer never hits the deadline. Returns the fresh deadline/timeout for the UI countdown, or null
// when the question is gone (answered/timed out/cancelled) — the caller then stops its heartbeat.
function extendUserQuestion(sessionId, questionId) {
  const entry = pendingQuestions.get(String(questionId || ''));
  if (!entry || entry.sessionId !== sessionId || entry.commandApplying) return null;
  try { entry.armTimeout(); } catch { return null; }
  return { deadlineAt: entry.deadlineAt, timeoutMs: entry.timeoutMs };
}

function clearPendingQuestions(sessionId, message) {
  for (const [qid, q] of pendingQuestions) {
    if (q.sessionId !== sessionId) continue;
    if (q.commandApplying) continue; // 75b: do not race the authoritative command-core terminal commit
    clearTimeout(q.timer);
    const cancelled = { ok: false, answers: [], content: message || 'session ended' };
    runAutomaticInterventionDecision({
      missionId: sessionId, interventionId: qid, source: 'clear_question', decidedBy: 'clear',
      idempotencyKey: `clear:${qid}`, payload: { action: 'answer', normalizedAnswer: cancelled },
    }, () => {
      if (pendingQuestions.get(qid) !== q || q.commandApplying) return;
      try { q.deliver(cancelled); } catch { /* already settled */ }
      pendingQuestions.delete(qid);
    });
  }
}

// 47a(Steer Phase A 分流纪律):会话当前是否有等待回答的 AskUser 提问。Claude 引擎的提问答案与插话同走
// stdin user envelope —— 提问挂起期间注入插话,CLI 可能把插话误收为答案(串扰)。/api/steer 据此拒绝。
function hasPendingQuestionForSession(sessionId) {
  for (const [, q] of pendingQuestions) if (q.sessionId === sessionId) return true;
  return false;
}
// 128f-⑪:权限请求挂着时同样豁免回合的 idle 看门狗(三处:09 provider、05 Claude CLI、05b Kimi)。修前权限窗口 120 s
// 恒短于看门狗(默认 600 s),豁不豁免无所谓;定时线程的 30 分钟窗口早就被看门狗在 10 分钟处截断过(回合被当成「空闲」
// 杀掉,而不是按拒绝收尾让模型接着说),管家盯着的线程 600 s 窗口则与看门狗同长、谁先到算谁。权限自己的计时器到点
// 一定按拒绝落定,所以豁免不会让回合永远挂着。
function hasPendingPermissionForSession(sessionId) {
  const sid = String(sessionId || '');
  for (const [, p] of pendingPermissions) if (p && p.sessionId === sid) return true;
  return false;
}

// v0.9-S5: clear any pending PLAN approvals for a session (abort/stop/turn-end), resolving each as a REJECT
// so the paused runOpenAiTurn unblocks and finishes cleanly (never left hanging). Mirrors
// clearPendingPermissions — called from stopSession (abort/stop) and at turn end.
function clearPendingPlans(sessionId, message) {
  for (const [pid, p] of pendingPlans) {
    if (p.sessionId === sessionId) {
      if (p.commandApplying) continue; // 75b: command core clears after terminal persistence
      clearTimeout(p.timer);
      const note = message || 'session ended';
      runAutomaticInterventionDecision({
        missionId: sessionId, interventionId: pid, source: 'clear_plan', decidedBy: 'clear',
        idempotencyKey: `clear:${pid}`, payload: { action: 'reject', feedback: note },
      }, () => {
        if (pendingPlans.get(pid) !== p || p.commandApplying) return;
        pendingPlans.delete(pid);
        try { p.resolve({ decision: 'reject', note }); } catch { /* already settled */ }
      });
    }
  }
}

// ===================================================================================================
// v0.7d — zero-dependency MCP stdio client. Bridges an external stdio MCP server (e.g. the user's
// ai-computer-control desktop MCP) into the workbench so the NATIVE provider tool loop can call it.
// Protocol: JSON-RPC 2.0 over newline-delimited stdout (MCP 2024-11-05). All errors are internalized;
// a crashing/hung child can never take down the web server.
// ===================================================================================================

// ── hunt2-mcp:stdio / 远程两个客户端共用的小件(修前各抄一份,行为已经分叉过)──
// 单行上限:MCP 一条响应就是一行 JSON,读大文件/截图类工具一行几 MB 是常态。修前 4MB 处直接「截掉前半行」,
// 结果那一行永远拼不回完整 JSON、调用干等到超时再被杀进程。现在上限放宽,真超了就丢弃到下一个换行并
// 如实拒掉那一次调用(按行首的 id 找得到时),绝不在行中间切。
const MCP_STDIO_LINE_MAX_CHARS = 64 * 1024 * 1024;
// tools/list 分页(nextCursor)最多跟这么多页 —— 防对端回同一个游标/无限翻页把握手拖死。
const MCP_TOOLS_LIST_MAX_PAGES = 20;
// 条目上的 startupTimeoutMs(从 Codex startup_timeout_sec / Claude 配置导入)只在握手各 rpc 已有的超时参数上生效。
function mcpStartupRpcMs(client, fallback) {
  const v = Number(client && client.startupTimeoutMs);
  return Number.isInteger(v) && v > 0 ? v : fallback;
}
// 条目上的 enabledTools(非空 = 白名单)/ disabledTools(黑名单)。修前导入并落盘了却没人读,原生桥照样把
// 用户关掉的工具全部交给模型。空白名单视为「未设置」—— 清洗后变空的数组不该把整台服务器的工具静默藏光。
function mcpToolAllowed(entry, name) {
  const n = String(name || '');
  const allow = entry && Array.isArray(entry.enabledTools) ? entry.enabledTools : null;
  if (allow && allow.length && !allow.includes(n)) return false;
  const deny = entry && Array.isArray(entry.disabledTools) ? entry.disabledTools : null;
  if (deny && deny.includes(n)) return false;
  return true;
}
// tools/call 结果归一(两个客户端同一份)。修前:文本是 JSON 数组时被展开成 {"0":…,"1":…};
// 工具自带的 ok:true 会盖掉协议层 isError:true(失败被报成成功)。现在数组放进 items,ok 取两者的「与」。
function normalizeMcpToolResult(res) {
  const isError = !!(res && res.isError);
  const blocks = (res && Array.isArray(res.content)) ? res.content : [];
  // 审计 N6:MCP 标准 content 是多块(text / image / resource / audio…)。修前只取第一个 text 块,其余静默丢弃;
  // 只有图片时把整个 content 数组(含 9 万字符 base64)原样回给模型,再被 60 KB 截断劈成半截 base64 文字。
  // 现在:全部 text 块拼起来(单块时与修前逐字一致);image 块映射成工具图像通道认识的字段
  // (第一张 image_base64 + image_mime,多张的其余放 images:[{mimeType,data}]),base64 永不进 text;
  // 内嵌文本资源当文本收;其余块类型只留一条 {type, note:'omitted'}。
  const texts = [];
  const images = [];
  const omitted = [];
  for (const c of blocks) {
    if (!c || typeof c !== 'object') continue;
    if (c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
    else if (c.type === 'image' && typeof c.data === 'string' && c.data) images.push({ mimeType: String(c.mimeType || c.mime_type || 'image/png'), data: c.data });
    else if (c.type === 'resource' && c.resource && typeof c.resource.text === 'string') texts.push(c.resource.text);
    else {
      const o = { type: String(c.type || 'unknown'), note: 'omitted' };
      for (const k of ['uri', 'name', 'mimeType']) if (typeof c[k] === 'string') o[k] = c[k].slice(0, 300);   // resource_link 等:留下可辨认的指针,不留载荷
      omitted.push(o);
    }
  }
  // 多个 text 块时先看【第一块】是不是 JSON(结构化结果 {ok:false,error,…} 后面常跟一条 warning 之类的附注块):是 → 以它为载荷,
  // 其余块放 extraText;否则才把各块拼起来。修前(拼接后再解析)会让「第一块是失败 JSON + 第二块附注」整体变成 ok:true 的文本。
  let textOut = texts.length > 1 ? texts.join('\n') : (texts[0] || '');
  let extraText = '';
  if (texts.length > 1) {
    const head = safeJsonParse(texts[0], undefined);
    if (head && typeof head === 'object') { textOut = texts[0]; extraText = texts.slice(1).join('\n'); }
  }
  const withExtras = base => {
    if (images.length) {
      if (base.image_base64 === undefined && base.image === undefined) {
        base.image_base64 = images[0].data;
        if (base.image_mime === undefined) base.image_mime = images[0].mimeType;
        if (images.length > 1 && base.images === undefined) base.images = images.slice(1);
      } else if (base.images === undefined) {
        base.images = images;
      }
    }
    if (omitted.length && base.omittedBlocks === undefined) base.omittedBlocks = omitted;
    if (extraText && base.extraText === undefined) base.extraText = extraText;
    return base;
  };
  if (textOut) {
    // Prefer the text content; parse it as JSON when it is JSON (desktop MCP returns {ok,...}).
    const parsed = safeJsonParse(textOut, undefined);
    if (Array.isArray(parsed)) return withExtras({ ok: !isError, items: parsed });
    if (parsed && typeof parsed === 'object') {
      const { ok: toolOk, ...rest } = parsed;
      return withExtras({ ok: !isError && toolOk !== false, ...rest });
    }
    return withExtras({ ok: !isError, text: textOut });
  }
  if (images.length || omitted.length) return withExtras({ ok: !isError });
  return { ok: !isError, content: (res && res.content) || [] };
}
// 跟 nextCursor 翻完 tools/list(MCP 2025-03-26 起工具目录可分页;修前只取第一页,后面的工具凭空消失)。
async function mcpListAllTools(rpc, timeoutMs) {
  const tools = [];
  let cursor = '';
  for (let page = 0; page < MCP_TOOLS_LIST_MAX_PAGES; page++) {
    const listed = await rpc('tools/list', cursor ? { cursor } : {}, timeoutMs);
    if (listed && Array.isArray(listed.tools)) tools.push(...listed.tools);
    const next = (listed && typeof listed.nextCursor === 'string') ? listed.nextCursor : '';
    if (!next || next === cursor) break;
    cursor = next;
  }
  return tools;
}
// 对端发来的【请求】(同时带 id 与 method,如 ping)。修前被当成响应:用它的 id 去结我们自己同号的 pending,
// 于是一次真正的 tools/call 被 undefined「成功」提前结掉。现在按 JSON-RPC 回话:ping 回 {},其余 -32601。
function mcpServerRequestReply(msg) {
  if (msg.method === 'ping') return { jsonrpc: '2.0', id: msg.id, result: {} };
  return { jsonrpc: '2.0', id: msg.id, error: { code: -32601, message: 'method not supported by client: ' + String(msg.method).slice(0, 80) } };
}

// 安全修复(审计 A①):桥接 MCP 服务器(ACC 桌面控制、第三方 stdio MCP)不得继承工作台自己的回环凭据。
// 每会话 MCP 子进程(`server.js mcp`)的环境里有 WCW_TOKEN / WCW_PORT / WCW_HOST / WCW_SESSION_ID(01 generateSessionMcpConfig
// 塞进去的),修前它再 spawn 桥接服务器时整份 process.env 原样传下去 —— ACC 的 get_environment_variable 一问就把
// 令牌交给了模型(令牌 = 可调 /api/permission/decision 等 body-token 路由,自己批自己的权限)。
// 规则见 01 bridgedEnvKeyStripped(与交给 agent CLI 去 spawn 的 --mcp-config 条目同一个判据):继承来的环境里去掉
// 所有 WCW_*(WCW_DATA_DIR 除外)与 ANTHROPIC_AUTH_TOKEN / ANTHROPIC_API_KEY。服务器条目【自己声明】的 env(ownEnv)
// 原样叠在最后,仍然生效。
function bridgedServerSpawnEnv(baseEnv, ownEnv) {
  const out = {};
  for (const [k, v] of Object.entries(baseEnv || {})) {
    if (bridgedEnvKeyStripped(k)) continue;
    out[k] = v;
  }
  return { ...out, ...(ownEnv && typeof ownEnv === 'object' ? ownEnv : {}) };
}

// 走查 W1·F7:桥接超时 / 用户插话中断的 reject 打【标记】(err.mcpTimeout / err.mcpAborted),callTool 只认标记。
// 修前 callTool 用 /timed out/ 匹配 e.message —— MCP 服务端自己回的 JSON-RPC error(「upstream API timed out」「query timed out」)
// 文本里只要带这几个字,就被当成桥接超时:工作台杀掉一个健康的 MCP 进程树、报「桥接进程树已终止」,而服务端的原话被吞掉。
// 现在服务端的错误(没有标记)原样回给模型。
function mcpBridgeError(message, kind) {
  const e = new Error(message);
  if (kind === 'timeout') e.mcpTimeout = true;
  else if (kind === 'abort') e.mcpAborted = true;
  return e;
}

// MCP transport metadata belongs to the host call context, outside model arguments.
// Clone a small JSON object so an awaited send cannot observe later metadata mutation.
function mcpCallToolParams(name, args, options) {
  const params = { name, arguments: args || {} };
  if (options && Object.prototype.hasOwnProperty.call(options, 'meta')) {
    const meta = options.meta;
    if (!meta || typeof meta !== 'object' || Array.isArray(meta)) throw new Error('mcp metadata must be an object');
    const encoded = options.executionCheck ? JSON.stringify(copyOrdinaryJsonData(meta)) : JSON.stringify(meta);
    if (Buffer.byteLength(encoded, 'utf8') > 4096) throw new Error('mcp metadata exceeds 4096 bytes');
    const copied = JSON.parse(encoded);
    if (!copied || typeof copied !== 'object' || Array.isArray(copied)) throw new Error('mcp metadata must serialize to an object');
    params._meta = copied;
  }
  return params;
}

// A real, safe tools/call roundtrip must preserve both reserved metadata and SDK numeric types.
// The schema-shape flag alone is insufficient. Never cache this across an MCP child replacement.
async function probeDesktopExecutionReceipts(client, options = {}) {
  const nonce = crypto.randomBytes(16).toString('hex');
  const probeValues = { integer: 1000000000000000100, exponent: 1e21, decimal: 0.0000001,
    subnormal: Number.MIN_VALUE, zero: 0, unicode: '你好🚀' };
  const expected = executionArgumentsDigest(probeValues);
  const result = await client.callTool('execution_receipt', { invocation_id: '0'.repeat(32), probe_values: probeValues },
    8000, { ...options, meta: { 'org.ruyi.workbench/execution-probe-v1': { schema: 1, nonce } } });
  const probe = result?.metadata_probe;
  if (result?.ok !== true || result.execution_receipt_version !== 1 || result.semantic_validation?.semantic_version !== 1 || !probe || probe.schema !== 1 || probe.nonce !== nonce
      || probe.context_required !== true || probe.args_semantic_codec !== 'ruyi-sdk-json-v1' || probe.received_semantic_sha256 !== expected
      || !/^[a-f0-9]{32}$/.test(probe.acc_worker_id || '') || !Number.isSafeInteger(probe.acc_pid) || probe.acc_pid <= 0) {
    return { ok: false, code: 'execution_receipts_unavailable', outcome: 'not_dispatched', action_sent: false };
  }
  return { ok: true, receiptVersion: 1, argumentsCodec: probe.args_semantic_codec,
    accWorkerId: probe.acc_worker_id, accPid: probe.acc_pid, contextRequired: true };
}

class McpStdioClient {
  constructor({ id, command, args, cwd, env, startupTimeoutMs, toolTimeoutMs, enabledTools, disabledTools }) {
    this.id = id;
    this.command = command;
    this.args = Array.isArray(args) ? args : [];
    this.cwd = cwd || undefined;
    this.env = env || {};
    this.startupTimeoutMs = startupTimeoutMs;
    this.toolTimeoutMs = toolTimeoutMs;
    this.enabledTools = enabledTools;
    this.disabledTools = disabledTools;
    this.child = null;
    this.pid = null;
    this.dead = false;
    this.started = false;
    this.tools = [];
    this._bufParts = [];         // 未满一行的 stdout 片段(按块累积,不反复拼接整串)
    this._bufLen = 0;
    this._discarding = false;    // 超长行:丢弃到下一个换行
    this._lineMax = MCP_STDIO_LINE_MAX_CHARS;
    this._nextId = 1;
    this._pending = new Map();   // rpc id -> { resolve, timer }
    this._stderr = '';
  }

  // Send one JSON-RPC request and await its result (by id). Rejects on timeout/child death.
  _rpc(method, params, timeoutMs = 8000, options = {}) {
    return new Promise((resolve, reject) => {
      if (this.dead || !this.child || !this.child.stdin || !this.child.stdin.writable) {
        return reject(new Error('mcp client not running'));
      }
      const id = this._nextId++;
      const signal = options && options.signal;
      let abortHandler = null;
      const cleanup = () => {
        clearTimeout(timer);
        if (signal && abortHandler) signal.removeEventListener('abort', abortHandler);
      };
      const timer = setTimeout(() => {
        this._pending.delete(id);
        // 47b 桥 cancel 契约:tools/call 超时先按 MCP 标准发 notifications/cancelled(对端若实现协作式取消
        // 可收手);真正的兜底是 callTool catch 里的 kill 进程树(ACC 侧不响应取消也不留僵尸执行)。
        if (method === 'tools/call') { try { this._notify('notifications/cancelled', { requestId: id, reason: 'timeout' }); } catch { /* best-effort */ } }
        cleanup();
        reject(mcpBridgeError(`mcp ${method} timed out`, 'timeout'));
      }, Math.max(1000, timeoutMs));
      abortHandler = () => {
        if (!this._pending.has(id)) return;
        this._pending.delete(id);
        if (method === 'tools/call') { try { this._notify('notifications/cancelled', { requestId: id, reason: 'user_steer' }); } catch { /* best-effort */ } }
        cleanup();
        reject(mcpBridgeError(`mcp ${method} aborted by user steer`, 'abort'));
      };
      this._pending.set(id, { resolve, reject, timer, cleanup });
      if (signal) {
        signal.addEventListener('abort', abortHandler, { once: true });
        if (signal.aborted) { abortHandler(); return; }
      }
      try {
        const packet = { jsonrpc: '2.0', id, method, params: params || {} };
        const safePacket = options.executionCheck ? copyOrdinaryJsonData(packet) : packet;
        const encoded = JSON.stringify(safePacket);
        if (options.executionCheck) options.executionCheck(safePacket);
        this.child.stdin.write(encoded + '\n', 'utf8');
      } catch (e) {
        cleanup(); this._pending.delete(id); reject(e);
      }
    });
  }
  // Fire-and-forget notification (no id, no response expected).
  _notify(method, params) {
    if (this.dead || !this.child || !this.child.stdin || !this.child.stdin.writable) return;
    try { this.child.stdin.write(JSON.stringify({ jsonrpc: '2.0', method, params: params || {} }) + '\n', 'utf8'); } catch { /* ignore */ }
  }
  _onLine(line) {
    line = line.trim();
    if (!line) return;
    const msg = safeJsonParse(line);
    if (!msg || msg.id == null) return;          // notifications/logs from the server: ignore
    if (msg.method != null) {                     // 对端发起的请求(ping 等),不是给我们的响应
      if (this.dead || !this.child || !this.child.stdin || !this.child.stdin.writable) return;
      try { this.child.stdin.write(JSON.stringify(mcpServerRequestReply(msg)) + '\n', 'utf8'); } catch { /* ignore */ }
      return;
    }
    const p = this._pending.get(msg.id);
    if (!p) return;
    if (p.cleanup) p.cleanup(); else clearTimeout(p.timer);
    this._pending.delete(msg.id);
    if (msg.error) p.reject(new Error(msg.error.message || 'mcp error'));
    else p.resolve(msg.result);
  }
  _failAllPending(err) {
    for (const [, p] of this._pending) { if (p.cleanup) p.cleanup(); else clearTimeout(p.timer); try { p.reject(err); } catch { /* settled */ } }
    this._pending.clear();
  }
  // 按行切 stdout。只在【新到的块】里找换行(修前每块都从整串头上重找,几十 MB 的一行是平方级);
  // 超过 _lineMax 的行整行丢弃到下一个换行,并按行首的 "id" 把那一次调用如实拒掉,不在行中间切。
  _onStdoutChunk(chunk) {
    let start = 0;
    let nl;
    while ((nl = chunk.indexOf('\n', start)) >= 0) {
      const piece = chunk.slice(start, nl);
      start = nl + 1;
      if (this._discarding) { this._discarding = false; continue; }
      const line = this._bufParts.length ? this._bufParts.join('') + piece : piece;
      this._bufParts = []; this._bufLen = 0;
      try { this._onLine(line); } catch { /* never let a bad line throw */ }
    }
    const rest = start ? chunk.slice(start) : chunk;
    if (!rest || this._discarding) return;
    this._bufParts.push(rest);
    this._bufLen += rest.length;
    if (this._bufLen > this._lineMax) {
      let head = '';
      for (const part of this._bufParts) { head += part.slice(0, 256 - head.length); if (head.length >= 256) break; }
      this._bufParts = []; this._bufLen = 0;
      this._discarding = true;
      const m = /^\s*\{[^{]*?"id"\s*:\s*(\d+)/.exec(head);   // 只认顶层 id(它前面不能再有别的 {)
      const p = m ? this._pending.get(Number(m[1])) : null;
      if (p) {
        this._pending.delete(Number(m[1]));
        if (p.cleanup) p.cleanup(); else clearTimeout(p.timer);
        p.reject(new Error(`mcp response too large (> ${Math.round(this._lineMax / 1048576)}MB single line)`));
      }
    }
  }

  // Spawn + handshake (initialize -> notifications/initialized -> tools/list). Throws on failure and
  // leaves the client marked dead (caller caches the failure so it won't respawn in a tight loop).
  async start() {
    if (this.started) return;
    this.started = true;
    const s = batchSafeSpawn(this.command, this.args);   // transparently wrap .cmd/.bat
    const spawnEnv = DesktopExecutionHooks.clientEnvironment(this.id, bridgedServerSpawnEnv(process.env, this.env), this);
    this.executionContextRequired = spawnEnv.RUYI_EXECUTION_CONTEXT_REQUIRED === '1';
    let child;
    try {
      child = ProcessRuntime.spawn(s.command, s.args, {
        cwd: this.cwd,
        env: spawnEnv,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe'],
        ...s.opts,
      }, { kind: 'mcp', serverId: this.id });
    } catch (e) {
      this.dead = true;
      throw new Error(`spawn failed: ${e && e.message ? e.message : e}`);
    }
    this.child = child;
    this.pid = child.pid;
    // Don't let the live MCP child keep the event loop from exiting on a clean shutdown; we reap it
    // explicitly via killAllMcpClients()/killChildTree on exit.
    try { child.unref(); } catch { /* ignore */ }
    child.on('error', e => { this.dead = true; this._failAllPending(new Error('mcp child error: ' + (e && e.message))); });
    child.on('exit', (code, signal) => {
      this.dead = true;
      // 审计 A14:带上退出码/信号与 stderr 末尾,callTool 据此给模型可行动的说明(修前只有裸的「mcp child exited」)。
      const err = new Error(`mcp child exited (code ${code == null ? 'null' : code}${signal ? `, signal ${signal}` : ''})`);
      err.mcpChildExit = { code: code == null ? null : code, signal: signal || null, stderrTail: String(this._stderrTail || '').slice(-400).trim() };
      this._failAllPending(err);
    });
    // EPIPE on stdin must not crash the process.
    if (child.stdin) child.stdin.on('error', () => { /* ignore broken pipe */ });
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => this._onStdoutChunk(chunk));
    child.stderr.setEncoding('utf8');
    child.stderr.on('data', d => { if (this._stderr.length < 8000) this._stderr += d; this._stderrTail = (String(this._stderrTail || '') + d).slice(-800); });

    try {
      const init = await this._rpc('initialize', {
        protocolVersion: '2024-11-05',
        capabilities: {},
        clientInfo: { name: RUYI_MCP_SERVER_ID, version: VERSION }, // MCP 客户端标识名与 server id 一致
      }, mcpStartupRpcMs(this, 8000));
      this.serverInfo = (init && init.serverInfo) || {};
      this._notify('notifications/initialized', {});
      this.tools = await this._listAllTools(mcpStartupRpcMs(this, 8000));
    } catch (e) {
      this.kill();
      this.dead = true;
      throw new Error(`handshake failed: ${e && e.message ? e.message : e}${this._stderr ? ' | stderr: ' + this._stderr.slice(0, 300) : ''}`);
    }
    return this;
  }

  listTools() { return this.tools; }
  _listAllTools(timeoutMs) { return mcpListAllTools((m, p, t) => this._rpc(m, p, t), timeoutMs); }
  // 探针用:真发一次 tools/list(修前 probe 读的是握手时缓存的目录,卡死的服务器照样报「正常」)。
  async refreshTools(timeoutMs) { this.tools = await this._listAllTools(timeoutMs); return this.tools; }

  // Call a tool and normalize the MCP result into a workbench result object. Never throws.
  // 47b:超时走契约化处理 —— notifications/cancelled(_rpc 内已发)+ kill 客户端进程树(无僵尸执行),
  // 下次调用由 mcpClients 惰性重 spawn。错误文本如实告知"已杀进程树"。
  async callTool(name, args, timeoutMs, options = {}) {
    // 条目 disabledTools/enabledTools 在调用时再挡一道(目录里已经滤掉;这里防裸名容错路由或旧目录缓存绕过)。
    if (!mcpToolAllowed(this, name)) return { ok: false, error: `tool '${name}' is disabled for MCP server '${this.id}' (enabledTools/disabledTools)` };
    // 超时:调用方显式给的优先,其次条目的 toolTimeoutMs,最后按工具名的内置表。
    const limit = Math.max(1000, Number(timeoutMs) || Number(this.toolTimeoutMs) || bridgedToolCallTimeoutMs(name, args));
    try {
      const res = await this._rpc('tools/call', mcpCallToolParams(name, args, options), limit, options);
      return normalizeMcpToolResult(res);
    } catch (e) {
      const m = (e && e.message) ? e.message : String(e);
      if (e && e.mcpChildExit) return mcpChildExitResult(this, name, e.mcpChildExit);   // 审计 A14
      if (e && (e.mcpTimeout || e.mcpAborted)) {
        // _rpc already sent the cooperative cancellation notification. Report the verified
        // cleanup scope from the actual child handle, including dependency/identity failures.
        let cleanup;
        const stoppedChild = this.child;
        try {
          cleanup = this.kill();
          if (cleanup && cleanup.scope === 'owned-group-and-observed') {
            const confirmed = await ProcessRuntime.waitForCleanup(stoppedChild);
            if (confirmed) cleanup = confirmed;
          }
        } catch { cleanup = { scope: 'unknown', incomplete: true }; }
        const description = cleanup ? (cleanup.incomplete ? '桥接子进程清理未确认完成' : '已核验的桥接子进程已终止') : '桥接进程树已终止';
        const fields = cleanup ? { cleanupScope: cleanup.scope, cleanupIncomplete: cleanup.incomplete === true,
          ...(cleanup.escapeCoverage ? { cleanupEscapeCoverage: cleanup.escapeCoverage, cleanupUnconfirmed: cleanup.unconfirmed } : {}) } : {};
        if (e.mcpTimeout) return { ok: false, ...fields,
          error: `tool timed out after ${Math.round(limit / 1000)}s; ${description}${cleanup ? '' : '(防僵尸执行)'},下次调用将自动重连` };
        return { ok: false, ...fields, error: `工具已因用户插话中断；${description}，模型将立即处理新指令`, steerInterrupted: true };
      }
      return { ok: false, error: m };
    }
  }

  kill() {
    this.dead = true;
    this._failAllPending(new Error('mcp client killed'));
    if (this.child) this.lastCleanup = killChildTree(this.child);
    try { if (this.child && this.child.stdin) this.child.stdin.end(); } catch { /* ignore */ }
    this.child = null;
    return this.lastCleanup;
  }
}

// ===================================================================================================
// 49c — zero-dependency remote MCP client (03 §4.2). Two transports:
//   * 'http'  — streamable HTTP (2025-03-26): POST JSON-RPC to one endpoint; the response is either
//               application/json or text/event-stream (we parse both). Mcp-Session-Id is captured at
//               initialize and echoed on every later request.
//   * 'sse'   — legacy SSE transport (2024-11-05): GET opens an event stream whose first `endpoint`
//               event yields the POST uri; responses arrive back on the stream as `message` events.
// headers 值里的 ${VAR}/%VAR% 在【连接时】从 process.env 展开(配置里只存引用,密钥不落盘明文)。
// tools/list_changed:sse 流上收到该通知即惰性重列工具(下次 listTools 前刷新)。
// ===================================================================================================
class McpHttpClient {
  constructor({ id, transport, url, headers, bearerTokenEnvVar, startupTimeoutMs, toolTimeoutMs, enabledTools, disabledTools }) {
    this.id = id;
    this.transport = transport === 'sse' ? 'sse' : 'http';
    this.url = String(url || '');
    // 连接时展开密钥引用;未定义的变量保留原样(与 48c 导入器同语义)。
    this.headers = {};
    for (const [k, v] of Object.entries(headers || {})) this.headers[k] = _expandMcpVar(String(v));
    // bearerTokenEnvVar(Codex bearer_token_env_var / 导入的同名字段):连接时从 process.env 取令牌补
    // Authorization。修前存了不用,需要鉴权的远程连接器永远 401。显式写了 Authorization 头的以头为准。
    const tokenVar = typeof bearerTokenEnvVar === 'string' ? bearerTokenEnvVar.trim() : '';
    const token = tokenVar ? String(process.env[tokenVar] || '').trim() : '';
    if (token && !Object.keys(this.headers).some(k => k.toLowerCase() === 'authorization')) this.headers.Authorization = 'Bearer ' + token;
    this.startupTimeoutMs = startupTimeoutMs;
    this.toolTimeoutMs = toolTimeoutMs;
    this.enabledTools = enabledTools;
    this.disabledTools = disabledTools;
    this.dead = false;
    this.started = false;
    this.tools = [];
    this._nextId = 1;
    this._pending = new Map();     // rpc id -> { resolve, reject, timer }
    this._sessionId = null;
    this._sseReq = null;           // legacy-sse GET stream (http.ClientRequest)
    this._ssePostUrl = null;       // legacy-sse endpoint uri
    this._sseBuf = '';
    this._toolsStale = false;      // tools/list_changed 通知标记
  }

  _failAllPending(err) {
    for (const [, p] of this._pending) { if (p.cleanup) p.cleanup(); else clearTimeout(p.timer); try { p.reject(err); } catch { /* settled */ } }
    this._pending.clear();
  }

  _baseHeaders(extra) {
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json, text/event-stream',
      ...(this._sessionId ? { 'Mcp-Session-Id': this._sessionId } : {}),
      ...this.headers,
      ...(extra || {}),
    };
  }

  // One HTTP request. Returns { status, headers, body } (body = Buffer, capped at 8MB). Never throws.
  _request(method, urlStr, payload, timeoutMs, extraHeaders, options = {}) {
    return new Promise(resolve => {
      let u; try { u = new URL(urlStr); } catch { return resolve({ error: 'bad url: ' + urlStr }); }
      const lib = u.protocol === 'https:' ? require('https') : http;
      const bodyBuf = payload ? Buffer.from(JSON.stringify(payload), 'utf8') : null;
      const signal = options && options.signal;
      let settled = false;
      let abortHandler = null;
      let why = '';   // 'timeout' / 'abort':这次失败是我们自己的超时 / 用户中断(不是对端的错误),随 error 一起交出去
      const finish = value => {
        if (settled) return;
        settled = true;
        if (signal && abortHandler) signal.removeEventListener('abort', abortHandler);
        resolve(why && value && value.error ? { ...value, why } : value);
      };
      const req = lib.request(u, {
        method,
        headers: { ...this._baseHeaders(extraHeaders), ...(bodyBuf ? { 'Content-Length': bodyBuf.length } : {}) },
        timeout: Math.max(1000, timeoutMs || 10000),
      }, res => {
        const chunks = [];
        let size = 0;
        res.on('data', c => {
          size += c.length;
          if (size <= 8 * 1024 * 1024) chunks.push(c); // cap runaway bodies
        });
        res.on('end', () => finish({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
        res.on('error', e => finish({ error: (e && e.message) || String(e) }));
      });
      req.on('timeout', () => { why = 'timeout'; req.destroy(new Error('request timed out')); });
      req.on('error', e => finish({ error: (e && e.message) || String(e) }));
      abortHandler = () => { why = 'abort'; req.destroy(new Error('request aborted by user steer')); };
      if (signal) {
        signal.addEventListener('abort', abortHandler, { once: true });
        if (signal.aborted) abortHandler();
      }
      if (bodyBuf) req.write(bodyBuf);
      req.end();
    });
  }

  // Parse a text/event-stream body, returning the JSON-RPC messages it carries (data: lines, possibly
  // multi-line per event — the e5-multiline-sse lesson: join data lines with \n before JSON.parse).
  static _parseSseMessages(text) {
    const out = [];
    let dataLines = [];
    const flush = () => {
      if (!dataLines.length) return;
      const raw = dataLines.join('\n');
      dataLines = [];
      const msg = safeJsonParse(raw, null);
      if (msg && typeof msg === 'object') out.push(msg);
    };
    for (const line of String(text).split(/\r?\n/)) {
      if (line === '') { flush(); continue; }
      if (line.startsWith(':')) continue;                 // comment/heartbeat
      const m = line.match(/^data:\s?(.*)$/);
      if (m) dataLines.push(m[1]);
    }
    flush();
    return out;
  }

  // streamable-HTTP round trip: POST one JSON-RPC message, resolve with the matching-id result.
  async _rpcHttp(method, params, timeoutMs, options = {}) {
    if (this.dead) throw new Error('mcp client not running');
    const id = this._nextId++;
    const resp = await this._request('POST', this.url, { jsonrpc: '2.0', id, method, params: params || {} }, timeoutMs, null, options);
    if (resp.error) {
      // 49c 对抗验证修(第50波):_rpcHttp 超时也发 notifications/cancelled(与 _rpcSse/stdio _rpc 一致--
      //   对端若实现协作式取消可收手,不留无主处理)。连接可能已断,_notify 静默失败 best-effort。
      if (method === 'tools/call' && resp.why) { try { this._notify('notifications/cancelled', { requestId: id, reason: resp.why === 'abort' ? 'user_steer' : 'timeout' }); } catch { /* best-effort */ } }
      throw mcpBridgeError('mcp http: ' + resp.error, resp.why);
    }
    const sid = resp.headers && (resp.headers['mcp-session-id'] || resp.headers['Mcp-Session-Id']);
    if (sid && !this._sessionId) this._sessionId = String(sid);
    const ctype = String((resp.headers && resp.headers['content-type']) || '');
    let msgs = [];
    if (ctype.includes('text/event-stream')) msgs = McpHttpClient._parseSseMessages(resp.body.toString('utf8'));
    else { const j = safeJsonParse(resp.body.toString('utf8'), null); if (j) msgs = [j]; }
    // 带 method 的是对端发来的请求(同 id 撞号也不是给我们的响应)。
    const mine = msgs.find(m => m && m.id === id && m.method == null);
    if (!mine && this._sessionId && (resp.status === 404 || resp.status === 400 || resp.status === 401) && method !== 'initialize') {
      // 服务端会话失效(对端重启 / 会话过期:规范要求回 404,客户端须不带旧 Mcp-Session-Id 重新 initialize)。
      // 修前客户端既不重握手也不标 dead,之后每一次调用都 404,直到进程重启。现在就地重握手后重发一次
      // (对端没认这个会话,原请求不会被执行过);重握手或重发仍失败 -> 标 dead,下次 getMcpClient 整个重建。
      if (!options._sessionRetried) {
        this._sessionId = null;
        try { await this._initialize(timeoutMs); }
        catch (e) { this.kill(); throw new Error('mcp http: 会话已失效(HTTP ' + resp.status + '),重新握手失败: ' + ((e && e.message) || e)); }
        return this._rpcHttp(method, params, timeoutMs, { ...options, _sessionRetried: true });
      }
      this.kill();
      throw new Error('mcp http: 会话已失效(HTTP ' + resp.status + '),连接已重置,下次调用将重新握手');
    }
    if (!mine) throw new Error('mcp http: 响应中无匹配 id(状态 ' + resp.status + ')');
    if (mine.error) throw new Error(mine.error.message || 'mcp error');
    return mine.result;
  }

  // legacy-SSE round trip: POST to the endpoint uri (202 ack), the result arrives on the GET stream.
  _rpcSse(method, params, timeoutMs, options = {}) {
    return new Promise((resolve, reject) => {
      if (this.dead || !this._ssePostUrl) return reject(new Error('mcp sse: 事件流未就绪'));
      const id = this._nextId++;
      const signal = options && options.signal;
      let abortHandler = null;
      const cleanup = () => {
        clearTimeout(timer);
        if (signal && abortHandler) signal.removeEventListener('abort', abortHandler);
      };
      const timer = setTimeout(() => {
        this._pending.delete(id);
        if (method === 'tools/call') { try { this._notify('notifications/cancelled', { requestId: id, reason: 'timeout' }); } catch { /* best-effort */ } }
        cleanup();
        reject(mcpBridgeError(`mcp ${method} timed out`, 'timeout'));
      }, Math.max(1000, timeoutMs));
      abortHandler = () => {
        if (!this._pending.has(id)) return;
        this._pending.delete(id);
        if (method === 'tools/call') { try { this._notify('notifications/cancelled', { requestId: id, reason: 'user_steer' }); } catch { /* best-effort */ } }
        cleanup();
        reject(mcpBridgeError(`mcp ${method} aborted by user steer`, 'abort'));
      };
      this._pending.set(id, { resolve, reject, timer, cleanup });
      if (signal) {
        signal.addEventListener('abort', abortHandler, { once: true });
        if (signal.aborted) { abortHandler(); return; }
      }
      this._request('POST', this._ssePostUrl, { jsonrpc: '2.0', id, method, params: params || {} }, timeoutMs, null, options)
        .then(resp => {
          if (resp.error || (resp.status && resp.status >= 400)) {
            cleanup(); this._pending.delete(id);
            reject(mcpBridgeError('mcp sse post: ' + (resp.error || ('HTTP ' + resp.status)), resp.why));
          }
        });
    });
  }

  _rpc(method, params, timeoutMs = 8000, options = {}) {
    return this.transport === 'sse' ? this._rpcSse(method, params, timeoutMs, options) : this._rpcHttp(method, params, timeoutMs, options);
  }

  _notify(method, params) {
    if (this.dead) return;
    const url = this.transport === 'sse' ? this._ssePostUrl : this.url;
    if (!url) return;
    this._request('POST', url, { jsonrpc: '2.0', method, params: params || {} }, 5000).catch(() => {});
  }

  // legacy-SSE: open the GET event stream, wait for the `endpoint` event, then keep reading `message`
  // events into the pending map. tools/list_changed notifications mark the catalog stale.
  async _openSseStream() {
    let u; try { u = new URL(this.url); } catch { throw new Error('bad url: ' + this.url); }
    const lib = u.protocol === 'https:' ? require('https') : http;
    await new Promise((resolve, reject) => {
      // hunt2-mcp:openTimer 修前声明在响应回调里,而 req.on('error') 在回调外引用它 —— 连接被拒(连接器
      // 地址写错/对端没起)时 error 先于任何响应到达,ReferenceError 冒成 uncaughtException,整个工作台进程退出。
      // 现在提到外层、从发请求起就计时:连不上、连上不给 endpoint、TCP 挂住,都在这一个时限内拒掉并断开请求。
      let opened = false;
      let req = null;
      const openTimer = setTimeout(() => {
        if (opened) return;
        reject(new Error('mcp sse: 等 endpoint 事件超时'));
        try { if (req) req.destroy(); } catch { /* ignore */ }
      }, mcpStartupRpcMs(this, 8000));
      req = lib.request(u, { method: 'GET', headers: { ...this.headers, 'Accept': 'text/event-stream' } }, res => {
        if (res.statusCode >= 400) { clearTimeout(openTimer); reject(new Error('mcp sse: HTTP ' + res.statusCode)); res.resume(); return; }
        this._sseReq = req;
        res.setEncoding('utf8');
        // 干净的事件累积器:event:/data: 逐行累积,空行派发(多行 data 以 \n 连接 —— e5-multiline-sse 教训)。
        let evtName = 'message', evtData = [];
        const dispatch = () => {
          if (!evtData.length) { evtName = 'message'; return; }
          const raw = evtData.join('\n');
          const name = evtName;
          evtName = 'message'; evtData = [];
          if (name === 'endpoint' && !opened) {
            opened = true; clearTimeout(openTimer);
            this._ssePostUrl = new URL(raw.trim(), this.url).toString();
            resolve();
            return;
          }
          const msgObj = safeJsonParse(raw, null);
          if (!msgObj) return;
          if (msgObj.id != null && msgObj.method != null) {
            // 对端发来的请求(ping 等):回话走 endpoint POST,绝不拿它的 id 去结我们的 pending。
            if (!this.dead && this._ssePostUrl) this._request('POST', this._ssePostUrl, mcpServerRequestReply(msgObj), 5000).catch(() => {});
            return;
          }
          if (msgObj.id != null) {
            const p = this._pending.get(msgObj.id);
            if (p) {
              if (p.cleanup) p.cleanup(); else clearTimeout(p.timer); this._pending.delete(msgObj.id);
              if (msgObj.error) p.reject(new Error(msgObj.error.message || 'mcp error'));
              else p.resolve(msgObj.result);
            }
          } else if (msgObj.method === 'notifications/tools/list_changed') {
            this._toolsStale = true; // 03 §4.2:响应 tools/list_changed —— 下次 listTools 前重列
          }
        };
        res.on('data', chunk => {
          this._sseBuf += chunk;
          let nl;
          while ((nl = this._sseBuf.indexOf('\n')) >= 0) {
            const line = this._sseBuf.slice(0, nl).replace(/\r$/, '');
            this._sseBuf = this._sseBuf.slice(nl + 1);
            if (line === '') { dispatch(); continue; }
            if (line.startsWith(':')) continue; // heartbeat/comment
            const em = line.match(/^event:\s?(.*)$/); if (em) { evtName = em[1].trim() || 'message'; continue; }
            const dm = line.match(/^data:\s?(.*)$/); if (dm) { evtData.push(dm[1]); continue; }
          }
        });
        res.on('end', () => { this.dead = true; this._failAllPending(new Error('mcp sse: 事件流断开')); });
        res.on('error', e => { this.dead = true; this._failAllPending(new Error('mcp sse: ' + (e && e.message))); });
      });
      req.on('error', e => {
        clearTimeout(openTimer);
        reject(new Error('mcp sse connect: ' + (e && e.message)));   // 已 open 时是空操作
        // 已建立的流中途断(ECONNRESET 等):与 res 'error' 同一收尾,挂着的调用立刻失败,下次调用重建。
        if (opened) { this.dead = true; this._failAllPending(new Error('mcp sse: ' + (e && e.message))); }
      });
      req.end();
    });
  }

  async start() {
    if (this.started) return;
    this.started = true;
    try {
      if (this.transport === 'sse') await this._openSseStream();
      await this._initialize(mcpStartupRpcMs(this, 10000));
      this.tools = await this._listAllTools(mcpStartupRpcMs(this, 10000));
    } catch (e) {
      this.kill();
      this.dead = true;
      throw new Error(`remote mcp handshake failed: ${e && e.message ? e.message : e}`);
    }
    return this;
  }

  // initialize + notifications/initialized。start 与「会话失效就地重握手」共用。
  async _initialize(timeoutMs) {
    const init = await this._rpc('initialize', {
      protocolVersion: '2025-03-26',
      capabilities: {},
      clientInfo: { name: RUYI_MCP_SERVER_ID, version: VERSION },
    }, timeoutMs);
    this.serverInfo = (init && init.serverInfo) || {};
    this._notify('notifications/initialized', {});
    return init;
  }
  _listAllTools(timeoutMs) { return mcpListAllTools((m, p, t) => this._rpc(m, p, t), timeoutMs); }
  // 探针用:真发一次 tools/list,不读缓存(同 McpStdioClient.refreshTools)。
  async refreshTools(timeoutMs) { this.tools = await this._listAllTools(timeoutMs); this._toolsStale = false; return this.tools; }

  // 03 §4.2 tools/list_changed:sse 通知把目录标陈旧,此处惰性重列(不主动推,桥是拉模型)。
  async listTools() {
    if (this._toolsStale && !this.dead) {
      try {
        this.tools = await this._listAllTools(8000);
      } catch { /* 保留旧目录,下次再试 */ }
      this._toolsStale = false;
    }
    return this.tools;
  }

  // Same result normalization as McpStdioClient.callTool — never throws.
  async callTool(name, args, timeoutMs, options = {}) {
    if (!mcpToolAllowed(this, name)) return { ok: false, error: `tool '${name}' is disabled for MCP server '${this.id}' (enabledTools/disabledTools)` };
    const limit = Math.max(1000, Number(timeoutMs) || Number(this.toolTimeoutMs) || bridgedToolCallTimeoutMs(name, args));
    try {
      const res = await this._rpc('tools/call', mcpCallToolParams(name, args, options), limit, options);
      return normalizeMcpToolResult(res);
    } catch (e) {
      const m = (e && e.message) ? e.message : String(e);
      if (e && e.mcpAborted) {
        try { this.kill(); } catch { /* already dead */ }
        return { ok: false, error: '工具已因用户插话中断；远程 MCP 连接已重置，模型将立即处理新指令', steerInterrupted: true };
      }
      if (e && e.mcpTimeout) {
        // 远程无进程树可杀 —— 断连接 + 下次调用惰性重建(sse 流 / session 重新握手)。
        try { this.kill(); } catch { /* already dead */ }
        return { ok: false, error: `tool timed out after ${Math.round(limit / 1000)}s; 远程连接已重置,下次调用将自动重连` };
      }
      return { ok: false, error: m };
    }
  }

  kill() {
    this.dead = true;
    this._failAllPending(new Error('mcp client killed'));
    try { if (this._sseReq) this._sseReq.destroy(); } catch { /* ignore */ }
    this._sseReq = null;
  }
}

// Live bridged-client registry (shared across turns). Lazy start; a failed start is cached as a
// negative entry (with a timestamp) so we don't respawn a broken server on every single turn.
const mcpClients = new Map();       // serverId -> McpStdioClient
const mcpClientFailures = new Map(); // serverId -> { at, error }
const MCP_FAILURE_COOLDOWN_MS = 60000;
const mcpClientPending = new Map();  // 55a: serverId -> 进行中的 start Promise(并发互斥,防孤儿子进程)
const mcpStartingClients = new Map(); // 55a: serverId -> 正在握手(尚未入 mcpClients)的客户端,invalidate 时需 kill
const mcpClientGen = new Map();     // 55a: serverId -> 代数;invalidate 自增以让在途 start 结果作废、不写冷却
// hunt2-mcp:serverId -> 当前运行时状态(活客户端 / 在途启动 / 失败冷却)所属条目的指纹。上面几张表都只按 id 记账,
// 修前用户在设置页 / import-folder / import-config 里改好了一个坏连接器(同 id),旧进程、旧冷却(60s 内一律 null)
// 与在途启动照用不误 —— 「改好了还是连不上」。现在取客户端前先比指纹,变了就按 invalidateMcpRuntime 作废旧的。
const mcpClientFingerprints = new Map();
function mcpEntryFingerprint(entry) {
  const e = entry || {};
  return JSON.stringify([e.transport || 'stdio', e.command || '', e.args || [], e.cwd || '', e.env || {}, e.url || '', e.headers || {},
    e.bearerTokenEnvVar || '', e.startupTimeoutMs || 0, e.toolTimeoutMs || 0, e.enabledTools || null, e.disabledTools || null]);
}
function reconcileMcpEntryFingerprint(entry) {
  if (!entry || !entry.id) return;
  const fp = mcpEntryFingerprint(entry);
  const prev = mcpClientFingerprints.get(entry.id);
  if (prev !== undefined && prev !== fp) invalidateMcpRuntime(entry.id);
  mcpClientFingerprints.set(entry.id, fp);
}

// ============================================================================
// v1.1-W2 (T2) — MCP drop-in 自动扫描。
// ============================================================================
// 扫描两个位置的 `*/ruyi-mcp.json` 清单并「运行时合并」进 externalMcpServers 视图(见 resolveExternalMcpServers):
//   ① <repo>/mcp/*/ruyi-mcp.json      —— 随发行包分发的即插即用连接器(externalRoot()/mcp)。
//   ② <dataRoot>/mcp/*/ruyi-mcp.json  —— 用户自装(dataRoot()/mcp)。
// 与 /api/mcp/import-folder(v1.0.2-S5)的关系【互补,非重复】:
//   • import-folder 走「持久化」路径 —— 把清单写进 config.externalMcpServers(删条目=卸载,重启保留)。
//   • drop-in 走「运行时合并」路径 —— 绝不写回 config;存在性由文件夹本身表达,删文件夹即卸载。
//   两者互不覆盖:id 冲突时 config 里的显式条目(含 import-folder 写入的)优先,drop-in 跳过并审计一条 warn。
// cwd 缺省 = 清单所在文件夹(与 import-folder 同语义)。drop-in 数量上限 10。
// 同步 I/O(readdirSync/readFileSync):调用点是请求期且频繁,故加 2s 缓存;扫描量小(≤两目录各 ≤10 子文件夹)。
const MCP_DROPIN_MAX = 10;
let _dropInCache = { at: 0, list: null };
const MCP_DROPIN_CACHE_MS = 2000;
function mcpDropInDirs() {
  return [
    { root: path.join(externalRoot(), 'mcp'), source: 'repo' },
    { root: path.join(dataRoot(), 'mcp'), source: 'dataRoot' },
  ];
}
// 扫描并返回清洗后的 drop-in 条目数组 [{id,label,command,args,cwd,env,enabled,_dropInSource}]。纯读盘,不改 config。
// 坏清单(缺失/超限/解析失败/清洗后无效)静默跳过(审计一条 warn),绝不抛。总数封顶 MCP_DROPIN_MAX。
function scanMcpDropIns() {
  const now = Date.now();
  if (_dropInCache.list && (now - _dropInCache.at) < MCP_DROPIN_CACHE_MS) return _dropInCache.list;
  const out = [];
  const seen = new Set();
  for (const { root, source } of mcpDropInDirs()) {
    let subdirs;
    try { subdirs = fs.readdirSync(root, { withFileTypes: true }); }
    catch { continue; } // mcp/ 目录不存在 → 正常,跳过
    for (const ent of subdirs) {
      if (out.length >= MCP_DROPIN_MAX) break;
      const folder = path.join(root, ent.name);
      // 链进来的连接器目录(符号链接 / junction)也认:Dirent 对链接不报目录,stat 跟随一次(hunt2-mcp,同 readSkillDir)。
      if (!ent.isDirectory()) {
        if (!ent.isSymbolicLink()) continue;
        try { if (!fs.statSync(folder).isDirectory()) continue; } catch { continue; }
      }
      const manifestPath = path.join(folder, 'ruyi-mcp.json');
      let raw = null;
      try {
        const st = fs.statSync(manifestPath);
        if (!st.isFile() || st.size > 32 * 1024) throw new Error('too large / not a file');
        raw = safeJsonParse(fs.readFileSync(manifestPath, 'utf8'), null);
      } catch { continue; } // 无清单 → 该文件夹不是 drop-in,跳过(不审计,常态)
      if (!raw || typeof raw !== 'object') { logEvent({ kind: 'mcp_dropin_skip', reason: 'bad-manifest', folder, source }); continue; }
      // cwd 缺省 = 清单所在文件夹(与 import-folder 同)。
      const withCwd = { ...raw, cwd: (typeof raw.cwd === 'string' && raw.cwd.trim()) ? raw.cwd : folder };
      const cleaned = sanitizeExternalMcpServer(withCwd);
      if (!cleaned) { logEvent({ kind: 'mcp_dropin_skip', reason: 'invalid', folder, source }); continue; }
      if (cleaned.enabled === false) continue; // 清单显式禁用 → 跳过
      if (seen.has(cleaned.id)) { logEvent({ kind: 'mcp_dropin_skip', reason: 'dup-dropin-id', id: cleaned.id, folder, source }); continue; }
      seen.add(cleaned.id);
      out.push({ ...cleaned, _dropInSource: source, _dropInFolder: folder });
    }
    if (out.length >= MCP_DROPIN_MAX) break;
  }
  _dropInCache = { at: now, list: out };
  return out;
}
// 测试可用:强制下次扫描重读盘(e2e 造完清单后调用)。
function invalidateMcpDropInCache() { _dropInCache = { at: 0, list: null }; }

// ── ruyi-toolbox 组件登记(用户 2026-09-21:「toolbox 下的都自动识别接入 —— 是 MCP 就自动配上,服务就自动拉起并配置好」)──
// 两个仓库之间【唯一】的对接面是 ruyi-toolbox 仓的 docs/00-component-registry.md:组件装好后在
// ~/.ruyi-toolbox/components/<id>.json 放一份登记,本函数只读那个目录,绝不读任何组件的代码目录。
// 与上面 drop-in 的关系:drop-in 的清单住在【如意自己的】目录里(仓里/dataRoot),这一条住在用户主目录下的
// toolbox 目录里,而且多一种 kind:'service'(常驻本机的小 HTTP 服务,由 04f 拉起并接成能力端点)。
// 威胁模型(26 号文 §4「localCommand 只能来自配置文件,不接受 API 写入」的延续):命令【只来自磁盘上的登记文件】,
// 如意没有任何 HTTP 途径写它;登记目录与 config.json 同一信任域(能写这里的人本来就能改 externalMcpServers 里的命令)。
// 校验从严、坏文件一律当「没装」并审计一条,绝不抛、绝不打断启动:绝对路径且存在、不经 shell、不展开变量、不拼接参数。
// 同步 I/O + 2s 缓存(与 drop-in 同理:resolveExternalMcpServers 在请求期频繁调)。上限 20 个组件、单文件 32 KB。
const TOOLBOX_COMPONENT_MAX = 20;
const TOOLBOX_PROVIDES_TYPES = new Set(['asr', 'asr-stream']);   // 现在认识的能力;不认识的 type 跳过(向前兼容:组件可以先登记、如意后支持)。asr-stream:130(51 号文)
let _toolboxCache = { at: 0, list: null };
const _toolboxSkipLogged = new Set();
function toolboxComponentsDir() {
  const override = String(process.env.RUYI_TOOLBOX_HOME || '').trim();
  return path.join(override || path.join(os.homedir(), '.ruyi-toolbox'), 'components');
}
function sanitizeToolboxComponent(raw, fileId) {
  if (!raw || typeof raw !== 'object' || raw.schema !== 1) return { error: 'schema' };
  const id = String(raw.id || '');
  if (!/^[a-z0-9][a-z0-9-]{0,39}$/.test(id) || id !== fileId) return { error: 'id' };
  const kind = raw.kind === 'service' || raw.kind === 'mcp' ? raw.kind : '';
  if (!kind) return { error: 'kind' };
  const run = raw.run && typeof raw.run === 'object' ? raw.run : null;
  const command = run && typeof run.command === 'string' ? run.command.trim() : '';
  const cwd = run && typeof run.cwd === 'string' ? run.cwd.trim() : '';
  if (!command || command.length > 1000 || !path.isAbsolute(command)) return { error: 'run.command' };
  if (!cwd || cwd.length > 1000 || !path.isAbsolute(cwd)) return { error: 'run.cwd' };
  try { if (!fs.statSync(command).isFile()) return { error: 'run.command' }; } catch { return { error: 'run.command-missing' }; }
  try { if (!fs.statSync(cwd).isDirectory()) return { error: 'run.cwd' }; } catch { return { error: 'run.cwd-missing' }; }
  const rawArgs = Array.isArray(run.args) ? run.args : [];
  if (rawArgs.length > 32 || rawArgs.some(a => typeof a !== 'string' || a.length > 1000)) return { error: 'run.args' };
  const env = {};
  const rawEnv = run.env && typeof run.env === 'object' && !Array.isArray(run.env) ? run.env : {};
  if (Object.keys(rawEnv).length > 32) return { error: 'run.env' };
  for (const [k, v] of Object.entries(rawEnv)) {
    if (!/^[A-Za-z_][A-Za-z0-9_]{0,119}$/.test(k) || typeof v !== 'string' || v.length > 2048) return { error: 'run.env' };
    env[k] = v;
  }
  const out = {
    id, kind,
    name: (typeof raw.name === 'string' ? raw.name : '').trim().slice(0, 80) || id,
    version: (typeof raw.version === 'string' ? raw.version : '').trim().slice(0, 40),
    run: { command, args: rawArgs.slice(), cwd, env },
  };
  if (kind === 'mcp') {
    const transport = raw.mcp && typeof raw.mcp === 'object' ? String(raw.mcp.transport || 'stdio') : 'stdio';
    if (transport !== 'stdio') return { error: 'mcp.transport' };
    return { component: out };
  }
  const svc = raw.service && typeof raw.service === 'object' ? raw.service : null;
  const port = svc ? Number(svc.port) : NaN;
  if (!Number.isInteger(port) || port < 1024 || port > 65535) return { error: 'service.port' };
  const portEnv = svc && typeof svc.portEnv === 'string' ? svc.portEnv : '';
  if (!/^[A-Za-z_][A-Za-z0-9_]{0,119}$/.test(portEnv)) return { error: 'service.portEnv' };
  const health = svc && typeof svc.health === 'string' ? svc.health : '';
  if (!/^\/[A-Za-z0-9._~\/-]{0,199}$/.test(health)) return { error: 'service.health' };
  const componentTag = svc && typeof svc.component === 'string' ? svc.component.trim() : '';
  if (!componentTag || componentTag.length > 80) return { error: 'service.component' };
  const provides = [];
  for (const p of (Array.isArray(raw.provides) ? raw.provides.slice(0, 8) : [])) {
    if (!p || typeof p !== 'object' || !TOOLBOX_PROVIDES_TYPES.has(p.type)) continue;
    const basePath = typeof p.basePath === 'string' && /^\/[A-Za-z0-9._~\/-]{0,99}$/.test(p.basePath) ? p.basePath : '';
    const model = typeof p.model === 'string' ? p.model.trim().slice(0, 120) : '';
    if (!model) continue;
    // 133(约定 §2.2 可选字段):同一端点上可选的多份模型 [{id,label}];缺省那份必须在清单里,不在就补到最前。
    const models = [];
    const seen = new Set();
    for (const m of (Array.isArray(p.models) ? p.models.slice(0, 8) : [])) {
      const id = m && typeof m === 'object' && typeof m.id === 'string' ? m.id.trim().slice(0, 120) : '';
      if (!id || seen.has(id)) continue;
      seen.add(id);
      models.push({ id, label: (typeof m.label === 'string' ? m.label.trim().slice(0, 80) : '') || id });
    }
    if (models.length && !seen.has(model)) models.unshift({ id: model, label: model });
    provides.push({ type: p.type, basePath, model, protocol: p.protocol === 'chat-audio' ? 'chat-audio' : 'transcriptions', ...(models.length ? { models } : {}) });
  }
  // 133:可选的「立刻卸载」路径 —— 用户把语音识别切走时如意 POST 它,组件就地释放显存。形状同 health。
  const unload = svc && typeof svc.unload === 'string' && /^\/[A-Za-z0-9._~\/-]{0,199}$/.test(svc.unload) ? svc.unload : '';
  out.service = { port, portEnv, health, component: componentTag, ...(unload ? { unload } : {}) };
  out.provides = provides;
  return { component: out };
}
function scanToolboxComponents() {
  const now = Date.now();
  if (_toolboxCache.list && (now - _toolboxCache.at) < MCP_DROPIN_CACHE_MS) return _toolboxCache.list;
  const out = [];
  const dir = toolboxComponentsDir();
  let files = [];
  try { files = fs.readdirSync(dir, { withFileTypes: true }); } catch { files = []; }   // 目录不存在 = 没装 toolbox,常态
  for (const ent of files) {
    if (out.length >= TOOLBOX_COMPONENT_MAX) break;
    if (!ent.isFile() || !ent.name.endsWith('.json')) continue;
    const file = path.join(dir, ent.name);
    let raw = null;
    try {
      const st = fs.statSync(file);
      if (st.size > 32 * 1024) throw new Error('too large');
      raw = safeJsonParse(fs.readFileSync(file, 'utf8').replace(/^﻿/, ''), null);
    } catch { raw = null; }
    const verdict = sanitizeToolboxComponent(raw, ent.name.slice(0, -5));
    if (!verdict.component) {
      // 扫描是 2s 缓存、请求期频繁调:同一份坏文件只审计一次,不每两秒刷一行日志。
      const key = ent.name + ':' + (verdict.error || 'unreadable');
      if (!_toolboxSkipLogged.has(key)) { _toolboxSkipLogged.add(key); logEvent({ kind: 'toolbox_component_skip', file: ent.name, reason: verdict.error || 'unreadable' }); }
      continue;
    }
    out.push(verdict.component);
  }
  _toolboxCache = { at: now, list: out };
  return out;
}
function invalidateToolboxCache() { _toolboxCache = { at: 0, list: null }; }
// 服务类组件的管理器住 04f(拼接顺序在本文件之后)。它的四个消费点(13 的启动／收尾／保存配置／状态视图、05 的转写)
// 一律经这张表调,从不直接引用 04f 的符号 —— 于是 04f 是【零入边】的叶子,进不了那个唯一的大强连通分量,
// 它到 00／01／04 的出边也就不是环边(与 StewardHooks／SchedulerHooks、13t 同一个模具,103b 的债务上限一个字不用加)。
// 表是空的也安全:每个消费点都先判 typeof === 'function'(require() 进来的单测、裁剪构建都不会炸)。
const ToolboxHooks = {};
// 这台配置下哪些登记的组件是【启用】的:总开关关掉 = 一个都不接;逐个停用记在 toolbox.disabled。
function enabledToolboxComponents(config) {
  const tb = (config && config.toolbox) || {};
  if (tb.autoDiscover === false) return [];
  const disabled = new Set(Array.isArray(tb.disabled) ? tb.disabled : []);
  return scanToolboxComponents().filter(c => !disabled.has(c.id));
}

// Merge the desktop MCP (detected/explicit) + user externalMcpServers (enabled) into one list of
// {id,label,command,args,cwd,env}. desktopMcp always uses id 'ai-computer-control'.
// v1.1-W2 (T2): also merges drop-in connectors scanned from <repo>/mcp/*/ and <dataRoot>/mcp/*/ (runtime
// merge, never written back to config). config/desktop entries win on id collision; drop-in is skipped+warned.
function mcpRuntimeCommon(entry) {
  const out = {};
  for (const key of ['startupTimeoutMs', 'toolTimeoutMs']) {
    if (Number.isInteger(entry && entry[key]) && entry[key] >= 1 && entry[key] <= 2147483647) out[key] = entry[key];
  }
  for (const key of ['enabledTools', 'disabledTools']) {
    if (Array.isArray(entry && entry[key])) out[key] = entry[key].slice();
  }
  return out;
}

function isEquivalentDesktopAccServer(entry) {
  if (!entry || entry.transport || !entry.command) return false;
  const args = Array.isArray(entry.args) ? entry.args.map(value => String(value).trim().toLowerCase()) : [];
  if (args.includes('ai_computer_control.server')) return true;
  const executable = path.basename(String(entry.command)).toLowerCase().replace(/\.(exe|cmd|bat)$/i, '');
  return executable === 'ai-computer-control' || executable === 'ai_computer_control';
}

function resolveExternalMcpServers(config) {
  const out = [];
  const dm = config && config.desktopMcp;
  if (dm && dm.enabled) {
    let command = String(dm.command || '').trim();
    let args = Array.isArray(dm.args) ? dm.args.slice() : [];
    let cwd = String(dm.cwd || '').trim() || undefined;
    let env = {};
    let pythonSource = '';
    if (command) {
      // Explicit override — trust the user's command/args/cwd; default UTF-8 for a python launch.
      env = { PYTHONUTF8: '1' };
    } else if (dm.autodetect) {
      const det = detectDesktopMcp();
      if (det) { command = det.command; args = det.args; cwd = det.cwd; env = det.env || {}; pythonSource = det.pythonSource || ''; }
    }
    if (command) {
      const browser = (config && config.browserAutomation) || {};
      env = { ...env,
        ACC_BROWSER_MODE: String(browser.mode || 'system'),
        ACC_BROWSER_EXECUTABLE: String(browser.executable || ''),
        ACC_BROWSER_CDP_URL: String(browser.cdpUrl || 'http://127.0.0.1:9222'),
      };
      // 工作台记忆迁移成功（或确认标准位置没有旧库）后，ACC 不再注册同名 memory 工具；若旧库
      // 损坏/迁移失败则标记不存在，工具继续可见，避免数据尚未接管就把唯一入口藏掉。
      if (legacyAccMemoryMigrationComplete()) env.ACC_HIDE_MEMORY = '1';
      out.push({ id: 'ai-computer-control', label: '桌面控制 (ai-computer-control)', command, args, cwd, env,
      pythonSource });
    }
  }
  const ext = (config && Array.isArray(config.externalMcpServers)) ? config.externalMcpServers : [];
  for (const s of ext) {
    if (!s || s.enabled === false) continue;
    if (out.some(o => o.id === s.id)) continue;   // desktop entry wins on id collision
    if (out.some(o => o.id === 'ai-computer-control') && isEquivalentDesktopAccServer(s)) {
      logEvent({ kind: 'mcp_external_skip', reason: 'duplicate-desktop-acc', id: s.id });
      continue;
    }
    // 49c:远程条目(sse/http)按 transport+url 直通(headers 引用不展开,连接时才展开)。
    if (s.transport === 'sse' || s.transport === 'http') {
      if (!s.url) continue;
      out.push({
        id: s.id, label: s.label || s.id, transport: s.transport, url: s.url, headers: s.headers || {},
        ...(s.bearerTokenEnvVar ? { bearerTokenEnvVar: s.bearerTokenEnvVar } : {}), ...mcpRuntimeCommon(s),
      });
      continue;
    }
    if (!s.command) continue;
    out.push({
      id: s.id, label: s.label || s.id, command: s.command, args: s.args || [], cwd: s.cwd || undefined,
      env: s.env || {}, ...mcpRuntimeCommon(s),
    });
  }
  // v1.1-W2 (T2): merge drop-in connectors LAST → any id already claimed by a desktop/config entry wins;
  // the drop-in is skipped and a warn is audited (config 显式条目优先，与 import-folder 持久化路径互补)。
  // enableMcpDropIn 缺省开;显式 false 可关(normalizeConfig 清洗后的布尔)。
  if (!config || config.enableMcpDropIn !== false) {
    for (const d of scanMcpDropIns()) {
      if (out.some(o => o.id === d.id)) { logEvent({ kind: 'mcp_dropin_skip', reason: 'id-conflict-config-wins', id: d.id, folder: d._dropInFolder, source: d._dropInSource }); continue; }
      if (d.transport === 'sse' || d.transport === 'http') {
        if (!d.url) continue;
        out.push({
          id: d.id, label: d.label || d.id, transport: d.transport, url: d.url, headers: d.headers || {},
          ...(d.bearerTokenEnvVar ? { bearerTokenEnvVar: d.bearerTokenEnvVar } : {}), ...mcpRuntimeCommon(d),
        });
        continue;
      }
      if (out.some(o => o.id === 'ai-computer-control') && isEquivalentDesktopAccServer(d)) {
        logEvent({ kind: 'mcp_dropin_skip', reason: 'duplicate-desktop-acc', id: d.id, folder: d._dropInFolder, source: d._dropInSource });
        continue;
      }
      out.push({
        id: d.id, label: d.label || d.id, command: d.command, args: d.args || [], cwd: d.cwd || undefined,
        env: d.env || {}, ...mcpRuntimeCommon(d),
      });
    }
  }
  // ruyi-toolbox 登记的 MCP 组件排在最后:内部 id 一律 `toolbox-<id>`(前缀保留给自动发现),显式配置／drop-in 撞 id 时让路。
  // 生命周期、工具清单、权限分级全走现有 MCP 机制 —— 这里只是又一个条目来源,与 drop-in 一样【绝不写回 config】。
  for (const c of enabledToolboxComponents(config)) {
    if (c.kind !== 'mcp') continue;
    const id = 'toolbox-' + c.id;
    if (out.some(o => o.id === id)) { logEvent({ kind: 'toolbox_component_skip', file: c.id + '.json', reason: 'mcp-id-conflict' }); continue; }
    const cleaned = sanitizeExternalMcpServer({ id, label: c.name, command: c.run.command, args: c.run.args, cwd: c.run.cwd, env: c.run.env });
    if (!cleaned) continue;
    out.push({ id: cleaned.id, label: cleaned.label, command: cleaned.command, args: cleaned.args, cwd: cleaned.cwd || undefined, env: cleaned.env, _toolbox: c.id });
  }
  return out;
}

// 48c: MCP 配置导入器 v1 -- 从 Claude Code .mcp.json / ~/.claude.json / Codex config.toml 导入(03 §4.1)。
// 零依赖:JSON 直解;TOML 用行级状态机迷你 parser(只解 [mcp_servers.X] 段的 command/args/env/cwd,够 Codex 用)。
// ${VAR}/%VAR% 双向插值(从 process.env,未定义保留原样)。sse/http 标 unsupported(远程 transport 03 §4.2 后续波)。
function _expandMcpVar(s) {
  return String(s == null ? '' : s)
    .replace(/\$\{([A-Z_][A-Z0-9_]*)\}/gi, (_, n) => (process.env[n] != null ? String(process.env[n]) : '${' + n + '}'))
    .replace(/%([A-Z_][A-Z0-9_]*)%/gi, (_, n) => (process.env[n] != null ? String(process.env[n]) : '%' + n + '%'));
}
// hunt2-mcp:Codex config.toml 的迷你 parser 重写。修前逐行正则,真实配置里常见的写法全部静默丢字段:
// 多行数组(args = [ 换行 "-y", 换行 ... ])、[mcp_servers.X.env] 子表、行尾 # 注释、单引号字面串的 env 值、
// 远程条目(url / bearer_token_env_var / http_headers / env_http_headers)。仍是零依赖小状态机,只解我们认的键;
// 既没有 command 也没有 url 的段【不再静默丢】,标 unsupported 交给导入界面如实显示。
// 引号状态机:回调拿到每个【引号外】的字符(引号内的跳过),三个小工具共用。
function _tomlScan(text, onOutside) {
  let q = '';
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (q === '"' && c === '\\') { i++; continue; }
      if (c === q) q = '';
      continue;
    }
    if (c === '"' || c === "'") { q = c; continue; }
    if (onOutside(c, i) === false) return;
  }
}
function _tomlStripComment(line) {
  let cut = -1;
  _tomlScan(line, (c, i) => { if (c === '#') { cut = i; return false; } return true; });
  return cut >= 0 ? line.slice(0, cut) : line;
}
function _tomlDepth(text) {
  let depth = 0;
  _tomlScan(text, c => { if (c === '[' || c === '{') depth++; else if (c === ']' || c === '}') depth--; });
  return depth;
}
// 按顶层分隔符切(引号与括号内的不算)。
function _tomlSplitTop(text, sep) {
  const cuts = [];
  let depth = 0;
  _tomlScan(text, (c, i) => {
    if (c === '[' || c === '{') depth++;
    else if (c === ']' || c === '}') depth--;
    else if (c === sep && depth === 0) cuts.push(i);
  });
  const out = [];
  let from = 0;
  for (const i of cuts) { out.push(text.slice(from, i)); from = i + 1; }
  out.push(text.slice(from));
  return out;
}
function _tomlKeyPath(k) {
  return _tomlSplitTop(String(k).trim(), '.').map(part => {
    const t = part.trim();
    if (/^".*"$/.test(t)) { try { return JSON.parse(t); } catch { return t.slice(1, -1); } }
    if (/^'.*'$/.test(t)) return t.slice(1, -1);
    return t;
  });
}
function _tomlValue(raw) {
  const v = String(raw).trim();
  if (v.startsWith('"""') || v.startsWith("'''")) return undefined;   // 多行字符串:不解,当没写(该段缺 command 时会被标 unsupported)
  if (/^"[\s\S]*"$/.test(v)) { try { return JSON.parse(v); } catch { return v.slice(1, -1); } }
  if (/^'[\s\S]*'$/.test(v)) return v.slice(1, -1);
  if (v === 'true') return true;
  if (v === 'false') return false;
  if (/^[+-]?\d[\d_]*(\.\d+)?$/.test(v)) return Number(v.replace(/_/g, ''));
  if (v.startsWith('[') && v.endsWith(']')) {
    return _tomlSplitTop(v.slice(1, -1), ',').map(x => x.trim()).filter(Boolean).map(_tomlValue);
  }
  if (v.startsWith('{') && v.endsWith('}')) {
    const obj = {};
    for (const pair of _tomlSplitTop(v.slice(1, -1), ',')) {
      const kv = _tomlSplitTop(pair, '=');
      if (kv.length < 2) continue;
      const key = _tomlKeyPath(kv[0]).join('.');
      if (key) obj[key] = _tomlValue(kv.slice(1).join('='));
    }
    return obj;
  }
  return undefined;   // 认不出的值(多行字符串、日期等):当没写
}
function _parseTomlMcpServers(text) {
  const byId = new Map();
  const serverFor = id => {
    if (!byId.has(id)) byId.set(id, { id, label: id, type: 'stdio', command: '', args: [], env: {}, cwd: '' });
    return byId.get(id);
  };
  const strList = v => (Array.isArray(v) ? v.filter(x => typeof x === 'string') : null);
  const setKey = (cur, sub, key, val) => {
    if (val === undefined) return;
    if (sub === 'env') { if (typeof val === 'string' || typeof val === 'number') cur.env[key] = String(val); return; }
    if (sub === 'http_headers') { if (typeof val === 'string') (cur.headers = cur.headers || {})[key] = val; return; }
    // env_http_headers:头名 -> 环境变量名。存成 ${VAR} 引用,连接时才展开(密钥不落盘明文,与 headers 同纪律)。
    if (sub === 'env_http_headers') { if (typeof val === 'string' && /^[A-Za-z_][A-Za-z0-9_]*$/.test(val)) (cur.headers = cur.headers || {})[key] = '${' + val + '}'; return; }
    if (sub) return;   // 其它子表(如 tools.*)不认
    if (key === 'command' && typeof val === 'string') cur.command = val;
    else if (key === 'cwd' && typeof val === 'string') cur.cwd = val;
    else if (key === 'url' && typeof val === 'string') cur.url = val;
    else if (key === 'enabled') cur.enabled = val !== false;
    else if (key === 'bearer_token_env_var' && typeof val === 'string' && /^[A-Za-z_][A-Za-z0-9_]*$/.test(val.trim())) cur.bearerTokenEnvVar = val.trim();
    else if ((key === 'startup_timeout_sec' || key === 'tool_timeout_sec') && Number.isFinite(val) && val > 0) {
      cur[key === 'startup_timeout_sec' ? 'startupTimeoutMs' : 'toolTimeoutMs'] = Math.min(2147483647, Math.round(val * 1000));
    } else if (key === 'startup_timeout_ms' && Number.isFinite(val) && val > 0) cur.startupTimeoutMs = Math.min(2147483647, Math.round(val));
    else if (key === 'args') { const l = strList(val); if (l) cur.args = l; }
    else if (key === 'enabled_tools') { const l = strList(val); if (l) cur.enabledTools = l; }
    else if (key === 'disabled_tools') { const l = strList(val); if (l) cur.disabledTools = l; }
    else if ((key === 'env' || key === 'http_headers' || key === 'env_http_headers') && val && typeof val === 'object' && !Array.isArray(val)) {
      for (const [k2, v2] of Object.entries(val)) setKey(cur, key, k2, v2);
    }
  };
  let cur = null, sub = '';
  let pending = '';
  for (const physical of String(text).split(/\r?\n/)) {
    let line = _tomlStripComment(physical);
    if (pending) {
      pending += '\n' + line;
      if (_tomlDepth(pending) > 0) continue;
      line = pending; pending = '';
    } else if (!line.trim()) continue;
    const trimmed = line.trim();
    if (/^\[\[/.test(trimmed)) { cur = null; sub = ''; continue; }   // 表数组:不是我们的段
    const sec = /^\[\s*([^=]+?)\s*\]$/.exec(trimmed);
    if (sec) {
      const keyPath = _tomlKeyPath(sec[1]);
      if (keyPath[0] === 'mcp_servers' && keyPath.length >= 2 && keyPath[1]) {
        cur = serverFor(keyPath[1]);
        sub = keyPath.length === 2 ? '' : (keyPath.length === 3 ? keyPath[2] : '#deeper');   // 更深的子表不认
      } else { cur = null; sub = ''; }
      continue;
    }
    const eq = _tomlSplitTop(line, '=');
    if (eq.length < 2) continue;
    const valueText = eq.slice(1).join('=');
    if (_tomlDepth(valueText) > 0) { pending = line; continue; }   // 多行数组 / 内联表:拼到括号配平
    if (!cur) continue;
    const keyPath = _tomlKeyPath(eq[0]);
    const val = _tomlValue(valueText);
    if (keyPath.length === 1) setKey(cur, sub, keyPath[0], val);
    else if (keyPath.length === 2 && !sub) setKey(cur, keyPath[0], keyPath[1], val);   // env.FOO = "x" 点号键
  }
  const out = [];
  for (const srv of byId.values()) {
    if (srv.url) srv.type = 'http';
    if (!srv.command && !srv.url) srv.unsupported = 'config.toml 段缺 command/url(或写法无法解析)';
    out.push(srv);
  }
  return out;
}
const MCP_CONFIG_JSON_MAX_BYTES = 32 * 1024 * 1024;
const MCP_CONFIG_OTHER_MAX_BYTES = 1024 * 1024;
// 解析单个 MCP 配置文件。返回 { servers, error? }。从不抛(缺失/格式错 -> error,供 UI 明示)。
function parseMcpConfigFile(filePath) {
  // hunt2-mcp:~/.claude.json 里 projects 历史动辄几 MB,修前一律 256KB 封顶 → 重度用户的 Claude Code 连接器
  // 永远导不进来。JSON 放宽到 32MB(与该文件的真实规模同档),其它格式 1MB;先 stat 再读,不把超大文件整个读进内存。
  const lower = String(filePath || '').toLowerCase();
  const maxBytes = lower.endsWith('.json') ? MCP_CONFIG_JSON_MAX_BYTES : MCP_CONFIG_OTHER_MAX_BYTES;
  let text;
  try {
    const st = fs.statSync(filePath);
    if (st.isFile() && st.size > maxBytes) return { servers: [], error: `文件过大(>${Math.round(maxBytes / 1048576)}MB,跳过)` };
    text = fs.readFileSync(filePath, 'utf8');
  } catch (e) { return { servers: [], error: '读失败: ' + (e.code === 'ENOENT' ? '文件不存在' : e.message) }; }
  if (lower.endsWith('.json')) {
    let j; try { j = JSON.parse(text); } catch (e) { return { servers: [], error: 'JSON 解析失败: ' + e.message }; }
    const ms = (j && j.mcpServers && typeof j.mcpServers === 'object') ? j.mcpServers : null;
    if (!ms) return { servers: [], error: '未找到 mcpServers 字段' };
    const servers = [];
    for (const [id, raw] of Object.entries(ms)) {
      if (!raw || typeof raw !== 'object') continue;
      const importedType = String(raw.type || raw.transport || (raw.url ? 'http' : 'stdio')).toLowerCase();
      const type = importedType === 'streamable-http' ? 'http' : importedType;
      // 48c:解析即插值规范化(${VAR}/%VAR%),apply 拿到的已是终值。
      // 49c:sse/http 不再是 unsupported —— 映射为远程条目;但 headers 值【不展开】(密钥引用 ${VAR}
      //   原样保留进 config,连接时才从 process.env 展开,防明文落盘)。
      const srv = {
        id: String(id), label: String(id), type, command: _expandMcpVar(String(raw.command || '')),
        args: Array.isArray(raw.args) ? raw.args.map(a => _expandMcpVar(String(a))) : [], env: {}, cwd: _expandMcpVar(String(raw.cwd || '')),
        enabled: raw.enabled !== false,
      };
      for (const key of ['startupTimeoutMs', 'toolTimeoutMs']) {
        const value = Number(raw[key]);
        if (Number.isInteger(value) && value >= 1 && value <= 2147483647) srv[key] = value;
      }
      for (const key of ['enabledTools', 'disabledTools']) if (Array.isArray(raw[key])) srv[key] = raw[key].filter(value => typeof value === 'string');
      if (raw.env && typeof raw.env === 'object') for (const [k, v] of Object.entries(raw.env)) srv.env[k] = _expandMcpVar(String(v));
      if (type === 'sse' || type === 'http') {
        srv.url = String(raw.url || '');
        if (raw.headers && typeof raw.headers === 'object') {
          srv.headers = {};
          for (const [k, v] of Object.entries(raw.headers)) if (typeof v === 'string') srv.headers[k] = v;
        }
        if (typeof raw.bearerTokenEnvVar === 'string' && /^[A-Za-z_][A-Za-z0-9_]*$/.test(raw.bearerTokenEnvVar.trim())) srv.bearerTokenEnvVar = raw.bearerTokenEnvVar.trim();
        if (!srv.url) srv.unsupported = '远程条目缺 url';
      }
      servers.push(srv);
    }
    return { servers };
  }
  if (lower.endsWith('.toml') || /\[mcp_servers\./.test(text)) {
    return { servers: _parseTomlMcpServers(text).map(s => ({ ...s, command: _expandMcpVar(s.command), args: s.args.map(_expandMcpVar), env: Object.fromEntries(Object.entries(s.env).map(([k, v]) => [k, _expandMcpVar(v)])), cwd: _expandMcpVar(s.cwd) })) };
  }
  return { servers: [], error: '未知格式(需 .json 含 mcpServers,或 .toml 含 [mcp_servers.X])' };
}
// 扫描多个源文件,插值 + 标冲突。返回 { servers, errors }。servers 每条带 source + conflict(撞 config 已有 id)。
async function scanMcpSources(filePaths, config) {
  const servers = [], errors = [];
  const existingIds = new Set((Array.isArray(config && config.externalMcpServers) ? config.externalMcpServers : []).map(s => s && s.id).filter(Boolean));
  for (const fp of filePaths) {
    const r = parseMcpConfigFile(fp);
    for (const s of r.servers) {
      s.source = fp;
      s.conflict = existingIds.has(s.id);
      servers.push(s);
    }
    if (r.error) errors.push({ path: fp, error: r.error });
  }
  return { servers, errors };
}

function safeMcpInventory(config) {
  return resolveExternalMcpServers(config).map(entry => ({
    id: entry.id, label: entry.label || entry.id, command: entry.command, args: mcpArgsForDisplay(entry.args || []),   // 107-S0b:args 显示脱敏(`--token xyz` 一类)
    cwd: entry.cwd || '', envKeys: Object.keys(entry.env || {}),
    // 49c:远程条目无 command,回显 transport+url(headers 键名可见,值永不回显)。
    // 107-S2:url 过 safeUrlForDisplay —— `https://u:p@host` 与 `?api_key=…` 此前经 mcp_list 明文回给模型。
    ...(entry.transport ? { transport: entry.transport, url: safeUrlForDisplay(entry.url || ''), headerKeys: Object.keys(entry.headers || {}) } : {}),
    builtin: entry.id === 'ai-computer-control',
  }));
}

function invalidateMcpRuntime(id) {
  invalidateMcpDropInCache();
  bridgedCatalogCache = { key: '', expiresAt: 0, value: null };
  if (id) {
    const client = mcpClients.get(id);
    if (client) { try { client.kill(); } catch { /* ignore */ } mcpClients.delete(id); }
    // 55a: kill 正在握手(尚未入 mcpClients)的子进程 -- 否则一个 HANG 初始化的进程会活到 8s rpc 超时,
    // 既成孤儿(toggle 应立即停),又会让后续并发 probe 复用其永挂的 pending Promise 而不重新 spawn。
    const starting = mcpStartingClients.get(id);
    if (starting) { try { starting.kill(); } catch { /* ignore */ } mcpStartingClients.delete(id); }
    mcpClientFailures.delete(id);
    // hunt2-mcp:在途 start 的 Promise 也摘掉 —— 否则紧接着的 getMcpClient 会复用这个已被作废(结果注定 null)的
    // Promise,而不是按新配置重新起一个。
    mcpClientPending.delete(id);
    mcpClientFingerprints.delete(id);
    // 自增代数:在途 start(其 Promise 仍可能被并发 probe await)settle 后据此作废结果——
    // 已 killed 的失败不写冷却(否则 toggle-on 后立刻又命中 60s 冷却不重连)。
    mcpClientGen.set(id, (mcpClientGen.get(id) || 0) + 1);
  }
}

// 55b: toggle/delete 的源守卫。config 源(externalMcpServers 里有该 id)-> null(可操作);
// 内置 desktop / drop-in -> 409 + 人话原因;都没找到 -> 404。toggle 与 delete 共用,防两路判定分歧。
// 117n-M2:从 13b 下沉到 04 —— 工具面的 mcp_configure 也必须走这条护栏,而它住 04,04 -> 13b 是前向边。
// opts.allowMissing:upsert 语义下「本来就没有」是合法的新建,不算错;内置与 drop-in 仍然挡。
function mcpConnectorMutateError(id, config, opts) {
  if (id === 'ai-computer-control') return { status: 409, error: '内置桌面连接器(ai-computer-control)不可在此启停/删除;请在「设置」中调整桌面控制开关。' };
  // 如意自己的 MCP server id(ruyi 与旧名 win-claude-workbench)是保留名:新建 / 改写成这个 id 的外部连接器,
  // 生成 MCP 配置时会被静默丢掉,连接器列表里还会出现两个同名项。导入路径早就挡了,这里补上手动新建 / mcp_configure。
  // 已经存在的同名旧条目仍然允许停用 / 删除(allowMissing 只在 upsert 时给)。
  if (opts && opts.allowMissing && isRuyiMcpServerId(id)) return { status: 409, error: `「${id}」是如意自己的 MCP 服务名,不能用作外部连接器的 id;请换一个 id。` };
  const list = (config && Array.isArray(config.externalMcpServers)) ? config.externalMcpServers : [];
  if (list.some(s => s && s.id === id)) return null;
  const drop = scanMcpDropIns().find(d => d && d.id === id);
  if (drop) return { status: 409, error: `连接器「${id}」是 drop-in 目录运行时合并的(${drop._dropInFolder}),不可在此启停/删除/改写;请移除对应目录后再试。` };
  if (opts && opts.allowMissing) return null;
  return { status: 404, error: '未找到连接器: ' + id };
}

// 停用/删除遮蔽了同 id drop-in 的 config 条目时的如实告知(resolveExternalMcpServers:config 优先,
// 条目消失/停用后 drop-in 落入清单)。两个动作两句话,别处不要再抄一份。
const MCP_DROPIN_SHADOW_WARNING = {
  remove: '注意:存在同 id 的 drop-in 连接器,删除该 config 条目后 drop-in 版本将生效;如需彻底移除,请同时删除对应 drop-in 目录。',
  disable: '注意:存在同 id 的 drop-in 连接器,停用该 config 条目后 drop-in 版本将生效;如需彻底停用,请移除对应 drop-in 目录。',
};

// ── 117n-M2:MCP 连接器变更的唯一内核 ────────────────────────────────────────────────────────
// 修前同一件事有两处独立实现。HTTP 面(13b 的 POST /api/mcp/connectors/toggle 与
// DELETE /api/mcp/connectors)做了八件事:源守卫 -> 改 list -> 落盘 -> invalidateMcpRuntime ->
// 重生成 .mcp.json -> 删除时记 dismissedMcpIds -> drop-in 遮蔽警告 -> 审计。
// 工具面(mcp_configure -> configureMcpFromTool)只做了其中三件,于是漏了三项副作用:
//   · remove 不记 dismissedMcpIds -> 模型删掉的连接器下次启动被 autoImportClaudeCodeMcp 悄悄加回来;
//   · 不调 generateMcpConfig -> .mcp.json 落后于 config.json,CLI 侧看到的是旧清单;
//   · 没有源守卫(只硬编码挡了 ai-computer-control)-> drop-in 来源的连接器在工具面能改、
//     HTTP 面却拒绝(同一件事两套判据),且零审计。
// 现在两边都调这里,判据与副作用只有一份。op:'set-enabled' | 'remove' | 'upsert'
// (upsert 是工具面专有的写入操作,但走同一条护栏与同一个 generateMcpConfig 收尾)。
// 不收 config 入参:护栏与改 list 必须发生在 mutateConfig 的锁内、基于锁内刚读到的那一份,
// 拿调用方的快照判定等于把丢失更新换个地方留着。
// 返回 { ok:false, status, error } 或 { ok:true, op, id, config, server, removed, warning? }。
async function mutateMcpConnector({ op, id, enabled, server }) {
  const wantId = String(id || '').trim();
  if (!wantId) return { ok: false, status: 400, error: 'id is required' };
  const on = enabled !== false;
  const r = await mutateConfig(async (config) => {
    const guard = mcpConnectorMutateError(wantId, config, { allowMissing: op === 'upsert' });
    if (guard) return { abort: { ok: false, status: guard.status, error: guard.error } };
    const list = Array.isArray(config.externalMcpServers) ? config.externalMcpServers.slice() : [];
    const dismissed = Array.isArray(config.dismissedMcpIds) ? config.dismissedMcpIds.slice() : [];
    const idx = list.findIndex(s => s && s.id === wantId);
    if (op === 'set-enabled') {
      list[idx] = { ...list[idx], enabled: on };
    } else if (op === 'remove') {
      list.splice(idx, 1);
      // 记入 dismissedMcpIds:启动时 autoImportClaudeCodeMcp 会跳过它,避免「删了又自动回来」。
      // (normalizeConfig 去重;用户经 import-folder/import-config/upsert 显式再导入会从 dismissed 移除。)
      if (!dismissed.includes(wantId)) dismissed.push(wantId);
    } else if (op === 'upsert') {
      // 107-S0b:模型可能把读到的掩码(env／headers 的 ••••、args 的脱敏标记)原样回传 —— 与 POST /api/config 同一条
      // 还原规则:同 id 且启动向量(command／cwd／args,远程为 url)没变才取磁盘真值,否则 sanitize 那道闸清空。
      // 107-S2:远程 url 的显示脱敏(`?api_key=••••cdef`)也在这里对回真值 —— 模型从 mcp_list／
      // steward_config_get 读到的就是脱敏形,原样 upsert 回来是常态。对不回去的(改了一半的掩码)
      // 活不过 sanitize -> 下面那句 400,不会把掩码写进 config.json,也不会把连接器静默改接到别处。
      const clean = sanitizeExternalMcpServer(restoreExternalMcpServerSecrets({ ...(server || {}), id: wantId }, idx >= 0 ? list[idx] : null, collectDisplayUrlRestores(config)));
      if (!clean) return { abort: { ok: false, status: 400, error: 'MCP 配置无效：upsert 至少需要 id 与 command，args 必须是字符串数组。' } };
      // 122-§2.6:用户/工具显式 upsert = 接管这条连接器 —— 清掉来源标记,它从此算 Ruyi 自己的、照常同步回
      // Claude Code。显式删掉(不是让 sanitize 缺省丢弃):调用方可能把读出来的整条 server 原样回传。
      delete clean.origin;
      if (idx >= 0) list[idx] = clean; else list.push(clean);
      // 显式(再)导入覆盖撤销 —— 与 import-folder / import-config/apply 同语义。
      for (let i = dismissed.length - 1; i >= 0; i--) if (dismissed[i] === wantId) dismissed.splice(i, 1);
    } else {
      return { abort: { ok: false, status: 400, error: 'operation 必须是 upsert、remove 或 set-enabled' } };
    }
    config.externalMcpServers = list;
    config.dismissedMcpIds = dismissed;
    return {};
  });
  if (!r.ok) return r.value;
  const next = r.config;
  invalidateMcpRuntime(wantId); // 杀活客户端 / 清失败冷却:停用后不再重连,启用后可立即重测
  await generateMcpConfig(next.mcpCommandMode).catch(() => {}); // 与 import 路径一致:启用集变化后再生成 .mcp.json
  const shadowKind = op === 'remove' ? 'remove' : (op === 'set-enabled' && !on ? 'disable' : '');
  const warning = (shadowKind && scanMcpDropIns().some(d => d && d.id === wantId)) ? MCP_DROPIN_SHADOW_WARNING[shadowKind] : null;
  if (op === 'remove') logEvent({ kind: 'mcp_connector_delete', id: wantId });
  else if (op === 'set-enabled') logEvent({ kind: 'mcp_connector_toggle', id: wantId, enabled: on });
  else logEvent({ kind: 'mcp_connector_upsert', id: wantId });
  return { ok: true, op, id: wantId, config: next, removed: op === 'remove',
    server: (next.externalMcpServers || []).find(s => s && s.id === wantId) || null,
    ...(warning ? { warning } : {}) };
}

// 工具面入口(mcp_configure)。117n-M2 起只剩「工具形状 + set-browser」,连接器三操作全部转
// mutateMcpConnector。第二个参数 currentConfig 保留在签名里只为兼容既有调用点(12-tool-dispatch),
// 【有意不再使用】:落盘前的读必须发生在 mutateConfig 的锁内,回合起点的快照到这里已可能陈旧。
// 把 args 字符串按 shell 口径切开(空白分隔,单/双引号成组,不处理反斜杠转义 —— Windows 路径里全是反斜杠)。
function splitMcpArgsString(text) {
  const out = [];
  const re = /"([^"]*)"|'([^']*)'|(\S+)/g;
  let m;
  while ((m = re.exec(String(text || '')))) out.push(m[1] != null ? m[1] : (m[2] != null ? m[2] : m[3]));
  return out;
}
// 外部 MCP 连接器 id 的合法形(与 upsert 落盘文件名/CLI 键名兼容;含空格/斜杠/.. 的 id 会让 .mcp.json 键与路径判断出岔子)。
const MCP_CONNECTOR_ID_RE = /^[A-Za-z0-9_.-]{1,64}$/;
// set-browser 的入参校验与合并 —— 修前对非法输入一律静默改写成默认值还回 ok:true(mode:'bogus' 存成 system、
// 缺 browser 对象把自定义的 executable/cdpUrl 重置、cdpUrl:'not a url' 原样落盘、custom 没有 executable 也存)。
// 现在:只改显式给出的字段(其余沿用磁盘上的现值);任何一项不合法就整次拒绝并点名允许值。返回 { error } 或 { browser }。
function validateBrowserTargetPatch(raw, current) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw) || !Object.keys(raw).length) {
    return { error: `set-browser 需要 browser 对象:{mode: ${BROWSER_AUTOMATION_MODES.join('|')}, executable?, cdpUrl?}` };
  }
  const next = { ...(current || {}) };
  if (raw.mode !== undefined) {
    const mode = String(raw.mode).trim().toLowerCase();
    if (!BROWSER_AUTOMATION_MODES.includes(mode)) return { error: `browser.mode 无效:${JSON.stringify(raw.mode)};允许值 ${BROWSER_AUTOMATION_MODES.join(' / ')}` };
    next.mode = mode;
  }
  if (raw.executable !== undefined) {
    if (typeof raw.executable !== 'string') return { error: 'browser.executable 必须是字符串(浏览器可执行文件路径)' };
    next.executable = raw.executable.trim();
  }
  if (raw.cdpUrl !== undefined) {
    const url = typeof raw.cdpUrl === 'string' ? raw.cdpUrl.trim() : '';
    let ok = false;
    try { ok = /^(https?|wss?):$/.test(new URL(url).protocol); } catch { ok = false; }
    if (!ok) return { error: `browser.cdpUrl 不是合法地址:${JSON.stringify(raw.cdpUrl)};需要 http(s):// 或 ws(s):// 开头,如 http://127.0.0.1:9222` };
    next.cdpUrl = url;
  }
  if (next.mode === 'custom' && !String(next.executable || '').trim()) return { error: "browser.mode 为 custom 时必须同时给出 executable(浏览器可执行文件的完整路径)" };
  return { browser: { mode: next.mode, executable: next.executable, cdpUrl: next.cdpUrl } };
}

// 工具面入口(mcp_configure)。117n-M2 起只剩「工具形状 + set-browser」,连接器三操作全部转
// mutateMcpConnector。第二个参数 currentConfig 保留在签名里只为兼容既有调用点(12-tool-dispatch),
// 【有意不再使用】:落盘前的读必须发生在 mutateConfig 的锁内,回合起点的快照到这里已可能陈旧。
async function configureMcpFromTool(args, currentConfig) {
  void currentConfig; // 见上:有意不用
  const operation = String(args && args.operation || '').trim();
  if (operation === 'set-browser') {
    // 校验与合并都在 mutateConfig 的锁内、基于锁内刚读到的那份现值(同连接器写入的纪律)。
    const r = await mutateConfig(async (config) => {
      const checked = validateBrowserTargetPatch(args && args.browser, config.browserAutomation);
      if (checked.error) return { abort: { ok: false, operation, error: checked.error } };
      config.browserAutomation = checked.browser;
      return {};
    });
    if (!r.ok) return r.value;
    invalidateMcpRuntime('ai-computer-control');
    return { ok: true, operation, browserAutomation: r.config.browserAutomation,
      note: '浏览器目标已保存；当前桌面 MCP 连接已刷新，下一次工具发现会按新策略启动。' };
  }
  const id = String(args && (args.id || (args.server && args.server.id)) || '').trim();
  if (!id || id === 'ai-computer-control') return { ok: false, error: '外部 MCP 需要合法 id；内置 ai-computer-control 只能用 set-browser 调整浏览器目标。' };
  if (operation !== 'upsert' && operation !== 'remove' && operation !== 'set-enabled') {
    return { ok: false, error: 'operation 必须是 upsert、remove、set-enabled 或 set-browser' };
  }
  let server = (args && args.server) || null;
  if (operation === 'upsert') {
    // 新建/改写的入口形状校验(remove / set-enabled 不卡:历史导入的 id 可能带别的字符,照样要能停用/删除)。
    if (!MCP_CONNECTOR_ID_RE.test(id)) return { ok: false, operation, id, error: 'MCP id 只能含字母、数字、下划线、点和连字符(1-64 个字符),不能含空格或斜杠。' };
    if (server !== null && (typeof server !== 'object' || Array.isArray(server))) return { ok: false, operation, id, error: 'server 必须是对象:{command, args[], cwd, env{}, enabled},远程连接器用 {transport, url}' };
    if (server && server.args !== undefined) {
      // args 给成一个字符串(模型常这么写)修前被静默存成 [];按 shell 口径切开,数组里混进非字符串则拒绝。
      if (typeof server.args === 'string') server = { ...server, args: splitMcpArgsString(server.args) };
      else if (!Array.isArray(server.args) || server.args.some(a => typeof a !== 'string')) return { ok: false, operation, id, error: 'server.args 必须是字符串数组(或一个按空格切分的字符串)。' };
    }
  }
  const r = await mutateMcpConnector({ op: operation, id, enabled: args && args.enabled, server });
  if (!r.ok) return { ok: false, operation, id, error: r.error };
  const saved = r.server;
  return { ok: true, operation, id, removed: r.removed, ...(r.warning ? { warning: r.warning } : {}),
    server: saved ? { id: saved.id, label: saved.label, command: saved.command, args: mcpArgsForDisplay(saved.args), cwd: saved.cwd, enabled: saved.enabled, envKeys: Object.keys(saved.env || {}) } : null,   // 107-S0b:args 显示脱敏
    note: '配置已原子保存并刷新工具目录；若工具仍不可用，请读取 MCP 列表与启动诊断。' };
}

// 审计 A14:桥接子进程在一次调用中途退出(崩溃 / 被外部杀 / OOM)。返回给模型的错误说明是哪个工具、哪个组件、退出码、
// 是否会自动重启以及重试口径 —— 修前只有「mcp child exited」,模型无从判断是自己的参数错还是环境坏了。
function mcpChildExitResult(client, toolName, info) {
  const id = client && client.id ? String(client.id) : 'mcp';
  const isDesktop = id === 'ai-computer-control';
  const who = isDesktop ? `desktop control component (${id})` : `MCP server '${id}'`;
  const how = `code ${info && info.code != null ? info.code : 'null'}${info && info.signal ? `, signal ${info.signal}` : ''}`;
  const tail = info && info.stderrTail ? ` Last stderr: ${info.stderrTail.replace(/\s+/g, ' ').slice(-300)}` : '';
  return {
    ok: false, code: 'mcp-child-exited', retryable: true, serverId: id, tool: String(toolName || ''),
    error: `tool '${toolName}' was interrupted: the ${who} process exited unexpectedly (${how}). It restarts automatically on the next call: retry the call once; any state it held in memory (open browser pages, recording, thinking chain) is lost, and if the same call kills it again, stop retrying and report the failure.${tail}`,
  };
}
// 审计 A14:getBridgedClient 返回 null 时的说明 —— 带上上一次启动失败的原因与冷却剩余,而不是一句「not available」。
function bridgedServerUnavailableMessage(serverId) {
  const base = `bridged MCP server '${serverId}' is not available`;
  const fail = mcpClientFailures.get(serverId);
  if (!fail) return `${base} (it could not be started or has no launch command configured)`;
  const leftSec = Math.max(0, Math.ceil((MCP_FAILURE_COOLDOWN_MS - (Date.now() - fail.at)) / 1000));
  return `${base}: the last start failed: ${String(fail.error || 'unknown error').slice(0, 300)}. ${leftSec > 0 ? `It will be retried automatically in about ${leftSec}s.` : 'It will be retried on the next call.'} Use another tool meanwhile.`;
}
// Get (lazily starting) a live client for one server entry, or null if it can't start. Caches failures.
// 49c:按 entry.transport 选客户端类 —— sse/http 走 McpHttpClient(无进程,远程连接),其余走 stdio。
async function getMcpClient(entry) {
  reconcileMcpEntryFingerprint(entry);
  const existing = mcpClients.get(entry.id);
  if (existing && !existing.dead) return existing;
  if (existing && existing.dead) mcpClients.delete(entry.id);
  const fail = mcpClientFailures.get(entry.id);
  if (fail && (Date.now() - fail.at) < MCP_FAILURE_COOLDOWN_MS) return null;   // in cooldown
  // 55a: 并发互斥 -- 同一 entry.id 的并发 getMcpClient 复用同一个 start Promise。probeMcpConnector 的
  // start race-timeout(可低至 2s)先于 getMcpClient 的 8s rpc 超时返回,若无互斥,第二次 probe 会 spawn
  // 第二个子进程;两个都成功时第一个子进程成孤儿(child.unref 只防阻止退出不杀进程,持有句柄/端口/锁)。
  if (mcpClientPending.has(entry.id)) return mcpClientPending.get(entry.id);
  const gen = (mcpClientGen.get(entry.id) || 0);
  const p = (async () => {
    const client = (entry.transport === 'sse' || entry.transport === 'http') ? new McpHttpClient(entry) : new McpStdioClient(entry);
    mcpStartingClients.set(entry.id, client);
    try {
      await client.start();
      // 启动期间被 invalidateMcpRuntime 作废(配置变更/toggle):丢弃结果,不登记为活客户端,也不写失败冷却。
      if ((mcpClientGen.get(entry.id) || 0) !== gen) { try { client.kill(); } catch { /* ignore */ } return null; }
      mcpClients.set(entry.id, client);
      mcpClientFailures.delete(entry.id);
      return client;
    } catch (e) {
      // 被 invalidate kill 的在途启动:不写冷却(用户期望 toggle-on 后可立即重连)。
      if ((mcpClientGen.get(entry.id) || 0) !== gen) return null;
      mcpClientFailures.set(entry.id, { at: Date.now(), error: (e && e.message) || String(e) });
      logEvent({ kind: 'mcp_bridge_start_failed', serverId: entry.id, error: (e && e.message) || String(e) });
      return null;
    } finally {
      if (mcpStartingClients.get(entry.id) === client) mcpStartingClients.delete(entry.id);
    }
  })();
  mcpClientPending.set(entry.id, p);
  // 只摘自己那一个:invalidate 之后别人可能已经放进了新的在途 Promise。
  try { return await p; } finally { if (mcpClientPending.get(entry.id) === p) mcpClientPending.delete(entry.id); }
}

// Kill every live bridged client (called on process exit / cleanup).
function killAllMcpClients() {
  for (const [, c] of mcpClients) { try { c.kill(); } catch { /* ignore */ } }
  mcpClients.clear();
  // hunt2-mcp:还在握手的也要杀 —— 修前退出时它们不在 mcpClients 里,子进程成孤儿(unref 过,不拦退出)。
  for (const [, c] of mcpStartingClients) { try { c.kill(); } catch { /* ignore */ } }
  mcpStartingClients.clear();
}

// 47b:桥客户端获取的统一入口 —— 活则直给;死/缺则按 config 的服务器条目经 getMcpClient 惰性重 spawn。
// 此前三处分发点(12-tool-dispatch / 08 / 09)直接 mcpClients.get,47b 超时杀客户端后永远 'not available'
// 无法自愈;统一走这里后,"超时杀 → 下次调用自动重连"的契约闭环。
async function getBridgedClient(serverId, config) {
  const live = mcpClients.get(serverId);
  if (live && !live.dead) return live;
  const list = resolveExternalMcpServers(config || await readConfig());
  const entry = (list || []).find(s => s.id === serverId);
  if (!entry || (!entry.command && !entry.url)) return null; // 49c:远程条目无 command,认 url
  return getMcpClient(entry);
}

// Stable, reversible-ish server-id sanitizer for the bridged tool-name prefix. Non [A-Za-z0-9_] -> _.
function sanitizeServerId(id) { return String(id || '').replace(/[^A-Za-z0-9_]/g, '_'); }
// hunt2-mcp:provider 的函数名只收 ^[a-zA-Z0-9_-]{1,64}$。修前前缀冲突(my-srv 与 my_srv 都成 my_srv)时后到的
// 服务器工具被静默丢掉;工具名里带 . / 空格或总长超 64 的,整批请求被 provider 400 拒掉。
// 前缀冲突:先到者(desktop 在最前)保留原前缀,后到者加 id 的短哈希;名字非法字符转 _,超长截断并补哈希保唯一。
function mcpShortHash(text) { return crypto.createHash('sha1').update(String(text), 'utf8').digest('hex').slice(0, 6); }
function bridgedToolFunctionName(prefix, toolName) {
  const raw = `${prefix}__${String(toolName).replace(/[^A-Za-z0-9_-]/g, '_')}`;
  if (raw.length <= 64) return raw;
  return raw.slice(0, 57) + '_' + mcpShortHash(`${prefix}__${toolName}`);
}

// v0.7d line 2: collect bridged tools for THIS turn (once). Returns { tools:[openai fn schema], route }.
// route maps bridgedName -> { serverId, toolName }. Any server that fails to start/list is skipped;
// never throws, never blocks the main flow.
let bridgedCatalogCache = { key: '', expiresAt: 0, value: null };
// 整体扫描时限:getCapabilities 冷启动(网络探测 + 全量 MCP 扫描)不能无限期阻塞 —— 本机 ~/.claude.json
// 可能导入 10+ 个 MCP(含挂起桩 stdio-hang),串行 listTools 实测可达 18.9s,远超 /api/capabilities 的
// HTTP 超时(e2e 8s)。到点返回已收集的部分结果,不因单个慢/挂 MCP 拖死整次探测。
// 单个 MCP 的握手预算:start() 内部 initialize + tools/list 各 8s 上限,挂起桩(stdio-hang)串行可吃满 16s。
// 扫描期对每个 entry 用该预算 race,超时即跳过该 MCP —— 扫描不被单桩拖死,慢 MCP 的下次调用再补(有 60s 冷却)。
const BRIDGED_ENTRY_START_TIMEOUT_MS = Number(process.env.WCW_BRIDGED_ENTRY_START_TIMEOUT_MS) || 3500;   // env 仅为测试缝(unit/bridged-catalog-incomplete)
// 整体扫描时限:getCapabilities 冷启动(网络探测 + 全量 MCP 扫描)不能无限期阻塞 —— 本机 ~/.claude.json
// 可能导入 10+ 个 MCP,串行扫描实测可达 18.9s,远超 /api/capabilities 的 HTTP 超时(e2e 8s)。
// 到点返回已收集的部分结果,不因单个慢/挂 MCP 拖死整次探测。
const BRIDGED_CATALOG_SCAN_TIMEOUT_MS = 8000;

async function collectBridgedTools(config, force = false) {
  if (!config || config.bridgeExternalToolsToProvider === false) return { tools: [], route: {} };
  const entries = resolveExternalMcpServers(config);
  const cacheKey = JSON.stringify(entries.map(e => [e.id, mcpEntryFingerprint(e)]));   // 过滤表 / 超时 / 头也算目录变化
  if (!force && bridgedCatalogCache.value && bridgedCatalogCache.key === cacheKey && Date.now() < bridgedCatalogCache.expiresAt) {
    return bridgedCatalogCache.value;
  }
  // 残缺目录不进长缓存(审计 A3)之后,启动期一阵并发请求(状态轮询 / 能力探测 / 首回合)会各自重扫、各自再等一轮
  // 启动竞速:同一 key 的扫描在飞时直接共用它;force 照旧另起。
  if (!force && bridgedCatalogInflight && bridgedCatalogInflight.key === cacheKey) return bridgedCatalogInflight.promise;
  const promise = collectBridgedToolsScan(config, entries, cacheKey);
  if (!force) bridgedCatalogInflight = { key: cacheKey, promise };
  try { return await promise; }
  finally { if (bridgedCatalogInflight && bridgedCatalogInflight.promise === promise) bridgedCatalogInflight = null; }
}
let bridgedCatalogInflight = null;   // { key, promise }:同一 key 的目录扫描在飞时共用
// 残缺目录也短暂缓存 1 s:吸收紧挨着的一串调用,又不耽误慢起来的 MCP 在下一次(>1 s 后)被补进目录。
const BRIDGED_CATALOG_INCOMPLETE_TTL_MS = 1000;
async function collectBridgedToolsScan(config, entries, cacheKey) {
  const tools = [];
  const route = {};
  let incomplete = false;   // 有 entry 没在预算内起来 / 起不来:这一次的目录是残缺的
  const scan = (async () => {
    // 并行收集每个 entry 的 client + tools —— N 个 MCP 同时启动,单个慢/挂不再拖慢其它(每 entry 有独立握手预算)。
    const collected = await Promise.all(entries.map(async (entry) => {
      let client = null;
      try {
        // 每 entry 的 getMcpClient(内含 start 握手)跑在独立 race 里:挂起桩最多占自身预算,不影响并行中的其余 MCP。
        client = await Promise.race([
          getMcpClient(entry),
          new Promise(res => setTimeout(() => res('__timeout__'), BRIDGED_ENTRY_START_TIMEOUT_MS)),
        ]);
      } catch { client = null; }
      if (!client || client === '__timeout__') { incomplete = true; return null; }   // 审计 A3:没扫全的目录不缓存
      let list;
      try { list = await client.listTools(); } catch { list = []; }
      return { entry, list: Array.isArray(list) ? list : [] };
    }));
    const prefixOwner = new Map();   // 前缀 -> 占用它的 serverId
    for (const item of collected) {
      if (!item) continue;
      const { entry, list } = item;
      let prefix = sanitizeServerId(entry.id);
      if (prefixOwner.has(prefix) && prefixOwner.get(prefix) !== entry.id) {
        const taken = prefix;
        prefix = `${prefix}_${mcpShortHash(entry.id)}`;
        logEvent({ kind: 'mcp_bridge_prefix_collision', serverId: entry.id, other: prefixOwner.get(taken), prefix });
      }
      prefixOwner.set(prefix, entry.id);
      for (const t of list) {
        if (!t || typeof t.name !== 'string' || !t.name) continue;
        if (!mcpToolAllowed(entry, t.name)) continue;   // 条目 enabledTools / disabledTools
        const bridgedName = bridgedToolFunctionName(prefix, t.name);
        // Never overwrite an already-claimed name (defensive; prefixes make collisions unlikely).
        if (route[bridgedName]) continue;
        route[bridgedName] = { serverId: entry.id, toolName: t.name };
        tools.push({
          type: 'function',
          function: {
            name: bridgedName,
            description: t.description || t.name,
            parameters: (t.inputSchema && typeof t.inputSchema === 'object') ? t.inputSchema : { type: 'object', properties: {} },
          },
        });
      }
    }
  })();
  // 整体时限兜底:超时后返回当前已收集的部分(可能缺慢 MCP 的工具,但探测本身不再被拖死)。
  let scanDone = false;
  try {
    await Promise.race([scan.then(() => { scanDone = true; }), new Promise(res => setTimeout(res, BRIDGED_CATALOG_SCAN_TIMEOUT_MS))]);
  } catch { /* 并行收集失败不阻断 —— 返回已收集部分 */ }
  if (!scanDone) incomplete = true;
  const value = { tools, route };
  // 审计 A3:桌面组件(ACC)冷启动可能赶不上 3.5 s 的启动竞速。修前把「缺了它」的目录照常缓存 60 s,首几个回合模型看不到任何桌面
  // 工具、tool_search 也搜不到。现在残缺目录【不缓存】:下一次调用重新扫(慢的那个 start 仍在后台跑,getMcpClient 的
  // 待决互斥保证不会重复起进程;真起不来的有 60 s 失败冷却,重扫是廉价的 null)。
  if (incomplete) {
    bridgedCatalogCache = { key: cacheKey, expiresAt: Date.now() + BRIDGED_CATALOG_INCOMPLETE_TTL_MS, value };
    return value;
  }
  bridgedCatalogCache = {
    key: cacheKey,
    expiresAt: Date.now() + Math.max(5000, Number(config.toolCatalogCacheTtlMs) || 60000),
    value,
  };
  return value;
}

// ── 第55波 EC-C 55a: MCP 运维闭环 -- 统一读模型 + 健康探针 + 错误归类 + 兼容矩阵 ──────────
// 目标(roadmap EC-C):让非程序员不编辑 JSON 也能判断「接上了没有、为什么不可用、怎样恢复」。
// 本批为后端地基(路由在 13b,前端在 55c):
//  - MCP_COMPAT_MATRIX:在连接前说明 stdio/sse/http 各 transport 的能力与局限(退出条件#4)。
//  - classifyMcpError:把裸错误归一为 7 类(startup/network/auth/protocol/tool_registration/timeout/
//    security),而非统一「连接失败」(退出条件#3)。
//  - probeMcpConnector:对单连接器做一次显式健康探测,复用 getMcpClient(活则直给、死则重 spawn),
//    绝不抛,返回结构化 status。start 阶段用 probe 超时竞速(避免 8s rpc 超时拖慢用户重测)。
//  - buildMcpConnectorInventory:合并 desktop/config/drop-in 三源为带 source/transport/commandOrUrl/
//    enabled/builtIn/capabilities 的统一清单(含 disabled 条目,UI 需展示并允许启用);env 值掩码,
//    不返回可执行命令串供前端拼写(配置变更走 import/toggle 路由 + token + 审计,退出条件#5)。
const MCP_COMPAT_MATRIX = {
  stdio: {
    transport: 'stdio',
    capabilities: ['initialize', 'tools/list', 'tools/call', 'notifications/cancelled'],
    limitations: ['无服务端推送 tools/list_changed(工具列表变化需重新 tools/list 探测)'],
    supportsListChanged: false,
  },
  http: {
    transport: 'http (streamable-HTTP 2025-03-26)',
    capabilities: ['initialize', 'tools/list', 'tools/call', 'Mcp-Session-Id 会话', 'tools/list_changed 推送'],
    limitations: ['需可访问 URL;密钥引用连接时才展开(不落盘明文)'],
    supportsListChanged: true,
  },
  sse: {
    transport: 'sse (legacy 2024-11-05)',
    capabilities: ['initialize', 'tools/list', 'tools/call', 'tools/list_changed 推送'],
    limitations: ['legacy transport;新建连接器优先 streamable-HTTP'],
    supportsListChanged: true,
  },
};

// 把裸错误归一为 EC-C 退出条件要求的 7 类。顺序敏感:先匹配更具体的类别(auth/startup/network/
// timeout/security/tool_registration 在 protocol 之前,因为握手失败往往携带更具体的根因词)。
function classifyMcpError(err, entry) {
  const raw = (err && err.message) ? err.message : String(err == null ? '' : err);
  const msg = raw.toLowerCase();
  const transport = entry && entry.transport;
  // auth:HTTP 401/403(远程 transport 鉴权失败)。锚定 HTTP 上下文(HTTP/状态/status/code + 数字),
  // 避免误匹配端口号(如 ECONNREFUSED 127.0.0.1:401 -> 应归 network,非 auth)。
  if (/(?:HTTP|状态|status|code)\s*(401|403)\b|unauthorized|forbidden/i.test(msg)) return { category: 'auth', message: raw };
  // startup:spawn 失败 / 子进程退出 / ENOENT / not running(stdio 进程层)
  if (/spawn failed|enoent|exited|not running|child error/.test(msg)) return { category: 'startup', message: raw };
  // network:连接层(ECONNREFUSED/ENOTFOUND/ETIMEDOUT/ECONNRESET/bad url/EPIPE/socket hang up)
  if (/econnrefused|enotfound|etimedout|econnreset|eai_again|bad url|epipe|connect econn|socket hang up/.test(msg)) return { category: 'network', message: raw };
  // cancelled:用户 steer 中断/显式取消(优先于 timeout,防误归超时)
  if (/cancelled|canceled|aborted by user steer/.test(msg)) return { category: 'cancelled', message: raw };
  // timeout:rpc/请求/探针超时
  if (/timed out|timeout/.test(msg)) return { category: 'timeout', message: raw };
  // security:SSRF / sanitize 拒绝 / 非 http(s) url
  if (/ssrf|内网|sanitize|invalid entry|non-http|ftp:/.test(msg)) return { category: 'security', message: raw };
  // tool_registration:tools/list 失败或空目录
  if (/tools\/list|no tools|empty tools/.test(msg)) return { category: 'tool_registration', message: raw };
  // protocol:握手失败 / 非 MCP 响应 / JSON-RPC 错误 / initialize 被拒
  if (/handshake failed|non-mcp|bad json|protocol|initialize|mcp error|parse|json-rpc|无匹配 id/.test(msg)) return { category: 'protocol', message: raw };
  return { category: 'unknown', message: raw };
}

// 对单连接器做一次显式健康探测(用户「为什么不可用」排查 / 清单 ?probe=1)。
// 复用 getMcpClient(活则直给,死则按 config 条目重 spawn;受 MCP_FAILURE_COOLDOWN_MS 冷却约束 ->
// 冷却中返回存储的失败归类)。start 阶段用 probe 超时竞速,避免 stdio 8s rpc 超时拖慢用户重测。
// 绝不抛;返回 {id, status:'ok'|'degraded'|'failed', category?, message?, toolCount?, latencyMs, ...}。
async function probeMcpConnector(entry, opts = {}) {
  const startedAt = Date.now();
  const probedAt = new Date().toISOString();
  const timeoutMs = Math.max(2000, Number(opts && opts.timeoutMs) || 10000);
  if (!entry || (!entry.id && !entry.command && !entry.url)) {
    return { id: null, status: 'failed', category: 'startup', message: 'invalid entry', latencyMs: 0, probedAt };
  }
  reconcileMcpEntryFingerprint(entry);   // 配置改过(同 id)-> 旧客户端 / 旧冷却作废,按新条目重测
  let client = mcpClients.get(entry.id);
  // 已经活着的客户端:下面真发一次 tools/list(hunt2-mcp:修前读握手时缓存的目录,卡死的服务器也报 ok)。
  const wasLive = Boolean(client && !client.dead);
  if (!client || client.dead) {
    try {
      client = await Promise.race([
        getMcpClient(entry),
        new Promise((_, reject) => setTimeout(() => reject(new Error('mcp probe timed out (start)')), timeoutMs)),
      ]);
    } catch (e) {
      const cls = classifyMcpError(e, entry);
      return { id: entry.id, status: 'failed', ...cls, latencyMs: Date.now() - startedAt, probedAt };
    }
  }
  if (!client) {
    // getMcpClient 返回 null:冷却中或 start 失败已存。回放存储的失败归类。
    const fail = mcpClientFailures.get(entry.id);
    const err = fail ? new Error(fail.error) : new Error('mcp client not available');
    const cls = classifyMcpError(err, entry);
    return { id: entry.id, status: 'failed', ...cls, latencyMs: Date.now() - startedAt, probedAt };
  }
  try {
    let probeTimer = null;
    const tools = await Promise.race([
      Promise.resolve(wasLive && typeof client.refreshTools === 'function' ? client.refreshTools(timeoutMs) : client.listTools()),
      new Promise((_, reject) => { probeTimer = setTimeout(() => reject(new Error('mcp tools/list timed out')), timeoutMs); }),
    ]).finally(() => clearTimeout(probeTimer));
    const toolCount = Array.isArray(tools) ? tools.length : 0;
    return {
      id: entry.id,
      status: toolCount > 0 ? 'ok' : 'degraded',
      toolCount,
      latencyMs: Date.now() - startedAt,
      serverInfo: client.serverInfo || null,
      transport: entry.transport || 'stdio',
      probedAt,
    };
  } catch (e) {
    const cls = classifyMcpError(e, entry);
    return { id: entry.id, status: 'failed', ...cls, latencyMs: Date.now() - startedAt, probedAt };
  }
}

// 107-S2(46 号文 §5 ⑦b L3):URL 查询串里的凭据。`?api_key=…`／`?token=…` 这类把密钥写进地址的端点
// 到处都有(远程 MCP 清单、自建网关),而 GET /api/status 是 open 档 —— 本机任何进程一个 curl 就读到。
// 口径与 providers[].extraHeaders 那一格相同【按名字挑】,不按值猜:URL 的查询名是一小撮公认的凭据名
// (api_key／token／secret／password／auth／key／sig／signature／credential／access_token),把整个查询串
// 都遮了会连 ?model=、?version= 这类识别端点必需的信息一起遮掉,而识别端点正是保留 scheme/host/path
// 的理由。值走同一条 maskKey(••••<末4>),所以「回传的掩码 = 我们刚下发的那一串」可以逐字节比出来。
const SENSITIVE_URL_PARAM_RE = /^(?:x-)?(?:api[-_]?key|key|access[-_]?token|token|secret|password|passwd|auth|authorization|credential|sig|signature|session)$/i;
function isSensitiveUrlParamName(name) { return typeof name === 'string' && SENSITIVE_URL_PARAM_RE.test(name.trim()); }
// 只在【真有要遮的东西】时才重写这个串:没有凭据参数就原样返回,一个字节都不动 —— 否则
// `?a=1&b=2` 会被重新拼装,而这个返回值是要被原样回传、再逐字节比对的往返基准(见 05 的
// restoreDisplayUrl),任何归一化都会把「用户没动过这个框」误判成「用户换了端点」。
function maskUrlQueryCredentials(urlStr) {
  const s = String(urlStr || '');
  const hashAt = s.indexOf('#');
  const head = hashAt >= 0 ? s.slice(0, hashAt) : s;
  const tail = hashAt >= 0 ? s.slice(hashAt) : '';
  const queryAt = head.indexOf('?');
  if (queryAt < 0) return s;
  const prefix = head.slice(0, queryAt + 1);
  let changed = false;
  const pairs = head.slice(queryAt + 1).split('&').map(pair => {
    const eq = pair.indexOf('=');
    if (eq <= 0) return pair;
    const name = pair.slice(0, eq), value = pair.slice(eq + 1);
    if (!value || !isSensitiveUrlParamName(name)) return pair;
    changed = true;
    return name + '=' + maskKey(value);   // 值仍是【原编码形态】的末四位:掩码可逐字节对回去
  });
  return changed ? prefix + pairs.join('&') + tail : s;
}
// 55a: 远程条目 URL 展示脱敏 -- 剥离 userinfo(http://user:pass@host -> http://host),防凭据经
// token 保护的路由返回给前端(浏览器扩展/日志/共享机器可截获)。解析失败则原样返回(不阻断展示)。
// 107-S2:同一条规则再加查询串里的凭据(上面的 maskUrlQueryCredentials),并成为全仓【唯一】的
// 「URL 给人看之前怎么脱敏」判据 —— maskSecrets(providers 的 baseUrl／audioBaseUrl／extraBaseUrls、
// searchBackend.baseUrl、modelsApiBase)、maskExternalMcpServerForDisplay(远程 url)、safeMcpInventory
// (mcp_list)全部调它,不另写第二套。URL 能解析但没有 userinfo 时【不重建】(u.toString() 会给
// `http://host` 补出尾斜杠,那会让「原样回传」看起来像改了端点)。
function safeUrlForDisplay(urlStr) {
  const raw = String(urlStr || '');
  let stripped = raw;
  try { const u = new URL(raw); if (u.username || u.password) { u.username = ''; u.password = ''; stripped = u.toString(); } }
  catch { /* 非法/相对 URL:不重建,只做下面的查询串脱敏(与修前「解析失败原样返回」同一个不阻断口径) */ }
  return maskUrlQueryCredentials(stripped);
}

// 合并 desktop/config/drop-in 三源为统一读模型。与 resolveExternalMcpServers 的关键差异:本函数
// 【包含 disabled 条目】(UI 需展示已停用的连接器并允许启用),并附 source/transport/commandOrUrl/
// enabled/builtIn/capabilities。probe 时复用 resolveExternalMcpServers 取真实 entry(含完整 env,无漂移)。
// env 值经 maskKey 掩码(防 token 类泄漏);command/url 不掩(配置面非密钥,UI 需识别连接器)。
async function buildMcpConnectorInventory(config, opts = {}) {
  // 39 号文:本函数下面两处(resolveExternalMcpServers 与第 1 段的 autodetect)在冷缓存时会同步探针。
  // 它是 async,所以先等那趟异步预热 —— 缓存热时零开销,冷时也不再把事件循环钉住。
  await ensureDesktopMcpWarm(config);
  const doProbe = !!(opts && opts.probe);
  const probeTimeoutMs = Math.max(2000, Number(opts && opts.probeTimeoutMs) || 10000);
  const resolvedById = new Map();
  if (doProbe) {
    for (const e of resolveExternalMcpServers(config)) resolvedById.set(e.id, e);
  }
  const out = [];
  const addItem = (spec) => {
    const transport = (spec.transport === 'sse' || spec.transport === 'http') ? spec.transport : 'stdio';
    const cap = MCP_COMPAT_MATRIX[transport] || MCP_COMPAT_MATRIX.stdio;
    const maskedEnv = {};
    for (const [k, v] of Object.entries(spec.env || {})) maskedEnv[k] = maskKey(String(v));
    out.push({
      id: spec.id,
      label: spec.label || spec.id,
      source: spec.source,
      builtIn: !!spec.builtIn,
      transport,
      commandOrUrl: transport === 'stdio' ? String(spec.command || '') : safeUrlForDisplay(spec.url),
      enabled: spec.enabled !== false,
      capabilities: cap,
      envKeys: Object.keys(spec.env || {}),
      env: maskedEnv,
      argsCount: Array.isArray(spec.args) ? spec.args.length : 0,
      cwd: spec.cwd || '',
      health: null,
    });
  };
  // 1. desktop MCP(ai-computer-control,工作台签名能力 -- 内置)
  const dm = config && config.desktopMcp;
  if (dm) {
    let command = String(dm.command || '').trim();
    let args = Array.isArray(dm.args) ? dm.args.slice() : [];
    let cwd = String(dm.cwd || '').trim() || undefined;
    let env = {};
    if (command) {
      env = { PYTHONUTF8: '1' };
    } else if (dm.enabled !== false && dm.autodetect) {
      // 55a: 仅在启用时 autodetect(detectDesktopMcp 内部 spawnSync 最多 5s,禁用时不应阻塞 GET 清单)。
      const det = detectDesktopMcp();
      if (det) { command = det.command; args = det.args; cwd = det.cwd; env = det.env || {}; }
    }
    if (command) {
      const browser = (config && config.browserAutomation) || {};
      env = { ...env,
        ACC_BROWSER_MODE: String(browser.mode || 'system'),
        ACC_BROWSER_EXECUTABLE: String(browser.executable || ''),
        ACC_BROWSER_CDP_URL: String(browser.cdpUrl || 'http://127.0.0.1:9222'),
      };
      addItem({ id: 'ai-computer-control', label: '桌面控制 (ai-computer-control)', source: 'desktop', builtIn: true, transport: 'stdio', command, args, cwd, env, enabled: dm.enabled !== false });
    }
  }
  // 2. config.externalMcpServers(用户连接器 -- 含 disabled)
  const ext = (config && Array.isArray(config.externalMcpServers)) ? config.externalMcpServers : [];
  for (const s of ext) {
    if (!s || !s.id) continue;
    const transport = (s.transport === 'sse' || s.transport === 'http') ? s.transport : 'stdio';
    if (transport !== 'stdio' && !s.url) continue;     // 远程条目缺 url 不入清单(与 resolveExternalMcpServers 一致)
    if (transport === 'stdio' && !s.command) continue;
    addItem({ id: s.id, label: s.label, source: 'config', builtIn: false, transport, command: s.command, url: s.url, args: s.args || [], cwd: s.cwd || '', env: s.env || {}, enabled: s.enabled !== false });
  }
  // 3. drop-in(repo/<dataRoot>/mcp/*/ 运行时扫描 -- 内置,不写回 config)
  if (!config || config.enableMcpDropIn !== false) {
    for (const d of scanMcpDropIns()) {
      if (out.some(o => o.id === d.id)) continue;       // config 显式条目优先(与 resolveExternalMcpServers 一致)
      const transport = (d.transport === 'sse' || d.transport === 'http') ? d.transport : 'stdio';
      if (transport !== 'stdio' && !d.url) continue;
      addItem({ id: d.id, label: d.label, source: 'drop-in', builtIn: true, transport, command: d.command, url: d.url, args: d.args || [], cwd: d.cwd || '', env: d.env || {}, enabled: true });
    }
  }
  // 4. ruyi-toolbox 登记的 MCP 组件(~/.ruyi-toolbox/components/,运行时合并、不写回 config;与 resolveExternalMcpServers 一致)
  for (const c of enabledToolboxComponents(config)) {
    if (c.kind !== 'mcp') continue;
    const id = 'toolbox-' + c.id;
    if (out.some(o => o.id === id)) continue;
    addItem({ id, label: c.name, source: 'toolbox', builtIn: true, transport: 'stdio', command: c.run.command, args: c.run.args, cwd: c.run.cwd, env: c.run.env, enabled: true });
  }
  if (doProbe) {
    for (const item of out) {
      if (!item.enabled) { item.health = { id: item.id, status: 'disabled', probedAt: new Date().toISOString() }; continue; }
      const realEntry = resolvedById.get(item.id);
      if (!realEntry) { item.health = { id: item.id, status: 'disabled', probedAt: new Date().toISOString() }; continue; }
      item.health = await probeMcpConnector(realEntry, { timeoutMs: probeTimeoutMs });
    }
  }
  return out;
}

// v1.4.1: 桥接工具带 `<serverId>__` 前缀(如 ai_computer_control__excel_read)。部分 provider 模型(实测 qwen)
// 会【丢掉前缀】直接调裸名 `excel_read` → 命不中 bridgedRoute → 落到内建兜底报「Unknown tool: excel_read」。
// 宽容解析:①精确前缀名优先;②内建工具名绝不被桥接遮蔽(返回 null 走内建路径);③裸名在所有桥接工具里
// 【唯一】命中某 toolName 时路由过去(≥2 个同名歧义则不猜、返回 null)。纯加法:精确前缀路径行为不变。
let _nativeToolNameSet = null;
function isNativeToolName(name) {
  if (!_nativeToolNameSet) { try { _nativeToolNameSet = new Set(MCP_TOOLS.map(t => t && t.name)); } catch { _nativeToolNameSet = new Set(); } }
  return _nativeToolNameSet.has(name);
}
function resolveBridge(bridgedRoute, name) {
  if (!name || !bridgedRoute) return null;
  const valid = value => value && typeof value === 'object' && Object.hasOwn(value, 'serverId') && typeof value.serverId === 'string' && value.serverId.length > 0 && Object.hasOwn(value, 'toolName') && typeof value.toolName === 'string' && value.toolName.length > 0;
  if (Object.hasOwn(bridgedRoute, name) && valid(bridgedRoute[name])) return bridgedRoute[name]; // ① 精确前缀名
  if (isNativeToolName(name)) return null;                 // ② 内建优先,不被桥接遮蔽
  let hit = null, count = 0;                               // ③ 裸名唯一命中桥接工具 → 容错路由
  for (const k of Object.keys(bridgedRoute)) {
    const r = bridgedRoute[k];
    if (valid(r) && r.toolName === name) { hit = r; if (++count > 1) return null; }
  }
  return count === 1 ? hit : null;
}

function stopSession(sessionId, reason = 'stopped') {
  const entry = activeChildren.get(sessionId);
  clearPendingPermissions(sessionId, `turn ${reason}`);
  clearPendingQuestions(sessionId, `turn ${reason}`);
  clearPendingPlans(sessionId, `turn ${reason}`); // v0.9-S5: unblock a paused plan-mode turn on abort/stop (reject semantics)
  if (!entry) return false;
  entry.state = reason;
  // Prefer the live ChildProcess handle; only fall back to taskkill by pid while the child is alive,
  // so we never force-kill a recycled PID.
  if (typeof entry.abort === 'function') {
    // Native (openai) engine: no child process — abort the in-flight fetch instead of taskkill.
    entry.exited = true;
    try { entry.abort(); } catch { /* ignore */ }
  } else if (!entry.exited && entry.child && entry.child.exitCode === null) {
    entry.exited = true;
    entry.cleanup = killChildTree(entry.child);
    if (entry.cleanup && entry.cleanup.incomplete && typeof entry.onEvent === 'function') {
      try { entry.onEvent({ type: 'stderr', text: '[子进程清理尚未确认完成]\n' }); } catch { /* observer closed */ }
    }
  }
  activeChildren.delete(sessionId);
  logEvent({ kind: 'turn_kill', sessionId, reason, ...(entry.cleanup ? { cleanupScope: entry.cleanup.scope, cleanupIncomplete: entry.cleanup.incomplete === true } : {}) });
  return true;
}

// --- F3: defensive, side-effect-free event parser. Maps one raw stream-json event to a list of
// normalized events {kind, ...}. Unknown shapes fall through to {kind:'unknown', raw}. Every stream
// feature (text, thinking, tool cards, usage) plugs into this single seam. ---
function deltaOf(streamEvent) {
  // Tolerate both {event:{delta}} and {event:{event:{delta}}} nestings seen across CLI versions.
  if (!streamEvent || typeof streamEvent !== 'object') return null;
  if (streamEvent.delta) return streamEvent;
  if (streamEvent.event) return deltaOf(streamEvent.event);
  return null;
}

const CLAUDE_TASK_NOTIFICATION_MAX_CHARS = 100000;
function decodeClaudeTaskXmlText(value) {
  return String(value || '')
    .replace(/&#(\d+);/g, (_, n) => {
      const code = Number(n);
      return Number.isFinite(code) && code >= 0 && code <= 0x10ffff ? String.fromCodePoint(code) : _;
    })
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => {
      const code = parseInt(n, 16);
      return Number.isFinite(code) && code >= 0 && code <= 0x10ffff ? String.fromCodePoint(code) : _;
    })
    .replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&quot;/gi, '"')
    .replace(/&apos;/gi, "'").replace(/&amp;/gi, '&');
}
function claudeTaskNotificationTag(text, tag, maxChars = CLAUDE_TASK_NOTIFICATION_MAX_CHARS) {
  const match = String(text || '').match(new RegExp(`<${tag}>\\s*([\\s\\S]*?)\\s*</${tag}>`, 'i'));
  if (!match) return '';
  return decodeClaudeTaskXmlText(match[1]).slice(0, Math.max(0, maxChars));
}
// Claude Code emits background-Agent completion as a string-valued user message rather than a
// tool_result block. Keep this parser deliberately narrow: only the documented task-notification
// envelope is accepted, tags are bounded, and the raw XML is never surfaced as an assistant reply.
function parseClaudeTaskNotification(content) {
  const text = typeof content === 'string' ? content : '';
  if (!/<task-notification(?:\s|>)/i.test(text)) return null;
  const status = claudeTaskNotificationTag(text, 'status', 80).trim().toLowerCase();
  const result = claudeTaskNotificationTag(text, 'result');
  const summary = claudeTaskNotificationTag(text, 'summary', 4000);
  const failed = /^(?:failed|error|cancelled|canceled|stopped|interrupted)$/.test(status);
  return {
    kind: 'subagent_notification',
    taskId: claudeTaskNotificationTag(text, 'task-id', 256).trim(),
    toolUseId: claudeTaskNotificationTag(text, 'tool-use-id', 256).trim(),
    outputFile: claudeTaskNotificationTag(text, 'output-file', 4096).trim(),
    status: status || (failed ? 'failed' : 'completed'),
    summary,
    note: claudeTaskNotificationTag(text, 'note', 4000),
    result: (result || summary).slice(0, CLAUDE_TASK_NOTIFICATION_MAX_CHARS),
    resultChars: (result || summary).length,
    resultTruncated: (result || summary).length > CLAUDE_TASK_NOTIFICATION_MAX_CHARS,
    failed,
  };
}
function parseClaudeEvent(evt) {
  const out = [];
  if (!evt || typeof evt !== 'object') return [{ kind: 'unknown', raw: evt }];
  const sid = evt.session_id || evt.sessionId;

  if (evt.type === 'system') {
    if (sid) out.push({ kind: 'init', sessionId: sid, subtype: evt.subtype });
    return out.length ? out : [{ kind: 'unknown', raw: evt }];
  }

  if (evt.type === 'stream_event' || evt.type === 'content_block_delta' || evt.event) {
    // Per-API-CALL usage (message_start carries the input breakdown; message_delta the output).
    // This is NOT the cumulative turn total, so it reflects true context-window occupancy.
    const inner = evt.event || evt;
    const mu = (inner && inner.message && inner.message.usage) || (inner && inner.usage);
    if (mu && typeof mu === 'object' && ('input_tokens' in mu || 'output_tokens' in mu || 'cache_read_input_tokens' in mu || 'cache_creation_input_tokens' in mu)) {
      out.push({ kind: 'msg_usage', usage: mu });
    }
    const holder = deltaOf(evt.event || evt);
    const delta = holder && holder.delta;
    if (delta) {
      const dt = delta.type || '';
      if (dt === 'text_delta' && typeof delta.text === 'string') {
        out.push({ kind: 'text', text: delta.text, partial: true, index: holder.index });
      } else if (/thinking|reasoning/i.test(dt) || typeof delta.thinking === 'string' || typeof delta.reasoning === 'string') {
        // Tolerate old (thinking_delta) + new adaptive/reasoning shapes and varying text fields.
        const t = [delta.thinking, delta.reasoning, delta.text].find(v => typeof v === 'string') || '';
        if (t) out.push({ kind: 'thinking', text: t, partial: true, index: holder.index });
      }
      // signature_delta and other unknown deltas are intentionally ignored
    }
    if (out.length) return out;
    // fall through to structural handling below if it wasn't a recognized delta
  }

  if (evt.type === 'assistant' && evt.message && Array.isArray(evt.message.content)) {
    if (evt.message.usage) out.push({ kind: 'msg_usage', usage: evt.message.usage }); // complete per-call usage
    for (const block of evt.message.content) {
      if (!block || typeof block !== 'object') continue;
      if (block.type === 'text' && typeof block.text === 'string') {
        out.push({ kind: 'text', text: block.text, partial: false });
      } else if (block.type === 'redacted_thinking') {
        out.push({ kind: 'thinking', text: '[redacted thinking]', partial: false, redacted: true });
      } else if (/thinking|reasoning/i.test(block.type || '') || typeof block.thinking === 'string' || typeof block.reasoning === 'string') {
        // Robust across thinking(enabled)/thinking(adaptive)/reasoning block variants + text field names.
        const t = [block.thinking, block.reasoning, block.text, (typeof block.content === 'string' ? block.content : null)].find(v => typeof v === 'string') || '';
        out.push({ kind: 'thinking', text: t, partial: false });
      } else if (block.type === 'tool_use') {
        out.push({ kind: 'tool_use', id: block.id, name: block.name, input: block.input });
      }
    }
    return out.length ? out : [{ kind: 'unknown', raw: evt }];
  }

  if (evt.type === 'user' && evt.message) {
    if (typeof evt.message.content === 'string') {
      const notification = parseClaudeTaskNotification(evt.message.content);
      if (notification) return [notification];
    } else if (Array.isArray(evt.message.content)) {
      for (const block of evt.message.content) {
        if (block && block.type === 'tool_result') {
          out.push({ kind: 'tool_result', id: block.tool_use_id, content: block.content, isError: Boolean(block.is_error) });
        }
      }
    }
    return out.length ? out : [{ kind: 'unknown', raw: evt }];
  }

  if (evt.type === 'result') {
    return [{
      kind: 'result',
      sessionId: sid,
      ok: evt.subtype === 'success' || (!evt.is_error && evt.subtype !== 'error'),
      subtype: evt.subtype,
      result: typeof evt.result === 'string' ? evt.result : undefined,
      usage: evt.usage,
      costUsd: evt.total_cost_usd ?? evt.cost_usd,
      durationMs: evt.duration_ms,
      numTurns: evt.num_turns,
    }];
  }

  return [{ kind: 'unknown', raw: evt }];
}

// v2.8: normalize Kimi Code's OpenAI-shaped stream-json rows into the internal event vocabulary.
// 架构还债批 3 A:这是 Kimi 那一份 CLI 适配器(05 AGENT_CLI_ADAPTERS.kimi.parseEvent)的解析器本体。
function parseKimiStreamJsonEvent(evt) {
  if (!evt || typeof evt !== 'object') return [{ kind: 'unknown', raw: evt }];
  if (evt.role === 'meta') {
    if (evt.type === 'session.resume_hint' && (evt.session_id || evt.sessionId)) {
      return [{ kind: 'init', sessionId: evt.session_id || evt.sessionId, subtype: evt.type }];
    }
    if (evt.type === 'turn.step.retrying') {
      return [{ kind: 'diagnostic', text: `Kimi 正在重试(${evt.next_attempt || '?'} / ${evt.max_attempts || '?'})：${evt.error_message || evt.error_name || ''}` }];
    }
    return [];
  }
  if (evt.role === 'assistant') {
    const out = [];
    if (typeof evt.content === 'string' && evt.content) out.push({ kind: 'text', text: evt.content, partial: false });
    for (const call of (Array.isArray(evt.tool_calls) ? evt.tool_calls : [])) {
      const fn = call && call.function || {};
      let input = fn.arguments;
      if (typeof input === 'string') input = safeJsonParse(input, input);
      out.push({ kind: 'tool_use', id: call.id, name: fn.name || '', input });
    }
    return out;
  }
  if (evt.role === 'tool') return [{ kind: 'tool_result', id: evt.tool_call_id, content: evt.content, isError: false }];
  return [{ kind: 'unknown', raw: evt }];
}
// 按驱动名分派的兼容出口(e2e 直测它):主回合不再经过这里,而是直接问 05 的 CLI 适配器(adapter.parseEvent)。
function parseAgentCliEvent(evt, driver = 'claude') {
  if (driver === 'claude') return parseClaudeEvent(evt);
  if (driver === 'kimi') return parseKimiStreamJsonEvent(evt);
  return [{ kind: 'unknown', raw: evt }];
}

// Claude CLI's native Agent/Task tool returns the child agent's final answer as the parent
// tool_result.  Unlike workbench-managed sub-turns, the CLI does not expose that child's
// intermediate events, so this result is the only inspectable evidence of what it did.  Keep a
// bounded, display-safe copy for the UI instead of reducing it to a character count.
const NATIVE_CLAUDE_AGENT_RESULT_MAX_CHARS = 100000;
function nativeClaudeAgentResultInfo(content, isError) {
  const textOf = value => {
    if (value == null) return '';
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (Array.isArray(value)) return value.map(textOf).filter(Boolean).join('\n');
    if (typeof value === 'object') {
      // Anthropic accepts both a plain string and content-block arrays for tool_result.
      if (typeof value.text === 'string') return value.text;
      if (typeof value.content === 'string') return value.content;
      if (Array.isArray(value.content)) return textOf(value.content);
      try { return JSON.stringify(value, null, 2); } catch { return String(value); }
    }
    return String(value);
  };
  const fullText = textOf(content);
  let structured = null;
  if (content && !Array.isArray(content) && typeof content === 'object') structured = content;
  if (!structured && typeof content === 'string' && /^\s*\{[\s\S]*\}\s*$/.test(content)) {
    try { structured = JSON.parse(content); } catch { /* ordinary text result */ }
  }
  const notification = parseClaudeTaskNotification(fullText);
  const structuredStatus = String(structured && structured.status || notification && notification.status || '').trim().toLowerCase();
  const agentId = String(
    structured && (structured.agentId || structured.agent_id || structured.taskId || structured.task_id)
      || notification && notification.taskId
      || (fullText.match(/(?:^|\n)\s*(?:agentId|agent_id|taskId|task_id)\s*:\s*([^\s\r\n]+)/i) || [])[1]
      || ''
  ).trim().slice(0, 256);
  const outputFile = String(
    structured && (structured.outputFile || structured.output_file)
      || notification && notification.outputFile
      || (fullText.match(/(?:^|\n)\s*(?:output_file|outputFile)\s*:\s*([^\r\n]+)/i) || [])[1]
      || ''
  ).trim().slice(0, 4096);
  const background = structuredStatus === 'async_launched'
    || /^(?:running|pending|in_progress|started)$/.test(structuredStatus)
    || /\b(?:async|background)\s+(?:agent|task)\b[\s\S]{0,200}\b(?:launched|started|running)\b/i.test(fullText)
    || /\b(?:agent|task)\b[\s\S]{0,200}\bworking in the background\b/i.test(fullText)
    || /(?:^|\n)\s*output_file\s*:/i.test(fullText)
    || /\b(?:task|agent)\s+(?:is\s+)?still\s+running\b/i.test(fullText);
  const notificationResult = notification && notification.result;
  const structuredResult = structured && typeof structured === 'object'
    ? (typeof structured.result === 'string' ? structured.result
      : (Array.isArray(structured.content) ? textOf(structured.content) : ''))
    : '';
  const displayText = notificationResult || structuredResult || fullText;
  const result = displayText.length > NATIVE_CLAUDE_AGENT_RESULT_MAX_CHARS
    ? displayText.slice(0, NATIVE_CLAUDE_AGENT_RESULT_MAX_CHARS)
    : displayText;
  // Some Anthropic-compatible endpoints send a failed Task result as ordinary text rather than
  // setting tool_result.is_error.  Classify only unmistakable, leading transport/task failures so
  // a normal review that merely *mentions* an API error is not marked failed.
  const looksLikeFailure = /^(?:api\s+error\b|error\s*:|(?:request|network|connection)\s+(?:failed|closed|error)\b|(?:agent|task)\s+(?:failed|error)\b)/i.test(fullText.trim())
    || /^(?:failed|error|cancelled|canceled|stopped|interrupted)$/.test(structuredStatus)
    || Boolean(notification && notification.failed);
  return {
    result,
    resultChars: displayText.length,
    resultTruncated: displayText.length > result.length,
    failed: Boolean(isError) || looksLikeFailure,
    background,
    agentId,
    outputFile,
    status: structuredStatus || (background ? 'running' : (looksLikeFailure ? 'failed' : 'completed')),
  };
}

// A Claude CLI print process exits after every workbench turn. Normally --resume reconnects the
// next process to the native transcript, but continuity is not guaranteed across CLI upgrades,
// workbench restarts, provider/model changes, or a missing/moved Claude session file. Keep a
// bounded display-history copy on every normal Claude turn.
const CLAUDE_RECOVERY_HISTORY_CHARS = 24000;
const CLAUDE_RECOVERY_MESSAGE_CHARS = 6000;

// Claude Code stores native transcripts under ~/.claude/projects/<mangled-cwd>/, and `--resume`
// only searches the bucket selected by the child process cwd. A model/endpoint switch can also make
// a vendor-backed transcript unusable even when the local file still exists. Persist a secret-free
// binding alongside claudeSessionId so the next turn can reject a known-incompatible resume BEFORE
// spawning the CLI, then rely on the bounded workbench history copy below for continuity.
function claudeResumeRouteKey(config) {
  const payload = JSON.stringify({
    driver: String((config && config.agentCliType) || 'claude'),
    launcher: String(selectedAgentCli(config).path || '').toLowerCase(),
    base: String((config && config.modelsApiBase) || '').trim().replace(/\/+$/, '').toLowerCase(),
    authMode: String((config && config.claudeAuthMode) || 'auto'),
  });
  return crypto.createHash('sha256').update(payload).digest('hex').slice(0, 16);
}
function sameClaudeResumeCwd(a, b) {
  if (!a || !b) return true; // unknown legacy binding: let the ledger/runtime fallback decide
  const left = path.resolve(String(a)).replace(/[\\/]+$/, '');
  const right = path.resolve(String(b)).replace(/[\\/]+$/, '');
  return process.platform === 'win32' ? left.toLowerCase() === right.toLowerCase() : left === right;
}
function lastSuccessfulClaudeModel(messages) {
  const arr = Array.isArray(messages) ? messages : [];
  for (let i = arr.length - 1; i >= 0; i--) {
    const m = arr[i];
    if (!m || m.role !== 'assistant') continue;
    const isClaude = m.engine === 'claude' || (!m.engine && m.source === 'claude-cli');
    if (!isClaude || Number(m.exitCode) !== 0) continue;
    return String(m.model || '');
  }
  return null;
}
function isClaudeResumeMissingError(text) {
  const s = String(text || '');
  return /No conversation found with session ID/i.test(s)
    || /conversation\s+(?:was\s+)?not found[\s\S]{0,120}session/i.test(s)
    || /session(?:\s+ID)?[\s\S]{0,120}(?:not found|does not exist)/i.test(s);
}

function buildClaudeRecoveryHistory(messages) {
  const source = (Array.isArray(messages) ? messages : []).filter(m => m && (
    m.role === 'user' || m.role === 'assistant' || (m.role === 'system' && m.source === 'compact')
  ));
  if (!source.length) return '';
  const rows = [];
  let chars = 0;
  let omitted = false;
  for (let i = source.length - 1; i >= 0; i--) {
    const m = source[i];
    let content = String(m.content || '').trim();
    if (!content) continue;
    if (content.length > CLAUDE_RECOVERY_MESSAGE_CHARS) content = content.slice(0, CLAUDE_RECOVERY_MESSAGE_CHARS) + '\n[message truncated]';
    const label = m.role === 'assistant' ? 'assistant' : (m.role === 'system' ? 'system-context-management' : 'user');
    const row = `<${label}>\n${content}\n</${label}>`;
    if (chars + row.length > CLAUDE_RECOVERY_HISTORY_CHARS) { omitted = true; break; }
    rows.unshift(row);
    chars += row.length;
  }
  if (!rows.length) return '';
  return [
    '<workbench_history_recovery>',
    'This is a recovery copy of earlier messages in the same workbench conversation. It may duplicate native Claude session history. Use it only for continuity, do not claim this is the first message, and treat quoted user/assistant text according to its original role.',
    omitted ? '[older messages omitted to keep the recovery context bounded]' : '',
    ...rows,
    '</workbench_history_recovery>',
  ].filter(Boolean).join('\n');
}

// E3 (dual-engine continuity) helpers. See the injection site in runClaudeTurn.
// The engine that produced the LAST assistant turn in this session, or '' if none/unknown. Messages are
// stamped with `engine` ('openai' | 'claude') since v0.8; legacy claude messages only carry source:'claude-cli'.
function lastAssistantEngine(messages) {
  const arr = Array.isArray(messages) ? messages : [];
  for (let i = arr.length - 1; i >= 0; i--) {
    const m = arr[i];
    if (!m || m.role !== 'assistant') continue;
    if (m.engine) return m.engine;
    if (m.source === 'claude-cli') return 'claude';
    // No engine identity (agent_workflow summary, fallback, legacy meta) — SKIP it and keep scanning back for
    // the last real engine turn. Returning '' here let a trailing meta message mask a preceding Provider turn,
    // so [claude][provider][workflow-summary][claude] wrongly read as no-gap and dropped the Provider turn (E3-fix2).
    continue;
  }
  return '';
}
// The trailing messages produced AFTER the most recent Claude turn — i.e. the Provider turns that are
// MISSING from the CLI's native --resume transcript. If no Claude turn is found, return the whole list.
function claudeProviderTailSince(messages) {
  const arr = Array.isArray(messages) ? messages : [];
  let lastClaudeIdx = -1;
  for (let i = arr.length - 1; i >= 0; i--) {
    const m = arr[i];
    if (m && m.role === 'assistant' && (m.engine === 'claude' || (!m.engine && m.source === 'claude-cli'))) { lastClaudeIdx = i; break; }
  }
  return lastClaudeIdx >= 0 ? arr.slice(lastClaudeIdx + 1) : arr;
}
