'use strict';
const fs=require('node:fs'),p=require('node:path'),cp=require('node:child_process'),c=require('node:crypto'),a=require('node:assert/strict');
const B='C:/r31-1103/rehearsal-task/v4',repo='C:/r31-1103/rwt',H=b=>c.createHash('sha256').update(b).digest('hex');
const prepSha='19e97014d914743e0c80f6d08c8df7ad119a31cd37c8ef3f91e5ea9b02fe31b0';a.equal(H(fs.readFileSync('C:/r31-1102/prep.cjs')),prepSha);
const P=require('C:/r31-1102/prep.cjs');
const scopes={R01:['work-data-cold-preserved-snapshot.e2e.js',120000,5,'WORK DATA COLD PRESERVED SNAPSHOT'],R02:['work-data-cold-preserved-snapshot.e2e.js',120000,5,'WORK DATA COLD PRESERVED SNAPSHOT'],L01:['work-data-cold-operations.e2e.js',240000,4,'WORK DATA COLD OPERATIONS'],L02:['work-data-cold-operations.e2e.js',240000,4,'WORK DATA COLD OPERATIONS'],PM01:['work-data-production-maintenance.e2e.js',900000,14,'WORK DATA PRODUCTION MAINTENANCE'],PR01:['work-data-production-restore.e2e.js',900000,26,'WORK DATA PRODUCTION RESTORE']};
const order=Object.keys(scopes),[scope,reviewSha,priorRootSha,priorPeerSha]=process.argv.slice(2);a(Object.hasOwn(scopes,scope));a.equal(process.argv.length,scope==='R01'?4:6);P.checkContext();a.equal(process.version,'v24.14.0');
const auth=(file,sha)=>{const raw=fs.readFileSync(file);a.equal(H(raw),sha,file);return raw;};
auth('C:/r31-1102/prep.cjs','19e97014d914743e0c80f6d08c8df7ad119a31cd37c8ef3f91e5ea9b02fe31b0');
auth('C:/r31-1103/cold-task/USER-BUDGET-AUTHORIZATION.json','81023c4c57f4d163a538c8e0c6b562abd8fedb9b971bbcf2b22726ca499c64a6');
const review=JSON.parse(auth(B+'/ACTUAL-SOURCE-REVIEW.json',reviewSha));a.equal(review.status,'SOURCE_ACCEPTED');a.equal(review.unresolvedP1P2,0);a.equal(review.callerSha256,H(fs.readFileSync(__filename)));
const code=JSON.parse(auth(B+'/SOURCE-REVIEW.json',review.codeReviewSha256));a.equal(code.status,'SOURCE_ACCEPTED');a.deepEqual(code.unresolved,[]);
const source=JSON.parse(auth(B+'/checks-source/RESULT.json',review.sourceResultSha256)),fast=JSON.parse(auth(B+'/checks-fast/RESULT.json',review.fastResultSha256));
a.equal(review.prepSha256,prepSha);a.equal(source.callerSha256,review.checksCallerSha256);a.equal(fast.callerSha256,review.checksCallerSha256);auth(B+'/run-checks.cjs',review.checksCallerSha256);
for(const gate of [source,fast]){a.equal(gate.status,'PROJECT_CHECKS_PASS');for(const row of gate.results){a.equal(row.status,0);a.equal(row.signal,null);}}
a.deepEqual(source.pins,fast.pins);a.deepEqual(source.results.map(row=>row.name),['syntax','build-check']);a.deepEqual(fast.results.map(row=>row.name),['full-fast']);
for(const file of code.reviewedFiles)a.equal(source.pins.find(pin=>pin.file===file.path)?.sha256,file.sha256,file.path);
const fastPeer=JSON.parse(auth(B+'/checks-fast/INDEPENDENT-ACCEPTANCE.json',review.fastPeerSha256));a.equal(fastPeer.status,'ACCEPT_COMPLETE_FAST');a.equal(fastPeer.unresolvedP1P2,0);a.equal(fastPeer.resultSha256,review.fastResultSha256);
const [entry,budget,groups,suite]=scopes[scope],out=B+'/'+scope;a(!fs.existsSync(out));
const prior=scope==='R01'?null:order[order.indexOf(scope)-1];
if(prior){
 const root=JSON.parse(auth(B+'/'+prior+'/TOP-EXEC.json',priorRootSha)),peer=JSON.parse(auth(B+'/'+prior+'/INDEPENDENT-ACCEPTANCE.json',priorPeerSha));
 a.equal(root.actualToolExitCode,0);a.equal(root.naturalCompletion,true);a.equal(root.sourceReviewSha256,reviewSha);
 const result=JSON.parse(auth(B+'/'+prior+'/RESULT.json',root.resultSha256));a.equal(result.accepted,true);a.equal(result.scope,prior);a.equal(result.reviewSha,reviewSha);
 a.equal(peer.status,'ACCEPT_'+prior);a.equal(peer.unresolvedP1P2,0);a.equal(peer.rootReceiptSha256,priorRootSha);a.equal(peer.resultSha256,root.resultSha256);
}
const observerSha={120000:'50c764c82bfb9720243270cdbc6ff5aee7f5e046892696ac3d7a8d5d7f475b77',240000:'14f80c1e412038b0b00d116fd316e6cef668bd4324de4e0ed9740a13067df036',900000:'1d66f361df8ef8fac95701c323b8b84103dc3e6df4019195e89c0422aa137a73'}[budget];
const observerFile='C:/r31-1102/observer-'+budget/1000+'.cjs',raw=auth(observerFile,observerSha),moduleObject={exports:{}};new Function('module','exports',raw.toString())(moduleObject,moduleObject.exports);
const verify=()=>{a.equal(H(fs.readFileSync(process.execPath)),'63c259c81e5d472b5f11c8d506070130cb04a1ecf84b80377a34ed6ec9048088');for(const pin of source.pins)a.equal(H(fs.readFileSync(repo+'/'+pin.file)),pin.sha256,pin.file);};verify();
fs.mkdirSync(out);const env=P.environment(out+'/isolation');P.mkdirEnv(env);env.RUYI_HOME=out+'/isolation/data';env.PATH+=';C:/Program Files/nodejs;C:/Program Files/Git/cmd';env.PATHEXT='.COM;.EXE;.BAT;.CMD';
fs.writeFileSync(out+'/INPUT.json',JSON.stringify({scope,entry,budget,groups,reviewSha,callerSha256:review.callerSha256,observerSha,nodeVersion:process.version,sourcePinsSha256:H(Buffer.from(JSON.stringify(source.pins))),noKillRetry:true,strictStderr:true},null,2)+'\n',{flag:'wx'});
const sinks={stdout:fs.createWriteStream(out+'/stdout.log',{flags:'wx'}),stderr:fs.createWriteStream(out+'/stderr.log',{flags:'wx'})},events=fs.openSync(out+'/events.jsonl','wx');
const begin=process.hrtime.bigint(),child=cp.spawn(process.execPath,['--require',repo+'/dev-harness/lib/fixture-home-guard.js',repo+'/dev-harness/'+entry],{cwd:repo,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
moduleObject.exports.observe(child,sinks,{begin,clock:()=>process.hrtime.bigint(),setTimer:setTimeout,clearTimer:clearTimeout,event:(type,data)=>fs.writeSync(events,JSON.stringify({type,...data})+'\n'),deadlineReceipt:value=>{fs.writeFileSync(out+'/DEADLINE.json',JSON.stringify(value,null,2)+'\n',{flag:'wx'});process.exitCode=1;},onFailure:()=>{process.exitCode=1;},onComplete:observer=>{
 let accepted=false,failure=null,labels=[];
 try{verify();auth(__filename,review.callerSha256);auth(B+'/ACTUAL-SOURCE-REVIEW.json',reviewSha);auth(B+'/SOURCE-REVIEW.json',review.codeReviewSha256);auth(B+'/checks-source/RESULT.json',review.sourceResultSha256);auth(B+'/checks-fast/RESULT.json',review.fastResultSha256);auth(B+'/checks-fast/INDEPENDENT-ACCEPTANCE.json',review.fastPeerSha256);auth(observerFile,observerSha);
  auth('C:/r31-1102/prep.cjs',prepSha);auth(B+'/run-checks.cjs',review.checksCallerSha256);auth('C:/r31-1103/cold-task/USER-BUDGET-AUTHORIZATION.json','81023c4c57f4d163a538c8e0c6b562abd8fedb9b971bbcf2b22726ca499c64a6');
  if(prior){const root=JSON.parse(auth(B+'/'+prior+'/TOP-EXEC.json',priorRootSha));auth(B+'/'+prior+'/INDEPENDENT-ACCEPTANCE.json',priorPeerSha);auth(B+'/'+prior+'/RESULT.json',root.resultSha256);}
  a.equal(observer.status,'OBSERVED_NATURAL_ZERO');const stdout=fs.readFileSync(out+'/stdout.log'),stderr=fs.readFileSync(out+'/stderr.log');a.equal(stderr.length,0);const text=stdout.toString('utf8');a(!/^FAIL /m.test(text));a.equal(text.trimEnd().split(/\r?\n/).at(-1),suite+' E2E: ALL PASS');labels=[...text.matchAll(/^PASS (.*)$/gm)].map(row=>row[1].replace(/\r$/,''));a.equal(labels.length,groups);accepted=true;
 }catch(error){failure={code:error.code||null,message:String(error.message).slice(0,300)};}
 fs.fsyncSync(events);fs.closeSync(events);fs.writeFileSync(out+'/RESULT.json',JSON.stringify({scope,entry,accepted,reviewSha,observer,labels,failure,legacyForcedExit:scope.startsWith('L'),boundary:'Finite synthetic rehearsal regression only; no all-M3, metadata restore, release or all-OS-descendant close claim'},null,2)+'\n',{flag:'wx'});if(!accepted)process.exitCode=1;console.log(JSON.stringify({scope,accepted,groups:labels.length,status:observer.status,elapsedNs:observer.terminalElapsedNs}));
}});
