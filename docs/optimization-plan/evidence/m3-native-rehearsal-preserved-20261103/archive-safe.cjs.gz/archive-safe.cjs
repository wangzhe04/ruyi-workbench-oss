'use strict';
// Explicit finite allowlist only. No fixture DATA/packages/keys/config, raw unit
// output, private environment values, DLL/cache or transitive report traversal.
const fs=require('node:fs'),p=require('node:path'),z=require('node:zlib'),c=require('node:crypto'),a=require('node:assert/strict');
const B='C:/r31-1103/rehearsal-task',V=B+'/v4',repo='C:/r31-1103/rwt',name='m3-native-rehearsal-preserved-20261103',root=repo+'/docs/optimization-plan/evidence/'+name;
const buffers=new Map(),H=bytes=>c.createHash('sha256').update(bytes).digest('hex');
const read=file=>{if(!buffers.has(file))buffers.set(file,fs.readFileSync(file));return buffers.get(file);},json=file=>JSON.parse(read(file));
const qualification='7213c6490e17e6bf73975b108d242061aab1a34cc5fd22ea79370ce08d1a8c92';a.equal(H(read(V+'/ACTUAL-SOURCE-REVIEW.json')),qualification);
const auth=(file,sha)=>{a(/^[a-f0-9]{64}$/.test(sha));const raw=read(file);a.equal(H(raw),sha,file);return raw;},q=json(V+'/ACTUAL-SOURCE-REVIEW.json');
for(const [file,sha]of [['SOURCE-REVIEW.json',q.codeReviewSha256],['checks-source/RESULT.json',q.sourceResultSha256],['checks-source/TOP-EXEC.json',q.sourceRootReceiptSha256],['checks-fast/RESULT.json',q.fastResultSha256],['checks-fast/TOP-EXEC.json',q.fastRootReceiptSha256],['checks-fast/INDEPENDENT-ACCEPTANCE.json',q.fastPeerSha256],['run-case.cjs',q.callerSha256],['run-checks.cjs',q.checksCallerSha256]])auth(V+'/'+file,sha);
a.equal(process.version,q.nodeVersion);auth(process.execPath,q.nodeSha256);
for(const pin of json(V+'/checks-source/RESULT.json').pins)auth(repo+'/'+pin.file,pin.sha256);
const scopes=['R01','R02','L01','L02','PM01','PR01'],expectedGroups=[5,5,4,4,14,26],budgets=[120000,120000,240000,240000,900000,900000],cases=[];
for(let i=0;i<scopes.length;i++){
 const scope=scopes[i],result=json(V+'/'+scope+'/RESULT.json'),top=json(V+'/'+scope+'/TOP-EXEC.json'),peer=json(V+'/'+scope+'/INDEPENDENT-ACCEPTANCE.json');
 a.equal(result.accepted,true);a.equal(result.reviewSha,qualification);a.equal(result.labels.length,expectedGroups[i]);a.equal(top.scope,scope);a.equal(top.sourceReviewSha256,qualification);a.equal(top.actualToolExitCode,0);a.equal(top.naturalCompletion,true);a.equal(top.resultSha256,H(read(V+'/'+scope+'/RESULT.json')));
 a.equal(result.observer.status,'OBSERVED_NATURAL_ZERO');a.equal(result.observer.unknown,false);a.equal(result.observer.firstError,null);a.equal(result.observer.budgetMs,budgets[i]);a.equal(Object.keys(result.observer.flags).length,10);a(Object.values(result.observer.flags).every(value=>value===true));
 a.equal(peer.scope,scope);a.equal(peer.sourceReviewSha256,qualification);a.equal(peer.status,'ACCEPT_'+scope);a.equal(peer.unresolvedP1P2,0);a.equal(peer.rootReceiptSha256,H(read(V+'/'+scope+'/TOP-EXEC.json')));a.equal(peer.resultSha256,top.resultSha256);
 for(const [file,sha]of [['INPUT.json',peer.inputSha256],['events.jsonl',peer.eventsSha256],['stdout.log',peer.stdoutSha256],['stderr.log',peer.stderrSha256]])auth(V+'/'+scope+'/'+file,sha);
 cases.push({scope,entry:result.entry,wholeMs:result.observer.budgetMs,elapsedNs:result.observer.terminalElapsedNs,groups:result.labels.length,legacyForcedExit:result.legacyForcedExit,rootReceiptSha256:peer.rootReceiptSha256,resultSha256:peer.resultSha256,independentSha256:H(read(V+'/'+scope+'/INDEPENDENT-ACCEPTANCE.json'))});
}
const fast=json(V+'/checks-fast/RESULT.json'),fastPeer=json(V+'/checks-fast/INDEPENDENT-ACCEPTANCE.json');a.equal(fast.status,'PROJECT_CHECKS_PASS');a.equal(fastPeer.status,'ACCEPT_COMPLETE_FAST');a.equal(fastPeer.resultSha256,H(read(V+'/checks-fast/RESULT.json')));a.equal(fastPeer.unresolvedP1P2,0);
const batch=JSON.parse(auth(V+'/BATCH-INDEPENDENT-ACCEPTANCE.json',process.argv[2]));a.equal(batch.status,'ACCEPT_FINITE_SIX_SCOPE_REHEARSAL_BATCH');a.equal(batch.unresolvedP1P2,0);a.equal(batch.sourceReviewSha256,qualification);
a.equal(batch.archiveScriptSha256,H(read(__filename)));
a.deepEqual(batch.cases.map(row=>row.scope),scopes);for(let i=0;i<scopes.length;i++)for(const key of ['rootReceiptSha256','resultSha256','independentSha256'])a.equal(batch.cases[i][key],cases[i][key],scopes[i]+':'+key);
a(!fs.existsSync(root));fs.mkdirSync(root);const leaves=[];
function save(id,bytes,kind,origin={}){
 a(/^[A-Za-z0-9_./-]+$/.test(id)&&!id.includes('..'));const target=root+'/'+id+'.gz';fs.mkdirSync(p.dirname(target),{recursive:true});
 const packed=z.gzipSync(bytes,{level:9});fs.writeFileSync(target,packed,{flag:'wx'});a.deepEqual(z.gunzipSync(read(target),{maxOutputLength:bytes.length}),bytes);
 leaves.push({id,kind,bytes:bytes.length,sha256:H(bytes),artifact:{file:name+'/'+id+'.gz',bytes:packed.length,sha256:H(packed)},...origin});
}
const saveRaw=(id,file)=>save(id,read(file),'explicit-safe-metadata',{originalSha256:H(read(file))});
function unitSummary(file){const raw=read(file),text=raw.toString('utf8'),get=key=>{const rows=[...text.matchAll(new RegExp('^[ℹ#] '+key+' (\\d+)\\r?$','gm'))];a(rows.length);return Number(rows.at(-1)[1]);};return {tests:get('tests'),pass:get('pass'),fail:get('fail'),skipped:get('skipped'),rawBytes:raw.length,rawSha256:H(raw),rawArchived:false};}
for(const file of ['SOURCE-REVIEW.json','ACTUAL-SOURCE-REVIEW.json'])saveRaw(file,V+'/'+file);
saveRaw('BATCH-INDEPENDENT-ACCEPTANCE.json',V+'/BATCH-INDEPENDENT-ACCEPTANCE.json');
const authorization=read('C:/r31-1103/cold-task/USER-BUDGET-AUTHORIZATION.json');a.equal(H(authorization),'81023c4c57f4d163a538c8e0c6b562abd8fedb9b971bbcf2b22726ca499c64a6');
save('budget/summary.json',Buffer.from(JSON.stringify({kind:'separately-user-approved-cold-operations-whole-file-budget',wholeMs:240000,rounds:2,commandMs:120000,closeMs:2000,metadataMs:30000,safetyAssertionsUnchanged:true,sourceAuthorizationSha256:H(authorization)},null,2)+'\n'),'safe-derived-summary');
for(const phase of ['checks-source','checks-fast']){
 for(const file of ['RESULT.json','TOP-EXEC.json'])saveRaw(phase+'/'+file,V+'/'+phase+'/'+file);
}
saveRaw('checks-fast/INDEPENDENT-ACCEPTANCE.json',V+'/checks-fast/INDEPENDENT-ACCEPTANCE.json');
saveRaw('run-case.cjs',V+'/run-case.cjs');saveRaw('run-checks.cjs',V+'/run-checks.cjs');
saveRaw('archive-safe.cjs',__filename);
for(const scope of scopes){
 for(const file of ['RESULT.json','TOP-EXEC.json','INDEPENDENT-ACCEPTANCE.json','INPUT.json','events.jsonl'])saveRaw(scope+'/'+file,V+'/'+scope+'/'+file);
 const raw=read(V+'/'+scope+'/stdout.log'),labels=json(V+'/'+scope+'/RESULT.json').labels,lines=raw.toString('utf8').split(/\r?\n/),selected=lines.filter(line=>/^PASS /.test(line)||/ E2E: ALL PASS$/.test(line));
 a.deepEqual(selected.filter(line=>line.startsWith('PASS ')).map(line=>line.slice(5)),labels);a(/ E2E: ALL PASS$/.test(selected.at(-1)));
 save(scope+'/canonical.stdout.txt',Buffer.from(selected.join('\n')+'\n'),'canonical-derived',{originalSha256:H(raw),originalBytes:raw.length,notRaw:true});
 a.equal(read(V+'/'+scope+'/stderr.log').length,0);
}
const earlier=[
 ['v1',B+'/checks-fast',B+'/checks-fast/unit.combined.log'],
 ['v2',B+'/v2/checks-fast',B+'/v2/checks-fast/unit.combined.log'],
 ['v3',B+'/v3/checks-fast',B+'/v3/checks-fast/unit.combined.log'],
];
for(const [cohort,directory,unit]of earlier){
 const qualified=q.priorRejectedGates.find(row=>row.path===directory+'/INDEPENDENT-ACCEPTANCE.json');a(qualified);const peer=JSON.parse(auth(directory+'/INDEPENDENT-ACCEPTANCE.json',qualified.sha256));a.equal(peer.status,'REJECT_COMPLETE_FAST');
 auth(unit,peer.unit.actualCombinedLogSha256||peer.unit.combinedLogSha256);
 const record={cohort,status:'REJECT_COMPLETE_FAST',originalPeerSha256:H(read(directory+'/INDEPENDENT-ACCEPTANCE.json')),originalRootSha256:H(read(directory+'/TOP-EXEC.json')),unit:unitSummary(unit),rawUnitArchived:false,oldFailureNotRejudged:true,
  originalFailure:cohort==='v1'?'engine-env-brief first native exit 3221226505 after verdict; automatic retry cannot qualify the original gate':cohort==='v2'?'engine-env-brief called private flush through unavailable public export; static96PASS/1FAIL':'scheduler U3 expected needs_you but got failed/timeout; static NOT_RUN; original causal branch not captured'};
 save('preserved-reds/'+cohort+'.json',Buffer.from(JSON.stringify(record,null,2)+'\n'),'safe-derived-summary');
}
for(const unit of ['unit01','unit06']){const result=json(B+'/'+unit+'/RESULT.json');auth(B+'/'+unit+'/stdout.log',result.stdoutSha256);}
auth(V+'/checks-fast/unit.combined.log',fastPeer.unitCombinedSha256);
const unitFirst=unitSummary(B+'/unit01/stdout.log'),unitFinal=unitSummary(B+'/unit06/stdout.log'),fullUnit=unitSummary(V+'/checks-fast/unit.combined.log');
save('units/summary.json',Buffer.from(JSON.stringify({firstRed:unitFirst,finalTargeted:unitFinal,finalFullUnit:fullUnit,modelAndFilesystemTestsNotNativeEvidence:true},null,2)+'\n'),'safe-derived-summary');
const index={schema:1,status:'FINITE_REHEARSAL_BATCH_ACCEPTED_NOT_ALL_M3',baseCommit:'cb03470fd99efb34db19da7828dbd4502af49674',sourceQualificationSha256:qualification,cases,
 finalGates:{syntaxFiles:1449,unitFiles:445,...fullUnit,staticPass:97,staticFail:0,flaky:0,liveExcluded:7},
  boundaries:['Only preserved rehearsal source reads, genuine new-owner byte/identity proof and safe cleanup; migrationFactory and nonempty special remain next.','Cross-verifier byte/identity fingerprint does not freeze Basic/ADS/security; independent final exact namespace/default-stream census remains.','Backup remains default DATA/directory names, not metadata restoration.','Legacy L entries retain forced-exit identity; outer natural zero is not natural entry or all-OS-descendant closure.','v1/v2/v3 first failures remain rejected; no raw unit/HOME provenance, fixture DATA/packages/key/config/stdin/env payloads/DLL/cache are archived.','Archived caller paths are historical provenance, not authorization to replay old scopes.','No user-data migration, platform send, push, tag, version bump or release.'],leaves};
fs.writeFileSync(root+'.json',JSON.stringify(index,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({index:name+'.json',leaves:leaves.length,indexSha256:H(read(root+'.json'))}));
