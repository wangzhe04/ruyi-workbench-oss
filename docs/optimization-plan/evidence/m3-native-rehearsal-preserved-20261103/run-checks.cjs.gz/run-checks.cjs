'use strict';
const fs=require('node:fs'),p=require('node:path'),cp=require('node:child_process'),a=require('node:assert/strict'),c=require('node:crypto');
const P=require('C:/r31-1102/prep.cjs'),repo='C:/r31-1103/rwt',base='C:/r31-1103/rehearsal-task/v4',phase=process.argv[2],H=b=>c.createHash('sha256').update(b).digest('hex');
a(['generate','source','fast','tail'].includes(phase));P.checkContext();a.equal(process.version,'v24.14.0');
const out=base+'/checks-'+phase;a(!fs.existsSync(out));fs.mkdirSync(out);
const env=P.environment(out+'/isolation');P.mkdirEnv(env);env.RUYI_HOME=out+'/isolation/data';env.PATH+=';C:/Program Files/nodejs;C:/Program Files/Git/cmd';env.PATHEXT='.COM;.EXE;.BAT;.CMD';env.GIT_CONFIG_NOSYSTEM='1';env.GIT_OPTIONAL_LOCKS='0';
const git=cp.spawnSync('C:/Program Files/Git/cmd/git.exe',['ls-files','-z','ruyi-workbench/app','dev-harness'],{cwd:repo,encoding:'utf8',windowsHide:true});a.equal(git.status,0);
const files=git.stdout.split('\0').filter(Boolean),pins=files.map(file=>({file,sha256:H(fs.readFileSync(repo+'/'+file))})),results=[];
function run(name,args){const begin=process.hrtime.bigint(),r=cp.spawnSync(process.execPath,args,{cwd:repo,env,windowsHide:true,maxBuffer:64*1024*1024});
 const stdout=r.stdout||Buffer.alloc(0),stderr=r.stderr||Buffer.alloc(0);fs.writeFileSync(out+'/'+name+'.stdout.log',stdout);fs.writeFileSync(out+'/'+name+'.stderr.log',stderr);
 const row={name,args,status:r.status,signal:r.signal,errorCode:r.error?.code??null,elapsedMs:Number(process.hrtime.bigint()-begin)/1e6,stdoutBytes:stdout.length,stdoutSha256:H(stdout),stderrBytes:stderr.length,stderrSha256:H(stderr)};results.push(row);console.log(JSON.stringify(row));a.equal(r.status,0,name);a.equal(r.signal,null);a(!r.error);}
function browserPreflight(){const query="$ErrorActionPreference='Stop';$items=@(Get-CimInstance Win32_Process -Filter \"Name='msedge.exe' OR Name='chrome.exe'\" | Where-Object {$_.CommandLine -and $_.CommandLine -match '--user-data-dir=.*[\\\\/](?:ruyi-|wcw-)'});@{count=$items.Count;readOnly=$true}|ConvertTo-Json -Compress";
 const r=cp.spawnSync('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(query,'utf16le').toString('base64')],{env,windowsHide:true,encoding:'utf8',timeout:30000});a.equal(r.status,0);const value=JSON.parse(r.stdout);a.equal(value.count,0);fs.writeFileSync(out+'/BROWSER-PREFLIGHT.json',JSON.stringify(value)+'\n');}
try{
 if(phase==='generate'){
  const changed=cp.spawnSync('C:/Program Files/Git/cmd/git.exe',['diff','--name-only','-z'],{cwd:repo,encoding:'utf8',windowsHide:true});a.equal(changed.status,0);
  for(const file of changed.stdout.split('\0').filter(Boolean)){a(/\.js$/.test(file));const name=repo+'/'+file,raw=fs.readFileSync(name,'utf8');fs.writeFileSync(name,raw.replace(/\r\n/g,'\n'));}
  run('build',['ruyi-workbench/app/build.js']);run('graph',['dev-harness/module-dependency-graph.js','--write']);run('routes',['dev-harness/route-inventory.js']);run('facts',['dev-harness/facts-generate.js']);
 }else if(phase==='source'){run('syntax',['dev-harness/syntax-gate.js']);run('build-check',['ruyi-workbench/app/build.js','--check']);}
 else if(phase==='fast'){browserPreflight();run('full-fast',['--require',repo+'/dev-harness/lib/fixture-home-guard.js','dev-harness/run-all.js','--fast','--parallel','4']);}
 else {run('eol',['dev-harness/eol-policy.static.e2e.js']);browserPreflight();run('hygiene',['--require',repo+'/dev-harness/lib/fixture-home-guard.js','dev-harness/repo-hygiene.e2e.js']);}
 if(phase!=='generate')for(const pin of pins)a.equal(H(fs.readFileSync(repo+'/'+pin.file)),pin.sha256,pin.file);
 fs.writeFileSync(out+'/RESULT.json',JSON.stringify({phase,status:'PROJECT_CHECKS_PASS',nodeVersion:process.version,callerSha256:H(fs.readFileSync(__filename)),pins,results},null,2)+'\n');
}catch(error){fs.writeFileSync(out+'/FAILURE.json',JSON.stringify({phase,status:'PROJECT_CHECKS_RED',results,code:error.code||null,message:String(error.message).slice(0,300)},null,2)+'\n');throw error;}
