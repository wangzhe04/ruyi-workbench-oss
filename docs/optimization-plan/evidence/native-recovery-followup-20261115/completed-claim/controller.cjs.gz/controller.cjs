'use strict';
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const harness=path.resolve(__dirname,'../../../dev-harness'),repo=path.dirname(harness),name='work-data-completed-claim-recovery';
const {killOwnTree}=require(path.join(harness,'lib/kill-own-tree'));
const {fixtureChildEnv}=require(path.join(harness,'lib/fixture-home'));
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const target=require(path.join(harness,'lib/work-data-owned-claim-fixture')).bindTarget(harness,path.join(harness,name+'.e2e.js'));
const {env,home}=fixtureChildEnv({perTest:true});const temp=path.join(__dirname,'temp'),local=path.join(home,'AppData','Local'),roaming=path.join(home,'AppData','Roaming');
Object.assign(env,{TEMP:temp,TMP:temp,LOCALAPPDATA:local,APPDATA:roaming,RUYI_REAL_LOCALAPPDATA:local,RUYI_REAL_APPDATA:roaming});
const command=[process.execPath,path.join(harness,name+'.e2e.js')],result={schema:1,name,command,cwd:repo,node:process.version,controllerSha256:sha(__filename),
 serverSha256:sha(target.server),executionInputSha256:target.executionInputSha256,timeoutMs:900000,home,temp,start:new Date().toISOString(),
 spawn:null,exit:null,close:null,stdoutEOF:false,stderrEOF:false,timeout:false,forcedTermination:false,nativeTransactionClosed:false,
 observationTiming:'Added cold HTTP polling may add two 2500ms requests per sampled iteration; nonzero timing influence.',noHistoricalCleanup:true};
fs.writeFileSync(path.join(__dirname,'inputs-before.json'),JSON.stringify({executionInputSha256:target.executionInputSha256,files:target.boundFiles},null,2),{flag:'wx'});
const out=fs.createWriteStream(path.join(__dirname,'stdout.log'),{flags:'wx'}),err=fs.createWriteStream(path.join(__dirname,'stderr.log'),{flags:'wx'});
const doneOut=new Promise((resolve,reject)=>{out.on('finish',resolve);out.on('error',reject);}),doneErr=new Promise((resolve,reject)=>{err.on('finish',resolve);err.on('error',reject);});
const held=cp.spawn(command[0],command.slice(1),{cwd:repo,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
held.once('spawn',()=>{result.spawn={pid:held.pid,time:new Date().toISOString(),heldOriginalChildProcess:true};});
held.stdout.pipe(out);held.stderr.pipe(err);held.stdout.once('end',()=>result.stdoutEOF=true);held.stderr.once('end',()=>result.stderrEOF=true);
held.once('error',error=>{result.spawnError={code:error.code||null,name:error.name};});
held.once('exit',(code,signal)=>{result.exit={code,signal,time:new Date().toISOString()};});
let termination=Promise.resolve();const timer=setTimeout(()=>{result.timeout=true;if(!result.exit&&!result.close&&held.exitCode===null&&held.signalCode===null){result.forcedTermination=true;termination=Promise.resolve().then(()=>killOwnTree(held)).then(value=>{result.killReceipt=value;},error=>{result.killError={code:error.code||null,name:error.name};});}},result.timeoutMs);
held.once('close',(code,signal)=>{clearTimeout(timer);result.close={code,signal,time:new Date().toISOString()};Promise.all([doneOut,doneErr,termination]).then(()=>{
 try{result.inputsAfter=target.recheck();}catch(error){result.inputRecheckFailure={code:error.code||null,name:error.name};}
 result.elapsedMs=Date.now()-Date.parse(result.start);result.status=result.timeout?'TIMEOUT_UNKNOWN':code===0&&result.stdoutEOF&&result.stderrEOF&&!result.inputRecheckFailure?'CHILD_SUCCESS_REQUIRES_EVIDENCE_REVIEW':'FAILED_UNKNOWN_OWNERS_RETAINED';
 fs.writeFileSync(path.join(__dirname,'receipt.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify(result));process.exitCode=code===0&&!result.timeout?0:1;
 }).catch(error=>{console.error(error);process.exitCode=1;});});
