# Round 2 Luna audit · 2026-11-15

范围：只读复核 140 的 3 个历史失败、143 与 Terra 隔离记录，并从 140 compact/full gzip 还原 13 个 FLAKY_PASS 的首红情况。未启动任何测试、未修改共享源码/测试。

## 验收状态与证据边界

- 140 §开头及表格（[140](/E:/Claude/worktrees/steward-3x-implementation/docs/optimization-plan/140-m4-m6-command-line-handoff-20261112.md:3)、[18项清单](/E:/Claude/worktrees/steward-3x-implementation/docs/optimization-plan/140-m4-m6-command-line-handoff-20261112.md:19)）记录原 631 范围 612 PASS / 19 FAIL；本次三个失败包括 F2、rail S4、binding UI。文档明确说这些是最终同名节观察，不是统一根因结论；retry rail 仍有 S1/S2/S4/S6 红。
- 143 开头、验证与余项（[143](/E:/Claude/worktrees/steward-3x-implementation/docs/optimization-plan/143-3.1-acceptance-followup-20261115.md:3)、[验证记录](/E:/Claude/worktrees/steward-3x-implementation/docs/optimization-plan/143-3.1-acceptance-followup-20261115.md:20)、[未闭合范围](/E:/Claude/worktrees/steward-3x-implementation/docs/optimization-plan/143-3.1-acceptance-followup-20261115.md:41)）保留 140 的整体 RED；仍未发布 3.1。
- 当前 Terra 专属 HOME/TEMP 记录：`output/20261115-round2-terra/shell-session.json` + `shell-session.stdout.log`、`isolated/rail-session-search.browser/receipt.json` + `stdout.log`、`isolated/external-bot-setup.browser/receipt.json` + `stdout.log`。三项在当前 server SHA `664e42bf…f6073`、Node 24.14.1、各自临时 HOME/TEMP、120s 内均退出 0，完整末行 `ALL PASS`；rail S4 得 2 条；binding UI 完成 S16-S24。它们是当前修订的隔离通过，不覆盖 140 的原 RED。
- 140 原始 gzip `docs/optimization-plan/evidence/m4-m6-command-line-20261112/command-line-default-4.log.gz` 解压 SHA-256 为 `a3e3d8eab2703aa7e4c2f5a1923f3caf6a5d10d63d53347ab358f78b90693e43`，与 evidence JSON 一致。以下仅采用该文件最后同名错误节。

## 三项旧失败审计

| 项目 | 140 最终同名节的事实 | 当前实现/隔离证据 | 结论 |
| --- | --- | --- | --- |
| `shell-session.e2e.js` F2 | 旧错误节只有 F2 红；实际失败观察截断为 `PS …explicit-cwd> (Get-Location).Path`。 | 测试 [行 165-168](/E:/Claude/worktrees/steward-3x-implementation/dev-harness/shell-session.e2e.js:165) 的 `printsDir`（行 37）逐行寻找独立盘符路径行；提示符/命令行本身不算。产品 [shellSend](/E:/Claude/worktrees/steward-3x-implementation/ruyi-workbench/app/src/11-native-tools.js:615) 最长等待到输入安静 300ms，完全无输出时 5s 提前收尾（实现约 586-650）。当前隔离输出同样先见提示符，但随后有 cwd 独立输出行，F2 通过。 | 显式 cwd 产品路径当前正确。历史单次仅取得提示符/回显，符合交互 PS 启动/首命令输出未及时到达的可能性；与四路负载相关是合理假设，非已证明根因。保留“shell_send 冷启动输出观察窗与负载下时序”风险，不改断言。 |
| `rail-session-search.browser.e2e.js` S4 | 最后同名节首轮 S4=1；retry 中 S0 已建 206 filler/title，旧会话在第 206/207、首屏 200 之外；S1/S2 缺失，S4=1，S6 coverage 也缺。 | fixture [行 27-78](/E:/Claude/worktrees/steward-3x-implementation/dev-harness/rail-session-search.browser.e2e.js:27) 手工写入旧正文并删除 `index.json`，重扫后立即刷新页面；搜索输入后仅给旧命中行 400ms（行 67-73），随后立刻读 count（行 78）。UI 搜索 debounce 200ms 并异步请求/渲染（[session-experience.js:158-183](/E:/Claude/worktrees/steward-3x-implementation/ruyi-workbench/app/public/js/session-experience.js:158)）。当前隔离项建满 206 条并 PASS S1/S2/S4=2/S6。 | 当前修订按全路径通过；旧症状不是单独一个 S4：中间正文未进入搜索结果，结果列表与 coverage 一起缺失。 fixture 手工改盘 + 丢索引后立刻发搜索，冷建索引/后台 writer 与查询时序是候选因素；当前证据不足以断言并发为唯一根因，也有历史服务器/实现版本漂移。建议待后续独占日志确认索引在搜索前的完成条件，不放宽等待或结果断言。 |
| `external-bot-setup.browser.e2e.js` binding UI | 最终错误节：S6-S15 均 PASS，包括账号候选严格绑定且禁用、取消不启用；随后 `cfgStewardBotSetup` 文本等待“等待来自绑定账号”超时，failstate 状态为 `ok`、一行连接。 | 当前测试 [S15-S16](/E:/Claude/worktrees/steward-3x-implementation/dev-harness/external-bot-setup.browser.e2e.js:87) 先证明取消后仍禁用，再重新激活并确认，才等待 enabled 文案；中文文案在 [zh-CN.json:4176](/E:/Claude/worktrees/steward-3x-implementation/ruyi-workbench/app/public/locales/zh-CN.json:4176)。当前隔离完整通过 S16-S24。 | 当前修订闭合了相同用户旅程。旧超时是激活后的文案未及时/未出现，历史 failstate `status=ok` 不能区分 UI state/render 时序或激活响应链；没有证据归因到并发。需要把 140 原修订下该时点的 enabled GET/state 与 DOM 更新分开记录，当前不改断言。 |

三项当前隔离通过的相同实现不等于已证明“旧错误都是并发”。140 原服务器与当前 Terra server SHA 不同，且没有记录旧失败时的逐项运行耗时/状态转移，因此因果结论应保持未定。

## 140 中 13 个 FLAKY_PASS 首红名单

来源：`command-line-default-4-results.log.gz` 的 compact 状态行 + 同目录 `command-line-default-4.log.gz` 尾部 `# [flaky] 名单`。所有条目定义都是首跑失败、自动重跑通过；这是历史首红证据，不表示本轮当前红/绿。

| 文件 | 首跑症状（原文要点） |
| --- | --- |
| `monitor-incremental.e2e.js` | `FAIL H8 ops 指标端点形状(interventions/missions)` |
| `work-data-production-restore.e2e.js` | 无断言红，exit=1；保留夹具 stage=`encrypted-enable-successor` |
| `loop-guard-read-exempt.e2e.js` | `FAIL workbench up (B) on :63740` |
| `memory-scope-card.browser.e2e.js` | 本件 timeout；末尾已到首屏、E1/E2/E2a/E2b/E3-E5 等 PASS（原摘要保留末 25 行，不代表全部断言） |
| `missions-readmodel.e2e.js` | `FAIL workbench up on :63937`、`FAIL UI token scraped` |
| `steward-delivery.browser.e2e.js` | `FAIL 连续打开同名文件时迟到预览不覆盖后来选中的文件` |
| `external-bots-human-decisions.e2e.js` | 本件 timeout；末尾 permission allow/deny、question/answer、plan approve/reject、pool approve/reject、replan approve 均 PASS |
| `external-bots-retry.browser.e2e.js` | `FAIL RUI theme config synchronized`（含 AssertionError） |
| `live-full-text.e2e.js` | `B3 回合结束后 resumable.live 不是 true`，实际诊断 JSON `live:true` |
| `privacy-protocols.e2e.js` | 本件 timeout；末尾 Anthropic no-turn-errors、auxiliary completion、history protection 等 PASS |
| `steward-relay-channels.e2e.js` | `H3b 回合结束后 resumable.live 不是 true`，实际诊断 JSON `live:true` |
| `thread-relay.e2e.js` | `FAIL a fresh explicitly created relay can continue the current rewound target exactly once` |
| `vision-loop.e2e.js` | `workbench up on :58315`、`version === package.json`、`UI token scraped` 均 FAIL |

这份名单不自动扩大为当前待办，须先对照当前 86/92/140 门状态；尤其 timeout/no-assert 和 `live:true` 不能被摘成泛化产品缺陷。

## 附项：budget-guard E31 / T3

140 原始同名节只保留 `E31 零触发路径零预算日志` FAIL；末尾有 E29 快命令正常、E30 请求体等价 PASS，但**没有** T3 `elapsedMs`、事件种类或事件载荷。无法从归档判定实际发生了 `soft_warning`，也无法证明是误报。

当前测试的 T3 [budget-guard.e2e.js:245-254](/E:/Claude/worktrees/steward-3x-implementation/dev-harness/budget-guard.e2e.js:245) 注释称“高阈值”，实值 `toolTimeBudgetWarnMsV1: 1000`（1 秒）；监测 1500ms 内是否有 `tool_time_budget` 或 byte shadow 日志。生产 workflow [09-workflow.js:2420-2429](/E:/Claude/worktrees/steward-3x-implementation/ruyi-workbench/app/src/09-workflow.js:2420) 在调用耗时达到 warnMs 后会按契约发 `soft_warning`。T3 调 `powershell_run Write-Output hi`，启动时间也计入工具调用。因而在四路负载下如果真实 elapsed ≥1000ms，soft warning 属合法预算事件，而非产品误报；这只是由阈值和规则推出的条件判断，不是原运行的实测值。143 报告本轮独占原服务与修后均通过（[143:18](/E:/Claude/worktrees/steward-3x-implementation/docs/optimization-plan/143-3.1-acceptance-followup-20261115.md:18)），不能反推旧并发运行的 elapsed。不得调高阈值或减断言；要闭合需保留 T3 实际 tool elapsed 和 log event 的 `mode/state/warnMs/elapsedMs`，对比请求期间观测。

## E31 失败态诊断候选（非共享测试文件）

临时候选：[budget-guard.e2e.candidate.js](/E:/Claude/worktrees/steward-3x-implementation/output/20261115-round2-luna/budget-guard.e2e.candidate.js)。它从当前 `dev-harness/budget-guard.e2e.js` 复制，只在 `logs.length !== 0`（即 E31 将失败）时读取现有 `T3.readCap(2)`：仅检查 role=`tool` 的消息内容，将 JSON 结果对象顶层有限数值 `elapsedMs` 收集为 `toolResultElapsedMs`。不会打印 cap 内容，也不遍历/输出 stdout、stderr、命令、对话、凭据或配置。

预算日志按 `kind ∈ {tool_time_budget, tool_byte_budget_shadow}` 白名单保留；其余只允许 `mode ∈ {enforce, shadow}`、`state ∈ {soft_warning, hard_kill, would_soft_warning, would_hard_kill}` 和数值型 `warnMs`、`deadlineMs`、`elapsedMs`。非法/未知值省略。输出单行 `[E31 diagnostic]` 后照常执行原 E31 `ok(logs.length === 0, ...)`，未调整阈值、断言、wait 窗口、请求或流程。

验证仅执行 `node --check output/20261115-round2-luna/budget-guard.e2e.candidate.js`，退出 0；没有运行 E2E。该文件是待审候选，不自动替换共享测试。
