# 13 项历史 flaky 后续复验计划（只读，2026-11-15）

依据 `output/20261115-round2-luna/README.md` 的 140 原始首红及 `dev-harness/run-all.js` 的 `TIMEOUT_MS` / `TIMEOUT_OVERRIDES`。以下预算是每次原 runner 整件 watchdog；保留内部时限和断言，不自动重试洗绿。独立 HOME、AppData、TEMP 和数据根，逐件串行记录源码/测试哈希、exit/close/双 EOF、超时与完整日志；头less 依赖本机 Edge/Chrome。实际单件通过只说明当前条件下通过，不重写原 631 四路 flaky 或总体 RED。无测试在编制本计划时执行。

| 历史 flaky（`.e2e.js`） | 原预算 | 执行条件与首红聚焦 |
| --- | ---: | --- |
| monitor-incremental | 120s | 离线本地服务；H8 ops 端点形状。固定 tmp 子目录须放入每件独立 TEMP。 |
| work-data-production-restore | 900s | 暂缓并与四个 native 长件共享只读诊断：真实 Windows DPAPI/NTFS、冷 worker、同端口 successor 与 owned Job；首红 encrypted-enable-successor。先获得 owner/source/IPC/exit-close/UNKNOWN 收据，避免重复启动或清理未知后代。非 GUI；不是 Python312 测试。 |
| loop-guard-read-exempt | 120s | 离线 fake provider；B 服务启动条件。 |
| memory-scope-card.browser | 120s | 现有 headless 浏览器夹具，fake 服务；首轮 timeout，保留全阶段输出。 |
| missions-readmodel | 120s | 离线 fake provider；服务启动与 token。 |
| steward-delivery.browser | 120s | 现有 headless 浏览器夹具；迟到预览/后来选中项顺序。 |
| external-bots-human-decisions | 120s | 默认全旅程为离线 HTTP/模拟平台；保持无参数，不以局部模式冒充全件。记录各 action 与 close。 |
| external-bots-retry.browser | 120s | headless、模拟平台；源码内有前置哈希锁，先记录实际身份与前置拒绝，勿更改 pin 洗绿；首红主题配置同步。 |
| live-full-text | 120s | 离线 fake provider；记录回合结束后 resumable.live 与读取时序。此项为 `.e2e.js`，不是同名 `.browser` 件。 |
| privacy-protocols | 120s | 本地 fake OpenAI/Anthropic；首轮 timeout，保留完整阶段与清理结果。 |
| steward-relay-channels | 120s | 离线 fake provider；记录回合结束后 resumable.live 与读取时序。 |
| thread-relay | 120s | 离线 HTTP 和 fake provider；显式新 relay 续接一次判据。 |
| vision-loop | 120s | 本地 fake provider、fake MCP；截图和 OCR 均为 fake 响应，不调用真实桌面、剪贴板或真实 OCR；保留固定端口审计。 |

三件 `.browser` 由 `lib/browser-fixture.js` 使用 `--headless=new`，不使用 Computer Use。以上 13 件静态审阅未发现必须使用真实剪贴板、真实 OCR 或 Python 3.12；一般服务启动的可选环境探测不等于这些能力已通过。native 项仍须 Windows owner 安全证据，不得因无人机 UI 就当普通 fake 件。

原 631 的四个用户排除项（artifacts、desktop-mcp-smoke、privacy-clipboard-copy、privacy-mermaid-export）不纳入此清单、不启动，也不新增排除。历史禁止 Computer Use 持续有效。运行前检查各 fixture 本身的隔离及内嵌依赖；若需要真实桌面/剪贴板/OCR、真实平台、凭据或 Python312 的能力不可用，保留未执行和原因，不临时扩大跳过或改断言。
