'use strict';
const fs = require('fs');
const path = require('path');
const names = fs.readFileSync(path.join(__dirname, 'cases.txt'), 'utf8').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
if (process.argv.length !== 3 || !names.includes(process.argv[2])) throw new Error('Exactly one listed non-native case is required');
require('./controller.js');
