'use strict';
const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict'),c=require('node:crypto');
const repo=p.resolve(__dirname,'../..'),priv='C:/Users/87179/.codex/worktrees/m3-desktop-integration/ruyi-workbench-oss';
const core=require(p.join(repo,'dev-harness/lib/work-data-production-upload-core')),sha=b=>c.createHash('sha256').update(b).digest('hex');
const original=JSON.parse(fs.readFileSync(p.join(__dirname,'PROTECTED-INPUTS.json'))).files;
for(const row of original)core.read(row.file,row);
const relativeRefs=['m3-bound-directory-qualified-root-review-20261030/REPORT.json','m3-bound-deep-integration-root-review-20261030/REPORT.json','m3-bound-deep-integration-20261030/SOURCE-PINS.json','m3-bound-deep-integration-terra-actual-20261030/REPORT.json'];
const refs=relativeRefs.map(f=>core.read(p.join(priv,'.ruyi-runtime',f)).row);
a.equal(refs.at(-1).sha256,'691e8fb67df17f4ddba61aea0d3a3b7acb14a554e1ba08941935212085dc5587');
const referenceBytes=JSON.stringify({schema:1,files:refs,privateActualIsNotMainActual:true},null,2)+'\n';
a.equal(fs.readFileSync(p.join(__dirname,'reference-pins.json'),'utf8'),referenceBytes,'retain exact previously written references');
const compiler=JSON.parse(fs.readFileSync(p.join(__dirname,'checks-result.json'))).compilerInputs;
const extra=[...refs,...['dev-harness/lib/source-slice.js','dev-harness/facts.static.e2e.js'].map(f=>core.read(p.join(repo,f)).row)];
// Framework files may legitimately be OS hard links. Record their real fields
// separately; never weaken the product loader's nlink===1 requirement.
const diagnosticToolInputs=compiler.map(row=>{const st=fs.lstatSync(row.file,{bigint:true});a.ok(st.isFile()&&!st.isSymbolicLink());const b=fs.readFileSync(row.file);a.equal(b.length,row.bytes);a.equal(sha(b),row.sha256);return{...row,...core.physical(st)};});
const protectedInputs=[...new Map([...original,...extra].map(row=>[core.norm(row.file),row])).values()];
const members=fs.readdirSync(__dirname).filter(f=>f!=='PINS.json').sort().map(file=>{const b=fs.readFileSync(p.join(__dirname,file));return{file,bytes:b.length,sha256:sha(b)};});
const out={schema:1,verdict:'ACCEPT_FOR_TWO_FRESH_MAIN_ACTUAL_WINDOWS',head:'1615ec59fb249251112bd37e1f7a4b38c42a87b3',tree:'be3e32bdaf96d6db7c37ba2e7b4cb265297b9b1c',executionInputSha256:'700acc36f5358373f54ac9b486b3a2f3699d5d1f41426bb2be241e9c36d64908',members,protectedInputs,diagnosticToolInputs,actualExecuted:false};
fs.writeFileSync(p.join(__dirname,'PINS.json'),JSON.stringify(out,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({members:members.length,protectedInputs:protectedInputs.length}));
