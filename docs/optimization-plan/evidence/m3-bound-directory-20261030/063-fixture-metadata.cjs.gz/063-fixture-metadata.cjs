const fs=require('fs'),c=require('crypto');
const p='.ruyi-runtime/m3-bound-main-terra-actual-20261030/REPORT.json';
const r=JSON.parse(fs.readFileSync(p));
for(const x of r.runs){const e=fs.readFileSync(x.eventsPath,'utf8').trim().split(/\r?\n/).map(JSON.parse);const o=e.find(z=>z.kind==='fixture-owner'),s=e.find(z=>z.kind==='child-start'&&z.label==='main-server');x.fixture={nonce:o.nonce,temp:o.temp,tempUtf16Length:o.temp.length,port:Number(s.args[s.args.indexOf('--port')+1])};}
r.metadataPreparationNote='A read-only inline metadata extraction failed with SyntaxError due to shell regex escaping; it did not alter this report or rerun tests; corrected by this separate reader.';
fs.writeFileSync(p,JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify({sha256:c.createHash('sha256').update(fs.readFileSync(p)).digest('hex'),fixtures:r.runs.map(x=>x.fixture)}));
