'use strict';
// Summarize already completed diagnostic children; no child process is rerun.
const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict'),c=require('node:crypto');
const names=['source-pure-five','build-check','syntax-1','syntax-2','syntax-3','syntax-4','embedded-full-csharp-library-compile-only'];
const rows=names.map(name=>JSON.parse(fs.readFileSync(p.join(__dirname,name+'.json'))));
for(const row of rows){a.equal(row.exit,0,row.name);a.equal(row.signal,null);a.equal(row.error,null);}
for(const [label,count] of [['tests',5],['pass',5],['fail',0]])a.match(rows[0].stdout,new RegExp('^(?:#|ℹ) '+label+' '+count+'$','m'));
const sha=b=>c.createHash('sha256').update(b).digest('hex');
const files=['C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe','C:/Windows/Microsoft.NET/Framework64/v4.0.30319/System.Web.Extensions.dll'];
const compilerInputs=files.map(file=>{const b=fs.readFileSync(file);return{file,bytes:b.length,sha256:sha(b)};});
const dll=fs.readFileSync(p.join(__dirname,'native-current.dll'));
const original=JSON.parse(fs.readFileSync(p.join(__dirname,'PROTECTED-INPUTS.json'))).files;
const unique=new Map(original.map(row=>[p.resolve(row.file).toLowerCase(),row]));
const summary={schema:1,diagnosticChildren:rows.length,allChildrenExitZero:true,pureTests:5,syntax:4,buildCheck:true,fullEmbeddedCSharpLibraryCompiled:true,dll:{bytes:dll.length,sha256:sha(dll)},compilerInputs,protectedInputRecords:original.length,protectedDistinctPaths:unique.size,assemblyLoaded:false,nativeMethodsExecuted:false,actualExecuted:false};
fs.writeFileSync(p.join(__dirname,'checks-result.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(summary,null,2));
