'use strict';
// Read-only sealed-evidence, protected input, and Git-index verification.
const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict'),cp=require('node:child_process'),c=require('node:crypto');
const repo=p.resolve(__dirname,'../..'),pins=JSON.parse(fs.readFileSync(p.join(__dirname,'PINS.json')));
const core=require(p.join(repo,'dev-harness/lib/work-data-production-upload-core'));
const sha=b=>c.createHash('sha256').update(b).digest('hex');
for(const row of pins.members){const b=fs.readFileSync(p.join(__dirname,row.file));a.equal(b.length,row.bytes,row.file);a.equal(sha(b),row.sha256,row.file);}
a.deepEqual(fs.readdirSync(__dirname).sort(),[...pins.members.map(r=>r.file),'PINS.json'].sort(),'sealed member set');
for(const row of pins.protectedInputs)core.read(row.file,row);
for(const row of pins.diagnosticToolInputs){const st=fs.lstatSync(row.file,{bigint:true});a.ok(st.isFile()&&!st.isSymbolicLink());const b=fs.readFileSync(row.file);a.equal(b.length,row.bytes);a.equal(sha(b),row.sha256);for(const [key,value] of Object.entries(core.physical(st)))a.equal(value,row[key]);}
const git=(...args)=>cp.execFileSync('git',args,{cwd:repo,windowsHide:true,maxBuffer:64*1024*1024,env:{...process.env,GIT_OPTIONAL_LOCKS:'0'}});
a.equal(git('rev-parse','HEAD').toString().trim(),pins.head);git('diff','--cached','--quiet',pins.tree);git('diff','--quiet');
const execution=JSON.parse(fs.readFileSync(p.join(repo,'.ruyi-runtime/m3-bound-main-integration-20261030/EXECUTION-INPUTS.json'))),target=core.loadProductTarget(p.join(repo,'dev-harness'));
a.equal(target.boundFiles.length,146);a.equal(target.executionInputSha256,execution.coreExecutionInputSha256);
const rows=[...target.boundFiles,core.read(p.join(repo,'dev-harness/work-data-bound-directory-deep-path.e2e.js')).row];a.deepEqual(rows,execution.files);
const digest=sha(Buffer.from(JSON.stringify(rows.map(r=>({file:core.norm(r.file),bytes:r.bytes,sha256:r.sha256})).sort((x,y)=>x.file<y.file?-1:x.file>y.file?1:0))));a.equal(digest,pins.executionInputSha256);target.recheck();
a.equal(fs.readdirSync(p.join(repo,'dev-harness')).filter(n=>n.endsWith('.e2e.js')).length,599);a.equal(fs.readdirSync(p.join(repo,'dev-harness/unit')).filter(n=>n.endsWith('.test.js')).length,415);
console.log(JSON.stringify({verdict:'SEALED_SOURCE_ACCEPT_MAIN_ACTUAL_PENDING',members:pins.members.length,protectedInputs:pins.protectedInputs.length,directExecutionInputs:rows.length,digest,reportSha256:pins.members.find(r=>r.file==='REPORT.md').sha256,pinsSha256:sha(fs.readFileSync(p.join(__dirname,'PINS.json'))),actualExecuted:false}));
