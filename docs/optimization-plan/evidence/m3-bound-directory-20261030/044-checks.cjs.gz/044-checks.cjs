'use strict';
// Exact five source/pure tests and compile-only diagnostics. Never run the DLL.
const fs=require('node:fs'),p=require('node:path'),cp=require('node:child_process'),a=require('node:assert/strict'),c=require('node:crypto');
const repo=p.resolve(__dirname,'../..'),node=process.execPath;
const compiler='C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe';
const frameworkRef='C:/Windows/Microsoft.NET/Framework64/v4.0.30319/System.Web.Extensions.dll';
const sha=b=>c.createHash('sha256').update(b).digest('hex');
const cases=[
 ['source-pure-five',node,['--test','dev-harness/unit/work-data-bound-directory-native-path.test.js']],
 ['build-check',node,['ruyi-workbench/app/build.js','--check']],
 ...['ruyi-workbench/app/src/13u-migration-center.js','dev-harness/unit/work-data-bound-directory-native-path.test.js','dev-harness/work-data-bound-directory-deep-path.e2e.js','dev-harness/run-all.js'].map((f,i)=>['syntax-'+(i+1),node,['--check',f]]),
 ['embedded-full-csharp-library-compile-only',compiler,['/nologo','/target:library','/out:'+p.join(__dirname,'native-current.dll'),'/reference:'+frameworkRef,p.join(__dirname,'native-current.cs')]]
];
const rows=[];
for(const [name,command,args] of cases){const started=new Date().toISOString(),at=performance.now();const r=cp.spawnSync(command,args,{cwd:repo,windowsHide:true,encoding:'utf8',timeout:45000,maxBuffer:4*1024*1024});const row={name,command,args,cwd:repo,started,elapsedMs:performance.now()-at,exit:r.status,signal:r.signal,error:r.error?{name:r.error.name,code:r.error.code,message:r.error.message}:null,stdout:r.stdout||'',stderr:r.stderr||'',actualExecuted:false};rows.push(row);fs.writeFileSync(p.join(__dirname,name+'.json'),JSON.stringify(row,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({name,exit:row.exit,signal:row.signal,error:row.error,elapsedMs:row.elapsedMs,stdout:row.stdout}));a.equal(r.error,undefined,name);a.equal(r.status,0,name);a.equal(r.signal,null,name);}
const pure=rows[0];a.match(pure.stdout,/# tests 5/);a.match(pure.stdout,/# pass 5/);a.match(pure.stdout,/# fail 0/);
const compilerInputs=[compiler,frameworkRef].map(file=>{const b=fs.readFileSync(file);return{file,bytes:b.length,sha256:sha(b)};});
const dll=fs.readFileSync(p.join(__dirname,'native-current.dll'));
fs.writeFileSync(p.join(__dirname,'checks-result.json'),JSON.stringify({schema:1,passed:rows.length,pureTests:5,syntax:4,buildCheck:true,fullEmbeddedCSharpLibraryCompiled:true,dll:{bytes:dll.length,sha256:sha(dll)},compilerInputs,assemblyLoaded:false,nativeMethodsExecuted:false,actualExecuted:false},null,2)+'\n',{flag:'wx'});
