'use strict';
// Generates only a source-only draft. Never imports or invokes its main.
const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict'),c=require('node:crypto');
const sha=b=>c.createHash('sha256').update(b).digest('hex');
const baseline='C:/Users/87179/AppData/Local/Temp/ruyi-ordinary119-path-guard-fix-20261026-be035b34/prepare-ordinary119-path-guarded.cjs';
const original=fs.readFileSync(baseline,'utf8');a.equal(sha(original),'5405fe921324d76edc9861cd26bb393d613beaa674b2d5f539d3d3b96c93a80b');
const edits=[];let source=original;
function change(label,before,after){a.equal(source.split(before).length,2,label);source=source.replace(before,after);edits.push({label,before,after,occurrences:1});}
change('append fail-closed next candidate pins',"const ORIGINAL_TEMP=",`// Fixed candidate and independent approval pins must be finalized in a new reviewed identity.
const NEXT_PIN=Object.freeze({ready:false,identityFile:null,identitySha256:null,approvalFile:null,approvalSha256:null,sourceSha256:null});
const NEXT_MOVE=Object.freeze({before:'const moved=await platform.move({source,target,id:owned.objectInfo.id});',after:'const moved=await platform.move({source,target,id:owned.objectInfo.id,preserveMetadata:true});'});
const ORIGINAL_TEMP=`);
change('fail closed before preparation input access','function main(){\n',`function main(){
 a.equal(NEXT_PIN.ready,true,'next candidate and independent approval identities are not finalized');
 for(const key of ['identitySha256','approvalSha256','sourceSha256'])a.match(NEXT_PIN[key],/^[a-f0-9]{64}$/,'fixed next pin '+key);
 for(const key of ['identityFile','approvalFile'])a.ok(typeof NEXT_PIN[key]==='string'&&p.isAbsolute(NEXT_PIN[key]),'fixed absolute next pin '+key);
`);
change('admit only exact new candidate plus independent approval'," const frozenSrc=p.join(freeze,'with-diagnostic/runtime/app/src')",` const nextIdentityBytes=regular(NEXT_PIN.identityFile),nextApprovalBytes=regular(NEXT_PIN.approvalFile);a.equal(sha(nextIdentityBytes),NEXT_PIN.identitySha256);a.equal(sha(nextApprovalBytes),NEXT_PIN.approvalSha256);
 const nextIdentity=JSON.parse(nextIdentityBytes);a.ok(Array.isArray(nextIdentity.files)&&nextIdentity.files.length>0,'fixed candidate complete receipt');const nextRoot=p.dirname(NEXT_PIN.identityFile),nextSeen=new Set();for(const row of nextIdentity.files){a.ok(!nextSeen.has(row.file.toLowerCase()));nextSeen.add(row.file.toLowerCase());const bytes=regular(member(nextRoot,row.file));a.equal(bytes.length,row.bytes,row.file);a.equal(sha(bytes),row.sha256,row.file);}
 const old13uBytes=regular(p.join(freeze,'with-diagnostic/runtime/app/src/13u-migration-center.js'));a.equal(sha(old13uBytes),PIN.source13u);const old13u=old13uBytes.toString('utf8');a.equal(old13u.split(NEXT_MOVE.before).length,2,'ordinary move unique baseline span');const next13u=old13u.replace(NEXT_MOVE.before,NEXT_MOVE.after);a.equal(sha(next13u),NEXT_PIN.sourceSha256,'candidate must be exact ordinary move option only');a.equal(next13u.split(NEXT_MOVE.after).length,2,'ordinary move unique inverse');a.equal(next13u.replace(NEXT_MOVE.after,NEXT_MOVE.before),old13u,'whole product inverse');
 const frozenSrc=p.join(freeze,'with-diagnostic/runtime/app/src')`);
change('permit only one exact 13u source delta',"if(name!=='manifest.json'){a.equal(actual.length,row.bytes,name);a.equal(sha(actual),row.sha256,name);}","if(name==='13u-migration-center.js'){a.equal(actual.equals(Buffer.from(next13u,'utf8')),true,name+' unique admitted ordinary move span');}else if(name!=='manifest.json'){a.equal(actual.length,row.bytes,name);a.equal(sha(actual),row.sha256,name);}");
change('current 13u SHA pin only',"a.equal(sha(regular(p.join(actualSrc,'13u-migration-center.js'))),PIN.source13u);","a.equal(sha(regular(p.join(actualSrc,'13u-migration-center.js'))),NEXT_PIN.sourceSha256);");
change('physical admission for new immutable candidate/review',"const admissionPaths=[originalTemp,runRoot,", "const admissionPaths=[NEXT_PIN.identityFile,NEXT_PIN.approvalFile,nextRoot,...nextIdentity.files.map(row=>member(nextRoot,row.file)),originalTemp,runRoot,");
change('extra proof without altering original freeze attestation',"sourceProof:{files:checkedSource,", "nextCandidate:{identityFile:NEXT_PIN.identityFile,identitySha256:NEXT_PIN.identitySha256,approvalFile:NEXT_PIN.approvalFile,approvalSha256:NEXT_PIN.approvalSha256,source13uSha256:NEXT_PIN.sourceSha256,onlyOrdinaryMovePreserveOption:true,wholeInverseTo0975:true},sourceProof:{files:checkedSource,");
let inverse=source;for(const row of edits.slice().reverse()){a.equal(inverse.split(row.after).length,2,row.label+' inverse uniqueness');inverse=inverse.replace(row.after,row.before);}a.equal(inverse,original);
const guardBefore=original.slice(original.indexOf(' // Path admission:'),original.indexOf(' const proof='));const guardAfter=source.slice(source.indexOf(' // Path admission:'),source.indexOf(' const proof='));a.equal(guardAfter.replace(edits.find(row=>row.label==='physical admission for new immutable candidate/review').after,edits.find(row=>row.label==='physical admission for new immutable candidate/review').before),guardBefore,'entire physical guard and exclusive writer identical except extended read-only admission list');
fs.writeFileSync(p.join(__dirname,'prepare-ordinary119-next.draft.cjs'),source,{flag:'wx'});
fs.writeFileSync(p.join(__dirname,'draft-inverse-to5405.json'),JSON.stringify({schema:1,status:'DRAFT FAIL-CLOSED; DO NOT EXECUTE MAIN',baseline,baselineSha256:sha(original),draftSha256:sha(source),spans:edits,wholeForwardAndInverseExact:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({draftSha256:sha(source),spans:edits.length,ready:false,mainInvoked:false}));
