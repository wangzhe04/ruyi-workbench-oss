'use strict';
// Source preparation only: no application loading, build, tests, process or socket.
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),a=require('node:assert/strict');
const repo=p.resolve(process.argv[2]||''),out=p.resolve(process.argv[3]||'');a.equal(process.argv.length,4);a.equal(fs.existsSync(out),false);
const key=x=>process.platform==='win32'?x.toLowerCase():x,actualOut=p.join(fs.realpathSync(p.dirname(out)),p.basename(out)),actualRepo=fs.realpathSync(repo);a.ok(key(actualOut)!==key(actualRepo)&&!key(actualOut).startsWith(key(actualRepo)+p.sep));
const hash=x=>c.createHash('sha256').update(x).digest('hex'),products=JSON.parse(fs.readFileSync(p.join(__dirname,'products.json'))),changes=JSON.parse(fs.readFileSync(p.join(__dirname,'spans.json'))),writes=[];
for(const row of products){let value=fs.readFileSync(p.join(__dirname,'files',row.file),'utf8');a.equal(hash(value),row.sha256);if(row.kind==='modified'){let source=fs.readFileSync(p.join(repo,row.file),'utf8');a.equal(hash(source),row.baseSha256);for(const span of changes.find(x=>x.file===row.file).spans){a.equal(source.split(span.before).length,2);source=source.replace(span.before,span.after);}a.equal(source,value);}writes.push([p.join(out,row.file),value]);}
fs.mkdirSync(out);for(const [file,value] of writes){fs.mkdirSync(p.dirname(file),{recursive:true});fs.writeFileSync(file,value,{flag:'wx'});}console.log(JSON.stringify({sourcePreparedOnly:true,out,files:writes.length}));
