# Portable permanent retry tests + HTTP increment draft

This package depends on the separately approved V2 backend source:
13w 36dafa162e277baea75f82e7faf4d2d37ebb31ff022090000788cb68b993e3c6
01b 5a1f833241c348dc738aeaa7382f0d4496f33beb2083e0e9c28724d73d50356a
Root review: fa9ebcf2f3efa0329f3b4932d7e6c75c5625a25372d79e93af2629b516c195a6.
No backend/generated-server bytes are supplied or changed here.

Eight candidate files live under files/. products.json binds every base and candidate hash; spans.json fully inverses the three modified existing files. reconstruct-tests.cjs <repo> <fresh external directory> only reconstructs these sources outside checkout.

Permanent tests:
- external-bots-retry.test.js ports original45. It reads current production 13w relative to repository, removes only the exact API spans for the original six-core-span inverse contract, and reconstructs exact c82 as historical v3. Original behavior assertions remain.
- external-bots-retry-capacity.test.js ports original1. Observation JSON moves from candidate source folder into its existing test-owned fixture directory, cleaned by the fixture.
- external-bots-retry-api.test.js ports V2 21. It reads actual 13w and01b relative to repository. The auth-inverse assertion now checks exact predecessor SHA instead of a TEMP full-baseline file. No source override environment variable or absolute execution path remains.
- Core45 and API21 retain all business/durability/identity/capacity assertions. They have NOT been executed in this preparation; old V2 green runs do not certify these ports.

Shared history:
- external-bots-source-history.js has no node:test hooks, service imports, git or TEMP dependency.
- Existing fixture historicalSource delegates to this helper, retaining original v2/v1 reconstruction.
- history.json retains v3Sha and every original v2/v1 JSON value. New v4 inverse contains exact API3 + core6 inverse (reverse application order). It reconstructs full c82 first, then historical v2/v1.
- contracts.json contains exact core/API/auth spans and hashes, not full old product snapshots.
- Preparation directly verified exact old sources v3=c82cef97, v2=1ad6064f, v1=5bf22598; omit-core and omit-API controls each raise ERR_ASSERTION.

HTTP draft:
The original external-bots-control.e2e.js C/B/X assertions and cancellation segment remain byte exact. Five narrow fixture spans add a token503 mode, retry-only owned rename fault preload, cleanup and independent R1-R11 after X10.
R preconditions are produced by actual callback -> actual Steward -> actual reply adapter token-phase failure. There is no state seeding or synthetic reader data. The helper also waits for the actual worker to become idle, so its previous loop cannot mask the lost-write-result liveness case.
R covers token/origin/body rejection; known-unsubmitted retry -> one original reply; stable request after success; dropped local ACK; process restart and duplicate callback; precise successor cancellation retaining schema4; actual rename commits then returns EIO -> human same receipt resumes one attempt; exact old v1/v2/v3 full-ledger validators reject real producer schema4. Old actual Store plain/sealed rejection is additionally covered by permanent core tests, not misrepresented by the validator-only HTTP assertion.
Only model responses and fixed official HTTPS are synthetic, using the existing harness. The draft does not broaden unknown/429 eligibility.

Performed here:
- vm.Script parse of six JavaScript candidates; JSON parse of two fixtures.
- Full byte/SHA inverse of three modified existing files.
- Exact source-history reconstruction and two removed-inverse negative controls.
- Original cancellation segment exact byte check; R1-R11 count.
No app loading, generated build, native/helper execution, socket, HTTP server, e2e or permanent unit run occurred. There were no source/test execution first failures because those gates were not run. verification-first.log records the first source-only verification.

Next gate is independent root review of all eight exact files, then stage the already-approved backend plus these tests into an isolated review tree, build and run original relevant units and actual HTTP e2e serially with normal ownership/isolation. Any first failures remain evidence and are fixed separately. Permanent artifacts/inventories/facts/route/egress and broader checks follow actual tested source identity. UI remains separate, along with retention, 429 timing, trustworthy unknown reconciliation, real platform accounts and complete B1/3.1 acceptance.
