# M5 known-unsubmitted reply retry API candidate

Prepared in Temp only against HEAD 4b455b83 / live 13w c82cef972e46ae42d58f74d775a6a6a09e52caeb7d3d368a71fcaa57074504c6.

Products:
- 13w-core.js: exact reconstructed previously reviewed 026d912512f8d36cd10678d801075f386d0527ac4aeea0bbac561b24eb0ff79a.
- 13w-external-bots.js: core plus exactly three routing spans, SHA-256 0e2f8c1b5f0d08a068b1ef25493b59a5ae66eb523cd4eeb8edc6d3b13a73d360.
- 01b-route-auth.js: one exact POST token row, SHA-256 5a1f833241c348dc738aeaa7382f0d4496f33beb2083e0e9c28724d73d50356a.
- api-spans.json gives unique reversible text spans; all nine 13w core+API changes invert exactly to c82.
- reconstruct-api.cjs <repo> <fresh external directory> reconstructs source only. It never loads the service or runs tests.

POST /api/external-bots/deliveries/retry requires the existing local header token and origin gates, rejects queries and extra body keys, and accepts {id, expectedAttemptId, retryRequestId}. The request ID must remain stable for the same user action, including a lost response.

Within the original state chain the existing core requires the current known-unsubmitted failed attempt and current original owner/credentials, commits complete immutable prior-attempt history and a new pending reply as payload4, then returns its durable receipt. Only a newly committed result wakes the original worker; alreadyRetried never wakes. A disconnected caller does not discard a successfully committed action. A writer that reports uncertainty after commit produces a failure without wake; a repeated request reconciles durable history only. This deliberately does not claim automatic recovery/resend from an ambiguous write result.

The original run/sender/nextJob/finish/recover/Store/privacy paths are byte unchanged. A real-source VM test follows wake -> drain -> nextJob -> actual 13x token and message code with modeled HTTPS/PrivacyGateway and confirms a single protected MESSAGE and zero business reruns. This is not a real HTTP server/platform test.

Pure evidence:
- Original core assertions: 45/45, only core filename adapted; 1/1 original physical-capacity case, only core/baseline filenames adapted.
- New real handler tests: 16/16 twice; final adds an assertion that the exact path is handled so baseline negative fails ERR_ASSERTION.
- Seven explicit negatives: live c82 without API; token gate removed; retry origin gate removed; duplicate wake; state serialization removed; precommit wake; physical capacity removed. Each exits 1 and ERR_ASSERTION.
- api-first.log (16 pass) and unchanged original logs retained. No unexpected candidate first failure occurred in these runs; expected baseline and removed-guard reds are separate evidence. Historic draft first failures remain in the repository, not rewritten.

No working tree edit, generated server/build/native/socket/fullsuite/UI or real platform send occurred. Root-owned working changes were left untouched.

Admission requested only for root independent review of this exact core + two backend source candidates and focused pure tests. Before production promotion, add permanent tests and original historical-reader fixtures, update generated route/dependency/facts/egress inventories through their generators, build then run isolated actual HTTP/e2e and relevant checks. UI stable request lifecycle/history/compatibility notices, retention/reclamation, 429 cooldown/protocol rules, trustworthy unknown-delivery reconciliation and real QQ/Feishu remain unfinished. This candidate does not complete B1 or 3.1.
