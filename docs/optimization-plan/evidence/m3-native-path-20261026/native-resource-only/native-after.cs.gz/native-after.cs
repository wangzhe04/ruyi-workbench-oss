
using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using Microsoft.Win32.SafeHandles;

// This process owns one skill's original NTFS objects. It never receives an encryption key.
public static class RuyiSkillCapsule {
  [StructLayout(LayoutKind.Sequential)] struct Info {
    public uint Attr; public System.Runtime.InteropServices.ComTypes.FILETIME Creation, Access, Write;
    public uint Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
  }
  [StructLayout(LayoutKind.Sequential)] struct Basic { public long Creation, Access, Write, Change; public uint Attr; }
  [StructLayout(LayoutKind.Explicit,Size=24)] struct FileIdDescriptor {
    [FieldOffset(0)] public uint Size; [FieldOffset(4)] public int Type;
    [FieldOffset(8)] public long FileId; [FieldOffset(16)] public long Reserved;
  }
  [StructLayout(LayoutKind.Sequential)] struct RelativeName { public ushort Length, MaximumLength; public IntPtr Buffer; }
  [StructLayout(LayoutKind.Sequential)] struct RelativeAttributes { public uint Length; public IntPtr RootDirectory, ObjectName; public uint Attributes; public IntPtr SecurityDescriptor, SecurityQualityOfService; }
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern SafeFileHandle CreateFile(string p, uint access, uint share, IntPtr security, uint mode, uint flags, IntPtr template);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandle(SafeFileHandle h, out Info value);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandleEx(SafeFileHandle h, int kind, out Basic value, uint size);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool SetFileInformationByHandle(SafeFileHandle h, int kind, IntPtr value, uint size);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool ReadFile(SafeFileHandle h, byte[] buffer, uint count, out uint read, IntPtr overlap);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool WriteFile(SafeFileHandle h, byte[] buffer, uint count, out uint wrote, IntPtr overlap);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool SetFilePointerEx(SafeFileHandle h, long offset, out long result, uint method);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool SetEndOfFile(SafeFileHandle h);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileSizeEx(SafeFileHandle h, out long size);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool FlushFileBuffers(SafeFileHandle h);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool BackupRead(SafeFileHandle h, byte[] buffer, uint count, out uint read, bool abort, bool security, ref IntPtr context);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool BackupSeek(SafeFileHandle h, uint low, uint high, out uint doneLow, out uint doneHigh, ref IntPtr context);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern uint GetFinalPathNameByHandle(SafeFileHandle h, StringBuilder path, uint size, uint flags);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern bool GetVolumeInformationByHandleW(SafeFileHandle h, StringBuilder volume, uint volumeSize, out uint serial, out uint component, out uint flags, StringBuilder filesystem, uint filesystemSize);
  [DllImport("ntdll.dll")] static extern int NtSetInformationFile(SafeFileHandle h, IntPtr iosb, IntPtr value, uint length, int kind);
  [DllImport("ntdll.dll")] static extern uint RtlNtStatusToDosError(int status);
  [DllImport("ntdll.dll")] static extern int NtQueryInformationFile(SafeFileHandle h,IntPtr iosb,IntPtr value,uint length,int kind);
  [DllImport("kernel32.dll",SetLastError=true)] static extern SafeFileHandle OpenFileById(SafeFileHandle volumeHint,ref FileIdDescriptor descriptor,uint access,uint share,IntPtr security,uint flags);
  [DllImport("ntdll.dll")] static extern int NtCreateFile(out SafeFileHandle handle,uint access,ref RelativeAttributes attributes,IntPtr iosb,IntPtr allocation,uint fileAttrs,uint share,uint disposition,uint options,IntPtr ea,uint eaLength);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool MoveFileExW(string source,string target,uint flags);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool SetFileShortName(SafeFileHandle h,string name);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CheckNameLegalDOS8Dot3(string name,IntPtr oem,uint size,out bool spaces,out bool legal);
  static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = 180000000, RecursionLimit = 512 };
  static readonly Dictionary<string, Node> Nodes = new Dictionary<string, Node>();
  static Dictionary<string,object> Snapshot;
  static SafeFileHandle Capsule;
  static string OriginalRoot;
  static long MaxBytes = 96000000, TotalBytes;
  static string Step = "idle";
  static bool PreserveTimeHandles = false;
  sealed class Node {
    public SafeFileHandle Handle; public bool Writable; public Dictionary<string,object> Entry;
    public Dictionary<string,SafeFileHandle> Streams = new Dictionary<string,SafeFileHandle>();
    public HashSet<string> ReadOnlyStreams = new HashSet<string>();
  }
  static Dictionary<string,object> Dict(object value) { return (Dictionary<string,object>)value; }
  static string Str(object value) { return Convert.ToString(value, System.Globalization.CultureInfo.InvariantCulture); }
  static void Check(bool ok) { if (!ok) throw new Win32Exception(Marshal.GetLastWin32Error()); }
  static void Reject(string reason) { throw new InvalidOperationException(reason); }
  static SafeFileHandle Open(string file) {
    bool ignored; return Open(file, out ignored);
  }
  static SafeFileHandle Open(string file, out bool writable, bool dataStream = false) {
    // Known DATA streams exclude existing writers. Directories/new streams require
    // explicit set verification; Windows sharing is per-stream, not per-tree.
    FileAttributes attributes = File.GetAttributes(file);
    bool directory = !dataStream && (attributes & FileAttributes.Directory) != 0, readOnly = (attributes & FileAttributes.ReadOnly) != 0;
    writable = !directory && !readOnly;
    SafeFileHandle handle = CreateFile(file, CapturedDirectoryWrite && directory ? 0xC0010100u : writable ? 0xC0010000u : 0x80010100u, directory ? 7u : 5u, IntPtr.Zero, 3, 0x02200000, IntPtr.Zero);
    if (handle.IsInvalid) { handle.Dispose(); throw new Win32Exception(Marshal.GetLastWin32Error()); }
    if(PreserveTimeHandles) {try {PreserveHandleTimes(handle);} catch {handle.Dispose();throw;}}
    return handle;
  }
  static string Id(SafeFileHandle handle) {
    Info info; Check(GetFileInformationByHandle(handle, out info));
    // Only SetBasic-restorable ordinary attributes. Reparse/EFS/sparse/compressed,
    // integrity/provider-specific metadata and multiple links need a different codec.
    if ((info.Attr & ~0x31b7u) != 0 || (info.Attr & 0x10u) == 0 && info.Links != 1) Reject("unsupported_object");
    return info.Volume.ToString("x8") + info.IndexHigh.ToString("x8") + info.IndexLow.ToString("x8");
  }
  static string PathOf(SafeFileHandle handle) {
    StringBuilder value = new StringBuilder(32768);
    uint count = GetFinalPathNameByHandle(handle, value, (uint)value.Capacity, 0);
    if (count == 0 || count >= value.Capacity) throw new Win32Exception(Marshal.GetLastWin32Error());
    return value.ToString();
  }
  static string VolumeOf(SafeFileHandle handle) {
    StringBuilder value = new StringBuilder(32768);
    uint count = GetFinalPathNameByHandle(handle,value,(uint)value.Capacity,1);
    if (count==0 || count>=value.Capacity) throw new Win32Exception(Marshal.GetLastWin32Error());
    string path=value.ToString(); int end=path.IndexOf('}');
    if (!path.StartsWith(@"\\?\Volume{",StringComparison.OrdinalIgnoreCase) || end<0) Reject("volume_unsupported");
    return path.Substring(0,end+1);
  }
  static string ShortName(SafeFileHandle handle) {
    IntPtr iosb=Marshal.AllocHGlobal(IntPtr.Size*2), value=Marshal.AllocHGlobal(1024);
    try {
      int status=NtQueryInformationFile(handle,iosb,value,1024,21);
      if (status==unchecked((int)0xc0000034)) return "";
      if (status<0) throw new Win32Exception((int)RtlNtStatusToDosError(status));
      int length=Marshal.ReadInt32(value);
      if (length<0 || length>24 || length%2!=0) Reject("short_name_shape");
      return Marshal.PtrToStringUni(IntPtr.Add(value,4),length/2);
    } finally { Marshal.FreeHGlobal(value); Marshal.FreeHGlobal(iosb); }
  }
  static void LegalShortName(string name) {
    if (name=="") return;
    bool spaces,legal; Check(CheckNameLegalDOS8Dot3(name,IntPtr.Zero,0,out spaces,out legal));
    if (spaces || !legal) Reject("unsupported_short_name");
  }
  static void ProbeShortNames(Dictionary<string,object> args) {
    string file=System.IO.Path.Combine(Str(args["root"]),".ruyi-short-probe-"+RandomName());
    // The same access as original directories/readonly files. Older platforms
    // needing SeRestorePrivilege fail here, before touching any original object.
    using (SafeFileHandle handle=CreateFile(file,0x80010100u,7,IntPtr.Zero,1,0x06000000u,IntPtr.Zero)) {
      if(handle.IsInvalid) throw new Win32Exception(Marshal.GetLastWin32Error());
      string name="RC"+RandomName().Substring(0,6).ToUpperInvariant()+".TMP";
      Check(SetFileShortName(handle,name));
      if(!String.Equals(ShortName(handle),name,StringComparison.OrdinalIgnoreCase)) Reject("short_name_capability");
      Check(SetFileShortName(handle,""));
      if(ShortName(handle)!="") Reject("short_name_capability");
    }
  }
  static string RandomName() {
    byte[] bytes = new byte[32]; using (RandomNumberGenerator rng = RandomNumberGenerator.Create()) rng.GetBytes(bytes);
    return BitConverter.ToString(bytes).Replace("-", "").ToLowerInvariant();
  }
  static string Hash(byte[] bytes) { using (SHA256 hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
  static void Rewind(SafeFileHandle handle) { long position; Check(SetFilePointerEx(handle, 0, out position, 0)); }
  static byte[] Read(SafeFileHandle handle) {
    long size; Check(GetFileSizeEx(handle, out size));
    if (size < 0 || size > MaxBytes) Reject("archive_limit");
    byte[] result = new byte[(int)size]; Rewind(handle);
    int used = 0;
    while (used < result.Length) {
      byte[] buffer = new byte[Math.Min(65536, result.Length - used)]; uint got;
      Check(ReadFile(handle, buffer, (uint)buffer.Length, out got, IntPtr.Zero));
      if (got == 0) Reject("source_changed");
      Buffer.BlockCopy(buffer, 0, result, used, (int)got); used += (int)got;
    }
    byte[] extra = new byte[1]; uint extraRead; Check(ReadFile(handle, extra, 1, out extraRead, IntPtr.Zero));
    if (extraRead != 0) Reject("source_changed");
    return result;
  }
  static void Write(SafeFileHandle handle, byte[] bytes) {
    Rewind(handle); int offset = 0;
    while (offset < bytes.Length) {
      byte[] buffer = new byte[Math.Min(65536, bytes.Length - offset)];
      Buffer.BlockCopy(bytes, offset, buffer, 0, buffer.Length); uint wrote;
      Check(WriteFile(handle, buffer, (uint)buffer.Length, out wrote, IntPtr.Zero));
      if (wrote == 0) Reject("write_failed"); offset += (int)wrote;
    }
    Check(SetEndOfFile(handle)); Check(FlushFileBuffers(handle));
  }
  static byte[] BackupBytes(SafeFileHandle handle, int count, ref IntPtr context, bool eofAllowed) {
    byte[] result = new byte[count]; int used = 0;
    while (used < count) {
      byte[] buffer = new byte[count - used]; uint got;
      Check(BackupRead(handle, buffer, (uint)buffer.Length, out got, false, false, ref context));
      if (got == 0) { if (used == 0 && eofAllowed) return null; Reject("stream_header"); }
      Buffer.BlockCopy(buffer, 0, result, used, (int)got); used += (int)got;
    }
    return result;
  }
  static List<string> StreamNames(Node node) {
    List<string> names = new List<string>(); IntPtr context = IntPtr.Zero;
    try {
      while (true) {
        byte[] header = BackupBytes(node.Handle, 20, ref context, true); if (header == null) break;
        uint kind = BitConverter.ToUInt32(header, 0), flags = BitConverter.ToUInt32(header, 4), length = BitConverter.ToUInt32(header, 16);
        long size = BitConverter.ToInt64(header, 8);
        if (length > 65536 || size < 0 || size > MaxBytes || flags != 0) Reject("unsupported_stream");
        string name = length == 0 ? "" : Encoding.Unicode.GetString(BackupBytes(node.Handle, (int)length, ref context, false));
        if (kind != 1 && kind != 4) Reject("unsupported_stream");
        if (kind == 4 && (!name.StartsWith(":") || !name.EndsWith(":$DATA") || name.IndexOf('\0') >= 0)) Reject("stream_name");
        if (kind == 1) name = "";
        if (names.Contains(name)) Reject("stream_duplicate"); names.Add(name);
        uint low, high; Check(BackupSeek(node.Handle, (uint)size, (uint)((ulong)size >> 32), out low, out high, ref context));
        if ((((ulong)high << 32) | low) != (ulong)size) Reject("stream_seek");
      }
    } finally { uint ignored; BackupRead(node.Handle, new byte[1], 0, out ignored, true, false, ref context); }
    // BackupRead may omit the unnamed DATA header for an empty ordinary file.
    if ((BasicOf(node.Handle).Attr & 0x10u) == 0 && !names.Contains("")) {
      long size; Check(GetFileSizeEx(node.Handle, out size));
      if (size != 0) Reject("default_stream_missing"); names.Add("");
    }
    return names;
  }
  static Basic BasicOf(SafeFileHandle handle) { Basic info; Check(GetFileInformationByHandleEx(handle, 0, out info, (uint)Marshal.SizeOf(typeof(Basic)))); return info; }
  static void Walk(string path, string rel, List<object> entries, bool capture) {
    if (entries.Count >= 10000 || rel.Split('/').Length > 256) Reject("archive_limit");
    Node node = new Node(); node.Handle = Open(path, out node.Writable);
    try {
      string id = Id(node.Handle); if (Nodes.ContainsKey(id)) Reject("object_duplicate");
      Basic basic = BasicOf(node.Handle); bool directory = (basic.Attr & 0x10u) != 0;
      node.Entry = new Dictionary<string,object> { { "rel", rel }, { "opaque", RandomName() }, { "id", id }, { "dir", directory }, { "attrs", basic.Attr },
        { "shortName", ShortName(node.Handle) }, { "times", new string[] { Str(basic.Creation), Str(basic.Access), Str(basic.Write), Str(basic.Change) } } };
      LegalShortName(Str(node.Entry["shortName"]));
      Nodes.Add(id, node); entries.Add(node.Entry);
      List<object> streams = new List<object>();
      foreach (string name in StreamNames(node)) {
        if (directory && name == "") Reject("directory_data");
        bool writable = node.Writable;
        SafeFileHandle handle = name == "" ? node.Handle : Open(PathOf(node.Handle) + name, out writable, true);
        if (name != "") { node.Streams.Add(name, handle); if (!writable) node.ReadOnlyStreams.Add(name); }
        if (capture) {
          byte[] bytes = Read(handle); TotalBytes += bytes.Length;
          if (TotalBytes > MaxBytes) Reject("archive_limit");
          streams.Add(new Dictionary<string,object> { { "name", name }, { "size", bytes.Length }, { "hash", Hash(bytes) }, { "data", Convert.ToBase64String(bytes) } });
          Array.Clear(bytes, 0, bytes.Length);
        }
      }
      if (!directory && !StreamNames(node).Contains("")) Reject("default_stream_missing");
      node.Entry["streams"] = streams;
      if (directory) foreach (string child in Directory.GetFileSystemEntries(path)) Walk(child, rel == "" ? System.IO.Path.GetFileName(child) : rel + "/" + System.IO.Path.GetFileName(child), entries, capture);
    } catch { if (!Nodes.ContainsValue(node)) node.Handle.Dispose(); throw; }
  }
  static object Capture(Dictionary<string,object> args) {
    if (Nodes.Count != 0) Reject("already_open"); TotalBytes = 0;
    List<object> entries = new List<object>(); Walk(Str(args["root"]), "", entries, true);
    StringBuilder filesystem = new StringBuilder(64); uint serial, component, flags;
    Check(GetVolumeInformationByHandleW(RootNode().Handle, null, 0, out serial, out component, out flags, filesystem, 64));
    if (filesystem.ToString() != "NTFS") Reject("filesystem_unsupported");
    Snapshot = new Dictionary<string,object> { { "schema", 1 }, { "platform", "ntfs-objects-v1" }, { "revision", Str(args["revision"]) }, { "entries", entries } };
    OriginalRoot = PathOf(RootNode().Handle);
    VerifyOriginalLayout(); Verify(false, true); return Snapshot;
  }
  static void Attach(Dictionary<string,object> args) {
    if (Nodes.Count != 0) Reject("already_open"); Snapshot = Dict(args["snapshot"]);
    List<object> current = new List<object>();
    foreach (object root in (IEnumerable)args["roots"]) Walk(Str(root), "", current, false);
    foreach (object raw in (IEnumerable)Snapshot["entries"]) {
      Dictionary<string,object> entry = Dict(raw); string id = Str(entry["id"]);
      LegalShortName(Str(entry["shortName"]));
      if (!Nodes.ContainsKey(id)) Reject("object_missing"); Nodes[id].Entry = entry;
    }
    if (current.Count != Expected().Count) Reject("entry_set_changed");
  }
  static void Rename(Node node, string target, SafeFileHandle parent = null) {
    string current = PathOf(node.Handle);
    string fullTarget = parent == null ? target : System.IO.Path.Combine(PathOf(parent), target);
    if (String.Equals(current, fullTarget, StringComparison.OrdinalIgnoreCase)) return;
    byte[] name = Encoding.Unicode.GetBytes(target); int offset = IntPtr.Size == 8 ? 20 : 12;
    IntPtr value = Marshal.AllocHGlobal(offset + name.Length);
    try {
      for (int i=0;i<offset + name.Length;i++) Marshal.WriteByte(value, i, 0);
      if (parent != null) Marshal.WriteIntPtr(value, IntPtr.Size == 8 ? 8 : 4, parent.DangerousGetHandle());
      Marshal.WriteInt32(value, IntPtr.Size == 8 ? 16 : 8, name.Length); Marshal.Copy(name, 0, IntPtr.Add(value, offset), name.Length);
      IntPtr iosb = Marshal.AllocHGlobal(IntPtr.Size * 2);
      try { int status = NtSetInformationFile(node.Handle, iosb, value, (uint)(offset + name.Length), 10); if (status < 0) throw new Win32Exception((int)RtlNtStatusToDosError(status)); }
      finally { Marshal.FreeHGlobal(iosb); }
    } finally { Marshal.FreeHGlobal(value); }
  }
  static Node RootNode() { foreach (Node node in Nodes.Values) if (Str(node.Entry["rel"]) == "") return node; throw new InvalidOperationException("root_missing"); }
  static List<Node> Expected() {
    List<Node> result = new List<Node>(); foreach (object raw in (IEnumerable)Snapshot["entries"]) result.Add(Nodes[Str(Dict(raw)["id"])]); return result;
  }
  static void DeleteStream(SafeFileHandle handle) {
    IntPtr value = Marshal.AllocHGlobal(1);
    try { Marshal.WriteByte(value, 1); Check(SetFileInformationByHandle(handle, 4, value, 1)); }
    finally { Marshal.FreeHGlobal(value); handle.Dispose(); }
  }
  static void UpgradeStream(Node node, string name) {
    SafeFileHandle old = name == "" ? node.Handle : node.Streams[name];
    string path = PathOf(old), expected = Id(old);
    // This attribute-only guard remains bound to the original object during the
    // short read-only DATA-handle handoff. It never bypasses another DATA writer.
    SafeFileHandle guard = CreateFile(path,0x180u,7,IntPtr.Zero,3,0x02200000,IntPtr.Zero);
    if (guard.IsInvalid) { guard.Dispose(); throw new Win32Exception(Marshal.GetLastWin32Error()); }
    if (Id(guard) != expected) { guard.Dispose(); Reject("identity_changed"); }
    old.Dispose();
    SafeFileHandle replacement = CreateFile(path,0xC0010000u,5,IntPtr.Zero,3,0x02200000,IntPtr.Zero);
    int failure = replacement.IsInvalid ? Marshal.GetLastWin32Error() : 0;
    if (failure != 0 || Id(replacement) != expected) {
      replacement.Dispose();
      if (name == "") node.Handle=guard; else node.Streams[name]=guard;
      RestoreNodeBasic(node,guard);
      if (failure != 0) throw new Win32Exception(failure);
      Reject("identity_changed");
    }
    guard.Dispose();
    if (name == "") { node.Handle=replacement; node.Writable=true; } else node.Streams[name]=replacement;
  }
  static void EnsureWritable(Node node) {
    Basic basic = BasicOf(node.Handle);
    if ((basic.Attr & 1u) != 0) {
      // A read-only ordinary file can be renamed, but cannot be truncated until
      // its attribute is cleared. This runs only after the durable archive/intent.
      basic.Attr &= ~1u; IntPtr value = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Basic)));
      try { Marshal.StructureToPtr(basic,value,false); Check(SetFileInformationByHandle(node.Handle,0,value,(uint)Marshal.SizeOf(typeof(Basic)))); }
      finally { Marshal.FreeHGlobal(value); }
    }
    if (!(bool)node.Entry["dir"] && !node.Writable) UpgradeStream(node, "");
    foreach (string name in new List<string>(node.ReadOnlyStreams)) UpgradeStream(node, name);
    node.ReadOnlyStreams.Clear();
  }
  static void Verify(bool cleared, bool exact) {
    List<Node> expected = Expected(); if (exact && expected.Count != Nodes.Count) Reject("entry_set_changed");
    VerifyEntries(expected);
    foreach (Node node in expected) {
      if (Id(node.Handle) != Str(node.Entry["id"])) Reject("identity_changed");
      List<string> current = StreamNames(node), names = new List<string>();
      foreach (object raw in (IEnumerable)node.Entry["streams"]) names.Add(Str(Dict(raw)["name"]));
      foreach (string name in current) if (!names.Contains(name) || cleared && name != "") Reject("stream_set_changed");
      if (cleared) {
        if (ShortName(node.Handle)!="") Reject("short_name_not_cleared");
        if (!(bool)node.Entry["dir"]) { long size; Check(GetFileSizeEx(node.Handle, out size)); if (size != 0) Reject("not_cleared"); }
      } else {
        foreach (object raw in (IEnumerable)node.Entry["streams"]) {
          Dictionary<string,object> stream = Dict(raw); string name = Str(stream["name"]);
          if (!current.Contains(name)) Reject("stream_missing");
          SafeFileHandle handle = name == "" ? node.Handle : node.Streams[name];
          byte[] bytes = Read(handle); if (Hash(bytes) != Str(stream["hash"])) Reject("content_changed"); Array.Clear(bytes, 0, bytes.Length);
        }
      }
    }
  }
  static void VerifyEntries(List<Node> expected) {
    HashSet<string> paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    foreach (Node node in expected) paths.Add(PathOf(node.Handle));
    foreach (Node node in expected) if ((bool)node.Entry["dir"]) {
      foreach (string child in Directory.GetFileSystemEntries(PathOf(node.Handle))) {
        if (!paths.Contains(child)) Reject("entry_set_changed");
      }
    }
  }
  static void VerifyOriginalLayout() {
    if (!String.Equals(PathOf(RootNode().Handle), OriginalRoot, StringComparison.OrdinalIgnoreCase)) Reject("root_changed");
    foreach (Node node in Expected()) {
      string rel = Str(node.Entry["rel"]);
      string expected = rel == "" ? OriginalRoot : System.IO.Path.Combine(OriginalRoot, rel.Replace('/', '\\'));
      if (!String.Equals(PathOf(node.Handle), expected, StringComparison.OrdinalIgnoreCase)) Reject("entry_set_changed");
      if (!String.Equals(ShortName(node.Handle),Str(node.Entry["shortName"]),StringComparison.OrdinalIgnoreCase)) Reject("short_name_changed");
    }
  }
  static bool IsPrefix(byte[] actual,string encoded) {
    byte[] expected=Convert.FromBase64String(encoded);
    try { if(actual.Length>expected.Length)return false;for(int i=0;i<actual.Length;i++)if(actual[i]!=expected[i])return false;return true; }
    finally { Array.Clear(expected,0,expected.Length); }
  }
  static void VerifyRestorable(Dictionary<string,object> alternate = null) {
    List<Node> expected = Expected(); VerifyEntries(expected);
    foreach (Node node in expected) {
      Dictionary<string,object> streams = new Dictionary<string,object>();
      foreach (object raw in (IEnumerable)node.Entry["streams"]) streams.Add(Str(Dict(raw)["name"]), raw);
      foreach (string name in StreamNames(node)) {
        if (!streams.ContainsKey(name)) Reject("stream_set_changed");
        SafeFileHandle handle = name == "" ? node.Handle : node.Streams[name];
        byte[] actual = Read(handle);
        try {
          bool valid=IsPrefix(actual,Str(Dict(streams[name])["data"]));
          if(!valid && alternate!=null) foreach(object raw in (IEnumerable)alternate["entries"]) {
            Dictionary<string,object> entry=Dict(raw);if(Str(entry["id"])!=Str(node.Entry["id"]))continue;
            foreach(object streamRaw in (IEnumerable)entry["streams"]) { Dictionary<string,object> stream=Dict(streamRaw);
              if(Str(stream["name"])==name && IsPrefix(actual,Str(stream["data"])))valid=true;
            }
          }
          if(!valid)Reject("content_changed");
        } finally { Array.Clear(actual,0,actual.Length); }
      }
    }
  }
  static void Seal(Dictionary<string,object> args) {
    // Detect unknown nodes/streams before clearing any data, then verify again afterwards.
    List<Node> expected = Expected(); if (expected.Count != Nodes.Count) Reject("entry_set_changed");
    VerifyOriginalLayout();
    Verify(false, true);
    foreach (Node node in expected) {
      List<string> allowed = new List<string>(); foreach (object raw in (IEnumerable)node.Entry["streams"]) allowed.Add(Str(Dict(raw)["name"]));
      foreach (string name in StreamNames(node)) if (!allowed.Contains(name)) Reject("stream_set_changed");
    }
    if (Capsule == null) Capsule = Open(Str(args["container"]));
    Id(Capsule);
    if (!String.Equals(VolumeOf(Capsule),VolumeOf(RootNode().Handle),StringComparison.OrdinalIgnoreCase)) Reject("cross_volume");
    // Upgrade every initially read-only DATA stream before clearing any object.
    // A new writer in a handoff gap causes rejection with the original Basic restored.
    try { foreach (Node node in expected) EnsureWritable(node); }
    catch { RestoreBasic(expected); throw; }
    VerifyOriginalLayout(); Verify(false,true);
    expected.Sort(delegate(Node a, Node b) { return Str(b.Entry["rel"]).Length.CompareTo(Str(a.Entry["rel"]).Length); });
    foreach (Node node in expected) {
      if (!String.Equals(PathOf(RootNode().Handle), OriginalRoot, StringComparison.OrdinalIgnoreCase)) Reject("root_changed");
      string rel = Str(node.Entry["rel"]);
      string expectedPath = rel == "" ? OriginalRoot : System.IO.Path.Combine(OriginalRoot, rel.Replace('/', '\\'));
      if (!String.Equals(PathOf(node.Handle), expectedPath, StringComparison.OrdinalIgnoreCase)) Reject("entry_set_changed");
      Id(node.Handle);
      // Upgrade of an initially read-only handle must exclude pre-existing
      // writers and revalidate its authenticated content before the first clear.
      foreach (object raw in (IEnumerable)node.Entry["streams"]) {
        Dictionary<string,object> stream=Dict(raw); string name=Str(stream["name"]);
        byte[] bytes=Read(name==""?node.Handle:node.Streams[name]);
        if (Hash(bytes)!=Str(stream["hash"])) Reject("content_changed"); Array.Clear(bytes,0,bytes.Length);
      }
      Step = "truncate";
      if (!(bool)node.Entry["dir"]) Write(node.Handle, new byte[0]);
      Step = "delete-stream";
      foreach (SafeFileHandle handle in node.Streams.Values) DeleteStream(handle); node.Streams.Clear(); node.ReadOnlyStreams.Clear();
      Step = "rename-node";
      Rename(node, Str(node.Entry["opaque"]), Capsule);
      Check(SetFileShortName(node.Handle,""));
    }
    Verify(true, true);
    string[] actual = Directory.GetFileSystemEntries(PathOf(Capsule)); if (actual.Length != expected.Count) Reject("entry_set_changed");
  }
  static void SetAlias(Node node,string name) {
    LegalShortName(name);
    if (String.Equals(ShortName(node.Handle),name,StringComparison.OrdinalIgnoreCase)) return;
    // NTFS refuses directory short-name mutation while a descendant is open.
    // Child directories are still empty; Publish handles the root after releasing descendants.
    Step="alias-remove"; Check(SetFileShortName(node.Handle,""));
    if(name!="") { Step="alias-set"; Check(SetFileShortName(node.Handle,name)); }
    if(!String.Equals(ShortName(node.Handle),name,StringComparison.OrdinalIgnoreCase)) Reject("short_name_changed");
  }
  static void Flatten(List<Node> expected,bool root) {
    expected.Sort(delegate(Node a,Node b){return PathOf(b.Handle).Length.CompareTo(PathOf(a.Handle).Length);});
    foreach(Node node in expected) {
      if(!root && Str(node.Entry["rel"])=="") continue;
      VerifyEntries(expected);
      Step="flatten-node"; Rename(node,Str(node.Entry["opaque"]),Capsule); SetAlias(node,"");
    }
  }
  static void Assemble(List<Node> expected) {
    expected.Sort(delegate(Node a,Node b){return Str(a.Entry["rel"]).Length.CompareTo(Str(b.Entry["rel"]).Length);});
    Dictionary<string,Node> parents=new Dictionary<string,Node>();
    foreach(Node node in expected) parents.Add(Str(node.Entry["rel"]),node);
    foreach(Node node in expected) {
      string rel=Str(node.Entry["rel"]); if(rel=="") continue;
      VerifyEntries(expected);
      int slash=rel.LastIndexOf('/');string parentRel=slash<0?"":rel.Substring(0,slash);
      string name=slash<0?rel:rel.Substring(slash+1),alias=Str(node.Entry["shortName"]);
      if(String.Equals(name,alias,StringComparison.OrdinalIgnoreCase)) SetAlias(node,alias);
      Step="restore-child"; Rename(node,name,parents[parentRel].Handle);
      SetAlias(node,alias);
    }
  }
  static void VerifyNames(string root,bool rootAlias) {
    if(!root.StartsWith(@"\\?\")) root=@"\\?\"+System.IO.Path.GetFullPath(root);
    foreach(Node node in Expected()) {
      string rel=Str(node.Entry["rel"]),target=rel==""?root:System.IO.Path.Combine(root,rel.Replace('/','\\'));
      if(!String.Equals(PathOf(node.Handle),target,StringComparison.OrdinalIgnoreCase)) Reject("entry_set_changed");
      if((rootAlias || rel!="") && !String.Equals(ShortName(node.Handle),Str(node.Entry["shortName"]),StringComparison.OrdinalIgnoreCase)) Reject("short_name_changed");
    }
  }
  static void Restore(Dictionary<string,object> args) {
    VerifyRestorable(args.ContainsKey("allowedSnapshot") ? Dict(args["allowedSnapshot"]) : null);
    List<Node> expected=Expected();
    if(Capsule==null) Capsule=Open(Str(args["container"]));
    foreach(Node node in expected) EnsureWritable(node);
    Flatten(expected,true);
    Step="restore-root";
    using(SafeFileHandle parent=Open(System.IO.Path.GetDirectoryName(Str(args["target"])))) Rename(RootNode(),System.IO.Path.GetFileName(Str(args["target"])),parent);
    SetAlias(RootNode(),""); Assemble(expected);
    foreach(Node node in expected) {
      foreach(object raw in (IEnumerable)node.Entry["streams"]) {
        Dictionary<string,object> stream=Dict(raw);string name=Str(stream["name"]);
        byte[] bytes=Convert.FromBase64String(Str(stream["data"]));
        if(bytes.Length!=Convert.ToInt32(stream["size"]) || Hash(bytes)!=Str(stream["hash"])) Reject("archive_content");
        SafeFileHandle handle;
        if(name=="") handle=node.Handle;
        else if(!node.Streams.TryGetValue(name,out handle)) {
          handle=CreateFile(PathOf(node.Handle)+name,0xC0010000,5,IntPtr.Zero,4,0,IntPtr.Zero);
          if(handle.IsInvalid) throw new Win32Exception(Marshal.GetLastWin32Error());node.Streams.Add(name,handle);
        }
        Step="restore-content";
        // A representation conversion can shrink an existing managed stream.
        // Clear first so a crash never leaves an unrecognizable old-data suffix.
        if(args.ContainsKey("allowedSnapshot"))Write(handle,new byte[0]);
        Write(handle,bytes);Array.Clear(bytes,0,bytes.Length);
      }
    }
    Step="restore-verify";Verify(false,true);VerifyNames(Str(args["target"]),false);RestoreBasic(expected);
  }
  static void CheckPublication(Dictionary<string,object> args) {
    string alias=Str(RootNode().Entry["shortName"]);if(alias=="") return;
    string candidate=System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Str(args["target"])),alias);
    using(SafeFileHandle handle=CreateFile(candidate,0x80u,7,IntPtr.Zero,3,0x02200000,IntPtr.Zero)) {
      if(handle.IsInvalid) { int code=Marshal.GetLastWin32Error();if(code==2 || code==3)return;throw new Win32Exception(code); }
      string id=Id(handle);
      if(id!=Str(RootNode().Entry["id"]) && (!args.ContainsKey("allowedId") || id!=Str(args["allowedId"]))) Reject("root_alias_collision");
    }
  }
  static void FinishPublished(Dictionary<string,object> args) {
    // An already visible old root can still be between publication and final
    // alias/Basic restoration. Relock and verify the original objects before completing.
    Verify(false,true); Publish(args);
  }
  static void RestoreBasic(List<Node> source) {
    List<Node> expected = new List<Node>(source);
    expected.Sort(delegate(Node a, Node b) { return Str(b.Entry["rel"]).Length.CompareTo(Str(a.Entry["rel"]).Length); });
    foreach (Node node in expected) RestoreNodeBasic(node,node.Handle);
  }
  static void RestoreNodeBasic(Node node, SafeFileHandle handle) {
      List<string> times = new List<string>(); foreach (object raw in (IEnumerable)node.Entry["times"]) times.Add(Str(raw));
      Basic info = new Basic { Creation=long.Parse(times[0]), Access=long.Parse(times[1]), Write=long.Parse(times[2]), Change=long.Parse(times[3]), Attr=Convert.ToUInt32(node.Entry["attrs"]) };
      IntPtr value = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Basic)));
      Step="restore-basic";
      try { Marshal.StructureToPtr(info, value, false); Check(SetFileInformationByHandle(handle, 0, value, (uint)Marshal.SizeOf(typeof(Basic)))); }
      finally { Marshal.FreeHGlobal(value); }
      Basic actual = BasicOf(handle);
      if (actual.Creation != info.Creation || actual.Access != info.Access || actual.Write != info.Write
          || actual.Change != info.Change || actual.Attr != info.Attr) Reject("metadata_changed");
  }
  static void Publish(Dictionary<string,object> args) {
    Verify(false,true); CheckPublication(args);
    Node root=RootNode();
    foreach(Node node in Nodes.Values) {
      foreach(SafeFileHandle stream in node.Streams.Values) stream.Dispose();node.Streams.Clear();
      if(node!=root) node.Handle.Dispose();
    }
    string error=null;
    try {
      string name=System.IO.Path.GetFileName(Str(args["target"]));
      string alias=Str(root.Entry["shortName"]);
      if(String.Equals(alias,name,StringComparison.OrdinalIgnoreCase)) SetAlias(root,alias);
      using(SafeFileHandle parent=Open(System.IO.Path.GetDirectoryName(Str(args["target"])))) Rename(root,name,parent);
      SetAlias(root,alias);
    } catch(Win32Exception failure) { error="publish_win32_"+failure.NativeErrorCode; }
    string current=PathOf(root.Handle);root.Handle.Dispose();Nodes.Clear();
    List<object> entries=new List<object>();Walk(current,"",entries,false);
    foreach(object raw in (IEnumerable)Snapshot["entries"]) {
      Dictionary<string,object> entry=Dict(raw);string id=Str(entry["id"]);
      if(!Nodes.ContainsKey(id)) Reject("object_missing");Nodes[id].Entry=entry;
    }
    Verify(false,true);
    if(error!=null) Reject(error);
    VerifyNames(Str(args["target"]),true);RestoreBasic(Expected());
  }
  static void Close() {
    foreach (Node node in Nodes.Values) { foreach (SafeFileHandle stream in node.Streams.Values) stream.Dispose(); node.Handle.Dispose(); }
    Nodes.Clear(); Snapshot = null; OriginalRoot = null; if (Capsule != null) { Capsule.Dispose(); Capsule = null; }
  }
  static void StoreFileSystem(SafeFileHandle handle) {
    StringBuilder filesystem=new StringBuilder(64);uint serial,component,flags;
    Check(GetVolumeInformationByHandleW(handle,null,0,out serial,out component,out flags,filesystem,64));
    if(filesystem.ToString()!="NTFS") Reject("filesystem_unsupported");
  }
  static object StoreInfoCore(Dictionary<string,object> args) {
    using(var handle=Open(Str(args["root"]))) {
      StoreFileSystem(handle);
      if((BasicOf(handle).Attr&16u)==0) Reject("store_not_directory");
      if(!String.Equals(PathOf(handle),@"\\?\"+System.IO.Path.GetFullPath(Str(args["root"])),StringComparison.OrdinalIgnoreCase)) Reject("store_path_alias");
      return new Dictionary<string,object>{{"id",Id(handle)},{"volume",VolumeOf(handle)}};
    }
  }
  static void FlushStoreDirectory(string path) {
    using(var handle=CreateFile(path,0xC0000000u,7,IntPtr.Zero,3,0x02200000u,IntPtr.Zero)) {
      if(handle.IsInvalid) throw new Win32Exception(Marshal.GetLastWin32Error()); if(PreserveTimeHandles)PreserveHandleTimes(handle);Check(FlushFileBuffers(handle));
    }
  }
  static bool FlushPart(string value) {
    if(value.Length<1 || value.Length>255 || value=="." || value==".." || value.EndsWith(".") || value.EndsWith(" "))return false;
    foreach(char ch in value)if(ch<32 || "\\/:*?\"<>|".IndexOf(ch)>=0)return false;
    return true;
  }
  static void CheckFlushDirectory(SafeFileHandle handle,string expected,string volume,string expectedId=null) {
    PreserveHandleTimes(handle);
    Info info;Check(GetFileInformationByHandle(handle,out info));
    if((info.Attr&16u)==0)Reject("store_not_directory");string observedId=Id(handle);if(expectedId!=null && !String.Equals(observedId,expectedId,StringComparison.Ordinal))Reject("store_id_changed");StoreFileSystem(handle);
    if(!String.Equals(PathOf(handle),expected,StringComparison.OrdinalIgnoreCase))Reject("store_path_alias");
    if(volume!=null && !String.Equals(VolumeOf(handle),volume,StringComparison.Ordinal))Reject("store_volume_changed");
  }
  static SafeFileHandle OpenFlushChild(SafeFileHandle parent,string part,string expected,string volume) {
    IntPtr buffer=Marshal.StringToHGlobalUni(part),name=Marshal.AllocHGlobal(Marshal.SizeOf(typeof(RelativeName))),iosb=Marshal.AllocHGlobal(IntPtr.Size*2);
    SafeFileHandle handle=null;
    try {
      RelativeName unicode=new RelativeName{Length=(ushort)(part.Length*2),MaximumLength=(ushort)((part.Length+1)*2),Buffer=buffer};
      Marshal.StructureToPtr(unicode,name,false);
      RelativeAttributes attributes=new RelativeAttributes{Length=(uint)Marshal.SizeOf(typeof(RelativeAttributes)),RootDirectory=parent.DangerousGetHandle(),ObjectName=name,Attributes=0x40};
      // Open exactly one component relative to the already protected directory.
      // FILE_OPEN, DIRECTORY_FILE, SYNCHRONOUS_IO_NONALERT, OPEN_FOR_BACKUP_INTENT,
      // OPEN_REPARSE_POINT. No absolute fallback or create disposition is allowed.
      int status=NtCreateFile(out handle,0xC0100000u,ref attributes,iosb,IntPtr.Zero,0,3,1,0x00204021u,IntPtr.Zero,0);
      if(status<0)throw new Win32Exception((int)RtlNtStatusToDosError(status));
      if(status!=0 || handle==null || handle.IsInvalid)Reject("store_relative_open");
      CheckFlushDirectory(handle,expected,volume);return handle;
    } catch {if(handle!=null)handle.Dispose();throw;}
    finally {GC.KeepAlive(parent);Marshal.FreeHGlobal(buffer);Marshal.FreeHGlobal(name);Marshal.FreeHGlobal(iosb);}
  }
  static void FlushStoreDirectoryPreserved(string path,string anchor) {
    // Both paths are strict local DOS paths, validated lexically before any open.
    if(path==null || anchor==null || path.Length<3 || anchor.Length<3 || path.Length>32763 || anchor.Length>32763
      || !Char.IsLetter(path[0]) || !Char.IsLetter(anchor[0]) || path[1]!=':' || anchor[1]!=':' || path[2]!='\\' || anchor[2]!='\\')Reject("store_flush_anchor");
    if(path.Length>3)path=path.TrimEnd('\\');if(anchor.Length>3)anchor=anchor.TrimEnd('\\');
    string prefix=anchor.EndsWith("\\")?anchor:anchor+"\\";
    if(!String.Equals(System.IO.Path.GetFullPath(path),path,StringComparison.OrdinalIgnoreCase)
      ||!String.Equals(System.IO.Path.GetFullPath(anchor),anchor,StringComparison.OrdinalIgnoreCase)
      ||!String.Equals(path,anchor,StringComparison.OrdinalIgnoreCase)&&!path.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))Reject("store_flush_anchor");
    foreach(string part in anchor.Length==3?new string[0]:anchor.Substring(3).Split('\\'))if(!FlushPart(part))Reject("store_flush_anchor");
    string relative=path.Length==anchor.Length?"":path.Substring(prefix.Length);
    string[] parts=relative==""?new string[0]:relative.Split('\\');
    if(parts.Length>512)Reject("store_flush_anchor");foreach(string part in parts)if(!FlushPart(part))Reject("store_flush_anchor");
    bool previous=PreserveTimeHandles;PreserveTimeHandles=true;var handles=new List<SafeFileHandle>();
    try {
      var root=CreateFile(anchor,0xC0000000u,3,IntPtr.Zero,3,0x02200000u,IntPtr.Zero);
      if(root.IsInvalid){int error=Marshal.GetLastWin32Error();root.Dispose();throw new Win32Exception(error);}
      handles.Add(root);string expected=@"\\?\"+anchor;CheckFlushDirectory(root,expected,null);string volume=VolumeOf(root);
      SafeFileHandle current=root;
      foreach(string part in parts){expected+=(expected.EndsWith("\\")?"":"\\")+part;current=OpenFlushChild(current,part,expected,volume);handles.Add(current);}
      Check(FlushFileBuffers(current));
    } finally {try {for(int n=handles.Count-1;n>=0;n--)handles[n].Dispose();}finally {PreserveTimeHandles=previous;}}
  }
  static bool CapturedDirectoryWrite = false, CapturedFlushScope = false, CapturedFlushConsumed = false;
  static Dictionary<string,object> CapturedFlushSnapshot;
  static string CapturedFlushToken, CapturedFlushRoot, CapturedFlushRevision, CapturedFlushVolume, CapturedFlushRole;
  static object CaptureOwnedFlushReady(Dictionary<string,object> args) {
    object scope=null,preserve=null,rawRoot=null,rawRevision=null;
    if(Nodes.Count!=0 || CapturedFlushScope)Reject("already_open");
    if(!args.TryGetValue("scope",out scope) || !(scope is string) || ((string)scope!="owned-stage" && (string)scope!="owned-target"))Reject("captured_flush_scope");
    if(!args.TryGetValue("preserveMetadata",out preserve) || !(preserve is bool) || !(bool)preserve)Reject("captured_flush_option");
    if(!args.TryGetValue("root",out rawRoot) || !(rawRoot is string) || !args.TryGetValue("revision",out rawRevision) || !(rawRevision is string))Reject("captured_flush_binding");
    string root=(string)rawRoot,revision=(string)rawRevision;
    if(root.Length<3 || root.Length>32763 || !Char.IsLetter(root[0]) || root[1]!=':' || root[2]!='\\'
      || !String.Equals(System.IO.Path.GetFullPath(root),root,StringComparison.OrdinalIgnoreCase)
      || !System.Text.RegularExpressions.Regex.IsMatch(revision,"^[a-f0-9]{64}$"))Reject("captured_flush_binding");
    // This internal opt-in is for a separately admitted new owned stage/target.
    // The scope label is not ownership authority; the caller must hold that lease.
    CapturedFlushScope=true;bool previous=CapturedDirectoryWrite;CapturedDirectoryWrite=true;
    try {
      Dictionary<string,object> captured=Dict(CapturePreserved(args));
      if(!String.Equals(OriginalRoot,@"\\?\"+root,StringComparison.OrdinalIgnoreCase))Reject("captured_flush_root_alias");
      object requestedVolume=null;string admittedVolume=null;
      if(args.TryGetValue("expectedVolume",out requestedVolume)) {
        if(!(requestedVolume is string) || ((string)requestedVolume).Length<1 || ((string)requestedVolume).Length>128)Reject("captured_flush_volume");
        admittedVolume=VolumeOf(RootNode().Handle);if(!String.Equals(admittedVolume,(string)requestedVolume,StringComparison.Ordinal))Reject("store_volume_changed");
      }
      CapturedFlushSnapshot=captured;CapturedFlushRoot=root;CapturedFlushRevision=revision;CapturedFlushToken=RandomName();CapturedFlushConsumed=false;CapturedFlushVolume=admittedVolume;CapturedFlushRole=(string)scope;
      var ready=new Dictionary<string,object>{{"schema",1},{"snapshot",captured},{"token",CapturedFlushToken},{"scope",(string)scope}};if(admittedVolume!=null)ready.Add("volume",admittedVolume);return ready;
    } finally {CapturedDirectoryWrite=previous;}
  }
  static void CheckCapturedDirectory(Node node,string volume) {
    string rel=Str(node.Entry["rel"]),expected=rel==""?OriginalRoot:System.IO.Path.Combine(OriginalRoot,rel.Replace('/','\\'));
    if(!(bool)node.Entry["dir"] || node.Writable)Reject("captured_flush_not_directory");
    if(!String.Equals(Id(node.Handle),Str(node.Entry["id"]),StringComparison.Ordinal))Reject("identity_changed");
    StoreFileSystem(node.Handle);
    if(!String.Equals(PathOf(node.Handle),expected,StringComparison.OrdinalIgnoreCase))Reject("store_path_alias");
    if(!String.Equals(VolumeOf(node.Handle),volume,StringComparison.Ordinal))Reject("store_volume_changed");
    if(!String.Equals(ShortName(node.Handle),Str(node.Entry["shortName"]),StringComparison.Ordinal))Reject("short_name_changed");
    Basic actual=BasicOf(node.Handle);var times=new List<string>();foreach(object time in (IEnumerable)node.Entry["times"])times.Add(Str(time));
    if(times.Count!=4 || Str(actual.Creation)!=times[0] || Str(actual.Access)!=times[1] || Str(actual.Write)!=times[2] || Str(actual.Change)!=times[3] || actual.Attr!=Convert.ToUInt32(node.Entry["attrs"]))Reject("captured_flush_metadata_changed");
  }
  static object FlushCapturedDirectories(Dictionary<string,object> args) {
    object token=null,root=null,revision=null,rawIds=null;
    if(!CapturedFlushScope || CapturedFlushSnapshot==null || CapturedFlushConsumed || !Object.ReferenceEquals(Snapshot,CapturedFlushSnapshot))Reject("captured_flush_not_ready");
    if(!args.TryGetValue("token",out token) || !(token is string) || (string)token!=CapturedFlushToken
      ||!args.TryGetValue("root",out root) || !(root is string) || (string)root!=CapturedFlushRoot
      ||!args.TryGetValue("revision",out revision) || !(revision is string) || (string)revision!=CapturedFlushRevision
      ||!args.TryGetValue("directoryIds",out rawIds) || !(rawIds is object[]))Reject("captured_flush_binding");
    object requestedVolume=null;if(CapturedFlushVolume!=null && (!args.TryGetValue("expectedVolume",out requestedVolume) || !(requestedVolume is string) || !String.Equals((string)requestedVolume,CapturedFlushVolume,StringComparison.Ordinal)))Reject("captured_flush_volume");
    object[] ids=(object[])rawIds;var expected=Expected();var directories=new List<Node>();var supplied=new HashSet<string>(StringComparer.Ordinal);
    if(expected.Count!=Nodes.Count)Reject("entry_set_changed");
    foreach(object id in ids)if(!(id is string) || !System.Text.RegularExpressions.Regex.IsMatch((string)id,"^[a-f0-9]{24}$") || !supplied.Add((string)id))Reject("captured_flush_binding");
    foreach(Node node in expected)if((bool)node.Entry["dir"]){if(!supplied.Contains(Str(node.Entry["id"])))Reject("captured_flush_binding");directories.Add(node);}
    if(directories.Count<1 || directories.Count!=ids.Length)Reject("captured_flush_binding");
    // From this point a failure is not retryable. Every directory was opened
    // with WRITE before the ready capture's original checkpoint, never here.
    CapturedFlushConsumed=true;
    directories.Sort(delegate(Node a,Node b){return Str(b.Entry["rel"]).Length.CompareTo(Str(a.Entry["rel"]).Length);});
    Step="captured-directory-precheck";string volume=VolumeOf(RootNode().Handle);if(CapturedFlushVolume!=null && !String.Equals(volume,CapturedFlushVolume,StringComparison.Ordinal))Reject("store_volume_changed");foreach(Node node in directories)CheckCapturedDirectory(node,volume);
    Step="captured-directory-flush";var flushed=new List<object>();foreach(Node node in directories){Check(FlushFileBuffers(node.Handle));flushed.Add(new Dictionary<string,object>{{"rel",Str(node.Entry["rel"])},{"id",Str(node.Entry["id"])}});}
    Step="captured-directory-postcheck";foreach(Node node in directories)CheckCapturedDirectory(node,volume);
    var receipt=new Dictionary<string,object>{{"schema",1},{"kind","captured-directory-flush-v1"},{"token",CapturedFlushToken},{"root",CapturedFlushRoot},{"revision",CapturedFlushRevision},{"directories",flushed},{"count",flushed.Count},{"allFlushed",true},{"metadataExact",true}};if(CapturedFlushVolume!=null){receipt.Add("volume",volume);receipt.Add("role",CapturedFlushRole);}return receipt;
  }
  static void CheckBoundFlushDirectory(SafeFileHandle handle,string root,string id,string volume) {
    Info value;Check(GetFileInformationByHandle(handle,out value));if((value.Attr&16u)==0)Reject("store_not_directory");
    if(!String.Equals(Id(handle),id,StringComparison.Ordinal))Reject("store_id_changed");StoreFileSystem(handle);
    if(!String.Equals(PathOf(handle),@"\\?\"+root,StringComparison.OrdinalIgnoreCase))Reject("store_path_alias");
    if(!String.Equals(VolumeOf(handle),volume,StringComparison.Ordinal))Reject("store_volume_changed");
  }
  static object FlushStoreDirectoryBound(Dictionary<string,object> args) {
    object rawRoot=null,rawId=null,rawVolume=null,rawRole=null,rawOrdinal=null;
    if(!args.TryGetValue("root",out rawRoot) || !(rawRoot is string) || !args.TryGetValue("id",out rawId) || !(rawId is string)
      ||!args.TryGetValue("volume",out rawVolume) || !(rawVolume is string) || !args.TryGetValue("role",out rawRole) || !(rawRole is string)
      ||!args.TryGetValue("ordinal",out rawOrdinal) || !(rawOrdinal is int))Reject("bound_flush_binding");
    string root=(string)rawRoot,id=(string)rawId,volume=(string)rawVolume,role=(string)rawRole;int ordinal=(int)rawOrdinal;
    if(root.Length<3 || root.Length>32763 || !Char.IsLetter(root[0]) || root[1]!=':' || root[2]!='\\'
      ||!String.Equals(System.IO.Path.GetFullPath(root),root,StringComparison.OrdinalIgnoreCase)
      ||!System.Text.RegularExpressions.Regex.IsMatch(id,"^[a-f0-9]{24}$") || volume.Length<1 || volume.Length>128
      ||(role!="external-parent" && role!="new-target-ancestor") || ordinal<0 || ordinal>=10000)Reject("bound_flush_binding");
    // Ordinary directory durability, independently bound to this exact parent.
    // No metadata suppression, capture, child-name lookup or borrowed tree ID.
    using(var handle=CreateFile(root,0xC0000000u,7,IntPtr.Zero,3,0x02200000u,IntPtr.Zero)) {
      if(handle.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error());
      CheckBoundFlushDirectory(handle,root,id,volume);Step="bound-directory-flush";Check(FlushFileBuffers(handle));CheckBoundFlushDirectory(handle,root,id,volume);
    }
    return new Dictionary<string,object>{{"schema",1},{"kind","bound-directory-flush-v1"},{"root",root},{"id",id},{"volume",volume},{"role",role},{"ordinal",ordinal},{"flushed",true}};
  }
  static void FlushStoreDirectoryById(Dictionary<string,object> args) {
    object preserve=null,rawPath=null,rawAnchor=null,rawId=null;
    if(!args.TryGetValue("preserveMetadata",out preserve) || !(preserve is bool) || !(bool)preserve)Reject("store_flush_option");
    if(!args.TryGetValue("root",out rawPath) || !(rawPath is string) || !args.TryGetValue("anchor",out rawAnchor) || !(rawAnchor is string))Reject("store_flush_anchor");
    if(!args.TryGetValue("objectId",out rawId) || !(rawId is string))Reject("store_flush_id");
    string path=(string)rawPath,anchor=(string)rawAnchor,objectId=(string)rawId;uint serial=0;ulong index=0;
    if(!System.Text.RegularExpressions.Regex.IsMatch(objectId,"^[a-f0-9]{24}$")
      ||!uint.TryParse(objectId.Substring(0,8),System.Globalization.NumberStyles.HexNumber,System.Globalization.CultureInfo.InvariantCulture,out serial)
      ||!ulong.TryParse(objectId.Substring(8),System.Globalization.NumberStyles.HexNumber,System.Globalization.CultureInfo.InvariantCulture,out index))Reject("store_flush_id");
    // Pure lexical checks precede all opens. The target ID comes only from the
    // caller's unchanged original checkpoint, never a new lookup by this path.
    if(path.Length<3 || anchor.Length<3 || path.Length>32763 || anchor.Length>32763
      ||!Char.IsLetter(path[0]) || !Char.IsLetter(anchor[0]) || path[1]!=':' || anchor[1]!=':' || path[2]!='\\' || anchor[2]!='\\')Reject("store_flush_anchor");
    if(path.Length>3)path=path.TrimEnd('\\');if(anchor.Length>3)anchor=anchor.TrimEnd('\\');
    string prefix=anchor.EndsWith("\\")?anchor:anchor+"\\";
    if(!String.Equals(System.IO.Path.GetFullPath(path),path,StringComparison.OrdinalIgnoreCase)
      ||!String.Equals(System.IO.Path.GetFullPath(anchor),anchor,StringComparison.OrdinalIgnoreCase)
      ||!String.Equals(path,anchor,StringComparison.OrdinalIgnoreCase)&&!path.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))Reject("store_flush_anchor");
    foreach(string part in anchor.Length==3?new string[0]:anchor.Substring(3).Split('\\'))if(!FlushPart(part))Reject("store_flush_anchor");
    string relative=path.Length==anchor.Length?"":path.Substring(prefix.Length);string[] parts=relative==""?new string[0]:relative.Split('\\');
    if(parts.Length>512)Reject("store_flush_anchor");foreach(string part in parts)if(!FlushPart(part))Reject("store_flush_anchor");
    bool previous=PreserveTimeHandles;PreserveTimeHandles=true;
    try {
      using(var hint=CreateFile(anchor,0xC0000000u,3,IntPtr.Zero,3,0x02200000u,IntPtr.Zero)) {
        if(hint.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error());
        CheckFlushDirectory(hint,@"\\?\"+anchor,null);
        Info information;Check(GetFileInformationByHandle(hint,out information));if(information.Volume!=serial)Reject("store_volume_changed");
        string volume=VolumeOf(hint);
        FileIdDescriptor descriptor=new FileIdDescriptor{Size=(uint)Marshal.SizeOf(typeof(FileIdDescriptor)),Type=0,FileId=unchecked((long)index),Reserved=0};
        using(var target=OpenFileById(hint,ref descriptor,0xC0100000u,3,IntPtr.Zero,0x02200000u)) {
          if(target.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error());
          CheckFlushDirectory(target,@"\\?\"+path,volume,objectId);
          Check(FlushFileBuffers(target));
        }
      }
    } finally {PreserveTimeHandles=previous;}
  }
  static object MoveStoreCore(Dictionary<string,object> args) {
    string source=System.IO.Path.GetFullPath(Str(args["source"])),target=System.IO.Path.GetFullPath(Str(args["target"]));
    string fromParent=System.IO.Path.GetDirectoryName(source),toParent=System.IO.Path.GetDirectoryName(target);
    using(var original=Open(source)) using(var parent=Open(toParent)) {
      StoreFileSystem(original);
      if(Id(original)!=Str(args["id"]) || !String.Equals(PathOf(original),@"\\?\"+source,StringComparison.OrdinalIgnoreCase)) Reject("store_identity");
      if(!String.Equals(PathOf(parent),@"\\?\"+toParent,StringComparison.OrdinalIgnoreCase)) Reject("store_path_alias");
      if(!String.Equals(VolumeOf(original),VolumeOf(parent),StringComparison.OrdinalIgnoreCase)) Reject("cross_volume");
      // Capability refusal precedes rename. No COPY_ALLOWED and no replacement.
      bool preserveMetadata=args.ContainsKey("preserveMetadata") && args["preserveMetadata"] is bool && (bool)args["preserveMetadata"];
      Basic before=BasicOf(original);string beforeAlias=ShortName(original);
      Step="store-flush-pre";FlushStoreDirectory(fromParent);FlushStoreDirectory(toParent);
      Step="store-move";Check(MoveFileExW(@"\\?\"+source,@"\\?\"+target,8));
      if(Id(original)!=Str(args["id"]) || !String.Equals(PathOf(original),@"\\?\"+target,StringComparison.OrdinalIgnoreCase)) Reject("store_identity");
      Step="store-flush-post";FlushStoreDirectory(fromParent);FlushStoreDirectory(toParent);
      if(preserveMetadata) {
        Node owned=new Node { Handle=original,Entry=new Dictionary<string,object>{{"shortName",beforeAlias},{"attrs",before.Attr},{"times",new string[]{Str(before.Creation),Str(before.Access),Str(before.Write),Str(before.Change)}}} };
        SetAlias(owned,beforeAlias);if(!String.Equals(ShortName(original),beforeAlias,StringComparison.Ordinal))Reject("portable_short_name_unrepresentable");
        FlushStoreDirectory(target);RestoreNodeBasic(owned,original);
        Basic after=BasicOf(original);if(after.Creation!=before.Creation || after.Access!=before.Access || after.Write!=before.Write || after.Change!=before.Change || after.Attr!=before.Attr)Reject("metadata_changed");
      }
      return new Dictionary<string,object>{{"id",Id(original)},{"volume",VolumeOf(original)}};
    }
  }
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateDirectoryW(string path,IntPtr security);
  // FILE_BASIC_INFORMATION -1 suppresses automatic updates on this handle.
  // This is scoped to owned creation/preserved capture, never general writes.
  static object StoreInfo(Dictionary<string,object> args) {
    bool previous=PreserveTimeHandles;PreserveTimeHandles=true;
    try {return StoreInfoCore(args);}finally {PreserveTimeHandles=previous;}
  }
  static object MoveStore(Dictionary<string,object> args) {
    bool preserve=args.ContainsKey("preserveMetadata") && args["preserveMetadata"] is bool && (bool)args["preserveMetadata"];
    if(!preserve)return MoveStoreCore(args);
    bool previous=PreserveTimeHandles;PreserveTimeHandles=true;
    try {return MoveStoreCore(args);}finally {PreserveTimeHandles=previous;}
  }

  static void PreserveHandleTimes(SafeFileHandle handle) {
    Basic keep = new Basic { Access=-1, Write=-1, Change=-1 };
    IntPtr value=Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Basic))),iosb=Marshal.AllocHGlobal(IntPtr.Size*2);
    string prior=Step;Step="preserve-times";
    try {
      Marshal.StructureToPtr(keep,value,false);
      int status=NtSetInformationFile(handle,iosb,value,(uint)Marshal.SizeOf(typeof(Basic)),4);
      if(status<0)throw new Win32Exception((int)RtlNtStatusToDosError(status));
      Step=prior;
    } finally {Marshal.FreeHGlobal(value);Marshal.FreeHGlobal(iosb);}
  }
  static object CapturePreserved(Dictionary<string,object> args) {
    bool previous=PreserveTimeHandles;PreserveTimeHandles=true;
    try {return Capture(args);}
    finally {try {RestoreBasic(new List<Node>(Nodes.Values));} finally {PreserveTimeHandles=previous;}}
  }
  static object CreateOwnedPortable(Dictionary<string,object> args) {
    bool previous=PreserveTimeHandles;PreserveTimeHandles=true;
    try {return CreateOwnedPortableCore(args);}
    finally {PreserveTimeHandles=previous;}
  }
  static void VerifyPortableReadback(Dictionary<string,object> wanted,Dictionary<string,object> actual) {
    Dictionary<string,Dictionary<string,object>> byPath=new Dictionary<string,Dictionary<string,object>>(StringComparer.Ordinal);
    foreach(object raw in (IEnumerable)actual["entries"]) {Dictionary<string,object> entry=Dict(raw);byPath.Add(Str(entry["rel"]),entry);}
    int count=0;
    foreach(object raw in (IEnumerable)wanted["entries"]) {
      Dictionary<string,object> expected=Dict(raw);string rel=Str(expected["rel"]);count++;
      if(!byPath.ContainsKey(rel))Reject("portable_readback_changed");Dictionary<string,object> entry=byPath[rel];
      if(Str(entry["id"])!=Str(expected["id"]) || (bool)entry["dir"]!=(bool)expected["dir"] || Convert.ToUInt32(entry["attrs"])!=Convert.ToUInt32(expected["attrs"]))Reject("portable_readback_changed");
      if(!String.Equals(Str(entry["shortName"]),Str(expected["shortName"]),StringComparison.Ordinal))Reject("portable_short_name_unrepresentable");
      List<string> expectedTimes=new List<string>(),actualTimes=new List<string>();
      foreach(object time in (IEnumerable)expected["times"])expectedTimes.Add(Str(time));
      foreach(object time in (IEnumerable)entry["times"])actualTimes.Add(Str(time));
      if(expectedTimes.Count!=4 || actualTimes.Count!=4)Reject("portable_readback_changed");
      for(int index=0;index<4;index++)if(actualTimes[index]!=expectedTimes[index])Reject("portable_metadata_changed");
      Dictionary<string,Dictionary<string,object>> streams=new Dictionary<string,Dictionary<string,object>>(StringComparer.Ordinal);int streamCount=0;
      foreach(object streamRaw in (IEnumerable)entry["streams"]) {Dictionary<string,object> stream=Dict(streamRaw);streams.Add(Str(stream["name"]),stream);}
      foreach(object streamRaw in (IEnumerable)expected["streams"]) {
        Dictionary<string,object> stream=Dict(streamRaw);string name=Str(stream["name"]);streamCount++;
        if(!streams.ContainsKey(name))Reject("portable_readback_changed");Dictionary<string,object> read=streams[name];
        if(Convert.ToInt64(read["size"])!=Convert.ToInt64(stream["size"]) || Str(read["hash"])!=Str(stream["hash"]) || Str(read["data"])!=Str(stream["data"]))Reject("portable_readback_changed");
      }
      if(streamCount!=streams.Count)Reject("portable_readback_changed");
    }
    if(count!=byPath.Count)Reject("portable_readback_changed");
  }

  static object CreateOwnedPortableCore(Dictionary<string,object> args) {
    // All objects are new, created without replacement. Security is inherited
    // from the destination; source IDs/opaque names never authorize a live object.
    if(Nodes.Count!=0 || Capsule!=null) Reject("already_open");
    string root=System.IO.Path.GetFullPath(Str(args["root"])),revision=Str(args["revision"]);
    if(!System.Text.RegularExpressions.Regex.IsMatch(revision,"^[a-f0-9]{64}$")) Reject("portable_revision");
    Dictionary<string,object> source=Dict(args["snapshot"]);
    if(Convert.ToInt32(source["schema"])!=1 || Str(source["platform"])!="ntfs-objects-v1") Reject("portable_shape");
    List<Dictionary<string,object>> entries=new List<Dictionary<string,object>>();
    HashSet<string> names=new HashSet<string>(StringComparer.OrdinalIgnoreCase),dirs=new HashSet<string>(StringComparer.OrdinalIgnoreCase),sourceIds=new HashSet<string>(),aliases=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    long bytesTotal=0;
    foreach(object raw in (IEnumerable)source["entries"]) {
      Dictionary<string,object> entry=Dict(raw);string rel=Str(entry["rel"]);bool directory=(bool)entry["dir"];
      if(entries.Count>=10000 || rel.Length>30000 || !names.Add(rel)) Reject("portable_shape");
      if(!System.Text.RegularExpressions.Regex.IsMatch(Str(entry["id"]),"^[a-f0-9]{24}$") || !sourceIds.Add(Str(entry["id"]))) Reject("portable_shape");
      if(rel!="") {
        string[] parts=rel.Split('/');if(parts.Length>256)Reject("portable_path");
        foreach(string part in parts) if(part.Length<1 || part.Length>255 || part=="." || part==".." || part.EndsWith(".") || part.EndsWith(" ") || part.IndexOfAny(new char[]{'\\',':','*','?','"','<','>','|'})>=0 || System.Text.RegularExpressions.Regex.IsMatch(part,"[\\x00-\\x1f]")) Reject("portable_path");
      } else if(!directory)Reject("portable_root");
      uint attrs=Convert.ToUInt32(entry["attrs"]);if((attrs & ~0x31b7u)!=0 || ((attrs&16u)!=0)!=directory) Reject("portable_attrs");
      int times=0;foreach(object time in (IEnumerable)entry["times"]) {long parsed;if(!long.TryParse(Str(time),out parsed)||parsed<0)Reject("portable_times");times++;}if(times!=4)Reject("portable_times");
      string alias=Str(entry["shortName"]);LegalShortName(alias);
      if(rel!="" && alias!="") {int slash=rel.LastIndexOf('/');string key=(slash<0?"":rel.Substring(0,slash+1))+alias;if(!aliases.Add(key))Reject("portable_alias");}
      HashSet<string> streams=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
      foreach(object streamRaw in (IEnumerable)entry["streams"]) {
        Dictionary<string,object> stream=Dict(streamRaw);string name=Str(stream["name"]);
        if(streams.Count>=1024 || !streams.Add(name) || name.Length>1024 || directory&&name=="")Reject("portable_stream");
        if(name!="" && !System.Text.RegularExpressions.Regex.IsMatch(name,"^:[^:\\\\/*?\"<>|\\x00-\\x1f]+:\\$DATA$"))Reject("portable_stream");
        byte[] bytes=Convert.FromBase64String(Str(stream["data"]));
        try {bytesTotal+=bytes.Length;if(bytesTotal>MaxBytes || bytes.Length!=Convert.ToInt64(stream["size"]) || Convert.ToBase64String(bytes)!=Str(stream["data"]) || Hash(bytes)!=Str(stream["hash"]))Reject("portable_content");}
        finally {Array.Clear(bytes,0,bytes.Length);}
      }
      if(!directory && !streams.Contains(""))Reject("portable_default");
      if(directory)dirs.Add(rel);entries.Add(entry);
    }
    if(entries.Count<1 || !dirs.Contains(""))Reject("portable_root");
    foreach(Dictionary<string,object> entry in entries) {
      string rel=Str(entry["rel"]);if(rel=="")continue;int slash=rel.LastIndexOf('/');string parent=slash<0?"":rel.Substring(0,slash);
      if(!dirs.Contains(parent))Reject("portable_parent");string alias=Str(entry["shortName"]),key=(parent==""?"":parent+"/")+alias;
      if(alias!="" && names.Contains(key) && !String.Equals(key,rel,StringComparison.OrdinalIgnoreCase))Reject("portable_alias");
    }
    // Validate the real destination parent and flush capability before mutation.
    string parentRoot=System.IO.Path.GetDirectoryName(root);using(SafeFileHandle parent=Open(parentRoot)) {
      StoreFileSystem(parent);if(!String.Equals(PathOf(parent),@"\\?\"+parentRoot,StringComparison.OrdinalIgnoreCase))Reject("portable_parent_alias");
      FlushStoreDirectory(parentRoot);
    }
    entries.Sort(delegate(Dictionary<string,object> a,Dictionary<string,object> b){return Str(a["rel"]).Length.CompareTo(Str(b["rel"]).Length);});
    List<object> created=new List<object>();OriginalRoot=@"\\?\"+root;
    foreach(Dictionary<string,object> entry in entries) {
      string rel=Str(entry["rel"]),file=rel==""?OriginalRoot:System.IO.Path.Combine(OriginalRoot,rel.Replace('/','\\'));bool directory=(bool)entry["dir"];
      Step="portable-create";Node node=new Node();
      try {
      if(directory){Check(CreateDirectoryW(file,IntPtr.Zero));node.Handle=Open(file,out node.Writable);}
      else {node.Handle=CreateFile(file,0xC0010000u,5,IntPtr.Zero,1,0x00200000u,IntPtr.Zero);node.Writable=true;if(node.Handle.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error());try {PreserveHandleTimes(node.Handle);}catch{node.Handle.Dispose();throw;}}
      string id=Id(node.Handle);if(Nodes.ContainsKey(id)){node.Handle.Dispose();Reject("object_duplicate");}
      if(!String.Equals(PathOf(node.Handle),file,StringComparison.OrdinalIgnoreCase)){node.Handle.Dispose();Reject("portable_path_alias");}
      Dictionary<string,object> staged=new Dictionary<string,object>(entry);staged["id"]=id;staged["opaque"]=RandomName();node.Entry=staged;Nodes.Add(id,node);created.Add(staged);
      } catch {
        if(!Nodes.ContainsValue(node) && node.Handle!=null && !node.Handle.IsClosed)node.Handle.Dispose();
        throw;
      }
      // Directories have no descendants open when their alias is established.
      SetAlias(node,Str(entry["shortName"]));
      if(!String.Equals(ShortName(node.Handle),Str(entry["shortName"]),StringComparison.Ordinal))Reject("portable_short_name_unrepresentable");
      foreach(object streamRaw in (IEnumerable)entry["streams"]) {
        Dictionary<string,object> stream=Dict(streamRaw);string name=Str(stream["name"]);byte[] bytes=Convert.FromBase64String(Str(stream["data"]));
        try {
          SafeFileHandle handle=node.Handle;
          if(name!=""){handle=CreateFile(file+name,0xC0010000u,5,IntPtr.Zero,1,0x00200000u,IntPtr.Zero);if(handle.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error());try{PreserveHandleTimes(handle);}catch{handle.Dispose();throw;}node.Streams.Add(name,handle);}
          Step="portable-write";Write(handle,bytes);
        } finally {Array.Clear(bytes,0,bytes.Length);}
      }
    }
    Snapshot=new Dictionary<string,object>{{"schema",1},{"platform","ntfs-objects-v1"},{"revision",revision},{"entries",created}};
    Step="portable-verify";Verify(false,true);VerifyOriginalLayout();
    // Enumeration and every auxiliary flush handle finish before the final
    // metadata application. Suppressed primary/stream handles cannot overwrite
    // restored Basic values on close. Reopen and inspect actual objects/bytes.
    foreach(Node node in Expected())if((bool)node.Entry["dir"])FlushStoreDirectory(PathOf(node.Handle));FlushStoreDirectory(parentRoot);
    RestoreBasic(Expected());Dictionary<string,object> wanted=Snapshot;Close();
    Dictionary<string,object> observed=Dict(CapturePreserved(new Dictionary<string,object>{{"root",root},{"revision",revision}}));
    Step="portable-readback";VerifyPortableReadback(wanted,observed);return observed;
  }

  public static void Run() {
    Console.InputEncoding = new UTF8Encoding(false); Console.OutputEncoding = new UTF8Encoding(false);
    try {
      string line;
      while ((line = Console.ReadLine()) != null) {
        try {
          Dictionary<string,object> args = Dict(Json.DeserializeObject(line)); string command = Str(args["cmd"]); object result = null;
          if(CapturedFlushScope && command!="flush-captured-directories" && command!="close")Reject("captured_flush_scope");
          if (command == "store-info") result=StoreInfo(args);
          else if (command == "store-move") result=MoveStore(args);
          else if (command == "create-owned-portable") result=CreateOwnedPortable(args);
          else if (command == "capture") result = Capture(args);
          else if (command == "capture-preserved") result=CapturePreserved(args);
          else if (command == "capture-owned-flush-ready") result=CaptureOwnedFlushReady(args);
          else if (command == "flush-captured-directories") result=FlushCapturedDirectories(args);
          else if (command == "short-probe") ProbeShortNames(args);
          else if (command == "attach") Attach(args);
          else if (command == "seal") Seal(args);
          else if (command == "seal-attached") { OriginalRoot=PathOf(RootNode().Handle); Seal(args); }
          else if (command == "restore") Restore(args);
          else if (command == "publish") Publish(args);
          else if (command == "finish-published") FinishPublished(args);
          else if (command == "publish-check") CheckPublication(args);
          else if (command == "store-flush-bound") result=FlushStoreDirectoryBound(args);
          else if (command == "store-flush-by-id") FlushStoreDirectoryById(args);
          else if (command == "store-flush") {
            object preserve;
            if(args.TryGetValue("preserveMetadata",out preserve) && !(preserve is bool)) Reject("store_flush_option");
            if(preserve is bool && (bool)preserve) {
              object anchor;if(!args.TryGetValue("anchor",out anchor) || !(anchor is string))Reject("store_flush_anchor");
              FlushStoreDirectoryPreserved(Str(args["root"]),(string)anchor);
            }
            else FlushStoreDirectory(Str(args["root"]));
          }
          else if (command == "verify") Verify(Convert.ToBoolean(args["cleared"]), true);
          else if (command == "close") { Close(); Console.WriteLine("{\"ok\":true}"); return; }
          else Reject("command_invalid");
          Console.WriteLine(Json.Serialize(new Dictionary<string,object> { { "ok", true }, { "value", result } }));
        } catch (Exception error) {
          Win32Exception native = error as Win32Exception;
          string code = native == null ? error is InvalidOperationException ? error.Message : "native_failure" : Step.Replace('-','_') + "_win32_" + native.NativeErrorCode;
          Console.WriteLine(Json.Serialize(new Dictionary<string,object> { { "ok", false }, { "code", code } }));
        }
      }
    } finally { Close(); }
  }
}
