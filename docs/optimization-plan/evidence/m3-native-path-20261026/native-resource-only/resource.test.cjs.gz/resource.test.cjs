'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),vm=require('node:vm'),{constBlock,functionBlock}=require('C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss/dev-harness/lib/source-slice');
const D=__dirname,span=JSON.parse(fs.readFileSync(p.join(D,'span.json'),'utf8')),before=fs.readFileSync(p.join(D,'13u-before-aedd.js'),'utf8'),after=fs.readFileSync(p.join(D,'13u-after.js'),'utf8'),sha=x=>c.createHash('sha256').update(x).digest('hex');
const guarded=process.env.N1_MODEL_CONTROL!=='unfixed';
function model(fault){const nodes=new Map(),state={disposeCalls:0,closes:0,newDiskObject:false},primary=Error(fault),node={handle:null};const handle={IsClosed:false,Dispose(){state.disposeCalls++;if(!this.IsClosed){this.IsClosed=true;state.closes++;}}};let error;
 try{
  try{
   if(fault==='directory-create')throw primary;
   state.newDiskObject=true;
   if(fault==='directory-open'){handle.Dispose();throw primary;}
   node.handle=handle;
   if(fault==='invalid-file-handle')throw primary;
   if(fault==='preserve-times'){handle.Dispose();throw primary;}
   if(fault==='id')throw primary;
   if(fault==='duplicate-id'||fault==='path-alias'){handle.Dispose();throw primary;}
   if(fault==='entry-clone'||fault==='random-name'||fault==='register-map')throw primary;
   nodes.set('id',node);
   if(fault==='created-list')throw primary;
  }catch(cause){if(guarded&&![...nodes.values()].includes(node)&&node.handle!==null&&!node.handle.IsClosed)node.handle.Dispose();throw cause;}
  if(fault==='registered-alias')throw primary;
 }catch(cause){error=cause;}
 const beforeTerminal={...state,registered:nodes.size,closed:handle.IsClosed,errorIsPrimary:error===primary};
 for(const node of nodes.values())node.handle.Dispose();return{beforeTerminal,afterTerminal:{...state},handle,error,primary};}
test('one source/native span inverses toV2 and retains every old registration check',()=>{a.equal(sha(before),span.beforeSha256);a.equal(sha(after),span.afterSha256);a.equal(before.split(span.before).length,2);a.equal(after.split(span.after).length,2);a.equal(before.replace(span.before,span.after),after);a.equal(after.replace(span.after,span.before),before);const native=s=>vm.runInNewContext(constBlock(s,'MIGRATION_SKILL_CAPSULE_NATIVE')+';MIGRATION_SKILL_CAPSULE_NATIVE;');a.equal(sha(native(before)),span.nativeBeforeSha256);a.equal(sha(native(after)),span.nativeAfterSha256);a.equal(native(after).replace(span.after,span.before),native(before));a.equal(functionBlock(before,'migrationCapsuleCreateOwnedPortable'),functionBlock(after,'migrationCapsuleCreateOwnedPortable'));a.ok(span.after.includes(span.before));a.ok(span.after.includes('!Nodes.ContainsValue(node) && node.Handle!=null && !node.Handle.IsClosed'));a.equal(span.after.includes('DeleteFile'),false);a.equal(span.after.includes('Remove('),false);});
test('unregistered Id failure is deterministically disposed before negative ACK control',()=>{const observed=model('id');a.equal(observed.beforeTerminal.registered,0);a.equal(observed.beforeTerminal.disposeCalls,1);a.equal(observed.beforeTerminal.closes,1);a.equal(observed.beforeTerminal.errorIsPrimary,true);a.equal(observed.afterTerminal.disposeCalls,1);a.equal(observed.beforeTerminal.newDiskObject,true);});
for(const fault of ['invalid-file-handle','entry-clone','random-name','register-map'])test(fault+' unregistered failure disposes once without deleting owned stage',()=>{const observed=model(fault);a.equal(observed.beforeTerminal.registered,0);a.equal(observed.beforeTerminal.disposeCalls,1);a.equal(observed.beforeTerminal.errorIsPrimary,true);a.equal(observed.beforeTerminal.newDiskObject,true);a.equal(observed.afterTerminal.disposeCalls,1);});
for(const fault of ['preserve-times','duplicate-id','path-alias'])test(fault+' existing explicit Dispose is not repeated by the new catch',()=>{const observed=model(fault);a.equal(observed.beforeTerminal.disposeCalls,1);a.equal(observed.beforeTerminal.closes,1);a.equal(observed.beforeTerminal.errorIsPrimary,true);a.equal(observed.afterTerminal.disposeCalls,1);});
test('directory acquisition failure with no assigned handle does not dereference null',()=>{const pre=model('directory-create'),opened=model('directory-open');a.equal(pre.beforeTerminal.disposeCalls,0);a.equal(pre.beforeTerminal.newDiskObject,false);a.equal(opened.beforeTerminal.disposeCalls,1);a.equal(opened.beforeTerminal.errorIsPrimary,true);});
for(const fault of ['created-list','registered-alias'])test(fault+' registered handle remains solely owned by normal Close registry',()=>{const observed=model(fault);a.equal(observed.beforeTerminal.registered,1);a.equal(observed.beforeTerminal.disposeCalls,0);a.equal(observed.beforeTerminal.errorIsPrimary,true);a.equal(observed.afterTerminal.disposeCalls,1);});
test('normal registered node remains open until normal native terminal Close',()=>{const observed=model('normal');a.equal(observed.error,undefined);a.equal(observed.beforeTerminal.registered,1);a.equal(observed.beforeTerminal.disposeCalls,0);a.equal(observed.beforeTerminal.closed,false);a.equal(observed.afterTerminal.disposeCalls,1);a.equal(observed.afterTerminal.closes,1);});
