'use strict';
// Private observation of the actual fixture/broker. It changes no native bytes,
// command arguments, return values, or production files; no raw payload logging.
const path=require('node:path'),fs=require('node:fs');
const file='C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss/dev-harness/lib/migration-skill-backup-fixture.js';
const fx=require(file),original=fx.createMigrationSkillBackupFixture;
const allowed=new Set(['short-probe','capture','capture-preserved','attach','seal','restore','publish','verify','publish-check','finish-published']);
fx.createMigrationSkillBackupFixture=function(...args){const f=original(...args),factory=f.api.migrationCapsuleBroker;f.replace('migrationCapsuleBroker',async()=>{const broker=await factory();return Object.freeze({command:async value=>{const command=allowed.has(value?.cmd)?value.cmd:'other';console.log(JSON.stringify({diagnostic:'owned.deep.command.start',command}));try{return await broker.command(value);}catch(error){const code=typeof error?.code==='string'&&/^[A-Za-z0-9_.-]{1,128}$/.test(error.code)?error.code:null;console.log(JSON.stringify({diagnostic:'owned.deep.command.failure',command,code}));throw error;}},close:()=>broker.close()});});return f;};
