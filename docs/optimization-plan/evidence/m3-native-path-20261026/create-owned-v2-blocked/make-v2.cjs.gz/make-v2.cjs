'use strict';
const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict'),c=require('node:crypto'),{functionBlock}=require('C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss/dev-harness/lib/source-slice');
const V1='C:/Users/87179/AppData/Local/Temp/ruyi-create-owned-cleanup-fix-20261026-a23da9c7',sha=x=>c.createHash('sha256').update(x).digest('hex'),v1=fs.readFileSync(p.join(V1,'13u-after.js'),'utf8'),before=fs.readFileSync(p.join(V1,'13u-before.js'),'utf8');a.equal(sha(v1),'9d6e01e62a69dce441b4f9b446cd8e67851f8440dd4d800d61ea5f78bcdcc84d');a.equal(sha(before),'02d2edd58e4463723e592f1ba56a64b718c903382541b436aa14c8ddc1f827fb');
const graph=`  const hasUncertainty=root=>{
    const active=new Set(),done=new Set();let nodes=0;
    const walk=(value,depth)=>{
      if(value===null||!['object','function'].includes(typeof value))return false;
      if(require('node:util').types.isProxy(value)||depth>8||active.has(value))return true;if(done.has(value))return false;if(++nodes>64)return true;active.add(value);
      try{
        let proto=value;const seen=new Set();for(let level=0;proto!==null&&level<8;level++){
          if(require('node:util').types.isProxy(proto)||seen.has(proto))return true;seen.add(proto);const flag=Object.getOwnPropertyDescriptor(proto,'helperMayStillRun');
          if(flag&&(!Object.hasOwn(flag,'value')||flag.value!==false))return true;
          if(proto!==value&&(Object.getOwnPropertyDescriptor(proto,'cause')||Object.getOwnPropertyDescriptor(proto,'errors')))return true;
          proto=Object.getPrototypeOf(proto);
        }if(proto!==null)return true;
        if(Array.isArray(value)){
          const length=Object.getOwnPropertyDescriptor(value,'length');if(!length||!Object.hasOwn(length,'value')||!Number.isSafeInteger(length.value)||length.value<0||length.value>16)return true;
          for(let index=0;index<length.value;index++){const item=Object.getOwnPropertyDescriptor(value,String(index));if(!item||!Object.hasOwn(item,'value')||walk(item.value,depth+1))return true;}
        }
        for(const key of ['cause','errors']){const edge=Object.getOwnPropertyDescriptor(value,key);if(!edge)continue;if(!Object.hasOwn(edge,'value')||key==='errors'&&!Array.isArray(edge.value)||walk(edge.value,depth+1))return true;}
        done.add(value);return false;
      }catch{return true;}finally{active.delete(value);}
    };return walk(root,0);
  };
`;
let after=v1;const edits=[];function edit(before,afterText){a.equal(after.split(before).length,2);after=after.replace(before,afterText);edits.push({before,after:afterText});}
edit('  let broker,result,failure,failed=false,started=false;\n','  let broker,result,failure,failed=false,started=false;\n'+graph);
edit('failure=migrationCapturedCleanupFailure(failure,failed,cleanupErrors,cleanupUnproven);','failure=migrationCapturedCleanupFailure(failure,failed,cleanupErrors,cleanupUnproven||(failed&&hasUncertainty(failure))||cleanupErrors.some(hasUncertainty));');
edit('const helperMayStillRun=migrationCapturedCleanupFailure(failure,true,[],false).helperMayStillRun;','const helperMayStillRun=hasUncertainty(failure);');
let inverse=after;for(const row of edits.slice().reverse()){a.equal(inverse.split(row.after).length,2);inverse=inverse.replace(row.after,row.before);}a.equal(inverse,v1);
const fnOld=functionBlock(before,'migrationCapsuleCreateOwnedPortable'),fnNew=functionBlock(after,'migrationCapsuleCreateOwnedPortable');a.equal(before.split(fnOld).length,2);a.equal(before.replace(fnOld,fnNew),after);a.equal(after.replace(fnNew,fnOld),before);
fs.writeFileSync(p.join(__dirname,'13u-before.js'),before,{flag:'wx'});fs.writeFileSync(p.join(__dirname,'13u-blocked-v1.js'),v1,{flag:'wx'});fs.writeFileSync(p.join(__dirname,'13u-after.js'),after,{flag:'wx'});
fs.writeFileSync(p.join(__dirname,'spans.json'),JSON.stringify({schema:1,baseline02d2:sha(before),blockedV1:sha(v1),afterSha256:sha(after),localV1Edits:edits,wholeInverseToV1:true,baselineSpan:{before:fnOld,after:fnNew},wholeInverseTo02d2:true},null,2)+'\n',{flag:'wx'});
for(const name of ['cleanup.test.cjs','original-image-repro.cjs','original-image-repro.log'])fs.copyFileSync(p.join(V1,name),p.join(__dirname,name),fs.constants.COPYFILE_EXCL);
fs.copyFileSync('C:/Users/87179/AppData/Local/Temp/ruyi-create-cleanup-root-review-HiIFsW/nested-unknown-repro.json',p.join(__dirname,'blocked-v1-root-repro.json'),fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({source:sha(after),oneFunctionOnly:true,mainInvoked:false}));
