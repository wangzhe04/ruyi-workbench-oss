'use strict';
const helper=require('C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss/dev-harness/lib/server-internals'),load=helper.loadServerInternals;
helper.loadServerInternals=function(names,options){const api=load(names,{...options,withEval:true});api.__eval(`{
 const original=migrationCapsuleBroker;
 const observed=async()=>{const broker=await original();return Object.freeze({command:async args=>{const command=typeof args?.cmd==='string'&&/^[a-z-]{1,64}$/.test(args.cmd)?args.cmd:'unsupported';const lengths={};for(const key of ['root','source','target','container'])if(typeof args[key]==='string')lengths[key]=args[key].length;console.log(JSON.stringify({diagnostic:'representation.native.command.start',command,lengths}));try{return await broker.command(args);}catch(cause){console.log(JSON.stringify({diagnostic:'representation.native.command.failure',command,code:typeof cause?.code==='string'&&/^[A-Za-z0-9_.-]{1,128}$/.test(cause.code)?cause.code:null}));throw cause;}},close:()=>broker.close()});};
 Object.defineProperty(observed,'helperMayStillRun',{get:()=>original.helperMayStillRun,set:value=>{original.helperMayStillRun=value;}});migrationCapsuleBroker=observed;
 }`);return api;};
