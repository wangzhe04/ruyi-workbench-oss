'use strict';
const fs=require('node:fs'),a=require('node:assert/strict');
const ROOT='C:/Users/87179/AppData/Local/Temp/ruyi-m3-complete-support-review-20261026-75be2919',source=fs.readFileSync(ROOT+'/private-native.cs','utf8'),live=fs.readFileSync(ROOT+'/live-native.cs','utf8');
const create=source.slice(source.indexOf('  static object CreateOwnedPortableCore('),source.indexOf('  public static void Run()'));
a.ok(create.indexOf('string id=Id(node.Handle);')<create.indexOf('Nodes.Add(id,node)'));
a.ok(create.includes('if(Nodes.Count!=0 || Capsule!=null) Reject("already_open")'));
const close=source.slice(source.indexOf('  static void Close()'),source.indexOf('  static void StoreFileSystem('));a.ok(close.includes('foreach (Node node in Nodes.Values)'));
// A deliberately small language-control-flow model, not C#/Win32 execution.
const nodes=new Map(),handle={disposed:false},node={handle};let negativeACK=false;
try{const id=(()=>{throw Error('unsupported_object');})();nodes.set(id,node);}catch{negativeACK=true;}
for(const node of nodes.values())node.handle.disposed=true;
a.equal(negativeACK,true);a.equal(handle.disposed,false);a.equal(nodes.size,0);
const rawProtocolReuseAdmitted=nodes.size===0; // Core's actual already_open predicate.
a.equal(rawProtocolReuseAdmitted,true);
const primary=Error('capture_primary'),cleanup=Error('restore_metadata_cleanup');let observed,preserved=true;
try{try{throw primary;}finally{try{throw cleanup;}finally{preserved=false;}}}catch(error){observed=error;}
a.equal(observed,cleanup);a.equal(preserved,false);
a.ok(live.includes('else if (command == "capture-preserved") { try { result=Capture(args); } finally { RestoreBasic(new List<Node>(Nodes.Values)); } }'));
a.ok(source.includes('try {return Capture(args);}')&&source.includes('finally {try {RestoreBasic(new List<Node>(Nodes.Values));} finally {PreserveTimeHandles=previous;}}'));
console.log(JSON.stringify({noNative:true,modelOnly:true,sourceOrderWitness:true,unregisteredHandleNotDisposedByNativeCloseRegistry:true,rawWireRetryAnotherRootNotPreventedByAlreadyOpenWhenRegistrationNeverOccurred:rawProtocolReuseAdmitted,normalJSCreateWrapperDoesNotExposeThisReuse:true,actualProcessExitStillReclaimsItsHandles:true,cleanupCanReplaceCapturePrimary:true,maskingWasAlreadyInLiveF79:true}));
