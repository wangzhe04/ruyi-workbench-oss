'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto');
const root=__dirname,temp=p.dirname(root),runtime=p.join(temp,'r31p-sgNqTk/runtime/app/src'),driver=p.join(temp,'ruyi-special-snapshot-diagnostic-20261026-779a8af1/ordinary-mode-gate.cjs');
const hash=x=>c.createHash('sha256').update(x).digest('hex'),spans=[];
function change(file,name,edits){const original=fs.readFileSync(file),text=original.toString('utf8');fs.writeFileSync(p.join(root,name+'.before'),original);let result=text;
 for(const [from,to]of edits){if(result.split(from).length!==2)throw Error('span not unique: '+from);spans.push({file:name,from,to});result=result.replace(from,to);}
 let reversed=result;for(const [from,to]of [...edits].reverse()){if(reversed.split(to).length!==2)throw Error('reverse not unique');reversed=reversed.replace(to,from);}if(reversed!==text)throw Error('not reversible');
 fs.writeFileSync(p.join(root,name),result);return{path:file,originalSha256:hash(original),candidateSha256:hash(result),bytes:Buffer.byteLength(result)};}
const host=change(p.join(runtime,'01ad-work-data-migration-host.js'),'01ad-work-data-migration-host.js',[
 ['function create({base,ownership,assertExclusive,manifest,','function create({base,ownership,assertExclusive,assertExclusiveSync,preservedRead,manifest,'],
 ["    base=p.resolve(base);const tree=WorkDataTree.create(limits),issued=new WeakMap(),published=new WeakMap();let busy=false;", "    if(assertExclusiveSync!==undefined&&typeof assertExclusiveSync!=='function')fail('host_invalid');\n    if(preservedRead!==undefined&&(preservedRead?.profile!=='bounded-native-v1'||typeof preservedRead.capturePreserved!=='function'||typeof WorkDataTree.createPreserved!=='function'))fail('preserved_reader_invalid');\n    base=p.resolve(base);const tree=WorkDataTree.create(limits),sourceTree=preservedRead===undefined?tree:WorkDataTree.createPreserved({capturePreserved:preservedRead.capturePreserved,ownership,assertExclusive,assertExclusiveSync,limits}),issued=new WeakMap(),published=new WeakMap();let busy=false;"],
 ['const snapshot=await tree.capture(base);try{','const snapshot=await sourceTree.capture(base);try{'],
 ['await checkSource(plan);const source=await tree.capture(expected.root);','await checkSource(plan);const source=await sourceTree.capture(expected.root);'],
 ['const complete=await tree.capture(base);try{const source=','const complete=await sourceTree.capture(base);try{const source='],
 ["WorkDataStore.createText({...d,file:()=>p.join(base,...row.path.split('/')),keys:plan.keys,", "WorkDataStore.createText({...d,file:()=>p.join(base,...row.path.split('/')),...(preservedRead===undefined?{}:{capturedFile:()=>WorkDataTree.borrowCapturedFile(complete,p.join(base,...row.path.split('/')),ownership,{maxBytes:256*1024*1024})}),keys:plan.keys,"],
 ['}finally{portable.release();}await tree.verify(complete);','}finally{portable.release();}await sourceTree.verify(complete);']
]);
const gate=change(driver,'ordinary-mode-gate.cjs',[
 ['api.WorkDataMigrationHost.create({base:input.base,ownership:owner,assertExclusive:check,manifest,','api.WorkDataMigrationHost.create({base:input.base,...ownerProfile(api,input.base,owner,owners),manifest,']
]);
const dependencies={};for(const name of ['01aa-work-data-tree.js','01p-work-data-store.js','01ab-work-data-full-snapshot.js','01x-work-data-migration-codecs.js','13u-migration-center.js']){const bytes=fs.readFileSync(p.join(runtime,name));fs.writeFileSync(p.join(root,name+'.input'),bytes);dependencies[name]=hash(bytes);}
fs.writeFileSync(p.join(root,'spans.json'),JSON.stringify(spans,null,2));fs.writeFileSync(p.join(root,'identity.json'),JSON.stringify({host,gate,dependencies,spansSha256:hash(fs.readFileSync(p.join(root,'spans.json')))},null,2));
console.log(JSON.stringify({root,host,gate,dependencies},null,2));
