'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),root=__dirname,input=p.join(root,'v2'),out=p.join(root,'v3'),hash=x=>c.createHash('sha256').update(x).digest('hex');fs.mkdirSync(out,{recursive:true});
const source=fs.readFileSync(p.join(input,'01ad-work-data-migration-host.js'),'utf8');let text=source;const spans=[];
function replace(from,to){if(text.split(from).length!==2)throw Error('not unique');text=text.replace(from,to);spans.push({from,to});}
replace('    function closeSource(value,primary,failed){',`    // Observe rejection only for a descriptor-checked native Promise. Calling
    // even the intrinsic then on an unchecked Promise runs constructor/species.
    // Observation never makes a non-void synchronous release an accepted close.
    function observeSourcePromise(value){
      const types=require('node:util').types;
      try{
        if(types.isProxy(value)||!types.isPromise(value))return;
        const data=(object,name)=>{
          let found=false,result;const seen=new Set();
          for(let depth=0;object!==null;depth++){
            if(depth>=8||types.isProxy(object)||seen.has(object))throw new Error('source_promise_untrusted');seen.add(object);
            const descriptor=Object.getOwnPropertyDescriptor(object,name);
            if(!found&&descriptor){if(!Object.hasOwn(descriptor,'value'))throw new Error('source_promise_untrusted');found=true;result=descriptor.value;}
            object=Object.getPrototypeOf(object);
          }
          if(!found)throw new Error('source_promise_untrusted');return result;
        };
        const ctor=data(value,'constructor'),then=data(value,'then'),nativeText=fn=>Function.prototype.toString.call(fn);
        if(typeof ctor!=='function'||typeof then!=='function'||types.isProxy(ctor)||types.isProxy(then)
          ||nativeText(ctor)!=='function Promise() { [native code] }'||nativeText(then)!=='function then() { [native code] }')return;
        const species=Object.getOwnPropertyDescriptor(ctor,Symbol.species);
        if(!species)return;
        if(Object.hasOwn(species,'value')){if(species.value!==undefined&&species.value!==null&&species.value!==ctor)return;}
        else if(typeof species.get!=='function'||types.isProxy(species.get)||species.set!==undefined
          ||nativeText(species.get)!=='function get [Symbol.species]() { [native code] }')return;
        Reflect.apply(then,value,[undefined,()=>{}]);
      }catch{/* Untrusted promises remain unobserved and the release remains uncertain. */}
    }
    function closeSource(value,primary,failed){`);
replace("if(require('node:util').types.isPromise(result))Promise.prototype.then.call(result,undefined,()=>{});",'observeSourcePromise(result);');
let reversed=text;for(const{from,to}of [...spans].reverse()){if(reversed.split(to).length!==2)throw Error('reverse not unique');reversed=reversed.replace(to,from);}if(reversed!==source)throw Error('reversal');
fs.writeFileSync(p.join(out,'01ad-work-data-migration-host.js'),text);fs.writeFileSync(p.join(out,'v3-spans.json'),JSON.stringify(spans,null,2));
for(const name of ['01ad-work-data-migration-host.js.before','ordinary-mode-gate.cjs','ordinary-mode-gate.cjs.before','01aa-work-data-tree.js.input','01p-work-data-store.js.input','01ab-work-data-full-snapshot.js.input','01x-work-data-migration-codecs.js.input','13u-migration-center.js.input','pure.test.cjs'])fs.copyFileSync(p.join(input,name),p.join(out,name));
const identity=JSON.parse(fs.readFileSync(p.join(input,'identity.json'),'utf8'));identity.host.v2CandidateSha256=identity.host.candidateSha256;identity.host.candidateSha256=hash(text);identity.host.bytes=Buffer.byteLength(text);identity.v3SpansSha256=hash(fs.readFileSync(p.join(out,'v3-spans.json')));identity.promiseContractReference={path:'C:/Users/87179/AppData/Local/Temp/ruyi-create-owned-cleanup-v2-20261026-c288465a/13u-after.js',sha256:'aedd4015dfb162cfb1fec93d4cfd175cb8edc5a4a3dde06a80e07d6919a84d18'};fs.writeFileSync(p.join(out,'identity.json'),JSON.stringify(identity,null,2));
console.log(JSON.stringify({out,sha256:hash(text),spans:spans.length}));
