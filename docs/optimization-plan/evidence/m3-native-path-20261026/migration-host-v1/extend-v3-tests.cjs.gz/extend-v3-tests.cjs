'use strict';
const fs=require('node:fs'),p=require('node:path'),file=p.join(__dirname,'v3/pure.test.cjs');let s=fs.readFileSync(file,'utf8');function replace(from,to){if(s.split(from).length!==2)throw Error('not unique '+from);s=s.replace(from,to);}
replace("candidate=fs.readFileSync(p.join(dir,'01ad-work-data-migration-host.js'),'utf8')","candidate=fs.readFileSync(p.join(dir,process.argv.includes('--v2-control')?'../v2/01ad-work-data-migration-host.js':'01ad-work-data-migration-host.js'),'utf8')");
replace("const identity=JSON.parse(fs.readFileSync(p.join(dir,'identity.json'),'utf8'))","const identity=JSON.parse(fs.readFileSync(p.join(dir,process.argv.includes('--v2-control')?'../v2/identity.json':'identity.json'),'utf8'))");
replace("console.log('PURE SOURCE VM: ALL PASS ('+count+'); native model only, no Windows causality claim');",`
 const cleanupResult=async result=>{const f=fixture(candidate,{preserved:true,sync:true,releaseFaults:{1:()=>result}}),error=await captureError(f.prepare());a.equal(error.code,'work_data_migration_host.source_cleanup');a.equal(error.errors.length,1);a.equal(error.errors[0].message,'source_release_unproven');a.equal(error.helperMayStillRun,true);a.equal(error.ownershipRetained,true);return error;};
 for(const property of ['constructor','then']){
   let getterCalls=0;const result=Promise.resolve();Object.defineProperty(result,property,{get(){getterCalls++;return property==='constructor'?Promise:Promise.prototype.then;}});await cleanupResult(result);console.log(JSON.stringify({counter:'native-promise-own-'+property+'-getter',getterCalls}));a.equal(getterCalls,0,'cleanup must not execute foreign Promise '+property+' getters');
 }pass('root constructor getter counter and own then getter remain zero');
 for(const variant of ['species-getter','species-getter-proxy','species-constructor-proxy','species-custom-constructor']){
   let calls=0;const foreign=vm.runInNewContext('({ctor:Promise,pending:Promise.resolve()})');
   if(variant==='species-getter')Object.defineProperty(foreign.ctor,Symbol.species,{get(){calls++;return foreign.ctor;}});
   if(variant==='species-getter-proxy'){const getter=Object.getOwnPropertyDescriptor(foreign.ctor,Symbol.species).get;Object.defineProperty(foreign.ctor,Symbol.species,{get:new Proxy(getter,{apply(target,thisValue,args){calls++;return Reflect.apply(target,thisValue,args);}})});}
   if(variant==='species-constructor-proxy')Object.defineProperty(foreign.ctor,Symbol.species,{value:new Proxy(foreign.ctor,{construct(target,args){calls++;return Reflect.construct(target,args);}})});
   if(variant==='species-custom-constructor')Object.defineProperty(foreign.ctor,Symbol.species,{value:function(executor){calls++;return new Promise(executor);}});
   await cleanupResult(foreign.pending);console.log(JSON.stringify({counter:variant,calls}));a.equal(calls,0,variant+' must not execute external species code');
 }pass('species getter Proxy getter Proxy constructor and custom species code remain unexecuted');
 for(const variant of ['prototype-proxy','prototype-constructor-getter','constructor-proxy','then-proxy']){
   let calls=0;const result=Promise.resolve();
   if(variant==='prototype-proxy')Object.setPrototypeOf(result,new Proxy(Promise.prototype,{get(target,key,receiver){calls++;return Reflect.get(target,key,receiver);},getOwnPropertyDescriptor(target,key){calls++;return Reflect.getOwnPropertyDescriptor(target,key);},getPrototypeOf(target){calls++;return Reflect.getPrototypeOf(target);}}));
   if(variant==='prototype-constructor-getter')Object.setPrototypeOf(result,Object.create(Promise.prototype,{constructor:{get(){calls++;return Promise;}}}));
   if(variant==='constructor-proxy')Object.defineProperty(result,'constructor',{value:new Proxy(Promise,{get(target,key,receiver){calls++;return Reflect.get(target,key,receiver);},getOwnPropertyDescriptor(target,key){calls++;return Reflect.getOwnPropertyDescriptor(target,key);}})});
   if(variant==='then-proxy')Object.defineProperty(result,'then',{value:new Proxy(Promise.prototype.then,{apply(target,thisValue,args){calls++;return Reflect.apply(target,thisValue,args);}})});
   await cleanupResult(result);console.log(JSON.stringify({counter:variant,calls}));a.equal(calls,0,variant+' must not execute external proxy traps or getters');
 }pass('Promise prototype constructor and then Proxy traps and inherited getters remain zero');
 for(const result of [Promise.reject(Error('trusted same realm rejection')),vm.runInNewContext('Promise.reject(new Error("trusted other realm rejection"))')])await cleanupResult(result);
 await new Promise(resolve=>setImmediate(resolve));pass('trusted same and cross realm native rejection is observed under strict unhandled rejection mode and still refuses release');
 const primary=false,nonvoid=Promise.resolve(),falsyPromise=fixture(candidate,{preserved:true,sync:true,workFaults:{1:primary},releaseFaults:{1:()=>nonvoid}}),falsyError=await captureError(falsyPromise.prepare());a.equal(falsyError.errors[0],false);a.equal(falsyError.errors[1].message,'source_release_unproven');a.equal(falsyError.cause,false);a.equal(falsyError.helperMayStillRun,true);pass('Promise observation never makes nonvoid release successful or reorders falsy primary');
 console.log('PURE SOURCE VM: ALL PASS ('+count+'); native model only, no Windows causality claim');`);
fs.writeFileSync(file,s);
