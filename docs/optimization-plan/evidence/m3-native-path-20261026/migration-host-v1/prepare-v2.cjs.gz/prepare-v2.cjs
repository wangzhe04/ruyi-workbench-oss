'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),root=__dirname,out=p.join(root,'v2'),hash=x=>c.createHash('sha256').update(x).digest('hex');fs.mkdirSync(out,{recursive:true});
const spans=[],original=fs.readFileSync(p.join(root,'01ad-work-data-migration-host.js'),'utf8');let text=original;
function replace(from,to){if(text.split(from).length!==2)throw Error('not unique: '+from);text=text.replace(from,to);spans.push({from,to});}
replace("    const admission=async()=>{if(await assertExclusive(ownership)!==true)fail('ownership_required');};",`    const admission=async()=>{if(await assertExclusive(ownership)!==true)fail('ownership_required');};
    // A preserved source lease can fail to close. Keep its primary failure,
    // even when falsy, and never convert uncertain cleanup into a safe release.
    const sourceUnknown = value => {
      const queue=[value],seen=new Set();let visited=0;
      try { while(queue.length) {
        const item=queue.shift();if(item===null||!['object','function'].includes(typeof item))continue;
        if(require('node:util').types.isProxy(item))return true;
        if(seen.has(item))return true;seen.add(item);if(++visited>64)return true;
        if(Array.isArray(item)) {
          const length=Object.getOwnPropertyDescriptor(item,'length');if(!length||!Object.hasOwn(length,'value')||length.value>64)return true;
          for(let index=0;index<length.value;index++){const entry=Object.getOwnPropertyDescriptor(item,String(index));if(!entry||!Object.hasOwn(entry,'value'))return true;queue.push(entry.value);}
        }
        let current=item;
        for(let depth=0;current!==null;depth++) {
          if(depth>=8||require('node:util').types.isProxy(current))return true;
          for(const name of ['helperMayStillRun','cause','errors']) {
            const descriptor=Object.getOwnPropertyDescriptor(current,name);if(!descriptor)continue;
            if(!Object.hasOwn(descriptor,'value'))return true;
            if(name==='helperMayStillRun'){if(descriptor.value!==false&&descriptor.value!==undefined)return true;}
            else if(name==='cause')queue.push(descriptor.value);
            else if(descriptor.value!==undefined) {
              const list=descriptor.value;if(!Array.isArray(list)||require('node:util').types.isProxy(list))return true;
              const length=Object.getOwnPropertyDescriptor(list,'length');if(!length||!Object.hasOwn(length,'value')||length.value>64)return true;
              for(let index=0;index<length.value;index++){const entry=Object.getOwnPropertyDescriptor(list,String(index));if(!entry||!Object.hasOwn(entry,'value'))return true;queue.push(entry.value);}
            }
          }
          current=Object.getPrototypeOf(current);
        }
      }return false;}catch{return true;}
    };
    const sourceFailure=(primary,failed,errors,releaseFailed)=>{
      const causes=[...(failed?[primary]:[]),...errors],code='work_data_migration_host.source_cleanup';
      return Object.assign(new AggregateError(causes,code,{cause:causes[0]}),{code,apiCode:code,statusCode:503,cleanupFailed:true,ownershipRetained:true,helperMayStillRun:releaseFailed||sourceUnknown(causes)});
    };
    function closeSource(value,primary,failed){
      const errors=[];let releaseFailed=false;
      try{const result=value.release();if(result!==undefined){
        if(require('node:util').types.isPromise(result))Promise.prototype.then.call(result,undefined,()=>{});
        releaseFailed=true;throw new Error('source_release_unproven');
      }}catch(cause){releaseFailed=true;errors.push(cause);}
      if(errors.length)throw sourceFailure(primary,failed,errors,releaseFailed);
      if(failed)throw primary;
    }
    async function usingSource(value,work){
      if(preservedRead===undefined){try{return await work(value);}finally{value.release();}}
      let result,primary,failed=false;try{result=await work(value);}catch(cause){failed=true;primary=cause;}
      closeSource(value,primary,failed);return result;
    }
    async function usingPlanSource(plan,release,work){
      if(preservedRead===undefined)return work();
      let result,primary,failed=false;try{result=await work();}catch(cause){failed=true;primary=cause;}
      if(release()&&plan.sourceCapture){const source=plan.sourceCapture;plan.sourceCapture=null;closeSource(source,primary,failed);}
      else if(failed)throw primary;return result;
    }`);
replace('const snapshot=await sourceTree.capture(base);try{','return usingSource(await sourceTree.capture(base),async snapshot=>{');
replace('      }finally{snapshot.release();}\n    }\n    async function writeNew','      });\n    }\n    async function writeNew');
replace('await checkSource(plan);const source=await sourceTree.capture(expected.root);plan.disposable.push(source);','await checkSource(plan);const source=await sourceTree.capture(expected.root);if(preservedRead===undefined)plan.disposable.push(source);else plan.sourceCapture=source;');
replace("const complete=await sourceTree.capture(base);try{const source=", "await usingSource(await sourceTree.capture(base),async complete=>{const source=");
replace("try{const value=JSON.parse(strict(portable.data));if(!value.records.some(row=>row.kind==='catalog')||value.records.some(row=>row.kind==='history'||row.kind==='binding'&&row.value.entries.length))fail('special_owner_change_proof_required');}finally{portable.release();}await sourceTree.verify(complete);\n            }finally{complete.release();}", "await usingSource(portable,async()=>{const value=JSON.parse(strict(portable.data));if(!value.records.some(row=>row.kind==='catalog')||value.records.some(row=>row.kind==='history'||row.kind==='binding'&&row.value.entries.length))fail('special_owner_change_proof_required');});await sourceTree.verify(complete);\n            });");
replace("}catch(cause){for(const item of plan.disposable.reverse()){try{item.release?.();item.clear?.();}catch{}}if(!plan.mutationStarted)","}catch(cause){for(const item of plan.disposable.reverse()){try{item.release?.();item.clear?.();}catch{}}if(preservedRead!==undefined&&plan.sourceCapture){const source=plan.sourceCapture;plan.sourceCapture=null;try{closeSource(source,cause,true);}catch(failure){cause=failure;}}if(!plan.mutationStarted)");
replace("retry:false,candidateRetained:plan.candidate?.root||null});}","retry:false,candidateRetained:plan.candidate?.root||null,...(preservedRead!==undefined&&sourceUnknown(cause)?{helperMayStillRun:true,ownershipRetained:true}:{})});}");
replace('let publishing=false;try{await admission();publishing=true;','let publishing=false;return usingPlanSource(plan,()=>publishing,async()=>{try{await admission();publishing=true;');
replace("code:'work_data_migration_host.publish_failed',commitUncertain:true,retry:false});}finally{if(publishing)","code:'work_data_migration_host.publish_failed',commitUncertain:true,retry:false,...(preservedRead!==undefined&&sourceUnknown(cause)?{helperMayStillRun:true,ownershipRetained:true}:{})});}finally{if(publishing)");
replace('}catch{}}}});}\n    async function cancel','}catch{}}}});});}\n    async function cancel');
replace('await current(plan.expected);try{await plan.special.recoverRepresentation();','await current(plan.expected);return usingPlanSource(plan,()=>true,async()=>{try{await plan.special.recoverRepresentation();');
replace('}catch{}}}});}\n    async function verifyPublished','}catch{}}}});});}\n    async function verifyPublished');
let reversed=text;for(const{from,to}of [...spans].reverse()){if(reversed.split(to).length!==2)throw Error('not reverse unique');reversed=reversed.replace(to,from);}if(reversed!==original)throw Error('not reversible');
fs.writeFileSync(p.join(out,'01ad-work-data-migration-host.js'),text);fs.writeFileSync(p.join(out,'v2-spans.json'),JSON.stringify(spans,null,2));
const identity=JSON.parse(fs.readFileSync(p.join(root,'identity.json'),'utf8'));identity.host.v1CandidateSha256=identity.host.candidateSha256;identity.host.candidateSha256=hash(text);identity.host.bytes=Buffer.byteLength(text);identity.v2SpansSha256=hash(fs.readFileSync(p.join(out,'v2-spans.json')));fs.writeFileSync(p.join(out,'identity.json'),JSON.stringify(identity,null,2));
for(const name of ['01ad-work-data-migration-host.js.before','ordinary-mode-gate.cjs','ordinary-mode-gate.cjs.before','01aa-work-data-tree.js.input','01p-work-data-store.js.input','01ab-work-data-full-snapshot.js.input','01x-work-data-migration-codecs.js.input','13u-migration-center.js.input','pure.test.cjs'])fs.copyFileSync(p.join(root,name),p.join(out,name));
console.log(JSON.stringify({out,sha256:hash(text),spans:spans.length}));
