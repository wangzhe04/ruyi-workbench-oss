'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),p=require('node:path'),vm=require('node:vm'),c=require('node:crypto'),{EventEmitter}=require('node:events');
const repo='C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss',root=__dirname,source=fs.readFileSync(process.env.RETRY_API_SOURCE||p.join(root,'13w-external-bots.js'),'utf8');
const {fixture,plain,until}=require(repo+'/dev-harness/lib/external-bots-inbox-fixture'),{functionBlock,constBlock}=require(repo+'/dev-harness/lib/source-slice');
const target='/api/external-bots/deliveries/retry',request=(x,id='retry_request_00000001')=>({id:x.id,expectedAttemptId:x.delivery.attemptId,retryRequestId:id});
function make({worker=false,...options}={}) {
 const f=fixture({source,...options});f.trace={wakes:0,acks:0,bodyReads:0};f.auth={token:true,origin:true};
 Object.assign(f.context,{tokenOk:()=>f.auth.token,originOk:()=>f.auth.origin,json:(body,status=200)=>({body,status}),apiFailure:(code,params,message,status)=>({body:{ok:false,error:code},status}),send:(res,result)=>{f.trace.acks++;res.result=plain(result);res.writableEnded=true;}});
 vm.runInContext('api.http=handleExternalBotApiRoutes;api.workerBusy=()=>externalBotWorkerBusy;api.workerAgain=()=>externalBotWorkerAgain;api.workerStopped=value=>{externalBotWorkerStopped=value;};api.retry=body=>runKeyedChain(externalBotChains,"state",()=>externalBotRetryReply(body,EXTERNAL_BOT_LOCAL_REPLY_RETRY));',f.context);
 f.context.onWake=()=>{f.trace.wakes++;};
 vm.runInContext('const originalWake=externalBotWakeWorker;externalBotWakeWorker=()=>{onWake();return originalWake();};',f.context);
 f.api.workerStopped(!worker);
 f.call=(body,options={})=>{
  const req=new EventEmitter(),res=new EventEmitter();req.url=options.url||target;req.method=options.method||'POST';req.complete=true;req.headers=options.headers||{};
  req.pause=()=>{};req.destroy=()=>{req.destroyed=true;};res.destroyed=options.lost===true;res.writableEnded=false;res.setHeader=()=>{};
  const promise=f.api.http(req,res,options.pathname||new URL(req.url,'http://localhost').pathname);
  queueMicrotask(()=>{if(req.listenerCount('data')){f.trace.bodyReads++;req.emit('data',options.raw||Buffer.from(JSON.stringify(body)));req.emit('end');}});
  return promise.then(handled=>({handled,result:res.result,res}));
 };return f;
}
async function failed(options={},errorCode='external_delivery.predispatch'){
 const f=make(options);await f.api.update({op:'upsert',connection:{...f.connection,mode:'control',ownerSenderId:'user_a',ownerConversationId:'room_a',ownerConversationType:'group'},controlConfirmed:true});
 await f.api.accept(f.message());await f.api.finish(await f.api.next(),{ok:true,say:'EXACT BUSINESS REPLY MUST NOT RERUN',turnSeq:1});
 await f.api.finish(await f.api.next(),{status:'failed',errorCode});return f;
}
async function item(f){return(await f.api.read()).items[0];}
function channel(f){
 const messages=[],requests=[];
 f.context.require=name=>{a.equal(name,'node:https');return{request(options,cb){const req=new EventEmitter();req.destroy=()=>{};req.end=bytes=>{requests.push(options.path);if(!options.path.includes('getAppAccessToken'))messages.push(Buffer.from(bytes));queueMicrotask(()=>{const res=new EventEmitter();res.statusCode=200;res.headers={};res.destroy=()=>{};cb(res);res.emit('data',Buffer.from(JSON.stringify(options.path.includes('getAppAccessToken')?{access_token:'FAKE'}:{id:'official_reply'})));res.emit('end');});};return req;}};};
 f.context.PrivacyGateway={withPolicy:(_scope,work)=>work(),disclosurePolicyGuard:()=>()=>{},prepareDisclosure:async()=>({receipt:{}}),refreshDisclosure:async()=> 'PROTECTED_REPLY',assertDisclosure(){}};
 vm.runInContext(fs.readFileSync(p.join(repo,'ruyi-workbench/app/src/13x-external-channel-delivery.js'),'utf8'),f.context);return{messages,requests};
}

test('root counter: same explicit human receipt resumes sole durable pending attempt after writer lost result',async()=>{
 const f=await failed({worker:true}),outbound=channel(f),body=request(await item(f)),writer=f.context.atomicWriteJson;
 f.context.atomicWriteJson=async(...args)=>{await writer(...args);throw Error('synthetic lost commit result');};
 const first=await f.call(body);a.equal(first.result.body.error,'external_channel.storage_unavailable');a.equal(f.trace.wakes,0);
 f.context.atomicWriteJson=writer;const pending=plain(await item(f)),bytes=f.disk(),writes=f.counts().writes;
 const again=await f.call(body);a.equal(again.result.body.alreadyRetried,true);a.equal(again.result.body.receipt.attemptId,pending.delivery.attemptId);
 for(let tick=0;tick<4;tick++)await new Promise(setImmediate);
 await until(()=>!f.api.workerBusy());
 const current=await item(f);console.log(JSON.stringify({counter:'root-lost-commit-result-human-reconcile',status:current.delivery.status,wakes:f.trace.wakes,businessRuns:f.counts().runs,messageRequests:outbound.messages.length,history:current.replyHistory.length,workerBusy:f.api.workerBusy()}));
 a.equal(current.delivery.status,'sent','same explicit human request must resume its one durable pending reply');a.equal(outbound.messages.length,1);a.equal(f.counts().runs,0);
 a.equal(current.replyHistory.length,1);a.equal(current.delivery.attemptId,pending.delivery.attemptId);a.equal(f.trace.wakes,1);a.equal(f.counts().writes,writes+2);
});
test('twenty concurrent stable receipt resumes produce one MESSAGE and no new attempt or business work',async()=>{
 const f=await failed({worker:true}),outbound=channel(f),body=request(await item(f)),writer=f.context.atomicWriteJson;
 f.context.atomicWriteJson=async(...args)=>{await writer(...args);throw Error('lost commit result');};await f.call(body);f.context.atomicWriteJson=writer;
 const pending=plain(await item(f)),responses=await Promise.all(Array.from({length:20},()=>f.call(body)));await until(()=>!f.api.workerBusy());
 for(const response of responses){a.equal(response.result.body.alreadyRetried,true);a.equal(response.result.body.receipt.attemptId,pending.delivery.attemptId);}
 const done=await item(f);a.equal(done.delivery.status,'sent');a.equal(done.delivery.attemptId,pending.delivery.attemptId);a.equal(done.replyHistory.length,1);a.equal(outbound.messages.length,1);a.equal(f.counts().runs,0);
 const wakes=f.trace.wakes,again=await f.call(body);a.equal(again.result.body.alreadyRetried,true);a.equal(f.trace.wakes,wakes);a.equal(outbound.messages.length,1);
});
test('old durable receipt never wakes a later pending attempt even when old request ID is valid',async()=>{
 const f=await failed(),one=request(await item(f)),first=await f.call(one);await f.api.finish(await f.api.next(),{status:'failed',errorCode:'external_delivery.token_network'});
 const two=request(await item(f),'retry_request_00000002');await f.call(two);const pending=await item(f),writes=f.counts().writes,wakes=f.trace.wakes,bytes=f.disk();
 const old=await f.call(one);a.equal(old.result.body.alreadyRetried,true);a.equal(old.result.body.item.delivery.status,'pending');a.notEqual(old.result.body.item.delivery.attemptId,old.result.body.receipt.attemptId);
 a.deepEqual(old.result.body.receipt,first.result.body.receipt);a.equal(f.trace.wakes,wakes);a.equal(f.disk(),bytes);a.equal(f.counts().writes,writes);a.equal((await item(f)).delivery.attemptId,pending.delivery.attemptId);
});
test('same durable pending receipt never bypasses current owner checks in actual worker',async()=>{
 const f=await failed({worker:true}),outbound=channel(f),body=request(await item(f)),writer=f.context.atomicWriteJson;
 f.context.atomicWriteJson=async(...args)=>{await writer(...args);throw Error('lost commit result');};await f.call(body);f.context.atomicWriteJson=writer;
 await f.api.update({op:'disable',id:f.connection.id});const again=await f.call(body);a.equal(again.result.body.alreadyRetried,true);await until(()=>!f.api.workerBusy());
 a.equal((await item(f)).delivery.status,'failed');a.equal((await item(f)).delivery.errorCode,'external_channel.control_revoked');a.equal(outbound.messages.length,0);a.equal(f.counts().runs,0);a.equal((await item(f)).replyHistory.length,1);
});
test('same durable pending receipt requires token and origin again before any resume wake',async()=>{
 for(const gate of ['token','origin']){const f=await failed(),body=request(await item(f));await f.call(body);const bytes=f.disk(),wakes=f.trace.wakes;f.auth[gate]=false;
 const result=await f.call(body);a.equal(result.result.status,403);a.equal(f.trace.wakes,wakes);a.equal(f.disk(),bytes);}
});
