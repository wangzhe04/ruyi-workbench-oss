# M5 manual reply retry API V2 — frozen for independent review

V1 remains blocked and unchanged:
C:/Users/87179/AppData/Local/Temp/ruyi-retry-api-candidate-20261026-04fb7e3c2e
V1 13w SHA 0e2f8c1b5f0d08a068b1ef25493b59a5ae66eb523cd4eeb8edc6d3b13a73d360.

The root reviewer found real liveness failure: a write can commit a retry pending record then report storage uncertainty; V1 emits zero wake, and the same explicit human request also emits zero wake forever. Production has startup/event/maintenance-resume wakeups, no independent periodic external worker wake.

V2 is precisely one V1-to-V2 span changing the retry handler's wake condition and its two comments:
- A successful core result may wake only if returned current delivery is pending and its attemptId equals this durable receipt's attemptId.
- This applies to new actions and an explicit same-request receipt replay. It creates no additional intent, history row, attempt or business execution.
- Sent/cancelled/unknown/sending/current failed/later attempt do not inherit an old receipt wake.
- Worker reads current state and rechecks owner, credentials, source and privacy through unchanged production code.
- Only the module-private core success result controls this condition; request JSON cannot manufacture it.

V2 13w SHA: 36dafa162e277baea75f82e7faf4d2d37ebb31ff022090000788cb68b993e3c6.
Core remains 026d912512f8d36cd10678d801075f386d0527ac4aeea0bbac561b24eb0ff79a.
01b remains 5a1f833241c348dc738aeaa7382f0d4496f33beb2083e0e9c28724d73d50356a.
api-spans.json still holds three 13w routing spans from core plus one exact auth table row. v1-to-v2-spans.json holds the single new span. Every source fully inverts to its fixed predecessor. reconstruct-api.cjs has reproduced the V2 outside checkout without loading any runtime.

Evidence:
- Original core 45/45 and original physical-capacity 1/1 run in this V2 package, all assertions unchanged.
- Real handler/worker VM 21/21 twice. This includes actual wake/drain/nextJob/13x code, with explicitly modeled official HTTPS and PrivacyGateway.
- Readiness-aware root counter: sent, wakes1, businessRuns0, MESSAGE1, history1, workerBusyfalse, same attempt.
- Twenty concurrent identical receipt resumes: one MESSAGE, one retry-history row, same attempt, zero business reruns.
- Old receipt against a later pending attempt never wakes; current owner revocation remains zero MESSAGE; token/origin revalidated for every explicit resume.
- Eight exact current negatives all exit1 with ERR_ASSERTION: V1 liveness; remove pending status; remove same-attempt check; remove token; remove origin; remove serialization; precommit wake; remove physical capacity.

Original failures are separate:
- root-counter-original.test.cjs and root-counter-original-red.log retain root's original V1 counter.
- root-counter-v2-exact.log retains V2 exact four-setImmediate counter failure: pending/wakes1/workerBusytrue. That checks before filesystem/worker settlement.
- New root liveness check keeps the same original business assertions and adds existing bounded until(!workerBusy) after those ticks. The same test immediately fails on V1 because it is idle and still pending; it passes V2 after actual worker settlement. Four event-loop turns are not a product latency contract.
- V1's three incorrect universal zero-wake assertions are preserved in api-v1-preserved.test.cjs. V2 changes only those wake expectations for current matching pending receipt; durable writes/identity/history/zero-business and all core assertions remain.
- An initial V2 preparation failed a CRLF-only text needle assertion before a candidate source was written. The untouched partial copied folder is retained as its original name without deletion; see report exact path. The final preparer matched the existing LF source, not a normalized/rebased source.

Scope remains backend-only preparation. No workspace edits, generated server, native/helper, socket/HTTP server, full suite, UI or real platform send occurred. This is not B1 completion. Root independent review, permanent fixtures/tests, generated inventories/runtime, isolated actual HTTP/e2e, stable UI request/receipt/history flow, retention, 429 and trustworthy unknown reconciliation plus real platform gates remain required.
