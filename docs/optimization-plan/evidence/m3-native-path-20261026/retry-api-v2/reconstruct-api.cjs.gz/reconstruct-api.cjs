'use strict';
// Source-only reconstruction. Never loads server, builds, starts a native process or runs tests.
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),a=require('node:assert/strict');
const repo=p.resolve(process.argv[2]||''),out=p.resolve(process.argv[3]||'');a.equal(process.argv.length,4);a.equal(fs.existsSync(out),false);
const key=x=>process.platform==='win32'?x.toLowerCase():x,actualOut=p.join(fs.realpathSync(p.dirname(out)),p.basename(out)),actualRepo=fs.realpathSync(repo);a.ok(key(actualOut)!==key(actualRepo)&&!key(actualOut).startsWith(key(actualRepo)+p.sep));
const hash=x=>c.createHash('sha256').update(x).digest('hex'),api=JSON.parse(fs.readFileSync(p.join(__dirname,'api-spans.json'))),draft=p.join(repo,'docs/optimization-plan/drafts/reply-retry-next-2026-10-26');
const identity=JSON.parse(fs.readFileSync(p.join(draft,'candidate-identity.json'))),coreSpans=JSON.parse(fs.readFileSync(p.join(draft,'spans.json'))).spans;
const baseline=fs.readFileSync(p.join(repo,identity.product.file),'utf8');a.equal(hash(baseline),identity.product.beforeSha256);
function apply(source,spans){for(const row of spans){a.equal(source.split(row.before).length,2);source=source.replace(row.before,row.after);}return source;}
function invert(source,spans){for(const row of spans.toReversed()){a.equal(source.split(row.after).length,2);source=source.replace(row.after,row.before);}return source;}
const core=apply(baseline,coreSpans);a.equal(hash(core),api.base);const candidate=apply(core,api.spans);a.equal(hash(candidate),api.candidate);a.equal(invert(invert(candidate,api.spans),coreSpans),baseline);
const authBase=fs.readFileSync(p.join(repo,'ruyi-workbench/app/src/01b-route-auth.js'),'utf8');a.equal(hash(authBase),api.auth.base);const auth=apply(authBase,[api.auth]);a.equal(hash(auth),api.auth.candidate);a.equal(invert(auth,[api.auth]),authBase);
fs.mkdirSync(out);for(const [name,value] of Object.entries({'13w-retry-baseline.js':baseline,'13w-core.js':core,'13w-external-bots.js':candidate,'01b-route-auth.js':auth}))fs.writeFileSync(p.join(out,name),value,{flag:'wx'});
console.log(JSON.stringify({sourcePreparedOnly:true,out,core:hash(core),candidate:hash(candidate),auth:hash(auth),inverseVerified:true}));
