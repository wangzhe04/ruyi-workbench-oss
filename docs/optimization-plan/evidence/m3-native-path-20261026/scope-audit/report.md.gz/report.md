# 3.1 剩余完整范围只读审计

基线 4b455b83e39c93ce2e739d5eeccc1af6dbf697a7；只读源码审计，未运行 native/build/test；不授予候选准入。

## 首三个关键缺口

1. M3 strict special-refusal metadata predicate remains red in latest §12.24; its fingerprint precondition means false is not proof of timestamps alone. Five support modules and live-to-private native increment remain unadmitted.
2. M3 production runtime configuration, recovery kernel, restart claim, upload ticket-to-file/hash, download, restored-root activation and subsequent boot routing are not closed.
3. M4 only dependency verification and bounded RGBA-to-PNG contract exist; trusted production owners and actual decode/OCR/barcode/derived-store/preview/outbound chain are absent.

## 可执行顺序

| 序号 | 里程碑 | 任务 | 依赖 | 出门条件 |
|---|---|---|---|---|
| 01 | M3 | Diagnose and close strict special-refusal actual gate | 无 | All seven original roles, no partial pass relabeling; explicit final helper exit/close evidence or uncertainty retention. |
| 02 | M3 | Admit complete support/native candidate and long-path fix | 01 | Final exact source/runtime identity; actual Windows 250/259/260/261/270 path matrix and original strict predicates. Historical private success is not admission. |
| 03 | M3 | Finish nonempty special portable restore | 02 | Ordinary special refusal is only negative coverage; actual nonempty restore and native metadata/history/bytes proof required. |
| 04 | M3 | Implement owned startup recovery kernel and cross-crash claim | 02 | Fault at each prepared/candidate/key-ready/published/complete boundary, kill/restart/space/lock/tamper/duplicate-instance and uncertainty; one authority and source retained. |
| 05 | M3 | Compose cold production runtime | 03,04 | Actual production process and Desktop window takeover; worker readiness must derive from complete capabilities and owners. |
| 06 | M3 | Bind upload tickets and complete backup download | 04,05 | Wrong ticket/hash/changed file/oversize/late/cancel/unknown do not execute transition or overwrite; real HTTP/UI upload/download journey. |
| 07 | M3 | Activate new restore root and persist subsequent boot selection | 04,05,06 | Continuous cold restarts and CLI one-shot entry select same active root; no old-root writers/private data bypass; key loss restore remains viable. |
| 08 | M3 | Complete full storage/index/user journeys and performance | 03,07 | Real production UI and 3.0.1 upgrade, interruption/restart, true cross-account/machine recovery, index delete/edit/rollback/permission/rebuild; cold/hot p50/p95/memory/disk and 10/100/1000-session matrix versus frozen baseline. |
| 09 | M4 | Freeze dependency/processor/license/runtime capabilities | 无 | Full and Slim capabilities accurately differ; no replacement downloads/cloud fallback; manifest verification alone insufficient. |
| 10 | M4 | Ship protected image production chain | 08,09 | Actual receiver sees zero original bytes, exact preview/derived hash; source/policy/scope/revoke/cancel/timeout/low confidence/unknown preserve typed failure and never fallback. Real local process lifecycle. |
| 11 | M4 | Ship protected PDF/Office derived chain | 09,10 | Malicious zip relationships/external links, embedded content, hidden text, render/font failure, corruption/limits and metadata; actual received bytes and derived provenance. |
| 12 | M4 | Ship protected video frames/text chain | 09,10 | Short sensitive frames/subtitles/metadata/cancel/timeout; all delivered frames/text protected, unsampled footage explicitly outside conclusion. |
| 13 | M5 | Finish B1 manual reply retry and physical retention | 08 | Payload3 cancellation matrix plus payload4 migration/capacity/crash/unknown/sent/cancelled/429 refusal; old-reader rejection and no automatic resends or business replay. |
| 14 | M5 | Implement B2 progress/query and C remote decisions | 13 | Replay/swap person/group/expiry/concurrency/restart/changed policy refused; group-safe disclosure and real-send status separate from business status. QQ optional SDK thin bridge separately provenance/acceptance/reconnect reviewed. |
| 15 | M5 | Deliver existing-thread sequential relay | 08 | Actual existing A/B journey, repeated click/restart/late results/source edit/permission/scope changes/busy/pending/failure/stop; unknown reconcile same identity, no business replay. |
| 16 | M5 | Deliver editable scheduled Playbook templates | 08 | Pause/resume/cancel/edit/missed/sleep/DST/timezone/restart unknown; old pending retains old snapshot or explicit retirement, no duplicate execution or expanded permission. |
| 17 | M5/M6 | Complete authorized real platform validation | 14 | Needs explicit actual-send authorization and external account resources; keep missing evidence unresolved while internal work continues. No synthetic HTTPS pass substituted. |
| 18 | M6 | Freeze final candidate, version/docs/packages, run final acceptance | 08,10,11,12,13,14,15,16,17 | Windows Node24 full unit/static/default E2E, real model/platform, bilingual/themes/keyboard/narrow UI; same final package bytes new install/3.0.1 upgrade/interruption/key recovery/disable/backup/rollback with preupgrade backup. No auto publication; any later byte change rebuild and affected actual-package revalidation. |

细项、生产入口、固定输入摘要及边界见 report.json。M2/P0不重开；通用HTTP裁撤、严格CLI和ASR暂缓保留用户决定。
