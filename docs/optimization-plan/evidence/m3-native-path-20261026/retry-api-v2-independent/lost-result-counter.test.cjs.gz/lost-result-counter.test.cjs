'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),p=require('node:path'),vm=require('node:vm'),c=require('node:crypto'),{EventEmitter}=require('node:events');
const repo='C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss',root=__dirname,source=fs.readFileSync(process.env.RETRY_API_SOURCE||p.join(root,'13w-external-bots.js'),'utf8');
const {fixture,plain,until}=require(repo+'/dev-harness/lib/external-bots-inbox-fixture'),{functionBlock,constBlock}=require(repo+'/dev-harness/lib/source-slice');
const target='/api/external-bots/deliveries/retry',request=(x,id='retry_request_00000001')=>({id:x.id,expectedAttemptId:x.delivery.attemptId,retryRequestId:id});
function make({worker=false,...options}={}) {
 const f=fixture({source,...options});f.trace={wakes:0,acks:0,bodyReads:0};f.auth={token:true,origin:true};
 Object.assign(f.context,{tokenOk:()=>f.auth.token,originOk:()=>f.auth.origin,json:(body,status=200)=>({body,status}),apiFailure:(code,params,message,status)=>({body:{ok:false,error:code},status}),send:(res,result)=>{f.trace.acks++;res.result=plain(result);res.writableEnded=true;}});
 vm.runInContext('api.http=handleExternalBotApiRoutes;api.workerBusy=()=>externalBotWorkerBusy;api.workerAgain=()=>externalBotWorkerAgain;api.workerStopped=value=>{externalBotWorkerStopped=value;};api.retry=body=>runKeyedChain(externalBotChains,"state",()=>externalBotRetryReply(body,EXTERNAL_BOT_LOCAL_REPLY_RETRY));',f.context);
 f.context.onWake=()=>{f.trace.wakes++;};
 vm.runInContext('const originalWake=externalBotWakeWorker;externalBotWakeWorker=()=>{onWake();return originalWake();};',f.context);
 f.api.workerStopped(!worker);
 f.call=(body,options={})=>{
  const req=new EventEmitter(),res=new EventEmitter();req.url=options.url||target;req.method=options.method||'POST';req.complete=true;req.headers=options.headers||{};
  req.pause=()=>{};req.destroy=()=>{req.destroyed=true;};res.destroyed=options.lost===true;res.writableEnded=false;res.setHeader=()=>{};
  const promise=f.api.http(req,res,options.pathname||new URL(req.url,'http://localhost').pathname);
  queueMicrotask(()=>{if(req.listenerCount('data')){f.trace.bodyReads++;req.emit('data',options.raw||Buffer.from(JSON.stringify(body)));req.emit('end');}});
  return promise.then(handled=>({handled,result:res.result,res}));
 };return f;
}
async function failed(options={},errorCode='external_delivery.predispatch'){
 const f=make(options);await f.api.update({op:'upsert',connection:{...f.connection,mode:'control',ownerSenderId:'user_a',ownerConversationId:'room_a',ownerConversationType:'group'},controlConfirmed:true});
 await f.api.accept(f.message());await f.api.finish(await f.api.next(),{ok:true,say:'EXACT BUSINESS REPLY MUST NOT RERUN',turnSeq:1});
 await f.api.finish(await f.api.next(),{status:'failed',errorCode});return f;
}
async function item(f){return(await f.api.read()).items[0];}
function channel(f){
 const messages=[],requests=[];
 f.context.require=name=>{a.equal(name,'node:https');return{request(options,cb){const req=new EventEmitter();req.destroy=()=>{};req.end=bytes=>{requests.push(options.path);if(!options.path.includes('getAppAccessToken'))messages.push(Buffer.from(bytes));queueMicrotask(()=>{const res=new EventEmitter();res.statusCode=200;res.headers={};res.destroy=()=>{};cb(res);res.emit('data',Buffer.from(JSON.stringify(options.path.includes('getAppAccessToken')?{access_token:'FAKE'}:{id:'official_reply'})));res.emit('end');});};return req;}};};
 f.context.PrivacyGateway={withPolicy:(_scope,work)=>work(),disclosurePolicyGuard:()=>()=>{},prepareDisclosure:async()=>({receipt:{}}),refreshDisclosure:async()=> 'PROTECTED_REPLY',assertDisclosure(){}};
 vm.runInContext(fs.readFileSync(p.join(repo,'ruyi-workbench/app/src/13x-external-channel-delivery.js'),'utf8'),f.context);return{messages,requests};
}
test('exact route is token only; old auth rows and full core invert byte exactly',()=>{
 const auth=fs.readFileSync(p.join(root,'01b-route-auth.js'),'utf8'),context=vm.createContext({});vm.runInContext(auth+';globalThis.rows=ROUTE_AUTH;',context);const rows=plain(context.rows);
 a.deepEqual(rows.filter(x=>x.p===target),[{m:'POST',p:target,auth:'token'}]);const spans=JSON.parse(fs.readFileSync(p.join(root,'api-spans.json')));let inverse=source;
 for(const row of spans.spans.toReversed()){a.equal(inverse.split(row.after).length,2);inverse=inverse.replace(row.after,row.before);}a.equal(inverse,fs.readFileSync(p.join(root,'13w-core.js'),'utf8'));
 a.equal(auth.replace(spans.auth.after,spans.auth.before),fs.readFileSync(p.join(repo,'ruyi-workbench/app/src/01b-route-auth.js'),'utf8'));
 for(const name of ['externalBotRetryReply','externalBotCancellationWindow','externalBotCancelDelivery','externalBotNextJob','externalBotFinishJob','externalBotPrepareReply','externalBotRecover','externalBotDrain','externalBotWakeWorker'])a.equal(functionBlock(source,name),functionBlock(inverse,name));
 a.equal(constBlock(source,'externalBotStore'),constBlock(inverse,'externalBotStore'));
});
test('token and origin gates refuse before reading request body or touching ledger',async()=>{
 for(const gate of ['token','origin']){const f=await failed(),body=request(await item(f)),bytes=f.disk(),writes=f.counts().writes;f.auth[gate]=false;const r=await f.call(body);
 a.equal(r.result.status,403);a.equal(r.result.body.error,'auth.'+(gate==='token'?'token_invalid':'origin_rejected'));a.equal(f.disk(),bytes);a.equal(f.counts().writes,writes);a.equal(f.trace.bodyReads,0);a.equal(f.trace.wakes,0);}
});
test('exact path and POST only; query refuses before body, no similar prefix accepted',async()=>{
 const f=await failed(),body=request(await item(f)),bytes=f.disk();
 a.equal((await f.call(body,{url:target+'/extra'})).handled,false);
 for(const method of ['GET','PUT','DELETE'])a.equal((await f.call(body,{method})).result.status,405);
 a.equal((await f.call(body,{url:target+'?x=1'})).result.body.error,'external_channel.request_invalid');a.equal(f.disk(),bytes);a.equal(f.trace.wakes,0);a.equal(f.trace.bodyReads,0);
});
test('strict JSON UTF8/body bound and exact three fields cannot mint authority or change payload',async()=>{
 const f=await failed(),body=request(await item(f)),bytes=f.disk();
 for(const raw of [Buffer.from('[]'),Buffer.from('{'),Buffer.from([0xc0,0xaf])])a.equal((await f.call(body,{raw})).result.body.error,'external_channel.body_invalid');
 for(const patch of [{authority:true},{localAuthorized:true},{attemptId:'injected'},{retryRequestId:'short'},{expectedAttemptId:''}])a.equal((await f.call({...body,...patch})).result.body.error,'external_channel.request_invalid');
 a.equal((await f.call(body,{headers:{'content-length':'65537'}})).result.status,413);a.equal(f.disk(),bytes);a.equal(f.trace.wakes,0);
});
test('new HTTP action commits same pending attempt and history then wakes original worker once',async()=>{
 const f=await failed(),old=plain(await item(f)),writes=f.counts().writes,r=await f.call(request(old)),state=await f.api.read();
 a.equal(r.handled,true,'exact local retry route must be handled');a.equal(r.result.status,200);a.equal(r.result.body.alreadyRetried,false);a.equal(state.schema,4);a.equal(state.items[0].delivery.status,'pending');a.equal(state.items[0].replyHistory.length,1);
 a.deepEqual(plain(state.items[0].replyHistory[0].attempt),old.delivery);a.deepEqual(plain(state.items[0].execution),old.execution);a.equal(f.counts().writes,writes+1);a.equal(f.trace.wakes,1);a.equal(f.counts().runs,0);a.equal(f.counts().sends,0);
});
test('pending durability blocks ACK and wake; write failure produces neither',async()=>{
 const f=await failed(),body=request(await item(f)),bytes=f.disk(),writes=f.counts().writes;let release,settled=false;f.gate(new Promise(r=>release=r));
 const pending=f.call(body).then(r=>{settled=true;return r;});await until(()=>f.counts().writes===writes+1);a.equal(settled,false);a.equal(f.trace.wakes,0);a.equal(f.trace.acks,0);a.equal(f.disk(),bytes);release();await pending;a.equal(f.trace.wakes,1);
 const g=await failed(),before=g.disk();g.fail(true);const r=await g.call(request(await item(g)));a.equal(r.result.body.error,'external_channel.storage_unavailable');a.equal(g.trace.wakes,0);a.equal(g.disk(),before);
});
test('lost ACK after durable commit still wakes once; stable retryRequestId reconciles without write or wake',async()=>{
 const f=await failed(),body=request(await item(f)),first=await f.call(body,{lost:true});a.equal(first.result,undefined);a.equal(f.trace.wakes,1);
 const bytes=f.disk(),writes=f.counts().writes,second=await f.call(body);a.equal(second.result.body.alreadyRetried,true);a.equal(second.result.body.receipt.previousAttemptId,body.expectedAttemptId);a.equal(f.disk(),bytes);a.equal(f.counts().writes,writes);a.equal(f.trace.wakes,1);
});
test('commit succeeded but writer reports lost result: no wake/ACK, same identity reads durable history only',async()=>{
 const f=await failed(),body=request(await item(f)),writer=f.context.atomicWriteJson;f.context.atomicWriteJson=async(...args)=>{await writer(...args);throw Error('synthetic lost commit result');};
 const first=await f.call(body);a.equal(first.result.body.error,'external_channel.storage_unavailable');a.equal(f.trace.wakes,0);f.context.atomicWriteJson=writer;
 const bytes=f.disk(),writes=f.counts().writes,second=await f.call(body);a.equal(second.result.body.alreadyRetried,true);a.equal(f.disk(),bytes);a.equal(f.counts().writes,writes);a.equal(f.trace.wakes,0);
});
test('historical same request after sent cancelled unknown or later attempt returns exact original receipt without wake',async()=>{
 for(const status of ['sent','cancelled','unknown','later']){const f=await failed(),body=request(await item(f)),first=(await f.call(body)).result.body;
 if(status==='cancelled'){const cur=await item(f);await f.api.cancel({id:cur.id,attemptId:cur.delivery.attemptId});}
 else {await f.api.finish(await f.api.next(),status==='sent'?{status:'sent',messageId:'official_reply'}:status==='unknown'?{status:'unknown',errorCode:'external_channel.delivery_unknown'}:{status:'failed',errorCode:'external_delivery.token_network'});if(status==='later')await f.call(request(await item(f),'retry_request_00000002'));}
 const bytes=f.disk(),writes=f.counts().writes,wakes=f.trace.wakes,again=(await f.call(body)).result.body;
 a.equal(again.alreadyRetried,true);a.deepEqual(again.receipt,first.receipt);a.equal(f.disk(),bytes);a.equal(f.counts().writes,writes);a.equal(f.trace.wakes,wakes);a.equal(f.counts().runs,0);}
});
test('unsafe unknown sent cancelled pending sending and non-whitelisted failed provenance refuse with zero wake',async()=>{
 for(const status of ['unknown','sent','cancelled','pending','sending','429']){const f=await failed({},status==='429'?'external_delivery.rate_limited':'external_delivery.predispatch');
 if(status!=='429'){const state=plain(await f.api.read());state.items[0].delivery.status=status;state.items[0].delivery.messageId=status==='sent'?'message':'';if(status==='cancelled'){state.schema=3;for(const row of state.items)row.archivedAt='';state.items[0].delivery.cancelledAt=new Date().toISOString();state.items[0].delivery.errorCode='external_channel.delivery_cancelled';}await f.api.write(state);}
 const bytes=f.disk(),r=await f.call(request(await item(f)));a.equal(r.result.body.error,'external_channel.delivery_cannot_retry');a.equal(f.disk(),bytes);a.equal(f.trace.wakes,0);a.equal(f.counts().runs,0);}
});
test('concurrent same request serializes durable commit before second ACK and wakes exactly once',async()=>{
 const f=await failed(),body=request(await item(f)),writes=f.counts().writes,[one,two]=await Promise.all([f.call(body),f.call(body)]);
 a.equal(one.result.body.alreadyRetried,false);a.equal(two.result.body.alreadyRetried,true);a.deepEqual(one.result.body.receipt,two.result.body.receipt);a.equal(f.counts().writes,writes+1);a.equal(f.trace.wakes,1);
});
test('different request IDs race for predecessor; one succeeds and old-attempt replay conflicts',async()=>{
 const f=await failed(),body=request(await item(f)),outcomes=await Promise.all([f.call(body),f.call({...body,retryRequestId:'retry_request_00000002'})]);a.equal(outcomes[0].result.status,200);a.equal(outcomes[1].result.body.error,'external_channel.delivery_changed');a.equal(f.trace.wakes,1);a.equal((await item(f)).replyHistory.length,1);
});
test('cancel/retry both orderings use shared state chain; old cancellation cannot cancel successor',async()=>{
 for(const cancelFirst of [true,false]){const f=await failed(),old=await item(f),retry=()=>f.call(request(old)),cancel=()=>f.call({id:old.id,attemptId:old.delivery.attemptId},{url:'/api/external-bots/deliveries/cancel'}),results=await Promise.all(cancelFirst?[cancel(),retry()]:[retry(),cancel()]);
 a.equal(results[cancelFirst?1:0].result.status,200);a.equal(results[cancelFirst?0:1].result.body.error,cancelFirst?'external_channel.delivery_cannot_cancel':'external_channel.delivery_changed');a.equal((await item(f)).delivery.status,'pending');a.equal(f.trace.wakes,1);}
});
test('accurate successor cancellation retains payload4 history and later old retry cannot resurrect it',async()=>{
 const f=await failed(),body=request(await item(f)),first=(await f.call(body)).result.body,current=await item(f);
 const cancel=await f.call({id:current.id,attemptId:current.delivery.attemptId},{url:'/api/external-bots/deliveries/cancel'});a.equal(cancel.result.status,200);a.equal((await f.api.read()).schema,4);
 const bytes=f.disk(),again=(await f.call(body)).result.body;a.deepEqual(again.receipt,first.receipt);a.equal(again.item.delivery.status,'cancelled');a.equal(f.disk(),bytes);a.equal(f.trace.wakes,1);
});
test('actual wake/drain/next/13x message path sends only original reply, never original completed business again',async()=>{
 const f=await failed({worker:true}),old=plain(await item(f)),channelResult=channel(f),body=request(old),res=await f.call(body);
 a.equal(res.result.body.alreadyRetried,false);await until(()=>!f.api.workerBusy());a.equal((await item(f)).delivery.status,'sent');a.equal(f.counts().runs,0);a.equal(channelResult.requests.length,2);a.equal(channelResult.messages.length,1);a.match(channelResult.messages[0].toString(),/PROTECTED_REPLY/);a.doesNotMatch(channelResult.messages[0].toString(),/EXACT BUSINESS REPLY/);
 const again=await f.call(body);a.equal(again.result.body.alreadyRetried,true);await f.api.drain();a.equal(f.trace.wakes,1);a.equal(channelResult.messages.length,1);a.equal(f.counts().runs,0);a.deepEqual(plain((await item(f)).execution),old.execution);
});
test('real original 40MiB pretty capacity refuses route before durable write or wake in both Store modes',async()=>{
 for(const enabled of [false,true]){const f=await failed({enabled}),state=plain(await f.api.read()),seed=state.items[0],count=40;
 state.items=Array.from({length:count},(_,n)=>{const row=plain(seed);row.id='physical_item_'+n;row.messageId='physical_message_'+n;row.eventId='physical_event_'+n;row.sourceKey=JSON.stringify([row.connectionId,row.tenantId,row.conversationId,row.messageId]);row.execution.replyText='X'.repeat(1024*1024);return row;});
 const targetBytes=f.api.limits.stateBytes-1,size=Buffer.byteLength(JSON.stringify(state,null,2));a.ok(size>targetBytes);state.items.at(-1).execution.replyText=state.items.at(-1).execution.replyText.slice(0,-(size-targetBytes));a.equal(Buffer.byteLength(JSON.stringify(state,null,2)),targetBytes);a.equal(f.api.valid(state),true);await f.api.write(state);
 const body=request((await f.api.read()).items[0]),bytes=f.disk(),writes=f.counts().writes,r=await f.call(body);a.equal(r.result.body.error,'external_channel.inbox_full');a.equal(f.trace.wakes,0);a.equal(f.disk(),bytes);a.equal(f.counts().writes,writes);await f.api.read();}
});

test('root retained durable retry should resume after lost writer result on same human request',async()=>{
 const f=await failed({worker:true}),outbound=channel(f),body=request(await item(f)),writer=f.context.atomicWriteJson;
 f.context.atomicWriteJson=async(...args)=>{await writer(...args);throw Error('synthetic lost commit result');};
 const first=await f.call(body);a.equal(first.result.body.error,'external_channel.storage_unavailable');
 f.context.atomicWriteJson=writer;const again=await f.call(body);a.equal(again.result.body.alreadyRetried,true);
 for(let tick=0;tick<4;tick++)await new Promise(setImmediate);
 const current=await item(f);console.log(JSON.stringify({counter:'root-lost-commit-result-human-reconcile',status:current.delivery.status,wakes:f.trace.wakes,businessRuns:f.counts().runs,messageRequests:outbound.messages.length,history:current.replyHistory.length,workerBusy:f.api.workerBusy()}));
 a.equal(current.delivery.status,'sent','same explicit human request must resume its one durable pending reply');a.equal(outbound.messages.length,1);a.equal(f.counts().runs,0);
});