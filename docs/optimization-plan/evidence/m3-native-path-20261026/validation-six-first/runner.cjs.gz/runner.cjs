'use strict';
const fs=require('node:fs'),p=require('node:path'),os=require('node:os'),cp=require('node:child_process');
const repo='C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss';
const {releaseEnvironment}=require(p.join(repo,'dev-harness/lib/release-checks')),{killOwnTree}=require(p.join(repo,'dev-harness/lib/kill-own-tree'));
const root=fs.mkdtempSync(p.join(os.tmpdir(),'ruyi-native-path-validation-')),env=releaseEnvironment(p.join(root,'home'),p.join(root,'data')); const results=[];
fs.writeFileSync(p.join(__dirname,'native-path-validation-root.txt'),root);console.log(root);
async function run(name,args,budgetMs){const log=p.join(root,name+'.log'),fd=fs.openSync(log,'w'),started=Date.now();const child=cp.spawn(process.execPath,args,{cwd:repo,env,windowsHide:true,stdio:['ignore',fd,fd]});let timer,timeout=false,cleanup;
const result=await new Promise(resolve=>{child.once('error',error=>resolve({errorCode:error.code||null}));child.once('close',(code,signal)=>resolve({code,signal}));timer=setTimeout(()=>{timeout=true;try{cleanup=killOwnTree(child);}catch(error){cleanup={errorCode:error.code||null};}},budgetMs);});clearTimeout(timer);fs.closeSync(fd);
const record={name,args,budgetMs,elapsedMs:Date.now()-started,pid:child.pid,timeout,cleanup:cleanup||null,...result,log};results.push(record);fs.writeFileSync(p.join(root,'results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(record));return !timeout&&result.code===0;}
(async()=>{for(const [name,args,budget] of [['syntax',['dev-harness/syntax-gate.js'],240000],['build-check',['ruyi-workbench/app/build.js','--check'],120000],['fast',['dev-harness/run-all.js','--fast','--parallel','2'],1200000],...['migration-skill-backup-representation','migration-records-work-data','work-data-full-snapshot','work-data-cold-operations'].map(n=>[n,['dev-harness/'+n+'.e2e.js'],240000])])if(!await run(name,args,budget))return process.exitCode=1;})();
