# M5 reply retry UI + read hint candidate

Files are in files/. This is source preparation and pure DOM/VM validation, not browser, HTTP, native, package or B1 acceptance.

Requires the already reviewed backend V2 (36dafa16) plus the portable-test draft (identity88c14ed4) as explicit predecessor layers. Ten candidate files are listed in products.json. Nine existing/upstream files inverse exactly through spans.json; the only new production module is external-bot-retry-state.js.

UI behavior:
- A module-owned, bounded Map retains the original {id,expectedAttemptId,retryRequestId} across panel and DOM recreation. It does not put data in browser storage.
- During physical POST, the same request cannot run again. The existing archivePending physical owner and writeOwner/generation/deliverySeq guards remain the mutation fence; old completions cannot unlock a newer write or restore focus to a different control.
- Network/storage errors and malformed ACKs keep an uncertain original request. A fresh manual read enables “Check and continue this reply request”; its POST reuses the exact original ID. There is no automatic retry POST.
- Explicit typed rejection from the reviewed backend's precommit branches marks that request rejected. After a fresh authoritative read, a new user action can create a fresh ID. It does not falsely trap delivery_changed forever as an unknown commit.
- After whole-page reload, a current pending delivery whose latest valid replyHistory points to its exact attempt reconstructs the old request ID/previous attempt. It shows an explicit manual check/resume action without creating a new ID or automatically posting.
- Unknown sends and429 have no new retry action. A local uncertain request may still reconcile its own historical receipt; this cannot force an unknown send and is not full platform unknown reconciliation.
- Every history field is rendered with textContent through the existing el helper; no HTML interpolation. Native buttons retain keyboard behavior; focus is restored only when the original owner still owns it.
- Persistent Chinese/English copy explains original-reply-only, no business rerun, retained previous attempts, and whole-ledger payload4 compatibility after the first saved retry.

Backend read hint:
13w0f20414a8cf9af554b5bab9ba9c54f9b5e2dc4c3445f4e874fd97bfce77d1b09 has exactly three spans from V2: add retryAvailable projection; extract the original synchronous retry window; call that same window from core. The eight failure codes remain in the original single backend table.
The hint is not permission. The actual async owner/connection/credential check and original private-authority/state-chain/durability paths remain unchanged. Matrix comparison checks all5280 combinations of the former synchronous predicate.
Storage remains payload4. “v5” is only a historical-source fixture label: it strips these hint spans to exact V2 before the unchanged v4 API/core inverse to c82, then exact v2/v1 sources. Earlier SHA values are not rebased. The upstream API21 test's static identity comparison de-scopes only these explicit hint spans; all behavior assertions remain unchanged.

Evidence:
- Original40 UI pure tests are retained; nine new cases give49/49.
- Four actual-source/state tests pass, including5280 predicate combinations, async-owner byte identity, exact V2 inverse, v5/V2/c82/v2/v1 reconstruction and raw non-string rejection.
- Final same-byte combined pure run53/53, no skip.
- Four current removed guards each exit1 with ERR_ASSERTION: panel-local Map, new ID on uncertain replay, no reload recovery, late completion unconditional unlock.
- First UI preparation run48 tests had45 pass/3 ENOENT due old locale test read paths in TEMP. ui-first.log and ui-first.test.cjs preserve it. Only test locale read locations were adapted; product bytes did not change for those failures.
- The original external-bots.browser.e2e.js is untouched. Its prior233 assertions were not run or relabeled as new browser evidence.

Initial retry-function.txt is a preparation fragment retained for provenance; only products.json plus files/ are final source products.

Independent root review must cover the Map lifetime/reload path, new read-hint source and exact inverse, fixed backend error classification, immutable request/receipt checks, DOM late reads and write ownership. Then stage exact predecessor layers and candidates in an isolated tree, build/generate inventories and run current backend/core/API, actual HTTP and original233+new browser journeys serially. Register the new public JS in overlay/public asset packaging where required. This source batch does not complete unknown reconciliation,429 policy, retention/reclamation, real platform testing, B1 or3.1.
