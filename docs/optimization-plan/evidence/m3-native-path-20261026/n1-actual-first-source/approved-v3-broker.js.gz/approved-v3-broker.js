const MIGRATION_CAPSULE_ARCHIVE_LIMIT = 160 * 1024 * 1024;
function migrationCapsuleFail(reason, uncertain = false) {
  const code = 'work_data_backup.' + reason;
  throw Object.assign(new Error(code), { code, apiCode: code, statusCode: 503,
    ...(uncertain ? { operationMayHaveExecuted: true, resultUnavailable: true, retry: false } : {}) });
}
async function migrationCapsuleBroker() {
  const failure = (suffix, cause, uncertain = false) => {
    const code = 'work_data_backup.' + suffix;
    return Object.assign(new Error(code), { code, apiCode: code, statusCode: 503,
      ...(cause ? { cause } : {}), ...(uncertain ? { helperMayStillRun: true, operationMayHaveExecuted: true, retry: false } : {}) });
  };
  if (migrationCapsuleBroker.helperMayStillRun === true) throw failure('native_helper_uncertain', null, true);
  if (process.platform !== 'win32') migrationCapsuleFail('platform_unsupported');
  const bootstrap = "$ErrorActionPreference='Stop'; $ruyiSkillCapsuleSource=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($env:RUYI_SKILL_CAPSULE_SOURCE)); [Environment]::SetEnvironmentVariable('RUYI_SKILL_CAPSULE_SOURCE',$null,[EnvironmentVariableTarget]::Process); try { Add-Type -ReferencedAssemblies System.Web.Extensions -TypeDefinition $ruyiSkillCapsuleSource } finally { $ruyiSkillCapsuleSource=$null }; [RuyiSkillCapsule]::Run()";
  let child;
  try {
    child = require('node:child_process').spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(bootstrap, 'utf16le').toString('base64')], {
      env: { ...process.env, RUYI_SKILL_CAPSULE_SOURCE: Buffer.from(MIGRATION_SKILL_CAPSULE_NATIVE, 'utf8').toString('base64') },
      windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'],
    });
  } catch (cause) { throw failure('native_unavailable', cause); } // no issued child
  const timers = require('node:timers');
  const decoder = new (require('node:string_decoder').StringDecoder)('utf8');
  let pending = null, closing = false, stopping = false, settled = false, spawned = false;
  let output = [], outputBytes = 0, firstError = null, settleTimer = null, closePromise = null, resolveClosed;
  const closed = new Promise(resolve => { resolveClosed = resolve; });
  const finish = error => {
    if (settled) return;
    settled = true; timers.clearTimeout(settleTimer); output = []; outputBytes = 0;
    if (pending) {
      const entry = pending; pending = null; timers.clearTimeout(entry.timer);
      entry.reject(error || failure('native_exit'));
    }
    resolveClosed(error);
  };
  const kill = () => { try { child.kill(); } catch (cause) { firstError ||= failure('native_unavailable', cause); } };
  const boundClose = () => {
    if (settled || settleTimer !== null) return;
    settleTimer = timers.setTimeout(() => {
      if (settled) return;
      migrationCapsuleBroker.helperMayStillRun = true; // permanent, even after late close
      firstError ||= failure('native_close_timeout'); kill();
      finish(failure('native_helper_uncertain', firstError, true));
    }, 2000);
  };
  const stop = (suffix, cause) => {
    if (settled || stopping) return;
    stopping = true; firstError ||= failure(suffix, cause);
    if (pending) timers.clearTimeout(pending.timer);
    output = []; outputBytes = 0; boundClose(); kill();
  };
  child.on('spawn', () => { spawned = true; });
  child.on('error', cause => {
    // Node's spawn-failure event can prove no helper was issued. Runtime/kill
    // errors on a PID, and ambiguous error objects, still require actual close.
    let absent = false;
    try { absent = !spawned && child.pid == null && typeof cause?.syscall === 'string' && cause.syscall.startsWith('spawn '); } catch { /* unknown is not absent */ }
    if (absent) { firstError ||= failure('native_unavailable', cause); finish(firstError); }
    else stop('native_unavailable', cause);
  });
  child.on('exit', code => {
    // Exit does not close inherited pipes. It can prohibit another command but
    // cannot discharge the lease or settle pending command failures.
    if (settled) return;
    if (!closing || code !== 0 || pending) firstError ||= failure('native_exit');
    closing = true; boundClose();
  });
  child.on('close', code => {
    if (settled) return;
    if (code !== 0 || pending) firstError ||= failure('native_exit');
    finish(firstError);
  });
  try {
    child.stdout.on('data', chunk => {
      if (settled || stopping) return;
      const parts = decoder.write(chunk).split('\n');
      for (let index = 0; index < parts.length; index++) {
        output.push(parts[index]); outputBytes += Buffer.byteLength(parts[index]);
        if (outputBytes > MIGRATION_CAPSULE_ARCHIVE_LIMIT) { stop('native_limit'); return; }
        if (index === parts.length - 1) break;
        const line = output.join(''); output = []; outputBytes = 0;
        if (!pending) continue;
        let response;
        try { response = JSON.parse(line); } catch { stop('native_unavailable'); return; }
        const entry = pending; pending = null; timers.clearTimeout(entry.timer);
        if (response?.ok === true) entry.resolve(response.value);
        else {
          const suffix = /^[a-z0-9_]+$/.test(response?.code || '') ? response.code : 'native_unavailable';
          const error = failure(suffix); firstError ||= error; entry.reject(error);
        }
      }
    });
    child.stdout.on('error', cause => stop('native_pipe', cause));
    child.stdin.on?.('error', cause => stop('native_pipe', cause));
    child.stderr.on?.('error', cause => stop('native_pipe', cause));
    child.stderr.resume(); // never capture/log compiler or payload stderr
  } catch (cause) { stop('native_pipe', cause); }
  const command = args => new Promise((resolve, reject) => {
    if (pending || closing || stopping || settled || migrationCapsuleBroker.helperMayStillRun === true) {
      reject(migrationCapsuleBroker.helperMayStillRun === true ? failure('native_helper_uncertain', firstError, true) : failure('native_exit')); return;
    }
    const timer = timers.setTimeout(() => stop('native_timeout'), 120000);
    pending = { resolve, reject, timer };
    try {
      child.stdin.write(JSON.stringify(args) + '\n', cause => { if (cause) stop('native_pipe', cause); });
    } catch (cause) { stop('native_pipe', cause); }
  });
  const close = () => {
    if (closePromise) return closePromise;
    closePromise = closed.then(error => { if (error) throw error; });
    if (!settled) {
      closing = true; boundClose();
      try { child.stdin.end(); } catch (cause) { stop('native_pipe', cause); }
    }
    return closePromise;
  };
  return Object.freeze({ command, close });
}
({broker:migrationCapsuleBroker,helperMayStillRun:()=>migrationCapsuleBroker.helperMayStillRun===true});
