'use strict';
const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process'), crypto = require('node:crypto'), os = require('node:os');
const root = path.resolve(__dirname, '../..');
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const python = 'E:/Claude/ruyi-workbench-oss/mcp/ai-computer-control/build_offline/python_embed/python.exe';
const browser = 'E:/Claude/ruyi-workbench-oss/mcp/ai-computer-control/build_offline/playwright_browsers/chromium-1234/chrome-win64/chrome.exe';
const files = [python, browser, 'dev-harness/lib/browser-fixture.js', 'dev-harness/live-full-text.browser.e2e.js', 'ruyi-workbench/app/server.js', 'ruyi-workbench/app/src/manifest.json', 'dev-harness/run-all.js', 'docs/architecture/route-inventory.json', 'docs/architecture/route-inventory.md',
  'dev-harness/budget-guard.e2e.js', 'dev-harness/live-full-text.e2e.js', 'dev-harness/steward-relay-channels.e2e.js',
  'dev-harness/lib/work-data-production-upload-core.js', 'dev-harness/work-data-production-maintenance.e2e.js',
  'dev-harness/work-data-production-restore.e2e.js', 'dev-harness/unit/work-data-maintenance-snapshot-diagnostics.test.js',
  'dev-harness/unit/session-execution-write-owner.test.js'];
const snapshot = () => Object.fromEntries(files.map(file => [file, hash(path.isAbsolute(file) ? file : path.join(root, file))]));
const priorLogs = Object.fromEntries(['last-unit-run.log', 'last-run.log'].map(name => {
  const file = path.join(root, 'dev-harness', name);
  return [name, fs.existsSync(file) ? { hash: hash(file), mtimeMs: fs.statSync(file).mtimeMs } : null];
}));
const receipt = { command: [process.execPath, 'dev-harness/run-all.js', '--fast', '--parallel', '4'], cwd: root,
  node: process.version, start: new Date().toISOString(), controllerSha256: hash(__filename), inputsBefore: snapshot(),
  exit: null, close: null, stdoutEOF: false, stderrEOF: false };
const out = fs.createWriteStream(path.join(__dirname, 'stdout.log'), { flags: 'wx' });
const err = fs.createWriteStream(path.join(__dirname, 'stderr.log'), { flags: 'wx' });
const finished = stream => new Promise((resolve, reject) => { stream.on('finish', resolve); stream.on('error', reject); });
const streams = Promise.all([finished(out), finished(err)]);
const probe = "$n=@(Get-CimInstance Win32_Process -Filter \"Name='msedge.exe' OR Name='chrome.exe'\" | Where-Object { $_.CommandLine -and $_.CommandLine -match '--user-data-dir=.*[\\\\/](?:ruyi-|wcw-)' }); Write-Output $n.Count";
const pre = cp.spawnSync('powershell.exe', ['-NoProfile','-NonInteractive','-Command',probe], { encoding:'utf8', windowsHide:true, timeout:30000 });
if (pre.status !== 0 || !/^0\s*$/.test(pre.stdout)) throw Error('unsafe or failed browser cleanup preflight');
const pythonProbe = cp.spawnSync(python, ['-I','-B','-c','import sys,unittest.mock,struct; print(sys.version.split()[0],struct.calcsize("P")*8)'], { encoding:'utf8', windowsHide:true, timeout:20000 });
if (pythonProbe.status !== 0 || pythonProbe.stdout.trim() !== '3.12.10 64') throw Error('Python identity mismatch');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'ruyi-fast-nav-'));
if (fs.realpathSync(temp).toLowerCase().startsWith(fs.realpathSync(root).toLowerCase()+path.sep)) throw Error('TEMP inside workspace');
receipt.temp = temp; receipt.pythonProbe = {status:pythonProbe.status, stdout:pythonProbe.stdout.trim()}; receipt.browser = browser;
const env = {...process.env, TEMP:temp, TMP:temp, RUYI_TEST_ACC_INSTALLER_PYTHON:python, RUYI_E2E_BROWSER:browser};
const child = cp.spawn(receipt.command[0], receipt.command.slice(1), { cwd: root, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
child.stdout.pipe(out); child.stderr.pipe(err);
child.stdout.once('end', () => receipt.stdoutEOF = true); child.stderr.once('end', () => receipt.stderrEOF = true);
child.once('error', error => receipt.spawnError = { name: error.name, code: error.code || null });
child.once('exit', (code, signal) => receipt.exit = { code, signal, time: new Date().toISOString() });
child.once('close', async (code, signal) => {
  receipt.close = { code, signal, time: new Date().toISOString() };
  try {
    await streams;
    receipt.inputsAfter = snapshot();
    receipt.inputsUnchanged = JSON.stringify(receipt.inputsBefore) === JSON.stringify(receipt.inputsAfter);
    receipt.runnerLogs = {};
    for (const name of ['last-unit-run.log', 'last-run.log']) {
      const source = path.join(root, 'dev-harness', name);
      if (!fs.existsSync(source)) { receipt.runnerLogs[name] = 'not-written'; continue; }
      const before = priorLogs[name], stat = fs.statSync(source), digest = hash(source);
      if (before && before.hash === digest && before.mtimeMs === stat.mtimeMs) {
        receipt.runnerLogs[name] = 'unchanged-preexisting-not-copied'; continue;
      }
      fs.copyFileSync(source, path.join(__dirname, name), fs.constants.COPYFILE_EXCL);
      receipt.runnerLogs[name] = { sha256: digest, mtimeMs: stat.mtimeMs };
    }
    fs.writeFileSync(path.join(__dirname, 'receipt.json'), JSON.stringify(receipt, null, 2), { flag: 'wx' });
    console.log(JSON.stringify(receipt));
    process.exitCode = code === 0 && receipt.inputsUnchanged && receipt.stdoutEOF && receipt.stderrEOF ? 0 : 1;
  } catch (error) { console.error(error); process.exitCode = 1; }
});
console.log('Started final fast verification; original runner owns its per-case budgets.');
