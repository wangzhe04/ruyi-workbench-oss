'use strict';
// REVIEW CANDIDATE. No stage runs without its explicit --execute flag.
// One invocation owns one stage; no automatic chain/retry/cleanup of old runs.
const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process');
const crypto = require('node:crypto'), assert = require('node:assert/strict');
const repo = path.resolve(__dirname, '../..'), wb = path.join(repo, 'ruyi-workbench');
const { releaseEnvironment } = require(path.join(repo, 'dev-harness/lib/release-checks.js'));
const { observeHeldChild, knownClosed } = require(path.join(repo, 'dev-harness/lib/external-bots-c2/actual-http-fixture.cjs'));
const { retainUnknownOwners } = require(path.join(repo, 'dev-harness/lib/offline-package-retention.cjs'));
const { killOwnTree } = require(path.join(repo, 'dev-harness/lib/kill-own-tree.js'));
const CFG = Object.freeze({
  sourceRepo: 'E:/Claude/worktrees/q31-5cd9a6f3',
  donor: 'E:/Claude/ruyi-workbench-oss/mcp/ai-computer-control/build_offline',
  sourceDir: 'E:/Claude/handoffs/ruyi-3.1-resume-20261025/media-source-sidecar',
  sidecar: 'opencv-windows-ffmpeg-source-sidecar.zip', sidecarBytes: 19922194,
  sidecarSha: '09b13acc951b1ca1ed5f0971a51564599daad1bf733d2bf1f02c29d5c124f0d7',
  pkg: 'C:/Users/87179/.pkg-cache/v3.6/fetched-v24.18.0-win-x64',
  pkgSha: '430b93420ce5c670698c90a935274a754ac655a97924b486ea2d7d3371a02e0c',
  browser: 'E:/Claude/ruyi-workbench-oss/mcp/ai-computer-control/build_offline/playwright_browsers/chromium-1234/chrome-win64/chrome.exe',
  browserBytes: 4024832, browserVersion: '151.0.7922.34',
  browserSha: '409805a16d6416087e6b2f778df1cf8f7bbb267d6b99f6b5bb0a618eace234f2',
  overlayAudit: 'output/20261115-donor-manifest-audit-r1.json',
  overlayAuditSha: '7e8b2fa7277f517d5063e0d5a6f227c06104e57c3dde6045e8fcda1498df0391',
  runtimeLockSha: '4e84862cf50907c84b14a55dcabcc347ae3a52e78a88031b7ecb878565d6735f',
  sourceLockSha: '96b07893303e89c9ba668247aa9fb95a15d879c7fd741e674dbfc8491d11fd29',
  baselineTag: '5055930875b32fc713d2fca01f652d7671f374db', cleanupMs: 45000,
});
const STEPS = ['prepare', 'build-slim', 'build-full', 'qualify-slim', 'qualify-full', 'acceptance'];
const HASH = b => crypto.createHash('sha256').update(b).digest('hex');
const hash = file => HASH(fs.readFileSync(file));
const json = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const writeNew = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const safeError = e => ({ name: e.name, code: e.code || '', message: e.message });
function waitWithin(work, ms) {
  let timer; return Promise.race([work.then(value => ({ settled: true, value })),
    new Promise(resolve => { timer = setTimeout(() => resolve({ settled: false }), ms); })]).finally(() => clearTimeout(timer));
}
function within(base, target) {
  const rel = path.relative(path.resolve(base), path.resolve(target));
  assert.ok(rel && !rel.startsWith('..') && !path.isAbsolute(rel), 'target must stay strictly within assigned root');
  return path.resolve(target);
}
function noLinkAncestors(target) {
  const parsed = path.parse(path.resolve(target)); let current = parsed.root;
  for (const part of path.resolve(target).slice(parsed.root.length).split(path.sep)) {
    current = path.join(current, part); if (!fs.existsSync(current)) break;
    assert.ok(!fs.lstatSync(current).isSymbolicLink(), 'junction/symlink ancestor refused: ' + current);
  }
}
function fileRow(file, { singleLink = false } = {}) {
  noLinkAncestors(file); const stat = fs.lstatSync(file);
  assert.ok(stat.isFile() && (!singleLink || stat.nlink === 1), 'regular input / single-link owned target required: ' + file);
  return { file: path.resolve(file), bytes: stat.size, sha256: hash(file) };
}
function systemEnv() {
  const system = {};
  for (const key of ['SystemRoot', 'WINDIR', 'SystemDrive', 'ComSpec', 'OS', 'PATHEXT', 'PROCESSOR_ARCHITECTURE', 'PROCESSOR_IDENTIFIER', 'NUMBER_OF_PROCESSORS', 'ProgramFiles', 'ProgramFiles(x86)', 'CommonProgramFiles', 'CommonProgramFiles(x86)', 'ProgramData']) {
    const actual = Object.keys(process.env).find(name => name.toUpperCase() === key.toUpperCase()); if (actual) system[key] = process.env[actual];
  }
  system.PATH = [path.dirname(process.execPath), 'C:/Program Files/Git/cmd', 'C:/Windows/System32', 'C:/Windows', 'C:/Windows/System32/WindowsPowerShell/v1.0'].join(path.delimiter);
  Object.assign(system, { GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_SYSTEM: 'NUL', GIT_CONFIG_GLOBAL: 'NUL' }); return system;
}
function git(argv, cwd = repo) {
  return cp.execFileSync('C:/Program Files/Git/cmd/git.exe', argv, { cwd, env: systemEnv(), windowsHide: true, encoding: 'utf8', timeout: 20000 });
}
function walk(root) {
  noLinkAncestors(root); const rows = [];
  const visit = dir => { for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a,b) => a.name.localeCompare(b.name, 'en'))) {
    const file = path.join(dir, entry.name); assert.ok(!entry.isSymbolicLink(), 'linked tree entry refused');
    if (entry.isDirectory()) visit(file); else rows.push(fileRow(file));
  } }; visit(root); return rows;
}
function trackedInputs(source = repo) {
  const names = git(['ls-files', '-z', '--', 'ruyi-workbench', 'dev-harness', 'mcp/ai-computer-control', 'facts.json', 'CLAUDE.md', 'CONTRIBUTING.md'], source).split('\0').filter(Boolean).sort();
  const generated = ['ruyi-workbench/RuyiDesktop.exe', 'ruyi-workbench/WebView2Loader.dll', 'ruyi-workbench/dist/Ruyi.exe'];
  assert.ok(generated.every(file => !names.includes(file)), 'official shared generated outputs must be untracked');
  return names.map(file => fileRow(path.join(source, file)));
}
function frozenInputs() {
  const nodeDir=path.dirname(process.execPath);
  const rows = [...trackedInputs(), ...walk(path.join(wb, 'node_modules')),
    fileRow(process.execPath), fileRow(path.join(wb, 'node_modules/.bin/pkg.cmd')),
    ...walk(path.join(nodeDir,'node_modules/npm')),
    ...['npm.cmd','npx.cmd'].map(name=>fileRow(path.join(nodeDir,name))),
    ...['C:/Program Files/Git/cmd/git.exe','C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe',
      'C:/Windows/System32/tar.exe','C:/Windows/System32/robocopy.exe','C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe'].map(file=>fileRow(file)),
    fileRow(__filename)];
  return { head: git(['rev-parse', 'HEAD']).trim(), rows, sha256: HASH(JSON.stringify(rows)) };
}
function workspaceInputs() {
  const rows = [...trackedInputs(CFG.sourceRepo), ...walk(path.join(CFG.sourceRepo, 'ruyi-workbench/node_modules'))];
  return { head: git(['rev-parse', 'HEAD'], CFG.sourceRepo).trim(), rows, sha256: HASH(JSON.stringify(rows)) };
}
async function createWorkspace(run, timeoutMs) {
  noLinkAncestors(CFG.sourceRepo); assert.ok(!fs.existsSync(CFG.sourceRepo), 'fresh short detached worktree required; no existing source cleanup');
  const dir = path.join(run.root, 'prepare-git-worktree'); fs.mkdirSync(dir);
  const receipt = { phase: 'prepare-git-worktree', timeoutMs, status: 'RUNNING', startedAt: new Date().toISOString() };
  const save = () => fs.writeFileSync(path.join(dir, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  const hooks = path.join(run.root,'empty-git-hooks'); fs.mkdirSync(hooks);
  receipt.command = { executable: 'C:/Program Files/Git/cmd/git.exe', cwd: repo,
    argv: ['-c','core.hooksPath='+hooks,'worktree','add','--detach',CFG.sourceRepo,run.inputs.head] }; save();
  try { await originalChild(receipt.command, minimalEnv(run, 'prepare-git'), dir, receipt, save); receipt.status = 'PASS_ORIGINAL_GIT_CHILD_CLOSED'; }
  catch (error) { receipt.failure = safeError(error); if (!receipt.status.startsWith('RED_UNKNOWN')) receipt.status = 'RED_FAILURE_RETAINED'; throw error; }
  finally { receipt.finishedAt = new Date().toISOString(); save(); }
  // Every tracked file in the detached checkout, not only runtime inputs, is
  // independently byte-compared with the assigned committed source worktree.
  const allNames = git(['ls-files','-z']).split('\0').filter(Boolean).sort(), sourceRows = [], copiedRows = [];
  assert.deepEqual(git(['ls-files','-z'],CFG.sourceRepo).split('\0').filter(Boolean).sort(),allNames);
  for (const name of allNames) {
    const original = fileRow(path.join(repo,name)), copied = fileRow(path.join(CFG.sourceRepo,name));
    assert.equal(copied.bytes,original.bytes,'detached source byte count differs: '+name); assert.equal(copied.sha256,original.sha256,'detached source SHA differs: '+name);
    sourceRows.push(original); copiedRows.push(copied);
  }
  writeNew(path.join(run.root,'source-copy-binding.json'),{head:run.inputs.head,gitWorktreeReceipt:'prepare-git-worktree/receipt.json',sourceRows,copiedRows,
    sourceSha256:HASH(JSON.stringify(sourceRows)),copiedSha256:HASH(JSON.stringify(copiedRows)),fullTrackedByteEquality:true});
  const moduleSource = path.join(wb,'node_modules'), moduleTarget = path.join(CFG.sourceRepo,'ruyi-workbench/node_modules');
  assert.ok(!fs.existsSync(moduleTarget)); fs.mkdirSync(moduleTarget);
  for (const row of walk(moduleSource)) {
    const dest = within(moduleTarget,path.join(moduleTarget,path.relative(moduleSource,row.file))); fs.mkdirSync(path.dirname(dest),{recursive:true});
    fs.copyFileSync(row.file,dest,fs.constants.COPYFILE_EXCL); const copied = fileRow(dest,{singleLink:true}); assert.equal(copied.bytes,row.bytes); assert.equal(copied.sha256,row.sha256);
  }
  for (const rel of ['ruyi-workbench/RuyiDesktop.exe','ruyi-workbench/WebView2Loader.dll','ruyi-workbench/dist/Ruyi.exe']) assert.ok(!fs.existsSync(path.join(CFG.sourceRepo,rel)), 'new worktree must not import old generated output');
  run.workspace = workspaceInputs(); assert.equal(run.workspace.head,run.inputs.head);
}
function donorInputs() {
  const auditFile=path.join(repo,CFG.overlayAudit); assert.equal(hash(auditFile),CFG.overlayAuditSha,'exact donor overlay audit required');
  const audit=json(auditFile); assert.equal(audit.mismatches.length,20); assert.equal(audit.matched,17611);
  for(const name of ['missing','unlisted','nonRegular']) assert.equal(audit[name].length,0);
  assert.equal(audit.manifestUnchanged,true);
  const overlay=new Map(audit.mismatches.map(row=>[row.path,row])); assert.equal(overlay.size,20);
  const sourcePrefix='python_embed/Lib/site-packages/ai_computer_control/';
  for(const [relative,allowed] of overlay){
    assert.equal(allowed.scope,'official-replacement-member');
    assert.ok(relative.startsWith(sourcePrefix)&&relative.endsWith('.py')&&!relative.includes('/__pycache__/'));
    const source=path.resolve(repo,'mcp/ai-computer-control/src/ai_computer_control',relative.slice(sourcePrefix.length));
    assert.equal(source,path.resolve(allowed.current.file),'whitelist must name the official current source replacement');
    const current=fileRow(source); assert.equal(current.bytes,allowed.current.bytes); assert.equal(current.sha256,allowed.current.sha256);
  }
  const manifestFile = path.join(CFG.donor, 'offline-manifest.json'), manifest = json(manifestFile);
  assert.equal(hash(manifestFile),audit.manifest.sha256,'donor original manifest changed from audited bytes');
  assert.equal(manifest.pythonVersion, '3.12.10'); assert.equal(manifest.wheelOnly, true);
  assert.equal(manifest.fileCount, manifest.files.length);
  const seen = new Set(), pending=[], rows = manifest.files.map(expected => {
    assert.ok(typeof expected.path === 'string' && !expected.path.includes('\\') && expected.path.split('/').every(part => part && part !== '.' && part !== '..') && !path.isAbsolute(expected.path));
    assert.ok(!seen.has(expected.path.toLowerCase())); seen.add(expected.path.toLowerCase());
    const row = fileRow(within(CFG.donor, path.join(CFG.donor, expected.path)));
    const allowed=overlay.get(expected.path);
    if(allowed){
      assert.equal(expected.bytes,allowed.expected.bytes); assert.equal(expected.sha256,allowed.expected.sha256);
      assert.equal(row.bytes,allowed.actual.bytes,'only the exact audited donor source bytes are admissible'); assert.equal(row.sha256,allowed.actual.sha256);
      pending.push({path:expected.path,originalManifest:allowed.expected,auditedDonor:row,officialCurrentSource:allowed.current,status:'SOURCE_OVERLAY_PENDING'});
    }else{
      assert.equal(row.bytes, expected.bytes, 'donor strict manifest byte mismatch: ' + expected.path);
      assert.equal(row.sha256, expected.sha256, 'donor strict manifest SHA mismatch: ' + expected.path);
    }
    return row;
  });
  assert.equal(pending.length,20,'every exact pending source replacement must be present');
  const expectedNames=new Set(['offline-manifest.json',...manifest.files.map(row=>row.path)]);
  const actualNames=[];
  const enumerate=(dir,relative='')=>{for(const name of fs.readdirSync(dir)){
    const file=path.join(dir,name),rel=relative?relative+'/'+name:name,stat=fs.lstatSync(file);
    assert.ok(!stat.isSymbolicLink(),'linked donor member refused');
    if(stat.isDirectory())enumerate(file,rel);else{assert.ok(stat.isFile());actualNames.push(rel);}
  }};
  enumerate(CFG.donor); assert.equal(actualNames.length,expectedNames.size,'unlisted donor files refused');
  for(const name of actualNames)assert.ok(expectedNames.has(name),'unlisted donor member refused: '+name);
  const lockFile = path.join(wb, 'resources/media-runtime-dependencies.json'); assert.equal(hash(lockFile), CFG.runtimeLockSha);
  const byFile = new Map(rows.map(row => [row.file.toLowerCase(), row]));
  const locked = json(lockFile).artifacts;
  for (const expected of locked) { const row = byFile.get(path.resolve(CFG.donor, expected.path).toLowerCase()); assert.ok(row, 'media artifact absent from donor manifest'); assert.equal(row.bytes, expected.bytes); assert.equal(row.sha256, expected.sha256); }
  assert.equal(locked.length, 4987);
  const sidecar = fileRow(path.join(CFG.sourceDir, CFG.sidecar)); assert.equal(sidecar.bytes, CFG.sidecarBytes); assert.equal(sidecar.sha256, CFG.sidecarSha);
  assert.equal(hash(path.join(wb, 'resources/media-runtime-sources.json')), CFG.sourceLockSha);
  return { manifest: fileRow(manifestFile), rows, sidecar, sha256: HASH(JSON.stringify(rows)),
    status:'STRICT_DEPENDENCY_FILES_VERIFIED_SOURCE_OVERLAY_PENDING',originalWholeManifestVerified:false,
    strictOriginalMembers:rows.length-pending.length,sourceOverlayPending:pending,overlayAudit:fileRow(auditFile) };
}
function assertOfficialOverlayStage(artifacts,donor){
  const acc=path.join(artifacts.stage,'mcp/ai-computer-control'),file=path.join(acc,'offline-manifest.json');
  const manifest=json(file),by=new Map(manifest.files.map(row=>[row.path,row]));
  for(const pending of donor.sourceOverlayPending){
    const actual=fileRow(path.join(acc,pending.path)),expected=by.get(pending.path); assert.ok(expected);
    assert.equal(actual.bytes,pending.officialCurrentSource.bytes); assert.equal(actual.sha256,pending.officialCurrentSource.sha256);
    assert.equal(expected.bytes,actual.bytes); assert.equal(expected.sha256,actual.sha256);
  }
  return {status:'AUDITED20_MEMBERS_REPLACED_WITH_FROZEN_CURRENT_SOURCE',members:donor.sourceOverlayPending.length,
    stagedManifest:fileRow(file),officialFullManifestGate:'Unchanged pinned package-offline.ps1 runs installer.verify_offline_payload before a successful exit; see original build child stdout/exit receipt.'};
}
function minimalEnv(run, phase) {
  const system = systemEnv();
  const outer = path.join(run.root, 'environments', phase), env = releaseEnvironment(path.join(outer, 'home'), path.join(outer, 'data'), system);
  Object.assign(env, { PKG_CACHE_PATH: path.join(run.root, 'pkg-cache'),
    PSModulePath: 'C:/Windows/System32/WindowsPowerShell/v1.0/Modules',
    RUYI_TEST_ACC_INSTALLER_PYTHON: path.join(CFG.donor, 'python_embed/python.exe'),
    RUYI_E2E_BROWSER: CFG.browser,
    NPM_CONFIG_USERCONFIG: path.join(run.root, 'empty-user.npmrc'), NPM_CONFIG_GLOBALCONFIG: path.join(run.root, 'empty-global.npmrc'),
    NPM_CONFIG_CACHE: path.join(run.root, 'npm-cache'), NPM_CONFIG_OFFLINE: 'true', NPM_CONFIG_AUDIT: 'false',
    NPM_CONFIG_FUND: 'false', NPM_CONFIG_UPDATE_NOTIFIER: 'false', NPM_CONFIG_REGISTRY: 'http://127.0.0.1:9/unavailable', CI: 'true',
    PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD: '1' });
  if (phase.startsWith('build-')) env.PATH = [path.join(run.root,'build-shims'),env.PATH].join(path.delimiter);
  return env;
}
function browserIdentity(run) {
  const row=fileRow(CFG.browser); assert.equal(row.bytes,CFG.browserBytes); assert.equal(row.sha256,CFG.browserSha);
  // Read OS PE version metadata only; never launch the browser for this probe.
  const executable='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe';
  const argv=['-NoProfile','-NonInteractive','-Command',
    "[Console]::Write([System.Diagnostics.FileVersionInfo]::GetVersionInfo('"+CFG.browser+"').FileVersion)"];
  const result=cp.spawnSync(executable,argv,{cwd:repo,env:minimalEnv(run,'browser-version-metadata'),windowsHide:true,encoding:'utf8',timeout:20000,maxBuffer:65536});
  assert.ifError(result.error); assert.equal(result.status,0); assert.equal(result.signal,null);
  const fileVersion=String(result.stdout).trim(); assert.equal(fileVersion,CFG.browserVersion);
  return {...row,fileVersion,probe:{executable,argv,status:result.status,signal:result.signal,metadataOnly:true}};
}
function writeDesktopShim(run) {
  const dir=path.join(run.root,'build-shims'); fs.mkdirSync(dir);
  const script=path.join(CFG.sourceRepo,'ruyi-workbench/desktop/build-desktop.ps1');
  assert.ok(!/["\r\n%&|<>^!]/.test(script));
  const bytes=Buffer.from(['@echo off',
    'if /I not "%~1"=="-ExecutionPolicy" exit /b 64',
    'if /I not "%~2"=="Bypass" exit /b 64',
    'if /I not "%~3"=="-File" exit /b 64',
    'if /I not "%~4"=="'+script+'" exit /b 64',
    'if not "%~5"=="" exit /b 64',
    '"C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+script+'"',
    'exit /b %ERRORLEVEL%',''].join('\r\n'),'ascii');
  const file=path.join(dir,'powershell.cmd'); fs.writeFileSync(file,bytes,{flag:'wx'});
  run.desktopShim=fileRow(file,{singleLink:true});
}
function assertFrozen(run) {
  const now = frozenInputs(); assert.equal(now.head, run.inputs.head, 'HEAD changed');
  assert.equal(now.sha256, run.inputs.sha256, 'tracked source/build tool inputs changed');
  assert.equal(hash(path.join(run.root, 'pkg-cache/v3.6/fetched-v24.18.0-win-x64')), CFG.pkgSha);
  assert.equal(hash(path.join(CFG.sourceDir, CFG.sidecar)), CFG.sidecarSha);
  assert.equal(hash(run.desktopShim.file),run.desktopShim.sha256,'fixed Desktop-only NoProfile shim changed');
  const workspace = workspaceInputs(); assert.equal(workspace.head,run.inputs.head); assert.equal(workspace.sha256,run.workspace.sha256,'isolated tracked source/pkg dependencies changed');
  const browser=browserIdentity(run); assert.equal(browser.sha256,run.browser.sha256); assert.equal(browser.bytes,run.browser.bytes); assert.equal(browser.fileVersion,run.browser.fileVersion);
  return { head: now.head, sha256: now.sha256, workspaceSha256:workspace.sha256, browser, unchanged: true };
}
function artifactInputs(run, variant) {
  const packageWb = path.join(CFG.sourceRepo,'ruyi-workbench');
  const stage = within(packageWb, path.join(packageWb, run.outputRelative, 'Ruyi-' + variant)), zip = stage + '.zip';
  const files = walk(stage), manifest = { files, sha256: HASH(JSON.stringify(files)), zip: fileRow(zip) };
  assert.equal(hash(path.join(stage, 'app/server.js')), run.serverSha);
  for (const name of ['Ruyi.exe', 'RuyiDesktop.exe', 'WebView2Loader.dll', 'runtime/node/node.exe']) {
    const file = path.join(stage, name), fd = fs.openSync(file, 'r'), magic = Buffer.alloc(2);
    try { assert.equal(fs.readSync(fd, magic, 0, 2, 0), 2); assert.equal(magic.toString(), 'MZ'); } finally { fs.closeSync(fd); }
  }
  assert.ok(fs.statSync(path.join(stage, 'Ruyi.exe')).size > 10 * 1024 * 1024);
  return { stage, zip, ...manifest };
}
function prior(run, phase) {
  const dir = path.join(run.root, 'stages', phase), value = json(path.join(dir, 'receipt.json'));
  assert.equal(value.status, 'PASS_SCOPED_REQUIRES_ROOT_REVIEW', phase + ' prerequisite is not accepted child success'); return value;
}
function describeCommand(run, phase, stageDir) {
  const packageWb = path.join(CFG.sourceRepo,'ruyi-workbench');
  if (phase.startsWith('build-')) {
    const variant = phase.slice(6), stage = within(packageWb, path.join(packageWb, run.outputRelative, 'Ruyi-' + variant));
    assert.ok(!fs.existsSync(stage) && !fs.existsSync(stage + '.zip'), 'existing package output is retained; use a new run');
    const argv = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', path.join(packageWb, 'tools/package-offline.ps1'), '-OutputDir', run.outputRelative, '-Variant', variant];
    if (variant === 'full') argv.push('-IncludeAcc', '-AccOfflineSource', CFG.donor, '-MediaSourcesRoot', CFG.sourceDir);
    return { executable: 'C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe', argv };
  }
  if (phase.startsWith('qualify-')) {
    const variant = phase.slice(8), built = prior(run, 'build-' + variant), current = artifactInputs(run, variant);
    assert.equal(current.sha256, built.artifacts.sha256); assert.equal(current.zip.sha256, built.artifacts.zip.sha256);
    const argv = [path.join(CFG.sourceRepo, 'dev-harness/lib/offline-package-qualification.cjs'), '--stage', current.stage, '--zip', current.zip.file,
      '--output', path.join(stageDir, 'evidence'), '--expected-server-sha', run.serverSha, '--python', path.join(CFG.donor, 'python_embed/python.exe')];
    if (variant === 'full') argv.push('--full-media'); return { executable: process.execPath, argv };
  }
  for (const variant of ['slim', 'full']) { prior(run, 'qualify-' + variant); const built = prior(run, 'build-' + variant), current = artifactInputs(run, variant); assert.equal(current.sha256, built.artifacts.sha256); assert.equal(current.zip.sha256, built.artifacts.zip.sha256); }
  return { executable: process.execPath, argv: [path.join(CFG.sourceRepo, 'dev-harness/release-package-acceptance.js'), '--repo', CFG.sourceRepo,
    '--slim', path.join(packageWb, run.outputRelative, 'Ruyi-slim.zip'), '--full', path.join(packageWb, run.outputRelative, 'Ruyi-full.zip'),
    '--baseline-ref', 'refs/tags/v3.0.1', '--output', path.join(stageDir, 'evidence')] };
}
async function originalChild(command, env, dir, receipt, save) {
  const logs = {}, writers = [], logErrors = [];
  for (const stream of ['stdout','stderr']) {
    const file = path.join(dir, stream + '.log'), writer = fs.createWriteStream(file, { flags: 'wx' });
    const closed = new Promise(resolve => { writer.once('close', resolve); writer.on('error', error => { logErrors.push(safeError(error)); resolve(); }); });
    logs[stream] = { file, writer }; writers.push(closed);
  }
  const child = cp.spawn(command.executable, command.argv, { cwd: command.cwd || CFG.sourceRepo, env, windowsHide: true, stdio: ['ignore','pipe','pipe'] });
  const row = observeHeldChild(child, receipt.phase, { stdio: 'original stdout/stderr pipes' }); receipt.child = row.facts;
  child.stdout.pipe(logs.stdout.writer); child.stderr.pipe(logs.stderr.writer);
  let timedOut, interrupted, timer, resolveAbort;
  const aborted = new Promise(resolve => { resolveAbort = resolve; });
  const interrupt = signal => { interrupted = signal; resolveAbort('interrupt'); };
  const sigint = () => interrupt('SIGINT'), sigterm = () => interrupt('SIGTERM');
  process.once('SIGINT', sigint); process.once('SIGTERM', sigterm);
  timer = setTimeout(() => { timedOut = true; resolveAbort('timeout'); }, receipt.timeoutMs);
  const reason = await Promise.race([row.closed.then(() => 'close'), aborted]); clearTimeout(timer);
  receipt.timedOut = Boolean(timedOut); receipt.interrupted = interrupted || null;
  const killCurrent = () => { if (!row.facts.exit && !row.facts.close && child.exitCode === null && child.signalCode === null) { row.killReceipt = killOwnTree(child); receipt.killReceipt = row.killReceipt; } };
  if (reason !== 'close') killCurrent();
  if (!knownClosed(row)) await waitWithin(row.closed, CFG.cleanupMs);
  process.removeListener('SIGINT', sigint); process.removeListener('SIGTERM', sigterm);
  if (!knownClosed(row)) {
    receipt.status = 'RED_UNKNOWN_ORIGINAL_OWNER_RETAINED'; save();
    const retained = retainUnknownOwners({ actors: [row], provider: null, deadline: Date.now() + CFG.cleanupMs,
      stop: async () => { killCurrent(); }, note: value => { receipt.retention = value; save(); },
      hardExit: code => { receipt.finishedAt = new Date().toISOString(); save(); process.exit(code); } });
    await retained.promise;
  }
  assert.ok((await waitWithin(Promise.all(writers), CFG.cleanupMs)).settled,'complete log file closure deadline');
  receipt.logErrors = logErrors; receipt.logs = {};
  for (const name of ['stdout','stderr']) receipt.logs[name] = fileRow(logs[name].file);
  assert.ok(knownClosed(row), 'original child exit/close/double EOF required');
  assert.equal(logErrors.length, 0); assert.ok(!receipt.timedOut && !receipt.interrupted, 'outer timeout/interrupt remains RED');
  assert.equal(row.facts.exit.code, 0); assert.equal(row.facts.exit.signal, null);
}
async function prepare(id, expectedHead, timeoutMs) {
  const root = within(path.join(repo, 'output'), path.join(repo, 'output/20261115-postcommit-release-runs', id));
  noLinkAncestors(root); assert.ok(!fs.existsSync(root), 'new run directory required'); fs.mkdirSync(root, { recursive: true });
  const packageWb = path.join(CFG.sourceRepo,'ruyi-workbench');
  const outputRelative = 'dist/pq-' + id, output = within(path.join(packageWb, 'dist'), path.join(packageWb, outputRelative));
  noLinkAncestors(output); assert.ok(!fs.existsSync(output), 'new package output root required');
  const run = { schema: 1, root, id, outputRelative, createdAt: new Date().toISOString(), cfg: CFG, controllerSha256: hash(__filename), prepared: false };
  writeNew(path.join(root, 'owner.json'), { nonce: crypto.randomBytes(24).toString('hex'), run: root, output, controllerSha256: run.controllerSha256, noHistoricalCleanup: true });
  try {
    run.inputs = frozenInputs(); assert.equal(run.inputs.head, git(['rev-parse', '--verify', expectedHead + '^{commit}']).trim(), 'explicit expected HEAD required');
    assert.equal(git(['rev-parse', 'refs/tags/v3.0.1']).trim(), CFG.baselineTag);
    assert.ok(process.versions.node.startsWith('24.'), 'Node24 development baseline required');
    run.donor = donorInputs(); run.pkg = fileRow(CFG.pkg); assert.equal(run.pkg.sha256, CFG.pkgSha);
    assert.ok(fs.existsSync(path.join(wb, 'node_modules/.bin/pkg.cmd')), 'local pkg must already exist; npm install forbidden');
    assert.equal(json(path.join(wb, 'node_modules/@yao-pkg/pkg-fetch/package.json')).version, '3.6.4');
    assert.equal(json(path.join(wb, 'node_modules/@yao-pkg/pkg-fetch/lib-es5/expected-shas.json'))['node-v24.18.0-win-x64'], CFG.pkgSha);
    fs.mkdirSync(path.join(root, 'pkg-cache/v3.6'), { recursive: true });
    fs.copyFileSync(CFG.pkg, path.join(root, 'pkg-cache/v3.6/fetched-v24.18.0-win-x64'), fs.constants.COPYFILE_EXCL);
    for (const name of ['empty-user.npmrc','empty-global.npmrc']) fs.writeFileSync(path.join(root, name), '', { flag: 'wx' });
    run.browser=browserIdentity(run);
    await createWorkspace(run,timeoutMs);
    writeDesktopShim(run);
    fs.mkdirSync(path.join(root, 'stages')); fs.mkdirSync(output, { recursive: true });
    writeNew(path.join(output, 'qualification-owner.json'), json(path.join(root, 'owner.json')));
    run.serverSha = hash(path.join(wb, 'app/server.js')); run.prepared = true;
  } catch (error) { run.failure = safeError(error); throw error; }
  finally { writeNew(path.join(root, 'run.json'), run); }
  console.log(JSON.stringify({ status: 'PREPARED_ONLY', root, output, nextStageExplicit: 'build-slim',
    donorStrictVerifiedFiles:run.donor.strictOriginalMembers,donorSourceOverlayPending:run.donor.sourceOverlayPending.length,
    originalWholeDonorManifestVerified:false,wholeReleaseAccepted: false }));
}
async function execute(id, phase, timeoutMs) {
  const root = within(path.join(repo, 'output'), path.join(repo, 'output/20261115-postcommit-release-runs', id)); noLinkAncestors(root);
  const run = json(path.join(root, 'run.json')); assert.equal(run.root, root); assert.equal(run.id, id); assert.equal(run.prepared, true); assert.equal(run.controllerSha256, hash(__filename));
  assert.equal(run.outputRelative,'dist/pq-'+id);
  assert.deepEqual(run.cfg, CFG); const owner = json(path.join(root, 'owner.json'));
  assert.equal(owner.run,root);
  assert.equal(owner.output,path.resolve(CFG.sourceRepo,'ruyi-workbench','dist/pq-'+id));
  assert.deepEqual(json(path.join(CFG.sourceRepo,'ruyi-workbench',run.outputRelative,'qualification-owner.json')),owner);
  const lease = path.join(root, 'active-operation.json'), dir = path.join(root, 'stages', phase);
  assert.ok(!fs.existsSync(dir), 'stage attempt already exists and is retained; no automatic retry');
  writeNew(lease, { nonce: owner.nonce, phase, pid: process.pid, startedAt: new Date().toISOString() }); fs.mkdirSync(dir);
  const receipt = { schema: 1, phase, runId: id, startedAt: new Date().toISOString(), timeoutMs, controllerSha256: hash(__filename), status: 'RUNNING',
    noHistoricalCleanup: true, allDescendantKernelExitCertified: false, wholeReleaseAccepted: false,
    generatedSharedOutputs: ['ruyi-workbench/RuyiDesktop.exe','ruyi-workbench/WebView2Loader.dll','ruyi-workbench/' + run.outputRelative + '/Ruyi.exe'].map(rel=>path.join(CFG.sourceRepo,rel)) };
  const save = () => fs.writeFileSync(path.join(dir, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n'); save();
  try {
    receipt.inputsBefore = assertFrozen(run);
    receipt.generatedBefore=receipt.generatedSharedOutputs.map(file=>fs.existsSync(file)?fileRow(file):{file,absent:true});
    if (phase === 'build-full') prior(run, 'build-slim');
    receipt.command = describeCommand(run, phase, dir); const env = minimalEnv(run, phase);
    receipt.environment = env; save(); await originalChild(receipt.command, env, dir, receipt, save);
    receipt.inputsAfter = assertFrozen(run);
    receipt.generatedAfter=receipt.generatedSharedOutputs.map(file=>fs.existsSync(file)?fileRow(file):{file,absent:true});
    if (phase.startsWith('build-')) {
      receipt.artifacts = artifactInputs(run, phase.slice(6));
      if (phase === 'build-full') { const after = donorInputs(); assert.equal(after.sha256, run.donor.sha256); assert.equal(after.manifest.sha256, run.donor.manifest.sha256);
        receipt.donorAfter = { unchanged: true, sha256: after.sha256, manifestSha256: after.manifest.sha256,originalWholeManifestVerified:false,sourceOverlayPending:after.sourceOverlayPending.length };
        receipt.officialSourceOverlay=assertOfficialOverlayStage(receipt.artifacts,run.donor); }
    } else if (phase.startsWith('qualify-')) {
      const reportFile = path.join(dir, 'evidence/qualification.json'), report = json(reportFile);
      assert.equal(report.status, 'PASS_SCOPED_PACKAGE_QUALIFICATION'); assert.equal(report.cleanup.status, 'KNOWN_ORIGINAL_ACTORS_CLOSED');
      receipt.innerReport = fileRow(reportFile);
    } else {
      const reportFile = path.join(dir, 'evidence/validation.json'), report = json(reportFile);
      assert.equal(report.complete, true); assert.equal(report.failures, 0); receipt.innerReport = fileRow(reportFile);
    }
    receipt.status = 'PASS_SCOPED_REQUIRES_ROOT_REVIEW';
  } catch (error) { receipt.failure = safeError(error); if (!receipt.status.startsWith('RED_UNKNOWN')) receipt.status = 'RED_FAILURE_RETAINED'; process.exitCode = 1; }
  finally {
    if (!receipt.generatedAfter) {
      try { receipt.generatedAfter=receipt.generatedSharedOutputs.map(file=>fs.existsSync(file)?fileRow(file):{file,absent:true}); }
      catch (error) { receipt.generatedOutputObservationFailure=safeError(error); }
    }
    receipt.finishedAt = new Date().toISOString(); receipt.elapsedMs = Date.now() - Date.parse(receipt.startedAt); save();
    // An UNKNOWN lease is deliberately retained; never unlock by old PID/name.
    if (!receipt.status.startsWith('RED_UNKNOWN')) fs.unlinkSync(lease);
    console.log(JSON.stringify({ phase, status: receipt.status, receipt: path.join(dir, 'receipt.json'), elapsedMs: receipt.elapsedMs }));
  }
}
async function main() {
  const [phase, ...argv] = process.argv.slice(2);
  if (!phase || phase === '--help') { console.log('REVIEW CANDIDATE. Stages: ' + STEPS.join(', ') + '\nprepare --run-id <new-id> --expected-head <commit> --timeout-ms <approved-git-child-cap> --execute\nOther stage: --run-id <id> --timeout-ms <explicit-approved-outer-cap> --execute\nNo automatic chain/retry. Do not execute while Terra owns the window.'); return; }
  assert.ok(STEPS.includes(phase)); const options = {};
  for (let i = 0; i < argv.length; i++) { const key = argv[i]; assert.ok(['--run-id','--expected-head','--timeout-ms','--execute'].includes(key) && !Object.hasOwn(options, key)); options[key] = key === '--execute' ? true : argv[++i]; }
  assert.equal(options['--execute'], true, 'explicit execution flag required'); assert.match(options['--run-id'] || '', /^[a-z0-9][a-z0-9-]{0,23}$/);
  const timeout = Number(options['--timeout-ms']); assert.ok(Number.isSafeInteger(timeout) && timeout > 0 && timeout <= 86400000, 'explicit positive outer caller cap required; internal harness budgets stay unchanged');
  if (phase === 'prepare') { assert.ok(options['--expected-head']); return prepare(options['--run-id'], options['--expected-head'],timeout); }
  return execute(options['--run-id'], phase, timeout);
}
main().catch(error => { console.error(JSON.stringify({ status: 'CONTROLLER_REFUSED_OR_FAILED', error: safeError(error) })); process.exitCode = 1; });
