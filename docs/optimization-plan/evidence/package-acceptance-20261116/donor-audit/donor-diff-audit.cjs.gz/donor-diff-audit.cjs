'use strict';
// Read-only cache audit. No module from donor is imported or executed.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../..'),donor='E:/Claude/ruyi-workbench-oss/mcp/ai-computer-control/build_offline';
const output=path.join(repo,'output/20261115-donor-manifest-audit-r1.json');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const row=file=>{const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink())throw Error('non-regular audit member');return {bytes:s.size,sha256:sha(fs.readFileSync(file))};};
const prefix='python_embed/Lib/site-packages/ai_computer_control/',currentRoot=path.join(repo,'mcp/ai-computer-control/src/ai_computer_control');
const replacements=new Map([['install.py','installer/install.py'],['install.bat','installer/install.bat'],['mcp_config_template.json','installer/mcp_config_template.json'],['requirements_offline.txt','requirements_offline.txt']].map(([a,b])=>[a,path.join(repo,'mcp/ai-computer-control',b)]));
const currentPath=rel=>rel.startsWith(prefix)?path.join(currentRoot,rel.slice(prefix.length)):replacements.get(rel);
const discardedBytecode=rel=>rel.startsWith(prefix)&&(rel.includes('/__pycache__/')||rel.toLowerCase().endsWith('.pyc'));
const manifestFile=path.join(donor,'offline-manifest.json'),manifestBytes=fs.readFileSync(manifestFile),manifest=JSON.parse(manifestBytes);
const result={schema:1,startedAt:new Date().toISOString(),donor,manifest:{bytes:manifestBytes.length,sha256:sha(manifestBytes),fileCount:manifest.fileCount,rows:manifest.files.length},matched:0,mismatches:[],missing:[],unlisted:[],nonRegular:[],allFileBytesRead:0,donorModified:false,executedModules:false};
const listed=new Set(['offline-manifest.json']);
for(const expected of manifest.files){
 const rel=expected.path;if(typeof rel!=='string'||rel.includes('\\')||rel.split('/').some(x=>!x||x==='.'||x==='..')||path.isAbsolute(rel))throw Error('unsafe manifest path');
 if(listed.has(rel))throw Error('duplicate manifest path');listed.add(rel);
 const file=path.join(donor,rel),source=currentPath(rel);let current=null;
 if(source&&fs.existsSync(source))current={file:source,...row(source)};
 const scope=discardedBytecode(rel)?'official-dropped-bytecode':current?'official-replacement-member':'strict-original-member';
 if(!fs.existsSync(file)){result.missing.push({path:rel,expected,scope,current});continue;}
 const actual=row(file);result.allFileBytesRead+=actual.bytes;
 if(actual.bytes===expected.bytes&&actual.sha256===expected.sha256)result.matched++;
 else result.mismatches.push({path:rel,expected:{bytes:expected.bytes,sha256:expected.sha256},actual,scope,current,equalsCurrent:current?actual.bytes===current.bytes&&actual.sha256===current.sha256:null});
}
function walk(dir,rel=''){for(const name of fs.readdirSync(dir)){const file=path.join(dir,name),r=rel?rel+'/'+name:name,s=fs.lstatSync(file);if(s.isSymbolicLink()){result.nonRegular.push({path:r,kind:'symlink'});continue;}if(s.isDirectory())walk(file,r);else if(!listed.has(r)){const actual=row(file),source=currentPath(r);result.unlisted.push({path:r,...actual,scope:discardedBytecode(r)?'official-dropped-bytecode':source&&fs.existsSync(source)?'official-replacement-member':'strict-unlisted-member'});}}}
walk(donor);
result.manifestUnchanged=sha(fs.readFileSync(manifestFile))===result.manifest.sha256;
result.finishedAt=new Date().toISOString();fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output,manifestRows:manifest.files.length,matched:result.matched,mismatches:result.mismatches.length,missing:result.missing.length,unlisted:result.unlisted.length,nonRegular:result.nonRegular.length,bytesRead:result.allFileBytesRead,manifestUnchanged:result.manifestUnchanged}));
