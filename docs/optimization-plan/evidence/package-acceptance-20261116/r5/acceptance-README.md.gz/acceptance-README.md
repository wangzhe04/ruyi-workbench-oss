# Acceptance-only r5

Root approved the r4 plan and source/harness split, fixed five same-package/CfT regressions, complete fast and committed harness `6cea256beadf5f9e9962c19ca92ae161354ea1ca`. r4 stopped before launching acceptance: its dependency expected array contained pkg.cmd twice because the original snapshot recorded both a full node_modules walk and a specific pkg entry. No package/input drift was proved and no acceptance child/evidence was launched. The original r4 controller3164222a...936d34 and preflight RED receipt remain in r4.

r5 changes only expected dependency **membership** to a Set of paths; all original row bytes/SHA remain checked, including both records of pkg.cmd. No disk entry or hash is skipped. It uses fresh r5 receipts/evidence/environment and role names. Package, app, current committed harness, fixed CfT, outer3600000 and every internal budget/condition remain as described in ACCEPTANCE-R4.md. Shorter evidence layout is disclosed separately, never claimed as the repair. Root cause-specific change remains explicit navigation.

```powershell
node output/20261115-postcommit-release-controller/acceptance-r5.cjs --execute --timeout-ms 3600000 --expected-head 6cea256beadf5f9e9962c19ca92ae161354ea1ca
```

Receipt/controller/logs: implementation `output/20261115-postcommit-release-runs/r5`. New evidence: `E:/Claude/worktrees/q31-c0ab478b/output/acceptance-r5`, environment at its `-env` sibling. Both must be absent at execution; no prior scene is deleted. Unchanged original ZIPs and sibling stages remain in `q31-c0ab478b/ruyi-workbench/dist/pq-r3` with pinned Slim9115331b...93a999 and Full266505ee...c4d047.
