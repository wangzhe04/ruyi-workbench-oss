'use strict';
// REVIEW CANDIDATE. Current committed harness, unchanged previously built app
// packages. Navigation repair is the cause-specific change; shorter evidence
// layout is disclosed separately and is not claimed to fix the failure.
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../..'),source=repo,packageSource='E:/Claude/worktrees/q31-c0ab478b';
const r3Root=path.join(repo,'output/20261115-postcommit-release-runs/r3');
const r4Root=path.join(repo,'output/20261115-postcommit-release-runs/r5');
const evidence='E:/Claude/worktrees/q31-c0ab478b/output/acceptance-r5',envRoot=evidence+'-env';
const {releaseEnvironment}=require(path.join(repo,'dev-harness/lib/release-checks.js'));
const {observeHeldChild,knownClosed}=require(path.join(repo,'dev-harness/lib/external-bots-c2/actual-http-fixture.cjs'));
const {retainUnknownOwners}=require(path.join(repo,'dev-harness/lib/offline-package-retention.cjs'));
const {killOwnTree}=require(path.join(repo,'dev-harness/lib/kill-own-tree.js'));
const PIN={packageSourceHead:'c0ab478bb3d7a55e6dca4ec2244584a2fe19620f',baseline:'5055930875b32fc713d2fca01f652d7671f374db',r3Controller:'9f2780ee9c4908b5906a8ba538817dd9f65df99ab4300b94d026e2719124445e',
 runSha:'90f5b9d1e38b00a4400eb34d490292723c5e23a98436522e1525aca683877db9',
 sourceSha:'6d3fc2511dcbe45e8881510087a9445b67b37af1205e1a11eca677e808a2f985',workspaceSha:'926dbd7bbfc733fc16ad6ae57d1daadf67db1cfb1af8bc7ef72170b31fe0118a',
 server:'664e42bf8314965fb9e2596329fb688bab1ee79bc68fa774aad91174b43f6073',
 browser:'E:/Claude/ruyi-workbench-oss/mcp/ai-computer-control/build_offline/playwright_browsers/chromium-1234/chrome-win64/chrome.exe',
 browserSha:'409805a16d6416087e6b2f778df1cf8f7bbb267d6b99f6b5bb0a618eace234f2',browserBytes:4024832,browserVersion:'151.0.7922.34',
 slim:{bytes:88385377,sha256:'9115331bd7bc7c288782823d921dced9cfc21c11455910a9f695aeb20793a999'},
 full:{bytes:839619269,sha256:'266505ee1e1d7f2c75833ae5ffdf7268d07585314719472076b73fdd91c4d047'}};
const digest=b=>crypto.createHash('sha256').update(b).digest('hex'),hash=f=>digest(fs.readFileSync(f));
const json=f=>JSON.parse(fs.readFileSync(f,'utf8'));
const write=(f,x)=>fs.writeFileSync(f,JSON.stringify(x,null,2)+'\n',{flag:'wx'});
const failure=e=>({name:e.name,code:e.code||'',message:e.message});
function noLinks(file){let cur=path.parse(path.resolve(file)).root;for(const part of path.resolve(file).slice(cur.length).split(path.sep)){cur=path.join(cur,part);if(!fs.existsSync(cur))break;assert.ok(!fs.lstatSync(cur).isSymbolicLink(),'linked evidence/input path refused');}}
function row(file){noLinks(file);const s=fs.lstatSync(file);assert.ok(s.isFile());return{file:path.resolve(file),bytes:s.size,sha256:hash(file)};}
function checkRows(rows){for(const before of rows){const after=row(before.file);assert.equal(after.bytes,before.bytes,before.file);assert.equal(after.sha256,before.sha256,before.file);}return{rows:rows.length,sha256:digest(JSON.stringify(rows)),unchanged:true};}
function names(root){const result=[];const visit=dir=>{noLinks(dir);for(const name of fs.readdirSync(dir)){const file=path.join(dir,name),s=fs.lstatSync(file);assert.ok(!s.isSymbolicLink());if(s.isDirectory())visit(file);else{assert.ok(s.isFile());result.push(path.resolve(file));}}};visit(root);return result.sort();}
function system(){const env={};for(const key of ['SystemRoot','WINDIR','SystemDrive','ComSpec','OS','PATHEXT','PROCESSOR_ARCHITECTURE','PROCESSOR_IDENTIFIER','NUMBER_OF_PROCESSORS','ProgramFiles','ProgramFiles(x86)','CommonProgramFiles','CommonProgramFiles(x86)','ProgramData']){const actual=Object.keys(process.env).find(x=>x.toUpperCase()===key.toUpperCase());if(actual)env[key]=process.env[actual];}
 Object.assign(env,{PATH:[path.dirname(process.execPath),'C:/Program Files/Git/cmd','C:/Windows/System32','C:/Windows','C:/Windows/System32/WindowsPowerShell/v1.0'].join(path.delimiter),GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_SYSTEM:'NUL',GIT_CONFIG_GLOBAL:'NUL',PSModulePath:'C:/Windows/System32/WindowsPowerShell/v1.0/Modules'});return env;}
function environment(run){const env=releaseEnvironment(path.join(envRoot,'home'),path.join(envRoot,'data'),system());Object.assign(env,{RUYI_E2E_BROWSER:PIN.browser,RUYI_TEST_ACC_INSTALLER_PYTHON:run.browser?path.join(run.cfg.donor,'python_embed/python.exe'):'',PKG_CACHE_PATH:path.join(r3Root,'pkg-cache'),NPM_CONFIG_USERCONFIG:path.join(r4Root,'empty-user.npmrc'),NPM_CONFIG_GLOBALCONFIG:path.join(r4Root,'empty-global.npmrc'),NPM_CONFIG_CACHE:path.join(envRoot,'npm-cache'),NPM_CONFIG_OFFLINE:'true',NPM_CONFIG_AUDIT:'false',NPM_CONFIG_FUND:'false',NPM_CONFIG_UPDATE_NOTIFIER:'false',NPM_CONFIG_REGISTRY:'http://127.0.0.1:9/unavailable',CI:'true',PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD:'1'});return env;}
function git(args,cwd=repo){return cp.execFileSync('C:/Program Files/Git/cmd/git.exe',args,{cwd,env:system(),encoding:'utf8',windowsHide:true,timeout:20000,maxBuffer:8*1024*1024});}
function gitHead(cwd){return git(['rev-parse','HEAD'],cwd).trim();}
function browser(env){const b=row(PIN.browser);assert.equal(b.bytes,PIN.browserBytes);assert.equal(b.sha256,PIN.browserSha);const argv=['-NoProfile','-NonInteractive','-Command',"[Console]::Write([System.Diagnostics.FileVersionInfo]::GetVersionInfo('"+PIN.browser+"').FileVersion)"];
 const p=cp.spawnSync('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe',argv,{cwd:source,env,windowsHide:true,encoding:'utf8',timeout:20000,maxBuffer:65536});assert.ifError(p.error);assert.equal(p.status,0);assert.equal(p.signal,null);assert.equal(p.stdout.trim(),PIN.browserVersion);return{...b,fileVersion:p.stdout.trim(),metadataOnly:true};}
function checkPackages(){const result={};for(const variant of ['slim','full']){const built=json(path.join(r3Root,'stages/build-'+variant+'/receipt.json'));assert.equal(built.status,'PASS_SCOPED_REQUIRES_ROOT_REVIEW');const a=built.artifacts,expected=path.resolve(packageSource,'ruyi-workbench/dist/pq-r3/Ruyi-'+variant);assert.equal(a.stage,expected);assert.equal(a.zip.file,expected+'.zip');
 const z=row(a.zip.file);assert.equal(z.bytes,PIN[variant].bytes);assert.equal(z.sha256,PIN[variant].sha256);assert.equal(z.sha256,a.zip.sha256);assert.deepEqual(names(a.stage),a.files.map(x=>x.file).sort(),'unexpected stage file membership');const stage=checkRows(a.files);assert.equal(stage.sha256,a.sha256);assert.equal(hash(path.join(a.stage,'app/server.js')),PIN.server);
 const prefix=path.join(a.stage,'app')+path.sep,appRows=a.files.filter(x=>x.file.startsWith(prefix)),currentApp=path.join(repo,'ruyi-workbench/app');
 const boundCurrent=appRows.map(x=>({file:path.join(currentApp,path.relative(path.join(a.stage,'app'),x.file)),bytes:x.bytes,sha256:x.sha256}));
 assert.deepEqual(names(currentApp),boundCurrent.map(x=>x.file).sort(),'current app membership differs from original package');
 result[variant]={stage,zip:z,currentAppMatchesOriginalPackage:checkRows(boundCurrent)};}return result;}
function check(run,env,expectedHead){assert.equal(gitHead(repo),expectedHead);assert.equal(gitHead(packageSource),PIN.packageSourceHead);assert.equal(git(['rev-parse','refs/tags/v3.0.1']).trim(),PIN.baseline);assert.equal(hash(path.join(r3Root,'controller.cjs')),PIN.r3Controller);assert.equal(hash(path.join(repo,'output/20261115-postcommit-release-controller/controller.cjs')),PIN.r3Controller);assert.equal(hash(path.join(source,'ruyi-workbench/app/server.js')),PIN.server);
 const harnessPrefix=path.resolve(repo,'dev-harness')+path.sep;
 const unchangedOriginal=run.inputs.rows.filter(x=>!x.file.startsWith(harnessPrefix));
 for(const [root,rows] of [[repo,run.inputs.rows],[packageSource,run.workspace.rows]]){const modules=path.resolve(root,'ruyi-workbench/node_modules'),prefix=modules.toLowerCase()+path.sep;assert.deepEqual(names(modules),[...new Set(rows.filter(x=>x.file.toLowerCase().startsWith(prefix)).map(x=>x.file))].sort(),'dependency membership changed');
  const dirty=cp.execFileSync('C:/Program Files/Git/cmd/git.exe',['status','--porcelain','--untracked-files=all','--','ruyi-workbench','dev-harness','mcp/ai-computer-control','facts.json','CLAUDE.md','CONTRIBUTING.md'],{cwd:root,env:system(),encoding:'utf8',windowsHide:true,timeout:20000,maxBuffer:8*1024*1024});assert.equal(dirty.trim(),'','source membership/working tree changed');}
 const original=checkRows(unchangedOriginal),workspace=checkRows(run.workspace.rows);assert.equal(workspace.sha256,PIN.workspaceSha);
 const harnessNames=git(['ls-files','--cached','--others','--exclude-standard','-z','--','dev-harness']).split('\0').filter(Boolean).sort();
 const harnessRows=harnessNames.map(rel=>row(path.join(repo,rel)));
 return{harnessHead:expectedHead,harness:{rows:harnessRows,sha256:digest(JSON.stringify(harnessRows))},unchangedOriginalNonHarness:original,originalPackageWorkspace:workspace,packages:checkPackages(),browser:browser(env)};}
function within(promise,ms){let timer;return Promise.race([promise.then(value=>({settled:true,value})),new Promise(resolve=>{timer=setTimeout(()=>resolve({settled:false}),ms);})]).finally(()=>clearTimeout(timer));}
async function main(){if(process.argv.length===2||process.argv.includes('--help')){console.log('Root-approved r5 attempt: node acceptance-r5.cjs --execute --timeout-ms 3600000 --expected-head 6cea256beadf5f9e9962c19ca92ae161354ea1ca');return;}
 assert.deepEqual(process.argv.slice(2,4),['--execute','--timeout-ms']);assert.equal(process.argv[5],'--expected-head');assert.equal(process.argv.length,7);const expectedHead=process.argv[6];assert.match(expectedHead,/^[a-f0-9]{40}$/);const timeoutMs=Number(process.argv[4]);assert.equal(timeoutMs,3600000,'same approved outer observation cap; inner budgets unchanged');
 for(const dir of [r4Root,evidence,envRoot]){noLinks(dir);assert.ok(!fs.existsSync(dir),'fresh r5 path required; failed r3 and preflight r4 are retained');}
 fs.mkdirSync(r4Root,{recursive:true});fs.copyFileSync(__filename,path.join(r4Root,'controller.cjs'),fs.constants.COPYFILE_EXCL);
 const receipt={schema:1,status:'PREPARING',startedAt:new Date().toISOString(),timeoutMs,controller:row(path.join(r4Root,'controller.cjs')),source,output:evidence,
  changeScope:'Current reviewed committed harness includes explicit-navigation repair; package app byte-for-byte unchanged. Shorter fresh evidence/environment layout is separately disclosed, not the root-cause fix. Same CFT and inner budgets. No build.',expectedHarnessHead:expectedHead,packageSourceHead:PIN.packageSourceHead,r3FailureRetained:true,allDescendantKernelExitCertified:false,wholeReleaseAccepted:false};
 const save=()=>fs.writeFileSync(path.join(r4Root,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');save();
 let held,env,run;
 try{
  const runFile=path.join(r3Root,'run.json');assert.equal(hash(runFile),PIN.runSha);run=json(runFile);assert.equal(run.prepared,true);assert.equal(run.controllerSha256,PIN.r3Controller);assert.equal(run.inputs.head,PIN.packageSourceHead);assert.equal(run.cfg.sourceRepo,packageSource);
  for(const name of ['empty-user.npmrc','empty-global.npmrc'])fs.writeFileSync(path.join(r4Root,name),'',{flag:'wx'});
  env=environment(run);receipt.environment=env;receipt.inputsBefore=check(run,env,expectedHead);
  receipt.command={executable:process.execPath,argv:[path.join(source,'dev-harness/release-package-acceptance.js'),'--repo',source,'--slim',path.join(packageSource,'ruyi-workbench/dist/pq-r3/Ruyi-slim.zip'),'--full',path.join(packageSource,'ruyi-workbench/dist/pq-r3/Ruyi-full.zip'),'--baseline-ref','refs/tags/v3.0.1','--output',evidence],cwd:source};
  const outputs={},closedLogs=[],logErrors=[];for(const stream of ['stdout','stderr']){const w=fs.createWriteStream(path.join(r4Root,stream+'.log'),{flags:'wx'});closedLogs.push(new Promise(resolve=>{w.once('close',resolve);w.on('error',e=>{logErrors.push(failure(e));resolve();});}));outputs[stream]=w;}
  const child=cp.spawn(receipt.command.executable,receipt.command.argv,{cwd:source,env,windowsHide:true,stdio:['ignore','pipe','pipe']});held=observeHeldChild(child,'acceptance-r5',{stdio:'original stdout/stderr pipes'});receipt.child=held.facts;receipt.status='RUNNING';save();child.stdout.pipe(outputs.stdout);child.stderr.pipe(outputs.stderr);
  let timer,resolveAbort;const aborted=new Promise(resolve=>{resolveAbort=resolve;});const interrupt=signal=>{receipt.interrupted=signal;resolveAbort('interrupt');};const sigint=()=>interrupt('SIGINT'),sigterm=()=>interrupt('SIGTERM');process.once('SIGINT',sigint);process.once('SIGTERM',sigterm);
  timer=setTimeout(()=>{receipt.timedOut=true;resolveAbort('timeout');},timeoutMs);const reason=await Promise.race([held.closed.then(()=>'close'),aborted]);clearTimeout(timer);process.removeListener('SIGINT',sigint);process.removeListener('SIGTERM',sigterm);
  const stopCurrent=()=>{if(!held.facts.exit&&!held.facts.close&&child.exitCode===null&&child.signalCode===null){held.killReceipt=killOwnTree(child);receipt.killReceipt=held.killReceipt;}};if(reason!=='close')stopCurrent();if(!knownClosed(held))await within(held.closed,45000);
  if(!knownClosed(held)){receipt.status='RED_UNKNOWN_ORIGINAL_OWNER_RETAINED';save();const retention=retainUnknownOwners({actors:[held],provider:null,deadline:Date.now()+45000,stop:async()=>stopCurrent(),note:x=>{receipt.retention=x;save();},hardExit:code=>{save();process.exit(code);}});await retention.promise;}
  assert.ok((await within(Promise.all(closedLogs),45000)).settled);receipt.logErrors=logErrors;receipt.logs={stdout:row(path.join(r4Root,'stdout.log')),stderr:row(path.join(r4Root,'stderr.log'))};assert.ok(knownClosed(held));assert.equal(logErrors.length,0);assert.ok(!receipt.timedOut&&!receipt.interrupted);assert.equal(held.facts.exit.code,0);assert.equal(held.facts.exit.signal,null);
  const reportFile=path.join(evidence,'validation.json'),report=json(reportFile);receipt.validation=row(reportFile);assert.equal(report.complete,true);assert.equal(report.failures,0);receipt.status='PASS_SCOPED_REQUIRES_ROOT_REVIEW';
 }catch(error){receipt.failure=failure(error);if(!receipt.status.startsWith('RED_UNKNOWN'))receipt.status='RED_FAILURE_RETAINED';process.exitCode=1;}
 finally{if(run&&env){try{receipt.inputsAfter=check(run,env,expectedHead);if(receipt.inputsBefore)assert.equal(receipt.inputsAfter.harness.sha256,receipt.inputsBefore.harness.sha256,'current harness drifted during acceptance');}catch(error){receipt.inputRecheckFailure=failure(error);if(!receipt.status.startsWith('RED_UNKNOWN'))receipt.status='RED_INPUT_DRIFT_RETAINED';process.exitCode=1;}}
  if(fs.existsSync(path.join(evidence,'validation.json'))&&!receipt.validation)receipt.validation=row(path.join(evidence,'validation.json'));
  receipt.finishedAt=new Date().toISOString();receipt.elapsedMs=Date.now()-Date.parse(receipt.startedAt);save();console.log(JSON.stringify({status:receipt.status,receipt:path.join(r4Root,'receipt.json'),elapsedMs:receipt.elapsedMs}));}
}
main().catch(error=>{console.error(JSON.stringify({status:'CONTROLLER_REFUSED_OR_FAILED',error:failure(error)}));process.exitCode=1;});
