'use strict';
// Actual JS crypto/Store/Tree/FullSnapshot/13u and ordinary owned FS. Native Basic/ADS,
// account protector and ownership issuance remain explicit pure-test models.
const fs=require('node:fs'),fsp=require('node:fs/promises'),p=require('node:path'),vm=require('node:vm'),a=require('node:assert/strict');const{originalFixture}=require('./work-data-original-portable-fixture');
async function setup(t){const f=await originalFixture(t),target=p.join(f.root,'preserved-target'),sourceLease=Object.freeze({roots:Object.freeze([f.base])}),targetLease=Object.freeze({roots:Object.freeze([target])}),leases=new Set([sourceLease,targetLease]),events=[],captureState={targetCaptures:0,before:null};let nativeDepth=0;const capture=f.special.native.capture;f.special.native.capture=async(...args)=>{nativeDepth++;try{if(p.resolve(args[0])===p.resolve(target)){captureState.targetCaptures++;captureState.before?.(captureState.targetCaptures);}return JSON.parse(JSON.stringify(await capture(...args)));}finally{nativeDepth--;}};f.special.native.capturePreserved=f.special.native.capture;
 const treeSource=fs.readFileSync(p.join(__dirname,'reader-src/01aa-work-data-tree.js'),'utf8');vm.runInContext(treeSource+';this.PortableTargetTree=WorkDataTree;',f.special.context);
 const profile={profile:'bounded-native-v1',capturePreserved:(...args)=>f.special.native.capturePreserved(...args)},issued=[];
 const ownerFactory=options=>{const owner=f.special.api.hooks.createBackupOwner({...options,native:f.special.native,ownership:sourceLease,assertExclusive:value=>leases.has(value),assertExclusiveSync:value=>leases.has(value),preservedRead:profile});issued.push(owner);return owner;};
 const host=f.api.WorkDataFullSnapshot.create({base:f.base,ownership:sourceLease,assertExclusive:value=>leases.has(value),assertExclusiveSync:value=>leases.has(value),preservedRead:profile,protector:f.protector,externalOwner:options=>f.api.ExternalBotCredentials.create(options),skillBackupOwner:ownerFactory,maintenanceResultOwner:f.api.WorkDataMaintenanceResult});
 const old={stream:fs.createReadStream,read:fsp.readFile,open:fsp.open};let count=10000;
 const bump=(file,kind)=>{if(nativeDepth||typeof file!=='string'||!p.resolve(file).startsWith(target+p.sep)||!/(?:^|[\\/])(?:archive|intent)$/.test(file)||!fs.existsSync(file))return;const id=f.special.nativeId(file),metadata=f.special.metadata.get(id);if(metadata){metadata.times[1]=String(++count);events.push({file,kind,id});}};
 function installReadEffects(){fs.createReadStream=function(file,...args){bump(file,'createReadStream');return old.stream.call(this,file,...args);};fsp.readFile=async function(file,...args){bump(file,'readFile');return old.read.call(this,file,...args);};fsp.open=async function(file,flags,...args){if(flags==='r')bump(file,'open');return old.open.call(this,file,flags,...args);};}
 function restoreReadEffects(){fs.createReadStream=old.stream;fsp.readFile=old.read;fsp.open=old.open;}
 t.after(restoreReadEffects);return{f,host,target,targetLease,sourceLease,leases,events,captureState,issued,installReadEffects,restoreReadEffects};}
module.exports={setup};


