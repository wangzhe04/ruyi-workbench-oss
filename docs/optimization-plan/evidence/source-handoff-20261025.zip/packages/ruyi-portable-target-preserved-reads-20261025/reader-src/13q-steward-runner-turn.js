// ============================================================================
// 第 117 波 T2(32 号文 §5「13h-steward-runner.js 2522 行」):管家的回合入口、到访、递话通道与 acts 落定。
//
// 落点(transport 层,manifest 中位于 13p-steward-runner-actions.js 之后、13h-steward-runner.js 之前)。
// T2 拆分:原 13h-steward-runner.js 已 2522 行 —— 比 T1 拆之前的 13g 还长,而 31 号文七轴的
// 回合层改动(污染打标、代答/代批、通知)全要往它里面加。按「谁被谁引用」把它拆成六个
// 文件,拼接顺序即依赖方向,零新增前向边:
//   · 13m-steward-runner-base.js —— 六个文件都要用的共享面:落盘面常量、回合层数值口径、
//     自理动作与到访摘要的文本表、可由 actions 执行的写工具白名单、运行时内存态
//     stewardRunnerRuntime、停机/唤醒/中止,以及管家会话单例(引擎解析 + 懒创建);
//   · 13n-steward-arbiter.js —— 116h 线程间仲裁(并发位 / 同 cwd 写锁 / 预算 / 可解释的排队 / 饥饿提升)。
//     它排在提示词之前,因为总览行与递话通道都要读它的等待原因(stewardArbiterWait);
//   · 13o-steward-runner-prompt.js —— 提示词装配(记忆块 / 线程摘要 / 递话预判 / 总览 /
//     两个分叉入口)与 {say,acts,actions,why} 输出契约解析;
//   · 13p-steward-runner-actions.js —— actions 执行与降级、116-2b 确定性自理动作、id 人话化、
//     熔断、收件箱消息装配、输入区预判归一;
//   · 13q-steward-runner-turn.js —— 回合入口 runStewardTurn、收件箱去抖驱动、到访与归档、
//     117l D2 递话通道、117l D7 线程分档落盘、acts 落定;
//   · 13h-steward-runner.js —— 两个「够不着才落在这里」的工具实现(thread_prioritize /
//     thread_stop)、三条路由、运行器状态与 StewardHooks 注册表(排在最后:注册表要引用
//     上面五个文件里的实现,排在后面才是后向边)。
// 本次拆分是【纯搬家】:所有函数体逐字节不变,新写的只有各文件的头部注释。
//
// 依赖纪律(§11.3「不得新增前向边」):本文件只引用拼接顺序在它之前的模块符号
// (00/01/02/04/06b/06i/08/09/10/13e/13g 族 …),全部后向边;它自己的符号只被排在它之后的
// 管家运行器族文件与 14-main.js 的 e2e 导出面引用,同样是后向边。
// ============================================================================
// 单管家并发 1 + 用户抢占(§11.3):
//   · 用户回合到达时,在途的【收件箱】回合被就地取消(停回合 + 该批事件重排到队列尾),用户永远优先;
//   · 收件箱回合到达时若有任何在途回合,事件回排队列、本次不跑(去抖定时器会再来一次);
//   · 用户回合撞用户回合:排队等前一个收尾(不取消 —— 用户自己的两句话都要答)。
// 128f-⑪:已经报过「留给你」的权限请求 id(每条只报一次;有界,超过 512 条先进先出)。
const stewardDeferredNotified = new Set();
// 2026-10(用户拍板「管家常常只说留给你、不表态 —— 加强」):已经追问过一次的权限请求 id(每条最多追问一次;有界同上)。
const stewardDecideNudged = new Set();
// hunt2-steward ①:排队等槽位的用户回合(到达先后;只有排头能认领。见 runStewardTurn 的等待循环)。
const stewardUserWaiters = [];
async function runStewardTurn(input) {
  if (typeof WorkDataMaintenanceHooks !== 'undefined' && WorkDataMaintenanceHooks.run && !WorkDataMaintenanceHooks.entered('steward-turn')) return WorkDataMaintenanceHooks.run('steward-turn', () => runStewardTurn(...arguments));
  const generation = stewardRunnerRuntime.conversationGeneration;
  const opts = (input && typeof input === 'object') ? input : {};
  const trigger = opts.trigger === 'external' ? 'external' : opts.trigger === 'inbox' ? 'inbox' : 'user';
  let externalSource = null;
  if (trigger === 'external') {
    try { externalSource = (await stewardAuthorizeExternalContext({ trigger, externalActor: opts.externalActor })).externalSource; }
    catch { return stewardFail('external_channel.control_revoked', 'external owner authorization was revoked'); }
  }
  const onEvent = typeof opts.onEvent === 'function' ? opts.onEvent : () => {};
  const events = Array.isArray(opts.events) ? opts.events : [];
  const config = await readConfig().catch(() => ({}));
  if (config.stewardEnabledV1 !== true) return stewardFail('steward.disabled', 'the workbench steward is disabled (stewardEnabledV1=false)');

  if (generation !== stewardRunnerRuntime.conversationGeneration || stewardRunnerRuntime.inflight?.kind === 'reset') {
    if (trigger === 'inbox') stewardRunnerRuntime.queue.push(...events);
    return stewardFail('steward.cancelled', '已开始新对话，这句没有送入新上下文');
  }
  const circuit = await stewardCircuitCheck(config, trigger);
  if (generation !== stewardRunnerRuntime.conversationGeneration) {
    if (trigger === 'inbox') stewardRunnerRuntime.queue.push(...events);
    return stewardFail('steward.cancelled', '已开始新对话，这句没有送入新上下文');
  }
  if (circuit) {
    if (trigger === 'inbox' && events.length) stewardRunnerRuntime.queue.push(...events);
    stewardRunnerRuntime.circuit = { ...circuit, at: nowIso() };
    const reply = { trigger, say: circuit.detail, why: '熔断', acts: [], actions: [], parsed: false, circuit };
    stewardRunnerRuntime.lastReply = { ...reply, at: nowIso() };
    logEvent({ kind: 'steward_circuit', circuit: circuit.kind, trigger });
    return { ok: false, circuit, ...reply };
  }

  // 117l D3(§11.9):本次回合的登记项在入口就造好(含一个占位 promise)—— 等待循环退出
  // 之后必须【同步】认领 stewardRunnerRuntime.inflight,中间不能有 await:两个等待者否则会在同一
  // 微任务里一起冲出去,各自开一个回合。占位 promise 在本函数真正返回时才 resolve —— 于是
  // 等在后面的那一句话不仅等到回合跑完,还等到 stewardStampReply 把结构化结果盖完章。
  const controller = typeof AbortController === 'function' ? new AbortController() : null;
  const entry = { kind: trigger, controller, cancelled: '', events, promise: null, routeHint: await stewardNormalizeRouteHint(opts.routeHint),
    ...(trigger === 'external' ? { externalActor: opts.externalActor, externalSource } : {}) };
  let finishEntry = () => {};
  entry.promise = new Promise(resolve => { finishEntry = () => resolve(); });

  if (generation !== stewardRunnerRuntime.conversationGeneration || stewardRunnerRuntime.inflight?.kind === 'reset') {
    if (trigger === 'inbox') stewardRunnerRuntime.queue.push(...events);
    return stewardFail('steward.cancelled', '已开始新对话，这句没有送入新上下文');
  }
  if (trigger === 'external') {
    try { entry.externalSource = (await stewardAuthorizeExternalContext({ trigger, externalActor: entry.externalActor })).externalSource; }
    catch { return stewardFail('external_channel.control_revoked', 'external owner authorization was revoked'); }
    if (generation !== stewardRunnerRuntime.conversationGeneration) return stewardFail('steward.cancelled', 'conversation changed');
  }
  const inflight = stewardRunnerRuntime.inflight;
  if (trigger === 'inbox' && (inflight || stewardUserWaiters.length)) {
    // 有在途回合,或有用户的话正排着队(槽位刚空、它还没醒过来认领):收件箱批次回排,不插队。
    stewardRunnerRuntime.queue.push(...events);
    return stewardFail('steward.busy', 'a steward turn is already in flight; the inbox batch was re-queued');
  }
  if (inflight || stewardUserWaiters.length) {
    // 无论取消与否都等在途那个收尾:管家会话同一时刻只能有一个回合在写它的正文。
    //
    // 117l D3(§11.9;用户第四轮走查第 6 条):修前这里是【一发】 Promise.race(15s),之后不复查
    // stewardRunnerRuntime.inflight —— 一个跑了 16 秒还在写正文的回合会被这条路径直接放行,于是
    // 第二句用户的话带着另一个回合同时开跑,两个回合抢同一份 session.messages(后写者赢),用户
    // 看到的就是「输出完了还说在忙上一件」和一条被吞掉的回复。
    // 修法:循环等到轮到自己,总上限 5 分钟。真等过才记一条审计。
    //
    // hunt2-steward ①:修前循环条件是「inflight 仍是【进门时看到的】那一个」—— 两句用户的话排在同一个
    // 在途回合后面时,它一收尾,先醒的那句同步认领了槽位,后醒的那句一看「已经不是我等的那个了」也冲了
    // 出去,两个回合同时开跑,后开的把先开的 superseded 掉(一句话被吞)。现在:
    //   · 每一圈都【重读】槽位,只要里面还有别人就接着等;
    //   · 排队的用户回合按到达先后排成一列(stewardUserWaiters),只有排头能认领 —— 用户说的两句话
    //     按他说的顺序答,不看谁的定时器先醒;
    //   · 槽位里若换成了一个收件箱回合(理论上上面的入口已拦住,兜底),照「用户永远优先」抢占它。
    // 退出循环之后到认领之间仍然没有 await。
    stewardUserWaiters.push(entry);
    const waitStartedAt = Date.now();
    let waitedFor = inflight ? inflight.kind : 'user';
    try {
      for (;;) {
        if (generation !== stewardRunnerRuntime.conversationGeneration) return stewardFail('steward.cancelled', '已开始新对话，排队消息已取消');
        if (trigger === 'external') {
          try { entry.externalSource = (await stewardAuthorizeExternalContext({ trigger, externalActor: entry.externalActor })).externalSource; }
          catch { return stewardFail('external_channel.control_revoked', 'external owner authorization was revoked'); }
          if (generation !== stewardRunnerRuntime.conversationGeneration) return stewardFail('steward.cancelled', 'conversation changed');
        }
        const current = stewardRunnerRuntime.inflight;
        // Authorization awaited disk IO. Read the slot and FIFO after it, then claim without another await.
        if (!current && stewardUserWaiters[0] === entry) break;
        const target = current || stewardUserWaiters[0];
        waitedFor = target.kind;
        if (current && current.kind === 'inbox' && !current.cancelled) {
          current.cancelled = 'preempted';
          stewardRunnerRuntime.queue.push(...(current.events || []));   // 事件不丢:重排到下一轮
          stewardAbortInflight(current);
          logEvent({ kind: 'steward_preempt', preempted: 'inbox', requeued: (current.events || []).length });
        }
        if (Date.now() - waitStartedAt >= STEWARD_USER_QUEUE_WAIT_MS) {
          logEvent({ kind: 'steward_user_turn_timeout', waitedMs: Date.now() - waitStartedAt, waitedFor });
          return stewardFail('steward.busy', `上一件还没写完(已经等了 ${Math.round((Date.now() - waitStartedAt) / 1000)} 秒),先看看它是不是卡住了`, { trigger, waitedMs: Date.now() - waitStartedAt });
        }
        await Promise.race([
          (target.promise || Promise.resolve()).catch(() => {}),
          new Promise(resolve => { const t = setTimeout(resolve, 200); if (t && t.unref) t.unref(); }),
        ]);
      }
    } finally {
      // 认领或超时都出列(同步,与下面的认领之间没有 await)。
      const at = stewardUserWaiters.indexOf(entry);
      if (at >= 0) stewardUserWaiters.splice(at, 1);
    }
    const waitedMs = Date.now() - waitStartedAt;
    // 「真等过」才记账:抢占一个收件箱回合通常是毫秒级,那不该在审计里刷屏。
    if (waitedMs > 0) logEvent({ kind: 'steward_user_turn_queued', waitedMs, waitedFor, trigger });
  }

  stewardRunnerRuntime.inflight = entry;   // 同步认领(与上面的 while 判定之间没有 await)
  try {
    return await stewardRunClaimedTurn(trigger, opts, config, entry, controller, onEvent, events);
  } finally {
    if (stewardRunnerRuntime.inflight === entry) stewardRunnerRuntime.inflight = null;
    finishEntry();
  }
}

// 123-N1 ①:本回合落盘的那条助手消息的 createdAt(回执带给前端当水位用,见 stewardRunClaimedTurn
// 里的调用点)。形状照抄同族的 stewardLastAssistantContent —— 同一条消息、同一个找法(从尾往前
// 找第一条 assistant),只是取的字段不同;读不到会话、没有助手消息、字段缺失都回空串,调用方据此
// 退到「对齐一发」的老路。代价是每回合多一次会话读:stewardLastAssistantContent 在 13p、本刀不碰
// 它(硬纪律的独占文件表),合并成一次读是主会话的活,登记为一笔小债。
async function stewardLastAssistantCreatedAt() {
  const session = await loadSession(STEWARD_SESSION_ID).catch(() => null);
  if (!session) return '';
  const messages = Array.isArray(session.messages) ? session.messages : [];
  for (let i = messages.length - 1; i >= 0; i--) {
    if (messages[i] && messages[i].role === 'assistant') return String(messages[i].createdAt || '');
  }
  return '';
}

// 127 波 2-quater B2(45 号文 §2-quater.1 取证 6 / §2-quater.2「确定性回执」):管家回合里模型【直调】
// steward_decide 代批了一条永久豁免命令,修前回执(executed)只收自理行与结构化 actions —— 代批了,用户却
// 不一定知道(要看模型自己在 say 里提不提)。这里把本回合管家助手消息的 toolCalls 扫一遍:成功、且结果上
// 带 13l 的 exemptDelegation 标记的 steward_decide,每条补一行回执,与结构化 actions 那一行同形
// ({tool,label,args,result}),前端 appendActionReceipts 照常画成「已办:…」灰字、落盘的章也带着它。
// 纯函数与装载分开:合并规则(去重)单测可直接喂数组。
// 去重键 = interventionId:同一条待决只会被成功代批一次(第二次核心层回 already_terminal),
// 所以「executed 里已经有一行成功的代批」就不再补 —— 结构化 actions 与工具直调撞在同一条上时只留一行。
function stewardDelegationReceiptLabel(result, title) {
  const labels = (result && result.exemptDelegation && Array.isArray(result.exemptDelegation.labels))
    ? result.exemptDelegation.labels.map(stewardSanitizeText).filter(Boolean) : [];
  const kinds = labels.length ? `「${labels.join('」「')}」` : '';
  const where = title ? ` · 线程「${stewardSanitizeText(title).slice(0, 24)}」` : '';
  return `代批${kinds}${where}`;
}
function stewardMergeDelegationReceipts(executedRows, delegationToolCalls, titleOf) {
  const rows = Array.isArray(executedRows) ? executedRows : [];
  const delegatedId = row => {
    const r = row && row.result;
    if (!row || row.tool !== 'steward_decide' || !r || r.ok !== true || !r.exemptDelegation) return '';
    return String((row.args && row.args.interventionId) || '');
  };
  const seen = new Set(rows.map(delegatedId).filter(Boolean));
  const extra = [];
  for (const call of (Array.isArray(delegationToolCalls) ? delegationToolCalls : [])) {
    if (!call || String(call.name || '') !== 'steward_decide') continue;
    const args = (call.input && typeof call.input === 'object' && !Array.isArray(call.input)) ? call.input : {};
    const row = { tool: 'steward_decide', label: '', args, result: call.result };
    const id = delegatedId(row);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    const sid = safeSessionId(args.missionId || args.sessionId);
    row.label = stewardDelegationReceiptLabel(call.result, typeof titleOf === 'function' ? titleOf(sid) : '');
    extra.push(row);
  }
  return extra;
}
async function stewardDelegationToolCalls(turnSeq, includeActions = false) {
  const want = Math.max(0, Number(turnSeq) || 0);
  if (!want) return [];
  const session = await loadSession(STEWARD_SESSION_ID).catch(() => null);
  const messages = Array.isArray(session && session.messages) ? session.messages : [];
  const out = [];
  for (const m of messages) {
    if (!m || m.role !== 'assistant' || Number(m.turnSeq) !== want || !Array.isArray(m.toolCalls)) continue;
    for (const call of m.toolCalls) {
      if (call && ((includeActions && (STEWARD_ACTION_HOOKS[call.name] || call.name === 'steward_bot_setup')) ||
        (call.name === 'steward_decide' && call.result && call.result.ok === true && call.result.exemptDelegation))) out.push(call);
    }
  }
  return out;
}

// 117l D3:认领之后的回合本体。抽出来只为让「同步认领 -> try/finally 释放」这条纪律
// 一目了然:释放必须盖住【全部】退出路径 —— 含 stewardStampReply 之后那一段。修前它跑在
// inflight 已经清空之后,第二句用户的话于是能在正文还没盖章时插进来。
async function stewardRunClaimedTurn(trigger, opts, config, entry, controller, onEvent, events) {
  const ensured = await ensureStewardSession(config);
  if (!ensured.ok) {
    if (trigger === 'inbox') stewardRequeueFailedInboxBatch(events, 'engine_unavailable');
    return stewardFail(ensured.error, ensured.message || 'steward engine is unsupported', { engine: ensured.engine });
  }
  const session = ensured.session;
  // 116-2b:自理动作【先于模型】跑。它是确定性处置(见 stewardSelfServeInbox 的头注),结果作为
  // 收件箱事件的补充信息进回合层 —— 模型只需要说,不必再决定。用户回合不走这里:用户就在跟前,
  // 他这一句话本身就是指令,轮不到管家替他主动做什么(§3.3「没在说话时才叫主动」)。
  const selfServe = trigger === 'inbox' && events.length
    ? await stewardSelfServeInbox(events, session, config)
    : { executed: [], notes: [] };
  const message = trigger === 'inbox' ? await stewardInboxMessage(events, config, selfServe.notes) : String(opts.message == null ? '' : opts.message);
  if (!message.trim()) return stewardFail('invalid_request', 'message is required');
  if (trigger === 'external') {
    try { entry.externalSource = (await stewardAuthorizeExternalContext({ trigger, externalActor: entry.externalActor })).externalSource; }
    catch { return stewardFail('external_channel.control_revoked', 'external owner authorization was revoked'); }
  }

  if (!stewardRunnerRuntime.visit.startedAt) stewardRunnerRuntime.visit.startedAt = nowIso();
  stewardRunnerRuntime.visit.lastActivityAt = nowIso();
  stewardRunnerRuntime.turns.push(Date.now());

  const run = (async () => {
    try {
      return await runSessionTurn({
        sessionId: session.id,
        message,
        // 133e:用户在管家输入框里附的文件(只有 trigger:'user' 才可能有;收件箱回合没有)
        attachments: (trigger === 'user' && Array.isArray(opts.attachments)) ? opts.attachments : [],
        cwd: session.cwd,
        source: 'steward',
        engineRoute: ensured.route,
        // 收件箱回合的这条 user 消息【不是用户本人说的话】:origin 随会话正文落盘,
        // steward_memory_write 的来源校验据此确定性拒绝它(13g stewardSourceIsUserMessage)。
        messageMeta: trigger === 'inbox' ? { origin: 'inbox', inboxSeqs: events.map(e => Number(e && e.inboxSeq) || 0).slice(0, STEWARD_INBOX_EVENTS_PER_TURN) }
          : trigger === 'external' ? { origin: 'external-owner', externalSource: entry.externalSource } : null,
        requestMeta: { steward: true, trigger, ...(trigger === 'external' ? { external: entry.externalSource } : {}) },
        onEvent,
        signal: controller ? controller.signal : null,
      });
    } catch (error) {
      return { ok: false, error: String((error && error.message) || error) };
    }
  })();
  entry.run = run;
  const turn = await run;
  stewardRunnerRuntime.visit.lastActivityAt = nowIso();
  // 127 波 2-quater B2:回合里工具直调的代批(见 stewardMergeDelegationReceipts 头注)在三条出口【之前】取出来 ——
  // 回合被抢占 / 失败时,已经落定的代批照样是真的发生了,回执不能跟着回合一起丢。取不到回合号(回合整个抛出)
  // 就是空表。没有代批时三条出口的信封与修前逐字节相同。
  const turnToolCalls = await stewardDelegationToolCalls(turn && turn.turnSeq, true);
  // 设置直调也须出现在可见回执和历史章里，不能只留在折叠的工具轨迹中。
  const settingReceipts = turnToolCalls.filter(call => call.name === 'steward_config_set' && call.result?.error !== 'propose_required')
    .map(call => ({ tool: call.name, args: call.input?.privacy ? { privacy: true } : call.input || {}, label: STEWARD_TOOL_LABELS[call.name],
      result: call.result?.status === 'pending' && turn?.privacySettings ? { ...turn.privacySettings,
        receipt: { kind: 'settings', object: 'ruyi', changes: [{ key: 'privacyModeV1', value: turn.privacySettings.mode, scope: 'application', effective: 'next_turn' }] } } : call.result }));
  const externalToolFacts = trigger === 'external' ? {
    toolFailures: Math.min(100, turnToolCalls.filter(call => call.result?.ok === false && call.result.error !== 'propose_required').length),
    toolProposals: Math.min(100, turnToolCalls.filter(call => call.result?.ok === false && call.result.error === 'propose_required').length),
  } : {};
  const delegationCalls = turnToolCalls.filter(call => call.name === 'steward_decide' && call.result?.ok === true && call.result.exemptDelegation);
  const delegationTitles = new Map();
  for (const call of delegationCalls) {
    const sid = safeSessionId(call && call.input && (call.input.missionId || call.input.sessionId));
    if (!sid || delegationTitles.has(sid)) continue;
    const delegatedHead = await stewardReadSessionHead(sid).catch(() => null);
    delegationTitles.set(sid, delegatedHead ? String(delegatedHead.title || '') : '');
  }
  const delegationTitleOf = sid => delegationTitles.get(sid) || '';

  if (entry.cancelled) {
    logEvent({ kind: 'steward_turn_cancelled', reason: entry.cancelled, trigger });
    const cancelledReceipts = settingReceipts.concat(stewardMergeDelegationReceipts(selfServe.executed, delegationCalls, delegationTitleOf));
    return stewardFail('steward.cancelled', `steward turn cancelled: ${entry.cancelled}`, { trigger, ...(cancelledReceipts.length ? { actions: cancelledReceipts } : {}) });
  }

  // 回合本身失败(端点不通/被停/装载抛错)时【不能】去读「最后一条助手消息」—— 那是【上一个】回合
  // 的话,拿它当本回合的回答就是把旧答复冒充成新答复。如实回一条稳定信封,say 留给界面说人话。
  // hunt2-steward ③:成败还要看【内层】 result.ok(与 13k stewardRecordLaunchOutcome 同一口径)——
  // 端点回 HTTP 500 时 runSessionTurn 外层照样 ok:true(「这次调用完成了」),修前据此把一个失败回合
  // 当成功解析,say 为空、收件箱那一批事件已经从队列里拿走,就此蒸发。
  const turnInner = (turn && turn.result && typeof turn.result === 'object') ? turn.result : null;
  if (turn && (turn.ok === false || (turnInner && turnInner.ok === false))) {
    const detail = String(turn.error || (turnInner && (turnInner.error || turnInner.errorClass)) || '').slice(0, 300);
    logEvent({ kind: 'steward_turn_failed', trigger, error: detail });
    if (trigger === 'inbox') stewardRequeueFailedInboxBatch(events, 'turn_failed');
    // 自理动作已经真的发生了,回合失败不能把它们吞掉 —— 如实带回去(界面与 /api/steward/state 都能看到)。
    return stewardFail('steward.turn_failed', detail || 'the steward turn did not complete', { trigger, ...externalToolFacts, stopped: !!turn.stopped, actions: selfServe.executed.concat(settingReceipts, stewardMergeDelegationReceipts(selfServe.executed, delegationCalls, delegationTitleOf)) });
  }
  const finalText = await stewardLastAssistantContent();
  // 123-N1 ①(34 号文;用户 2026-09-13 真机走查「同一段对话出现两遍」):回执带上【本回合落盘的
  // 那条助手消息的 createdAt】。前端 finishReply 拿它推 appendSince 的水位 —— 修前水位只在
  // 「进壳画历史」那一处推高,用户自己发的回合直接上屏、从不推水位,于是下一条收件箱回合到达时
  // 壳层按旧水位重拉增量,把屏上已有的回合又画了一遍。
  // 取的是【同一条消息】的字段:stewardStampReply 盖章盖在「最后一条助手消息」上,这里读的也是
  // 它(盖章只写 .steward,不动 createdAt,所以先读后盖、先盖后读拿到的是同一个值)。用户那条消息
  // 的 createdAt 更早,水位推到助手这条即把两条一起盖住。
  const stampedAt = await stewardLastAssistantCreatedAt();
  let parsedReply = stewardParseReply(finalText);
  // 135:整段解析失败时退到【最后一段文字】再解析一次(见 13p stewardLastAssistantFinalSegment 头注)——
  // 工具调用之前那些边做边说的过程话不再和答复一起上屏。没有多段就是同一个结果,不另起一套兜底。
  if (!parsedReply.parsed) {
    const finalSegment = await stewardLastAssistantFinalSegment();
    if (finalSegment.trim()) parsedReply = stewardParseReply(finalSegment);
  }
  // 123-P1 ①(38 号文;用户 2026-09-14 真机取证):契约不完整 —— 模型没给必填的 why(判据与理由见
  // 13o stewardParseReply 那一段头注)。这里做两件事:记一条审计(trigger / 模型给了哪些键 / say
  // 有多长,正文一个字不进日志),以及往下把旗子带进回执与落盘的章 —— 前端据此在这条回复下面画
  // 一句灰字系统回执,明说「这一轮它没有执行任何动作」。
  // **诚实优先,不重试**:在同一回合里用一条纠正提示重跑一次模型这个方案评估过,不做 ——
  // 它必然动到回合语义的四处:① 第二发 runSessionTurn 会往管家会话里【真的】写一条 user 消息
  // (纠正提示)和第二条 assistant 消息,对话流回放时那条纠正提示会当成用户气泡上屏;
  // ② stewardRunnerRuntime.turns 与用量台账要么漏记(一次模型调用逃过每小时熔断与日费用)、
  // 要么多记(用户看到「一句话花了两个回合」);③ 抢占:重试把 inflight 的占用窗口拉长一倍,
  // 用户回合抢占一个收件箱回合的时序随之改变(controller 只有一个,abort 落在哪一发也要重新定义);
  // ④ stewardLastAssistantCreatedAt / turnSeq 取的是「最后一条助手消息」,重试后它指向第二发。
  // 派单稿的原话是「如果会动到回合循环、预算、熔断或抢占的语义,就不做」—— 四条全中,故登记为
  // 后续(要做得先给重试一条【不写会话正文】的旁路通道,那是 09-workflow 的地界)。
  if (parsedReply.contractIncomplete === true) {
    logEvent({
      kind: 'steward_contract_incomplete',
      trigger,
      keys: Array.isArray(parsedReply.contractKeys) ? parsedReply.contractKeys : [],
      sayChars: String(parsedReply.say || '').length,
    });
  }
  // 自理动作排在模型 actions 【前面】:它们先发生,steward_reply.actions 的顺序就该是事情发生的
  // 顺序。两者同形,故 stewardDowngradeActions 一视同仁 —— 自理侧被闸门拦下的行(propose_required)
  // 与模型侧被 13g 拦下的行走同一条降级路径,变成一个按钮。
  // 116-3 P2-11:自理侧【真的动过】的目标带进 actions 侧,两边合起来数同一个 3 —— 不是各数各的。
  const selfServeTargets = selfServe.executed.filter(row => row && row.acted === true).map(row => row.sessionId);
  // 3.0 收口走查(第四波):actions 是【这一回合】的动作,闸门与配额 / 污点按回合序号取键(13j stewardTaintKeyOf → providerTurnQuotaKey)。
  // 修前传的是回合开始前 ensureStewardSession 装载的那份会话对象,turnSeq 还停在上一回合 —— 同一回合里读过网页打下的污点(键 t N)
  // 在这里查成 t(N-1):查不到本回合的,反而可能查到上一回合的。按本回合的序号给一份浅拷贝(只用作 ctx,不落盘)。
  const actionSession = (turn && Number(turn.turnSeq) > 0) ? { ...session, turnSeq: Number(turn.turnSeq) } : session;
  const actionRows = parsedReply.actions.length
    ? await stewardExecuteActions(parsedReply.actions, actionSession, config, trigger, selfServeTargets, entry.externalActor)
    : [];
  // 127 波 2-quater B2:回合里工具直调的代批补进回执(上面已取出)。顺序按事情发生的先后:自理(模型之前)→
  // 回合里的工具调用 → 回合结束后执行的结构化 actions。没有代批时 delegationRows 为空,executed 与修前逐元素相同。
  const delegationRows = stewardMergeDelegationReceipts(selfServe.executed.concat(actionRows), delegationCalls, delegationTitleOf);
  const executed = selfServe.executed.concat(settingReceipts, delegationRows, actionRows);
  // Direct tool calls happen before the final JSON reply too. Their receipts
  // must invalidate duplicate buttons just like the structured actions do.
  const directReceipts = turnToolCalls.map(call => ({ tool: call.name, args: call.input || {}, result: call.result }));
  const acts = stewardDowngradeActions(executed, parsedReply.acts, directReceipts);
  if (trigger === 'user') {
    const prepared = turnToolCalls.find(call => call.name === 'steward_bot_setup' && call.input?.op === 'prepare'
      && call.result?.ok === true && call.result.prepared === true && /^[a-z][a-z0-9_-]{0,63}$/.test(call.result.connectionId));
    if (prepared) {
      if (acts.length >= STEWARD_ACTS_MAX) acts.pop();
      acts.push({ kind: 'external_bot_setup', connectionId: prepared.result.connectionId, label: '继续配置机器人' });
    }
  }
  // 117l D5:say/why 在【这里】过一遍人话化 —— 于是 steward_reply 帧、落盘的 meta、/api/steward/state
  // 的 lastReply 三处拿到的是【同一份】文字(修前 ※ 里满是 sess_/question_)。acts/actions 不动。
  const say = await stewardHumanizeSay(parsedReply.say);
  const why = await stewardHumanizeSay(parsedReply.why);
  const reply = {
    trigger,
    ...externalToolFacts,
    say,
    why,
    acts,
    actions: executed,
    parsed: parsedReply.parsed,
    turnSeq: Number(turn && turn.turnSeq) || 0,
    sessionId: session.id,
    // 123-N1 ①:落盘时刻(ISO 8601 定长 UTC 串,与 GET /api/sessions/steward?since= 同一把尺)。
    // 读不到就不下发这个键 —— 前端缺省时自己走「对齐一发」的退路,老回执逐字节不变。
    ...(stampedAt ? { createdAt: stampedAt } : {}),
    // 123-P1 ①:【缺省不写】。老回合的落盘章里读不到这个键即为 false,前端 `=== true` 判定,
    // 一份历史都不用迁移。
    ...(parsedReply.contractIncomplete === true ? { contractIncomplete: true } : {}),
    circuit: null,
  };
  // 117s-H4:落盘的回执带来源(对象);reply.trigger(内存态 lastReply 与 steward_reply 帧)仍是字符串。
  await stewardStampReply({
    say: reply.say, why: reply.why, acts: reply.acts, actions: reply.actions, parsed: reply.parsed,
    // 123-P1 ①:落盘的章也带这一面 —— 回放那条路(前端 renderHistorySince)只看得到这份章,
    // live 与刷新之后看到的必须是同一句话。同样缺省不写。
    ...(reply.contractIncomplete === true ? { contractIncomplete: true } : {}),
    trigger: await stewardTriggerStamp(trigger, events).catch(() => ({ kind: trigger })),
  });
  // 121-K2a(§6.1 第 3 条):管家刚说完一句并落了盘。**正文不进事件**(§6.1 红线;避免双写)——
  // 前端收到这一帧再去拉一次消息面,拉到的与落盘的是同一份。
  RUYI_EVENTS.emit('steward.say', { turnSeq: reply.turnSeq, trigger: String(trigger || '') });
  // 128f-⑪(Brief §4.2 第 7 条前半;用户拍板 A「立刻通知你,请求挂 600 秒等你处理」):这一回合看过的权限请求,
  // 回合结束时还挂着 = 管家没替你批、留给你了。真模型实测管家常常【不调】steward_decide、只说一句「留在那儿等你过目」
  // (45 号文 §9.6.5 (b)),所以判据是「还挂着」,不是「调了拒」。每条请求只报一次;窗口已经过了的不报。
  if (trigger === 'inbox') {
    const nudges = [];
    for (const evt of events) {
      const payload = (evt && evt.payload && typeof evt.payload === 'object') ? evt.payload : {};
      if (!evt || evt.kind !== 'needs_you' || payload.interventionType !== 'permission') continue;
      const interventionId = String(payload.interventionId || '');
      const pending = interventionId ? pendingPermissions.get(interventionId) : null;
      if (!pending || stewardDeferredNotified.has(interventionId)) continue;
      if (Number(pending.deadlineAt) && Number(pending.deadlineAt) <= Date.now()) continue;
      // 只报管家【经手】的线程(13k stewardMediatesPermissions;2026-10 起含用户自己开、按智能自动在跑的):
      // 不归管家处理的线程,那条请求的通知是收件箱 needs_you 自己那一路;用户此刻就坐在 / 看着那条线程,也不报(请求是当面弹着的)。
      const sid = String(evt.sessionId || '');
      const head = await stewardReadSessionHead(sid).catch(() => null);
      if (!stewardMediatesPermissions(sid, config, head)) continue;
      // 2026-10 追问:这一回合管家对它【一个态都没表】—— 没调 steward_decide(13l 记着,被工具挡回也算表过态),
      // 也没把它做成按钮交给用户 —— 就先不报「留给你」,把它带一个 nudge 标记排回队头,让下一回合专门表态
      // (13p 给这种行加一句点名要求)。每条最多追问一次:追问那一回合还不表态,照旧报「留给你」。
      const proposed = acts.some(act => act && act.tool === 'steward_decide' && act.args && String(act.args.interventionId || '') === interventionId);
      if (!proposed && !stewardDecideAttempted(interventionId) && !stewardDecideNudged.has(interventionId)) {
        stewardDecideNudged.add(interventionId);
        if (stewardDecideNudged.size > 512) stewardDecideNudged.delete(stewardDecideNudged.values().next().value);
        nudges.push({ ...evt, payload: { ...payload, nudge: true } });
        continue;
      }
      stewardDeferredNotified.add(interventionId);
      if (stewardDeferredNotified.size > 512) stewardDeferredNotified.delete(stewardDeferredNotified.values().next().value);
      RUYI_EVENTS.emit('steward.deferred', {
        sessionId: String(evt.sessionId || ''),
        interventionId,
        ask: String(payload.summary || payload.ask || ''),
        // 不限时的请求没有截止时刻:给空串,前端就说「留给你」而不是「还等你 35000 分钟」。
        deadlineAt: promptDeadlineIsReal(pending.deadlineAt) ? new Date(Number(pending.deadlineAt)).toISOString() : '',
      });
    }
    // 追问排回队头:收件箱排空器在本回合结束后自己接着排(权限待决走 1 s 去抖,见 stewardInboxDebounceMs)。
    if (nudges.length && !stewardRunnerRuntime.stopped) {
      stewardRunnerRuntime.queue.unshift(...nudges);
      logEvent({ kind: 'steward_decide_nudge', count: nudges.length });
    }
  }

  // 无进展熔断的计数:只看收件箱回合(用户回合永远清零 —— 用户说话就是进展)。
  if (trigger === 'inbox') {
    if (!acts.length && !executed.length) stewardRunnerRuntime.noProgress += 1;
    else stewardRunnerRuntime.noProgress = 0;
  } else {
    stewardRunnerRuntime.noProgress = 0;
    // 116-3 P1-10:用户回合收尾时顺带把积压的收件箱事件排上 —— 用户说话解除退避,却不带走队列里
    // 那些没人处理的事件,是修前那个「积压永久停滞」的另一半。
    stewardScheduleInboxDrain();
  }
  // 116-2e(§11.1 第 2 项「速查线程自动收工」):速查线程的 done 事件【已经进过这一回合】之后才
  // 收工 —— 顺序不能反。先收工的话总览与搜索里就没这条了,管家转述答案时会发现自己刚读到的那条
  // 线程凭空消失。收工只写会话头上的 stewardQuick.closedAt,不动正文、不进事项、不改执行语义。
  if (trigger === 'inbox' && typeof StewardHooks.quickClose === 'function') {
    for (const evt of events) {
      if (!evt || evt.kind !== 'done') continue;
      if (!(evt.payload && evt.payload.quick === true)) continue;
      try { await StewardHooks.quickClose(evt.sessionId); } catch { /* 旁路:收工失败不影响这一回合 */ }
    }
  }
  stewardRunnerRuntime.lastReply = { ...reply, at: nowIso() };
  return { ok: true, ...reply };
}

// ────────────────────────────────────────────────────────────────────────────
// 收件箱驱动:116b 每轮写完箱子调 onInboxBatch,这里做 5 秒去抖后起一个收件箱回合。
// ────────────────────────────────────────────────────────────────────────────
// hunt2-steward ③:收件箱回合失败(端点不通 / 引擎不可用)时这一批事件回到队列【头部】,下一次排空
// 先处理它们。失败按指数退避、最长一分钟重判，不再因端点暂时不可用三次就丢掉监工机会。
const stewardInboxRetryCounts = new WeakMap();
function stewardRequeueFailedInboxBatch(events, reason) {
  if (stewardRunnerRuntime.stopped) return;
  const keep = [];
  for (const evt of (Array.isArray(events) ? events : [])) {
    if (!evt || typeof evt !== 'object') continue;
    const tries = Math.min(6, (stewardInboxRetryCounts.get(evt) || 0) + 1);
    stewardInboxRetryCounts.set(evt, tries);
    if (!stewardRunnerRuntime.queue.includes(evt)) keep.push(evt);
  }
  if (keep.length) stewardRunnerRuntime.queue.unshift(...keep);
  logEvent({ kind: 'steward_inbox_requeued', reason: String(reason || ''), requeued: keep.length, dropped: 0 });
}
function stewardInboxRetryDelay(events) {
  const tries = Math.max(0, ...(Array.isArray(events) ? events : []).map(evt => stewardInboxRetryCounts.get(evt) || 0));
  return tries ? Math.min(60000, 1000 * 2 ** tries) : 0;
}
// 116-3 P1-10:排空是【自持】的。修前只有「轮询器又写了新的一批」才会排一次定时器,于是一次大批量
// 积压超过 30 条之后,只要活动很快安静下来,剩下的条目会一直躺在内存队列里没人处理(而且是纯内存态,
// 进程重启整份丢失);用户来跟管家说话也不会把它清掉。现在:一批处理完队列还有就接着排一个定时器;
// 用户回合结束时也顺带踢一次(用户说话本来就会解除无进展退避,顺手把积压带走)。
// 116-4:队列里有没有「有人正等着的那一句答案」。
function stewardQueueHasQuickAnswer(rows) {
  return (Array.isArray(rows) ? rows : []).some(r => r && r.kind === 'done' && r.payload && r.payload.quick === true);
}
// 2026-10:队列里有没有「线程正卡在上面等」的权限/提问待决(13i 投影出来的那一路:payload 带 interventionId)。
function stewardQueueHasBlockingAsk(rows) {
  return (Array.isArray(rows) ? rows : []).some(r => r && r.payload && r.payload.interventionId
    && (r.payload.interventionType === 'permission' || r.payload.interventionType === 'question'));
}
function stewardInboxDebounceMs(rows) {
  if (stewardQueueHasQuickAnswer(rows)) return STEWARD_QUICK_DEBOUNCE_MS;
  if (stewardQueueHasBlockingAsk(rows)) return STEWARD_BLOCKING_DEBOUNCE_MS;
  return STEWARD_DEBOUNCE_MS;
}
// 2026-10(用户:「用户在看提问、权限,管家被立刻唤醒也不要插手」):起回合之前,把【用户此刻正看着】的那几条待决
// (在场信号 viewing,见 13r / 13i)从这一批里拿出来先扣着 —— 不为它起回合,也就不会去插手。收件箱那一行照常在
// (安静卡、到访摘要都读它),扣的只是「管家处理」这一步。每 STEWARD_VIEW_RECHECK_MS 重判一次:已经结算的作罢;
// 用户不看了(收起弹窗 / 走开一分钟)就排回队头、照常排空。工具层另有一道同判据的门(13k stewardSeatedByUser)。
function stewardViewedPendingStillOpen(evt) {
  const payload = (evt && evt.payload && typeof evt.payload === 'object') ? evt.payload : {};
  if (payload.interventionType === 'permission') return pendingPermissions.has(String(payload.interventionId || ''));
  return stewardPendingStillOpen(evt);
}
function stewardRecheckViewHeld() {
  const held = Array.isArray(stewardRunnerRuntime.viewHeld) ? stewardRunnerRuntime.viewHeld : [];
  const viewing = stewardViewingSessionIds(stewardPresenceRows());
  const keep = [];
  const release = [];
  for (const evt of held) {
    if (!stewardViewedPendingStillOpen(evt)) continue;
    if (viewing.has(String(evt.sessionId || ''))) keep.push(evt); else release.push(evt);
  }
  stewardRunnerRuntime.viewHeld = keep;
  if (!keep.length && stewardRunnerRuntime.viewHeldTimer) {
    clearInterval(stewardRunnerRuntime.viewHeldTimer);
    stewardRunnerRuntime.viewHeldTimer = null;
  }
  if (release.length && !stewardRunnerRuntime.stopped) {
    stewardRunnerRuntime.queue.unshift(...release);
    stewardScheduleInboxDrain();
  }
}
function stewardHoldViewedEvents(batch) {
  const list = Array.isArray(batch) ? batch : [];
  const viewing = stewardViewingSessionIds(stewardPresenceRows());
  if (!viewing.size) return list;
  const run = [];
  for (const evt of list) {
    const key = viewing.has(String((evt && evt.sessionId) || '')) ? stewardPendingKeyOf(evt) : '';
    if (!key) { run.push(evt); continue; }
    if (!stewardRunnerRuntime.viewHeld.some(item => stewardPendingKeyOf(item) === key)) stewardRunnerRuntime.viewHeld.push(evt);
  }
  while (stewardRunnerRuntime.viewHeld.length > STEWARD_VIEW_HELD_MAX) stewardRunnerRuntime.viewHeld.shift();
  if (stewardRunnerRuntime.viewHeld.length && !stewardRunnerRuntime.viewHeldTimer) {
    const timer = setInterval(stewardRecheckViewHeld, STEWARD_VIEW_RECHECK_MS);
    if (timer && typeof timer.unref === 'function') timer.unref();
    stewardRunnerRuntime.viewHeldTimer = timer;
  }
  return run;
}
function stewardScheduleInboxDrain(retryDelayMs = 0) {
  if (stewardRunnerRuntime.inflight?.kind === 'reset') return;
  if (stewardRunnerRuntime.stopped) return;
  if (!stewardRunnerRuntime.queue.length) return;
  // 116-4:去抖时长由【队列内容】决定,不由调用方决定 —— 五个调用点一行都不用改,新语义自动覆盖全部。
  const delay = Math.max(stewardInboxDebounceMs(stewardRunnerRuntime.queue), Number(retryDelayMs) || 0);
  if (stewardRunnerRuntime.debounceTimer) {
    // 已经排着的那个更快或一样快:不动。更慢:重排 —— 否则一条先到的普通通知会把速查答案一起按住 5 秒。
    if (delay >= stewardRunnerRuntime.debounceMs) return;
    clearTimeout(stewardRunnerRuntime.debounceTimer);
    stewardRunnerRuntime.debounceTimer = null;
  }
  stewardRunnerRuntime.debounceMs = delay;
  const timer = setTimeout(() => {
    if (!stewardRunnerRuntime.queue.length) { stewardRunnerRuntime.debounceTimer = null; stewardRunnerRuntime.debounceMs = -1; return; }
    const drain = () => {
    stewardRunnerRuntime.debounceTimer = null;
    stewardRunnerRuntime.debounceMs = -1;
    if (stewardRunnerRuntime.stopped) return;
    const batch = stewardHoldViewedEvents(stewardRunnerRuntime.queue.splice(0, STEWARD_INBOX_EVENTS_PER_TURN));
    if (!batch.length) { stewardScheduleInboxDrain(); return; }
    void runStewardTurn({ trigger: 'inbox', events: batch }).then(
      // 用户预算暂时触顶时每分钟重判，预算恢复后继续处理积压；明确停机仍不排回合。
      result => { stewardScheduleInboxDrain(result?.circuit ? 60000 : stewardInboxRetryDelay(batch)); },
      () => {
        stewardRequeueFailedInboxBatch(batch, 'unexpected_error');
        stewardScheduleInboxDrain(stewardInboxRetryDelay(batch));
      },
    );
    };
    if (typeof WorkDataMaintenanceHooks !== 'undefined' && WorkDataMaintenanceHooks.continueOwner) void WorkDataMaintenanceHooks.continueOwner(stewardRunnerRuntime, drain).catch(() => {}); else drain();
  }, delay);
  if (timer && typeof timer.unref === 'function') timer.unref();
  stewardRunnerRuntime.debounceTimer = timer;
}
function stewardOnInboxBatch(rows) {
  if (stewardRunnerRuntime.stopped) return;
  const list = Array.isArray(rows) ? rows.filter(Boolean) : [];
  if (!list.length) return;
  // 新事实代表新的处置机会，历史上几次「无需动作」不能把后来的线程交付和待决一起封死。
  stewardRunnerRuntime.noProgress = 0;
  stewardRunnerRuntime.queue.push(...list);
  stewardScheduleInboxDrain();
}

// ────────────────────────────────────────────────────────────────────────────
// 到访(§8.9「每次打开」/§11.1 第 7 项「一次到访 = 页面重开,或静默 60 分钟」)。
//
// 摘要是【确定性】的:由 inbox 自上次到访以来的事件按五类归纳,不调模型 —— 打开如意的第一屏不该
// 等一次模型往返,也不该因为端点不通就什么都看不到。
// ────────────────────────────────────────────────────────────────────────────
function stewardVisitsDir() { return path.join(stewardDir(), STEWARD_VISITS_DIR); }
const stewardArchiveChains = new Map(); // one read/persist/truncate transaction per conversation

// 归档文件名:ISO 时间戳里的 ':' 与 '.' 在 Windows 文件名里非法,换成 '-'(§CONTRIBUTING 第 4 条)。
function stewardVisitFileName(at) {
  return String(at || nowIso()).replace(/[:.]/g, '-') + '.json';
}

function stewardVisitStore(file) {
  const name = path.basename(String(file || ''));
  const identity = process.platform === 'win32' ? name.toLowerCase() : name;
  return WorkDataStore.createText({
    file: () => file,
    purpose: 'memory', schema: STEWARD_VISIT_SCHEMA, scopeId: STEWARD_SESSION_ID,
    recordId: 'visit:' + crypto.createHash('sha256').update(identity, 'utf8').digest('hex'),
    chunked: true, maxPlaintextBytes: 256 * 1024 * 1024,
    keys: { snapshot: () => WorkDataStore.acquireSnapshot(WorkDataStore.requireKeys()), unlock: () => WorkDataStore.requireKeys().unlock(), instance: () => WorkDataStore.requireKeys().instance() },
    enabled: () => readConfig().then(config => config.workDataEncryptionV1 === true),
    writeJson: atomicWriteJson,
    validateSealedText: text => {
      const raw = JSON.parse(text);
      return Boolean(raw && typeof raw === 'object' && !Array.isArray(raw) && raw.schema === STEWARD_VISIT_SCHEMA
        && raw.sessionId === STEWARD_SESSION_ID && Array.isArray(raw.messages));
    },
  });
}

async function stewardUnusedVisitFile(baseFile) {
  for (let collision = 0; ; collision++) {
    const file = collision ? baseFile.replace(/\.json$/, '-' + makeId('archive') + '-' + collision + '.json') : baseFile;
    try { await stewardVisitStore(file).read(); }
    catch (error) {
      if (error && error.code === 'ENOENT') return file;
      throw error; // unreadable ciphertext or an occupied/unreadable path is never permission to overwrite
    }
    // Existing plaintext or an authenticated archive remains untouched. The process-wide archive
    // chain prevents a second local archiver from claiming the same missing path before it persists.
  }
}

async function stewardTrimVisits() {
  const dir = stewardVisitsDir();
  const files = (await fsp.readdir(dir).catch(() => [])).filter(f => f.endsWith('.json')).sort();
  if (files.length <= STEWARD_VISITS_KEEP) return;
  for (const file of files.slice(0, files.length - STEWARD_VISITS_KEEP)) {
    await fsp.unlink(path.join(dir, file)).catch(() => {});
  }
}

// A reset occupies the existing runner slot. Older waiters observe the generation
// change and cancel; inbox events remain queued for the next conversation.
async function stewardResetConversation() {
  const current = stewardRunnerRuntime.inflight;
  if (current?.kind === 'reset') return current.promise;
  stewardRunnerRuntime.conversationGeneration += 1;
  const entry = { kind: 'reset', promise: null };
  stewardRunnerRuntime.inflight = entry;
  if (stewardRunnerRuntime.debounceTimer) {
    clearTimeout(stewardRunnerRuntime.debounceTimer);
    stewardRunnerRuntime.debounceTimer = null;
    stewardRunnerRuntime.debounceMs = -1;
  }
  if (current) {
    current.cancelled = 'reset';
    if (current.kind === 'inbox') stewardRunnerRuntime.queue.push(...(current.events || []));
    stewardAbortInflight(current);
  }
  entry.promise = (async () => {
    try {
      stopSession(STEWARD_SESSION_ID, 'reset');
      if (current?.promise) {
        let timer;
        const settled = await Promise.race([
          current.promise.then(() => true),
          new Promise(resolve => { timer = setTimeout(() => resolve(false), 8000); }),
        ]).finally(() => clearTimeout(timer));
        if (!settled) {
          // Keep the old turn in its slot until its own finally releases it.
          stewardRunnerRuntime.inflight = current;
          throw new Error('上一回合仍未停止，请稍后再开始新对话');
        }
      }
      if (!await waitMissionTurnSettled(STEWARD_SESSION_ID)) throw new Error('上一回合仍未停止，请稍后再开始新对话');
      const config = await readConfig();
      const archive = await stewardArchiveConversation(config, stewardRunnerRuntime.visit.startedAt || nowIso(), { reset: true });
      await writeSessionNotes(STEWARD_SESSION_ID, '');
      stewardRunnerRuntime.lastReply = null;
      stewardRunnerRuntime.noProgress = 0;
      stewardRunnerRuntime.circuit = null;
      _stewardReadBudget.delete(STEWARD_SESSION_ID);
      stewardRunnerRuntime.visit.startedAt = nowIso();
      stewardRunnerRuntime.visit.lastActivityAt = stewardRunnerRuntime.visit.startedAt;
      logEvent({ kind: 'steward_conversation_reset', archived: archive.archived });
      return { ok: true, archive, startedAt: stewardRunnerRuntime.visit.startedAt };
    } catch (error) {
      return stewardFail('steward.reset_failed', String(error?.message || error));
    } finally {
      if (stewardRunnerRuntime.inflight === entry) stewardRunnerRuntime.inflight = null;
      stewardScheduleInboxDrain();
    }
  })();
  return entry.promise;
}

// 按 stewardConversationRetention 归档管家会话历史。
//   visit   : 整段归档后清空(默认,§8.1 原则 8「对话不是档案」);
//   24h     : 只归档 24 小时前的消息,近 24 小时留在会话里;
//   forever : 不归档不清空。
// 返回 { archived, file, kept }。
async function stewardArchiveConversation(config, startedAt, options = {}) {
  return runKeyedChain(stewardArchiveChains, STEWARD_SESSION_ID, async () => {
    const retention = options.reset === true ? 'visit' : String((config && config.stewardConversationRetention) || 'forever');
    if (retention === 'forever') return { archived: 0, file: '', kept: -1 };
    const session = await loadSession(STEWARD_SESSION_ID).catch(error => {
      if (String(error && error.code || '').startsWith('work_data')) throw error;
      return null;
    });
    if (!session) return { archived: 0, file: '', kept: 0 };
    if (options.generation !== undefined && options.generation !== stewardRunnerRuntime.conversationGeneration) throw new Error('conversation changed');
    const baseGen = Number(session.rewindGen) || 0;   // 128b:归档文件与截断必须基于同一份正文
    const messages = Array.isArray(session.messages) ? session.messages : [];
    if (!messages.length && !options.reset) return { archived: 0, file: '', kept: 0 };
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    const keepFrom = retention === '24h'
      ? messages.findIndex(m => {
        const at = Date.parse(String((m && m.createdAt) || ''));
        return Number.isFinite(at) && at >= cutoff;
      })
      : messages.length;
    const splitAt = keepFrom < 0 ? messages.length : keepFrom;
    const archived = messages.slice(0, splitAt);
    if (!archived.length && !options.reset) return { archived: 0, file: '', kept: messages.length };
    const at = nowIso();
    const baseFile = path.join(stewardVisitsDir(), options.reset ? stewardVisitFileName(at).replace('.json', '-' + makeId('reset') + '.json') : stewardVisitFileName(startedAt || at));
    await fsp.mkdir(stewardVisitsDir(), { recursive: true });
    const file = await stewardUnusedVisitFile(baseFile);
    const archive = {
      schema: STEWARD_VISIT_SCHEMA,
      sessionId: STEWARD_SESSION_ID,
      startedAt: String(startedAt || ''),
      archivedAt: at,
      retention,
      messages: archived,
      ...(options.reset ? { sessionNotes: await readSessionNotes(STEWARD_SESSION_ID) } : {}),
    };
    // Preserve the old JSON bytes while OFF. While ON, sealing must finish before live truncation.
    await stewardVisitStore(file).write(JSON.stringify(archive, null, 2));
    // 正文按保留策略截断。providerHistory 与消息不是一一对应(工具轮次更多),整段清空是唯一
    // 安全的做法:留半截会让下一回合带着孤儿 tool_calls 去请求(strict provider 直接 400)。
    // 128b:修前是裸 saveSession(...).catch —— 被撤回闸丢掉时,归档文件已经写了、会话里那几条却还在(同一段对话存两份,
    // 下次拜访再归档一次)。现在截断带 expectGen 走 mutateSession:期间撤回过,或正文头部已不是刚归档的那几条,就不截断,
    // 并把刚写的归档文件删掉 —— 归档先写、截断后做的次序不变(截断之前归档一定已经在盘上,不会两头都没有)。
    let kept = messages.length - splitAt;
    let truncated = false;
    let storageError = null;
    try {
      const written = await mutateSession(STEWARD_SESSION_ID, fresh => {
        if (options.generation !== undefined && options.generation !== stewardRunnerRuntime.conversationGeneration) return { abort: 'conversation_changed' };
        const now = Array.isArray(fresh.messages) ? fresh.messages : [];
        const samePrefix = now.length >= splitAt && archived.every((m, i) => now[i] && now[i].createdAt === m.createdAt && now[i].role === m.role);
        if (!samePrefix) return { abort: 'prefix_changed' };
        fresh.messages = now.slice(splitAt);
        fresh.providerHistory = [];
        fresh.providerHistoryCursor = fresh.messages.length;
        fresh.autoCompactWatermark = 0;
        if (options.reset) {
          fresh.summary = '';
          fresh.claudeSessionId = null;
          fresh.attachments = [];
          delete fresh.stewardTaint;
        }
        kept = fresh.messages.length;
        return undefined;
      }, { writer: 'steward_archive', expectGen: baseGen, saveOpts: { shrinkBody: true, ...(options.reset ? { rewindBump: true, throwIfStale: true } : {}) } });   // 有意截短:不让 saveSession 当旧副本补回
      truncated = Boolean(written && written.ok);
    } catch (error) {
      truncated = false;
      if (String(error && error.code || '').startsWith('work_data')) storageError = error;
    }
    if (!truncated) {
      await fsp.unlink(file).catch(() => {});
      logEvent({ kind: 'steward_archive_rolled_back', sessionId: STEWARD_SESSION_ID, archived: archived.length });
      if (storageError) throw storageError;
      if (options.reset) throw new Error('conversation reset could not persist');
      return { archived: 0, file: '', kept: messages.length };
    }
    await stewardTrimVisits();
    return { archived: archived.length, file: path.basename(file), kept };
  });
}

// 确定性到访摘要:自上次到访以来的收件箱事件按七类归纳成 ≤5 条人话,再加 123-M2 的【承诺三项】。
//
// 承诺三项(37 号文 §3.5)与上面那七类是【两本账】,不能合成一本:
//   · 七类数的是「上次到访以来【发生过】什么」(收件箱流水,按 inboxSeq 切);
//   · 三项里的「未来承诺」与「等你的」数的是【此刻的状态】(还没发生的下一次触发、仍然卡着的
//     needs_you)—— 拿流水去数它们会把「同一条任务反复 needs_you」算成好几条。
// 只有中间那一项(过期或结果未知)是流水,所以它单独用 fires 的 seq 当水位(见 13m 的 visit.fireSeq)。
//
// 读口经 06j 的 SchedulerHooks.commitmentsSince —— 实现住 13t-steward-schedule.js,它在 manifest 里
// 排在本文件【之后】,直接写函数名会是前向边;调度器关着或钩子没填充时整段是无操作(三项全 0)。
const STEWARD_COMMITMENT_TEXT = Object.freeze({
  upcoming: n => `${n} 件定时任务 24 小时内要触发`,
  missed: n => `${n} 件定时任务过期或结果未知`,
  needsYou: n => `${n} 件定时任务等你批准`,
});
const STEWARD_COMMITMENT_I18N = Object.freeze({
  upcoming: 'stewardShell.digest.commitment.upcoming',
  missed: 'stewardShell.digest.commitment.missed',
  needsYou: 'stewardShell.digest.commitment.needsYou',
});
// hunt2-steward ⑧:到访摘要逐页读完「上次到访以来」的收件箱(读口一页至多 200 行)。修前只读第一页,
// 水位却推到全箱最大的 inboxSeq —— 离开期间攒下超过 200 行时,第 201 行往后的事件永远不进任何一次摘要。
// 页数有帽(STEWARD_VISIT_DIGEST_PAGES);帽子到了还没读完,水位就停在【最后读到的那一行】,
// 余下的留给下一次到访,不跳过。
const STEWARD_VISIT_DIGEST_PAGES = 25;
async function stewardVisitDigest(sinceSeq, sinceFireSeq) {
  const counts = {};
  for (const kind of STEWARD_EVENT_KINDS) counts[kind] = 0;
  let cursor = Math.max(0, Number(sinceSeq) || 0);
  let watermark = cursor;
  for (let page = 0; page < STEWARD_VISIT_DIGEST_PAGES; page++) {
    const read = await stewardInboxRead({ since: cursor, limit: 200 }).catch(() => null);
    if (!read) break;   // 读失败:水位不动,下一次到访重读
    const rows = Array.isArray(read.items) ? read.items : [];
    for (const row of rows) {
      if (Object.prototype.hasOwnProperty.call(counts, row && row.kind)) counts[row.kind] += Math.max(1, Number(row.count) || 1);
      cursor = Math.max(cursor, Number(row && row.inboxSeq) || 0);
    }
    watermark = cursor;
    if (!read.hasMore || !rows.length) { watermark = Math.max(cursor, Number(read.inboxSeq) || 0); break; }
  }
  const items = [];
  for (const kind of STEWARD_EVENT_KINDS) {
    if (items.length >= STEWARD_VISIT_DIGEST_MAX) break;
    if (counts[kind] > 0) items.push({ kind, text: STEWARD_DIGEST_KIND_TEXT[kind](counts[kind]), count: counts[kind] });
  }
  let commitments = { upcoming: 0, missed: 0, needsYou: 0, fireSeq: Math.max(0, Number(sinceFireSeq) || 0) };
  if (typeof SchedulerHooks.commitmentsSince === 'function') {
    // 旁路纪律:承诺读口出错只是少三行摘要,绝不让「打开管家」这件事失败。
    try { commitments = (await SchedulerHooks.commitmentsSince(sinceFireSeq, Date.now())) || commitments; }
    catch { /* 保持全 0 */ }
  }
  // 为承诺留出名额:事件类别满五种时也不能把漏跑/结果未知吞掉,同时推进 fireSeq 让它永远消失。
  const commitmentFields = ['upcoming', 'missed', 'needsYou'].filter(field => Math.max(0, Number(commitments[field]) || 0) > 0);
  items.splice(Math.max(0, STEWARD_VISIT_DIGEST_MAX - commitmentFields.length));
  for (const field of commitmentFields) {
    if (items.length >= STEWARD_VISIT_DIGEST_MAX) break;
    const n = Math.max(0, Number(commitments[field]) || 0);
    if (!n) continue;
    items.push({
      kind: 'commitment', field, count: n,
      key: STEWARD_COMMITMENT_I18N[field], params: { count: n },
      text: STEWARD_COMMITMENT_TEXT[field](n),
    });
  }
  return {
    items, counts,
    commitments: { upcoming: commitments.upcoming, missed: commitments.missed, needsYou: commitments.needsYou },
    inboxSeq: watermark,
    fireSeq: Math.max(0, Number(commitments.fireSeq) || 0),
  };
}

// 待决列表(来自投影,不读磁盘 —— 投影本身就是可重建物化索引)。
async function stewardPendingList() {
  const index = await getPretenderProjectionIndex().catch(() => null);
  const out = [];
  for (const slice of (index && Array.isArray(index.sessions) ? index.sessions : [])) {
    const sid = slice && safeSessionId(slice.sessionId);
    if (!sid || sid === STEWARD_SESSION_ID) continue;
    for (const iv of (Array.isArray(slice.interventions) ? slice.interventions : [])) {
      if (!iv || iv.status !== 'pending') continue;
      if (out.length >= STEWARD_PENDING_LIST_MAX) return out;
      out.push({
        sessionId: sid,
        missionId: String(slice.missionId || sid),
        interventionId: String(iv.id || ''),
        type: String(iv.type || ''),
        summary: stewardPendingOneLine(iv),
      });
    }
  }
  return out;
}

async function stewardVisit(opts) {
  const generation = stewardRunnerRuntime.conversationGeneration;
  const options = (opts && typeof opts === 'object') ? opts : {};
  const config = await readConfig().catch(() => ({}));
  if (config.stewardEnabledV1 !== true) return stewardFail('steward.disabled', 'the workbench steward is disabled (stewardEnabledV1=false)');
  if (generation !== stewardRunnerRuntime.conversationGeneration || stewardRunnerRuntime.inflight?.kind === 'reset') return stewardFail('steward.busy', '正在开始新对话');
  const idleMinutes = Math.max(1, Math.round(Number(config.stewardVisitIdleMinutes) || 60));
  const lastActivity = Date.parse(String(stewardRunnerRuntime.visit.lastActivityAt || ''));
  const idle = !Number.isFinite(lastActivity) || (Date.now() - lastActivity) > idleMinutes * 60 * 1000;
  const newVisit = options.force === true || idle;
  const previousStartedAt = stewardRunnerRuntime.visit.startedAt;
  const sinceSeq = Math.max(0, Number(stewardRunnerRuntime.visit.inboxSeq) || 0);
  const sinceFireSeq = Math.max(0, Number(stewardRunnerRuntime.visit.fireSeq) || 0);   // 123-M2 承诺三项的第二个水位

  // 116-3 P0-6(对抗审查):到访归档与在途管家回合会【并发】读-改-写同一份管家会话文件。
  // saveSession 的 sessionWriteChains 只序列化「落盘」这个动作本身,不合并两个调用方各自持有的
  // 内存快照 —— 谁的 save 排在后面,谁那份快照就整份覆盖文件。后果是回合刚写的回复在归档件与活
  // 会话里【双双消失】,或者已归档的旧消息被复活,两种都不报错。
  // 修法:归档前等在途回合收尾(上限与用户抢占同一个 STEWARD_PREEMPT_WAIT_MS);等不到就
  // steward.busy —— 不归档、不重置到访,下一次打开再来(到访是可重试的,数据不是)。
  if (newVisit) {
    const inflight = stewardRunnerRuntime.inflight;
    if (inflight && inflight.promise) {
      await Promise.race([
        inflight.promise.catch(() => {}),
        new Promise(resolve => { const t = setTimeout(resolve, STEWARD_PREEMPT_WAIT_MS); if (t && t.unref) t.unref(); }),
      ]);
    }
    if (stewardRunnerRuntime.inflight) {
      return stewardFail('steward.busy', '管家正在跑一个回合,归档要等它收尾才安全;稍后再打开一次', {
        inflight: String(stewardRunnerRuntime.inflight.kind || ''),
      });
    }
  }

  let archive = { archived: 0, file: '', kept: -1 };
  // 116-3 P2-14:归档写文件失败(磁盘满、visits 目录被占用……)此前被 .catch 吞成「归档成功的新到访」——
  // 时间戳照常重置,于是基于 stewardVisitIdleMinutes(默认 60 分钟)的下一次自动到访要再等一整个
  // 静默窗口才重试,期间没有任何错误呈现给用户。修法:失败就【不推进到访状态】(下一次调用仍视为
  // 「到访还没真正开始」,可以立刻重试),并把 archive.error 带进响应体供上层如实说人话。
  let visitOpened = newVisit;
  if (newVisit) {
    archive = await stewardArchiveConversation(config, previousStartedAt || nowIso(), { generation })
      .catch(error => ({ archived: 0, file: '', kept: -1, error: String((error && error.message) || error).slice(0, 300) }));
    if (generation !== stewardRunnerRuntime.conversationGeneration) return stewardFail('steward.cancelled', 'conversation changed');
    if (archive.error) {
      visitOpened = false;
      try { logEvent({ kind: 'steward_visit_archive_failed', error: archive.error }); } catch { /* 观测绝不反噬 */ }
    } else {
      // 到访重置:读预算桶(§11.2 每回合 6 次 / 每到访 stewardReadBudgetChars)与无进展计数一起归零。
      try { _stewardReadBudget.delete(STEWARD_SESSION_ID); } catch { /* 桶是纯内存加速,清不掉也不影响正确性 */ }
      stewardRunnerRuntime.noProgress = 0;
      stewardRunnerRuntime.circuit = null;
      stewardRunnerRuntime.visit = {
        startedAt: nowIso(),
        lastActivityAt: nowIso(),
        inboxSeq: sinceSeq,
        fireSeq: sinceFireSeq,
        previousStartedAt: previousStartedAt || '',
      };
    }
  }
  const digest = await stewardVisitDigest(sinceSeq, sinceFireSeq);
  if (generation !== stewardRunnerRuntime.conversationGeneration) return stewardFail('steward.cancelled', 'conversation changed');
  if (visitOpened) {
    stewardRunnerRuntime.visit.inboxSeq = digest.inboxSeq;   // 下次到访从这里往后归纳
    stewardRunnerRuntime.visit.fireSeq = digest.fireSeq;     // 123-M2:fires 那本账各走各的水位
  }
  const pending = await stewardPendingList();
  // 124 还债④(40 号文 §8.5 ④):**服务端不再自己挑「现在这一件」**,只把行投影出去。
  //
  // 修前这里有自己的一条挑选式:
  //     rows.find(needs_you) || rows.find(running) || rows[0]
  // 而界面那一份(public/js/thread-facts.js 的 focusThreadFor,124 走查② 之后是「等你 > 在跑 >
  // 最近发生的那一件」)判的是同一个问题:右栏「现在这一件」挑一条,问候语那枚「打开这一件」挑
  // 另一条。两处的第三档修前本来就不一样 —— 上面 stewardThreadDigestRows 的排序把 dispatching
  // 顶在「其余」之前,于是一条排队中的线程会赢过刚刚做完的那条。同一个问题两处判,迟早各说各话。
  //
  // 收法:这里只投影事实(id / 名字 / 五态 / 最后动静),挑哪一条由前端那一份纯函数判 —— 它有
  // unit 真值表与 focus-rail B1 两道锁,而本文件里再没有第二条挑选式(steward-runner.static 钉着)。
  // 帽子复用总览那一个(STEWARD_DIGEST_LIMITS.maxThreads = 40),不另起旋钮;行序保持
  // stewardThreadDigestRows 的优先序,所以裁掉的只可能是【既不等你也不在跑】的那些。
  const rows = await stewardThreadDigestRows(config).catch(() => []);
  const threads = rows.slice(0, STEWARD_DIGEST_LIMITS.maxThreads).map(row => ({
    sessionId: row.sessionId,
    // 116-5b:名字走显示名(缺摘要时回落到原话),与修前 focus.title 逐字同源。
    title: row.displayTitle || row.digest.title,
    state: row.state,
    updatedAt: row.updatedAt,
  }));
  return {
    ok: true,
    // 116-3 P2-14:归档失败时如实说「这次到访没真正开始」—— 时间戳没推进,下一次调用会立刻再试一次。
    newVisit: visitOpened,
    since: previousStartedAt || '',
    visit: { startedAt: stewardRunnerRuntime.visit.startedAt, lastActivityAt: stewardRunnerRuntime.visit.lastActivityAt },
    archive,
    digest: { items: digest.items, counts: digest.counts, commitments: digest.commitments },
    pending,
    // 124 还债④:不再回 focus —— 挑哪一条由前端那一份 focusThreadFor 判(§8.5 ④)。
    // 行里的名字仍走显示名(116-5b),与修前 focus.title 逐字同源。
    threads,
  };
}

// 117l D7(§11.9;用户走查第 7 条「一个针对复杂任务的强模型、一个简单任务的快速模型」):
// 把 06i 判出来的那一档落到刚建好的会话头上。判定在 06i(纯函数),这里只做两件够得着的事 ——
// 用 02 的归一器把它构造成 engineRoute,以及在「配了但端点已经被删」时记一条审计。
//   · 那一档没配 → 不写 session.engineRoute = createSession 的既有缺省(跟随全局),存量零变化;
//   · 端点已删 → 同样回落全局,但必须留下审计:否则用户会看到「我明明配了强模型」而无从解释
//     (不报错、不拒绝开线程是故意的 —— 模型配错不该把事儿卡死)。
function stewardApplyThreadTier(session, tier, config) {
  const decided = stewardThreadEngineRoute(tier, config);
  let route = decided.found
    ? normalizeSessionEngineRoute({ engine: 'openai', providerId: decided.providerId, model: decided.model })
    : null;
  if (route) session.engineRoute = route;
  else {
    if (decided.fallback) logEvent({ kind: 'steward_thread_model_fallback', tier: decided.tier, providerId: decided.providerId, sessionId: session.id });
    // 133d:那一档没配 → 不留给全局缺省(可能是 Agent CLI),按 06i 的顺序挑一个 OpenAI 兼容端点。
    route = stewardEnsureOpenAiRoute(session, config, decided.tier);
  }
  return {
    tier: decided.tier,
    engine: route ? { providerId: route.providerId, model: route.model } : { providerId: '', model: '' },
  };
}
// 133d(用户 2026-09-21 拍板:管家开的线程只走 OpenAI 兼容端点,两个 CLI 只留给工作台里人用):会话头上已经是
// OpenAI 路由就一字不动;否则按 06i stewardOpenAiFallback 的顺序挑一个写上并记审计;一个端点都没有 → 留全局缺省、记审计。
// 三个开线程的口(13k 线程/快问经 applyThreadTier、13t 定时任务直接调)都经这里,不许各自再判一遍。
function stewardEnsureOpenAiRoute(session, config, tier) {
  const current = normalizeSessionEngineRoute(session && session.engineRoute);
  if (current && current.engine === 'openai') return current;
  const fb = stewardOpenAiFallback(config);
  const route = fb ? normalizeSessionEngineRoute({ engine: 'openai', providerId: fb.providerId, model: fb.model }) : null;
  if (route) {
    session.engineRoute = route;
    logEvent({ kind: 'steward_thread_engine_openai_only', sessionId: session.id, tier: String(tier || ''), source: fb.source, providerId: route.providerId, model: route.model });
    return route;
  }
  logEvent({ kind: 'steward_thread_no_openai_provider', sessionId: session.id, tier: String(tier || ''), globalRoute: current ? current.engine : '' });
  return null;
}

// ════════════════════════════════════════════════════════════════════════════
// 第 117 波 117l D2(27 号文 §11.9;用户第四轮走查第 1、6 条):递话按【目标状态】选通道。
//
// 修前只有一道判据:`activeChildren.has(sessionId)` → `steward.busy`,否则起一个新回合。两头都错:
//   · 线程正挂在 request_user_input 上等用户回答时,它在 activeChildren 里 —— 于是用户那句
//     「走 A」被当成「线程忙」原地退回,界面还说成「我正忙着上一件」(管家忙),而真相是线程在等他;
//   · 一旦那条判据没命中(回合刚收尾/竞态),`stewardLaunchTurn` → `runSessionTurn` 的
//     `if (activeChildren.has) stopSession('superseded')`(09:1343,2.0 主输入框的既有语义)会把
//     那个等回答的回合就地杀掉,`request_user_input` 变成 status:'failed',用户还没答的问题凭空消失。
//
// 单点判定 + 单点执行:13g 的 steward_thread_continue 与 POST /api/steward/relay 都走这里,
// 抽屉「直接对这条线程说」不必再自己在 /api/steer 与 /api/chat/stream 之间猜。判定顺序固定:
//   answer(在等回答)> permission(在等批准)> queued(在仲裁器队列里排着)> steer(在跑)> turn(空闲)。
// 每一条都复用【既有】核心,不新造第二条通路:answer 走 decideIntervention(与 /api/chat/answer
// 同一条),steer 走 steerSessionCore(与 /api/steer 同一条),turn 走 stewardLaunchTurn。
// ════════════════════════════════════════════════════════════════════════════
// 117l-A1-fix (1):第五种目标状态 'queued'(在仲裁器队列里等着开跑)。它排在 steer 之前 ——
// 见 stewardRelayChannelFor 里那段头注。
const STEWARD_RELAY_CHANNELS = Object.freeze(['answer', 'permission', 'queued', 'steer', 'turn']);
// hunt2-steward ②:递话撞上「回合起步 / 收尾」窗口时最多等多久再重判(见 stewardRelayDeliver)。
const STEWARD_RELAY_SETTLE_WAIT_MS = 5000;

// 判定单点。只读内存注册表(04 的三张待决表)与活回合表,零写入、零文件读 —— 判定必须便宜,
// 它在每一次递话前都要跑一遍。用【内存】表而不是待决旁路账:旁路账里可能留着一条回合已经死掉的
// 陈旧 pending(那种待决没人能再答),拿它挡住递话等于把线程锁死;内存表里有 = 此刻真的有人在等。
function stewardRelayChannelFor(sessionId) {
  const sid = safeSessionId(sessionId);
  if (!sid) return { channel: 'turn' };
  for (const [qid, entry] of pendingQuestions) {
    if (!entry || entry.sessionId !== sid || entry.commandApplying) continue;
    return { channel: 'answer', questionId: String(qid), questions: Array.isArray(entry.questions) ? entry.questions : [] };
  }
  for (const [rid, entry] of pendingPermissions) {
    if (!entry || entry.sessionId !== sid || entry.commandApplying) continue;
    return { channel: 'permission', pendingId: String(rid), pendingType: 'permission' };
  }
  // 117l-A1-fix (1)(§11.9;主会话在真夹具上复核 A1 时撞出来的边界,是真丢数据):线程【已经排在
  // 仲裁器队列里、还没开跑】也是一种目标状态,而且它落在下面两道判据的缝里 —— 它不在 activeChildren
  // 里(09 的 activeChildren.set 在回合本体里,回合本体要等 10 拿到并发位之后才开始跑),也没有任何
  // 待决(有待决的回合根本不入队,见 stewardArbiterHasPending)。修前因此判成 turn -> stewardLaunchTurn
  // 又排一个回合;锁一放两个回合前后脚被放行,后一个在 09 的
  // `if (activeChildren.has) stopSession('superseded')` 里把前一个就地杀掉 —— 排队中那句话连同它的
  // 回合一起没了(实测 turn_start x2 / turn_kill superseded / 正文只剩第二句)。这正是 §11.9 D2 要
  // 杜绝的那种 supersede,只是换了个入口,所以判据加在这里、与另外四条同一处。
  // 判据用 13h 既有的同步只读单点 stewardArbiterWait:非 null 就是「此刻真的排在队里」。
  // 入队到 drain 首次判定之间有一个极短的窗口(条目已在队列、但马上会被放行),那一刻的递话也会被
  // 判成 queued —— 保守方向:让用户再说一遍,远好过丢掉一整个回合。
  const queuedWait = stewardArbiterWait(sid);
  if (queuedWait) return { channel: 'queued', wait: waitReasonFor({ pending: 0 }, queuedWait) };
  if (activeChildren.has(sid)) return { channel: 'steer' };
  // hunt2-steward ②:回合已经进了 10 runSessionTurn(turnSettlers 已登记)、但引擎还没把它登记进
  // activeChildren —— 起步那几个 await 的窗口,或 until-done 驱动器两回合之间的空档。此刻判成 turn 会
  // 让新回合在 09 里把它 superseded 掉;插话也还插不进去(没有活子回合接它)。与上面仲裁器排队同一个
  // 保守方向:判成 queued。settling:true 标出这是「回合正在起步/收尾」而不是真的在仲裁器里排队 ——
  // 这两个窗口都很短,执行单点(stewardRelayDeliver)会先等一小会儿再重判一次,不急着退回给用户。
  // (回合收尾那一段同样落在这里:09 先把回合移出 activeChildren,再做收尾的几次存盘。)
  if (turnSettlers.has(sid)) return { channel: 'queued', wait: null, settling: true };
  // 管家自己刚发起的回合还在起步(13k stewardLaunchingTurns,同步登记):同上,判成 settling,不再开第二个回合。
  if (stewardLaunchingTurns.has(sid)) return { channel: 'queued', wait: null, settling: true };
  return { channel: 'turn' };
}

// 执行单点。返回值就是工具/路由的稳定信封({ok:true,channel,…} 或 stewardFail(...))。
// launch 由调用方传进来(13g 的 stewardLaunchTurn 带着它自己的决策日志锚点与 requestMeta),
// 本函数不替它决定「新回合该带什么」—— 那是 13g 的既有语义,一个字都不动。
async function stewardRelayDeliver(input) {
  const o = (input && typeof input === 'object') ? input : {};
  const sid = safeSessionId(o.sessionId);
  const message = String(o.message == null ? '' : o.message);
  const title = String(o.title || '');
  if (!sid) return stewardFail('not_found', 'invalid sessionId');
  if (!message.trim()) return stewardFail('invalid_request', 'message is required');
  let decided = stewardRelayChannelFor(sid);
  // hunt2-steward ②:「起步 / 收尾」窗口(见 stewardRelayChannelFor)只是一瞬:等那个回合收尾(或引擎
  // 把它登记进 activeChildren)再重判,至多 STEWARD_RELAY_SETTLE_WAIT_MS —— 收尾完了走 turn,起步完了走 steer。
  // 等不到才照 queued 退回。仲裁器排队(settling 不在)不等:那可能是几分钟。
  const settleDeadline = Date.now() + STEWARD_RELAY_SETTLE_WAIT_MS;
  while (decided.channel === 'queued' && decided.settling === true && Date.now() < settleDeadline) {
    const settler = turnSettlers.get(sid);
    await Promise.race([
      settler && settler.promise ? settler.promise.catch(() => {}) : Promise.resolve(),
      new Promise(resolve => { const t = setTimeout(resolve, 100); if (t && t.unref) t.unref(); }),
    ]);
    decided = stewardRelayChannelFor(sid);
  }

  if (Array.isArray(o.attachments) && o.attachments.length && decided.channel !== 'turn') {
    return stewardFail('attachment_channel_unsupported', '这条任务正在执行、排队或等你处理待决,附件还没递进去;请等它空闲后重试,或在线程里处理当前事项', { channel: decided.channel, sessionId: sid });
  }
  if (o.revision && decided.channel !== 'turn') return stewardFail('delivery_busy', '修订需要任务空闲,请处理当前运行或待决后重试', { sessionId: sid });
  if (decided.channel === 'answer') {
    // 129g(31 号文 §2.5):这一支是管家唯一一个【替用户说话】的出口 —— 递话时那句话是用户的原话,
    // 代答时那句话是管家自己编的,而线程分不出来(两者走同一条 decideIntervention,落到线程眼里
    // 都是「用户答了」)。所以闸咬在【通道】上,不咬在工具上:不论从 steward_thread_continue 还是
    // 从 POST /api/steward/relay 进来,只要落到这一支就要过同一道门。
    // 判据与执行不分家:门在这里、在通道已经定下来【之后】、在 decideIntervention 之前,于是
    // 「先探一次通道、再去投递」中间那个状态翻转的窗口(线程刚好这一刻才挂出提问)也盖得住。
    // guard 由调用方注入(13k 拿得到 config / 目标线程头 / 管家记忆库,13h 拿不到);没注入 = 既有行为。
    if (typeof o.answerGuard === 'function') {
      const refused = await o.answerGuard(decided);
      if (refused) return refused;
    }
    // 用户这句话【就是】那道提问的答案。走与 /api/chat/answer 逐字相同的核心(13d 的 decideIntervention
    // 命令核心 + 04 的 normalizeQuestionAnswer),于是 CAS 行、审计、回合唤醒三样一个不少。
    const normalizedAnswer = normalizeQuestionAnswer({ content: message, answers: [] }, decided.questions);
    const result = await decideIntervention({
      missionId: sid,
      interventionId: decided.questionId,
      payload: { action: 'answer', normalizedAnswer },
      source: 'steward_relay',
      contractRequest: false,
    });
    if (!result || result.status !== 200) {
      return stewardFail('relay_failed', '这句话没能递成那道提问的答案(它可能刚刚超时或被别处答掉了)', {
        channel: 'answer', sessionId: sid, questionId: decided.questionId,
      });
    }
    logEvent({ kind: 'steward_relay', channel: 'answer', sessionId: sid, questionId: decided.questionId, source: String(o.source || 'steward_thread_continue') });
    return { ok: true, channel: 'answer', sessionId: sid, questionId: decided.questionId, undoRef: { kind: 'answer', sessionId: sid, questionId: decided.questionId } };
  }

  if (decided.channel === 'permission') {
    // 不代答。放行一个动作与回答一句话是两件事:前者要用户看着命令原文点头(§3.3 永久豁免的同一条精神)。
    return stewardFail('propose_required', '它在等你批准一个动作,先去批了再递话', {
      reason: 'pending_permission', channel: 'permission', sessionId: sid, pendingId: decided.pendingId,
    });
  }

  if (decided.channel === 'queued') {
    // 117l-A1-fix (1):不启动回合。也【不】把这句话挂到排队项上 —— 那要改仲裁器的队列形状
    // (entry 现在只有 sessionId/cwdKey/等待原因,没有「待递的话」这个概念),超出本轮;
    // 而在两者之间,诚实地退回来让用户再说一遍是唯一不丢数据的选择。
    // 人话里带上等待原因(与 steward_thread_status / 看板 / GET /api/missions 逐字同源的那个 label),
    // 用户才知道自己在等什么、什么时候该再说一次。
    const label = String((decided.wait && decided.wait.label) || '还没轮到它开跑');
    return stewardFail('steward.queued', `线程「${stewardSanitizeText(title) || sid}」还在排队(${label}),这句先没递进去;等它开跑后再说一次`, {
      channel: 'queued', sessionId: sid, wait: decided.wait || null,
    });
  }

  if (decided.channel === 'steer') {
    const outcome = await steerSessionCore({ sessionId: sid, text: message });
    const body = (outcome && outcome.kind === 'json') ? outcome.body : null;
    if (body && body.ok === true) {
      logEvent({ kind: 'steward_relay', channel: 'steer', sessionId: sid, source: String(o.source || 'steward_thread_continue') });
      return { ok: true, channel: 'steer', sessionId: sid, queued: Number(body.queued) || 0, injected: body.injected === true };
    }
    // 插不进去(Claude legacy/print、队列满、引擎不支持)。这时候才是「忙」—— 而且要说清是【线程】忙。
    const why = stewardErrorDetail((body && body.error) || (outcome && outcome.message)) || '这一步不能插话';
    return stewardFail('steward.busy', `线程「${title || sid}」正忙且这一步不能插话:${stewardSanitizeText(why)}`, {
      channel: 'steer', sessionId: sid, reason: 'steer_ineligible',
    });
  }

  const launch = typeof o.launch === 'function' ? o.launch : null;
  if (!launch) return stewardFail('invalid_request', 'relay turn channel needs a launcher');
  const launched = await launch();
  if (launched && launched.ok === false) return launched;
  logEvent({ kind: 'steward_relay', channel: 'turn', sessionId: sid, source: String(o.source || 'steward_thread_continue') });
  return { ok: true, channel: 'turn', sessionId: sid, ...(launched && typeof launched === 'object' ? launched : {}) };
}

// ────────────────────────────────────────────────────────────────────────────
// acts 落定:用户点了一个按钮。tool 走 13g 的同一实现(同一门控、同一决策日志),
// dismiss 只记一行日志,open_thread 只回 sessionId(切换由 UI 完成)。
// ────────────────────────────────────────────────────────────────────────────
// 62 号第三轮 P1（失败与迟到响应保护）：递话超时后重发前要先核对上一次的回执。前端为「这一次递话」
// 生成一个 attemptId，同一个 attemptId 只执行一次；`check` 是只读回执查询，永远不会再次执行。
// 账本只在内存、有界、十分钟过期：进程重启后旧 attemptId 不再等于「已执行」——界面本来就只说「未确认」。
const STEWARD_ACT_ATTEMPT_LIMITS = Object.freeze({ entries: 256, ttlMs: 10 * 60 * 1000 });
const stewardActAttempts = new Map();   // attemptId -> { at, result }
const stewardActInflight = new Map();   // attemptId -> { signature, promise }：并发同 id 共用一次执行
let stewardActReceiptFloor = 0; // Missing receipts older than any eviction cannot prove non-execution.
function stewardActAttemptId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{8,64}$/.test(value) ? value : '';
}
function stewardActAttemptPrune(now) {
  const forget = id => { stewardActReceiptFloor = Math.max(stewardActReceiptFloor, stewardActAttempts.get(id).at); stewardActAttempts.delete(id); };
  for (const [id, row] of stewardActAttempts) if (now - row.at > STEWARD_ACT_ATTEMPT_LIMITS.ttlMs) forget(id);
  while (stewardActAttempts.size > STEWARD_ACT_ATTEMPT_LIMITS.entries) forget(stewardActAttempts.keys().next().value);
}
async function stewardRunAct(act, config, attempt) {
  const attemptId = stewardActAttemptId(attempt && attempt.attemptId);
  const check = Boolean(attempt && attempt.check === true);
  // 回执查询必须带合法 attemptId：否则它会被当成一次真实执行（那正是「核对」绝不能做的事）。
  if (check && !attemptId) return stewardFail('invalid_request', 'checkAttempt needs a valid attemptId');
  const now = Date.now();
  const window = attempt && attempt.window;
  if (window && !attemptId) return stewardFail('invalid_request', 'attemptWindow needs a valid attemptId');
  const sameInstance = window && window.serverInstanceId === OVERLAY_ID;
  const validWindow = sameInstance && Number.isFinite(window.issuedAt) && Number.isFinite(window.expiresAt) && window.issuedAt <= now && window.expiresAt === window.issuedAt + STEWARD_ACT_ATTEMPT_LIMITS.ttlMs && now < window.expiresAt;
  const signature = attemptId && !check ? crypto.createHash('sha256').update(JSON.stringify(act ?? null)).digest('hex') : '';
  if (attemptId) {
    stewardActAttemptPrune(now);
    const prior = stewardActAttempts.get(attemptId);
    // 只读回执：告诉前端「这一次到底执行过没有」，绝不触发第二次执行。
    if (check) {
      const inflight = stewardActInflight.has(attemptId);
      const known = !window || sameInstance;
      const state = known && prior ? 'applied' : known && inflight ? 'inflight' : validWindow && window.issuedAt > stewardActReceiptFloor ? 'not_applied' : 'unknown';
      return { ok: true, kind: 'attempt_check', applied: state === 'applied' ? true : state === 'not_applied' || !window ? false : null, state,
        serverInstanceId: OVERLAY_ID, window: { serverInstanceId: OVERLAY_ID, issuedAt: now, expiresAt: now + STEWARD_ACT_ATTEMPT_LIMITS.ttlMs }, ...(state === 'applied' ? { executedAt: new Date(prior.at).toISOString() } : {}) };
    }
    if (window && !sameInstance) return stewardFail('attempt_unknown', '服务已重启，请先核对目标任务；这次递送不会自动重发');
    if (prior) {
      if (prior.signature !== signature) return stewardFail('invalid_request', '这次递送的目标或内容已变化,请作为新的一次发送');
      return { ...prior.result, replayed: true, executedAt: new Date(prior.at).toISOString() };
    }
    // 先查后写之间隔着真实 I/O：同一 attemptId 的并发请求必须共用同一次执行，不能各自跑一遍。
    const inflight = stewardActInflight.get(attemptId);
    if (inflight) {
      if (inflight.signature !== signature) return stewardFail('invalid_request', '这次递送的目标或内容已变化,请作为新的一次发送');
      return { ...await inflight.promise, replayed: true };
    }
    if (window && (!validWindow || window.issuedAt <= stewardActReceiptFloor)) return stewardFail('attempt_unknown', '回执窗口已失效，请先核对目标任务；不能证明这次尚未执行');
  }
  const run = stewardRunActOnce(act, config);
  if (!attemptId) return run;
  // 执行前先占用 attemptId，并发的那一份 await 同一条链；只有真的执行成功才落账，失败不占 id。
  const shared = run.then(result => {
    if (result && result.ok === true && result.executed !== false) {
      stewardActAttempts.set(attemptId, { at: Date.now(), result, signature });
      stewardActAttemptPrune(Date.now());
    }
    return result;
  }).finally(() => {
    if (stewardActInflight.get(attemptId)?.promise === shared) stewardActInflight.delete(attemptId);
  });
  stewardActInflight.set(attemptId, { signature, promise: shared });
  return shared;
}
async function stewardRunActOnce(act, config) {
  const raw = (act && typeof act === 'object') ? act : {};
  const kind = String(raw.kind || (raw.tool ? 'tool' : ''));
  if (kind === 'dismiss') {
    logEvent({ kind: 'steward_act_dismissed', label: String(raw.label || '').slice(0, 40) });
    return { ok: true, kind: 'dismiss' };
  }
  if (kind === 'open_thread') {
    const sid = safeSessionId(raw.sessionId);
    if (!sid) return stewardFail('invalid_request', 'open_thread act needs a valid sessionId');
    return { ok: true, kind: 'open_thread', sessionId: sid };
  }
  if (kind !== 'tool') return stewardFail('invalid_request', `unknown act kind: ${stewardSanitizeText(kind)}`);
  const tool = String(raw.tool || '');
  const hookKey = STEWARD_ACTION_HOOKS[tool];
  if (!hookKey) return stewardFail('not_allowed', `${stewardSanitizeText(tool)} 不能作为 act 执行`);
  const ensured = await ensureStewardSession(config);
  if (!ensured.ok) return stewardFail(ensured.error, ensured.message || 'steward engine is unsupported');
  const args = (raw.args && typeof raw.args === 'object' && !Array.isArray(raw.args)) ? raw.args : {};
  // 用户【亲自】按下的按钮:自理清单不适用(那是「管家该不该主动做」的清单),但目标线程权限与
  // 永久豁免清单照旧由 13g 内部裁决 —— 管家不会因为用户点了一下就获得放宽权限的能力。
  // 116-2e:`userPressed` 的【唯一】来源就是这一行 —— 用户在界面上亲手按下了这个按钮。
  // 只有 steward_config_set 与 steward_skill_toggle 的「须确认」判定读它;stewardMayAct、
  // 永久豁免清单与线程权限判定一概不读(06i 契约注释与 steward-tools.static ⑦ 机械看住)。
  // 116-3 P0-2:trigger:'user' —— 用户就站在这个按钮前面,线程族的「无人值守」闸门不适用。
  // 它与 userPressed 是两件不同的事:trigger 说的是「用户在不在场」,userPressed 说的是
  // 「这一次配置改动是不是用户亲手按的」,后者的读者只有 config_set / skill_toggle 两处(06i 契约)。
  const result = await StewardHooks[hookKey](args, { session: ensured.session, sessionId: ensured.session.id, config, trigger: 'user', userPressed: true });
  // 按钮【被执行了】就是 ok:true —— 工具自己的稳定信封(propose_required / not_found / version_conflict …)
  // 原样放在 result 里交给界面去说人话。只有 act 本身不合法(未知 kind、非管家工具、开关关)才是 4xx:
  // 把「工具说不行」翻译成 HTTP 错误会让前端分不清「按钮坏了」和「这件事不该这么做」。
  return { ok: true, kind: 'tool', tool, executed: !!(result && result.ok !== false), result };
}
