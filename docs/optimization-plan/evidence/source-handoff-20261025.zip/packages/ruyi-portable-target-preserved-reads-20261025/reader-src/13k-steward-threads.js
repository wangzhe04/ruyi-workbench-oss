// ============================================================================
// 第 117 波 T1(32 号文 §2.1):管家线程族工具 —— 管家「动如意」的那只手全在这里。
//
// 落点(transport 层,manifest 中位于 13j-steward-tool-base.js 之后、13l-steward-ops.js 之前)。
// 收录九个工具的实现:steward_threads_search / thread_status / thread_read / thread_new /
//   thread_continue / thread_rename / thread_permission / thread_note / quick_ask;
//   派活原语(stewardLaunchTurn / stewardRecordLaunchOutcome / stewardTriggerOf /
//   stewardUnattendedByModel / stewardRelayAutoAllowed)也在这里 —— 它们的消费者全在本文件内;
//   外加两个基础设施实现 —— stewardEnrichInboxRows(给收件箱行补交付摘要,消费者是 13i 的轮询器)
//   与 stewardQuickClose(速查线程收工,消费者是 13h 的回合收尾),它们都只经 StewardHooks 露面。
// 全部函数体自原 13g-steward.js 逐字节搬来,零行为改动;工具门控壳与注册表仍在 13g。
//
// 铁律一条没变(见 13j 顶部 116c 横幅):管家不「动世界」,要动手一律委派给线程;每个写动作经
// stewardAppendDecision 落一行决策日志;放行范围一律经 06i 的 stewardMayAct,只能收紧不能放宽。
//
// 依赖纪律(§11.3):本文件只引用拼接顺序在它之前的模块符号(00/01/01c/02/04/06i/10/13d/13e/13i/13j …),
// 全部后向边;它自己的符号只被 13g 的注册表引用,同样是后向边。
// ============================================================================

// ── 117w-W1 提交①(27 号文 §11.19.4):cwd 校验先行 ──────────────────────────────────────
// 病灶:thread_new / quick_ask 原先把 args.cwd 【原样透传】给 createSession(零校验),而 createSession
// 的回落链是 `cwd || config.defaultWorkspace || os.homedir()`。校验先行:表外一律拒,不静默回落。
//
// W7(用户 2026-09-24:「如果是如意自己开的工作区,默认不显示在常用工作区中,不要让用户自己感知到;
// 然后管家需要把工作区和任务联系起来,有时候很多任务应该在特定工作区开的,管家会新开工作区」)
// 把这一节从「三态」改成【一条选择顺序】,并把「表」扩成【已知工作区】。根因三条,如实记:
//   ① 管家上下文里的候选表只给末段名(全路径是围栏信息),而这里的校验【只收绝对路径】—— 模型照表
//      填回来的名字一律被当成相对路径拒掉,拒绝文案又教它「不确定就省掉 cwd」。于是它从来填不对任何
//      一个 cwd,每件事都走省略 → 在 Ruyi 根下按标题新开一个文件夹(真机两条股票线程各开了一个)。
//   ② 省略 cwd 时没有任何「沿用」:同一事项、接着某条线程的活,也照样按标题新开。
//   ③ 新开的文件夹被追加进 workspaces[] —— 那张表就是界面上的「常用工作区」,用户于是看见一串
//      自己没开过的文件夹。
// 改法:
//   · 已知工作区 = 用户的常用工作区(config.workspaces,第一行是默认)∪ 如意自己开的文件夹
//     (config.stewardManagedWorkspaces)。每行有一个【名字】(06i stewardWorkspaceLabels:末段名,撞名
//     往上多带一段),上下文里给的是名字,这里收名字,也收绝对路径。recentWorkspaces 仍不进(打开过 ≠ 授权过)。
//   · 选择顺序(stewardResolveThreadCwd):① 明确给了 cwd → 用它;② 带了 missionId 且事项容器记着
//     工作区 → 沿用;③ 带了 relatedSessionId → 沿用那条线程的目录;带了 missionId → 沿用同事项里最近一条
//     线程的目录;④ 都没有 → 在 Ruyi 根下按标题新开一个文件夹,登记进如意自己那张表(不进常用工作区)。
//     派生失败才落到 createSession 的回落链(用户默认工作区)。
//   · 为什么第 ④ 步不是「用户默认工作区」(派单稿的写法):真机的默认工作区就是主目录根 —— 03 的
//     cwdWarning 把它判成最高风险目标,13n 的同目录写锁又会让所有落在那儿的线程排成一队(40 号文 §8
//     那次灌水 409 就是这么来的)。默认工作区仍在清单第一行、标着「默认」,活属于它就由管家点名。
//
// 归一化用仓里既有的那一份:01-config 清洗 workspaces 时用的 normalizeWorkspacePathString(剥
// Windows「复制为路径」带的引号 + trim + 截 1000),外加 path.resolve 收斜杠与尾斜杠。两侧【同一个
// 函数、同一个顺序】,否则表里的 `C:\a\` 与传入的 `C:/a` 会被判成两个东西。
// 候选上限【读 06i 的 STEWARD_WORKSPACE_TABLE_MAX】,与 13o 的清单投影同一个数字(§11.19.7 裁决)。

// 把一个工作区路径字符串折成可逐字比较的规范形;非绝对路径一律折成 ''(相对路径会被 path.resolve
// 按【服务进程的 cwd】补全,那是一条无声的越权路,所以在这里就掐掉)。
function stewardCanonWorkspacePath(stewardWsPathRaw) {
  const cleaned = normalizeWorkspacePathString(stewardWsPathRaw);
  if (!cleaned || !path.isAbsolute(cleaned)) return '';
  return path.resolve(cleaned);
}

// win32 忽略大小写比较,其余平台逐字比较。理由两条:(1) NTFS/ReFS 默认不区分大小写,`C:\Work` 与
// `c:\work` 就是同一个目录,放行一个拒掉另一个是任意的;(2) 01-config 自己的 workspaces 去重键就是
// `p.toLowerCase()`,配置层已经把两种写法当成【同一行】—— 这里再做区分大小写就比表本身还严,会出现
// 「表里加不进第二份、传进来又被拒」的死角。非 win32 上文件系统真区分大小写,所以不折。
function stewardFoldWorkspacePath(stewardWsPathCanon) {
  return process.platform === 'win32' ? String(stewardWsPathCanon).toLowerCase() : String(stewardWsPathCanon);
}

// W7:已知工作区(同步、纯读配置)。用户的常用工作区在前(顺序即优先级),如意自己开的在后(新开的在前)。
// 每行 { path(规范形), label, user, isDefault, write, note, owned }:owned = 如意自己开的、用户还没收编。
// 管家上下文里的清单(13o)、这里的 cwd 校验、thread_status 等读模型的 workspace 名字,三处读同一份。
function stewardKnownWorkspaces(stewardKnownConfig) {
  const out = [];
  const seen = new Set();
  const defaultKey = stewardFoldWorkspacePath(stewardCanonWorkspacePath(stewardKnownConfig && stewardKnownConfig.defaultWorkspace));
  const push = (row, extra) => {
    const canon = stewardCanonWorkspacePath(row && row.path);
    if (!canon) return;
    const key = stewardFoldWorkspacePath(canon);
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ path: canon, ...extra, isDefault: extra.user === true && key === defaultKey });
  };
  for (const row of (Array.isArray(stewardKnownConfig && stewardKnownConfig.workspaces) ? stewardKnownConfig.workspaces : [])) {
    push(row, { user: true, write: !(row && row.write === false), note: String((row && row.note) || ''), owned: false });
  }
  const managed = Array.isArray(stewardKnownConfig && stewardKnownConfig.stewardManagedWorkspaces) ? stewardKnownConfig.stewardManagedWorkspaces : [];
  for (let i = managed.length - 1; i >= 0; i--) {
    const row = managed[i];
    push(row, { user: false, write: true, note: '', owned: !(row && row.adopted === true) });
  }
  const labels = stewardWorkspaceLabels(out.map(row => row.path));
  out.forEach((row, i) => { row.label = labels[i]; });
  return out;
}

// 名字或绝对路径 → 已知工作区那一行(没有就 null)。名字按不分大小写比:06i 造名字时就是按不分大小写
// 去撞车的,所以同一份清单里不会有两个只差大小写的名字。
function stewardMatchKnownWorkspace(stewardMatchRaw, stewardMatchKnown) {
  const raw = String(stewardMatchRaw == null ? '' : stewardMatchRaw).trim();
  if (!raw) return null;
  const known = Array.isArray(stewardMatchKnown) ? stewardMatchKnown : [];
  const canon = stewardCanonWorkspacePath(raw);
  if (canon) {
    const key = stewardFoldWorkspacePath(canon);
    return known.find(row => stewardFoldWorkspacePath(row.path) === key) || null;
  }
  const wanted = normalizeWorkspacePathString(raw).replace(/[\\/]+/g, '/').replace(/\/+$/, '').toLowerCase();
  return wanted ? (known.find(row => String(row.label).toLowerCase() === wanted) || null) : null;
}

// 一条路径的【名字】(给读模型用):落在哪个已知工作区里就报那个工作区的名字(子目录也归它),
// 不在任何一个里报末段名。owned 与 06i 的 stewardRuyiOwnedPath 同一口径(数据根里的也算如意的)。
function stewardWorkspaceNameOf(stewardNameCwd, stewardNameConfig, stewardNameKnown) {
  const canon = stewardCanonWorkspacePath(stewardNameCwd);
  if (!canon) return null;
  const known = Array.isArray(stewardNameKnown) ? stewardNameKnown : stewardKnownWorkspaces(stewardNameConfig);
  const key = stewardFoldWorkspacePath(canon);
  let best = null;
  for (const row of known) {
    const rowKey = stewardFoldWorkspacePath(row.path);
    if (key === rowKey || key.startsWith(rowKey + path.sep) || key.startsWith(rowKey + '/')) {
      if (!best || row.path.length > best.path.length) best = row;
    }
  }
  return {
    name: best ? best.label : (path.basename(canon) || canon),
    ruyiOwned: stewardRuyiOwnedPath(canon, stewardNameConfig, dataRoot(), dataRootAliases()),
  };
}

// 返回 { ok:true, cwd, label, owned } —— cwd 为 undefined 表示「没给」;或 { ok:false, fail } —— fail 是现成的稳定信封。
// thread_new 与 quick_ask 两处【共用这一份】,不许各抄一遍(静态锁钉着出现次数)。13t 的定时任务也用它复核 workdir。
function stewardValidateCwd(stewardCwdRaw, stewardCwdConfig) {
  const given = stewardCwdRaw == null ? '' : String(stewardCwdRaw);
  if (!given.trim()) return { ok: true, cwd: undefined };          // 没给 → 交给选择顺序的后几步
  const known = stewardKnownWorkspaces(stewardCwdConfig);
  const hit = stewardMatchKnownWorkspace(given, known);
  if (hit) return { ok: true, cwd: hit.path, label: hit.label, owned: hit.owned };   // 名字或路径命中 → 用那一行的规范值
  // 其它 → 拒。人话说清「不在已知工作区里」并列出名字(名字足够让模型改对,又不泄露全路径)。
  const names = known.slice(0, STEWARD_WORKSPACE_TABLE_MAX).map(row => row.label);
  const more = known.length > STEWARD_WORKSPACE_TABLE_MAX ? `,另有 ${known.length - STEWARD_WORKSPACE_TABLE_MAX} 个未列出` : '';
  const message = names.length
    ? `cwd 不在已知工作区里(不要自己编路径)。现有:${names.join('、')}${more}。cwd 填其中一个的名字;要用别处请先请用户在设置里把那个文件夹加成工作区;跟哪个都不沾边就【省掉 cwd】,不要重试同一个值。`
    : 'cwd 不在已知工作区里,而且现在一个工作区都没有登记。请【省掉 cwd】,不要重试同一个值。';
  return { ok: false, fail: stewardFail('invalid_request', message, { reason: 'cwd_not_in_workspaces' }) };
}

// W7:能不能【沿用】一条线程或一个事项的目录。三条:目录还在(沿用一个被删掉的目录,线程的工具会全部
// 失败);不在数据根里(管家会话自己的 cwd 就是数据根 —— 落进去会和管家抢 13n 的同目录写锁;子代理
// worktree 也在那儿,用完即删);是绝对路径。沿用【不要求】在已知工作区里:那个目录是用户或管家早先
// 给那条线程定下的,03 已经把它当成那条线程的写根,新线程接着同一件事,只是站到同一块地上。
async function stewardInheritableCwd(stewardInheritRaw) {
  const canon = stewardCanonWorkspacePath(stewardInheritRaw);
  if (!canon) return '';
  const dataKey = stewardFoldWorkspacePath(stewardCanonWorkspacePath(dataRoot()));
  const key = stewardFoldWorkspacePath(canon);
  if (dataKey && (key === dataKey || key.startsWith(dataKey + path.sep) || key.startsWith(dataKey + '/'))) return '';
  try {
    const stat = await fsp.stat(canon);
    if (!stat.isDirectory()) return '';
  } catch { return ''; }
  return canon;
}

// W7:cwd 的选择顺序(thread_new / quick_ask 共用;见本节头注)。返回
//   { ok:true, cwd, source } —— source ∈ explicit / mission / related / mission_thread / new;
//   cwd 为 undefined 时 source === 'new':调用方在 createSession 之后派生(要真线程 id 兜 slug)。
//   { ok:false, fail } —— 给了但不合法的参数(表外 cwd、不存在的 relatedSessionId),不静默回落。
async function stewardResolveThreadCwd(stewardResolveArgs, stewardResolveConfig, stewardResolveMissionId) {
  const args = (stewardResolveArgs && typeof stewardResolveArgs === 'object') ? stewardResolveArgs : {};
  const relatedRaw = args.relatedSessionId == null ? '' : String(args.relatedSessionId).trim();
  const relatedId = relatedRaw ? safeSessionId(relatedRaw) : '';
  if (relatedRaw && !relatedId) return { ok: false, fail: stewardFail('invalid_request', 'invalid relatedSessionId') };
  let relatedHead = null;
  if (relatedId) {
    relatedHead = await stewardReadSessionHead(relatedId);
    if (!relatedHead || !relatedHead.id || stewardRawKind(relatedHead) === 'steward') {
      return { ok: false, fail: stewardFail('not_found', `relatedSessionId ${relatedId} 不是一条线程;不确定就省掉它,不要重试同一个值`, { reason: 'related_not_found' }) };
    }
  }
  // ① 明确给了。
  const cwdCheck = stewardValidateCwd(args.cwd, stewardResolveConfig);
  if (!cwdCheck.ok) return cwdCheck;
  if (cwdCheck.cwd !== undefined) {
    // 如意自己开的那个文件夹被人删了:原地建回来(路径是工作台自己派生、自己登记的;13t 的定时任务同一做法)。
    // 用户的工作区不替他建 —— 那是他的地盘,修前也不查。
    if (cwdCheck.owned) await fsp.mkdir(cwdCheck.cwd, { recursive: true }).catch(() => {});
    return { ok: true, cwd: cwdCheck.cwd, source: 'explicit', relatedSessionId: relatedId };
  }
  // ② 事项容器记着的工作区。
  if (stewardResolveMissionId) {
    const container = await readMissionContainer(stewardResolveMissionId).catch(() => null);
    const fromMission = container ? await stewardInheritableCwd(container.cwd) : '';
    if (fromMission) return { ok: true, cwd: fromMission, source: 'mission', relatedSessionId: relatedId };
  }
  // ③ 相关线程:点名的那一条优先,其次同事项里最近动过的那一条。
  if (relatedHead) {
    const fromRelated = await stewardInheritableCwd(relatedHead.cwd);
    if (fromRelated) return { ok: true, cwd: fromRelated, source: 'related', relatedSessionId: relatedId };
  }
  if (stewardResolveMissionId) {
    const metas = await listSessions().catch(() => []);
    const siblings = metas
      .filter(meta => meta && !sessionMetaIsSteward(meta) && (meta.missionId || meta.id) === stewardResolveMissionId)
      .sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')));
    for (const meta of siblings) {
      const fromSibling = await stewardInheritableCwd(meta.cwd);
      if (fromSibling) return { ok: true, cwd: fromSibling, source: 'mission_thread', relatedSessionId: relatedId };
    }
  }
  // ④ 都没有 → 新开(调用方派生)。
  return { ok: true, cwd: undefined, source: 'new', relatedSessionId: relatedId };
}

// W7:事项容器第一次有了工作区,就记下来(之后这个事项里新开的线程走选择顺序第 ② 步)。
// 只在容器存在、且还没记过时写 —— 用户或早先那条线程定下的,不覆盖。失败吞掉:这是旁路记账,
// 线程已经开成了,不能因为记不下事项的工作区就让整次调用失败。
async function stewardRecordMissionWorkspace(stewardRecordMissionId, stewardRecordCwd) {
  const id = safeSessionId(stewardRecordMissionId);
  const cwd = stewardCanonWorkspacePath(stewardRecordCwd);
  if (!id || !cwd) return false;
  try {
    return await withMissionContainerLock(id, async () => {
      const current = await readMissionContainer(id);
      if (!current || String(current.cwd || '').trim()) return false;
      await writeMissionContainer(Object.assign({}, current, { cwd }));
      return true;
    });
  } catch { return false; }
}

// ── 117w-W1 提交②(27 号文 §11.19.2「子工作区派生」)────────────────────────────────────────
// 选择顺序第 ④ 步:在 Ruyi 根下派生一条属于这条线程自己的子工作区。病灶是用户看到的那句「同一个
// 文件夹被占着」:出厂 defaultWorkspace 就是主目录,十几条线程全挤在主目录根上 —— 而仓里自己的
// 03 cwdWarning 恰恰把「cwd 落在主目录根」判成最高风险目标。
// W7:派生出来的目录登记进如意自己那张表(stewardManagedWorkspaces),不再进常用工作区。
const STEWARD_WORKSPACE_SLUG_MAX = 64;          // 目录名截到 64 字符(保留中文,只做文件系统安全处理)
const STEWARD_WORKSPACE_DERIVE_TRIES = 50;      // 撞名后缀上限:slug、slug-2 … slug-50

// 标题 → 目录名。非法字符表【复用 04 的 sanitizeFsSegmentName】(提交② 把 makeAttachmentRecord 里
// 那条内联正则抽成了函数),这里不另写第二份 —— 两处分叉的后果是「附件名安全、目录名不安全」。
function stewardWorkspaceSlug(stewardSlugTitle, stewardSlugSessionId) {
  const safe = sanitizeFsSegmentName(stewardSlugTitle)
    .replace(/\s+/g, ' ')                        // 制表/换行已被上面的控制字符档换成 '_',这里只并空格
    .replace(/_+/g, '_')                         // 连续替身并成一个:`<>:"` 不该变成四道下划线
    .slice(0, STEWARD_WORKSPACE_SLUG_MAX)
    // 首尾的替身/点/空格全剥掉。两个理由:Windows 目录名不许以点或空格【结尾】;而「"报告"」这种
    // 带引号的标题被替换后是 `_报告_`,首尾那两道下划线只是噪声。剥完为空 = 这条标题里没有任何
    // 可用作目录名的字符(整条都是非法字符),走下面的 id 回落。
    .replace(/^[_.\s]+/, '')
    .replace(/[_.\s]+$/, '');
  if (safe) return safe;
  // 标题为空,或整条被非法字符替换后只剩替身/点/空格 → 回落到线程 id。
  // 【与设计页的一处出入,如实记】§11.19.2 写「thread-<id 前 8 位>」,而 id 形如 sess_+16 位十六进制,
  // 直接切前 8 位得到的是 'sess_' + 3 位,几乎必然撞名;这里按【去掉 sess_ 前缀之后】的 8 位取。
  const short = String(stewardSlugSessionId || '').replace(/^sess_/, '').slice(0, 8);
  return 'thread-' + (short || 'unnamed');
}

// 撞名规则(§11.19.2):不存在 → 建它;已存在且【空】→ 直接复用(同一件事重开线程不该长出第二个
// 空壳);已存在且【非空】→ 试 -2、-3…。同名的是文件、或读不动 → 换下一个后缀(开线程不该因为
// 用户在 Ruyi 根下放了个同名文件就失败)。试满上限返回 dir:'' = 「没派生成」,调用方保持修前的回落链。
// 返回值带 created(117w-W1④ 小刀):建目录在 mutateConfig 的串行段里,失败回滚时只许删【本次新建】
// 的那个目录 —— 复用来的空目录可能是用户自己建的,删它就是删用户的东西。
async function stewardDeriveWorkspaceDir(stewardDeriveRoot, stewardDeriveSlug) {
  for (let attempt = 1; attempt <= STEWARD_WORKSPACE_DERIVE_TRIES; attempt++) {
    const dir = path.join(stewardDeriveRoot, attempt === 1 ? stewardDeriveSlug : `${stewardDeriveSlug}-${attempt}`);
    let entries = null;
    try {
      entries = await fsp.readdir(dir);
    } catch (error) {
      if (error && error.code === 'ENOENT') {
        try { await fsp.mkdir(dir, { recursive: true }); return { dir, created: true }; } catch { continue; }
      }
      continue;
    }
    if (entries.length === 0) return { dir, created: false };
  }
  return { dir: '', created: false };
}

// 回滚:只删【本次新建】的空目录(stewardDeriveWorkspaceDir 的 created 那一支)。非空就留着 ——
// 说明已经有别的东西写进去了,强删会毁用户数据。失败吞掉:回滚是尽力而为,它自己再抛出去会把
// 「派生没成」这件正事盖掉。
async function stewardDiscardDerivedWorkspaceDir(stewardDiscardDir) {
  if (!stewardDiscardDir) return;
  try { await fsp.rmdir(stewardDiscardDir); } catch { /* 非空,或已经被别人删了 */ }
}

// 把派生出来的目录【建目录 + 登记】做成一件事,整件坐在 mutateConfig 的串行段里(01-config 的
// mutateConfig 是「读 -> mutator -> 写」的唯一临界区),口径只有一句:【要么行落盘,要么不算派生成】。
// 为什么把文件 I/O 放进配置临界区:目录就一个,readdir/mkdir 是本地快操作;换来的是「占位与建目录
// 之间不存在窗口」这一条不变量。
// W7:登记的是 stewardManagedWorkspaces(如意自己那张表),不再往 workspaces[] 追加 —— 那张表就是
// 用户的常用工作区。因此 117w-W1④ 那道「常用工作区表满了就拒开线程」的帽检查也一并退役:派生从此
// 不占常用工作区的行;如意那张表满了由 01-config 从最老的一行起丢(STEWARD_MANAGED_WORKSPACES_CAP),
// 新登记的这一行永远在尾部,不会被丢。
// 返回:派生好的绝对路径,或 ''(撞名试满/写失败)。返回 '' 时调用方保持修前的回落链。
async function stewardClaimDerivedWorkspace(stewardClaimRoot, stewardClaimSlug) {
  let builtDir = '';       // 本次 mkdir 出来的目录(回滚目标);复用已有空目录时永远留空
  let claimedDir = '';
  let claimedKey = '';
  let outcome = null;
  const keyOf = row => stewardFoldWorkspacePath(stewardCanonWorkspacePath(row && row.path));
  try {
    outcome = await mutateConfig(async current => {
      // ① 占目录。占不到(撞名试满)= 不派生,不留任何东西。
      const claimed = await stewardDeriveWorkspaceDir(stewardClaimRoot, stewardClaimSlug);
      if (!claimed.dir) return { abort: 'no_dir' };
      claimedDir = claimed.dir;
      if (claimed.created) builtDir = claimed.dir;
      claimedKey = stewardFoldWorkspacePath(stewardCanonWorkspacePath(claimed.dir));
      if (!claimedKey) return { abort: 'no_dir' };
      // ② 已经登记过(同一件事重开线程复用了空目录;或用户早把它加进了常用)-> 不写盘,那一行在盘上。
      const userRows = Array.isArray(current.workspaces) ? current.workspaces : [];
      const managed = Array.isArray(current.stewardManagedWorkspaces) ? current.stewardManagedWorkspaces : [];
      if (userRows.some(row => keyOf(row) === claimedKey) || managed.some(row => keyOf(row) === claimedKey)) return { abort: 'exists' };
      // ③ 追加在如意那张表的【末尾】(= 最新;01-config 满员时从头部丢)。
      // 这是工作台写自己的配置,不经 steward_config_set,所以不违反这张表的 forbidden 档。
      current.stewardManagedWorkspaces = managed.concat([{ path: claimed.dir, at: nowIso() }]);
      return {};
    });
  } catch {
    // ④ 落盘抛了(磁盘满/文件只读/降级期):行没落盘 —— 删掉本次新建的目录,不算派生成。
    await stewardDiscardDerivedWorkspaceDir(builtDir);
    return '';
  }
  // 成功判据是【写完之后那份配置里真有这一行】(两张表任一),不是 mutator 说了什么。
  const cfg = outcome && outcome.config;
  const landed = !!(cfg && claimedKey && [
    ...(Array.isArray(cfg.workspaces) ? cfg.workspaces : []),
    ...(Array.isArray(cfg.stewardManagedWorkspaces) ? cfg.stewardManagedWorkspaces : []),
  ].some(row => keyOf(row) === claimedKey));
  if (!landed) {
    await stewardDiscardDerivedWorkspaceDir(builtDir);
    return '';
  }
  return claimedDir;
}

// 选择顺序第 ④ 步的入口。返回派生好的绝对路径,或 ''(根不可用/撞名试满/写失败)—— 返回 '' 时调用方
// 保持修前的回落链(createSession 的 `cwd || defaultWorkspace || homedir`),绝不拿一个假路径去跑。
async function stewardDeriveThreadCwd(stewardDeriveTitle, stewardDeriveSessionId, stewardDeriveConfig) {
  const root = stewardCanonWorkspacePath(stewardDeriveConfig && stewardDeriveConfig.stewardWorkspaceRoot);
  if (!root) return '';
  // 建目录与登记是【一件事】(见 stewardClaimDerivedWorkspace):中间任何一步没成,都不会留下
  // 「目录建了、行没了」。这两件事不再拆成两次调用 —— 拆开就又把窗口打开了。
  return await stewardClaimDerivedWorkspace(root, stewardWorkspaceSlug(stewardDeriveTitle, stewardDeriveSessionId));
}

// One ephemeral metadata grouping per lookup/overview; no history scan or separate store.
function threadRelationsIndex(metas) {
  const index = { byId: new Map(), missions: new Map(), workspaces: new Map(), sources: new Map() };
  const add = (map, key, meta) => { if (!key) return; if (!map.has(key)) map.set(key, []); map.get(key).push(meta); };
  for (const meta of (Array.isArray(metas) ? metas : [])) {
    if (!meta || sessionMetaIsSteward(meta)) continue;
    index.byId.set(meta.id, meta);
    add(index.missions, sessionMissionId(meta), meta);
    add(index.workspaces, stewardFoldWorkspacePath(stewardCanonWorkspacePath(meta.cwd)), meta);
    add(index.sources, meta.relatedSessionId, meta);
  }
  return index;
}
function threadRelatedThreads(head, metas) {
  const index = metas && metas.byId instanceof Map ? metas : threadRelationsIndex(metas);
  const missionId = sessionMissionId(head);
  const cwd = stewardFoldWorkspacePath(stewardCanonWorkspacePath(head && head.cwd));
  const candidates = new Map();
  const add = (rows, reason) => { for (const meta of rows || []) {
    if (meta.id === head.id) continue;
    if (!candidates.has(meta.id)) candidates.set(meta.id, { meta, reasons: [] });
    candidates.get(meta.id).reasons.push(reason);
  } };
  const source = index.byId.get(head.relatedSessionId);
  add(source ? [source] : [], 'source');
  add(index.sources.get(head.id), 'derived');
  add(index.missions.get(missionId), 'same_mission');
  add(index.workspaces.get(cwd), 'same_workspace');
  return [...candidates.values()].sort((a, b) => {
    const rank = row => row.reasons.some(reason => reason === 'source' || reason === 'derived') ? 0 : row.reasons.includes('same_mission') ? 1 : 2;
    return rank(a) - rank(b) || String(b.meta.updatedAt || '').localeCompare(String(a.meta.updatedAt || ''));
  }).slice(0, 4).map(({ meta, reasons }) => ({
    sessionId: meta.id, title: stewardSanitizeText(redact(String(meta.title || '')), true), updatedAt: String(meta.updatedAt || ''), reasons,
  }));
}

// 2) steward_threads_search —— 113b 的会话内容搜索核心(不走 HTTP)+ 标题词法兜底。
function stewardRecentUserRequest(o) {
  const request = sessionMeta(o).recentUserRequest;
  return request ? { ...request, text: stewardSanitizeText(redact(request.text), true) } : null;
}
function stewardThreadDisplayTitle(head, config) {
  let title = sessionDisplayTitle(head);
  if (head?.titleSource !== 'user' && isUntitledSessionTitle(title)) {
    const request = stewardRecentUserRequest(head);
    title = request?.text ? [...request.text].slice(0, SESSION_BRIEF_TITLE_CHARS).join('')
      : /^en/i.test(String(config?.locale || '')) ? 'Unnamed thread' : '未命名线程';
  }
  return stewardSanitizeText(redact(String(title || '')), true);
}
async function stewardImplThreadsSearch(args, ctx, config) {
  const q = String(args.q || '').trim();
  const limit = stewardClampInt(args.limit, 1, STEWARD_SEARCH_LIMIT_MAX, STEWARD_SEARCH_LIMIT_DEFAULT);
  const includeClosed = args.includeClosed === true;   // 116-2e:把已收工的速查线程也算进来
  let scope = sessionSearchScope(sessionSearchIndexEnabled(config));
  if (!q) return { ok: true, query: '', results: [], indexed: 0, scope, reason: 'query_empty' };
  // 第二轮工具走查(F8):13f 的描述一直写「太短(少于 2 字)返回空结果并给 reason」,实现却放行了 1 个字
  // (走词法兜底,于是 q:'x' 满屏命中)。与经典壳 GET /api/sessions/search(13d)同一个下限、同一个 reason 码。
  if (q.length < SESSION_SEARCH_MIN_QUERY) return { ok: true, query: q, results: [], indexed: 0, scope, reason: 'query_too_short' };
  const metas = await SessionFullTextHooks.metadata();
  const byId = new Map(metas.map(meta => [meta.id, meta]));
  const relations = threadRelationsIndex(metas);

  let ranked = [];        // [{ id, score }]
  let indexed = 0;
  let degraded = '';let coverage=null;const matches=new Map();
  if (sessionSearchIndexEnabled(config)) {
    // 内容索引在:直接用 113b 的核心函数(GET /api/sessions/search 背后那一个)。
    const found = await searchSessionsByContent(q, Math.min(STEWARD_SEARCH_LIMIT_MAX, limit + 10));
    if (found && Array.isArray(found.results)) {
      indexed = Number(found.indexed) || 0;coverage=found.coverage;scope=found.scope;for(const match of found.results)matches.set(match.id,match);
      ranked = found.results.map(row => ({ id: row.id, score: Number(row.score) || 0 }));
    } else throw Object.assign(Error('session_search.result_invalid'),{code:'session_search.result_invalid'});
  } else degraded = 'index_disabled';
  if (!ranked.length && !sessionSearchIndexEnabled(config)) {
    // 退化词法:只看标题与摘要(不读正文),命中即按更新时间排序 —— 索引关着时仍然能找到线程。
    const needle = q.toLowerCase();
    ranked = metas
      .filter(meta => (String(meta.title || '') + ' ' + String(meta.summary || '') + ' ' + String(meta.recentUserRequest && meta.recentUserRequest.text || '')).toLowerCase().includes(needle))
      .sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')))
      .map(meta => ({ id: meta.id, score: 0 }));
    if (!degraded) degraded = 'lexical_fallback';
  }

  const index = await getPretenderProjectionIndex().catch(() => null);
  const slices = new Map(((index && index.sessions) || []).map(row => [row.sessionId, row]));
  // 116g:同一事项被多条命中线程共用时只读一次事项文件(结果上限 50,不做无界扫描)。
  const missionTitles = new Map();
  const missionTitleOf = async missionId => {
    if (!missionTitles.has(missionId)) {
      const container = await readMissionContainer(missionId).catch(() => null);
      missionTitles.set(missionId, container ? stewardSanitizeText(container.title) : '');
    }
    return missionTitles.get(missionId);
  };
  const results = [];
  const knownForNames = stewardKnownWorkspaces(config);   // W7:结果行带工作区名字,整次调用只算一次清单
  for (const row of ranked) {
    if (results.length >= limit) break;
    const head = await stewardReadSessionHead(row.id);
    const rawKind = stewardRawKind(head);
    if (rawKind === 'steward') continue;                       // §11.3:管家自己的会话永不出现在结果里
    // 116-2e(§11.1 第 2 项):已收工的速查线程默认不出现 —— 它答完那一句就没用了,留在结果里
    // 只会挤掉真正的任务线程。includeClosed:true 可以要回来(用户问「刚才那条速查说了啥」)。
    if (!includeClosed && stewardQuickClosed(head)) continue;
    const meta = byId.get(row.id) || {};const publicMeta=await SessionFullTextHooks.publicMetadata(row.id);const publicHead={...head,...publicMeta,threadBrief:publicMeta.brief||null};
    const slice = slices.get(row.id) || null;
    const card = slice ? overlayMissionCard(slice) : null;
    // 116-3 P1-5:兜底判据从「非 mission 即 quick_ask」改成「只有管家自己开的速查线程才是 quick_ask」。
    // sessionKind() 里的 'quick_ask' 是第 70 波遗留的「纯问答默认档」,与 116 波的「速查线程」是两个概念;
    // 混用会把用户正在进行的普通对话打上「速查中」标签喂给管家,让它以为那是「答完即扔」的临时线程。
    // 117r-D5 收尾(主会话):D5 把五态的守卫从「是不是速查」换成「调用方有没有事实」之后，这条【没有
    // 卡片】的兜底支就漏了 —— 它一个事实都不喂,原来靠 kind 短路才说得出「速查中」,改完会一路掉进
    // 「无 run、无回合、无里程碑」那条分支变成「交办中」。D1 之后速查线程恒有卡片,所以只在投影还没
    // 赶上的瞬时窗口走到这里,但那也是一句假话。速查那一侧显式说「我没有事实」,与 13d 那条不读会话头
    // 的兜底支同一口径;mission 那一侧不动(它本来就落 dispatching,逐字节不变)。
    const derived = card ? stewardThreadStateFromCard(card)
      : (stewardQuickThread(head)
        ? deriveStewardThreadState({ kind: 'quick_ask', factsUnknown: true })
        : deriveStewardThreadState({ kind: 'mission' }));
    const missionId = (slice && slice.missionId) || (head && sessionMissionId(head)) || row.id;
    const wsName = stewardWorkspaceNameOf(meta.cwd || (head && head.cwd), config, knownForNames);
    const recentUserRequest = stewardRecentUserRequest(publicHead);
    results.push({
      sessionId: row.id,
      relatedThreads: threadRelatedThreads(head || meta, relations),
      missionId,
      // 116g:命中的线程属于哪个【事项】。未归类线程这里是空串(事项标题就是线程标题,不重复说)。
      missionTitle: await missionTitleOf(missionId),
      title: stewardSanitizeText(publicMeta.title || ''),
      displayTitle: stewardThreadDisplayTitle(publicHead, config),
      ...(publicMeta.brief ? { brief: publicMeta.brief } : {}),   // 116-5b(§11.8.5):title 仍是原话(管家凭它认出用户当时的说法),名字与概括另给一个键,缺席时不出现;经典壳那一面在 13d 的 searchSessionsByContent
      kind: stewardDisplayKind(head),
      state: derived.state,
      stateLabel: derived.label,
      // 诚实:总览与搜索结果里的「最后一句」用会话摘要(= 助手原话经既有收尾裁剪),不做模型改写。
      lastAssistantText: stewardClipSay(publicMeta.summary || ''),
      ...(recentUserRequest ? { recentUserRequest } : {}),
      updatedAt: String(meta.updatedAt || (head && head.updatedAt) || ''),
      score: Number(row.score) || 0,...(matches.get(row.id)?.reference?{reference:matches.get(row.id).reference,snippet:matches.get(row.id).snippet}:{}),
      // W7:它在哪个工作区里(已知工作区的名字;不在任何一个里给末段名)。只加字段,缺 cwd 时不出现。
      ...(wsName ? { workspace: wsName.name } : {}),
    });
  }
  return SessionFullTextHooks.finish(stewardForeignProjection({ok:true,query:q,results,indexed,scope,...(coverage?{coverage}:{}),...(degraded?{degraded}:{})}));
}

// 3) steward_thread_status —— 五态优先取投影 card,没有则按 mission-state.js 同一判据在服务端派生。
async function stewardImplThreadStatus(args, ctx, config) {
  const sessionId = safeSessionId(args.sessionId);
  if (!sessionId) return stewardFail('not_found', 'invalid sessionId');
  const head = await stewardReadSessionHead(sessionId);
  if (!head || !head.id) return stewardFail('not_found', `thread ${sessionId} not found`);
  const rawKind = stewardRawKind(head);
  if (rawKind === 'steward') return stewardFail('not_found', 'the steward session is not a thread');

  const index = await getPretenderProjectionIndex().catch(() => null);
  const slice = ((index && index.sessions) || []).find(row => row.sessionId === sessionId) || null;
  const card = slice ? overlayMissionCard(slice) : null;
  const derived = card
    ? stewardThreadStateFromCard(card)
    : stewardThreadStateFromHead(head, {   // 会话头证据键由 06i 适配器统一读(与 13d / 13o / 13r 同一个)
      kind: stewardQuickThread(head) ? 'quick_ask' : 'mission',   // 116-3 P1-5,判据同 threads_search
      pending: await missionPendingCounts(sessionId, [], null).catch(() => null),
      activeTurn: activeChildren.has(sessionId),
      runCount: 0,
    });

  const rawPending = (await readInterventions(sessionId).catch(() => [])).filter(iv => iv && iv.status === 'pending');
  // 127 波 2-quater B1 ③:豁免命中的权限待决多挂一个 exempt(类别 / 底线 / 脱敏摘录),与收件箱行同一个生产者;
  // 没命中的待决一个字段都不多。
  const interventions = rawPending
    .slice(0, STEWARD_PENDING_SUMMARY_MAX)
    .map(iv => {
      const exempt = stewardExemptPendingSummary(iv);
      const execution = stewardPendingExecutionSummary(iv);
      return { id: String(iv.id), type: String(iv.type || ''), toolName: String(iv.toolName || ''), tier: String(iv.tier || ''), summary: stewardPendingOneLine(iv), interventionVersion: Number(iv.interventionVersion) || 0, ...(exempt ? { exempt } : {}), ...(execution ? { execution } : {}) };
    });

  const session = await loadSession(sessionId).catch(() => null);
  const usage = (slice && slice.usage) || null;
  const engine = stewardEngineOf(head);
  const lastRun = card && card.lastRun ? card.lastRun : null;
  // 116g:这条线程属于哪个【事项】,以及那个事项整体是什么状态(由 06i 的 aggregateMissionState 单点
  // 纯函数按全部子线程五态算出;未归类事项 = 只有它自己一条线程,聚合态就等于自己的五态)。
  const missionOfThread = sessionMissionId(head) || sessionId;
  const missionRow = (await buildMissionAggregateRows({ includeArchived: true, config }).catch(() => null) || { rows: [] })
    .rows.find(row => row.missionId === missionOfThread) || null;
  return stewardForeignProjection({
    ok: true,
    sessionId,
    missionId: sessionMissionId(head),
    mission: {
      missionId: missionOfThread,
      title: stewardSanitizeText(missionRow ? missionRow.title : (head.title || '')),
      aggregateState: missionRow ? missionRow.aggregateState : derived.state,
      threadCount: missionRow ? missionRow.threadCount : 1,
      derived: missionRow ? missionRow.derived : true,
      // W7:事项的工作区(名字与出身,同本函数顶层的 workspace 口径)。
      workspace: missionRow && missionRow.workspace ? stewardWorkspaceNameOf(missionRow.workspace.path, config) : null,
    },
    title: stewardSanitizeText(head.title || ''),
    displayTitle: stewardThreadDisplayTitle(head, config),
    // W7:它在哪个工作区里 —— { name, ruyiOwned }(name 是已知工作区清单里的那个名字,可以原样填回
    // steward_thread_new 的 cwd;ruyiOwned = 如意自己开的文件夹)。缺 cwd 时为 null。只加字段。
    relatedThreads: threadRelatedThreads(head, await listSessions()),
    workspace: stewardWorkspaceNameOf(head.cwd, config),
    kind: stewardDisplayKind(head),
    state: derived.state,
    stateLabel: derived.label,
    stateSources: derived.sources,
    activeTurn: activeChildren.has(sessionId),
    execution: sessionExecutionSnapshot(sessionId),
    currentAction: lastRun ? stewardSanitizeText(`班组运行 ${lastRun.id || ''} · ${lastRun.status || ''}`) : (activeChildren.has(sessionId) ? '回合进行中' : ''),
    lastStep: lastRun ? stewardSanitizeText(`${lastRun.nodeCount || 0} 个节点 · eventSeq ${lastRun.eventSeq || 0}`) : '',
    pending: interventions,
    pendingCounts: (card && card.pending) || await missionPendingCounts(sessionId, [], null).catch(() => null),
    // 116h(§3.1 116h 行 / §8.10「排队可解释」):等待原因【单一】,由 06i 的 waitReasonFor 单点判定
    // (等你 > 等锁 > 等预算 > 等并发位)。pending 用五态判据已经算好的那一份,不再数第二遍;
    // 仲裁器一侧是同步只读(开关关时 arbiterWait 恒返回 null,wait 只可能是「等你」或 null)。
    wait: waitReasonFor(
      { pending: (derived.sources && derived.sources.pendingTotal) || 0 },
      typeof StewardHooks.arbiterWait === 'function' ? StewardHooks.arbiterWait(sessionId) : null,
    ),
    // 117l D4(§11.9;用户第四轮走查第 1 条):它在问你。【只加字段】—— wait 与五态一字不改。
    // 判据单点在 06i;本处拿得到完整的最后一条助手消息(session 已装载),所以三态都算得准。
    asksYou: stewardAsksYouForThread({
      pending: rawPending, activeTurn: activeChildren.has(sessionId),
      lastAssistantText: session ? stewardLastAssistantText(session) : (head.summary || ''),
    }),
    // permissionMode 保持既有语义 =【生效】档(既有断言与提示词都读它;断言只加不改)。
    permissionMode: stewardThreadPermissionMode(head, config),
    permissionLabel: stewardPermissionLabel(stewardThreadPermissionMode(head, config)),
    // 116-2a 只加两个字段,把「生效档」与「这条线程自己定的档」显式分开:
    //   effectivePermissionMode —— 与 permissionMode 同值,名字自解释,给 117 的 chip 与管家提示词读;
    //   sessionPermissionMode —— 会话级设置,null = 没定、跟着全局走(chip 的实底/浅底就看它)。
    effectivePermissionMode: stewardThreadPermissionMode(head, config),
    sessionPermissionMode: sessionPermissionModeOf(head),
    engine: engine.engine,
    model: engine.model,
    providerId: engine.providerId || '',
    usage: usage ? { inTok: usage.inTok, outTok: usage.outTok, cachedInTok: usage.cachedInTok, turns: usage.turns, costsByCurrency: usage.costsByCurrency } : null,
    turnSeq: Math.max(0, Number(head.turnSeq) || 0),
    updatedAt: String(head.updatedAt || ''),
    lastAssistantText: stewardClipSay(session ? stewardLastAssistantText(session) : (head.summary || '')),
    recentUserRequest: stewardRecentUserRequest(session || head),
  });
}

// 4) steward_thread_read —— §11.2 按需层。配额与预算在写任何东西之前先扣;读到的内容【不写入任何
//    持久化】(记忆只记用户本人陈述,深读结果不进记忆,也不落决策日志)。
function stewardToolCallLine(call) {
  const name = stewardSanitizeText((call && call.name) || 'tool');
  let inputHint = '';
  try {
    const raw = JSON.stringify((call && call.input) || {});
    // 107-S1 ⑥(46 号文 §5 ⑦b M4):入参提示【先脱敏再裁】。修前这里是 `JSON.stringify(input)` 原样裁 160 字
    // 交给管家模型并落盘(steward_thread_read 的结果进提示词、也进那一轮的会话文件)——
    // 而同一个文件里 B1 的摘录管线(:1073)早就立了「命令原文先 redact」,两处分叉。
    // redact 住在 04,13k→04 是既有边(:1073 用的就是它),零新增依赖。
    // 顺序照 S0 的教训:redact 在裁剪【之前】—— 先裁 160 字会把密钥切成半截,正则一条都咬不到。
    inputHint = stewardSanitizeText(redact(raw), true).slice(0, 160);
  } catch { inputHint = '{…}'; }
  let resultChars = 0;
  try { resultChars = JSON.stringify((call && call.result) != null ? call.result : '').length; } catch { resultChars = -1; }
  // 第二轮工具走查(F15):修前只有结果长度,失败的 {ok:false,error} 也有几十~几百字符,看不出成败 ——
  // 而「线程为什么卡住」恰恰最需要知道哪一步失败了。成败取结果对象自己的 ok(失败信封都是 {ok:false,…},
  // 或带 error / threw 字段);拿不到结果(Claude 引擎只记调用不记结果)或结果是裸文本时诚实地给 null,不猜。
  const verdict = stewardToolCallVerdict(call);
  const mark = verdict === true ? ' ✓' : verdict === false ? ' ✗失败' : '';
  // 工具输出只给长度(与既有 observation reducer 的缩减视图同一诚实口径:不给全文,给可回读的把手)。
  return `[工具] ${name} ${inputHint} → ${resultChars >= 0 ? resultChars + ' 字符' : '不可序列化'}${mark}${call && call.id ? ' (id=' + stewardSanitizeText(call.id) + ')' : ''}`;
}
function stewardToolCallVerdict(call) {
  const result = call && call.result;
  if (!result || typeof result !== 'object' || Array.isArray(result)) return null;
  if (result.ok === false || result.threw || result.error) return false;
  if (result.ok === true) return true;
  return null;
}
async function stewardImplThreadRead(args, ctx, config) {
  const sessionId = safeSessionId(args.sessionId);
  if (!sessionId) return stewardFail('not_found', 'invalid sessionId');
  const tail = stewardClampInt(args.tail, 1, STEWARD_READ_TAIL_MAX, STEWARD_READ_TAIL_DEFAULT);
  const maxChars = stewardClampInt(args.maxChars, STEWARD_READ_CHARS_MIN, STEWARD_READ_CHARS_MAX, STEWARD_READ_CHARS_DEFAULT);
  const budgetChars = stewardClampInt(config.stewardReadBudgetChars, 4000, 400000, 48000);
  const stewardSessionId = String((ctx.session && ctx.session.id) || process.env.WCW_SESSION_ID || 'steward');
  const bucket = stewardReadBucket(stewardSessionId, stewardTurnKeyOf(ctx));
  if (budgetChars - bucket.chars <= STEWARD_READ_ROW_OVERHEAD + STEWARD_READ_CLIP_MARK.length) {
    return stewardFail('budget_exceeded', `thread read character budget exhausted for this turn (${budgetChars} chars); answer with already-read information`, { quota: { callsRemaining: null, charsRemaining: 0 } });
  }
  const head = await stewardReadSessionHead(sessionId);
  if (!head || !head.id) return stewardFail('not_found', `thread ${sessionId} not found`);
  if (stewardRawKind(head) === 'steward') return stewardFail('not_found', 'the steward session is not a thread');
  const session = await loadSession(sessionId).catch(() => null);
  if (!session) return stewardFail('not_found', `thread ${sessionId} not found`);

  // 消耗一次配额:一旦真的开读就计数(不论最终返回多少字符),否则「读了但没算」就是预算漏洞。
  bucket.calls += 1;

  const messages = Array.isArray(session.messages) ? session.messages : [];
  const turnSeqs = [...new Set(messages.map(m => Number(m && m.turnSeq)).filter(Number.isFinite))].sort((a, b) => a - b);
  const eligibleTurns = args.beforeTurnSeq == null ? turnSeqs : turnSeqs.filter(seq => seq < Number(args.beforeTurnSeq));
  const wanted = new Set(eligibleTurns.slice(-tail));
  const rows = [];
  for (const m of messages) {
    if (!m) continue;
    const seq = Number(m.turnSeq);
    // 第二轮工具走查(F9):用户/助手正文也要先 redact 再中和 —— 用户在线程里随口贴的 sk-… / ghp_… 修前原样交给了
    // 管家模型(并进了那一轮的会话文件),而同一个函数对工具入参早就脱敏了。顺序照 stewardToolCallLine 的教训:
    // redact 在【之前】,后面按 maxChars 裁剪时不会把密钥切成半截让正则咬不到。
    // 唤醒通知(meta.origin:'agent_wake')不是用户说的话:以 system 行给管家看,免得它把「后台代理已完成…」当成用户的诉求引用。
    if (m.role === 'user') rows.push({ turnSeq: Number.isFinite(seq) ? seq : null, role: (m.meta && m.meta.origin === 'agent_wake') ? 'system' : 'user', text: stewardSanitizeBlock(stewardForeignProjection(redact(String(m.content || '')))) });
    else if (m.role === 'assistant') {
      rows.push({ turnSeq: Number.isFinite(seq) ? seq : null, role: 'assistant', text: stewardSanitizeBlock(stewardForeignProjection(redact(String(m.content || '')))) });
      for (const call of (Array.isArray(m.toolCalls) ? m.toolCalls : [])) {
        // ok:工具这一步成败(true/false;拿不到结果记录时为 null),给模型排查「线程卡在哪一步」用。
        rows.push({ turnSeq: Number.isFinite(seq) ? seq : null, role: 'tool', ok: stewardToolCallVerdict(call), text: stewardToolCallLine(call) });
      }
    }
  }
  // Cursor addresses the sanitized row and an exclusive character boundary. Appends do not move it.
  // Rewind/edit may change rows: restart the read after editing the history.
  let rowIndex = rows.length - 1, end = null;
  if (args.cursor != null) {
    const match = /^(\d+):(\d+)$/.exec(String(args.cursor));
    if (!match) return stewardFail('invalid_request', 'invalid cursor');
    rowIndex = Number(match[1]); end = Number(match[2]);
    if (!rows[rowIndex] || end > rows[rowIndex].text.length) return stewardFail('invalid_request', 'cursor no longer matches history; restart the read');
  } else {
    while (rowIndex >= 0 && rows[rowIndex].turnSeq != null && !wanted.has(rows[rowIndex].turnSeq)) rowIndex--;
  }
  const pageTurns = new Set();
  const kept = [];
  let room = Math.min(maxChars, budgetChars - bucket.chars), clippedRows = 0;
  while (rowIndex >= 0 && room > STEWARD_READ_ROW_OVERHEAD + STEWARD_READ_CLIP_MARK.length) {
    const row = rows[rowIndex];
    if (!pageTurns.has(row.turnSeq) && pageTurns.size >= tail) break;
    pageTurns.add(row.turnSeq);
    const boundary = end == null ? row.text.length : end;
    const start = Math.max(0, boundary - (room - STEWARD_READ_ROW_OVERHEAD - STEWARD_READ_CLIP_MARK.length));
    const clipped = start > 0;
    const text = (clipped ? STEWARD_READ_CLIP_MARK : '') + row.text.slice(start, boundary);
    kept.unshift({ ...row, text, rowIndex, startChar: start, endChar: boundary });
    room -= text.length + STEWARD_READ_ROW_OVERHEAD;
    if (clipped) { end = start; clippedRows++; break; }
    rowIndex--; end = null;
  }
  const chars = kept.reduce((n, r) => n + r.text.length, 0);
  bucket.chars += chars;
  const hasMore = rowIndex >= 0;
  const nextCursor = hasMore ? `${rowIndex}:${end == null ? rows[rowIndex].text.length : end}` : null;
  return stewardForeignProjection({
    ok: true, sessionId, title: stewardSanitizeText(redact(String(head.title || ''))), tail,
    turnSeqs: [...pageTurns].filter(seq => seq != null).sort((a, b) => a - b),
    truncated: hasMore, clippedRows, chars, hasMore, nextCursor,
    recentUserRequest: stewardRecentUserRequest(session),
    activityGuidance: getPromptPack(config && config.locale).steward.activityGuidance,
    relatedThreads: threadRelatedThreads(head, await listSessions()),
    quota: { callsUsed: bucket.calls, callsMax: null, charsUsed: bucket.chars, charsMax: budgetChars,
      callsRemaining: null, charsRemaining: Math.max(0, budgetChars - bucket.chars) },
    rows: kept,
  });
}

// ════════════════════════════════════════════════════════════════════════════
// 线程族(tier edit)—— 建线程/递话/改名。全部返回 undoRef 并落决策日志。
// ════════════════════════════════════════════════════════════════════════════

// 后台回合:fire-and-forget(不 await)。管家回合不能被线程回合的时长绑住 —— 它要立刻回一句
// 「已经交给线程 X 去做了」。异常只写 logEvent,绝不冒泡到工具返回值(那会让模型以为没交出去)。
// 116-4(27 号文 §11.7「第四源 sessionTurns」):回合 settle 之后把【身份与成败】落到会话头上。
// 为什么必须落盘:收件箱只读磁盘上的账,而会话头本来没有任何回合成败字段(实测:回合失败后头上只有
// summary 里那句人话,那是渲染不是信号),runSessionTurn 的返回值只活在这一个进程的这一个闭包里。
// 不落盘 = 第四源永远只能报「跑完了」,报不出「挂了」。
//   · launchedBy 在这里补写,是为了覆盖 thread_continue(递话给用户自己的会话,它没经过 createSession)；
//     quick_ask / thread_new 已经在建会话时就地写过了,这里重复写是幂等的。
//   · 成败取【内层】result.result.ok —— 外层 ok 只表示「这次调用完成了」,一条 HTTP 500 的回合外层
//     仍然是 ok:true(116-4 实测),拿外层判会把每一条失败回合都说成收工。
//   · 走 updateSessionMeta 而不是 loadSession+saveSession:settle 那一刻会话可能还在收尾窗口里,
//     这条通道会延后到 settle 之后在【重新装载的副本】上重放,不会用陈旧正文盖掉回合刚写的消息。
//   · 旁路纪律:写失败只是少一条账(第四源退化成报 done),绝不反噬回合本身。
function stewardRecordLaunchOutcome(sessionId, result) {
  const sid = safeSessionId(sessionId);
  if (!sid) return Promise.resolve(null);
  const inner = (result && typeof result === 'object' && result.result && typeof result.result === 'object') ? result.result : null;
  const aborted = !!(inner ? inner.aborted : (result && result.stopped));
  const ok = inner ? inner.ok === true : !!(result && result.ok);
  return updateSessionMeta(sid, {
    launchedBy: 'steward',
    stewardLastTurn: {
      seq: Math.max(0, Number(result && result.turnSeq) || 0),
      ok,
      aborted,
      errorClass: String((inner && inner.errorClass) || ''),
      at: nowIso(),
    },
  }).catch(() => null).finally(() => {
    if (typeof StewardHooks.onThreadSettled === 'function') StewardHooks.onThreadSettled();
  });
}

// 管家刚发起、但 runSessionTurn 还没走到登记 turnSettlers 的那几个 await 窗口里,线程既不在 activeChildren
// 也不在 turnSettlers:修前前后脚两次 steward_thread_continue 都判成 turn 通道,第二个回合在 09 里把第一个
// superseded 掉,第一句话连回合一起没了,两次却都回 ok:true。这里【同步】记一笔,13q 的通道判定据此判成
// queued(settling)。回合整个结束(不论成败)才摘掉;回合真跑起来之后 activeChildren 会先于它命中(steer)。
const stewardLaunchingTurns = new Set();
function stewardLaunchTurn(input, tool) {
  const launchSid = String(input.sessionId || '');
  if (launchSid) stewardLaunchingTurns.add(launchSid);
  let registered;
  const registration = new Promise(resolve => { registered = resolve; });
  // 第二轮工具走查(F17):给管家发起的那条【用户消息】盖上出身标 meta.origin:'steward'(随会话正文落盘,与收件箱回合的
  // origin:'inbox' 同一个机制)。修前 thread_new 的委托书、thread_continue 的递话、quick_ask 的问题落在线程里都是一条
  // 没有任何标记的 role:'user' 消息,于是 steward_memory_write 的来源校验(13l stewardSourceIsUserMessage)分不出
  // 「用户本人说的」和「管家自己转发过去的」—— 管家能把自己写的委托书引成「用户说过」记进记忆。
  // 只覆盖 Provider 引擎的线程(09 runOpenAiTurn 才接 messageMeta;CLI 引擎的回合不接,与收件箱标同一个边界)。
  // input 里调用方自己给的 messageMeta 优先(目前没有)。
  const promise = runSessionTurn({ messageMeta: { origin: 'steward', tool: String(tool || '') }, ...input, onEvent: event => {
    // Capture the identity and anchor emitted by THIS driver, never a later current-session lookup.
    if (event && event.type === 'session' && event.session && event.session.id === launchSid) {
      const execution = event.execution;
      registered(execution && typeof execution === 'object' ? {
        execution: { ...execution }, rewindTargetTurnSeq: (Number(event.session.turnSeq) || 0) + 1,
      } : null);
    }
  } });
  promise.registration = registration;
  promise.finally(() => { registered(null); if (launchSid) stewardLaunchingTurns.delete(launchSid); }).catch(() => {});
  promise.then(result => {
    logEvent({ kind: 'steward_turn_done', tool, sessionId: String(input.sessionId || ''), ok: !!(result && result.ok), stopped: !!(result && result.stopped) });
    void stewardRecordLaunchOutcome(input.sessionId, result);
  }).catch(error => {
    logEvent({ kind: 'steward_turn_error', tool, sessionId: String(input.sessionId || ''), message: String((error && error.message) || error).slice(0, 400) });
    // 回合整个抛出来(不是回合内部失败):同样要留一条落盘的账,否则第四源看见 turnSeq 没动
    // 就什么都不报,管家永远不知道自己派出去的这一趟连回合都没起来。
    void stewardRecordLaunchOutcome(input.sessionId, { result: { ok: false, aborted: false, errorClass: 'launch_error' } });
  });
  return promise;
}

// ── 116-3 P0-2(对抗审查:线程族三工具在三条路径上都没有接入权限门)────────────────────────
// 触发面判定。`ctx.trigger` 由回合运行器的三个执行点显式给:
//   · 模型在结构化回复里声明的 actions —— 透传本回合的 'user' | 'inbox';
//   · 确定性自理(七道闸那条路)—— 恒 'inbox',并另带 ctx.selfServe = true;
//   · 用户在界面上亲手按下按钮的 act 执行路径 —— 恒 'user'。
// 这里用的是 trigger 而【不是】 userPressed:后者的读者按 06i 契约与静态锁只有三处(config_set /
// skill_toggle 的「须确认」判定,加 117z-E2 给 thread_permission 的桌面【放宽】那一处),
// 「按钮 ≠ 扩权」—— 线程族的在不在场判定不该去挤那个字段。
// 其余调用面(工具循环里模型直接调、进程内直调)没有 trigger —— 保持既有直递语义。
// 核心层的失败可能是裸串,也可能是 apiFailure 的 {code,message,params}:修前一律 String() 掉,模型看到的拒绝理由
// 是「[object Object]」。
function stewardErrorDetail(error) {
  if (error && typeof error === 'object') return String(error.message || error.code || '');
  return String(error == null ? '' : error);
}
function stewardTriggerOf(ctx) {
  const raw = String((ctx && ctx.trigger) || '');
  return raw === 'inbox' || raw === 'user' || raw === 'external' ? raw : '';
}
function stewardUserDirected(ctx) {
  return stewardTriggerOf(ctx) === 'user' || (typeof ExternalBotHooks.isAuthorizedContext === 'function' && ExternalBotHooks.isAuthorizedContext(ctx) === true);
}
// 这一次调用是不是「模型自己在无人值守回合里决定要动别的线程」。
// 三者都不是它:① 用户就在跟前(trigger==='user',含亲手按按钮那条路);② 13h 的【确定性自理】(七道闸,
// ctx.selfServe === true —— 它按事件类别走的是 §3.3 真值表的 'failed' 档,不是 'relay' 档,已经在
// stewardSelfServeGate 里逐条判过了,这里再按 relay 判一次会把「失败自动重试」也一起挡掉);
// ③ 没有 trigger 的调用面(进程内直调/工具循环)—— 保持既有直递语义。
// ctx 由 13h 构造,模型碰不到它;args 里同名字段一概不作数(与 userPressed 同一条纪律)。
function stewardUnattendedByModel(ctx) {
  if (!ctx || ctx.selfServe === true) return false;
  return stewardTriggerOf(ctx) === 'inbox';
}
// 无人值守(inbox)触发时线程族的自理清单闸:relay 没勾选就只提议。
function stewardRelayAutoAllowed(config) {
  const auto = (config && config.stewardAutoActions && typeof config.stewardAutoActions === 'object') ? config.stewardAutoActions : {};
  return auto.relay === true;
}

// thread_new 的 missionId 是不是一个真实存在的事项(见调用处的说明)。
async function stewardMissionExists(stewardMissionIdArg) {
  const missionId = safeSessionId(stewardMissionIdArg);
  if (!missionId) return false;
  if (await readMissionContainer(missionId).catch(() => null)) return true;
  const own = await stewardReadSessionHead(missionId);
  if (own && own.id && stewardRawKind(own) !== 'steward') return true;
  const metas = await listSessions().catch(() => []);
  return metas.some(meta => meta && !sessionMetaIsSteward(meta) && String(meta.missionId || '') === missionId);
}

// 10) steward_thread_new —— 委托书。原话逐字在最前,管家补充经中和后进围栏(见 06i buildStewardBrief)。
// A step list is one DAG owned by one new thread, never cross-thread completion links.
function stewardDelegationSteps(raw, args, config) {
  if (raw === undefined) return { steps: null };
  if (!Array.isArray(raw) || raw.length < 2 || raw.length > 8) return { error: 'steps requires 2–8 ordered steps' };
  if (args.missionId || args.relatedSessionId || args.brief?.playbook) return { error: 'steps requires a new standalone mission, without missionId, relatedSessionId or playbook' };
  const cap = Number(config.subagentMaxPerTurn) || 0;
  if (cap <= 0) return { error: 'agent_delegation_disabled' };
  if (Number(config.agentWorkflowMaxNodes) === 0) return { error: 'agent_workflow_disabled' };
  if (raw.length > cap || (Number(config.agentWorkflowMaxNodes) > 0 && raw.length > Number(config.agentWorkflowMaxNodes))) return { error: 'steps exceeds the configured agent budget' };
  if (!stewardOpenAiFallback(config)) return { error: 'steps requires a configured provider' };
  const steps = [];
  for (const [i, row] of raw.entries()) {
    if (!row || typeof row !== 'object' || typeof row.task !== 'string' || !row.task.trim() || row.task.length > 2000 || !['read', 'edit', 'exec'].includes(row.toolTier || 'read') || Object.keys(row).some(k => !['task', 'toolTier'].includes(k))) return { error: `invalid step ${i + 1}: task (1–2000 chars) and toolTier (read/edit/exec) only` };
    steps.push({ id: 'step-' + (i + 1), task: row.task.trim(), toolTier: row.toolTier || 'read', dependsOn: i ? ['step-' + i] : [], maxRetries: 0 });
  }
  return { steps };
}
async function stewardImplThreadNew(args, ctx, config) {
  const brief = (args.brief && typeof args.brief === 'object') ? args.brief : null;
  if (!brief || !String(brief.userText || '').trim()) {
    return stewardFail('invalid_request', 'brief.userText is required and must contain the user\'s own words verbatim');
  }
  // 116-3 P0-2:收件箱触发的「自己新开线程」要用户先在自理清单里留着这一项(§11.1 第 6 项)。
  const delegation = stewardDelegationSteps(args.steps, args, config);
  if (delegation.error) return stewardFail('invalid_request', delegation.error, { reason: 'delegation_unavailable' });
  // 新线程还没有目标线程可判权限,所以这里只有清单这一道闸;新线程自己的权限由全局默认档决定。
  if (stewardUnattendedByModel(ctx)) {
    const auto = (config && config.stewardAutoActions && typeof config.stewardAutoActions === 'object') ? config.stewardAutoActions : {};
    if (auto.newThread === false) {
      return stewardFail('propose_required', '「自己新开线程」已经关掉,无人值守时只能把它作为提议交给用户,不要重试', {
        reason: 'self_serve_off', tool: 'steward_thread_new',
      });
    }
  }
  // ── 129h 跑 playbook(31 号文 §2.7 放①)────────────────────────────────────────────────
  // **有意不新加工具**。「跑一个 playbook」这件事拆开看就是:按模板组装一段话 → 开一条线程去办。
  // 后半截已经在这个函数里了,而且带着全套闸(工作区表、权限档、分档、事项、undoRef、决策账本)。
  // 另起一个 steward_playbook_run 要么把这些重抄一遍,要么转头调这里 —— 两头都不如直接长在这。
  // (§2.7 的原话也是「同一条执行路径,不另写」。)
  const pbAsk = (brief.playbook && typeof brief.playbook === 'object' && !Array.isArray(brief.playbook)) ? brief.playbook : null;
  let pbResolved = null;
  if (pbAsk) {
    const wantId = String(pbAsk.id || '').trim();
    if (!wantId) return stewardFail('invalid_request', 'brief.playbook.id is required');
    // 可用性直接读既有结论(06 的 listPlaybooksWithAvailability,与技能库面板同一份),不另写判据。
    const list = await listPlaybooksWithAvailability(config).catch(() => []);
    const pb = list.find(one => one && one.id === wantId) || null;
    if (!pb) {
      return stewardFail('not_found', `没有叫 "${stewardSanitizeText(wantId)}" 的 playbook —— 先用 steward_playbooks 看一眼有哪些,别猜 id`, {
        reason: 'playbook_not_found',
      });
    }
    // 不可用就别开:缺的是能力(联网/桌面/命令…),开出来的线程第一步就卡住,而用户要等到那时才知道。
    if (pb.available === false) {
      return stewardFail('invalid_request',
        // 字段名是 unavailableReason,**不是** reason(06 的 evalPlaybookAvailability 口径)——
        // 写错的话这里永远吐兜底那句「所需能力没就绪」,用户看不到真原因,而断言还是绿的:
        // 与 129b 那次「字段名写成 description 而非 desc,整列全空」同一个模具。
        `playbook「${stewardSanitizeText(pb.title)}」现在跑不了:${stewardSanitizeText(String(pb.unavailableReason || '所需能力没就绪'))} —— 把这句告诉用户,别开线程`, {
          reason: 'playbook_unavailable', playbookId: pb.id,
          missingCaps: (Array.isArray(pb.missingCaps) ? pb.missingCaps : []).map(c => stewardSanitizeText(String(c || ''))).slice(0, 6),
        });
    }
    // 参数必须齐。比前端严,理由见 06i stewardPlaybookMissingInputs 的头注:
    // 弹窗前面坐着用户,留空是他的选择;管家填空是猜,猜出来的空串会让模板在错的地方动手。
    const missing = stewardPlaybookMissingInputs(pb, pbAsk.inputs);
    if (missing.length) {
      return stewardFail('invalid_request',
        `这个 playbook 还缺 ${missing.length} 个参数没填:${missing.map(m => m.label).join('、')} —— 去问用户要,别自己编`, {
          reason: 'playbook_inputs_missing', playbookId: pb.id, missing,
        });
    }
    pbResolved = { id: pb.id, title: pb.title, text: stewardAssemblePlaybookPrompt(pb, pbAsk.inputs) };
  }
  const composed = buildStewardBrief(pbResolved
    ? { ...brief, playbookId: pbResolved.id, playbookTitle: pbResolved.title, playbookText: pbResolved.text }
    : brief);
  const requestedMissionId = args.missionId ? safeSessionId(args.missionId) : '';
  if (args.missionId && !requestedMissionId) return stewardFail('invalid_request', 'invalid missionId');
  // 第二轮工具走查(F14):missionId 格式合法但【根本没有这个事项】时,修前照样把新线程挂到它名下 —— 凭空造出一个
  // 只有一条线程、没有事项文件的「幽灵事项」(relatedSessionId 同样的错早就返回 not_found 了)。
  // 认三种真事项:有事项容器文件的;就是某条线程自己的 id(未归类事项的 missionId === 线程 id,不是管家会话);
  // 已有线程头上的 missionId 指着它的。都不是 -> not_found,排在 createSession 之前(拒的是「开线程」,不是开完再回滚)。
  if (requestedMissionId && !await stewardMissionExists(requestedMissionId)) {
    return stewardFail('not_found', `missionId ${requestedMissionId} 不是一个已有的事项(没有这个事项,也没有这条线程);不确定就省掉 missionId 让新线程自成事项,不要重试同一个值`, { reason: 'mission_not_found' });
  }
  // W7:cwd 选择顺序(见文件头 stewardResolveThreadCwd):明确给的 > 事项记着的 > 相关线程的 > 新开。
  // 给了但不合法(已知工作区之外的 cwd、不存在的 relatedSessionId)一律拒,不静默回落;排在 createSession
  // 之前:拒的是「开线程」,不是「开完再回滚」。
  const cwdPick = await stewardResolveThreadCwd(args, config, requestedMissionId);
  if (!cwdPick.ok) return cwdPick.fail;

  const session = await createSession({
    title: args.title ? String(args.title).slice(0, STEWARD_TITLE_MAX) : undefined,
    cwd: cwdPick.cwd,
    // 121-K3(§4.1 来源三值):出身在 createSession 那一次写死。与下面的 createdBy 是两个字段、
    // 一个事实的两面 —— createdBy 是权限判据(桌面权限只开给管家自己开的线程),origin 是展示与
    // 索引口径(界面上的来源图形)。不合并成一个:前者是布尔语义的闸,后者要三值。
    origin: 'steward',
  });
  // 选择顺序第 ④ 步:在 Ruyi 根下派生子工作区,登记进如意自己那张表(不进常用工作区)。写在 createSession
  // 之后是为了拿到真线程 id(标题为空时 slug 要回落到它),改的是内存副本,跟着下面那一次 saveSession
  // 一起落盘,零额外写。派生不成(根不可用/撞名试满/写失败)就保持 createSession 刚落的回落值。
  let cwdSource = cwdPick.source;
  if (cwdPick.cwd === undefined) {
    const derivedCwd = await stewardDeriveThreadCwd(args.title, session.id, config);
    if (derivedCwd) session.cwd = derivedCwd;
    else cwdSource = 'default';
  }
  if (cwdPick.relatedSessionId) session.relatedSessionId = cwdPick.relatedSessionId;
  if (delegation.steps) delegation.steps = delegation.steps.map(step => ({ ...step, resources: [(step.toolTier === 'read' ? 'read:' : '') + 'workspace:' + session.cwd] }));
  session.kind = 'mission';                                   // 线程 = 任务线程(不是速问)
  session.launchedBy = 'steward';                             // 116-4:收件箱第四源的「管家关心」标
  // 117z-E2 提交①(27 号文 §11.21.3):【出身】标 —— 这条线程是管家自己开的。
  // 为什么不复用既有的两个标:`launchedBy:'steward'` 也会打在 thread_continue 递话进【用户自己的】
  // 会话那一路(见本文件 stewardMarkLaunched),`titleSource:'steward'` 语义是标题来源、quick_ask 还
  // 会删掉它 —— 两个都答不出「这条线程是谁开的」。放宽桌面权限的目标合法性判据(13k 的
  // stewardImplThreadPermission)只读这一个字段;它只在这里与 quick_ask 各写一次,此后终身不变,
  // 也【不在】 02 的 applySessionMetaPatch 白名单里(PATCH 改不动它,见那里的注释)。
  session.createdBy = 'steward';
  // 117s-A D2(§11.13 ⑤a):管家给的 title【不是】人起的名字(模型只是把用户那句话抄了一遍),
  // 覆写掉 createSession 刚写下的 'user',否则 116-5 的自动摘要永远跳过 —— 白名单与理由见 02:1066。
  if (args.title) session.titleSource = 'steward';
  if (requestedMissionId) session.missionId = requestedMissionId; // 归入既有事项;否则 createSession 已置 missionId = 自身 id
  // 委托书落盘:原话与管家补充【分开存】,供 117 显示与用户「改一下」;不把拼好的整段存成一坨。
  session.brief = {
    schema: 1,
    by: 'steward',
    createdAt: nowIso(),
    userText: composed.userText,
    supplement: composed.supplement,
    // 132a:分字段版本(goal/acceptance/context/preferences/constraints,已裁剪),委托书带按它画列表;老线程没有它就回落 supplement。
    fields: composed.fields,
    truncated: composed.truncated,
    memoryIds: composed.memoryIds,
    // 129h:真跑了 playbook 时,这一格记【跑的那一个】。修前它只记 brief.playbookId ——
    // 那个字段的老语义是「建议线程参考的 id」(一行文字,没人加载它);现在两种来源都落到同一格,
    // 界面与事后对账不必分辨是「参考过」还是「跑过」的 id —— 真跑过的那一次另有决策账本作证。
    playbookId: pbResolved ? pbResolved.id : String(brief.playbookId || ''),
    ...(delegation.steps ? { steps: delegation.steps } : {}),
  };
  // 117l D7:按任务复杂度选档(缺省 strong)—— 写在 saveSession 之前,跟着同一次落盘走,零额外写。
  const tiered = StewardHooks.applyThreadTier(session, args.tier, config);
  await saveSession(session);
  // 116g:显式指定了事项就写反向索引(事项文件不存在 = 「未归类」,missionIndexAdd 自身 no-op ——
  // 新会话的 missionId === sessionId 那条常规路径永远不会凭空建出一个事项文件)。
  if (requestedMissionId) await missionIndexAdd(requestedMissionId, session.id);
  // W7:事项第一次有了工作区就记进事项容器(之后这个事项里开的线程走选择顺序第 ② 步)。
  // 回落到默认工作区的那一次不记 —— 那不是谁选的,是派生失败的兜底。
  if (requestedMissionId && cwdSource !== 'default') await stewardRecordMissionWorkspace(requestedMissionId, session.cwd);

  const launched = stewardLaunchTurn({
    sessionId: session.id,
    message: composed.text,
    cwd: session.cwd,
    source: 'steward',
    requestMeta: { tool: 'steward_thread_new' },
    ...(delegation.steps ? { delegationPlan: { nodes: delegation.steps, context: composed.text } } : {}),
  }, 'steward_thread_new');

  // 117d 第 0 步:回退锚点。undoRef.sessionId 是「删掉这条线程」的把手,但整单回退要的是
  // 【被递那一回合将拥有的 seq】—— 与 09-workflow 的 plannedTurnSeq 同口径(session.turnSeq + 1);
  // 新建会话 turnSeq 恒为 0,故委托书是第 1 回合。rewindSession 按这个 seq 定位首条用户消息。
  const registration = await launched.registration;
  const undoRef = registration ? { kind: 'thread_new', sessionId: session.id, ...registration } : { kind: 'none', sessionId: session.id };
  stewardAppendDecision({
    tool: 'steward_thread_new',
    args: {
      title: session.title, missionId: session.missionId, briefChars: composed.text.length,
      supplementChars: composed.supplement.length, truncated: composed.truncated, tier: tiered.tier,
      // W7:目录是怎么选出来的(explicit/mission/related/mission_thread/new/default)——行动流水事后
      // 答得出「为什么这条线程开在这儿」。只记来源不记全路径(决策日志也进管家的上下文)。
      cwdSource,
      ...(delegation.steps ? { steps: delegation.steps.length } : {}),
      // 129h:跑过 playbook 的那一次,行动流水要看得出来是【哪一个】、正文有多长 ——
      // 「管家自己起了一条线程」与「管家按你存下的那个流程起了一条线程」是两件事。
      ...(pbResolved ? { playbookId: pbResolved.id, playbookChars: pbResolved.text.length } : {}),
    },
    targetSessionId: session.id,
    permissionMode: stewardThreadPermissionMode(session, config),
    mayAct: 'auto',
    undoRef,
    basis: { memoryIds: composed.memoryIds, ...(pbResolved ? { playbookId: pbResolved.id } : {}) },
  });
  return {
    ok: true, sessionId: session.id, missionId: sessionMissionId(session), title: session.title,
    // W7:开在哪个工作区(名字,不给全路径)、为什么开在那儿。
    workspace: (stewardWorkspaceNameOf(session.cwd, config) || { name: '' }).name, cwdSource,
    briefTruncated: composed.truncated, tier: tiered.tier, engine: tiered.engine, undoRef,
    ...(delegation.steps ? { delegation: { kind: 'ordered_steps', steps: delegation.steps, coordinatorSessionId: session.id, status: 'accepted' } } : {}),
    ...(pbResolved ? { playbook: { id: pbResolved.id, title: pbResolved.title, chars: pbResolved.text.length } } : {}),
  };
}

// ────────────────────────────────────────────────────────────────────────────
// 121-K3(34 号文 §4.5「管家对你正坐着的线程」):用户此刻就坐在这条线程前面时,管家【不动手】。
// 具体是:不代答它的提问(不主动 steward_thread_continue)、不递话、不改它的权限与模型。
// **可以读**(steward_thread_read 不过这道门)—— 用户问「那条在干嘛」时管家还得答得上来。
//
// 事实源与 13e 的索引行 seatedBy 同一份:13r 的在场快照(SSE 连接自报的 lens/sessionId),
// 经 00-boot 的延迟绑定命名空间取(13k 拼在 13r 之前,直引是前向边)。
// 读不到一律当【没人坐着】= 修前行为:这道门管的是打扰纪律,不是权限门(那一道在别处,不受影响),
// 所以 fail-open —— 在场信号缺席时让管家停摆,比偶尔插一句话糟得多。
function stewardSeatedByUser(sessionId) {
  const sid = String(sessionId || '');
  if (!sid) return false;
  try {
    const presence = typeof EventStreamHooks.presenceSnapshot === 'function' ? EventStreamHooks.presenceSnapshot() : [];
    // 2026-10(用户:「用户在看提问、权限,管家被立刻唤醒也不要插手」):第二种「在跟前」—— 任一视角的连接在
    // viewing 里报了这条线程(它的权限/提问弹窗、展开的待办小窗、管家焦点栏正摆在用户面前,且人在,见 13r 头注)。
    // 同一个单点:代批(13l steward_decide)、代答、递话、续跑的门都从这里过,不各补一份。
    return Array.isArray(presence) && presence.some(row => row && (
      (row.lens === 'classic' && String(row.sessionId || '') === sid)
      || (Array.isArray(row.viewing) && row.viewing.includes(sid))));
  } catch { return false; }
}
// 128f-⑪(用户拍板 A):管家盯着的线程,权限请求至少等 600 s —— 04 的 permissionWaitMs 迟绑定的 steward 一格填在这里
// (本文件是第一个同时够得着 06i 的 stewardWatchedThread 与本文件 stewardSeatedByUser 的地方)。三个条件同时成立才算:
// 管家开着;线程由管家盯着(stewardWatchedThread);用户此刻没坐在 / 没看着它(那是当面弹的,按基础时限等 ——
// 缺省不限时,128f 时代的「120 s」已经不是缺省值 —— 管家也不插手,见上面的 stewardSeatedByUser)。
// WCW_TEST_STEWARD_PERMISSION_WAIT_MS 是测试口(e2e 不等 10 分钟)。
// 注:04 的 permissionTimeoutMs 自 2026-09-24 起缺省 0(不限时),那时这 600 s 只是 max(不限时, 600 s) = 仍不限时;
// 只有用户在设置里给权限请求配了时限,这一格才把它抬到至少 10 分钟。2026-10 的放宽(见下面 stewardMediatesPermissions)
// 【不】碰这一格:用户给自己开的线程配了时限,那是他的意思,不因为线程按智能自动在跑就被悄悄拉长到 10 分钟。
const STEWARD_MEDIATED_PERMISSION_WAIT_MS = 600000;
function stewardMediatedPermissionWaitMs(sessionId, config, head) {
  if (!config || config.stewardEnabledV1 !== true) return 0;
  const sid = String(sessionId || '');
  if (!sid || sid === STEWARD_SESSION_ID || !head || String(head.id || '') !== sid) return 0;
  if (!stewardWatchedThread(head, sid, sessionMissionId(head) || sid)) return 0;
  if (stewardSeatedByUser(sid)) return 0;
  const test = Number(process.env.WCW_TEST_STEWARD_PERMISSION_WAIT_MS);
  return Number.isFinite(test) && test > 0 ? test : STEWARD_MEDIATED_PERMISSION_WAIT_MS;
}
PermissionWaitHooks.steward = stewardMediatedPermissionWaitMs;
// 2026-10(用户拍板「用户自己开的线程可以适当放宽」):「这条线程停下来问的权限请求归管家处理」的单点 ——
// 13q 回合收尾的「留给你」通知与「追问一次」都读它。比上面那条等待判据宽:
//   · 管家开着、不是管家自己的会话、用户此刻没坐在 / 没看着它(stewardSeatedByUser);
//   · 用户按过「别盯了」(stewardWatch:false)—— 不算,那是用户说「这条我自己看着」;
//   · 管家盯着的线程(stewardWatchedThread)、定时任务开的线程 —— 算;
//   · 2026-10 放宽:用户自己开、按「智能自动」在跑的线程 —— 也算。用户把档位定成智能自动,就是把「停下来问的
//     那几条」交给了管家;代批本身仍要过 06i 的十道闸(闸 3 同样只认显式「别盯了」)。
function stewardMediatesPermissions(sessionId, config, head) {
  if (!config || config.stewardEnabledV1 !== true) return false;
  const sid = String(sessionId || '');
  if (!sid || sid === STEWARD_SESSION_ID || !head || typeof head !== 'object' || String(head.id || '') !== sid) return false;
  if (head.stewardWatch === false || stewardSeatedByUser(sid)) return false;
  if (stewardWatchedThread(head, sid, sessionMissionId(head) || sid)) return true;
  if (threadOriginOf(head) === 'schedule') return true;
  return stewardThreadPermissionMode(head, config) === 'auto';
}
// 结构化拒绝:错误码 'seated_by_user',人话直说「你正在这条线程里,我不插手」。
// 与 propose_required 那一族一样带 `reason`,行动流水事后能分清「管家没做」的两种原因。
function stewardSeatedFail(sessionId) {
  return stewardFail('seated_by_user',
    '你正在这条线程里(或正看着它的提问/权限),我不插手 —— 等你离开它我再接手;要我现在就动手,先把这条线程留给我',
    { sessionId: String(sessionId || ''), reason: 'seated_by_user' });
}

// ── 129g 代答要有依据(31 号文 §2.5)──────────────────────────────────────────────────────
// 修前的洞:线程挂着一道给用户的提问时,管家把 message 递过去就【直接答进那道题】—— 而且不检查
// 这句话是谁说的。用户在跟前时那是他的原话(本来就该这样);无人值守回合里那就是管家自己编的一句,
// 线程却分不出来(两条路同一个 decideIntervention,落到线程眼里都是「用户答了」)。
// 于是本刀的口径:**替用户说话之前,先说清这句话的出处,而且出处要服务端核得动。**
//
// 两种出处各有各的核法,都不做相似度 —— J12 那一轮已经用实测证伪过「中段相似度分得清改述与反话」
// (改述 0.176 < 反话 0.556,顺序是反的),这里不再走回同一条路:
//   · 记忆:给条目 id → 回库里查,必须真在、仍 active、没过期。编一个 id 当场穿帮。
//   · 委托书:给**原文片段** → indexOf 逐字核对。片段有下限,否则「是」「均价」这种碎片到处都能命中。
function stewardAnswerBasisOf(args) {
  const raw = (args && typeof args.answerBasis === 'object' && args.answerBasis && !Array.isArray(args.answerBasis)) ? args.answerBasis : null;
  if (!raw) return { memoryIds: [], briefQuote: '' };
  const ids = Array.isArray(raw.memoryIds) ? raw.memoryIds : (raw.memoryIds ? [raw.memoryIds] : []);
  return {
    memoryIds: ids.map(v => String(v == null ? '' : v).trim()).filter(Boolean).slice(0, STEWARD_ANSWER_BASIS.maxMemoryIds),
    briefQuote: String(raw.briefQuote == null ? '' : raw.briefQuote).trim().slice(0, STEWARD_ANSWER_BASIS.quoteChars),
  };
}

// 委托书的可引正文 = 用户原话 ＋ 管家补充(两段都是【开线程那一刻就定下】的文本,事后不会变)。
// 不是管家开的线程没有 brief —— 那就引不了委托书,只能靠记忆,或者照旧转用户。
function stewardBriefTextOf(head) {
  const b = (head && head.brief && typeof head.brief === 'object') ? head.brief : null;
  if (!b) return '';
  return [String(b.userText || ''), String(b.supplement || '')].filter(Boolean).join('\n');
}

// 回 { ok, resolved:{memoryIds,briefRef}, misses:[人话] }。ok 的判据是**至少有一条真的落实了**,
// 不是「模型填了字段」:填了四个不存在的 id 与一个字都没填,是同一件事。
async function stewardResolveAnswerBasis(wanted, head) {
  const resolved = { memoryIds: [], briefRef: '' };
  const misses = [];
  if (wanted.memoryIds.length) {
    const store = await stewardReadMemoryStore().catch(() => ({ entries: [] }));
    const nowMs = Date.now();
    const byId = new Map((Array.isArray(store.entries) ? store.entries : [])
      .map(e => [String((e && e.id) || ''), e]));
    for (const id of wanted.memoryIds) {
      const entry = byId.get(id);
      if (!entry) { misses.push(`记忆 ${id} 不在库里`); continue; }
      // 被否决的条目不能当依据 —— 用户否掉它就是在说「别再按这条办」。过期同理(126-M02:
      // 时效是过滤不是删除,条目还在库里,但它不该再替用户拿主意)。
      if (entry.state !== 'active') { misses.push(`记忆 ${id} 已经被你否决过`); continue; }
      if (memoryIsExpired(entry, nowMs)) { misses.push(`记忆 ${id} 已过期`); continue; }
      if (entry.basis === 'activity') { misses.push(`记忆 ${id} 是行动推断,不能代替用户明确答复`); continue; }
      resolved.memoryIds.push(id);
    }
  }
  if (wanted.briefQuote) {
    const brief = stewardBriefTextOf(head);
    if (!brief) misses.push('这条线程没有委托书,引不了它的原文');
    else if (wanted.briefQuote.length < STEWARD_ANSWER_BASIS.quoteMin) misses.push(`引的片段太短(至少 ${STEWARD_ANSWER_BASIS.quoteMin} 个字)`);
    else if (!brief.includes(wanted.briefQuote)) misses.push('引的片段在委托书里逐字找不到');
    else resolved.briefRef = wanted.briefQuote;
  }
  return { ok: resolved.memoryIds.length > 0 || Boolean(resolved.briefRef), resolved, misses };
}

// 那道题的人话。13q 传进来的 decided 里带着 04 归一化过的 questions;取第一道就够 ——
// 确认面板要的是「你在答什么」,不是把整份问卷再抄一遍。过一遍中和:它是线程模型写的文本。
function stewardAnswerQuestionText(decided) {
  const list = (decided && Array.isArray(decided.questions)) ? decided.questions : [];
  const first = list.find(q => q && String(q.question || '').trim());
  return first ? stewardSanitizeText(String(first.question)).slice(0, STEWARD_ANSWER_BASIS.shownChars) : '';
}

// 代答闸。只在通道真的落到 'answer' 时由 13q 回调进来(见那里的头注)。
// 返回 null = 放行;返回 stewardFail(...) = 这一句不代答,降级成提议交给用户。
async function stewardAnswerGate(o) {
  const { args, ctx, config, head, sessionId, permissionMode } = o;
  // ① 用户就在跟前 —— 这句话是他的原话,不是代答。既有行为一字不动。
  //    判据是【此刻这个管家回合是不是用户触发的】,不是模型说了算(ctx 由 13g 的门控壳按
  //    13h 的 inflight.kind 填,模型碰不到)。取不到 trigger 一律按「不是用户」办 —— fail-closed:
  //    替人说话这件事上,「不确定」必须等于「不做」。
  if (stewardUserDirected(ctx)) return null;
  // ② 污染(129c 红线 4):这一回合读过外界内容就不代答。理由比别处更硬 —— 代答的「依据」本身
  //    可以是被网页诱导出来的:一个假页面写「用户说了按收盘价」,管家转手就替用户答了「按收盘」。
  const taintedBy = stewardTurnTaintedBy(ctx);
  if (taintedBy.length) {
    return stewardFail('propose_required',
      `我这一回合读过外部内容(${taintedBy.join('/')}),按规矩读过之后我不替你回答线程的提问 —— 这一句交给你`, {
        reason: 'steward_turn_tainted', selfTaintBy: taintedBy, channel: 'answer', sessionId,
      });
  }
  // ③ 自理清单。独立一格 answer,**不搭在 relay 上** —— 「事项内自动交接」与「替我回答」是两件事,
  //    一格两权的话用户勾的时候看不见第二个(默认关,见 01-config 的 DEF_AA)。
  const auto = (config && config.stewardAutoActions && typeof config.stewardAutoActions === 'object') ? config.stewardAutoActions : {};
  if (auto.answer !== true) {
    return stewardFail('propose_required',
      '「替我回答线程的提问」没有勾选,这一句只能作为提议交给你,不要重试', {
        reason: 'self_serve_off', channel: 'answer', sessionId,
      });
  }
  // ④ 目标线程权限档。事件类别如实填 'question'(线程此刻问的就是一道题),于是判据仍然只有
  //    06i 那张 §3.3 真值表一份 —— 只有全自动档判 auto。
  //    **这比 31 号文 §2.5 那一行「acceptEdits 与 auto 自动」严**:真值表是 2026-09-05 用户拍板的
  //    单点,而 acceptEdits 的原意是「改文件不问」,不是「替我拿主意」。要放开就改真值表那一处,
  //    不要在这里另写一份档位判据。
  const mayAct = stewardMayAct(permissionMode, 'question', 'edit');
  if (mayAct !== 'auto') {
    return stewardFail('propose_required',
      `目标线程的权限档为「${stewardPermissionLabel(permissionMode)}」,我不替你回答它的提问;把这一句作为提议交给你,不要重试`, {
        reason: 'target_permission', permissionMode, channel: 'answer', sessionId,
      });
  }
  // ⑤ 依据。没有出处就照旧转用户 —— 这是 §2.5 的原话,也是这一刀的名字。
  const wanted = stewardAnswerBasisOf(args);
  const found = await stewardResolveAnswerBasis(wanted, head);
  if (!found.ok) {
    const why = found.misses.length ? found.misses.join(';') : '一条依据都没给';
    return stewardFail('propose_required',
      `这道题的答案我没有出处(${why}),不替你答 —— 要我代答,先在 answerBasis 里给出记忆条目 id 或委托书原文片段;给不出就把这道题交给你`, {
        reason: 'no_basis', channel: 'answer', sessionId, misses: found.misses,
        // 129g:把【那道题本身】带回去。降级成按钮之后 13p 要拿它拼确认清单 —— 见那里的头注:
        // 不带的话按钮上只有「接着办」三个字,用户看不见自己在答什么。
        question: stewardAnswerQuestionText(o.decided),
      });
  }
  o.used = found.resolved;   // 放行:把【核实过的】依据回给调用方记账(不记模型填了什么,记核住了什么)
  return null;
}

// 续办只接受仍存在的上传件。以 id/name 在 uploads 内重新定位,不相信客户端的 path/size。
async function stewardContinueAttachments(raw) {
  if (raw == null) return { ok: true, attachments: [] };
  if (!Array.isArray(raw) || raw.length > 12) return stewardFail('invalid_request', '最多递送 12 个上传附件');
  const root = await fsp.realpath(paths.uploads).catch(() => paths.uploads);
  const attachments = [];
  for (const item of raw) {
    const id = item && item.id, name = item && item.name;
    if (typeof id !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(id) || typeof name !== 'string' || !name || name.length > 200 || sanitizeFsSegmentName(name) !== name || /[. ]$/.test(name)) return stewardFail('invalid_request', '附件记录无效,请重新上传');
    const target = path.resolve(paths.uploads, id, name);
    const real = await fsp.realpath(target).catch(() => null);
    const stat = real && pathWithinRoot(real, root) ? await fsp.stat(real).catch(() => null) : null;
    if (!stat || !stat.isFile()) return stewardFail('attachment_missing', `附件「${stewardSanitizeText(name)}」已不可用,请重新上传`);
    const textLike = /\.(txt|md|json|js|ts|tsx|jsx|py|ps1|bat|cmd|csv|xml|svg|html|css|yaml|yml|ini|log)$/i.test(name);
    const media = /\.(png|jpe?g|gif|webp|bmp|wav|mp3|m4a|webm|ogg|flac)$/i.test(name);
    // 图片 OCR / 音频转写由上传端生成,仍按用户资料传递;文本文件的预览则重新从真实文件读取。
    const textPreview = textLike && stat.size <= 256 * 1024 ? decodeTextFileBytes(await fsp.readFile(real), true).slice(0, 12000)
      : media && typeof item.textPreview === 'string' ? item.textPreview.slice(0, 4000) : '';
    attachments.push({ id, name, path: real, size: stat.size, textPreview,
      ...(/\.(png|jpe?g|gif|webp|bmp)$/i.test(name) ? { kind: 'image' } : {}),
      ...(/\.(wav|mp3|m4a|webm|ogg|flac)$/i.test(name) ? { kind: 'audio' } : {}) });
  }
  return { ok: true, attachments };
}
// 11) steward_thread_continue —— 原话直递。undoRef 锚在递话【前】的 turnSeq(rewindSession 的主键)。
async function stewardImplThreadContinue(args, ctx, config) {
  const sessionId = safeSessionId(args.sessionId);
  if (!sessionId) return stewardFail('not_found', 'invalid sessionId');
  // 第二轮工具走查(F8):message 是【原话直递】—— 门控壳的类型校验对「数字当字符串」一贯宽松,
  // 但把 12345 当成用户的话递给线程等于模型自己编了一句原话,这里收紧到必须真是字符串。
  if (args.message != null && typeof args.message !== 'string') return stewardFail('invalid_request', 'message must be a string (the user\'s words, passed through verbatim)');
  const message = String(args.message == null ? '' : args.message);
  if (!message.trim()) return stewardFail('invalid_request', 'message is required');
  const head = await stewardReadSessionHead(sessionId);
  if (!head || !head.id) return stewardFail('not_found', `thread ${sessionId} not found`);
  if (stewardRawKind(head) === 'steward') return stewardFail('invalid_target', 'the steward session cannot be a relay target');
  const checkedAttachments = await stewardContinueAttachments(args.attachments);
  if (!checkedAttachments.ok) return checkedAttachments;
  const attachments = checkedAttachments.attachments;
  const revision = args.deliverySource ? await StewardHooks.validateDeliveryReference(sessionId, args.deliverySource, config) : null;
  if (revision && !revision.ok) return revision;
  // 121-K3(§4.5):用户正坐在这条线程前面 -> 不递话。排在权限闸【之前】:这不是「有没有权限」的问题,
  // 而是「现在不是时候」,先答这一句比先算一遍权限档诚实(也省一次配置读)。
  if (stewardSeatedByUser(sessionId)) return stewardSeatedFail(sessionId);
  // 117l D2(§11.9;用户第四轮走查第 1、6 条):这里原本只有一道 activeChildren.has -> steward.busy,
  // 两头都错(等回答的线程也算「忙」;没命中时 stewardLaunchTurn 又会 supersede 掉它)。现在按
  // 【目标状态】选通道,判定与执行的单点在 13h(经 StewardHooks.relayDeliver 延迟绑定,零前向边;
  // 四条通道各自的理由写在那里的头注),POST /api/steward/relay 走的是同一个实现。

  // 125-P0(42 号文 §1 ①):上一回合是被【停】下来的,就别自动往里递话 —— 用户按的停也好、别处
  // 掐的也好,那是一次明确的意思表示。判据在 06i 一处(本文件不自己算),排在权限闸【之前】:与上面
  // 那条「用户正坐在这条线程前面」同理,这不是「有没有权限」,是「这件事刚被停下来,不该由管家替他
  // 撤销」。条件是用户不在跟前 —— /api/steward/relay 与 /api/steward/act 都给 trigger:'user',
  // 用户自己按那枚按钮照旧递得进去。
  if (!stewardUserDirected(ctx) && stewardStoppedTarget(head, null) === 'thread') {
    return stewardFail('propose_required', stewardStoppedRefusal('thread'), {
      reason: 'target_stopped', sessionId, stopped: 'thread',
    });
  }

  // 116-3 P0-2:无人值守(收件箱)触发的递话要过两道闸 —— 自理清单勾选 + 目标线程权限档
  // (§3.5 工具面表格:线程族按目标线程权限,「每步都问」「只做计划」一律提议)。判据与
  // stewardImplDecide / stewardImplRunAction 同一写法:先算 mayAct,不是 'auto' 就 propose_required。
  const permissionMode = stewardThreadPermissionMode(head, config);
  let mayAct = 'auto';
  // 129g:先探一眼目标此刻在哪条通道上 —— **只为决定该问哪一格开关**,不作为放行依据。
  // 代答那一支归 answer 格管(见 stewardAnswerGate),不该被 relay 那一格挡下:用户勾「事项内自动
  // 交接」是要让上一条线程的结论流到下一条,与「替我回答」是两件事。
  // 探测与投递之间线程状态可能翻转,所以真正的门在 13q 的 answer 支里、在通道定下来之后 ——
  // 这里探错了顶多是多问一格开关,盖不住的那一半由那道门兜住。
  const answerProbe = typeof StewardHooks.relayChannel === 'function' ? StewardHooks.relayChannel(sessionId) : null;
  const probablyAnswer = Boolean(answerProbe && answerProbe.channel === 'answer');
  if (!probablyAnswer && stewardUnattendedByModel(ctx)) {
    if (!stewardRelayAutoAllowed(config)) {
      return stewardFail('propose_required', '「任务内自动交接」没有勾选,无人值守时的递话只能作为提议交给用户,不要重试', {
        reason: 'self_serve_off', sessionId, permissionMode,
      });
    }
    mayAct = stewardMayAct(permissionMode, 'relay', 'edit');
    if (mayAct !== 'auto') {
      return stewardFail('propose_required', `目标线程的权限档为「${stewardPermissionLabel(permissionMode)}」,管家不能在你不在场时直接往它里面递话;把它作为提议交给用户,不要重试`, {
        reason: 'target_permission', sessionId, permissionMode,
      });
    }
  }

  // 递话【前】的 turnSeq:检查点以它为锚。但 rewindSession 的主键【不是】它 —— 它按「要删的那一回合的
  // 第一条用户消息」定位,即 plannedTurnSeq = 递话前 turnSeq + 1(与 09-workflow 同口径)。117d 第 0 步
  // 补出显式字段 rewindTargetTurnSeq;turnSeq 语义保持「递话前」不变(既有消费者逐字节不受影响)。
  const beforeTurnSeq = Math.max(0, Number(head.turnSeq) || 0);
  let undoRef = { kind: 'none', sessionId };
  const basis = stewardBasisOf(args);
  // 129g:代答闸的回调。只在通道真的落到 'answer' 时被 13q 叫到;gate.used 是【核实过】的依据,
  // 放行后原样进决策账本 —— 账本记的是「服务端核住了什么」,不是「模型说它有什么」。
  const gate = { args, ctx, config, head, sessionId, permissionMode, used: null };
  // title 用【显示名】(116-5b 单点),不拿 id 冒充标题;turn 通道的启动仍是 13g 自己的
  // stewardLaunchTurn(同一个 requestMeta、同一本决策日志)—— 13h 只决定「走哪条」。
  const delivered = await StewardHooks.relayDeliver({
    sessionId, message, attachments, revision: !!revision, title: sessionDisplayTitle(head), source: 'steward_thread_continue',
    answerGuard: decided => { gate.decided = decided; return stewardAnswerGate(gate); },
    launch: async () => {
      const launched = stewardLaunchTurn({ sessionId, message, attachments, expectedCwd: String(head.cwd || ''), source: 'steward',
        ...(revision ? { expectedTurnSeq: revision.reference.latestTurnSeq, expectedDelivery: args.deliverySource, messageMeta: { origin: 'steward', tool: 'steward_thread_continue', revisionOf: revision.reference } } : {}),
        requestMeta: { tool: 'steward_thread_continue', ...(basis.origin ? { origin: basis.origin } : {}) } }, 'steward_thread_continue');
      const registration = await launched.registration;
      if (!registration) {
        await launched;
        return stewardFail('relay_failed', '目标回合未登记,这句话和附件尚未确认递送');
      }
      if (registration) undoRef = { kind: 'turn', sessionId, turnSeq: beforeTurnSeq, ...registration };
      return { undoRef };
    },
  });
  if (delivered && delivered.ok === false) return delivered;
  // 只有开了【新回合】的那一支(turn)才有可回退的锚点。答提问(answer)与插话(steer)都落在一个已有的回合里:
  // 修前 answer 交回的 undoRef 没有回合号,前端「撤回」按 0+1 回退 = 把整条线程从第 1 回合起删光;steer 交回的
  // 锚点指着正在跑的那一回合,撤回先停掉用户的回合再回退失败。这两支一律不给撤回锚点(kind:'none')。
  const deliveredChannel = String((delivered && delivered.channel) || 'turn');
  const finalUndoRef = deliveredChannel === 'turn' ? undoRef : { kind: 'none', sessionId, channel: deliveredChannel };

  stewardAppendDecision({
    tool: 'steward_thread_continue',
    // 117l D2:走的哪条通道进决策日志 —— 行动流水里「答了一道提问」与「开了一个新回合」是两件事。
    args: { messageChars: message.length, channel: String(delivered && delivered.channel || 'turn') },
    targetSessionId: sessionId,
    permissionMode,
    // 116-3 P0-2:写【真实】判定值,不再是硬编码 'auto' —— 决策日志要能事后对账
    // 「这个动作到底是不是该提议而没提议」。
    mayAct,
    undoRef: finalUndoRef,
    // 129g:代答那一支把核实过的出处并进 basis —— 行动流水里「管家替我答了那道题」必须能点开
    // 看见凭什么。没走代答(用户原话直递 / 别的通道)时 gate.used 为 null,basis 一字不变。
    basis: gate.used ? { ...basis, ...(gate.used.memoryIds.length ? { memoryIds: gate.used.memoryIds } : {}), ...(gate.used.briefRef ? { briefRef: gate.used.briefRef } : {}), answeredFor: 'user' } : basis,
  });
  return { ok: true, sessionId, ...(delivered && typeof delivered === 'object' ? delivered : {}), undoRef: finalUndoRef };
}

// 12) steward_thread_rename —— undoRef 带旧标题(一键改回)。
async function stewardImplThreadRename(args, ctx, config) {
  const sessionId = safeSessionId(args.sessionId);
  if (!sessionId) return stewardFail('not_found', 'invalid sessionId');
  // 第二轮工具走查(F8):title:{a:1} 修前被 String() 成 "[object Object]" 写进会话头(门控壳现在也会拦对象/数组,
  // 这里再收紧到「必须是字符串」—— 标题是给人看的名字,数字、布尔当标题都是模型传串了位)。
  if (args.title != null && typeof args.title !== 'string') return stewardFail('invalid_request', 'title must be a string');
  const title = String(args.title == null ? '' : args.title).replace(/[\r\n]+/g, ' ').trim().slice(0, STEWARD_TITLE_MAX);
  if (!title) return stewardFail('invalid_request', 'title is required');
  const head = await stewardReadSessionHead(sessionId);
  if (!head || !head.id) return stewardFail('not_found', `thread ${sessionId} not found`);
  if (stewardRawKind(head) === 'steward') return stewardFail('invalid_target', 'the steward session cannot be renamed by a tool');
  // 与 thread_continue 同一条忙锁:改名走 loadSession -> saveSession 的读改写,活回合期间那份内存副本会
  // 在回合的收尾 save 之后落盘,把回合刚写进去的消息用陈旧副本盖掉(会话正文缩水 = 头计数与正文行数错位)。
  // 经典壳的重命名由用户手动触发、撞上的概率低;管家是自动的,必须显式挡住。
  if (activeChildren.has(sessionId)) return stewardFail('steward.busy', `thread ${sessionId} has a turn in flight; rename it after the turn settles`);
  // 116-3 P0-2:改名同样按目标线程权限档判(§3.5 线程族整行都是「按目标线程权限」)。
  // 13h 的 stewardSelfServeAllows 末尾原有的注释说「rename 由 13g 内部的 stewardMayAct 裁决」——
  // 那句话此前是错的(内部根本没有这个裁决),这一行把它补成真的。
  const currentMode = stewardThreadPermissionMode(head, config);
  let renameMayAct = 'auto';
  if (stewardUnattendedByModel(ctx)) {
    renameMayAct = stewardMayAct(currentMode, 'relay', 'edit');
    if (renameMayAct !== 'auto') {
      return stewardFail('propose_required', `目标线程的权限档为「${stewardPermissionLabel(currentMode)}」,管家不能在你不在场时改它的标题;把它作为提议交给用户,不要重试`, {
        reason: 'target_permission', sessionId, permissionMode: currentMode,
      });
    }
  }
  const previousTitle = String(head.title || '');
  // 复用既有的会话元数据更新原语(PUT /api/sessions/:id 背后那一个),不另开第二条改名写路径。
  const session = await updateSessionMeta(sessionId, { title });
  if (!session) return stewardFail('not_found', `thread ${sessionId} not found`);
  const undoRef = { kind: 'title', sessionId, previousTitle };
  stewardAppendDecision({
    tool: 'steward_thread_rename',
    args: { title, previousTitle },
    targetSessionId: sessionId,
    permissionMode: stewardThreadPermissionMode(session, config),
    mayAct: renameMayAct,   // 116-3 P0-2:真实判定值,不再是常量
    undoRef,
    basis: {},
  });
  return { ok: true, sessionId, title, undoRef };
}

// 12a2) steward_thread_workspace —— 改一条【已有】线程在哪个目录里干活(129e;49 号文 §4)。
//
// 31 号文 §2.3 放① 只做了「开线程时选工作区」;真机上另一半更常撞见:**线程已经开在错的目录里了**
// (那份走查里四条线程含两条股票问题全落在代码仓库)。今天用户能在顶栏改(updateSessionMeta 的
// patch.cwd 就是那条路),管家不能 —— 它连提都提不出来。
//
// **围栏红线不破**:只收【工作区表】里的路径,表外一律拒;recentWorkspaces 不算(打开过 ≠ 授权过)。
// 管家写不了 workspaces 本身(forbidden 档),所以它只能在用户已经登记过的目录之间挪。
//
// 三条行为(用户 2026-09-20 拍板 ＋ 主会话定的两条):
//   ① **auto 档自动、其余档提议** —— 与「选工作区是开线程的参数、三档都可」对齐,但改【已有】线程
//      比开新线程重(脚下的地换了,后面每一回合都按新目录算),所以往紧里收一格;
//   ② 活回合期间一律拒 —— 不在回合中途换脚下的地。这与 thread_rename 同一条忙锁,但理由更硬:
//      rename 怕的是读改写竞态,这里还多一层「这一回合的工具正拿着旧 cwd 在跑」;
//   ③ 旧目录上的检查点**不迁移、不删除**,返回里明说 —— 悄悄搬走比不搬更难解释。
async function stewardImplThreadWorkspace(args, ctx, config) {
  const sessionId = safeSessionId(args && args.sessionId);
  if (!sessionId) return stewardFail('not_found', 'invalid sessionId');
  const wantRaw = String((args && args.cwd) || '').trim();
  if (!wantRaw) return stewardFail('invalid_request', 'cwd is required');
  const head = await stewardReadSessionHead(sessionId);
  if (!head || !head.id) return stewardFail('not_found', `thread ${sessionId} not found`);
  if (stewardRawKind(head) === 'steward') return stewardFail('invalid_target', 'the steward session has no working folder to change');
  // W7:与 thread_new 同一口径 —— 已知工作区清单里的【名字】也收(上下文里给的就是名字),先换成那一行的路径。
  const knownHit = stewardMatchKnownWorkspace(wantRaw, stewardKnownWorkspaces(config));
  const want = knownHit ? knownHit.path : wantRaw;
  // 围栏:只认已登记工作区(判据单点在 06i,与 steward_file_read 同一个函数)。
  const root = stewardWorkspaceRootFor(want, config);
  if (!root) {
    return stewardFail('outside_workspace', 'cwd must be one of the registered workspaces; pick a path from the workspace table', { cwd: stewardSanitizeText(want).slice(0, 200) });
  }
  // 真实落点也得在区内(链接/联接指向区外的不认),且得是一个已存在的目录:修前不存在的路径、甚至一个文件
  // 都能被设成线程的工作目录,线程下一回合直接起不来。
  const [realWant, realRoot] = await Promise.all([realpathForContainment(want), realpathForContainment(root)]);
  if (!pathWithinRoot(realWant, realRoot)) {
    return stewardFail('outside_workspace', 'that path is a link that points outside the registered workspace; pick a real folder inside it', { cwd: stewardSanitizeText(want).slice(0, 200) });
  }
  const wantStat = await fsp.stat(want).catch(() => null);
  if (!wantStat || !wantStat.isDirectory()) {
    return stewardFail('invalid_request', wantStat ? 'cwd must be a folder, not a file' : 'that folder does not exist; pick an existing folder from the workspace table', { cwd: stewardSanitizeText(want).slice(0, 200) });
  }
  if (activeChildren.has(sessionId)) {
    return stewardFail('steward.busy', `thread ${sessionId} has a turn in flight; change its working folder after the turn settles`, { sessionId });
  }
  const currentMode = stewardThreadPermissionMode(head, config);
  if (currentMode !== 'auto') {
    return stewardFail('propose_required', `目标线程的权限档是「${stewardPermissionLabel(currentMode)}」,换工作目录这件事要用户亲手按;把它作为提议交给用户,不要重试`, {
      reason: 'target_permission', sessionId, permissionMode: currentMode, cwd: stewardSanitizeText(want).slice(0, 200),
    });
  }
  const previousCwd = String(head.cwd || '');
  if (stewardSamePath(previousCwd, want)) {
    return stewardFail('not_changed', '这条线程已经在这个目录里了,不用改', { sessionId, cwd: stewardSanitizeText(previousCwd).slice(0, 200) });
  }
  // 复用顶栏那条既有写路径(updateSessionMeta 的 patch.cwd),不另开第二条。
  const session = await updateSessionMeta(sessionId, { cwd: want });
  if (!session) return stewardFail('not_found', `thread ${sessionId} not found`);
  const undoRef = { kind: 'cwd', sessionId, previousCwd };
  stewardAppendDecision({
    tool: 'steward_thread_workspace',
    args: { cwd: want, previousCwd },
    targetSessionId: sessionId,
    permissionMode: currentMode,
    mayAct: 'auto',
    undoRef,
    basis: {},
  });
  return {
    ok: true, sessionId, cwd: String(session.cwd || want), previousCwd, undoRef,
    note: '之前那些检查点仍然指向旧目录(没有迁移,也没有删除)。',
  };
}

// 12b) steward_thread_permission —— 线程权限【只降不升】(116-2a)。
// 这是永久豁免清单第 2 条(「管家不得自我扩权:放宽任一线程的 permissionMode」)的机器实现:
// 目标档必须严格比【当前生效档】更紧(STEWARD_PERMISSION_RANK 的单调性判定),否则一律
// steward.widen_forbidden —— 放宽只能由用户在界面上改,那条路上还有一道「切到全自动须二次确认」。
// 不加忙锁:116-2a 把 updateSessionMeta 的读改写竞态改成了「活回合期间延后落盘 + 内存覆盖表立刻生效」,
// 收紧对下一回合立即有效且不会盖掉在途回合刚写的消息 —— 这正是收紧最该起效的时刻,拒绝反而危险。
// 117z-E2 提交②(27 号文 §11.21.3/§11.21.5 裁决 A):本工具多一条【能力】轴 —— `capabilities.desktop`。
// 两条轴上的纪律不是同一条,但方向是同一个:**能自动的只有降,升永远要人按**。
//   · permissionMode 轴:只降不升,由 06i 的 stewardMayTightenTo 机械执行(一个字没动);
//   · desktop 轴:false(收紧)与档位轴的收紧同口径 —— 直接做;true(放宽)**恒 propose_required**,
//     含 auto 档,且目标必须是 createdBy === 'steward' 的线程,否则 invalid_target。
// 为什么放宽在 auto 档也不给自动路(§11.21.5 选项 A,用户未表态按推荐做):管家稳定层纪律 2 是
// 「任何情况下都不放宽」,而这条轴的爆炸半径是【用户的桌面】(03-bridge-guard 自己把它描述成
// "acts on everything the user owns")。例外一旦开在最高爆炸半径的面上,以后每一轴都会来要同样的例外。
// 于是「放宽」这条路上唯一的钥匙是 `ctx.userPressed === true` —— 用户在界面上亲手按下了那枚按钮
// (13q 的 POST /api/steward/act 是它全仓唯一的置 true 点)。模型自己在 args 里写 userPressed 不算数
// (13g 的门控壳把同名字段剥掉)。
async function stewardImplThreadPermission(args, ctx, config) {
  const sessionId = safeSessionId(args.sessionId);
  if (!sessionId) return stewardFail('not_found', 'invalid sessionId');
  // 两条轴都可选,但不能一条都不给(那是一次没有内容的写)。
  const hasMode = args.permissionMode != null && String(args.permissionMode) !== '';
  const capsArg = (args.capabilities && typeof args.capabilities === 'object' && !Array.isArray(args.capabilities)) ? args.capabilities : null;
  const hasDesktop = !!capsArg && typeof capsArg.desktop === 'boolean';
  if (!hasMode && !hasDesktop) {
    return stewardFail('invalid_request', 'permissionMode or capabilities.desktop is required');
  }
  const target = hasMode ? String(args.permissionMode) : '';
  if (hasMode && !PERMISSION_MODES.includes(target)) {
    return stewardFail('invalid_request', `permissionMode must be one of ${PERMISSION_MODES.join('/')}`);
  }
  const head = await stewardReadSessionHead(sessionId);
  if (!head || !head.id) return stewardFail('not_found', `thread ${sessionId} not found`);
  if (stewardRawKind(head) === 'steward') return stewardFail('invalid_target', 'the steward session has no thread permission');
  // 121-K3(§4.5):用户正坐在这条线程前面 -> 不改它的权限与模型。与递话那一处同一道门、同一条理由。
  if (stewardSeatedByUser(sessionId)) return stewardSeatedFail(sessionId);

  const current = stewardThreadPermissionMode(head, config);
  if (hasMode && !stewardMayTightenTo(current, target)) {
    return stewardFail('steward.widen_forbidden',
      `线程 ${sessionId} 当前权限是「${stewardPermissionLabel(current)}」,管家只能收紧、不能放宽或平移到「${stewardPermissionLabel(target)}」;要放宽请让用户在界面上改`,
      { sessionId, permissionMode: current, requested: target });
  }
  // ── desktop 轴的两道闸(只在放宽方向上有闸)────────────────────────────────────────────
  const wantDesktop = hasDesktop ? capsArg.desktop === true : null;
  if (wantDesktop === true) {
    // 闸一:目标必须是管家自己开的线程。用户自己的会话不归管家管,它的桌面权限在设置里改
    // (§11.21.2)—— 对那种线程连提议都不出。读的是【出身】标,不是 launchedBy(会被递话污染)。
    if (String(head.createdBy || '') !== 'steward') {
      return stewardFail('invalid_target',
        `线程 ${sessionId} 不是我开的线程,它的桌面权限只能由用户自己在设置里改;我连这个提议都不出`,
        { sessionId, reason: 'not_steward_created', capabilities: { desktop: true } });
    }
    // 闸二:恒提议。任何档位(含 auto)都走这里,只有用户亲手按下那枚按钮的那一次能穿过去。
    if (ctx == null || ctx.userPressed !== true) {
      return stewardFail('propose_required',
        `给线程开桌面权限是一次【放宽】,任何权限档都必须由你亲自按下才生效;把它作为提议交给用户,不要重试`,
        { reason: 'confirm_required', sessionId, permissionMode: current, capabilities: { desktop: true } });
    }
  }
  const previous = sessionPermissionModeOf(head);            // 档位轴的会话级旧值(null = 之前跟着全局走)
  const previousDesktop = sessionDesktopToolsOf(head);       // 能力轴的会话级旧值(null = 之前跟着全局走)
  const session = await updateSessionMeta(sessionId, {
    ...(hasMode ? { permissionMode: target } : {}),
    ...(hasDesktop ? { desktopTools: wantDesktop } : {}),
  });
  if (!session) return stewardFail('not_found', `thread ${sessionId} not found`);
  const effectiveMode = hasMode ? target : current;
  // undoRef 与既有形状同款(一键改回):动了能力轴就标 kind:'desktop',否则仍是 'permission'。
  const undoRef = hasDesktop
    ? { kind: 'desktop', sessionId, previous: previousDesktop, ...(hasMode ? { previousPermissionMode: previous } : {}) }
    : { kind: 'permission', sessionId, previous };
  stewardAppendDecision({
    tool: 'steward_thread_permission',
    args: {
      ...(hasMode ? { permissionMode: target, previous } : {}),
      ...(hasDesktop ? { capabilities: { desktop: wantDesktop }, previousDesktop } : {}),
    },
    targetSessionId: sessionId,
    permissionMode: effectiveMode,
    // 放宽那一次是【用户按的】,如实记 'user'(与 config_set 的 confirm 档同口径);其余仍是 'auto'。
    mayAct: wantDesktop === true ? 'user' : 'auto',
    undoRef,
    basis: { previousEffective: current },
  });
  return {
    ok: true, sessionId,
    permissionMode: effectiveMode, effectivePermissionMode: effectiveMode, previousEffective: current, previous,
    ...(hasDesktop ? { desktopTools: wantDesktop, previousDesktopTools: previousDesktop } : {}),
    undoRef,
  };
}

// 15b) steward_thread_note —— 既有线程的【插话补充】(116-2b,§3.5 委派行末句)。
//
// 为什么是插话而不是递话:§8.12 定的是「既有线程的递话走原话直递,管家如有补充以插话追加,不阻塞
// 线程启动」。递话(thread_continue)会【起一个新回合】,补充却必须落在【正在跑的那个回合】里 ——
// 它是给线程补上下文,不是给它派新活。所以走的是 /api/steer 背后的同一条注入通道(116-2b 把它零行为
// 抽成了 13b 的 steerSessionCore),而不是第二条注入路径:引擎分流(openai 队列 / Claude stdin /
// Kimi ACP 跟随)、队列上限、提问挂起时拒绝、持久呈现进会话正文,一条纪律都不用重写。
//
// 三条自己的收紧:①≤600 字;②尖括号中和(stewardSanitizeText,与总览行同一函数);③服务端加
// 「（管家补充）」前缀 —— 用户在 2.0 视窗里看到的插话必须能一眼分清是谁说的。
// 没有在途回合(或该回合不接受插话)时一律 steward.no_active_turn:模型看到这个信封就该改用
// steward_thread_continue,而不是轮询重试。
async function stewardImplThreadNote(args, ctx, config) {
  const sessionId = safeSessionId(args.sessionId);
  if (!sessionId) return stewardFail('not_found', 'invalid sessionId');
  const text = stewardSanitizeText(args.text).trim().slice(0, STEWARD_NOTE_TEXT_MAX);
  if (!text) return stewardFail('invalid_request', 'text is required');
  const head = await stewardReadSessionHead(sessionId);
  if (!head || !head.id) return stewardFail('not_found', `thread ${sessionId} not found`);
  if (stewardRawKind(head) === 'steward') return stewardFail('invalid_target', 'the steward session cannot receive a steward note');
  // 插话与递话走同一条注入通道,无人值守时也该过同样两道闸(修前写死 mayAct:'auto',「只做计划」档的线程
  // 照样被收件箱回合插进话去):自理清单 relay 勾选 + 目标线程权限档。
  const permissionMode = stewardThreadPermissionMode(head, config);
  let mayAct = 'auto';
  if (stewardUnattendedByModel(ctx)) {
    if (!stewardRelayAutoAllowed(config)) {
      return stewardFail('propose_required', '「任务内自动交接」没有勾选,无人值守时的插话只能作为提议交给用户,不要重试', {
        reason: 'self_serve_off', sessionId, permissionMode,
      });
    }
    mayAct = stewardMayAct(permissionMode, 'relay', 'edit');
    if (mayAct !== 'auto') {
      return stewardFail('propose_required', `目标线程的权限档为「${stewardPermissionLabel(permissionMode)}」,管家不能在你不在场时直接往它里面插话;把它作为提议交给用户,不要重试`, {
        reason: 'target_permission', sessionId, permissionMode,
      });
    }
  }

  const outcome = await steerSessionCore({ sessionId, text: STEWARD_NOTE_PREFIX + text });
  // 核心的两种"没成"(apiFailure 形态的 400/409 与裸 json 的 {ok:false,error}) 归一成同一个稳定信封:
  // 对模型来说它们是同一件事 —— 现在没法把这句话插进去,别重试。
  if (outcome.kind === 'failure' || !(outcome.body && outcome.body.ok === true)) {
    const detail = stewardErrorDetail(outcome.kind === 'failure' ? outcome.message : (outcome.body && outcome.body.error)).slice(0, 300);
    return stewardFail('steward.no_active_turn', `thread ${sessionId} cannot take a note right now: ${detail} —— do not retry; use steward_thread_continue to start a new turn instead`, { sessionId });
  }
  const body = outcome.body;
  // 撤回原语是 DELETE /api/steer,它按【文本】在队列里找那一条 —— 所以 undoRef 的真正把手是 text
  // 而不是某个 id(既有插话通道就没有 id 这个东西,编一个出来只会骗人)。
  const undoRef = { kind: 'note', sessionId, text: STEWARD_NOTE_PREFIX + text, queued: Number(body.queued) || 0, injected: body.injected === true };
  stewardAppendDecision({
    tool: 'steward_thread_note',
    args: { textChars: text.length },
    targetSessionId: sessionId,
    permissionMode,
    mayAct,
    undoRef,
    basis: {},
  });
  return { ok: true, sessionId, queued: Number(body.queued) || 0, injected: body.injected === true, undoRef };
}

// 24) steward_quick_ask —— 速查线程(§11.1 第 2 项)。
//     何时用:要读文件、联网或动手才能答的问题。何时别用:关于如意、事项、费用、设置的问题 —— 那些
//     管家自己就知道,开一条线程去问等于让用户白等一次回合。
//     不进任何事项;权限用新线程默认权限(即全局 permissionMode),照常受 116h 仲裁;答完自动收工。
async function stewardImplQuickAsk(args, ctx, config) {
  // 第二轮工具走查(F14):question 是【用户的话】,与 thread_new 的 brief.userText 同一待遇 —— 逐字递进线程。
  // 修前过 stewardSanitizeText:`List<String>`、`a<b` 里的尖括号被换成全角 ＜＞,换行折成空格,线程收到的已经不是用户写的那句
  // (问代码泛型/不等式的速查全被改了意思)。中和是为了防【管家自己提示词里】的围栏标记被冒充,而这句话进的是线程的
  // 首条用户消息,不是管家提示词;只有管家自己写的补充才需要中和(buildStewardBrief 的 supplement)。
  // 返回给管家的回显与线程标题仍走 stewardSanitizeText(单行、中和),它们是给管家/看板读的展示面。
  const question = String(args.question == null ? '' : args.question).trim();
  if (!question) return stewardFail('invalid_request', 'question is required');
  if (question.length > STEWARD_QUICK_QUESTION_CHARS) {
    return stewardFail('invalid_request', `question must be at most ${STEWARD_QUICK_QUESTION_CHARS} characters`);
  }
  // W7:与 thread_new 共用同一条 cwd 选择顺序(见文件头 stewardResolveThreadCwd;速查线程不进事项,
  // 所以没有事项那两步)。排在配额之前:参数不合法不该烧掉本回合的速查名额。
  const quickCwdPick = await stewardResolveThreadCwd(args, config, '');
  if (!quickCwdPick.ok) return quickCwdPick.fail;
  if (!stewardTurnQuotaTake('quick_ask', ctx, STEWARD_QUICK_ASKS_PER_TURN)) {
    return stewardFail('quota_exceeded', `at most ${STEWARD_QUICK_ASKS_PER_TURN} quick-ask threads per steward turn; do not retry - answer with what you already know or tell the user`);
  }
  const session = await createSession({
    title: stewardSanitizeText(question).slice(0, STEWARD_TITLE_MAX),
    cwd: quickCwdPick.cwd,
    origin: 'steward',   // 121-K3:速查线程也是管家开的(与 thread_new 同一口径,见那里的注释)
  });
  // 选择顺序第 ④ 步:与 thread_new 同一口径。速查线程的「标题」就是问题原话的前 N 个字,slug 自己会
  // 截到 64;答完就收工的线程也照样给它一个自己的目录(它可能下载了东西)—— 登记在如意自己那张表里,
  // 不进用户的常用工作区。
  let quickCwdSource = quickCwdPick.source;
  if (quickCwdPick.cwd === undefined) {
    const quickDerivedCwd = await stewardDeriveThreadCwd(question, session.id, config);
    if (quickDerivedCwd) session.cwd = quickDerivedCwd;
    else quickCwdSource = 'default';
  }
  if (quickCwdPick.relatedSessionId) session.relatedSessionId = quickCwdPick.relatedSessionId;
  session.kind = STEWARD_QUICK_KIND;
  // 116-5a:速查线程建出来时 title 是【问题原话的前 N 个字】,那不是「人给的名字」而恰恰是本波要
  // 替换掉的东西。createSession 会因为它非占位而标上 titleSource:'user',这里清掉 —— 否则这条线程
  // 永远拿不到自动摘要。thread_new 那边不清:args.title 是管家【有意】起的名字,与改名同一性质。
  delete session.titleSource;
  // 116-4:管家关心的会话的三个机器痕迹之一(另两个是 stewardQuick、线程在别人的事项里)。
  // 在这里就地写进内存副本,跟着下面那次 saveSession 一起落盘 —— 零额外写。
  session.launchedBy = 'steward';
  // 117z-E2 提交①(§11.21.3):出身标,与 thread_new 那处同一个字段、同一条纪律(见那里的注释)。
  // 速查线程也算「管家自己开的」—— 它确实是 steward_quick_ask 建出来的,与 titleSource 被删掉那件事
  // 无关(那删的是「标题是谁给的」,不是「线程是谁开的」)。
  session.createdBy = 'steward';
  // 速查线程【不进事项】:missionId 指回自己(createSession 的缺省),不写任何反向索引,
  // GET /api/missions 里它就是一条「未归类」的派生行,不占任何事项的验收与预算。
  session.stewardQuick = {
    schema: 1,
    askedAt: nowIso(),
    question,
    stewardTurnKey: String(stewardTurnKeyOf(ctx)),
    closedAt: null,
  };
  // 117l D7:速查线程恒走 fast 档 —— 它定义上就是「查一下」,没有理由烧强模型(没配 fast 档就跟随全局)。
  const quickTier = StewardHooks.applyThreadTier(session, 'fast', config);
  await saveSession(session);

  const launched = stewardLaunchTurn({
    sessionId: session.id,
    message: question,
    cwd: session.cwd,
    source: 'steward',
    requestMeta: { tool: 'steward_quick_ask' },
  }, 'steward_quick_ask');

  // 117e 第 0 步:与 117d-0 的 thread_new / thread_continue 同口径 —— 撤回锚点显式化。
  // rewindSession 按「要删的那一回合的第一条用户消息」定位(09 的 plannedTurnSeq = turnSeq + 1),
  // 按 `turnSeq` 字面传会得 target turn not found。新建会话的 turnSeq 恒为 0,这里仍按字段读,
  // 与上面那两处逐字同形(将来 createSession 若带出非零 seq 也不会错)。
  const registration = await launched.registration;
  const undoRef = registration ? { kind: 'thread_new', sessionId: session.id, ...registration } : { kind: 'none', sessionId: session.id };
  stewardAppendDecision({
    tool: 'steward_quick_ask',
    args: { chars: question.length, tier: quickTier.tier, cwdSource: quickCwdSource },
    targetSessionId: session.id,
    permissionMode: stewardThreadPermissionMode(session, config),
    mayAct: 'auto',
    undoRef,
    basis: stewardBasisOf(args),
  });
  return {
    ok: true, sessionId: session.id, kind: STEWARD_QUICK_KIND, question: stewardSanitizeText(question), tier: quickTier.tier, engine: quickTier.engine, undoRef,
    workspace: (stewardWorkspaceNameOf(session.cwd, config) || { name: '' }).name, cwdSource: quickCwdSource,   // W7:同 thread_new
  };
}

// ── 收件箱增强(13i 每轮落盘前调,经 StewardHooks 延迟绑定)──────────────────────────────────
// 117s-H1(27 号文 §11.13.3,用户第三轮回话「线程的交付管家能不能看全」):给【每一条】管家关心的
// 线程的 `done` 行补上这一回合真正的交付 —— `payload.deliverable = {text,chars,truncated,turnSeq,files}`。
// 修前只有速查线程补一个 `answer`,而那个字段 13h 里【零渲染点】(grep 可自证):交付正文从来没有
// 进过收件箱回合,管家只拿到一行「线程第 N 回合跑完了」,正文全靠它自己再花一次 thread_read 配额去读。
// 判据用 06i 的 stewardWatchedThread —— 与 13i 决定「这条线程要不要入箱」的是同一条线,不另立第二套
// (用户自己在经典壳里聊的普通会话本来就不入箱,这里也就不会为它们装载会话)。
//
// 为什么在这里而不是在 13i:13i 只认三条 seq 日志,不读会话正文;而交付正文与本回合的文件账都要装载
// 会话。放在 13g 并经命名空间回调,13i 就不需要认识 13g 的任何符号(前向边红线)。
// 旁路纪律:抛错绝不反噬轮询器 —— 13i 那边整段包在 try 里,补不上就是少几个字段。
// 127 波 2-quater B1 ③(45 号文 §2-quater.1 取证 1):管家今天根本看不到命令原文 —— 13i 归一化 needs_you 时
// 「永不带 iv.input」(那条单测锁不动)。可豁免命中的权限待决偏偏是管家要讲给用户听的那一类:用户真机上它只能
// 说「命令原文我这边看不到」。所以只给【豁免命中的权限待决】补一份经过三道处理的摘录,其余待决零新增字段:
//   ① 按 06i stewardExemptScanInput 的 tier 口径决定看不看 input(read/edit 档只看工具名 —— 摘录为空串);
//   ② stewardExemptHits 判全部命中:没有命中就返回 null(调用方据此一个字段都不挂);
//   ③ 摘录 = 04 redact(REDACT_PATTERNS 单一来源)→ 06i stewardExemptExcerpt(尖括号中和 + 以命中处为中心截 300 字)。
// 返回 { categories(类别键,去重保序;纯工具名命中时为空数组), floor(任一命中是底线), commandExcerpt }。
// 收件箱行(stewardEnrichInboxRows)与 steward_thread_status.pending[] 读的是这同一个函数。
function stewardPendingExecutionSummary(iv) {
  if (!iv || iv.type !== 'permission' || iv.status !== 'pending') return null;
  const input = stewardExemptScanInput(iv.tier, iv.input);
  if (input == null) return null; // 文件写入正文不作为命令摘录泄露。
  const text = stewardSanitizeBlock(redact(typeof input === 'string' ? input : JSON.stringify(input)));
  if (!text) return null;
  return { commandExcerpt: text.slice(0, 1200), chars: text.length, truncated: text.length > 1200 };
}
function stewardExemptPendingSummary(iv) {
  const v = (iv && typeof iv === 'object') ? iv : null;
  if (!v || String(v.type || '') !== 'permission' || String(v.status || '') !== 'pending') return null;
  const scanInput = stewardExemptScanInput(v.tier, v.input);
  const verdict = stewardExemptHits(String(v.toolName || ''), scanInput);
  if (!verdict.hits.length) return null;
  const categories = [...new Set(verdict.hits.map(hit => hit.category).filter(Boolean))];
  const commandExcerpt = scanInput == null
    ? ''
    : stewardExemptExcerpt(redact(stewardExemptInputText(scanInput).slice(0, STEWARD_EXEMPT_INPUT_CHARS)), verdict.hits);
  return { categories, floor: verdict.hits.some(hit => hit.floor === true), commandExcerpt };
}

// 127 波 2-quater B2(45 号文 §2-quater.2 闸 2 / 闸 8):代批要的两件【活回合】事实,从活回合登记表上现读。
// 为什么住 13k 而不是 13l:activeChildren 与 logEvent 都在 04,13k→04 是既有边、13l→04 不是(13l 今天一个 04
// 符号都不引用)—— 与 B1 把 stewardExemptPendingSummary 放在这里是同一个理由,零新增依赖边。
//   mode  —— 活回合此刻的实效档位:09 在 runOpenAiTurn 里挂到登记表上的 effectivePermissionMode(与闸门
//            gateWithLiveMode 读同一个函数)。没有活回合 / 登记表上没有这个函数(Claude CLI、Kimi)/ 调用抛错
//            → 空串,闸 2 据此拦下(判不出档位就不代批)。**不读会话头** —— 那正是要堵的错位。
//   taint —— 06i stewardTurnTaint 在活回合段表上判(a),再叠会话级粘性污染位(b)。判不出一律算污染(c):
//            没有活回合 'no_live_turn';登记表没有 liveSegments(Kimi 的就没有)'no_live_segments'。
//            粘性位优先读活回合里那一份会话对象(10 的 emit 写的就是它,比盘上新),盘上的会话头兜底。
//            10 只在读外部内容的那条工具调用【结果回来】时置位 —— 这条待决自己(还没执行、没有结果)不会把自己算进去。
// 审计 E:非代批的待决判 mayAct 也要看【活回合此刻的实效档】—— 定时任务(请求级 autonomy.permissionMode)与
// 交办卡的请求级收紧只活在回合里,不在会话头上。只读档位,不碰污染判定(那是代批十道闸的事)。
// 09 的登记表挂 effectivePermissionMode();Claude CLI 的登记表只有 spawn 时的解析档 permissionMode(05);
// 都没有(Kimi、无活回合、调用抛错)→ 空串,由调用方决定怎么兜底。
function stewardLiveTurnPermissionMode(liveSessionId) {
  const liveReg = activeChildren.get(String(liveSessionId || '')) || null;
  if (!liveReg) return '';
  try {
    if (typeof liveReg.effectivePermissionMode === 'function') return String(liveReg.effectivePermissionMode() || '');
  } catch { return ''; }
  return typeof liveReg.permissionMode === 'string' ? liveReg.permissionMode : '';
}
function stewardExemptLiveTurn(liveSessionId, liveInterventionId, liveHead) {
  const liveReg = activeChildren.get(String(liveSessionId || '')) || null;
  if (!liveReg) return { live: false, mode: '', taint: { tainted: true, taintBy: 'no_live_turn' } };
  let mode = '';
  try { mode = typeof liveReg.effectivePermissionMode === 'function' ? String(liveReg.effectivePermissionMode() || '') : ''; } catch { mode = ''; }
  const sticky = (liveReg.session && liveReg.session.stewardTaint) || (liveHead && liveHead.stewardTaint) || null;
  let taint = { tainted: true, taintBy: 'no_live_segments' };
  if (liveReg.liveSegments && typeof liveReg.liveSegments.snapshot === 'function') {
    try { taint = stewardTurnTaint(liveReg.liveSegments.snapshot(), liveInterventionId, sticky); } catch { taint = { tainted: true, taintBy: 'no_live_segments' }; }
  }
  return { live: true, mode, taint };
}
// 代批落定之后的审计行。**只放元数据**:类别、判据来源、有没有写理由、窗口里第几次 —— 命令摘录与 riskNote
// 正文都不进日志(日志会被 /api/audit 与导出面读走;摘录与理由只进决策账本与回执)。
function stewardExemptDelegatedLog(delegatedMeta) {
  const m = (delegatedMeta && typeof delegatedMeta === 'object') ? delegatedMeta : {};
  try {
    logEvent({
      kind: 'steward_exempt_delegated',
      sessionId: String(m.sessionId || ''),
      interventionId: String(m.interventionId || ''),
      toolName: String(m.toolName || '').slice(0, 120),
      categories: Array.isArray(m.categories) ? m.categories.slice(0, 5) : [],
      exemptBy: String(m.exemptBy || ''),
      riskNoteChars: Math.max(0, Number(m.riskNoteChars) || 0),
      windowCount: Math.max(0, Number(m.windowCount) || 0),
    });
  } catch { /* 审计旁路:写不进去不反噬已经落定的决定 */ }
}

async function stewardEnrichInboxRows(rows) {
  const list = Array.isArray(rows) ? rows : [];
  const heads = new Map();
  const pendingBySession = new Map();
  for (const row of list) {
    // 127 波 2-quater B1 ③:豁免命中的权限待决行补 exempt。只读待决旁路账(同一批同一线程只读一次),
    // 不装载会话;待决已经不是 pending(刚被答掉)就不挂 —— 摘录只描述「此刻还在等的那一条」。
    if (row && row.kind === 'needs_you' && row.payload && row.payload.interventionType === 'permission' && row.payload.interventionId) {
      const pendingSid = safeSessionId(row.sessionId);
      if (!pendingSid) continue;
      if (!pendingBySession.has(pendingSid)) pendingBySession.set(pendingSid, await readInterventions(pendingSid).catch(() => []));
      const iv = (pendingBySession.get(pendingSid) || []).find(item => item && String(item.id) === String(row.payload.interventionId));
      const exempt = stewardExemptPendingSummary(iv);
      if (exempt) row.payload = { ...row.payload, exempt };
      continue;
    }
    if (!row || row.kind !== 'done') continue;
    const sid = safeSessionId(row.sessionId);
    if (!sid) continue;
    if (!heads.has(sid)) heads.set(sid, await stewardReadSessionHead(sid).catch(() => null));
    const head = heads.get(sid);
    if (!head) continue;
    if (!stewardWatchedThread(head, sid, row.missionId)) continue;
    const quick = stewardRawKind(head) === STEWARD_QUICK_KIND && !!head.stewardQuick;
    const session = await loadSession(sid).catch(() => null);
    if (!session) continue;
    const payload = (row.payload && typeof row.payload === 'object') ? row.payload : {};
    // 回合号取事件自己的(第四源 stewardNormalizeSessionTurn 落的 payload.turnSeq);取不到就退到
    // 会话头上的当前回合号,再取不到才让下面的挑选退到「最后一条助手话」。
    const turnSeq = Math.max(0, Number(payload.turnSeq) || 0) || Math.max(0, Number(head.turnSeq) || 0);
    const deliverySession = turnSeq > 0 ? { messages: (session.messages || []).filter(message => Number(message.turnSeq) === turnSeq) } : session;
    const full = stewardSanitizeBlock(stewardTurnAssistantText(deliverySession, turnSeq));
    const patch = {};
    if (full.trim()) {
      patch.deliverable = {
        text: full.slice(0, STEWARD_DELIVERABLE_CHARS),
        chars: full.length,
        truncated: full.length > STEWARD_DELIVERABLE_CHARS,
        turnSeq,
        files: stewardTurnFiles(session, turnSeq),
      };
    }
    // 速查线程的 `answer` 留着(老消费者与 116-2e 的收工判据都认它),但它现在与交付【同一份原文】,
    // 只是仍按 ≤1200 的老口径中和成单行 —— 两个字段从此不会各说各的。
    if (quick) {
      patch.quick = true;
      patch.answer = stewardSanitizeText(full || (turnSeq > 0 ? '' : stewardLastAssistantText(session))).slice(0, STEWARD_QUICK_ANSWER_CHARS);
    }
    if (Object.keys(patch).length) row.payload = { ...payload, ...patch };
  }
  return list;
}

// 收工:回合结束后由 13h 调 —— 把 stewardQuick.closedAt 落在会话头上。收工后这条线程从管家的总览
// 与 steward_threads_search 里消失(经典壳照常看得见,它只是数据)。幂等:已收工的再调是无操作。
async function stewardQuickClose(sessionId) {
  const sid = safeSessionId(sessionId);
  if (!sid) return { ok: false, error: 'invalid_request' };
  const head = await stewardReadSessionHead(sid);
  if (!head || stewardRawKind(head) !== STEWARD_QUICK_KIND || !head.stewardQuick) return { ok: false, error: 'not_found' };
  // 116-3 P1-6:判「还算不算收工」走 stewardQuickClosed(它会把「收工后用户又聊了」算成重开),
  // 而不是只看 closedAt 是不是真值 —— 否则一条被用户重新用起来的速查线程再次收工时会被当成幂等
  // 直接返回,closedTurnSeq 永远停在第一次收工那一刻,它就再也关不上了。
  if (stewardQuickClosed(head)) return { ok: true, sessionId: sid, closedAt: head.stewardQuick.closedAt, changed: false };
  const closedAt = nowIso();
  // 收工时记下【当时的回合数】。之后会话每多一个用户回合,turnSeq 就会超过它 = 用户在继续用这条线程。
  const closedTurnSeq = Math.max(0, Number(head.turnSeq) || 0);
  await updateSessionMeta(sid, { stewardQuick: { ...head.stewardQuick, closedAt, closedTurnSeq } });
  return { ok: true, sessionId: sid, closedAt, closedTurnSeq, changed: true };
}
