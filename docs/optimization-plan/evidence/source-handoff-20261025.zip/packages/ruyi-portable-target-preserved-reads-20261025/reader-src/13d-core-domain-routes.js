// ── 113b: 会话内容搜索 ────────────────────────────────────────────────────────────────────────
// 摸底口径:侧栏搜索此前是纯前端子串过滤,只看 title/summary/cwd 三个字段(session-experience.js),
// 会话正文一个字都不查;`sessions/index.json` 也只是元数据缓存。用户「我上周让它改过那个文件」这类
// 回忆式查找完全做不到,而这恰恰是本地工作台最该会的事 —— 历史全在本机。
//
// 为什么这里要落盘索引,而记忆召回那边不落:记忆的检索单元就是注册表已经读进来的头部字段,重算是
// 微秒级;会话的检索单元要从可能几 MB 的 NDJSON 正文里抽,不缓存就是每次搜索把整个历史读一遍。
//
// 索引单元(v2)= 标题 + 摘要 + 【每一条】用户消息(各取开头一段)+ 助手回复(从新到旧各取开头一段),每会话 ≤ 8K 字符。
// v1 只收首条 user 与末尾 6 条,长对话中间问过的事永远搜不到(「搜不全」);还把后台任务回执、压缩标记这类
// 系统行也收了进来(「搜到垃圾」)。失效键 = updatedAt + messageCount(两者都在 listSessions 的元数据里,判断失效零额外 IO)。
// 正文读取:≤ 2MB 整个读,更大的只读头尾各 1MB —— 一条几十 MB 的会话不会因为被搜索而把内存顶起来。
// 索引文件名沿用 _search-index-v1.json(换了名旧文件就成了孤儿),版本号升到 2:旧索引读进来就是版本不符 → 全量重建。
const SESSION_SEARCH_INDEX_FILE = '_search-index-v1.json';
const SESSION_SEARCH_INDEX_VERSION = 2;
const SESSION_SEARCH_UNIT_CAP = 8192;      // 每会话进索引的字符上限
const SESSION_SEARCH_USER_CHARS = 400;     // 每条用户消息取多少
const SESSION_SEARCH_ASSISTANT_CHARS = 240;// 每条助手回复取多少
const SESSION_SEARCH_HEAD_BYTES = 1024 * 1024;
const SESSION_SEARCH_TAIL_BYTES = 1024 * 1024;
const SESSION_SEARCH_SNIPPET_RADIUS = 60;
const SESSION_SEARCH_MAX_LIMIT = 50;
const SESSION_SEARCH_MIN_QUERY = 2;

function sessionSearchIndexPath() { return path.join(paths.sessions, SESSION_SEARCH_INDEX_FILE); }

// 只读文件的头尾两段,中间跳过;两段都按【整行】交出去:
//   · 文件 ≤ 头 + 尾:两段本来就盖满全文,整个读(头注「≤ 2MB 整个读」)。修前这种文件也切成两段,头段尾巴的半行 JSON 解析失败、
//     尾段又无条件丢掉第一行 —— 恰好跨在 1MB 接缝上的那条消息两边都不要,搜它说过的话搜不到(而且与头注说的「整个读」不符);
//   · 更大:头段停在半行里就继续往后读到行尾,尾段起点落在行中间就往前读到行首 —— 跨边界的那条消息补成完整一行。
//     补读各有上限(NDJSON_EDGE_EXTEND_MAX):超过上限的单行(几 MB 的工具输出)才放弃,把那半行丢掉,不让它进解析。
const NDJSON_EDGE_EXTEND_CHUNK = 64 * 1024;
const NDJSON_EDGE_EXTEND_MAX = 2 * 1024 * 1024;
async function readNdjsonEdges(file, headBytes, tailBytes) {
  let fh = null;
  try {
    const st = await fsp.stat(file);
    if (!st.isFile() || st.size === 0) return { head: '', tail: '' };
    fh = await fsp.open(file, 'r');
    const size = st.size;
    const readAt = async (pos, len) => {
      const buf = Buffer.allocUnsafe(len);
      const { bytesRead } = await fh.read(buf, 0, len, pos);
      return bytesRead === len ? buf : buf.subarray(0, bytesRead);
    };
    if (size <= headBytes + tailBytes) return { head: (await readAt(0, size)).toString('utf8'), tail: '' };
    // 头段:读满 headBytes,停在半行里就往后补到行尾。
    let headBuf = await readAt(0, headBytes);
    if (headBuf.length && headBuf[headBuf.length - 1] !== 0x0a) {
      const extra = [];
      let pos = headBytes, found = false;
      while (pos < size && pos - headBytes < NDJSON_EDGE_EXTEND_MAX) {
        const chunk = await readAt(pos, Math.min(NDJSON_EDGE_EXTEND_CHUNK, size - pos));
        if (!chunk.length) break;
        const nl = chunk.indexOf(0x0a);
        if (nl >= 0) { extra.push(chunk.subarray(0, nl + 1)); found = true; break; }
        extra.push(chunk); pos += chunk.length;
      }
      if (found) headBuf = Buffer.concat([headBuf, ...extra]);
      else { const cut = headBuf.lastIndexOf(0x0a); headBuf = cut >= 0 ? headBuf.subarray(0, cut + 1) : Buffer.alloc(0); }   // 超限的巨型单行:丢掉这半行
    }
    // 尾段:起点前一个字节不是换行 = 起点在行中间,往前补到行首。
    const tailStart = size - tailBytes;
    let tailBuf = await readAt(tailStart, tailBytes);
    const before = await readAt(tailStart - 1, 1);
    if (before.length && before[0] !== 0x0a) {
      const front = [];
      let pos = tailStart, found = false;
      while (pos > 0 && tailStart - pos < NDJSON_EDGE_EXTEND_MAX) {
        const from = Math.max(0, pos - NDJSON_EDGE_EXTEND_CHUNK);
        const chunk = await readAt(from, pos - from);
        const nl = chunk.lastIndexOf(0x0a);
        if (nl >= 0) { front.unshift(chunk.subarray(nl + 1)); found = true; break; }
        front.unshift(chunk); pos = from;
        if (pos === 0) { found = true; break; }   // 一直退到文件开头:第一行本来就从 0 开始
      }
      if (found) tailBuf = Buffer.concat([...front, tailBuf]);
      else { const cut = tailBuf.indexOf(0x0a); tailBuf = cut >= 0 ? tailBuf.subarray(cut + 1) : Buffer.alloc(0); }   // 超限:丢掉起点那半行
    }
    return { head: headBuf.toString('utf8'), tail: tailBuf.toString('utf8') };
  } catch {
    return { head: '', tail: '' };
  } finally {
    if (fh) await fh.close().catch(() => {});
  }
}

function parseNdjsonRows(text) {
  const lines = String(text || '').split('\n');
  const rows = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try { rows.push(JSON.parse(trimmed)); } catch { /* 半条/坏行跳过,与会话读取侧同口径 */ }
  }
  return rows;
}

function sessionMessageText(row) {
  if (!row || typeof row !== 'object') return '';
  const content = typeof row.content === 'string' ? row.content : '';
  if (content) return content;
  // segments 型 assistant 消息:只取文本段与工具名,不展开工具结果(那是噪声,而且可能很大)。
  const segments = Array.isArray(row.segments) ? row.segments : [];
  const parts = [];
  for (const segment of segments) {
    if (!segment) continue;
    if (typeof segment.text === 'string' && segment.text) parts.push(segment.text);
    else if (segment.type === 'tool' && segment.name) parts.push(String(segment.name));
  }
  return parts.join(' ');
}

// 不进索引的行:系统行(压缩标记、修复说明、后台任务回执)、带 backgroundJobId 的回执、以及以「完成通知 /
// system-reminder」开头的注入文本 —— 它们不是用户说过或看过的话,进了索引只会让搜索命中一堆不相干的会话。
function sessionSearchRowIsNoise(row) {
  if (!row || typeof row !== 'object') return true;
  if (row.role !== 'user' && row.role !== 'assistant') return true;
  if (row.backgroundJobId || row.source === 'compact' || row.hidden === true) return true;
  if (row.meta && row.meta.origin === 'agent_wake') return true;   // 后台代理唤醒通知:系统文字,不是这条会话「干过什么」的信号
  const text = typeof row.content === 'string' ? row.content.trimStart() : '';
  return /^(?:\[(?:代理完成通知|后台任务完成通知|后台任务|工具结果)|<system-reminder>)/.test(text);
}
// Cipher records require physical ordinals, so authenticate a streaming pass while retaining
// only bounded logical plaintext head/tail rows. Legacy unsealed searches retain their old edge IO.
async function sessionSearchRows(sessionId) {
  const file = sessionBodyPaths(sessionId).messages;
  const protectedLine = line => {
    const probe = WorkDataRecords.lineProbe();
    probe.feed(Buffer.from(line, 'utf8'));
    return probe.reserved();
  };
  let enabled;
  try { enabled = (await readConfig()).workDataEncryptionV1 === true; }
  catch { throw Object.assign(new Error('work_data_store.switch_unavailable'), { code: 'work_data_store.switch_unavailable', apiCode: 'work_data_store.switch_unavailable', statusCode: 503 }); }
  // Enabling encryption can leave a mixed body. Scan it even when the sampled edges are legacy:
  // ciphertext in the middle still changes the physical offsets of the logical plaintext tail.
  if (!enabled) {
    const edges = await readNdjsonEdges(file, SESSION_SEARCH_HEAD_BYTES, SESSION_SEARCH_TAIL_BYTES);
    if (!(edges.head + '\n' + edges.tail).split('\n').some(protectedLine)) {
      return [...parseNdjsonRows(edges.head), ...parseNdjsonRows(edges.tail)];
    }
  }
  const headWindow = SESSION_SEARCH_HEAD_BYTES + NDJSON_EDGE_EXTEND_MAX + NDJSON_EDGE_EXTEND_CHUNK;
  const tailWindow = SESSION_SEARCH_TAIL_BYTES + NDJSON_EDGE_EXTEND_MAX + NDJSON_EDGE_EXTEND_CHUNK;
  let lease = null, handle = null, ordinal = 0, total = 0, primaryError = null;
  let pending = [], pendingBytes = 0, skipping = false, tailStart = 0, probe = WorkDataRecords.lineProbe();
  const head = [], tail = [];
  const fail = code => { throw Object.assign(new Error(code), { code, apiCode: code, statusCode: 503 }); };
  const accept = async (line, bytes, sealed = false) => {
    let raw = line;
    if (sealed) {
      if (!lease) lease = await WorkDataStore.acquireSnapshot();
      raw = await WorkDataRecords.decodeLine(raw, lease.key, { instanceId: lease.instanceId, sessionId, kind: 'messages', ordinal });
      bytes = Buffer.byteLength(raw, 'utf8') + 1;
    }
    const start = total;
    total += bytes;
    ordinal++;
    if (!raw) return;
    let value;
    try { value = JSON.parse(raw); }
    catch { if (sealed) fail('work_data_record.corrupt'); return; }
    const row = { start, end: total, value };
    if (start < SESSION_SEARCH_HEAD_BYTES + SESSION_SEARCH_TAIL_BYTES && total <= headWindow) head.push(row);
    tail.push(row);
    while (tailStart < tail.length && tail[tailStart].end <= total - tailWindow) tail[tailStart++] = null;
    if (tailStart > 4096 && tailStart * 2 > tail.length) { tail.splice(0, tailStart); tailStart = 0; }
  };
  try {
    handle = await fsp.open(file, 'r');
    const buffer = Buffer.alloc(64 * 1024);
    for (;;) {
      const { bytesRead } = await handle.read(buffer, 0, buffer.length, null);
      if (!bytesRead) break;
      let start = 0;
      for (let end = buffer.indexOf(10, start); end >= 0 && end < bytesRead; end = buffer.indexOf(10, start)) {
        const part = buffer.subarray(start, end);
        probe.feed(part);
        pendingBytes += part.length;
        if (pendingBytes > headWindow && probe.reserved()) fail('work_data_record.text_limit');
        if (!skipping) pending.push(Buffer.from(part));
        await accept(skipping ? '' : Buffer.concat(pending, pendingBytes).toString('utf8'), pendingBytes + 1, probe.reserved());
        pending = []; pendingBytes = 0; skipping = false; start = end + 1; probe = WorkDataRecords.lineProbe();
      }
      if (start < bytesRead) {
        const part = buffer.subarray(start, bytesRead);
        probe.feed(part);
        pendingBytes += part.length;
        if (pendingBytes > headWindow && probe.reserved()) fail('work_data_record.text_limit');
        if (!skipping) pending.push(Buffer.from(part));
        if (!skipping && pendingBytes > headWindow) {
          pending = []; skipping = true;
        }
      }
    }
    // Search used to accept a final complete legacy JSON without LF. An incomplete encrypted
    // append is not a search row; refuse it without repairing or publishing a derived index.
    if (pendingBytes) {
      const raw = skipping ? '' : Buffer.concat(pending, pendingBytes).toString('utf8');
      if (probe.reserved()) fail('work_data_record.corrupt');
      await accept(raw, pendingBytes);
    }
    if (total <= SESSION_SEARCH_HEAD_BYTES + SESSION_SEARCH_TAIL_BYTES) return head.map(row => row.value);
    const first = head.filter(row => row.start < SESSION_SEARCH_HEAD_BYTES && row.end <= headWindow);
    const last = tail.slice(tailStart).filter(row => row.end > total - SESSION_SEARCH_TAIL_BYTES && row.start >= Math.max(0, total - tailWindow));
    return [...first, ...last].map(row => row.value);
  } catch (error) {
    if (String(error?.code || '').startsWith('work_data')) { primaryError = error; throw error; }
    // Legacy ordinary I/O remains a missing search unit, not a mutation of session authority.
    return [];
  } finally {
    if (handle) await handle.close().catch(() => {});
    if (lease) { try { await lease.release(); } catch { if (!primaryError) fail('work_data_store.snapshot_release'); } }
  }
}

async function buildSessionSearchUnit(meta) {
  const rows = (await sessionSearchRows(meta.id)).filter(row => !sessionSearchRowIsNoise(row));   // 两段都是整行(见 readNdjsonEdges)
  // 116-5b:线程的名字与那句概括也进检索单元。它们是模型对「这条线程到底要干什么」的概括,
  // 常常用了用户原话里没打出来的词(原话「帮我分析一下AMD」/ 概括「拉 AMD 最新行情与新闻」)——
  // 顺带提召回,而不只是显示。缺席时这两段是空串,被下面的 filter(Boolean) 丢掉。
  const briefUnit = sessionBriefOf(meta);
  const parts = [meta.title || '', (briefUnit && briefUnit.title) || '', (briefUnit && briefUnit.gist) || '', meta.summary || '', meta.cwd || ''];
  let used = parts.reduce((n, part) => n + String(part).length + 1, 0);
  const seen = new Set();
  const push = (value, cap) => {
    const trimmed = String(value || '').replace(/\s+/g, ' ').trim().slice(0, cap);
    // 同一句话(重发、重试)只收一次,既不白白抬高 tf,摘录也不会像复制错了。
    if (!trimmed || seen.has(trimmed) || used >= SESSION_SEARCH_UNIT_CAP) return;
    seen.add(trimmed);
    parts.push(trimmed);
    used += trimmed.length + 1;
  };
  // 用户说过的每一句都是最强的「这条会话干过什么」信号,先收;剩下的额度给助手回复,从新到旧。
  for (const row of rows) if (row.role === 'user') push(sessionMessageText(row), SESSION_SEARCH_USER_CHARS);
  for (let i = rows.length - 1; i >= 0; i--) if (rows[i].role === 'assistant') push(sessionMessageText(rows[i]), SESSION_SEARCH_ASSISTANT_CHARS);
  return parts.filter(Boolean).join('\n').replace(/\s+/g, ' ').slice(0, SESSION_SEARCH_UNIT_CAP);
}

// 进程内缓存:侧栏搜索是边打字边搜(200ms 去抖),修前每敲一个字就把整份索引(会话多时十几 MB)读盘再解析一遍。
// 按文件的 mtime + size 认新旧;本进程自己写索引时直接更新缓存。
function sessionSearchIndexStore(onSealed, onMode, expectedStamp) {
  let usedStamp = "";
  return WorkDataStore.createText({ file: sessionSearchIndexPath, purpose: 'search-index', schema: 1,
    scopeId: 'global', recordId: 'session-search-index', chunked: true, maxPlaintextBytes: 256 * 1024 * 1024,
    keys: { snapshot: async () => {
      const lease=await WorkDataStore.acquireSnapshot();
      usedStamp=lease.instanceId+':'+crypto.createHash('sha256').update(lease.key).digest('hex');
      if(expectedStamp && usedStamp!==expectedStamp) {try { await lease.release(); } catch { /* preserve changed authority */ } throw Object.assign(new Error('work_data_key.changed'),{code:'work_data_key.changed',apiCode:'work_data_key.changed',statusCode:503});}
      return lease;
    }, unlock: () => WorkDataStore.requireKeys().unlock(), instance: () => WorkDataStore.requireKeys().instance() },
    enabled: async () => { const enabled = (await readConfig()).workDataEncryptionV1 === true; if (onMode) onMode(enabled); return enabled; },
    writeJson: atomicWriteJson, validateSealedText: text => {
      const value = JSON.parse(text);
      if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== SESSION_SEARCH_INDEX_VERSION
        || !value.entries || typeof value.entries !== 'object' || Array.isArray(value.entries)
        || Object.values(value.entries).some(row => !row || typeof row !== 'object' || typeof row.stamp !== 'string' || typeof row.unit !== 'string')) return false;
      if (onSealed) onSealed(usedStamp); return true;
    },
  });
}
async function sessionSearchIndexAuthStamp() {
  const lease = await WorkDataStore.acquireSnapshot();
  try { return lease.instanceId + ':' + crypto.createHash('sha256').update(lease.key).digest('hex'); }
  finally { try { await lease.release(); } catch { throw Object.assign(new Error('work_data_store.snapshot_release'), {code:'work_data_store.snapshot_release',apiCode:'work_data_store.snapshot_release',statusCode:503}); } }
}
const sessionSearchIndexFileStamp = st => [st.dev, st.ino, st.size, st.mtimeMs, st.ctimeMs].join(':');

let sessionSearchIndexCache = null;
async function readSessionSearchIndex() {
  try {
    let enabled;
    try { enabled = (await readConfig()).workDataEncryptionV1 === true; }
    catch { throw Object.assign(new Error('work_data_store.switch_unavailable'), {code:'work_data_store.switch_unavailable',apiCode:'work_data_store.switch_unavailable',statusCode:503}); }
    const file = sessionSearchIndexPath(), st = await fsp.stat(file), stamp = file + ':' + sessionSearchIndexFileStamp(st);
    let authStamp = enabled || sessionSearchIndexCache?.sealed ? await sessionSearchIndexAuthStamp() : '';
    if (sessionSearchIndexCache && sessionSearchIndexCache.stamp === stamp && sessionSearchIndexCache.authStamp === authStamp) return sessionSearchIndexCache.data;
    let sealed = false;
    const raw = JSON.parse(await sessionSearchIndexStore(stamp => { sealed = true; authStamp = stamp; }, null, authStamp).read());
    if (!raw || raw.version !== SESSION_SEARCH_INDEX_VERSION || !raw.entries || typeof raw.entries !== 'object') { sessionSearchIndexCache = null; return null; }

    sessionSearchIndexCache = { stamp, data: raw, sealed, authStamp, requiresKey: !!authStamp };
    return raw;
  } catch (error) {
    sessionSearchIndexCache = null;
    if (String(error?.code || '').startsWith('work_data')) throw error;
    return null;
  }
}

// 增量刷新:只为「新会话」或「updatedAt/messageCount 变了的会话」重抽单元;删掉的会话顺带清出去。
// 单飞:侧栏是边打字边搜,冷索引(首次/大批会话变化后)那一遍要把每个会话的正文头尾读一次、再整份写盘。修前每个并发请求
// 各自读到同一份旧索引、各自把全部单元重抽一遍、各自整份写回(N 个请求 = N 倍读盘 + N 次互相覆盖的写)。
// 现在按一条链串行(runKeyedChain):后到的请求等前一个建完,再拿它刚写好的索引做增量 —— 条目全都新鲜,不重抽、不重写。
// 不是「后到的直接共用先到的结果」:各请求带的 metas 可能不同(中途新建的会话),共用会漏掉它们。
const sessionSearchRefreshChains = new Map();
function refreshSessionSearchIndex(metas) {
  return runKeyedChain(sessionSearchRefreshChains, 'index', () => refreshSessionSearchIndexNow(metas));
}
async function refreshSessionSearchIndexNow(metas) {
  const existing = (await readSessionSearchIndex()) || { version: SESSION_SEARCH_INDEX_VERSION, entries: {} };
  const entries = {};
  let changed = false;
  for (const meta of metas) {
    const prior = existing.entries[meta.id];
    const stamp = `${meta.updatedAt || ''}|${Number(meta.messageCount) || 0}`;
    if (prior && prior.stamp === stamp && typeof prior.unit === 'string') { entries[meta.id] = prior; continue; }
    entries[meta.id] = { stamp, unit: await buildSessionSearchUnit(meta) };
    changed = true;
  }
  if (!changed && Object.keys(existing.entries).length === Object.keys(entries).length) return entries;
  const payload = { version: SESSION_SEARCH_INDEX_VERSION, builtAt: nowIso(), entries };
  // 写失败不影响本次搜索结果(内存里的 entries 已经算好了),下次再试。
  // 性能批 C1:紧凑 JSON(3000 条会话时带缩进写出来有 34 MB,每次会话有变都整份重写一遍)
  let sealedWrite = false;
  sessionSearchIndexCache = null;
  const wrote = await sessionSearchIndexStore(null, enabled => { sealedWrite = enabled; }).write(JSON.stringify(payload)).then(() => true, error => {
    if (String(error?.code || '').startsWith('work_data')) throw error;
    return false;
  });
  if (wrote) {
    if (!sealedWrite) {
      try { const file = sessionSearchIndexPath(), st = await fsp.stat(file); sessionSearchIndexCache = { stamp: file + ':' + sessionSearchIndexFileStamp(st), data: payload, sealed: false, requiresKey: false, authStamp: '' }; }
      catch { sessionSearchIndexCache = null; }
    }
  }
  return entries;
}

// 摘录:取【命中查询词最多】的那一段(修前取第一个命中处 —— 常常是某个常见字碰巧出现的地方,看不出为什么命中)。
// 出服务端前过 redact() —— 与 /api/audit 同一条脱敏路径,会话正文里粘过的 key/token 不会因为「搜了一下」就漏到响应里。
function sessionSearchSnippet(unit, terms) {
  const source = String(unit || '');
  const lower = source.toLowerCase();
  const span = SESSION_SEARCH_SNIPPET_RADIUS * 3;
  const candidates = [];
  for (const term of terms) {
    let from = 0;
    for (let n = 0; n < 20; n++) {
      const found = lower.indexOf(term, from);
      if (found < 0) break;
      candidates.push(found);
      from = found + term.length;
    }
  }
  let at = -1, best = -1;
  for (const pos of candidates) {
    const start = Math.max(0, pos - SESSION_SEARCH_SNIPPET_RADIUS);
    const window = lower.slice(start, start + span);
    const distinct = terms.filter(term => window.includes(term)).length;
    if (distinct > best || (distinct === best && pos < at)) { best = distinct; at = pos; }
  }
  const start = at < 0 ? 0 : Math.max(0, at - SESSION_SEARCH_SNIPPET_RADIUS);
  const end = Math.min(source.length, start + span);
  const slice = source.slice(start, end);
  return redact((start > 0 ? '…' : '') + slice + (end < source.length ? '…' : ''));
}

// 排序(修前:词法命中与字符 n-gram 向量两路做 RRF 融合,只要沾一个字就进结果 —— 「搜到垃圾」的主因):
//   ① 词法命中为主。一个会话要算命中,得覆盖至少一半的查询词,或者原样包含整句查询;
//      分数 = 各词权重之和,命中在标题 / 概括里翻倍,整句原样出现、查询词全中另有加分;
//   ② 向量(同义、拼写漂移)只补【强】命中:有词法结果时,只收分数不低于最高分六成且 ≥ 0.2 的;
//      一条词法命中都没有时(打错字)才放宽到最高分一半且 ≥ 0.15(实测打错字的真命中在 0.3–0.5,只沾一个词的在 0.08 上下)。
// 性能批 C1:会话搜索每敲一个字就查一次。语料(分词、df、向量)与每篇的「小写 + 空白折叠」都按条目缓存 ——
// 条目在会话没变时是同一个对象(refreshSessionSearchIndex 原样复用),结果与逐次现算逐位相同。
let sessionSearchCorpusCache = null;
const sessionSearchHayMemo = new WeakMap();   // 条目对象 -> { unit, hay }
function sessionSearchHayOf(entry) {
  const hit = sessionSearchHayMemo.get(entry);
  if (hit && hit.unit === entry.unit) return hit.hay;
  // 查询词(retrievalTerms 产出的)不含空白,所以在折叠过空白的文本里 includes 与在原文里结果相同;
  // 整句 phrase 本来就是在折叠后的文本里比。一份就够两用。
  const hay = String(entry.unit).toLowerCase().replace(/\s+/g, ' ');
  sessionSearchHayMemo.set(entry, { unit: entry.unit, hay });
  return hay;
}
function sessionSearchScope(indexEnabled = true) { return SessionFullTextHooks.scope(indexEnabled); }
async function searchSessionsByContent(query, limit) { return SessionFullTextHooks.search(query, limit); }

// GET /api/sessions/:id 条件 GET 的【盘上戳】。不装载会话就能取:头文件整份读出来哈希(头只有几 KB~几十 KB;
// 不能只信 updatedAt/mtime —— 同一毫秒/同一个文件系统时钟刻度内两次落头会撞)+ 两个正文的 size/mtime/ino(追加改 size,
// 慢路径整份重写是 rename 换 inode)+ 后台任务账本的认证内容摘要(loadSession 会把它合并进 messages)。
// 头是提交点(saveSession 正文先落、头后落,且每次都推 updatedAt),所以「头哈希 + 正文戳」不变 = 盘上没有新提交。
// 任何一步读不到(legacy 单文件会话没有正文文件、瞬时锁、会话不存在)一律返回 null → 调用方不发 ETag、走原来的无条件全量,
// 与修前逐字节一致。
async function sessionEnvelopeStamp(id) {
  if (safeSessionId(id) === null) return null;
  try {
    const bp = sessionBodyPaths(id);
    const [head, msg, prov, jobs] = await Promise.all([
      readSessionHeadText(id),   // M3-2c: 解密后的头文本参与信封戳
      fsp.stat(bp.messages),
      fsp.stat(bp.provider),
      // Even an unchanged stat cannot authorize a cached success after key loss or a
      // same-stat replacement. The late owner hook authenticates current ledger bytes.
      EventStreamHooks.backgroundJobsStamp ? EventStreamHooks.backgroundJobsStamp(id)
        : fsp.stat(path.join(paths.sessions, 'background-jobs', id + '.json')).then(st => `${st.size}:${st.mtimeMs}:${st.ino}`, () => '-'),
    ]);
    const fileStamp = st => `${st.size}:${st.mtimeMs}:${st.ino}`;
    return crypto.createHash('sha1').update(head).digest('hex') + '|' + fileStamp(msg) + '|' + fileStamp(prov) + '|' + jobs;
  } catch (error) { if (String(error?.code || '').startsWith('work_data')) throw error; return null; }
}
// 标签 = 盘上戳 + 装载会改变响应的全部【内存】输入:活态四件(见 sessionEnvelopeLiveParts)、会话级权限档/桌面工具覆盖表
// (loadSession 会把它们盖到返回的会话对象上)、垂死回合收尾窗口(turnSettlers:窗口内 loadSession 不做残留 pending 叙事段的
// 惰性清理,出窗后同一份盘面装载出的会话就不同了)、以及 ?since 参数(管家会话的尾巴切片,响应体不同)。
// deltaKey:增量取的两个查询参数(见路由体 fromIndex/prefixStamp)—— 它们改变响应体(尾巴 vs 全量),所以进标签;
// 不带这两个参数时哈希输入与修前逐项相同(不追加这一项),无参 GET 的标签逐字节不变。
function sessionEnvelopeEtag(id, stamp, liveParts, sinceRaw, deltaKey) {
  const overrides = [
    sessionPermissionModeOverrides.has(id) ? [sessionPermissionModeOverrides.get(id)] : null,
    sessionDesktopToolsOverrides.has(id) ? [sessionDesktopToolsOverrides.get(id)] : null,
  ];
  const parts = [stamp, overrides, turnSettlers.has(id), liveParts, sinceRaw == null ? null : String(sinceRaw)];
  if (deltaKey) parts.push(['delta', deltaKey]);
  return pretenderEtag('session', pretenderHash(parts));
}
// 会话信封上【只来自内存】的那几样(活回合标志 / liveTail / liveTurn / 递话通道):GET /api/sessions/:id 的 200 体与
// 条件 GET 的 ETag 共用这一份取样 —— 判据只写一处,响应里放了什么,ETag 就带什么(sessionEnvelopeEtag 直接哈希它)。
// 纯同步只读:不碰盘、不改 reg。取样逻辑与注释原样搬自路由体(只是从内联挪成函数,一个字没动)。
function sessionEnvelopeLiveParts(id) {
  // A child can exit before its final assistant message is persisted. Keep pollers live until
  // the driver releases its existing owner, or a user-only snapshot can stop polling forever.
  let live = activeChildren.has(id) || turnSettlers.has(id);
  if (!live) {
    for (const runtime of activeAgentRuns.values()) {
      if (runtime && runtime.run && runtime.run.sessionId === id) { live = true; break; }
    }
  }
  // 117l D4(§11.9;用户第四轮走查第 3 条):活回合的尾巴。只在【真有一个活回合】时出现
  // (回合一结束这个键就不在了 —— 抽屉据此把「它正在说」换回「它刚说」),不落盘、不进任何投影。
  // 放在【信封】上而不往 session 里塞:与下面 displayTitle 同一条纪律(路由不改写会话头本身)。
  // 117m-A5(用户第六轮走查①「点开线程的看全文,还是啥也看不到」):同一个信封上再多带四个键 ——
  // full(本回合从头累加的正文,04 里硬顶 12000 字、超顶砍头)、truncated、tools(最近 ≤20 条工具名
  // 与起止,**不含参数与结果**)、startedAt/iterations。经典壳据此在会话末尾画一张临时气泡,
  // 让「在别处起的回合」也看得到它现在在说什么。仍然是【条件展开】:回合一结束这个键就不在了。
  // 白名单式逐字段搬运,不 spread reg 上那份对象 —— 累加器上还有 batchMark/lastKind 这类内部游标,
  // tools 里还有工具调用 id,都不该出现在信封上。
  const liveReg = activeChildren.get(id);
  const liveTail = liveReg && liveReg.liveTail && typeof liveReg.liveTail === 'object'
    ? {
      text: String(liveReg.liveTail.text || ''), tool: String(liveReg.liveTail.tool || ''), updatedAt: String(liveReg.liveTail.updatedAt || ''),
      full: String(liveReg.liveTail.full || ''),
      truncated: Boolean(liveReg.liveTail.truncated),
      startedAt: String(liveReg.liveTail.startedAt || ''),
      iterations: Math.max(0, Number(liveReg.liveTail.iterations) || 0),
      tools: (Array.isArray(liveReg.liveTail.tools) ? liveReg.liveTail.tools : []).slice(-20).map(row => ({
        name: String((row && row.name) || '').slice(0, 80),
        status: String((row && row.status) || ''),
        startedAt: String((row && row.startedAt) || ''),
        endedAt: String((row && row.endedAt) || ''),
      })),
    }
    : null;
  // 117o-A7(用户第七轮走查,两张截图对照:「为啥这个查看全文,不能像 2.0 那样显示呢」):
  // 同一个信封上【再加一个新键】liveTurn —— 在途回合的有序叙事账本(02c 的 createTurnSegmentBuilder,
  // 回合落盘之后经典壳重建叙事靠的就是它)。A5 的 liveTail 只是一段拼好的纯文本,渲染层再怎么写
  // 也画不出思考块 / 过程记录 / 工具卡,差距的根子是数据形状。前端拿到它以后组装成一条与落盘助手
  // 消息同形的对象,交给【渲染落盘助手消息的同一个入口】去画,不写第二套简版渲染器。
  // 三条纪律:① 上面 liveTail 那几个键一个字不动(抽屉的「它正在说」在读它,117l/117m 的断言看着它),
  // 新键是【加】不是改;② 有界与截断方向都在 02c 的 liveSnapshot() 里(段数/单段/总文本三重硬顶,
  // 超顶从头部丢弃并置 truncated:true);③ **工具结果一律不下发** —— 只送 name 与那一行参数摘要,
  // 结果可能是整份文件、可能含密钥;回合一结束真消息落盘,经典壳照常拿到全部(e2e 的 E 段钉着这条)。
  const liveNarrative = liveReg && liveReg.liveSegments && typeof liveReg.liveSegments.liveSnapshot === 'function'
    ? liveReg.liveSegments.liveSnapshot()
    : null;
  const liveTurn = liveNarrative
    ? {
      segments: Array.isArray(liveNarrative.segments) ? liveNarrative.segments : [],
      toolCalls: Array.isArray(liveNarrative.toolCalls) ? liveNarrative.toolCalls : [],
      truncated: Boolean(liveNarrative.truncated),
      startedAt: liveTail ? liveTail.startedAt : '',
      iterations: liveTail ? liveTail.iterations : 0,
    }
    : null;
  // 117s-G(27 号文 §11.13.1 ②;真浏览器复现的丢回合 bug):这条线程此刻【该走哪条递话通道】。
  // 判据不是新造的 —— 就是 13h 那条递话阶梯 stewardRelayChannelFor,顺序 answer > permission >
  // queued > steer > turn,
  // 全仓递话唯一那处判定,经 06i 的延迟绑定命名空间取(13d 直接引用 13h 会造一条前向边)。
  // 为什么信封上要有它:经典壳的发送门只认 activeTurns —— 本页自己起的那条流。管家在服务端起的
  // 回合不在里面,于是用户在「2.0 视窗」里打一句话走的是「新回合」那条路,09:1347 的
  // `activeChildren.has -> stopSession('superseded')` 把跑着的回合就地杀掉,界面零提示。
  // 只投影 {channel, wait} 两个键:questionId/pendingId 是待决面的内部锚点,不该进会话信封。
  // 空闲(channel === 'turn')时整个键都不下发 —— 存量消费者拿到的信封逐字节不变。
  const relayDecision = typeof StewardHooks.relayChannel === 'function' ? StewardHooks.relayChannel(id) : null;
  const relay = relayDecision && relayDecision.channel && relayDecision.channel !== 'turn'
    ? { channel: String(relayDecision.channel), ...(relayDecision.wait ? { wait: relayDecision.wait } : {}) }
    : null;
  return { live, liveTail, liveTurn, relay, execution: sessionExecutionSnapshot(id), executionObservation: sessionExecutionObservation(id) };
}

// 安全走查 S10:导入会话 JSON(POST /api/sessions 带 messages)时,文件里写的 cwd 不能原样当工作区 —— 一份被分享来的会话文件
// 写个 cwd:'/' 就把本会话的文件工具写根放大到整盘。前端 importSession 已不再上送文件里的 cwd;这里是服务端的第二道:
// 导入形态(body.messages 非空)若显式带了 cwd,必须落在【已配置的工作区】(默认工作区 + workspaces[] 各条)之一内部或就是它,
// 否则 400(不回显路径)。比对走真实路径(符号链接 / junction 逃不出去)。普通「新建会话」(不带 messages)不受影响:
// 它的 cwd 来自用户在界面里选的文件夹(最近用过的、拖进来的),并不要求事先登记成工作区。
async function importedSessionCwdAllowed(cwd, config) {
  const raw = typeof cwd === 'string' ? cwd.trim() : '';
  if (!raw) return true;
  const target = await resolveContainmentPath(raw);
  if (!target || target.unresolvable) return false;
  const rootsRaw = [config && config.defaultWorkspace ? config.defaultWorkspace : os.homedir()];
  for (const w of (config && Array.isArray(config.workspaces) ? config.workspaces : [])) {
    if (w && typeof w === 'object' && typeof w.path === 'string' && w.path.trim()) rootsRaw.push(w.path.trim());
  }
  for (const rootRaw of rootsRaw) {
    if (typeof rootRaw !== 'string' || !rootRaw.trim()) continue;
    const root = await resolveContainmentPath(rootRaw);
    if (root && !root.unresolvable && pathWithinRoot(target.path, root.path)) return true;
  }
  return false;
}

async function handleSessionApiRoutes(req, res, pathname) {
  if (req.method === 'GET' && pathname === '/api/sessions') {
    return send(res, json({ ok: true, sessions: await listSessions() }));
  }
  // 113b: 会话内容搜索。GET /api/sessions/search?q=&limit=
  // 必须排在下面那条 pathname.startsWith('/api/sessions/') 的通配分支【之前】，
  // 否则 'search' 会被当成会话 id 拿去查。
  if (req.method === 'GET' && pathname === '/api/sessions/search') {
    if (!tokenOk(req)) return send(res, apiFailure('auth.token_invalid', {}, 'missing or invalid workbench token', 403));
    const config = await readConfig();
    if (!sessionSearchIndexEnabled(config)) {
      // 走 apiFailure 而不是裸字符串 error：后者会被 normalizeApiErrorPayload 归结成
      // api.request_failed，真正的 code 降级成 message，调用方就分不出“关了”和“坏了”。
      // 118 波在 help.doc_missing 上栓过同一个坑。状态码给 200：它不是错误，只是能力关着。
      return send(res, apiFailure('session_search.disabled', {}, 'session search index is disabled', 200));
    }
    const params = new URL(req.url, 'http://x').searchParams;
    return SessionFullTextHooks.withUI(req,res,params.get('project'),async()=>{const result=await searchSessionsByContent(params.get('q')||'',params.get('limit'));return SessionFullTextHooks.emitUI(result,value=>send(res,json(value)));});
  }
  if (req.method === 'POST' && pathname === '/api/sessions') {
    const body = await readJsonBody(req);
    if (body && Array.isArray(body.messages) && body.messages.length && typeof body.cwd === 'string' && body.cwd.trim()
      && !(await importedSessionCwdAllowed(body.cwd, await readConfig()))) {
      return send(res, apiFailure('session.import_cwd_not_allowed', {}, 'imported session cwd must be a configured workspace (or a subfolder of one)', 400));
    }
    // 121-K3(§4.1「来源三值」):这条路由就是【用户自己按下「新会话」】那一下,来源恒为 'user'。
    // 显式钉死而不是把 body 整份透传:createSession 现在认 origin 参数,透传等于让任意调用方
    // 把自己的普通会话刷成「管家开的」—— 那正是 02 把 origin 挡在 PATCH 白名单外要防的同一件事,
    // 只挡 PATCH 不挡建会话是把门修在窗户旁边。管家族那两条路径自己传 'steward'(13k)。
    return send(res, json({ ok: true, session: await createSession({ ...(body && typeof body === 'object' ? body : {}), origin: 'user' }) }));
  }
  // Bulk history cleanup is intentionally narrower than the single-session DELETE endpoint: it only
  // clears unpinned sessions and can preserve the currently open session supplied by the UI.
  if (req.method === 'POST' && pathname === '/api/sessions/bulk-delete') {
    const body = await readJsonBody(req);
    return send(res, json(await bulkDeleteUnpinnedSessions({
      preserveSessionId: body && body.preserveSessionId,
      purgeAssociated: Boolean(body && body.purgeAssociated),
    })));
  }
  // 135c(用户 2026-09-23「会话内的后台任务进度」;拍板:只在对应线程里显示、跑完即消失、能停但先确认、
  // 别的线程只在左栏打一个小标记)。四条路由,都排在下面 '/api/sessions/' 通配分支之前(否则
  // 'background' 会被当成会话 id)。修前后台命令【没有任何 HTTP 读口】—— 只有模型自己的 shell_* 工具看得见。
  //   GET  /api/sessions/background-counts      各线程在跑的后台件数(左栏标记用;只有计数,不带内容)
  //   GET  /api/sessions/:id/background         这条线程在跑的后台任务:后台命令 + 后台子代理 + 班组
  //   GET  /api/sessions/:id/background/output  某条后台命令的最近输出(过 redact)
  //   POST /api/sessions/:id/background/stop    停一件:命令走 shellKill(认主),子代理/班组走既有 stop 动作
  if (req.method === 'GET' && pathname === '/api/sessions/background-counts') {
    if (!tokenOk(req)) return send(res, apiFailure('auth.token_invalid', {}, 'missing or invalid workbench token', 403));
    const shells = EventStreamHooks.backgroundShells;
    const counts = shells ? shells.counts() : {};
    for (const row of sessionBackgroundRunRows(null)) counts[row.sessionId] = (counts[row.sessionId] || 0) + 1;
    return send(res, json({ ok: true, counts }));
  }
  {
    const bg = /^\/api\/sessions\/([^/]+)\/background(\/output|\/stop)?$/.exec(pathname);
    if (bg) {
      if (!tokenOk(req)) return send(res, apiFailure('auth.token_invalid', {}, 'missing or invalid workbench token', 403));
      const sid = safeSessionId(safeDecodeURIComponent(bg[1]));   // 坏编码(%zz)→ null → 400,不再 URIError 500
      if (!sid) return send(res, apiSessionIdInvalid());
      if (req.method === 'GET' && !bg[2]) {
        const shells = EventStreamHooks.backgroundShells;
        const items = (shells ? shells.rows(sid) : []).concat(sessionBackgroundRunRows(sid));
        items.sort((a, b) => String(a.startedAt).localeCompare(String(b.startedAt)));
        return send(res, json({ ok: true, sessionId: sid, items }));
      }
      if (req.method === 'GET' && bg[2] === '/output') {
        const shellId = new URL(req.url, 'http://x').searchParams.get('shellId') || '';
        const shells = EventStreamHooks.backgroundShells;
        const out = shells ? shells.outputTail(sid, shellId, 8000) : null;
        if (!out) return send(res, json({ ok: false, error: 'background command not found' }, 404));
        return send(res, json({ ok: true, ...out }));
      }
      if (req.method === 'POST' && bg[2] === '/stop') {
        const body = await readJsonBody(req);
        const taskId = String((body && body.id) || '');
        if (taskId.startsWith('shell:')) {
          const shells = EventStreamHooks.backgroundShells;
          const result = shells ? shells.stop(sid, taskId.slice(6)) : { ok: false };
          logEvent({ kind: 'background_task_stop', sessionId: sid, taskId, ok: result.ok === true, by: 'user' });
          return send(res, json(result.ok ? { ok: true, state: 'stopped' } : { ok: false, error: 'background command not found' }, result.ok ? 200 : 404));
        }
        if (taskId.startsWith('run:')) {
          const result = await agentRunActionCommand({ sessionId: sid, runId: taskId.slice(4), action: 'stop' });
          logEvent({ kind: 'background_task_stop', sessionId: sid, taskId, ok: result.status === 200, by: 'user' });
          return send(res, json(result.body, result.status));
        }
        return send(res, json({ ok: false, error: 'unknown background task id' }, 400));
      }
      return send(res, json({ ok: false, error: 'method not allowed' }, 405));
    }
  }
  // 单条会话的 GET / PATCH / DELETE 只认 /api/sessions/<一段>。修前是 startsWith + path.basename(pathname):
  // /api/sessions/随便/什么/<id> 与 /api/sessions/<id>/ 都被当成 <id> —— 同一条会话有无数个别名(DELETE 也吃),
  // 以后再加 /api/sessions/:id/xxx 子路由时稍不留神就被这里先吞掉。其余形状落到路由末尾的 api.route_not_found。
  const single = pathname.match(/^\/api\/sessions\/([^/]+)$/);
  if (single) {
    // 与后台任务那几条同一个解码口径:坏编码(%zz)→ '' → 下面各分支按不合形的 id 处理(404 / 400)。
    const id = safeDecodeURIComponent(single[1]) || '';
    if (req.method === 'GET') {
      if (!safeSessionId(id)) return send(res, apiSessionNotFound());   // 不合形/保留名(01 safeSessionId)不可能是一条会话
      // Mapping expiry/import/revocation may change a user-facing copy without a
      // canonical session write. Such sessions must not reuse canonical HTTP/delta
      // cache proofs. Fresh OFF sessions retain the original fast paths.
      const displayPrivate = Boolean(await PrivacyGateway.displayCacheKey(id));
      const displayReply = async (envelope, headers = {}) => send(res, json(await PrivacyGateway.displayEnvelope(id, envelope), 200, headers));
      // 条件 GET(perf):这条路由每 3 s(直播回合)/ 5–30 s(管家抽屉)被轮询一次,而 loadSession 要读整份头 + 两个
      // 正文并逐行 sha1(18 MB 会话 250–350 ms;逐行 sha1 后来去掉了,见 02 sessionBodyState)。ETag 在【装载之前】用「头文件内容哈希 + 两个正文的大小 + 后台任务账本 +
      // 内存覆盖表 + 内存活态」算出,与 If-None-Match 相等就直接 304,连会话都不装载。取样顺序有讲究:盘上的戳在装载【之前】取,
      // 装载期间若有写者落盘,下一次比对必然不等 → 只会多回一次 200,绝不会拿旧标签配新内容(只可能多刷新,不会漏刷新)。
      // 内存活态在 200 体里现算(与体里放的东西同一份取样);304 判定用装载前的取样:活态没变才相等。
      // providerHistory 仍在 200 体里:大量 e2e 与外部脚本从这条路由读它(前端虽不读,也不删 —— 断言只加不改)。
      const sinceRaw = id === STEWARD_SESSION_ID ? new URL(req.url, 'http://x').searchParams.get('since') : null;
      // perf(前端长会话):?fromIndex=N&prefixStamp=S —— 经典壳在自己起的回合收尾时只要 messages[N..]。S 是 02 sessionMessagesStamp
      // 给出的前缀戳(回合起点那条 session 事件上带着);服务端对【此刻要下发的】前 N 条重算一遍,相等才回尾巴,否则(历史被改写过、
      // N 超长、参数是垃圾)回与不带参数时逐字节相同的全量体。与 since 互斥(since 优先,管家会话的尾巴切片语义不动)。
      const deltaQuery = sinceRaw == null ? new URL(req.url, 'http://x').searchParams : null;
      const deltaFromRaw = deltaQuery ? deltaQuery.get('fromIndex') : null;
      const deltaStampRaw = deltaQuery ? deltaQuery.get('prefixStamp') : null;
      const deltaKey = !displayPrivate && (deltaFromRaw != null || deltaStampRaw != null) ? [deltaFromRaw, deltaStampRaw] : null;
      // perf(前端长会话):?view=live —— 经典壳看「别处起的回合」时每条 thread.live 推送(约 1 次/秒)来一发,只读信封上的在跑部分
      // (liveTail / liveTurn / relay / resumable.live)。修前每发都整份装载并下发全部历史(2000 条消息约 7.7 MB)。
      // 真有活回合时只读会话头、回轻量信封(view:'live',session 只带几个标量,不是完整会话);没有活回合就落回下面的全量路径
      // —— 回合刚收尾的那一拍前端正要把整份会话换上来,拿到的就是它。不带 view 的调用逐字节不变。
      if (sinceRaw == null && new URL(req.url, 'http://x').searchParams.get('view') === 'live') {
        const liveParts = sessionEnvelopeLiveParts(id);
        const head = liveParts.live ? await readSessionHeadResilient(id) : null;
        if (head && typeof head === 'object') {
          const { liveTail, liveTurn, relay, execution, executionObservation } = liveParts;
          const turnSeq = Math.max(0, Number(head.turnSeq) || 0);
          const count = (n, list) => (Number.isInteger(n) ? n : (Array.isArray(list) ? list.length : 0));
          const historyLength = count(head.providerHistoryCount, head.providerHistory);
          return displayReply({
            ok: true, view: 'live', execution, executionObservation,
            session: { id, updatedAt: String(head.updatedAt || ''), turnSeq, messageCount: count(head.messageCount, head.messages), providerHistoryCount: historyLength },
            resumable: { dangling: false, kind: null, turnSeq, historyLength, live: true },
            ...(liveTail ? { liveTail } : {}), ...(liveTurn ? { liveTurn } : {}), ...(relay ? { relay } : {}),
          }, { 'cache-control': 'no-store' });
        }
      }
      // 审查轮:活态在盘上戳【之前】取。反过来(先戳后活态)时,两次取样之间「落盘 + 活态翻转」可能拼出一个等于客户端手上旧标签的
      // 组合(旧盘 + 新活态),回一次不该回的 304;先取活态,竞态最多多回一次 200。
      const preLive = sessionEnvelopeLiveParts(id);
      const envelopeStamp = await sessionEnvelopeStamp(id);
      if (envelopeStamp && !displayPrivate) {
        const preEtag = sessionEnvelopeEtag(id, envelopeStamp, preLive, sinceRaw, deltaKey);
        if (pretenderNotModified(req, preEtag)) return send(res, { status: 304, headers: { etag: preEtag, 'cache-control': 'no-store' }, body: '' });
      }
      const notFound = () => send(res, id === STEWARD_SESSION_ID ? json({ ok: true, execution: sessionExecutionSnapshot(id), executionObservation: sessionExecutionObservation(id), session: { id: STEWARD_SESSION_ID, messages: [] }, resumable: null, displayTitle: '', created: false }) : apiSessionNotFound()); // 管家会话懒创建:首个管家回合落盘前回空历史(created:false),不再每次加载页面都在控制台留一条 404;别的会话照旧 404
      // perf(增量取):带 fromIndex/prefixStamp 的请求先用「不读 provider 正文」的装载视图(02 SESSION_LOAD_OMIT_PROVIDER:
      // 前提拿不准它自己就是一次完整装载)。前缀戳对不上 = 要回全量,全量体里有 providerHistory,于是换一份完整装载再往下走。
      let session = await loadSession(id, 0, 0, deltaKey ? SESSION_LOAD_OMIT_PROVIDER : null);
      if (!session) return notFound();
      let delta = null;
      if (deltaKey) {
        const omitted = sessionOmittedProviderHistory(session);
        delta = sessionMessagesDelta(session.messages, deltaFromRaw, deltaStampRaw, omitted ? omitted.body : null);
        if (!delta && omitted) {
          session = await loadSession(id);
          if (!session) return notFound();
        }
      }
      // v0.8-S0 A6: surface whether the last turn dangles (arrested mid-flight) so the UI can offer resume.
      // 运行中豁免:活回合/活 agent run 在跑时,providerHistory 尾部恰好就是 detectDanglingTurn
      // 判悬挂的形状(user 尾/tool 尾/未答 tool_calls)——切到还在正常跑的会话不能弹「未正常结束」
      // 横幅,故 live 会话直接返回不悬挂。
      const liveParts = sessionEnvelopeLiveParts(id);
      const { live, liveTail, liveTurn, relay, execution, executionObservation } = liveParts;
      // 200 体的标签:盘上戳是装载前取的(见上),内存活态是这一刻取的;没有戳(读不到头/正文)就不发 ETag,照旧无条件全量。
      const envelopeHeaders = displayPrivate ? { 'cache-control': 'no-store' }
        : envelopeStamp ? { etag: sessionEnvelopeEtag(id, envelopeStamp, liveParts, sinceRaw, deltaKey), 'cache-control': 'no-store' } : {};
      // 117l-A1-fix2(§11.9;B1 实现抽屉时发现,主会话核对源码):抽屉 steward-drawer.js 的
      // isLive() 第一判据是 `resumable && resumable.live === true`,而这个活回合分支修前没有
      // `live` 键,那条判据从没走通过,一直静默回落到「事项行五态 === 'running'」——挂在
      // request_user_input 上等答案的回合五态是 needs_you,于是被判成不在跑,抽屉的轮询节拍
      // (活 5s／闲 15s)与 activitySnapshot 都跟着错。只加这一个键;detectDanglingTurn 那一支
      // (真正判悬挂的形状)一个字不动。
      const resumable = live
        ? { dangling: false, kind: null, turnSeq: Math.max(0, Number(session.turnSeq) || 0), historyLength: sessionProviderHistoryLength(session), live: true }
        : detectDanglingTurn(session);
      // 116-4（27 号文 §11.7 第 3 项「唤醒链诚实」）：GET /api/sessions/steward?since=<ISO> 只回
      // 该时刻【之后】的消息。117b 的轮询发现 state.lastReply.at 变了（trigger:'inbox'）之后要把新
      // 回合追加进对话流，整份拉一遍管家会话在长会话上是几百 KB 的重复载荷。
      // 纪律：① 只对管家会话生效 —— 别的会话有自己的分页语义，不在本波范围；② 不带 since 的旧调用
      // 逐字节不变（没有这个参数就走原路，一行都不改）；③ 只切 messages 的尾巴，其余字段原样带出，
      // 前端拿到的仍是同一个形状；④ 不改会话对象本身（浅拷贝），loadSession 的返回值不许被路由改写。
      const sinceMs = sinceRaw ? Date.parse(String(sinceRaw)) : NaN;
      if (Number.isFinite(sinceMs)) {
        const all = Array.isArray(session.messages) ? session.messages : [];
        const tail = all.filter(m => {
          const at = Date.parse(String((m && m.createdAt) || ''));
          return Number.isFinite(at) && at > sinceMs;
        });
        return displayReply({ ok: true, execution, executionObservation, session: { ...session, messages: tail }, resumable, since: String(sinceRaw), messageCount: all.length, ...(liveTail ? { liveTail } : {}), ...(liveTurn ? { liveTurn } : {}) }, envelopeHeaders);
      }
      // 增量取:前缀戳对得上才回尾巴。信封与全量同形(同一组键、同一份 resumable/displayTitle/活态),只有三处不同 ——
      // session.messages 只是 messages[N..];session 上不带 providerHistory(前端从不读它,全量里照旧有);信封上多
      // messagesFrom(= N,客户端据此拼接)/ messageCount(整份条数,客户端拼完自检)/ messagesStamp(整份的新戳,可接着再增量)。
      // 对不上就什么都不做,落到下面的全量 —— 标签里带着参数,所以同一状态下全量与增量的标签不同,304 各认各的。
      // (delta 在装载之后就算好了,见上。)
      if (deltaKey) {
        if (delta) {
          const { providerHistory: _providerHistory, ...sessionHead } = session;
          return displayReply({
            ok: true, execution, executionObservation, session: { ...sessionHead, messages: delta.tail }, resumable, displayTitle: sessionDisplayTitle(session),
            messagesFrom: delta.from, messageCount: delta.count, messagesStamp: delta.stamp,
            ...(liveTail ? { liveTail } : {}), ...(liveTurn ? { liveTurn } : {}), ...(relay ? { relay } : {}),
          }, envelopeHeaders);
        }
      }
      // 116-5b(§11.8.5):这条线程该显示什么名字,由 02 的 sessionDisplayTitle 一处判定。
      // 放在【信封】上而不是往 session 里塞:session 就是会话头本身,路由不许改写它的形状
      // (上面 since 分支那条「不改会话对象本身」是同一条纪律);抽屉/「现在这一件」的标题读这个键。
      return displayReply({ ok: true, execution, executionObservation, session, resumable, displayTitle: sessionDisplayTitle(session), ...(liveTail ? { liveTail } : {}), ...(liveTurn ? { liveTurn } : {}), ...(relay ? { relay } : {}) }, envelopeHeaders);
    }
    if (req.method === 'PATCH' || (req.method === 'POST' && req.headers['x-http-method'] === 'PATCH')) {
      const body = await readJsonBody(req);
      // 116-3 A2:管家会话不是线程 —— 它没有权限档、没有标题重命名语义,元数据一律不许经这条通用
      // 路由改(GET 保留:117c 的历史渲染要读它)。与 10 的回合入口那道门同一条纪律:管家会话的写面
      // 只有管家运行器自己。
      if (id === STEWARD_SESSION_ID) {
        return send(res, apiFailure('steward.forbidden', {}, 'the steward session cannot be patched through /api/sessions', 403));
      }
      if (!safeSessionId(id)) return send(res, apiSessionNotFound());
      // 116-2a(27 号文 §3.3/§8.6「每条线程一个权限 chip、点开即换、立即生效」):线程级权限就地快切。
      // 与 engineRoute 同端点、同风格(它是会话级字段的既有先例)。两道门:
      //   ① 白名单 —— 非 PERMISSION_MODES 的值 400,绝不悄悄回落(用户按了一个档,系统却按另一个档跑,
      //      是第 78 波注释里点名的那类事故);null/'' 是【合法】的,意思是「清除会话级设置,回落全局」。
      //   ② 二次确认 —— 切到全自动必须显式 confirm:true,否则 409。这是 §8.6 那条弹窗要求的服务端一半:
      //      服务端不能只信 UI 弹过窗,任何调用方(脚本/117 壳/未来的管家 UI)都得过这道门。
      //      收紧与清除不需要确认。
      if (body && Object.prototype.hasOwnProperty.call(body, 'permissionMode')) {
        const requested = body.permissionMode == null ? '' : String(body.permissionMode);
        if (requested !== '' && !PERMISSION_MODES.includes(requested)) {
          return send(res, apiFailure('session.invalid_permission_mode', { permissionMode: requested, allowed: PERMISSION_MODES },
            `permissionMode must be one of ${PERMISSION_MODES.join('/')}, or null/"" to follow the global default`, 400));
        }
        if (PERMISSION_MODES_REQUIRING_CONFIRM.includes(requested) && body.confirm !== true) {
          return send(res, apiFailure('permission.confirm_required', { permissionMode: requested },
            'switching a thread to full-auto requires an explicit confirm:true (it can change files and run commands while you are away)', 409));
        }
      }
      // 117z-E2b 提交②(27 号文 §11.21.7 债 ②):给线程开桌面工具是与「切全自动」同一道门的另一种口径 ——
      // 修前只有 permissionMode 要 confirm:true,`desktopTools:true` 直接过。严格只看 === true:false / null /
      // '' / 不带键都是收紧或清除,与 permissionMode 那条一样不需要确认。错误码沿用同一个,前端一处分支。
      if (body && body.desktopTools === true && body.confirm !== true) {
        return send(res, apiFailure('permission.confirm_required', { desktopTools: true },
          'giving a thread desktop tools requires an explicit confirm:true (it can see your screen and press keys while you are away)', 409));
      }
      const session = await updateSessionMeta(id, body);
      if (!session) return send(res, apiSessionNotFound());
      const patchedConfig = await readConfig();
      // 审计:权限档是安全面,每一次改动都要能事后对账(谁、哪条线程、从哪档到哪档、生效档是什么)。
      if (body && Object.prototype.hasOwnProperty.call(body, 'permissionMode')) {
        logEvent({
          kind: 'session', source: 'permission_mode', sessionId: id,
          permissionMode: sessionMeta(session).permissionMode,
          effectivePermissionMode: resolvePermissionMode({ session, config: patchedConfig }),
          confirmed: body.confirm === true,
        });
      }
      // 117z-E2b 提交②:桌面工具的会话级覆盖同样是安全面,照 permission_mode 那条的形状记一行
      //(哪条线程、写成了什么、是不是带 confirm 来的)。desktopTools 读的是落盘后的三态(true/false/null)。
      if (body && Object.prototype.hasOwnProperty.call(body, 'desktopTools')) {
        logEvent({
          kind: 'session', source: 'desktop_tools', sessionId: id,
          desktopTools: sessionDesktopToolsOf(session),
          confirmed: body.confirm === true,
        });
      }
      // 既有形状只加不改:`session` 原样保留(既有断言与前端都读它),额外带一份 sessionMeta —— 它是
      // 权限 chip 要的两个字段(会话级 permissionMode / 派生 effectivePermissionMode)的唯一读形。
      return send(res, json({ ok: true, session, sessionMeta: sessionMeta(session, patchedConfig) }));
    }
    if (req.method === 'DELETE' || (req.method === 'POST' && req.headers['x-http-method'] === 'DELETE')) {
      // 列表只发布 safeSessionId 合法的 id(02 重建索引的判据),不合法的 id 不可能是一条会话:先回 400,
      // 不再对它跑 stopSession / revokeAllGrants / 一串 unlink,再回一个假的 ok:true。
      if (!safeSessionId(id)) return send(res, apiSessionIdInvalid());
      return send(res, json(await deleteSession(id)));
    }
  }
  return false;
}

// ============================================================================
// 第70波(EC-E Mission Ready 首切片):/api/missions 聚合只读投影。
// 纪律:①纯读模型 —— 不复制第二套执行状态机,快照全部从既有权威源(mission 账本 / run 快照 /
// checkpoint journal / usage 月度账本 / 内存 pending 注册表)现算;②旧会话适配只读派生(sessionKind),
// 绝不回写磁盘;③列表只读会话头文件(<id>.json 含 mission,不触 messages/provider 正文),详情才全量加载。
// ============================================================================

// 卡片/快照共用的状态派生:complete(全部里程碑 done) > active(until-done 驱动中) > paused(supervised =
// 预算耗尽/停滞/用户接管后的待命态) > idle(off 且未完成)。mission 缺失时不应出现在任务列表('none')。
function missionCardStatus(m) {
  if (!m) return 'none';
  const ms = Array.isArray(m.milestones) ? m.milestones : [];
  if (ms.length > 0 && ms.every(x => x && x.status === 'done')) return 'complete';
  if (m.autoMode === 'until-done') return 'active';
  if (m.autoMode === 'supervised') return 'paused';
  return 'idle';
}

// 未决事项统一读形(第71b:四源统一 —— permission/question/plan/pool 全部从 session.interventions NDJSON 现算)。
// 前三者此前是纯内存 Map(04-permission-runtime:191/194/199),重启即归零;71 波旁路持久化为 Intervention(02
// append-only NDJSON),重启终态化(markInterruptedInterventions)后 pending 标 cancelled_restart -> 计数归零。
// 71b 池提案统一进来:paused run 的提案恢复后仍可审批,boot 对账补登记 + markInterruptedInterventions 按 run
// 状态分流保留 pending(见 02/08);run 快照扫描仅作并集兜底(append 落盘延迟 + 对账前存量),按 id 去重不双计。
async function missionPendingCounts(sessionId, runs, interventions) {
  const ivs = Array.isArray(interventions) ? interventions : await readInterventions(sessionId).catch(() => []);
  let permissions = 0, questions = 0, plans = 0, pool = 0;
  const poolPendingIds = new Set();
  for (const iv of ivs) {
    if (!iv || iv.status !== 'pending') continue;
    if (iv.type === 'permission') permissions++;
    else if (iv.type === 'question') questions++;
    else if (iv.type === 'plan') plans++;
    else if (iv.type === 'pool') { pool++; poolPendingIds.add(String(iv.id)); }
  }
  for (const r of (runs || [])) for (const item of ((r && r.taskPool) || [])) {
    if (item && item.status === 'proposed' && !poolPendingIds.has(String(item.id))) { pool++; poolPendingIds.add(String(item.id)); }
  }
  return { permissions, questions, plans, pool };
}

function clipMissionRunText(value, max = 360) {
  return String(value || '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function lastMissionRunProgress(node) {
  const rows = Array.isArray(node && node.progressLog) ? node.progressLog : [];
  for (let index = rows.length - 1; index >= 0; index--) if (rows[index]) return rows[index];
  return null;
}

// 第82波班组图只消费这份精简节点投影。节点结果、角色快照、工具证据等大字段仍留在 Agent Run
// 权威文件；Mission 详情只带画图和递话资格所需事实，避免复制运行状态机或把 24KB result 带进任务单。
function missionRunGraph(src, live) {
  const nodes = Array.isArray(src && src.nodes) ? src.nodes : [];
  // 第98波(P5-A):真实调度波次 -- 按并发上限+wait 模拟派发,下发给前端班组图分列(替代纯拓扑层)。
  const waveSeq = computeWaveSeq(nodes, {
    concurrency: Number(src && src.concurrency) || 1,
    isWaitNode: n => !!(n && n.wait),
  });
  return {
    nodes: nodes.map(node => {
      // Read backwards instead of cloning/filtering a potentially long progress history on every Preview poll.
      const progress = lastMissionRunProgress(node);
      const eligibility = live
        ? nodeDeliveryEligibility(src, String(node && node.id || ''), { allowClaude: true })
        : { ok: false, reason: 'not_live' };
      return {
        id: String(node && node.id || ''),
        status: String(node && node.status || ''),
        roleId: String(node && (node.roleId || node.role) || ''),
        roleLabel: clipMissionRunText(node && node.roleLabel, 80),
        task: clipMissionRunText(node && node.task, 520),
        dependsOn: Array.isArray(node && node.dependsOn) ? node.dependsOn.map(value => String(value || '')).filter(Boolean).slice(0, 16) : [],
        engine: String(node && node.engine || ''), model: clipMissionRunText(node && node.model, 100),
        progress: clipMissionRunText(progress && progress.text, 220),
        startedAt: String(node && node.startedAt || ''), completedAt: String(node && node.completedAt || ''),
        fromPool: node && node.fromPool === true, proposedBy: String(node && node.proposedBy || ''),
        deterministic: Boolean(node && node.gate && ['vote', 'dedupe', 'coverage', 'propagate'].includes(node.gate.mode)),
        steerable: eligibility.ok === true, steerReason: String(eligibility.reason || ''),
        ...(waveSeq.has(String(node && node.id || '')) ? { wave: waveSeq.get(String(node && node.id || '')) } : {}),
      };
    }),
    proposals: (Array.isArray(src && src.taskPool) ? src.taskPool : [])
      .filter(item => item && item.status === 'proposed')
      .map(item => ({
        id: String(item.id || ''), status: 'proposed', proposedBy: String(item.proposedBy || ''),
        task: clipMissionRunText(item.task, 520), reason: clipMissionRunText(item.reason, 220),
        roleId: String(item.roleId || ''),
        dependsOn: Array.isArray(item.dependsOn) ? item.dependsOn.map(value => String(value || '')).filter(Boolean).slice(0, 16) : [],
      })),
  };
}

// run 摘要投影(对齐 /api/agent-runs?view=digest 的标量集 + 用量字段;live run 以内存为准)。
// includeGraph 仅供单 Mission 详情使用；300 Mission 列表和 75c 索引继续保持标量热路。
function missionRunDigest(r, includeLive = true, includeGraph = false) {
  const live = includeLive ? activeAgentRuns.get(r.id) : null;
  const mem = live && live.run ? live.run : null;
  const src = mem || r;
  const digest = {
    id: src.id, status: src.status, eventSeq: Number(src.eventSeq) || 0,
    createdAt: src.createdAt || '', updatedAt: src.updatedAt || '', completedAt: src.completedAt || '',
    nodeCount: Array.isArray(src.nodes) ? src.nodes.length : 0,
    poolPending: ((src.taskPool) || []).filter(p => p && p.status === 'proposed').length,
    live: !!live, paused: !!(live && live.paused), resumeTier: src.resumeTier || '',
    health: agentRunHealth(src, !!live),
    totalTokens: Number(src.totalTokens) || 0, costUsd: Number(src.costUsd) || 0,
  };
  if (includeGraph) Object.assign(digest, missionRunGraph(src, live));
  return digest;
}

// 列表卡片:从会话头文件投影(头含 mission,见 saveSession 头/正文拆分)。
async function buildMissionCard(head, runs, opts = {}) {
  // 116-4 第 0 步（复现出来的根因）：kind 是 'mission' 但头上【没有】mission 容器的会话是
  // 真实形状 —— steward_thread_new 建线程时显式写 kind='mission'，mission 容器要等
  // /api/mission start 才有。修前这里 m.goal 直接读 null，而 buildPretenderSessionSlice 没有
  // try，rebuildPretenderIndexFull 的 Promise.all 整份 reject：GET /api/missions、/api/missions/<id>、
  // GET /api/interventions 全部 500，收件箱每轮 tick 抛 "Cannot read properties of null (reading 'goal')"
  // 三个源一起停摆 —— 这正是「线程跑完管家没被唤醒」的第一层根因。
  // missionCardStatus(null) 早就返回 'none'（故它仍收 m 而不是 mm，否则 {} 会变成 'idle'）——
  // 本函数其余部分本来就是按「可能没有 mission」写的，只有下面那一段漏了守卫。
  const m = head.mission;
  const mm = (m && typeof m === 'object') ? m : {};
  const ms = Array.isArray(mm.milestones) ? mm.milestones : [];
  return {
    // 117r-D1:kind 从写死的 'mission' 改成【如实】取 sessionKind(head)。修前唯一的调用面是
    // 13e「kind === 'mission' 才造卡片」,所以这个字面量恒等于真值;现在管家关心的速查线程也有卡片了,
    // 再写死就是撒谎。mission 会话(含 steward_thread_new 那种 kind='mission' 但没有 mission 容器的)
    // 走 sessionKind 仍然返回 'mission',既有行为逐字不变。
    // 117r-D5:这个字段的【消费者换了一批】。修前它是五态第一条分支的守卫入参(kind === 'quick_ask'
    // 就短路),所以谎报会让速查线程顶着「交办中/已收工」;修后五态不再读 kind(守卫改看
    // factsUnknown),它转而是「这条线程是什么」的唯一出处 —— 看板行上那枚速查徽标
    // (public/js/steward-board.js 读 row.kind)就靠它。谎报的后果从「状态说错」变成「身份说错」,
    // 如实取 sessionKind 这件事因此比修前更要紧,不是更松。
    sessionId: head.id, missionId: sessionMissionId(head), title: head.title || '', cwd: head.cwd || '', kind: sessionKind(head),
    // 121-K3(34 号文 §4.2):`kind` 与「这是不是一条速查线程」**从这一刀起不再是同一件事**。
    // 修前 13e 只给 mission 与【管家关心的】线程造卡片,于是「有卡片 + kind==='quick_ask'」恰好等价于
    // 「管家用 steward_quick_ask 开的速查线程」—— 117r-D5 那段注释就是建立在这个巧合上的。
    // K3 把索引口径放宽成 threadVisible 之后,用户自己在 2.0 里聊的普通会话也有卡片了,而 sessionKind
    // 对它们同样返回 'quick_ask'(第 70 波的「纯问答默认档」,那是【档位】不是【身份】)—— 巧合破了。
    // 所以身份单独给一格,判据与 13j 的 stewardQuickThread 逐字同源(头上有没有 stewardQuick 容器):
    // 速查线程是管家为了回答一个问题临时开的,普通会话不是,两者在同一个 kind 里区分不开。
    quick: !!(head.stewardQuick && typeof head.stewardQuick === 'object'),
    // 116-5b(§11.8.5):这条线程该显示什么名字,由 02 的 sessionDisplayTitle 一处判定(人起的 >
    // 生成的 > 原话),前端只读结果不再算一遍 —— 与本行已有的 stateLabel / missionTitle / wait.label
    // 同一条纪律(读模型里本来就有一批服务端算好的显示串)。title 保持原话不动。
    // brief 单独带出是为了那句 gist(名字之外还要一句人话概括,抽屉与搜索结果要用);缺席时不出现。
    displayTitle: sessionDisplayTitle(head),
    // 117l D4(§11.9):最后一句助手原话的头部(= head.summary,09 收尾处写的前 160 字,不经模型改写)。
    // 看板行的「它在问你」要判「末句是不是问号」,而 13e 的活叠加层只拿得到卡片 —— 没这一个字段就只能
    // 每行再读一次会话头。只是会话头已有字段的投影,不新增任何持久化来源。
    // **注意截断**:summary 只有 160 字,长回复的末句问号会被截掉 —— 漏报是安全的(不会把不是问句
    // 的说成问句),完整判定在 steward_thread_status(那里会话正文已装载)。
    lastSay: String(head.summary || ''),
    ...(sessionBriefOf(head) ? { brief: sessionBriefOf(head) } : {}),
    createdAt: head.createdAt || '', updatedAt: head.updatedAt || '',
    status: missionCardStatus(m),
    // 117p-S2(30 号文 §8.3):五态判据需要的两个卡片字段 —— 都只是会话头已有字段的投影,不新增
    // 持久化来源(与 lastSay / displayTitle 同一条纪律)。缺了它们,两份五态抄写件只能把 turnSeq
    // 硬编码成 0,于是「跑过回合但头上没有 mission 账本」的管家线程永远落不进 done/stopped。
    turnSeq: Math.max(0, Number(head.turnSeq) || 0),
    lastTurn: head.stewardLastTurn && typeof head.stewardLastTurn === 'object'
      ? { seq: Math.max(0, Number(head.stewardLastTurn.seq) || 0), ok: head.stewardLastTurn.ok !== false, aborted: head.stewardLastTurn.aborted === true }
      : null,
    activeTurn: opts.persistent ? false : activeChildren.has(head.id), // 75c:live overlay 不写进可重建持久索引
    ...(opts.persistent ? {} : { execution: sessionExecutionSnapshot(head.id) }),
    ...(opts.persistent ? {} : { queued: stewardThreadTurnQueued(head.id) }), // hunt3:排队中的回合,同上只活在叠加层
    mission: {
      goal: mm.goal || '', createdAt: mm.createdAt || '', updatedAt: mm.updatedAt || '',
      autoMode: mm.autoMode || 'off',
      milestonesTotal: ms.length,
      done: ms.filter(x => x && x.status === 'done').length,
      blocked: ms.filter(x => x && x.status === 'blocked').length,
      pending: ms.filter(x => !x || x.status === 'pending').length,
      budget: mm.budget || { maxAutoTurns: 0, maxTokens: 0 },
      spent: mm.spent || { autoTurns: 0, tokens: 0 },
      budgetExhausted: Boolean(mm.budgetExhaustedAt), budgetExhaustedAt: String(mm.budgetExhaustedAt || ''),   // 后者给管家收件箱当去重键:任务重启后再次用尽是新的一件事
      // 第72波:结果章存根(列表卡片只带状态+时间,明细走详情快照 result)
      result: (mm.result && typeof mm.result === 'object') ? { status: mm.result.status || '', finishedAt: mm.result.finishedAt || '' } : null,
    },
    pending: await missionPendingCounts(head.id, runs, opts.interventions),
    runCount: (runs || []).length,
    lastRun: runs && runs.length ? missionRunDigest(runs[runs.length - 1], !opts.persistent) : null,
    // Latest persisted run plus every live run: a healthy newer run cannot hide an older live fault.
    healthRuns: missionHealthRuns(head.id, runs, !opts.persistent),
  };
}

function missionHealthRuns(sessionId, runs, includeLive = true) {
  const latest = (Array.isArray(runs) ? runs : []).filter(run => run && run.id)
    .slice().sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')) || String(b.id).localeCompare(String(a.id)))[0];
  const byId = new Map();
  if (latest) byId.set(latest.id, missionRunDigest(latest, includeLive));
  if (includeLive) for (const runtime of activeAgentRuns.values()) {
    const run = runtime && runtime.run;
    if (run && run.sessionId === sessionId) byId.set(run.id, missionRunDigest(run, true));
  }
  return [...byId.values()];
}

// ── 第 116 波 116g(27 号文 §3.1 / §8.10):事项级聚合读模型 ─────────────────────
// 一处装配,两处消费(GET /api/missions 的只加字段、13g 的 steward_missions 工具)。纪律与 70 波
// /api/missions 同源:**纯读模型** —— 线程五态取投影 card(与看板逐字节同源),事项级状态只经 06i 的
// `aggregateMissionState` 纯函数,绝不在这里另写一份判据;没有事项文件的 missionId 按需派生
// (`derived:true`,标题取会话标题),不落盘、不回写、不迁移。

// 02 事项容器的稳定信封 error -> HTTP 状态。事项/线程找不到是 404,容量满是 409(可重试的资源
// 约束,不是请求写错了),其余一律 400。表在这里而不在域侧:域函数不认识 HTTP。
function missionContainerHttpStatus(error) {
  if (error === 'not_found' || error === 'session_not_found') return 404;
  if (error === 'capacity_exceeded') return 409;
  return 400;
}
// 失败信封统一走 P2 的 apiFailure(code/params/message)—— 直接把 { ok:false, error:'字符串' } 送进
// json() 会被 normalizeApiErrorPayload 归一成 code:'api.request_failed',错误码就丢了。
const MISSION_FAILURE_PARAM_KEYS = ['limit', 'count', 'missionId', 'sessionId'];
function missionContainerFailure(result) {
  const params = {};
  for (const key of MISSION_FAILURE_PARAM_KEYS) if (result && result[key] !== undefined) params[key] = result[key];
  return apiFailure('mission.' + String((result && result.error) || 'failed'), params,
    String((result && result.message) || ''), missionContainerHttpStatus(result && result.error));
}

function emptyMissionCostBucket() {
  return { turns: 0, inTok: 0, outTok: 0, cachedInTok: 0, costsByCurrency: {} };
}
function addMissionCostBucket(bucket, usage) {
  if (!usage || typeof usage !== 'object') return bucket;
  bucket.turns += Number(usage.turns) || 0;
  bucket.inTok += Number(usage.inTok) || 0;
  bucket.outTok += Number(usage.outTok) || 0;
  bucket.cachedInTok += Number(usage.cachedInTok) || 0;
  for (const [currency, amount] of Object.entries(usage.costsByCurrency || {})) {
    if (!Number.isFinite(Number(amount))) continue;
    bucket.costsByCurrency[currency] = Math.round(((bucket.costsByCurrency[currency] || 0) + Number(amount)) * 1e6) / 1e6;
  }
  return bucket;
}

// 测试用确定性计数(不靠墙钟):workspaceComputed = 真正跑了一次「工作区归属判定」的次数(同 cwd 一次装配内只算一次)。
const missionAggregateStats = { workspaceComputed: 0 };
async function buildMissionAggregateRows(options = {}) {
  const includeArchived = options.includeArchived === true;
  // W7(用户 2026-09-24「管家需要把工作区和任务联系起来」):事项与线程的读模型把【工作区】带出去 ——
  // 只加字段。事项的工作区 = 事项容器记着的那个(13k 在事项第一次有了工作区时记下),没有就取组里
  // 最近动过的那条线程的目录。ruyiOwned 的判据单点在 06i 的 stewardRuyiOwnedPath(数据根里的、或如意
  // 为任务开的而用户没收编的),要配置里那张表 —— 调用方有现成的就传 options.config,省一次读盘。
  const wsConfig = (options.config && typeof options.config === 'object') ? options.config : await readConfig().catch(() => null);
  // 性能:2000 条线程只有寥寥几个不同的 cwd,而 stewardRuyiOwnedPath(逐字符归一 + 数据根前缀比较)与
  // dataRootAliases()(取数据根、比对别名)此前在【每条线程 + 每个事项组】各算一遍,一次 GET /api/missions
  // 约 4000 次,占去 37% CPU。本次装配内 wsConfig / paths.data / 别名都是定值,所以别名提到函数头只取一次,
  // 并按 cwd 记下 { name, ruyiOwned }(纯函数,同 cwd 同答案);每次仍返回【新对象】,调用方改它不会串行。
  const dataRootPath = paths.data;
  const dataRootAliasList = dataRootAliases();
  const workspaceMemo = new Map();   // 修剪后的 cwd -> { name, ruyiOwned }
  const workspaceOf = cwd => {
    const p = String(cwd || '').trim();
    if (!p) return null;
    let known = workspaceMemo.get(p);
    if (!known) {
      known = { name: path.basename(p.replace(/[\\/]+$/, '')) || p, ruyiOwned: stewardRuyiOwnedPath(p, wsConfig, dataRootPath, dataRootAliasList) };
      workspaceMemo.set(p, known);
      missionAggregateStats.workspaceComputed += 1;
    }
    return { path: p, name: known.name, ruyiOwned: known.ruyiOwned };
  };
  const overlayAt = nowIso();   // 一次装配只取一次「叠加时刻」:每行各取一次是 2000 次 Date + toISOString,而它们本就是同一个请求
  const index = await getPretenderProjectionIndex().catch(error => { if (String(error && error.code || '').startsWith('work_data')) throw error; return null; });
  const slices = new Map(((index && index.sessions) || []).map(row => [row.sessionId, row]));
  const metas = await listSessions().catch(() => []);          // 管家会话已在 listSessions 里滤掉
  const containers = await listMissionContainers().catch(() => []);
  const containerById = new Map(containers.map(row => [row.missionId, row]));
  const byMissionId = new Map();

  const ensure = (missionId, container) => {
    let group = byMissionId.get(missionId);
    if (!group) byMissionId.set(missionId, group = { missionId, container: null, threads: [], cost: emptyMissionCostBucket() });
    if (container && !group.container) group.container = container;
    return group;
  };
  for (const container of containers) {
    if (container.archivedAt && !includeArchived) continue;
    ensure(container.missionId, container);
  }
  for (const meta of metas) {
    const missionId = meta.missionId || meta.id;
    const container = containerById.get(missionId) || null;
    if (container && container.archivedAt && !includeArchived) continue;
    const group = ensure(missionId, container);
    const slice = slices.get(meta.id) || null;
    const card = slice ? overlayMissionCard(slice, overlayAt) : null;
    // 五态的三条取值路径,与 13g steward_thread_status 逐字一致(同一条线程在看板与管家里必须同色):
    //   ① 有投影卡片 -> fromCard(与 /api/missions 的卡片同源);
    //   ② 没卡片但是 mission 会话(投影还没赶上这条新会话)-> 按会话头现算,入参与 thread_status 相同
    //      —— 少喂 turnSeq 会把一条跑过回合的线程说成「交办中」,和 thread_status 的「已停工」打架;
    //   ③ 其余会话(= 用户自己在经典 2.0 里聊的普通会话)-> 【刻意不读会话头】以省 I/O,
    //      所以这一支手上一条事实都没有,明说 factsUnknown:true 让判据短路成「事实未知」。
    //      117r-D5 之前这里靠的是 kind === 'quick_ask' 那条守卫,出参完全一样(仍是 quick_ask、
    //      聚合仍落 stopped),变的只是【为什么】短路 —— 从「它是速查」变成「我不知道它在干什么」。
    //      对应地:①支里的速查线程(D1 之后它有卡片、有事实)不再被这条守卫劫走,走完整五态。
    let derived;
    // 124 还债①（40 号文 §8.5 ①）：这条线程有没有【自己的验收账本】（`session.mission`）。
    // 判据与 13g `thread_status` / 13h 总览同一条：卡片侧 `card.status === 'none'` ⇔ 头上没有
    // mission 容器（§6-ter 的 `ledgerless` 写的就是这两句的两种写法），不许拿
    // `milestonesTotal === 0` 之类的近似顶替。
    // 第三支（普通会话）刻意不读会话头以省 I/O —— 而 mission 账本只可能挂在 mission 会话上，
    // 所以那一支恒为 false：这不是猜，是定义。
    let threadLedger = false;
    if (card) { derived = stewardThreadStateFromCard(card); threadLedger = String(card.status || '') !== 'none'; }
    else if (meta.kind === 'mission') {
      const head = await readMissionSessionHead(meta.id);
      threadLedger = !!(head && head.mission);
      // 会话头这一支与 13k thread_status / 13o 总览 / 13r 事件流同一个适配器(06i stewardThreadStateFromHead)。
      derived = stewardThreadStateFromHead(head, {
        kind: 'mission',
        pending: await missionPendingCounts(meta.id, [], null).catch(() => null),
        activeTurn: activeChildren.has(meta.id),
        runCount: 0,
      });
    } else derived = deriveStewardThreadState({ kind: 'quick_ask', factsUnknown: true });
    // 124 还债①：组级两个事实在这一处累计（前端不再自己推）——
    //   · anyLedger：组里任一条线程带账本；
    //   · anyMission：这一组里有真正的【事项线程】（未归类事项没有容器，只能靠它认出来）。
    group.anyLedger = group.anyLedger === true || threadLedger;
    group.anyMission = group.anyMission === true || meta.kind === 'mission';
    group.threads.push({
      sessionId: meta.id,
      title: stewardSanitizeText(meta.title || ''),
      // 116-5b:同 buildMissionCard —— title 仍是原话,显示名另给一个键(steward_missions 的线程清单、
      // 抽屉页签、看板行都读它)。meta 是索引条目形态(brief/titleSource),sessionDisplayTitle 两形态都认。
      displayTitle: stewardSanitizeText(sessionDisplayTitle(meta)),
      ...(sessionBriefOf(meta) ? { brief: sessionBriefOf(meta) } : {}),
      kind: meta.kind || 'quick_ask',
      state: derived.state,
      stateLabel: derived.label,
      permissionMode: meta.permissionMode || null,
      lastAssistantText: stewardSanitizeText(meta.summary || '').slice(0, 120),
      updatedAt: String(meta.updatedAt || ''),
      cwd: String(meta.cwd || ''),   // W7:这条线程开在哪个目录(事项的 workspace 从这里派生)
      workspace: workspaceOf(meta.cwd),
      // 116h(§8.10「排队可解释」):等待原因由 06i 的 waitReasonFor 单点判定,与 steward_thread_status /
      // 总览行 / steward_missions 同一函数同一形状。pending 用上面五态判据已经算好的那一份(少喂一次
      // 就会出现 116g 那种「看板与 thread_status 各说各话」);仲裁器一侧同步只读,开关关时恒为 null。
      wait: waitReasonFor(
        { pending: (derived.sources && derived.sources.pendingTotal) || 0 },
        typeof StewardHooks.arbiterWait === 'function' ? StewardHooks.arbiterWait(meta.id) : null,
      ),
    });
    addMissionCostBucket(group.cost, slice && slice.usage);
  }

  const rows = [];
  const rowBySessionId = new Map();
  for (const group of byMissionId.values()) {
    const container = group.container;
    const acceptanceItems = container ? container.acceptance : [];
    // 117s-A D1(§11.13 ③):组内线程改成「状态秩优先、其次 updatedAt 降序」。秩由 06i 的
    // stewardThreadStateRank 单点给(needs_you > running > dispatching > done/stopped),
    // 状态本身仍是上面那三条取值路径算出来的那一个 —— 这里【不】重新判定任何状态。
    // 末位补 sessionId 是为了确定性:两条线程秩与 updatedAt 都相同时,行序不该随 listSessions
    // 的目录枚举顺序漂移(夹具与 ETag 都指望同样的输入给同样的行序)。
    group.threads.sort((a, b) => stewardThreadStateRank(a.state) - stewardThreadStateRank(b.state)
      || String(b.updatedAt).localeCompare(String(a.updatedAt))
      || String(a.sessionId).localeCompare(String(b.sessionId)));
    const row = {
      missionId: group.missionId,
      // 未归类事项没有事项文件,标题只能从它唯一那条线程的会话标题派生(§3.1「不改写历史」)。
      // 116-5b:派生用的是那条线程的【显示名】而不是原话 —— 这个字段本来就是一个派生出来的显示串
      // (真事项走 container.title),不是权威数据;线程的原话仍在 threads[].title 里原样躺着。
      title: container ? container.title : ((group.threads[0] && (group.threads[0].displayTitle || group.threads[0].title)) || group.missionId),
      goal: container ? container.goal : '',
      derived: !container,
      archivedAt: (container && container.archivedAt) || '',
      cwd: container ? container.cwd : '',
      // W7:事项的工作区(见本函数头注)。cwd 仍是容器那一格的原值,语义一个字不改。
      workspace: workspaceOf((container && container.cwd)
        || ((group.threads.slice().sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))[0] || {}).cwd)),
      aggregateState: aggregateMissionState(group.threads.map(thread => thread.state)),
      threadCount: group.threads.length,
      threads: group.threads,
      acceptance: {
        done: acceptanceItems.filter(item => item.done).length,
        total: acceptanceItems.length,
        items: acceptanceItems,
        // ── 124 还债①（40 号文 §8.5 ①）：让【看板】也答得出「未记录验收」───────────────
        // 修前这一块只有 done/total/items 三个数，都来自事项容器。容器里的 done 按定义只可能是
        // 用户勾的，所以那条 a/b 单一来源、不会说谎 —— 但它**答不出「这一件压根没人记过验收」**：
        // `total === 0` 既可能是「记过、是空的」，也可能是「从来没记过」，看板只能两者都当没话说。
        // 详情路由（/api/missions/:id）走的是 02 的 buildMissionAcceptanceProjection，那边有
        // `ledger`；列表这一侧没有，于是抽屉说得出「未记录验收」而看板说不出。这两个键就是把
        // 同一套事实补到列表行上 —— **判据仍然只有前端 thread-facts.acceptanceRecorded 一处**，
        // 这里只负责把它需要的事实如实投影出来。
        //   · ledger  —— 组里【任一条】线程带自己的验收账本（`session.mission`）。组级口径：
        //     事项是按组显示的，组里只要有一条记过，这一件就不算「没人记过」。
        //   · tracked —— 这一组是不是【一件活】：有事项容器，或组里有 mission 线程（未归类事项
        //     没有容器文件，只能靠后者认出来）。
        //     为什么要它：左栏自 121-K3 放宽索引口径后大半是用户手工开的普通会话，它们的聚合态
        //     恒落 stopped、也从来没有验收记录 —— 不带这个门，「收工却没记过」会把整栏刷成等重
        //     灰字（§2.3「只在有话可说时出现」，正是 P1 当初刻意不碰看板的那条理由）。
        //     普通聊天会话本来就没有验收这回事，对它说「未记录验收」是噪声，不是诚实。
        ledger: group.anyLedger === true,
        tracked: Boolean(container) || group.anyMission === true,
      },
      budget: container ? container.budget : {},
      cost: group.cost,
      createdAt: container ? container.createdAt : ((group.threads[group.threads.length - 1] && group.threads[group.threads.length - 1].updatedAt) || ''),
      updatedAt: container ? container.updatedAt : ((group.threads[0] && group.threads[0].updatedAt) || ''),
    };
    rows.push(row);
    for (const thread of group.threads) rowBySessionId.set(thread.sessionId, row);
  }
  // 117s-A D1(§11.13 ③):组同规则 —— 状态秩优先、其次 updatedAt 降序。组的秩取【它自己的聚合态】
  // 的秩,而聚合态只经 06i 的 aggregateMissionState(上面已经算过一次,直接读 row.aggregateState);
  // 「组的秩 = 组内最高秩」这句话由 aggregateMissionState 的规则本身保证,不在这里另算一遍最大值
  // (any needs_you -> needs_you;非全 done 时 any running -> running;再 any dispatching;否则
  //  done/stopped 同落末档 —— 逐档与 stewardThreadStateRank 的秩一一对应)。
  rows.sort((a, b) => stewardThreadStateRank(a.aggregateState) - stewardThreadStateRank(b.aggregateState)
    || String(b.updatedAt).localeCompare(String(a.updatedAt))
    || String(a.missionId).localeCompare(String(b.missionId)));
  // 事项文件不在 75c 物化索引的 sourceStamp 覆盖面内(它们不是会话文件),所以 ETag 必须自己带上
  // 它们的指纹 —— 否则 PATCH 完验收项、再带 If-None-Match 来读会拿到 304 + 陈旧的 acceptance。
  // 117h 第 0 步:行上新增的 missionTitle / goal / acceptanceItems 都由容器字段直出,所以指纹要把
  // 它们一并纳入 —— 光靠 updatedAt 依赖「每次改都会动 updatedAt」这条隐含约定,写进指纹才是自证的。
  // 117s-A D1:行序自此由【状态秩】决定,而状态可以在 updatedAt 与容器字段都不动的情况下变
  //   (最典型的一条:活回合结束 -> activeTurn 由真变假 -> running 落 done,会话头那一刻并没有再写一次)。
  // 指纹不带秩的话,带 If-None-Match 来的下一拍会拿到 304 + 一份【旧顺序】的行 —— 与上面那条
  // acceptance 的教训同一个模具,所以把秩写进指纹,而不是依赖「状态变了 updatedAt 一定也变」。
  const stamp = pretenderHash([
    containers.map(row => [row.missionId, row.updatedAt, row.archivedAt || '', row.title || '', row.goal || '']),
    rows.map(row => [
      row.missionId, stewardThreadStateRank(row.aggregateState),
      row.threads.map(thread => [thread.sessionId, stewardThreadStateRank(thread.state)]),
      // W7:工作区也进指纹 —— ruyiOwned 随配置里那张表变,而会话头与容器都没动。
      row.workspace ? [row.workspace.path, row.workspace.ruyiOwned] : null,
    ]),
  ]);
  return { rows, rowBySessionId, stamp };
}

// /api/missions 的行是【线程行】(每个 mission 会话一张卡,70 波起如此,前端静态锁按它冻结)。
// 116g 只在每行【追加】它所属事项的聚合事实,既有字段与顺序一个不动。
function overlayMissionAggregateFields(card, row) {
  if (!card) return card;
  // row 缺失 = 这张卡片的会话在 listSessions 的元数据里没有对应行(索引与投影之间的瞬时偏斜)。
  // 退化成「只有它自己一条线程的未归类事项」,聚合态仍然只经 aggregateMissionState —— 绝不在这里
  // 按 card.status 另编一套判据(那就是第二个状态机)。
  // 116h(§8.10「排队可解释」):看板每一行都要能说出「它在等什么」。这一行就是那条线程自己的行,
  // 所以取聚合行里【它自己】那条线程的 wait(与 steward_missions / steward_thread_status 同源同形);
  // row 缺失的退化分支里现算一次,仍然只经 06i 的 waitReasonFor(不另编第二套判据)。
  const threadWait = row ? ((row.threads || []).find(thread => thread.sessionId === card.sessionId) || {}).wait || null : null;
  if (!row) {
    const derived = stewardThreadStateFromCard(card);
    return Object.assign(card, {
      aggregateState: aggregateMissionState([derived.state]),
      threadCount: 1,
      // 124 还债①：退化支（没有聚合行）也得如实说 —— 没有容器就没有容器验收项，
      // 账本与「是不是一件活」仍然只读卡片上那两条既有事实，不另编。
      acceptance: { done: 0, total: 0, ledger: String(card.status || '') !== 'none', tracked: String(card.kind || '') === 'mission' },
      budget: {}, cost: emptyMissionCostBucket(), derived: true,
      // 117h 第 0 步:没有聚合行 = 没有容器,事项标题就是这条线程自己的标题,目标与验收项如实为空。
      missionTitle: String(card.displayTitle || card.title || ''), goal: '', acceptanceItems: [],
      missionWorkspace: null,   // W7:没有聚合行就没有事项级工作区;这条线程自己的目录仍在 card.cwd
      wait: waitReasonFor(
        { pending: (derived.sources && derived.sources.pendingTotal) || 0 },
        typeof StewardHooks.arbiterWait === 'function' ? StewardHooks.arbiterWait(card.sessionId) : null,
      ),
    });
  }
  return Object.assign(card, {
    aggregateState: row.aggregateState,
    threadCount: row.threadCount,
    // 124 还债①：ledger / tracked 跟着 done/total 一起上行 —— 看板按组取【领头那一行】的
    // acceptance（groupRows 里 `acceptance: row.acceptance`），而这两个是组级事实，同组每一行都一样。
    acceptance: { done: row.acceptance.done, total: row.acceptance.total, ledger: row.acceptance.ledger === true, tracked: row.acceptance.tracked === true },
    budget: row.budget,
    cost: row.cost,
    derived: row.derived,
    // ── 117h 第 0 步(27 号文 §5 117h 行 / 117d 拍板①):看板要按【事项】分组显示,而事项容器的
    // 标题 / 目标 / 验收项此前只有 steward_missions 工具面拿得到 —— 117d 抽屉只能按确定性顺序
    // 回落到线程标题。这里【只加三个字段】,不加新路由、不动既有字段与顺序:
    //   · missionTitle:有容器就是容器标题;没有容器(derived 行,`未归类事项`)就是本行自己的标题;
    //   · goal        :容器目标,无容器为空串(不猜、不拿线程摘要冒充);
    //   · acceptanceItems:容器验收项整表(既有 acceptance 只有 done/total 两个数,画不出条目)。
    // 116-5b:derived 行的事项标题 = 这条线程自己的【显示名】(见 buildMissionAggregateRows 同款注释)。
    missionTitle: row.derived ? String(card.displayTitle || card.title || '') : String(row.title || ''),
    goal: String(row.goal || ''),
    acceptanceItems: Array.isArray(row.acceptance.items) ? row.acceptance.items : [],
    wait: threadWait,
    // W7:这条线程所属事项的工作区({path,name,ruyiOwned} 或 null)。只加字段;给 W4 的管家界面读。
    missionWorkspace: row.workspace || null,
  });
}

async function handleMissionsApiRoutes(req, res, pathname) {
  // 75c:列表走可删物化索引。冷读验证/重建权威源，热读只叠加 live overlay；cursor 携带 revision，
  // 跨页期间事实变化返回 409 snapshot_changed，绝不静默漏项/重复。
  if (req.method === 'GET' && pathname === '/api/missions') {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const index = await getPretenderProjectionIndex();
    // 116g:只加字段 —— 行仍然是【线程行】(每个 mission 会话一张卡),既有字段与顺序逐字节不变,
    // 追加的是这条线程所属【事项】的聚合事实(aggregateState/threadCount/acceptance/cost/budget/derived)。
    const aggregate = await buildMissionAggregateRows();
    const overlayAt = nowIso();   // 与聚合装配同理:整张列表共用一个叠加时刻,不再逐行取一次
    const missions = index.sessions.filter(row => row.card && String(row.sessionId || '') !== STEWARD_SESSION_ID)   // 走查 U3:管家自己的会话不是任务,不进左栏
      .map(row => overlayMissionAggregateFields(overlayMissionCard(row, overlayAt), aggregate.rowBySessionId.get(row.sessionId)));
    // 117s-A D1(§11.13 ③):看板正文读的就是这一份行序(steward-board.js 的 groupRows() 按
    // missionId 首次出现的先后定组序、组内按行序)—— 设计页只点了 buildMissionAggregateRows 里的
    // 那两处排序,但那一份是给 steward_missions 工具面消费的;**看板真正吃的是这一行**,所以三处
    // 一起改,否则「在跑的排最前」在工具面成立、在用户眼前的看板上不成立。
    // 排序键四段,一段都不能省:
    //   ① 组的秩(aggregateState;overlayMissionAggregateFields 两个分支都已挂上它);
    //   ② 组的 updatedAt 降序 —— 取【同组各行 updatedAt 的最大值】,与修前「组序由它最新的那条线程
    //      决定」逐字同义(修前没有显式组序,组序就是第一条落在组里的行的位置);
    //   ③ 组内线程的秩(从叠加过 live 层的卡片现算,与看板自己 MissionState.fromCard(row) 同源);
    //   ④ 线程 updatedAt 降序,末位 sessionId 兜确定性。
    // 一二段在前保证【组仍然是连续的】—— 少了它,一条 needs_you 的线程会把它所在的组劈成两半。
    const groupRank = new Map();     // missionId -> 组秩(取组内最小秩,即最高优先级)
    const groupUpdated = new Map();  // missionId -> 组内最大 updatedAt
    const threadRank = new Map();    // sessionId -> 线程秩
    for (const row of missions) {
      const mid = String(row.missionId || row.sessionId || '');
      const rank = stewardThreadStateRank(stewardThreadStateFromCard(row).state);
      threadRank.set(String(row.sessionId || ''), rank);
      const own = stewardThreadStateRank(row.aggregateState);
      groupRank.set(mid, Math.min(groupRank.has(mid) ? groupRank.get(mid) : own, own));
      const at = String(row.updatedAt || '');
      if (!groupUpdated.has(mid) || at > groupUpdated.get(mid)) groupUpdated.set(mid, at);
    }
    const gid = row => String(row.missionId || row.sessionId || '');
    missions.sort((a, b) => (groupRank.get(gid(a)) - groupRank.get(gid(b)))
      || String(groupUpdated.get(gid(b))).localeCompare(String(groupUpdated.get(gid(a))))
      || String(gid(a)).localeCompare(String(gid(b)))
      || (threadRank.get(String(a.sessionId)) - threadRank.get(String(b.sessionId)))
      || String(b.updatedAt).localeCompare(String(a.updatedAt))
      || String(a.sessionId).localeCompare(String(b.sessionId)));
    // ?sessionIds=a,b,c:只要这几条的卡片(侧栏搜索命中了、但不在它已经取到的那一页里的会话 —— 左栏只取最新
    // 200 条,修前更早的会话搜得到也显示不出来)。只认合形的 id,最多 60 条;不分页、不参与 304。
    const wanted = String(new URL(req.url, 'http://x').searchParams.get('sessionIds') || '').split(',').map(id => safeSessionId(id.trim())).filter(Boolean).slice(0, 60);
    if (wanted.length) {
      const set = new Set(wanted);
      return send(res, json({ ok: true, missions: missions.filter(row => set.has(String(row.sessionId || ''))), projectionRevision: index.missionsRevision }));
    }
    const paged = paginatePretenderProjection(req, 'missions', index.missionsRevision, missions);
    if (paged.response) return send(res, paged.response);
    // 用量修订号挂在【最后】一段:前面三段(修订号 - 在场覆盖 - 行指纹)的段位有测试按位读(steward-thread-order ⑪)。
    const etag = pretenderEtag('missions', index.missionsRevision + '-' + pretenderLiveOverlayRevision() + '-' + aggregate.stamp + '-' + (index.missionsUsageRevision || ''), paged.page);
    if (pretenderNotModified(req, etag)) return send(res, { status: 304, headers: { etag }, body: '' });
    return send(res, json({
      ok: true,
      missions: paged.items,
      page: paged.page,
      nextCursor: paged.page.nextCursor,
      projectionRevision: index.missionsRevision,
      index: pretenderIndexMeta(index),
    }, 200, { etag }));
  }
  // ── 第 116 波 116g(27 号文 §3.1):事项容器的写面。五条路由,全部 token 门(01b 的
  // `POST /api/missions` 与 `PATCH /api/missions/` 两条新登记 + 既有 `POST /api/missions/` 前缀条)。
  // 幂等一律靠子操作本身幂等(attach/detach/去重/归档),不靠"是否做过"的标记位 —— 标记位会在
  // 崩溃窗口里说谎,幂等的子操作不会。
  if (req.method === 'POST' && pathname === '/api/missions') {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const body = await readJsonBody(req);
    const result = await createMissionContainer(body || {});
    return send(res, result.ok ? json(result, 201) : missionContainerFailure(result));
  }
  // 事项级字段(title/goal/acceptance/budget)的【唯一】写入口。会话头里的 head.mission 不受影响。
  if ((req.method === 'PATCH' || (req.method === 'POST' && req.headers['x-http-method'] === 'PATCH')) && pathname.match(/^\/api\/missions\/([^/]+)$/)) {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const missionId = safeSessionId(pathname.split('/')[3]);
    if (!missionId) return send(res, missionContainerFailure({ error: 'invalid_request', message: 'invalid missionId' }));
    const body = await readJsonBody(req);
    const result = await patchMissionContainer(missionId, body || {});
    return send(res, result.ok ? json(result) : missionContainerFailure(result));
  }
  // 线程加入 / 移出。attach 把会话头 missionId 改为目标事项(经 updateSessionMeta,享受 116-2a 的
  // 活回合竞态防护)并写反向索引;detach 恢复 missionId === sessionId(未归类)。
  if (req.method === 'POST' && pathname.match(/^\/api\/missions\/([^/]+)\/threads$/)) {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const missionId = safeSessionId(pathname.split('/')[3]);
    if (!missionId) return send(res, missionContainerFailure({ error: 'invalid_request', message: 'invalid missionId' }));
    const body = await readJsonBody(req);
    const action = String((body && body.action) || '');
    if (action !== 'attach' && action !== 'detach') {
      return send(res, missionContainerFailure({ error: 'invalid_request', message: "action must be 'attach' or 'detach'" }));
    }
    const result = action === 'attach'
      ? await missionAttachThread(missionId, body && body.sessionId)
      : await missionDetachThread(missionId, body && body.sessionId);
    return send(res, result.ok ? json(result) : missionContainerFailure(result));
  }
  // 合并:from 的全部线程搬到目标、验收项按文本去重并入、from 标 archivedAt。再合一次零变化。
  if (req.method === 'POST' && pathname.match(/^\/api\/missions\/([^/]+)\/merge$/)) {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const missionId = safeSessionId(pathname.split('/')[3]);
    if (!missionId) return send(res, missionContainerFailure({ error: 'invalid_request', message: 'invalid missionId' }));
    const body = await readJsonBody(req);
    const result = await missionMergeInto(missionId, body && body.from);
    return send(res, result.ok ? json(result) : missionContainerFailure(result));
  }
  // 拆分:把指定线程拆到一个新事项。幂等键 = 同一组 sessionIds 已完整落在同名未归档事项里。
  if (req.method === 'POST' && pathname.match(/^\/api\/missions\/([^/]+)\/split$/)) {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const missionId = safeSessionId(pathname.split('/')[3]);
    if (!missionId) return send(res, missionContainerFailure({ error: 'invalid_request', message: 'invalid missionId' }));
    const body = await readJsonBody(req);
    const result = await missionSplitThreads(missionId, body && body.sessionIds, body && body.title);
    return send(res, result.ok ? json(result) : missionContainerFailure(result));
  }
  // 第79波:确定性回来摘要数据面。只返回严格位于 (after,currentRevision] 的原始变更记录；
  // migration prefix、损坏行、内部/尾部缺号都以 degraded+gap 明示，客户端不得推进 lastSeen。
  if (req.method === 'GET' && /^\/api\/missions\/[^/]+\/changes$/.test(pathname)) {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const sessionId = safeSessionId(pathname.split('/')[3]);
    if (!sessionId) return send(res, apiSessionIdInvalid());
    const query = new URL(req.url, 'http://x').searchParams;
    const after = Number(query.get('after'));
    if (!Number.isSafeInteger(after) || after < 0) return send(res, json({ ok: false, error: 'after must be a non-negative integer' }, 400));
    const session = await loadSession(sessionId);
    if (!session) return send(res, apiSessionNotFound());
    // 117m-A3(用户第六轮走查④「交办台点开,显示报错」):线程 kind:'mission' 而 mission:null 是【合法状态】
    // —— 管家刚开的线程还没有任何变更账本。修前这里 404 'mission not found',而交办台详情是一个
    // Promise.all(详情 + 两次 changes),一挂就把整块面板换成错误卡(用户截图里那张)。把「还没有变更」
    // 说成「找不到事项」是判据错位:找不到的是账本,不是事项,而空账本本来就该回一份空清单。
    // 只放宽这一种情形(会话在、账本空);会话不存在仍旧 404。
    if (!session.mission) {
      return send(res, json({
        ok: true, missionId: sessionMissionId(session), sessionId,
        fromRevision: after, currentRevision: 0, baseRevision: 0,
        changes: [], degraded: false, gap: null,
        integrity: { corruptLines: 0, lastRevision: 0 },
      }));
    }
    const currentRevision = Math.max(0, Number(session.mission.changeSeq) || 0);
    const folded = await readMissionChangesWithMeta(sessionId, currentRevision);
    let gap = folded.gap;
    if (!gap && after < folded.baseRevision) gap = { expected: after + 1, actual: folded.baseRevision + 1, prefix: true };
    if (!gap && after > currentRevision) gap = { expected: currentRevision, actual: after, ahead: true };
    const degraded = folded.degraded || Boolean(gap);
    return send(res, json({
      ok: true,
      missionId: sessionMissionId(session),
      sessionId,
      fromRevision: after,
      currentRevision,
      baseRevision: folded.baseRevision,
      changes: folded.records.filter(record => Number(record.seq) > after && Number(record.seq) <= currentRevision),
      degraded,
      gap: gap || null,
      integrity: { corruptLines: folded.corruptLines, lastRevision: folded.lastRevision },
    }));
  }
  // 第84波:Mission 控制面。动作作用域由 missionControlCommand 单一核心冻结；本路由只做
  // missionId/sessionId 解析与 HTTP 适配，经典 /api/mission stop 也复用同一核心。
  if (req.method === 'POST' && /^\/api\/missions\/[^/]+\/control$/.test(pathname)) {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const sessionId = safeSessionId(pathname.split('/')[3]);
    if (!sessionId) return send(res, apiSessionIdInvalid());
    const body = await readJsonBody(req);
    const result = await missionControlCommand(sessionId, body && body.action, body && body.prompt);
    return send(res, json(result.body, result.status));
  }
  // 详情:单会话稳定任务快照(EC-E:mission + Agent Run + 产物 + 变更 + 检查点 + 用量 + 游标)。
  // 只认 /api/missions/<一段>(与 13d 单条会话路由同一个口径):修前是 startsWith + path.basename,
  // /api/missions/随便/什么/<id> 与 /api/missions/<id>/ 都被当成 <id>,以后加 GET 子路由会被这里先吞掉。
  const missionDetail = req.method === 'GET' ? pathname.match(/^\/api\/missions\/([^/]+)$/) : null;
  if (missionDetail) {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const sessionId = safeSessionId(safeDecodeURIComponent(missionDetail[1]) || '');
    if (!sessionId) return send(res, apiSessionIdInvalid());
    const index = await getPretenderProjectionIndex();
    const indexed = index.sessions.find(row => row.sessionId === sessionId) || null;
    // 124-P1:详情自此带着【事项容器】那一套验收项(「人工复核」那一档),容器是另一份文件,
    // 它变了不会动会话投影的 revision —— 指纹不带上它,勾完验收项的下一拍就是 304 + 陈旧验收。
    // 容器是小 JSON,304 这条路上多读它一次,换的是不说谎(指纹判据单点住在 02)。
    // 未归类线程(missionId === sessionId)天然没有事项文件 —— 事项 id 一律 `mission_<hex>`(02 的
    // safeMissionId 头注),与 `sess_` 分家,所以那一档连读都不用读(抽屉是轮询的,省的是每一拍一次
    // ENOENT)。归类过的才去读那份小 JSON。
    const containerId = (indexed && indexed.missionId && indexed.missionId !== sessionId) ? indexed.missionId : '';
    const container = containerId ? await readMissionContainer(containerId).catch(() => null) : null;
    const etag = indexed ? pretenderEtag('mission', indexed.revision + '-' + pretenderLiveOverlayRevision(sessionId) + '-' + missionContainerAcceptanceStamp(container)) : '';
    if (etag && pretenderNotModified(req, etag)) return send(res, { status: 304, headers: { etag }, body: '' });
    const session = await loadSession(sessionId);
    if (!session) return send(res, apiSessionNotFound());
const runs = await listAgentRuns(sessionId).catch(error => { if (String(error && error.code || '').startsWith('work_data')) throw error; return []; });

    // 验收投影(124-P1):里程碑计数与 items 形状一个字不动,另带「这条是谁判的」四态、机器检查的
    // 实情(没跑过 / 最近一次没通过 —— J08)、事项容器那一套(人工复核)与「有没有账本」。判据单点
    // 住在 02 的 buildMissionAcceptanceProjection,本路由只负责把两份数据喂进去。
    // indexed 缺失(会话还没进投影索引)时上面那次容器读不到,这里按会话头里的 missionId 补一次。
    const headMissionId = sessionMissionId(session);
    const acceptanceContainer = container
      || (headMissionId && headMissionId !== sessionId ? await readMissionContainer(headMissionId).catch(() => null) : null);
    const acceptance = buildMissionAcceptanceProjection(session.mission, acceptanceContainer);

    // 变更/产物聚合:跨回合 turnSummary 折叠(02 foldTurnSummaries 单一实现,与 buildMissionResult 共用) ——
    // filesChanged 按 path 后写胜(最新 op/revertible 为当前态),artifacts 按 path 先去重(首次产出记回合)。
    // revertible=false 即不可逆显式标注(journal skipped 或天生不在账内)。
    // 第72波顺手修:旧内联折叠 `commands += (ts.commands || []).length` 把数字当数组,commands>0 即 NaN
    // (JSON 序列化为 null)——统一走 fold 后该 bug 消失;irreversible 正向账随行,旧回合(无该字段)的
    // commands 诚实单列 legacyCommands,不混进新账假装有据。
    const fold = foldTurnSummaries(session);
    const filesChangedList = fold.filesChanged, artifactsList = fold.artifacts, commands = fold.commands;

    // 检查点引用(真实回滚能力的入口:POST /api/checkpoints/rollback {sessionId, turnSeq, entrySeq?})。
    const cpEntries = await journalReadIndex(sessionId).catch(error => { if (sessionHeadIsWorkDataError(error)) throw error; return []; });
    const cpTurnSeqs = [...new Set(cpEntries.map(e => e && e.turnSeq).filter(Number.isFinite))].sort((a, b) => a - b);
    const checkpoints = {
      entries: cpEntries.length,
      turnSeqs: cpTurnSeqs,
      totalBytes: cpEntries.reduce((s, e) => s + (Number(e && e.bytes) || 0), 0),
      rollbackAvailable: cpEntries.length > 0,
    };
    // 第84波台账时间轴:直接投影 checkpoint journal，不从摘要猜「可回退」。被跳过的大文件与不在
    // journal 中的变更诚实列入不可回退区；最多下发最近 200 条，长任务的详情响应保持有界。
    const checkpointKeys = new Set(cpEntries.map(entry => `${Number(entry && entry.turnSeq)}:${Number(entry && entry.entrySeq)}:${String(entry && entry.path || '')}`));
    // skipped:true 已在 checkpoint row 自身标成不可回退；这里只补「摘要里有、journal 里没有」的变更，
    // 避免同一大文件既算 skipped row 又算 nonRevertibleFile 而把不可退计数翻倍。
    const nonRevertibleFiles = filesChangedList.filter(file => file
      && !checkpointKeys.has(`${Number(file.turnSeq)}:${Number(file.entrySeq)}:${String(file.path || '')}`));
    const ledgerEntries = cpEntries.slice(-200).map(entry => ({
      turnSeq: Number(entry && entry.turnSeq) || 0,
      entrySeq: Number(entry && entry.entrySeq) || 0,
      path: String(entry && entry.path || ''),
      op: String(entry && entry.op || ''),
      tool: String(entry && entry.tool || ''),
      bytes: Math.max(0, Number(entry && entry.bytes) || 0),
      ts: String(entry && entry.ts || ''),
      revertible: !(entry && entry.skipped),
      reason: entry && entry.skipped ? 'content_too_large' : '',
    }));
    const reversibleEntries = ledgerEntries.filter(entry => entry.revertible).length;
    const recoveryBlockers = ledgerEntries.filter(entry => !entry.revertible).length + nonRevertibleFiles.length
      + fold.irreversible.total + fold.irreversible.legacyCommands;
    const controls = missionControlView(session, { checkpointEntries: cpEntries, runs });
    const ledger = {
      entries: ledgerEntries,
      truncated: cpEntries.length > ledgerEntries.length,
      totalEntries: cpEntries.length,
      nonRevertibleFiles: nonRevertibleFiles.slice(-80),
      irreversible: { items: fold.irreversible.items.slice(-80), legacyCommands: fold.irreversible.legacyCommands },
      rollbackTargetTurnSeq: controls.rollbackTargetTurnSeq,
      recoverability: reversibleEntries === 0 ? 'none' : (recoveryBlockers > 0 ? 'partial' : 'full'),
      reversibleEntries,
      nonRevertibleEntries: recoveryBlockers,
    };

    // 用量切片:append-only 月度账本按 sessionId 过滤(权威存储,session 对象上无聚合字段)。
    const usage = indexed && indexed.usage ? indexed.usage : emptyMissionUsage();

    // 游标:增量消费的位置令牌 —— 会话 turnSeq(单调不回绕)+ 各 run 事件流 eventSeq(严格单调,afterSeq 补播)。
    const cursor = {
      turnSeq: Number(session.turnSeq) || 0,
      runs: Object.fromEntries(runs.map(r => [r.id, Number(r && r.eventSeq) || 0])),
      projectionRevision: indexed ? indexed.revision : '',
      snapshotAt: nowIso(),
    };
    const pendingCounts = await missionPendingCounts(sessionId, runs, indexed && indexed.interventions);

    return send(res, json({
      ok: true,
      snapshot: {
        sessionId, missionId: sessionMissionId(session), kind: sessionKind(session), title: session.title || '', summary: session.summary || '',
        cwd: session.cwd || '', createdAt: session.createdAt || '', updatedAt: session.updatedAt || '',
        status: missionCardStatus(session.mission),
        activeTurn: activeChildren.has(sessionId), // 第56波:活回合标志(五态派生的「进行中」权威信号之一,与 run.live 同型内存叠加)
        queued: stewardThreadTurnQueued(sessionId), // hunt3:回合在仲裁器里排队(前端 fromSnapshot 读它,同 activeTurn 一档)
        mission: session.mission || null,
        acceptance,
        // 班组图只需最近 6 轮；更旧历史仍保留标量 digest，可在经典工作台查看完整节点。
        runs: runs.map((run, index) => missionRunDigest(run, true, index < 6)),
        changes: { filesChanged: filesChangedList, artifacts: artifactsList, commands },
        // 第72波:不可逆操作正向账(活任务也随快照下发;终态任务以 mission.result 盖章版为准)
        irreversible: { total: fold.irreversible.total, byKind: fold.irreversible.byKind, items: fold.irreversible.items.slice(-30), legacyCommands: fold.irreversible.legacyCommands },
        // 第72波:任务结果快照(终态盖章;active/paused 为 null,看 acceptance/changes/irreversible 实时投影)
        result: (session.mission && session.mission.result) || null,
        // 历史轮次验收报告(next_turn/retry/rollback/再武装前归档的旧 result,有界 last 10)
        resultHistory: Array.isArray(session.mission && session.mission.resultHistory) ? session.mission.resultHistory : [],
        checkpoints,
        controls,
        ledger,
        usage,
        pending: pendingCounts,
        cursor,
        projectionRevision: indexed ? indexed.revision : '',
        freshness: {
          persistentRevision: indexed ? indexed.revision : '',
          indexedAt: indexed ? indexed.indexedAt : '',
          liveOverlay: activeChildren.has(sessionId) || runs.some(r => activeAgentRuns.has(r.id)),
          overlayAt: nowIso(),
        },
      },
      index: pretenderIndexMeta(index),
    }, 200, etag ? { etag } : {}));
  }
  return false;
}

// ============================================================================
// 第75b波(Pretender P1):Intervention 单一 command core。
// 新契约与经典四端点都只做参数/响应适配;权威 CAS、可送达检查、实际动作、审计与幂等响应持久化均在这里。
// ============================================================================
function canonicalDecisionValue(value, depth = 0) {
  if (depth > 24 || value === null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(v => canonicalDecisionValue(v, depth + 1));
  const out = {};
  for (const key of Object.keys(value).sort()) out[key] = canonicalDecisionValue(value[key], depth + 1);
  return out;
}

function interventionDecisionFingerprint(missionId, interventionId, payload) {
  return crypto.createHash('sha256')
    .update(JSON.stringify(canonicalDecisionValue({ missionId, interventionId, payload })), 'utf8')
    .digest('hex');
}

function interventionCommandFailure(reason, status, params = {}, message = '') {
  return {
    status,
    body: {
      ok: false,
      reason,
      error: {
        code: `intervention.${reason}`,
        params: params && typeof params === 'object' && !Array.isArray(params) ? params : {},
        ...(message ? { message } : {}),
      },
    },
  };
}

function normalizeContractQuestionDecision(payload, questions) {
  const rows = payload && payload.answer && Array.isArray(payload.answer.answers)
    ? payload.answer.answers
    : null;
  const known = Array.isArray(questions) ? questions : [];
  if (!rows || rows.length !== known.length || rows.length < 1 || rows.length > 3) {
    return { ok: false, message: 'answer.answers must contain exactly one answer for each question' };
  }
  const byId = new Map(known.map(q => [String(q && q.id || ''), q]));
  const seen = new Set();
  for (const row of rows) {
    if (!row || typeof row !== 'object') return { ok: false, message: 'each answer must be an object' };
    if (Object.keys(row).some(key => !['questionId', 'selectedOptionIds', 'otherText'].includes(key))) {
      return { ok: false, message: 'answer contains fields outside the typed question contract' };
    }
    const questionId = String(row.questionId || '');
    const question = byId.get(questionId);
    if (!question || seen.has(questionId)) return { ok: false, message: 'questionId is unknown or duplicated' };
    seen.add(questionId);
    if (!Array.isArray(row.selectedOptionIds)) return { ok: false, message: 'selectedOptionIds must be an array' };
    if (row.selectedOptionIds.some(id => typeof id !== 'string')) return { ok: false, message: 'selectedOptionIds must contain strings' };
    if (row.otherText !== undefined && typeof row.otherText !== 'string') return { ok: false, message: 'otherText must be a string' };
    const selected = row.selectedOptionIds.map(x => String(x || '')).filter(Boolean);
    if (selected.length !== new Set(selected).size || selected.length > 12) return { ok: false, message: 'selectedOptionIds contains duplicates or too many values' };
    const optionIds = new Set((Array.isArray(question.options) ? question.options : []).map(o => String(o && o.id || '')));
    if (selected.some(id => !optionIds.has(id))) return { ok: false, message: 'selectedOptionIds contains an option outside this question' };
    const otherText = String(row.otherText || '').trim();
    const mode = String(question.answerMode || (question.multiSelect ? 'multiple' : 'single'));
    if (mode === 'single' && selected.length > 1) return { ok: false, message: 'single-choice question accepts at most one option' };
    if (mode === 'text' && selected.length) return { ok: false, message: 'text question does not accept selectedOptionIds' };
    if (otherText && mode !== 'text' && question.allowOther !== true) return { ok: false, message: 'otherText is not allowed for this question' };
    if (!selected.length && !otherText) return { ok: false, message: 'each question requires an answer' };
  }
  return { ok: true, answer: normalizeQuestionAnswer({ answers: rows }, known) };
}

function mapInterventionTransitionFailure(result) {
  const reason = String(result && result.reason || 'decision_failed');
  if (reason === 'not_found') return interventionCommandFailure(reason, 404, {}, 'mission or intervention not found');
  if (reason === 'expired') return interventionCommandFailure(reason, 410, { status: result.status || '' }, 'intervention has expired');
  if (reason === 'version_conflict') {
    return interventionCommandFailure(reason, 409, {
      expectedVersion: result.expectedVersion,
      actualVersion: result.actualVersion,
    }, 'intervention version does not match');
  }
  if (reason === 'idempotency_conflict') {
    return interventionCommandFailure(reason, 409, {}, 'idempotencyKey was already used for a different request');
  }
  if (reason === 'already_terminal') {
    return interventionCommandFailure(reason, 409, {
      status: result.status || '',
      interventionVersion: Number(result.interventionVersion) || 0,
    }, 'intervention is already terminal');
  }
  if (reason === 'not_pending') {
    return interventionCommandFailure(reason, 409, { status: result.status || '' }, 'intervention is already being applied');
  }
  if (reason === 'persist_failed') return interventionCommandFailure(reason, 503, {}, 'could not record the decision on disk; nothing was applied, try again');
  return interventionCommandFailure(reason, 409, {
    ...(result && result.runId ? { runId: result.runId } : {}),
  }, String(result && result.message || 'intervention cannot be delivered'));
}

async function decideIntervention(command = {}) {
  const rawMissionId = String(command.missionId || '');
  const missionId = safeSessionId(rawMissionId);
  const interventionId = String(command.interventionId || '');
  const source = String(command.source || 'contract').slice(0, 64);
  const contractRequest = command.contractRequest !== false;
  const payload = command.payload && typeof command.payload === 'object' && !Array.isArray(command.payload)
    ? command.payload
    : {};
  if (!missionId || missionId !== rawMissionId || !/^[A-Za-z0-9_-]{1,160}$/.test(interventionId)) {
    return interventionCommandFailure('invalid_request', 400, {}, 'invalid missionId or interventionId');
  }
  // 117j 收尾：这一发读【必须】走带瞬时重试的那一个。它是用户动作的判定入口 —— 读空一次就等于
  // 把「允许／回答」当场判成 404「会话不存在」，而真相只是回合正好在写头（见 02 的头注）。
  const head = await readSessionHeadResilient(missionId);
  // 117e 第 0 步(116g 引入的真 bug):这道门在 116g 之前是恒等式 —— 会话没挂进显式事项容器时
  // sessionMissionId(head) 就回落成 head.id,而 head 正是按 `sessionPath(missionId)` 读出来的。
  // 116g 的 missionAttachThread 把 session.missionId 改写成【容器 id】之后,同一条会话再按自己的
  // id 来答待决就恒判 not_found —— /api/chat/answer、/api/permission/decision、/api/plan/decision
  // 三条兼容适配器与 steward_decide 传的都是 sessionId,于是「凡是进了多线程事项的线程,问题/权限/
  // 计划都答不进去」(经典壳同样受影响)。
  // 修法:把「missionId 等于该会话自身 id」显式认作合法别名(容器 id 仍照旧受理,只是那个 id 上
  // 没有会话文件,读不出 head 就仍然 404)。**不放宽**「跨会话答别人的待决」:待决本体在下面按
  // `readInterventions(missionId)` 从这条会话自己的旁路账里取,并再核一次 `current.sessionId ===
  // missionId`;拿会话 A 的 id 去答会话 B 的待决,那两道判定照旧拦下。
  const headSelfId = String((head && head.id) || '');
  if (!head || (sessionMissionId(head) !== missionId && headSelfId !== missionId)) {
    return interventionCommandFailure('not_found', 404, {}, 'mission or intervention not found');
  }

  if (contractRequest) {
    if (!Number.isInteger(command.expectedVersion) || command.expectedVersion < 0) {
      return interventionCommandFailure('invalid_request', 400, { field: 'expectedVersion' }, 'expectedVersion must be a non-negative integer');
    }
    const key = String(command.idempotencyKey || '');
    if (!key || key.length > 128) {
      return interventionCommandFailure('invalid_request', 400, { field: 'idempotencyKey' }, 'idempotencyKey must contain 1-128 characters');
    }
  }

  const current = (await readInterventions(missionId).catch(() => []))
    .find(iv => iv && String(iv.id) === interventionId);
  if (!current || String(current.sessionId || missionId) !== missionId) {
    return interventionCommandFailure('not_found', 404, {}, 'mission or intervention not found');
  }

  const type = String(current.type || '');
  const action = String(payload.action || '');
  if (contractRequest) {
    const commonFields = new Set(['expectedVersion', 'idempotencyKey', 'action']);
    const typeFields = type === 'permission' ? ['updatedInput', 'scope']
      : type === 'question' ? ['answer']
        : type === 'plan' ? ['feedback']
          : [];
    const allowed = new Set([...commonFields, ...typeFields]);
    const unknown = Object.keys(payload).filter(key => !allowed.has(key));
    if (unknown.length) return interventionCommandFailure('payload_invalid', 400, { fields: unknown }, 'request contains fields outside the type/action contract');
  }
  let toStatus = '';
  let normalizedAnswer = null;
  if (type === 'permission') {
    if (action !== 'allow' && action !== 'deny') return interventionCommandFailure('action_invalid', 400, { type }, 'permission action must be allow or deny');
    if (action === 'allow' && payload.updatedInput !== undefined && (!payload.updatedInput || typeof payload.updatedInput !== 'object' || Array.isArray(payload.updatedInput))) {
      return interventionCommandFailure('payload_invalid', 400, { field: 'updatedInput' }, 'updatedInput must be an object');
    }
    if (payload.scope !== undefined && payload.scope !== 'session') {
      return interventionCommandFailure('payload_invalid', 400, { field: 'scope' }, 'scope must be session when provided');
    }
    toStatus = action === 'allow' ? 'allowed' : 'denied';
  } else if (type === 'question') {
    if (action !== 'answer') return interventionCommandFailure('action_invalid', 400, { type }, 'question action must be answer');
    if (contractRequest) {
      const normalized = normalizeContractQuestionDecision(payload, current.questions);
      if (!normalized.ok) return interventionCommandFailure('payload_invalid', 400, { type }, normalized.message);
      normalizedAnswer = normalized.answer;
    } else {
      normalizedAnswer = payload.normalizedAnswer;
      if (!normalizedAnswer || typeof normalizedAnswer !== 'object') return interventionCommandFailure('payload_invalid', 400, { type }, 'question answer is required');
    }
    toStatus = normalizedAnswer.ok === false ? 'cancelled' : 'answered';
  } else if (type === 'plan') {
    if (action !== 'approve' && action !== 'reject') return interventionCommandFailure('action_invalid', 400, { type }, 'plan action must be approve or reject');
    if (contractRequest && payload.feedback !== undefined && typeof payload.feedback !== 'string') {
      return interventionCommandFailure('payload_invalid', 400, { field: 'feedback' }, 'feedback must be a string');
    }
    toStatus = action === 'approve' ? 'approved' : 'rejected';
  } else if (type === 'pool') {
    if (action !== 'approve' && action !== 'reject') return interventionCommandFailure('action_invalid', 400, { type }, 'pool action must be approve or reject');
    toStatus = action === 'approve' ? 'approved' : 'rejected';
  } else if (type === 'replan') {
    if (action !== 'approve' && action !== 'reject') return interventionCommandFailure('action_invalid', 400, { type }, 'replan action must be approve or reject');
    toStatus = action === 'approve' ? 'approved' : 'rejected';
  } else {
    return interventionCommandFailure('type_unsupported', 409, { type }, 'intervention type is not supported by this release');
  }

  const idempotencyKey = String(command.idempotencyKey || makeId('legacy')).slice(0, 128);
  const decisionPayload = type === 'question'
    ? { action, answer: normalizedAnswer }
    : type === 'permission'
      ? { action, ...(action === 'allow' && payload.updatedInput !== undefined ? { updatedInput: payload.updatedInput } : {}), ...(action === 'allow' && payload.scope === 'session' ? { scope: 'session' } : {}) }
      : type === 'plan'
        ? { action, ...(payload.feedback !== undefined ? { feedback: String(payload.feedback) } : {}) }
        : { action };
  const decisionFingerprint = interventionDecisionFingerprint(missionId, interventionId, decisionPayload);
  let runtimeEntry = null;
  let poolContext = null;
  let replanContext = null;

  const preflight = async authoritative => {
    if (!authoritative || String(authoritative.type || '') !== type) return { ok: false, reason: 'not_found' };
    if (type === 'permission') {
      runtimeEntry = pendingPermissions.get(interventionId);
      if (!runtimeEntry || runtimeEntry.sessionId !== missionId) return { ok: false, reason: 'delivery_unavailable', message: 'permission consumer is not live' };
      return { ok: true };
    }
    if (type === 'question') {
      runtimeEntry = pendingQuestions.get(interventionId);
      if (!runtimeEntry || runtimeEntry.sessionId !== missionId) return { ok: false, reason: 'delivery_unavailable', message: 'question consumer is not live' };
      return { ok: true };
    }
    if (type === 'plan') {
      runtimeEntry = pendingPlans.get(interventionId);
      if (!runtimeEntry || runtimeEntry.sessionId !== missionId) return { ok: false, reason: 'delivery_unavailable', message: 'plan consumer is not live' };
      return { ok: true };
    }
    if (type === 'replan') {
      const runId = String(authoritative.runId || '');
      if (command.requestRunId && String(command.requestRunId) !== runId) return { ok: false, reason: 'not_found' };
      // R5: patch 审批不要求 run live —— 节点终态后 run 通常已收尾离开 activeAgentRuns。
      // 优先用 live 内存态(最新),否则读 persisted run JSON(已收尾仍可审批)。
      const live = activeAgentRuns.get(runId);
      let runObj = null;
      if (live && live.run && !live.closing) {
        if (live.run.sessionId !== missionId) return { ok: false, reason: 'not_found' };
        runObj = live.run;
      } else {
        try { runObj = await readAgentRunSnapshot(missionId, runId); }
        catch (error) { if (String(error && error.code || '').startsWith('work_data')) throw error; }
        if (!runObj || runObj.sessionId !== missionId) return { ok: false, reason: 'run_not_found', runId, message: 'run is not found' };
      }
      const patch = (Array.isArray(runObj.replanPatches) ? runObj.replanPatches : []).find(p => p && String(p.id) === interventionId);
      if (!patch || patch.status !== 'pending') return { ok: false, reason: 'replan_patch_unavailable', runId, message: 'replan patch is no longer pending' };
      replanContext = { runId, runObj, patch };
      return { ok: true };
    }

    const runId = String(authoritative.runId || '');
    if (command.requestRunId && String(command.requestRunId) !== runId) return { ok: false, reason: 'not_found' };
    const live = activeAgentRuns.get(runId);
    if (!live || !live.run || live.closing) {
      let persisted = null;
      try { persisted = await readAgentRunSnapshot(missionId, runId); }
      catch (error) { if (String(error && error.code || '').startsWith('work_data')) throw error; }
      const reason = persisted && persisted.status === 'paused' ? 'run_paused' : 'run_not_live';
      return { ok: false, reason, runId, message: reason === 'run_paused' ? 'run is paused; resume it before deciding' : 'run is not live' };
    }
    if (live.run.sessionId !== missionId) return { ok: false, reason: 'not_found' };
    if (live.stopRequested || (live.ctrl && live.ctrl.signal && live.ctrl.signal.aborted)) {
      return { ok: false, reason: 'run_stopping', runId, message: 'run is stopping' };
    }
    const item = (Array.isArray(live.run.taskPool) ? live.run.taskPool : []).find(p => p && String(p.id) === interventionId);
    if (!item || item.status !== 'proposed') return { ok: false, reason: 'pool_item_unavailable', runId, message: 'pool item is no longer proposed' };
    let config = null, cwd = '', roleLibrary = new Map();
    if (action === 'approve') {
      try {
        config = await readConfig();
        const session = await loadSession(missionId);
        cwd = normalizeCwd(session && session.cwd, config.defaultWorkspace);
        roleLibrary = new Map((await getAgentRoleLibrary(cwd, config)).map(role => [role.id, role]));
      } catch { /* preserve the existing empty-role-library fallback */ }
      const dryRun = { ...live.run, nodes: Array.isArray(live.run.nodes) ? [...live.run.nodes] : [] };
      const proxyModelsCache = config?.agentAutoModelTiering ? await ProxyModelHooks.read() : { models: [] };
      const dry = materializePoolItem(dryRun, { ...item }, { roleLibrary, cwd, config, proxyModelsCache, dryRun: true });
      if (!dry.ok) return { ok: false, reason: dry.reason || 'pool_materialize_rejected', runId, message: dry.error || 'pool item cannot be materialized' };
    }
    poolContext = { runId, live, item, config, cwd, roleLibrary };
    return { ok: true };
  };

  const execute = () => {
    if (type === 'permission') {
      runtimeEntry.commandApplying = true;
      clearTimeout(runtimeEntry.timer);
      const decision = action === 'allow'
        ? { behavior: 'allow', updatedInput: payload.updatedInput, ...(payload.scope === 'session' ? { scope: 'session' } : {}) }
        : { behavior: 'deny', message: String(payload.message || 'denied by user') };
      runtimeEntry.resolve(decision, { skipInterventionSettle: true });
      return { ok: true, delivered: true };
    }
    if (type === 'question') {
      runtimeEntry.commandApplying = true;
      clearTimeout(runtimeEntry.timer);
      const delivered = runtimeEntry.deliver(normalizedAnswer, { skipInterventionSettle: true, preserveRegistry: true });
      return { ok: delivered !== false, delivered: delivered !== false, reason: delivered === false ? 'delivery_failed' : '' };
    }
    if (type === 'plan') {
      runtimeEntry.commandApplying = true;
      clearTimeout(runtimeEntry.timer);
      runtimeEntry.resolve({
        decision: action,
        note: payload.feedback != null ? String(payload.feedback).slice(0, 2000) : '',
      }, { skipInterventionSettle: true });
      return { ok: true, delivered: true };
    }
    if (type === 'replan') {
      return (async () => {
        const { runObj, patch } = replanContext;
        if (patch.status !== 'pending') return { ok: false, reason: 'run_state_changed' };
        if (action === 'reject') {
          patch.status = 'rejected'; patch.decidedAt = nowIso();
          bumpRunIntervention(runObj, 'replan_reject');
          appendAgentRunEvent(runObj, { type: 'run_replan', data: { action: 'rejected', patchId: interventionId, by: String(command.decidedBy || 'user') } });
          await saveAgentRun(runObj);
          return { ok: true, patchId: interventionId };
        }
        if (!Array.isArray(patch.changes) || patch.changes.length === 0) return { ok: false, reason: 'replan_changes_pending', message: '重规划提案尚未补充 changes，暂不能应用；请先由 review 角色填充变更项，或拒绝该提案' };
        const ap = applyReplanPatch(runObj, interventionId);
        if (!ap.ok) return { ok: false, reason: 'replan_apply_failed', message: ap.error || '' };
        patch.decidedAt = nowIso();
        bumpRunIntervention(runObj, 'replan_approve');
        appendAgentRunEvent(runObj, { type: 'run_replan', data: { action: 'applied', patchId: interventionId, by: String(command.decidedBy || 'user'), applied: ap.applied } });
        await saveAgentRun(runObj);
        return { ok: true, patchId: interventionId, applied: ap.applied };
      })();
    }
    return (async () => {
      const { runId, live, item, config, cwd, roleLibrary } = poolContext;
      const proxyModelsCache = action === 'approve' && config?.agentAutoModelTiering ? await ProxyModelHooks.read() : { models: [] };
      if (activeAgentRuns.get(runId) !== live || live.closing || live.stopRequested || (live.ctrl && live.ctrl.signal && live.ctrl.signal.aborted) || item.status !== 'proposed') {
        return { ok: false, reason: 'run_state_changed' };
      }
      if (action === 'reject') {
        item.status = 'rejected'; item.decidedBy = String(command.decidedBy || 'user'); item.decidedAt = nowIso();
        bumpRunIntervention(live.run, 'pool_reject');
        appendAgentRunEvent(live.run, { type: 'run_pool', data: { action: 'rejected', poolId: interventionId, by: String(command.decidedBy || 'user') } });
        await saveAgentRun(live.run);
        return { ok: true, poolId: interventionId };
      }
      const mat = materializePoolItem(live.run, item, { roleLibrary, cwd, config, proxyModelsCache });
      if (!mat.ok) return { ok: false, reason: mat.reason || 'pool_materialize_failed', message: mat.error || '' };
      item.status = 'materialized'; item.decidedBy = String(command.decidedBy || 'user'); item.decidedAt = nowIso(); item.resultNodeId = mat.node.id;
      bumpRunIntervention(live.run, 'pool_approve');
      appendAgentRunEvent(live.run, { type: 'run_pool', data: { action: 'materialized', poolId: interventionId, by: String(command.decidedBy || 'user'), nodeId: mat.node.id } });
      try { live.poolGraceArmed = true; } catch {}
      if (live.inPoolGrace && Array.isArray(live.resumeWaiters)) {
        const waiters = live.resumeWaiters.splice(0);
        for (const wake of waiters) wake();
      }
      await saveAgentRun(live.run);
      return { ok: true, poolId: interventionId, nodeId: mat.node.id };
    })();
  };

  let transition;
  try {
    transition = await transitionInterventionState(
      missionId,
      interventionId,
      contractRequest ? command.expectedVersion : undefined,
      toStatus,
      {
        source,
        decidedBy: String(command.decidedBy || 'user'),
        idempotencyKey,
        decisionFingerprint,
        preflight,
        action: execute,
        resolveStatus: result => result && result.ok === false ? 'indeterminate' : toStatus,
        extra: result => ({
          action,
          ...(type === 'question' ? { answer: normalizedAnswer } : {}),
          ...(type === 'plan' && payload.feedback != null ? { feedback: String(payload.feedback).slice(0, 2000) } : {}),
          ...(result && result.nodeId ? { nodeId: result.nodeId } : {}),
        }),
        buildResponse: (result, meta) => result && result.ok === false
          ? interventionCommandFailure(result.reason || 'delivery_failed', 409, { type }, result.message || 'decision could not be delivered').body
          : {
              ok: true,
              missionId,
              interventionId,
              type,
              action,
              status: meta.status,
              interventionVersion: meta.interventionVersion,
              ...(result && result.delivered !== undefined ? { delivered: result.delivered } : {}),
              ...(result && result.nodeId ? { nodeId: result.nodeId } : {}),
            },
        audit: command.audit === false ? undefined : (_result, terminal) => {
          const auditSource = source === 'legacy_question' ? 'question_answer'
            : source === 'legacy_permission' ? 'permission_decision'
              : source === 'legacy_plan' ? 'plan_decision'
                : source === 'legacy_pool' ? `pool_${action}`
                  // 116c(27 号文 §11.3):管家代答的决定在审计流里必须一眼可辨,不能混进通用标签 ——
                  // 「谁按的这个批准」是事后解释与撤销的第一现场。
                  : source === 'steward' ? 'steward_decision'
                    : 'intervention_decision';
          logEvent({ kind: 'intervention', source: auditSource, sessionId: missionId, interventionId, type, action, interventionVersion: terminal.interventionVersion });
        },
        afterTerminal: () => {
          if (!runtimeEntry) return;
          runtimeEntry.commandApplying = false;
          if (type === 'permission' && pendingPermissions.get(interventionId) === runtimeEntry) pendingPermissions.delete(interventionId);
          else if (type === 'question' && pendingQuestions.get(interventionId) === runtimeEntry) pendingQuestions.delete(interventionId);
          else if (type === 'plan' && pendingPlans.get(interventionId) === runtimeEntry) pendingPlans.delete(interventionId);
        },
      },
    );
  } catch (error) {
    if (String(error && error.code || '').startsWith('work_data')) throw error;
    const message = String(error && error.message || error);
    return interventionCommandFailure('execution_failed', 500, {}, message);
  }
  if (!transition || !transition.ok) return mapInterventionTransitionFailure(transition);
  const response = transition.response && typeof transition.response === 'object'
    ? transition.response
    : {
        ok: true,
        missionId,
        interventionId,
        type,
        action,
        status: transition.status,
        interventionVersion: transition.interventionVersion,
      };
  return { status: response.ok === false ? 409 : 200, body: response };
}

// 性能批 P3:GET /api/interventions 的待决引用表,按索引对象缓存(索引任何刷新都换新对象,缓存随之作废)。
// 次序与修前逐条相同:按 requestedAt 的 localeCompare 稳定排序(每个索引版本只排一次)。
const pendingInterventionRefsMemo = new WeakMap();
function pendingInterventionRefs(index, onlySession) {
  let byFilter = pendingInterventionRefsMemo.get(index);
  if (!byFilter) pendingInterventionRefsMemo.set(index, byFilter = new Map());
  const hit = byFilter.get(onlySession);
  if (hit) return hit;
  const refs = [];
  const counts = { permission: 0, question: 0, plan: 0, pool: 0, replan: 0, total: 0 };
  for (const slice of index.sessions) {
    if (onlySession && slice.sessionId !== onlySession) continue;
    for (const iv of slice.interventions || []) {
      if (!iv || iv.status !== 'pending') continue;
      refs.push({ slice, iv, requestedAt: String(iv.requestedAt || '') });
      counts.total++;
      if (iv.type === 'permission') counts.permission++;
      else if (iv.type === 'question') counts.question++;
      else if (iv.type === 'plan') counts.plan++;
      else if (iv.type === 'pool') counts.pool++;
      else if (iv.type === 'replan') counts.replan++;
    }
  }
  refs.sort((a, b) => a.requestedAt.localeCompare(b.requestedAt));
  const entry = { refs, counts };
  byFilter.set(onlySession, entry);
  return entry;
}
// 一条待决的对外形状(字段与次序与修前逐字相同);实时字段每次现算。
function pendingInterventionItem(slice, iv) {
  const sessionId = slice.sessionId;
  return {
    id: iv.id, type: iv.type || '', sessionId, missionId: slice.missionId || sessionId,
    requestedAt: iv.requestedAt || '', interventionVersion: Math.max(0, Number(iv.interventionVersion) || 0),
    toolName: iv.toolName || '', tier: iv.tier || '', revertible: iv.revertible === true,
    runId: iv.runId || '', proposedBy: iv.proposedBy || '', task: iv.task || '',
    input: iv.type === 'permission' && iv.input && typeof iv.input === 'object' && !Array.isArray(iv.input) ? iv.input : undefined,
    questionSummary: iv.type === 'question' ? String(iv.questionSummary || '') : '',
    questions: iv.type === 'question' && Array.isArray(iv.questions) ? iv.questions : [],
    context: iv.type === 'question' ? String(iv.context || '').slice(0, 6000) : '',
    planSummary: iv.type === 'plan' ? String(iv.planSummary || '') : '',
    replanSummary: iv.type === 'replan' ? String(iv.summary || '') : '',
    replanTriggerType: iv.type === 'replan' ? String(iv.triggerType || '') : '',
    replanNodeId: iv.type === 'replan' ? String(iv.nodeId || '') : '',
    deliverable: iv.type === 'permission' ? pendingPermissions.has(String(iv.id))
      : iv.type === 'question' ? pendingQuestions.has(String(iv.id))
        : iv.type === 'plan' ? pendingPlans.has(String(iv.id))
          : iv.type === 'pool' ? activeAgentRuns.has(String(iv.runId || ''))
            : activeChildren.has(sessionId),
    live: activeChildren.has(sessionId), // 决策可送达性提示:活回合在,决策才能立刻被消费
    // 135(工作台「等你处理」队列的倒计时):内存登记簿里的截止时刻(ms)。权限的超时即自动拒绝、
    // 存档暂停会把它延长,提问靠心跳续期 —— 都只有这张登记簿知道真值,前端不自己猜。取不到为 0。
    deadlineAt: Math.max(0, Number((iv.type === 'permission' ? pendingPermissions.get(String(iv.id))
      : iv.type === 'question' ? pendingQuestions.get(String(iv.id)) : null)?.deadlineAt) || 0),
  };
}

async function handleInterventionApiRoutes(req, res, pathname) {
  if (req.method === 'POST' && pathname === '/api/_test/pretender-maintenance') {
    if (process.env.RUYI_TEST_HOOKS !== '1') return send(res, json({ ok: false, error: 'not found' }, 404));
    const body = await readJsonBody(req);
    if (body.action === 'compact') {
      const sessionId = safeSessionId(body.sessionId);
      if (!sessionId) return send(res, apiSessionIdInvalid());
      return send(res, json(await compactInterventionJournal(sessionId, { force: true })));
    }
    if (body.action === 'rebuild') {
      pretenderIndexRuntime.fullDirty = true;
      return send(res, json({ ok: true, index: pretenderIndexMeta(await getPretenderProjectionIndex()) }));
    }
    return send(res, json({ ok: false, error: 'invalid maintenance action' }, 400));
  }
  const contractMatch = pathname.match(/^\/api\/missions\/([^/]+)\/interventions\/([^/]+)\/decision$/);
  if (req.method === 'POST' && contractMatch) {
    let missionId = '', interventionId = '';
    try {
      missionId = decodeURIComponent(contractMatch[1]);
      interventionId = decodeURIComponent(contractMatch[2]);
    } catch {
      return send(res, json(interventionCommandFailure('invalid_request', 400, {}, 'malformed route encoding').body, 400));
    }
    const body = await readJsonBody(req);
    const result = await decideIntervention({
      missionId,
      interventionId,
      expectedVersion: body.expectedVersion,
      idempotencyKey: body.idempotencyKey,
      payload: body,
      source: 'contract',
      contractRequest: true,
    });
    return send(res, json(result.body, result.status));
  }
  // 第56波(Pretender 立项门 / EC-E 363):全局「需要你」最小聚合入口 —— 跨会话 pending Intervention 收件箱。
  // 只读派生:扫 *.interventions.ndjson 折叠取 pending(注册/决策/超时/清理/重启终态化全在旁路账里);
  // pool 型由 71b 注册 + boot 对账覆盖,append 落盘延迟窗为最终一致(与 13d missionPendingCounts 同立场)。
  // 按 requestedAt 升序(FIFO 收件箱:最先等你的在最前)。
  if (req.method === 'GET' && pathname === '/api/interventions') {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const index = await getPretenderProjectionIndex();
    // hunt2-steward ⑨:可选 ?sessionId= 只看一条线程的待决(counts 同口径只数它)。抽屉修前拉全局前 100 条
    // 再在前端按会话筛 —— 全局待决超过 100 条时,排在后面的那条线程的待决永远落在页外,抽屉说它「没在等你」。
    // 不带这个参数的调用逐字节不变。ETag 带上筛选键:同一个修订号下两种视图的响应体不同。
    const onlySessionRaw = new URL(req.url, 'http://127.0.0.1').searchParams.get('sessionId');
    const onlySession = onlySessionRaw ? (safeSessionId(onlySessionRaw) || '~invalid') : '';
    const stewardView = new URL(req.url, 'http://127.0.0.1').searchParams.get('view') === 'steward';
    // 性能批 P3:待决列表按索引版本只收集、排序一次(引用 + 计数缓存在 index 对象上);分页与 ETag 在造条目之前 ——
    // 304 不再付整张表的代价,200 也只为这一页造条目。条目里的实时字段(可送达、活回合、倒计时)照旧每次现算。
    const { refs, counts } = pendingInterventionRefs(index, onlySession);
    const paged = paginatePretenderProjection(req, 'interventions', index.interventionsRevision, refs);
    if (paged.response) return send(res, paged.response);
    const etag = pretenderEtag('interventions', index.interventionsRevision + '-' + pretenderLiveOverlayRevision() + (onlySession ? '-s:' + onlySession : '') + (stewardView ? '-steward' : ''), paged.page);
    if (pretenderNotModified(req, etag)) return send(res, { status: 304, headers: { etag }, body: '' });
    paged.items = paged.items.map(ref => pendingInterventionItem(ref.slice, ref.iv));
    // 135(「等你处理」队列真机走查):弹窗要写清「来自哪条线程」,而前端左栏列表可能还没刷到刚开的线程。
    // 只读【本页】有待决的那几条会话的头(每个 ~1 KB,并行),取不到就留空,前端退回「未命名线程」。
    // 3.0 预览收口:此前在分页与 304 之前串行读【全部】待决会话的头,299 条会话时每请求 300–450 ms
    // (mission-index-scale 收件箱热 P95 闸 250 ms 红);标题从不进 ETag,挪到分页之后响应不变。
    const pageSids = [...new Set(paged.items.map(p => p.sessionId))];
    const heads = await Promise.all(pageSids.map(sid => readSessionHeadResilient(sid).catch(() => null)));
    const titleOf = new Map(pageSids.map((sid, i) => [sid, String((heads[i] && heads[i].title) || '').slice(0, 120)]));
    for (const p of paged.items) p.title = titleOf.get(p.sessionId) || '';
    if (stewardView) {
      const ids = [...new Set(paged.items.map(p => p.missionId).filter(id => !pageSids.includes(id)))];
      const containers = await Promise.all(ids.map(id => readMissionContainer(id).catch(() => null)));
      const titles = new Map(ids.map((id, i) => [id, String(containers[i]?.title || '')]));
      for (const p of paged.items) {
        p.missionTitle = titles.get(p.missionId) || p.title;
        const run = activeAgentRuns.get(p.runId)?.run;
        const detail = p.type === 'permission' ? p.input
          : p.type === 'plan' ? pendingPlans.get(String(p.id))?.markdown
            : p.type === 'pool' ? run?.taskPool?.find(item => item.id === p.id)
              : p.type === 'replan' ? run?.replanPatches?.find(item => item.id === p.id) : null;
        const text = typeof detail === 'string' ? detail : detail ? JSON.stringify(detail, null, 2) : '';
        p.detailsText = text.slice(0, 32000);
        p.detailsComplete = !!detail && text.length <= 32000;
      }
    }
    return send(res, json({
      ok: true,
      pending: paged.items,
      counts,
      page: paged.page,
      nextCursor: paged.page.nextCursor,
      projectionRevision: index.interventionsRevision,
      index: pretenderIndexMeta(index),
    }, 200, { etag }));
  }
  // 第71波:会话的持久化 Intervention 只读派生(注册/决策/超时/清理/重启终态化的旁路记录,02 NDJSON)。
  // 只认 /api/interventions/<一段>(同上:不再用 path.basename 给多段路径当别名)。
  const interventionsOf = req.method === 'GET' ? pathname.match(/^\/api\/interventions\/([^/]+)$/) : null;
  if (interventionsOf) {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const sessionId = safeSessionId(safeDecodeURIComponent(interventionsOf[1]) || '');
    if (!sessionId) return send(res, apiSessionIdInvalid());
    const index = await getPretenderProjectionIndex();
    const slice = index.sessions.find(row => row.sessionId === sessionId) || null;
    const interventions = slice ? slice.interventions : [];
    const counts = { permission: 0, question: 0, plan: 0, pool: 0, replan: 0, pending: 0, resolved: 0 };
    for (const iv of interventions) {
      if (!iv) continue;
      if (iv.status === 'pending') {
        counts.pending++;
        if (iv.type === 'permission') counts.permission++;
        else if (iv.type === 'question') counts.question++;
        else if (iv.type === 'plan') counts.plan++;
        else if (iv.type === 'pool') counts.pool++;
        else if (iv.type === 'replan') counts.replan++;
      } else counts.resolved++;
    }
    const revision = slice ? slice.interventionRevision : pretenderHash([]);
    const paged = paginatePretenderProjection(req, 'session-interventions:' + sessionId, revision, interventions);
    if (paged.response) return send(res, paged.response);
    const etag = pretenderEtag('session-interventions', revision, paged.page);
    if (pretenderNotModified(req, etag)) return send(res, { status: 304, headers: { etag }, body: '' });
    return send(res, json({
      ok: true,
      sessionId,
      missionId: slice ? slice.missionId : sessionId,
      interventions: paged.items,
      counts,
      page: paged.page,
      nextCursor: paged.page.nextCursor,
      projectionRevision: revision,
      integrity: slice ? slice.integrity : { degraded: false, corruptLines: 0, journalRows: 0, journalBytes: 0 },
    }, 200, { etag }));
  }
  if (req.method === 'POST' && pathname === '/api/chat/answer') {
    // 75b compatibility adapter: normalize the classic answer[] shape, then hand the actual decision to
    // the same command core used by the Mission contract.
    const body = await readJsonBody(req);
    const sessionId = String(body.sessionId || '');
    const questionId = String(body.questionId || body.toolUseId || '');
    const entry = pendingQuestions.get(questionId);
    if (!entry || entry.sessionId !== sessionId) {
      return send(res, apiFailure('question.not_pending', {}, 'question is no longer pending', 409));
    }
    const result = await decideIntervention({
      missionId: sessionId,
      interventionId: questionId,
      payload: { action: 'answer', normalizedAnswer: normalizeQuestionAnswer(body, entry.questions) },
      source: 'legacy_question',
      contractRequest: false,
    });
    if (result.status !== 200) return send(res, apiFailure('question.delivery_failed', {}, 'answer could not be delivered; the question is still pending', 409));
    return send(res, json({ ok: true, delivered: true, questionId }));
  }
  if (req.method === 'POST' && pathname === '/api/question/heartbeat') {
    // Keep-alive from the open question modal: re-arms the pending question's timeout so a user typing a
    // long answer is never cut off at a fixed deadline. No heartbeat (modal closed / app gone) means the
    // original timeout fires as the backstop. Returns the fresh deadline for the UI countdown.
    const body = await readJsonBody(req);
    const sessionId = String(body.sessionId || '');
    const extension = extendUserQuestion(sessionId, String(body.questionId || ''));
    if (!extension) return send(res, apiFailure('question.not_pending', {}, 'question is no longer pending', 409));
    return send(res, json({ ok: true, deadlineAt: extension.deadlineAt, timeoutMs: extension.timeoutMs }));
  }
  if (req.method === 'POST' && pathname === '/api/question/request') {
    const body = await readJsonBody(req);
    if (!tokenMatches(body.token)) return send(res, apiFailure('auth.token_invalid', {}, 'bad token', 403));
    return send(res, await CliBusinessHooks.question(body, { isClosed: () => res.writableEnded || res.destroyed }));
  }
  if (req.method === 'POST' && pathname === '/api/permission/request') {
    const body = await readJsonBody(req);
    if (!tokenMatches(body.token)) return send(res, json({ ok: false, error: 'bad token' }, 403));
    const response = await CliBusinessHooks.permission(body, { isClosed: () => res.writableEnded || res.destroyed });
    if (response) return send(res, response);
    return;
  }
  if (req.method === 'POST' && pathname === '/api/permission/decision') {
    // 75b compatibility adapter. The entry lookup only recovers the mission partition; execution is core-owned.
    const body = await readJsonBody(req);
    const requestId = String(body.requestId || '');
    const entry = pendingPermissions.get(requestId);
    if (!entry) return send(res, json({ ok: false, error: 'unknown or expired request' }, 404));
    const behavior = body.behavior === 'allow' ? 'allow' : 'deny';
    const result = await decideIntervention({
      missionId: entry.sessionId,
      interventionId: requestId,
      payload: behavior === 'allow'
        ? { action: 'allow', updatedInput: body.updatedInput, ...(body.scope === 'session' ? { scope: 'session' } : {}) }
        : { action: 'deny', message: body.message || 'denied by user' },
      source: 'legacy_permission',
      contractRequest: false,
    });
    if (result.status === 503) return send(res, json({ ok: false, error: 'could not record the decision on disk; nothing was applied, try again' }, 503));
    if (result.status !== 200) return send(res, json({ ok: false, error: 'unknown or expired request' }, 404));
    return send(res, json({ ok: true }));
  }
  if (req.method === 'POST' && pathname === '/api/plan/decision') {
    // 75b compatibility adapter for the classic plan-mode pause.
    const body = await readJsonBody(req);
    const planId = String(body.planId || '');
    const sessionId = String(body.sessionId || '');
    const entry = pendingPlans.get(planId);
    if (!entry || entry.sessionId !== sessionId) return send(res, json({ ok: false, error: 'no pending plan' }));
    const decision = body.decision === 'approve' ? 'approve' : 'reject';
    const result = await decideIntervention({
      missionId: sessionId,
      interventionId: planId,
      payload: { action: decision, feedback: body.note != null ? String(body.note) : '' },
      source: 'legacy_plan',
      contractRequest: false,
    });
    if (result.status !== 200) return send(res, json({ ok: false, error: 'no pending plan' }));
    return send(res, json({ ok: true }));
  }
  // 75a-2: test-only CAS primitive probe (failure-injection matrix, SCHEMA §7 六窗口). Env-gated
  // (RUYI_TEST_HOOKS=1) + token; production returns 404. Not a user-facing route -- 75b 的统一契约端点
  // POST /api/missions/:missionId/interventions/:id/decision 才是对外入口。
  if (req.method === 'POST' && pathname === '/api/_test/intervention-cas') {
    if (process.env.RUYI_TEST_HOOKS !== '1') return send(res, json({ ok: false, error: 'not found' }, 404));
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const body = await readJsonBody(req);
    let result;
    try {
      // 116c: source 可由请求指定(默认仍是 'test',既有用例逐字节不变)——让 CAS 矩阵能直接验证
      // source:'steward' 的成功/版本冲突/越权三条路径在命令核心里走的是同一套判定与同一条落盘格式。
      result = await transitionInterventionState(body.sessionId, body.ivId, body.expectedVersion, body.toStatus || 'allowed', {
        crashAt: body.crashAt, decidedBy: body.decidedBy, source: String(body.source || 'test').slice(0, 64),
        action: body.actionMs ? () => new Promise(r => setTimeout(r, Number(body.actionMs) || 0)) : undefined,
      });
    } catch (e) {
      const m = String((e && e.message) || '');
      if (m.startsWith('__cas_crash:')) return send(res, json({ ok: false, reason: 'crash', at: m.slice('__cas_crash:'.length) }));
      throw e;
    }
    return send(res, json(result));
  }
  return false;
}

// ── 116c(27 号文 §11.3「116c ... steward_run_action ... 如果动作逻辑内联在路由里,先把它零行为抽成
// 可调用函数(同模块),路由改为调用它」)────────────────────────────────────────────────────────
// 五个班组动作(pause/resume/stop/retry_node/steer_node)的实现从 POST /api/agent-runs/:runId 路由体里
// 零行为搬出:每个分支原来的 `send(res, json(BODY, STATUS))` 逐个换成 `return { status, body }`,判定
// 顺序、措辞、计数(bumpRunIntervention)、事件(appendAgentRunEvent)与落盘时机一字未改。
// 不在本函数内处理的动作(apply_isolation / pool_approve / pool_reject / 未知动作)返回 null,由路由
// 沿用原有分支继续处理 —— 这样搬家对 HTTP 面是逐字节等价的。
// 归属校验(live.run.sessionId !== sessionId -> 404)在函数内【再做一次】:进程内调用方(管家)不经过
// 路由体那道闸,fail-closed 的重复判定比信任调用方便宜得多。
// 135c:线程内后台任务条里的「子代理 / 班组」两类。只看【活着的】run(activeAgentRuns,进程内真值):
// 跑完的 run 按拍板「跑完即消失」不出现,结果照旧走 background.completed 的 toast 与对话里的回执。
// sessionId 传 null = 全部线程(左栏计数用)。tail 取在跑节点最近一条 progressLog,过 redact 裁 160。
const BACKGROUND_RUN_DONE = new Set(['succeeded', 'failed', 'skipped', 'cancelled', 'stopped', 'partial']);
function sessionBackgroundRunRows(sessionId) {
  const sid = sessionId ? safeSessionId(sessionId) : '';
  const rows = [];
  for (const [runId, live] of activeAgentRuns) {
    const run = live && live.run;
    if (!run || !run.sessionId) continue;
    if (sid && run.sessionId !== sid) continue;
    const nodes = Array.isArray(run.nodes) ? run.nodes : [];
    let tail = '', tailAt = '';
    for (const node of nodes) {
      if (!node || node.status !== 'running' || !Array.isArray(node.progressLog) || !node.progressLog.length) continue;
      const last = node.progressLog[node.progressLog.length - 1];
      if (last && String(last.at || '') >= tailAt) { tailAt = String(last.at || ''); tail = String(last.text || ''); }
    }
    const first = nodes[0] || {};
    rows.push({
      id: 'run:' + runId,
      kind: (run.kind === 'spawn_agent' || nodes.length === 1) ? 'agent' : 'run', // 代理模式 v2:单节点 run 读作「代理」,多节点读作「班组」
      runId,
      sessionId: run.sessionId,
      name: String(run.title || first.task || first.id || runId).replace(/\s+/g, ' ').slice(0, 120),
      startedAt: run.createdAt || '',
      status: live.stopRequested ? 'stopping' : live.paused ? 'paused' : String(run.status || 'running'),
      progress: { done: nodes.filter(n => n && BACKGROUND_RUN_DONE.has(n.status)).length, total: nodes.length },
      tail: tail ? redact(tail.replace(/\s+/g, ' ')).slice(0, 160) : '',
    });
  }
  return rows;
}

async function agentRunActionCommand(input) {
  const o = (input && typeof input === 'object') ? input : {};
  const sessionId = safeSessionId(o.sessionId);
  const runId = safeSessionId(o.runId);
  const action = String(o.action || '');
  if (!sessionId || !runId) return { status: 400, body: { ok: false, error: 'sessionId/runId required' } };
  const live = activeAgentRuns.get(runId);
  if (live && live.run && live.run.sessionId && live.run.sessionId !== sessionId) return { status: 404, body: { ok: false, error: 'agent run not found' } };
  if (action === 'pause') {
    if (!live) return { status: 409, body: { ok: false, error: '工作流当前未运行' } };
    // 对抗轮 P3(#8): 计数按【状态迁移】幂等 —— 对已暂停 run 重复 POST(UI 按钮态滞后期双击/双面板)端点行为
    // 无害但计数器会被 UI 时延系统性抬高。只在真正 running→paused 时计一次干预(与本文件 pool_approve 先查
    // status!=='proposed' 的"无效重复不计干预"模式一致)。
    const wasPaused = live.paused === true;
    live.paused = true; live.run.pauseRequestedAt = nowIso();
    if (!wasPaused) bumpRunIntervention(live.run, 'pause'); // 29c(状态迁移才计)
    appendAgentRunEvent(live.run, { type: 'run_paused', data: { reason: 'user' } }); // 25.3
    await saveAgentRun(live.run);
    return { status: 200, body: { ok: true, state: 'pausing' } };
  }
  if (action === 'resume') {
    if (live) {
      // Reset the idle clock ATOMICALLY with clearing paused: the watchdog reads live.lastActivityAt, so by the
      // time it observes paused=false the clock is already fresh -> no false idle-abort right after a long pause.
      const wasPaused = live.paused === true; // 对抗轮 P3(#8): 仅 paused→running 计一次(对运行中 run resume 是 no-op,不计)
      live.paused = false; live.lastActivityAt = Date.now(); const waiters = live.resumeWaiters.splice(0); for (const wake of waiters) wake();
      if (wasPaused) bumpRunIntervention(live.run, 'resume'); // 29c
      appendAgentRunEvent(live.run, { type: 'run_resume_requested', data: { mode: 'warm' } }); // 25.3
      saveAgentRun(live.run).catch(() => {}); // 对抗轮修: 追写快照,让 eventSeq 尽快落盘(缩小崩溃重号窗口)
      return { status: 200, body: { ok: true, state: 'running' } };
    }
    return { status: 200, body: await launchPersistedAgentRun({ sessionId, runId, interventionKind: 'resume' }) };
  }
  if (action === 'stop') {
    if (!live) return { status: 409, body: { ok: false, error: '工作流当前未运行' } };
    const wasStopping = live.stopRequested === true; // 对抗轮 P3(#8): 重复 stop 不重复计
    live.stopRequested = true; live.paused = false; try { if (live.ctrl) live.ctrl.abort(); } catch {}
    const waiters = live.resumeWaiters.splice(0); for (const wake of waiters) wake();
    if (!wasStopping) bumpRunIntervention(live.run, 'stop'); // 29c
    appendAgentRunEvent(live.run, { type: 'run_stop_requested' }); // 25.3
    saveAgentRun(live.run).catch(() => {}); // 对抗轮修: 同 resume —— 追写快照缩小 eventSeq 崩溃重号窗口
    return { status: 200, body: { ok: true, state: 'stopping' } };
  }
  if (action === 'retry_node') {
    if (live) return { status: 409, body: { ok: false, error: '请先等待或停止当前运行' } };
    const nodeId = String(o.nodeId || '').trim();
    return { status: 200, body: await launchPersistedAgentRun({ sessionId, runId, retryNodeId: nodeId, retryCascade: o.cascade === true, interventionKind: 'retry_node' }) };
  }
  // Directional node steering. Provider nodes consume at their next iteration boundary; Claude nodes consume
  // through the live stream-json stdin channel. Queued nodes keep the message until their model starts.
  if (action === 'steer_node') {
    if (!live) return { status: 409, body: { ok: false, error: '工作流当前未运行，无法插话' } };
    // 停止收尾窗口：stop 已经请求（或 ctrl 已中止）之后，节点即将被标记 cancelled，不会再有下一次迭代边界来
    // 消费插话队列；此时接受插话只会让用户误以为它会生效，直接拒绝更诚实。
    if (live.stopRequested || (live.ctrl && live.ctrl.signal && live.ctrl.signal.aborted)) return { status: 409, body: { ok: false, error: '工作流正在停止，无法插话' } };
    const nodeId = String(o.nodeId || '').trim();
    if (!nodeId) return { status: 400, body: { ok: false, error: 'nodeId required' } };
    // 团队模式 v2 (B1): 投递资格判定与 send_to_agent 共用同一小函数(不复制两份),reason 各自映射为本处既有措辞。
    const elig = nodeDeliveryEligibility(live.run, nodeId, { allowClaude: true });
    if (elig.reason === 'not_found') return { status: 404, body: { ok: false, error: '节点不存在' } };
    if (elig.reason === 'deterministic_gate') return { status: 409, body: { ok: false, error: '确定性质量门节点不经过模型，无法插话' } };
    if (elig.reason === 'terminal') return { status: 409, body: { ok: false, error: '节点已结束，无法插话' } };
    if (!elig.ok) return { status: 409, body: { ok: false, error: { code: 'agent_run.mailbox_closed', params: { reason: elig.reason }, message: '节点正在收尾，无法插话' } } };
    const text = String(o.text || '').trim().slice(0, 2000);
    if (!text) return { status: 400, body: { ok: false, error: '插话内容不能为空' } };
    if (!live.steerQueues) live.steerQueues = new Map();
    let q = live.steerQueues.get(nodeId);
    if (!q) { q = []; live.steerQueues.set(nodeId, q); }
    if (q.length >= STEER_QUEUE_MAX) return { status: 409, body: { ok: false, error: '该节点插话队列已满' } };
    q.push(text);
    bumpRunIntervention(live.run, 'steer_node'); // 29c(队列在内存,计数随下一次快照落盘即可,不额外写盘)
    return { status: 200, body: { ok: true, queued: q.length, live: elig.node.status === 'running' } };
  }
  return null; // 本函数不认识的动作(apply_isolation / pool_* / 未知)——由路由沿用原分支
}

async function handleAgentRunApiRoutes(req, res, pathname) {
  if (req.method === 'GET' && pathname === '/api/agent-runs') {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const listUrl = new URL(req.url, 'http://x');
    const sessionId = safeSessionId(listUrl.searchParams.get('sessionId'));
    if (!sessionId) return send(res, json({ ok: false, error: 'sessionId required' }, 400));
    // digest 视图只要标量:走按 mtime+size 缓存的 listAgentRunDigests(08),未变的 run 文件零读盘;完整视图照旧读全量。
    const digestView = listUrl.searchParams.get('view') === 'digest';
    const readRuns = () => (digestView ? listAgentRunDigests(sessionId) : listAgentRuns(sessionId));
    const liveBefore = [...activeAgentRuns.keys()]; let runs = await readRuns(); if (liveBefore.some(id => !activeAgentRuns.has(id))) runs = await readRuns();   // 读盘期间有 run 收尾（终稿落盘后才撤活对象）：先前读到的是收尾前快照、却已不算 live（提案仍 proposed）→ 重读一次拿终稿
    // A live run's in-memory state is newer than its throttled crash-recovery snapshot. Return a detached
    // copy of that state for the full polling view, otherwise short nodes can finish before their intermediate
    // progressLog snapshot is ever observable and the UI falsely looks frozen.
    // digest(每 2s 轮询)只从这里读标量、不外发也不改对象:浅展开即与深拷贝读到的值逐字段相同,
    // 省掉每个 live run 整份节点/结果/progressLog 的 JSON 往返。完整视图照旧深拷贝(对象要外发)。
    for (let i = 0; i < runs.length; i += 1) {
      const live = activeAgentRuns.get(runs[i].id);
      if (!live || !live.run) continue;
      runs[i] = { ...(digestView ? live.run : JSON.parse(JSON.stringify(live.run))), live: true, paused: !!live.paused };
    }
    // 第29波(§29a): digest 轻量视图 —— 增量客户端每 tick 只拉这份 run 级标量做变更探测(eventSeq/status/
    // updatedAt),不再每 2s 重传全部节点(单节点 result≤24KB + roleSnapshot 8KB prompt,历史终态 run 每 tick
    // 白传)。live run 的 eventSeq/status/updatedAt 以【内存】为准(快照节流 1.5s,磁盘恒旧);快照仍是唯一
    // 权威状态源,digest 只是"该不该去拉"的信号。
    if (digestView) {
      // runs 此刻是磁盘摘要(live 且有内存对象的已被上面换成 live.run 的浅展开);逐行装配见 08 agentRunDigestRow。
      const digest = runs.map(r => agentRunDigestRow(r, activeAgentRuns.get(r.id)));
      return send(res, json({ ok: true, view: 'digest', runs: digest }));
    }
    return send(res, json({ ok: true, runs }));
  }
  // 第29波(§29a): 增量事件消费 —— 客户端记住 lastSeq,断线/重开后 afterSeq=lastSeq 重发即天然补播;
  // seq 严格单调(25.3)保证补播无重无漏。必须排在文件底部 GET /api/agent-runs/:id 通配前缀分支之前,
  // 否则被吞。跨会话防护与快照端点同源:事件文件按 sessionId 分目录,错 session 只会 404→空数组。
  if (req.method === 'GET' && pathname.startsWith('/api/agent-runs/') && pathname.endsWith('/events')) {
    if (!tokenOk(req)) return send(res, json({ ok: false, error: 'missing or invalid workbench token' }, 403));
    const evUrl = new URL(req.url, 'http://x');
    const sessionId = safeSessionId(evUrl.searchParams.get('sessionId'));
    const evParts = pathname.split('/').filter(Boolean); // ['api','agent-runs',runId,'events']
    const runId = evParts.length === 4 ? safeSessionId(evParts[2]) : null;
    if (!sessionId || !runId) return send(res, json({ ok: false, error: 'sessionId/runId required' }, 400));
    const afterSeq = Number(evUrl.searchParams.get('afterSeq')) || 0;
    const { events, hasMore } = await readAgentRunEvents(sessionId, runId, afterSeq, Number(evUrl.searchParams.get('limit')) || 0);
    return send(res, json({ ok: true, runId, afterSeq, events, hasMore }));
  }
  if (req.method === 'POST' && pathname.startsWith('/api/agent-runs/')) {
    const parts = pathname.split('/').filter(Boolean);
    const runId = safeSessionId(parts[2]);
    const body = await readJsonBody(req);
    const sessionId = safeSessionId(body.sessionId);
    const action = String(body.action || '');
    if (!sessionId || !runId) return send(res, json({ ok: false, error: 'sessionId/runId required' }, 400));
    const live = activeAgentRuns.get(runId);
    // runId 是全局命名空间（不像持久化文件那样按 sessionId 分目录），live runtime 挂在内存 Map 里也不天然按
    // sessionId 隔离——不加这层校验，一个知道/猜到 runId 的会话就能 pause/resume/stop/steer 另一个会话正在跑的
    // 工作流。对齐 apply_isolation 从文件读到 run 后做的 run.sessionId !== sessionId 校验语义，统一在这里拦截，
    // 对 pause/resume/stop/steer_node 全部生效；resume 的冷启动分支（live 为空）走 launchPersistedAgentRun，
    // 本来就按 sessionId 找持久化文件，不受影响。
    if (live && live.run && live.run.sessionId && live.run.sessionId !== sessionId) return send(res, json({ ok: false, error: 'agent run not found' }, 404));
    // 116c: pause/resume/stop/retry_node/steer_node 五个动作的实现搬到 agentRunActionCommand(同模块,
    // 零行为);本路由只做 HTTP 适配。其余动作(apply_isolation / pool_*)返回 null,继续走下面的原分支。
    {
      const cmd = await agentRunActionCommand({ sessionId, runId, action, nodeId: body.nodeId, text: body.text, cascade: body.cascade === true });
      if (cmd) return send(res, json(cmd.body, cmd.status));
    }
    if (action === 'apply_isolation') {
      if (live) return send(res, json({ ok: false, error: '请先等待当前运行结束' }, 409));
      const nodeId = String(body.nodeId || '').trim();
      const run = await readAgentRunSnapshot(sessionId, runId).catch(error => {
        if (String(error && error.code || '').startsWith('work_data')) throw error;
        return null;
      });
      if (!run || run.sessionId !== sessionId) return send(res, json({ ok: false, error: 'agent run not found' }, 404));
      const applied = await applyAgentWorktree(run, nodeId).catch(e => ({ ok: false, error: String(e && (e.gitStderr || e.message) || e) }));
      return send(res, json(applied, applied.ok ? 200 : 409));
    }
    // 75b compatibility adapter: pool approval/rejection shares decideIntervention with the Mission contract.
    if (action === 'pool_approve' || action === 'pool_reject') {
      const poolId = String(body.poolId || '').trim();
      if (!poolId) return send(res, json({ ok: false, error: 'poolId required' }, 400));
      const result = await decideIntervention({
        missionId: sessionId,
        interventionId: poolId,
        requestRunId: runId,
        payload: { action: action === 'pool_approve' ? 'approve' : 'reject' },
        source: 'legacy_pool',
        contractRequest: false,
      });
      if (result.status !== 200) {
        const reason = String(result.body && result.body.reason || '');
        if (!live || live.closing) return send(res, json({ ok: false, error: '运行已结束;可在新运行中执行该任务' }, 409));
        if (reason === 'not_found') return send(res, json({ ok: false, error: '提案不存在' }, 404));
        const item = (Array.isArray(live.run.taskPool) ? live.run.taskPool : []).find(p => p && String(p.id) === poolId);
        if (item && item.status !== 'proposed') return send(res, json({ ok: false, error: `该提案已处理(${item.status})` }, 409));
        const message = result.body && result.body.error && result.body.error.message;
        return send(res, json({ ok: false, error: message || '运行已结束或提案已处理' }, result.status === 404 ? 404 : 409));
      }
      return send(res, json({
        ok: true,
        status: action === 'pool_approve' ? 'materialized' : 'rejected',
        poolId,
        ...(result.body.nodeId ? { nodeId: result.body.nodeId } : {}),
      }));
    }
    return send(res, json({ ok: false, error: 'unknown action' }, 400));
  }
  if (req.method === 'DELETE' && pathname.startsWith('/api/agent-runs/')) {
    const runId = safeSessionId(pathname.slice('/api/agent-runs/'.length));
    const sessionId = safeSessionId(new URL(req.url, 'http://x').searchParams.get('sessionId'));
    if (!sessionId || !runId) return send(res, json({ ok: false, error: 'sessionId/runId required' }, 400));
    if (activeAgentRuns.has(runId)) return send(res, json({ ok: false, error: '运行中的工作流不能删除' }, 409));
    try {
      const file = agentRunFile(sessionId, runId);
      const run = await readAgentRunSnapshot(sessionId, runId);
      for (const node of (run && run.nodes || [])) if (node.isolation) await cleanupAgentWorktree(node.isolation);
      await fsp.unlink(file);
      agentRunDigestWriteSeq += 1;
      agentRunDigestCache.delete(file);   // digest 摘要缓存(08):文件没了条目一并撤
      // 对抗轮修(第25波): 删除快照必须连带删姊妹事件日志 —— 用户删「运行记录」的心智模型是数据消失,
      // 取证 ndjson(含时间线/错误切片)不该在删除后无限期残留。
      await fsp.unlink(agentRunEventsFile(sessionId, runId)).catch(() => {});
      await fsp.unlink(agentRunEventsFile(sessionId, runId) + '.gz').catch(() => {}); // v1.9 数据管家: 归档压缩变体一并删
    } catch (error) { if (String(error && error.code || '').startsWith('work_data')) throw error; return send(res, json({ ok: false, error: 'agent run not found' }, 404)); }
    await bumpMissionChangeSeq(sessionId, {
      type: 'run_deleted', cursor: { runId }, detail: { runId },
    });
    RUYI_EVENTS.emit('thread.state', { sessionId });   // 128f-⑫:行上的「最后一次班组」换了一条(或没了)
    return send(res, json({ ok: true }));
  }
  if (req.method === 'GET' && pathname.startsWith('/api/agent-runs/')) {
    if (!tokenOk(req)) return send(res, apiFailure('auth.token_invalid', {}, 'missing or invalid workbench token', 403));
    const sessionId = safeSessionId(new URL(req.url, 'http://x').searchParams.get('sessionId'));
    const runId = safeSessionId(pathname.slice('/api/agent-runs/'.length));
    if (!sessionId || !runId) return send(res, apiFailure('agent_run.id_required', {}, 'sessionId/runId required', 400));
    // 第29波(§29a): live run 以【内存】对象下发 —— 增量客户端在 settle 类事件后靠本端点刷新单 run 状态,
    // 磁盘快照节流 1.5s 恒旧,读盘会让客户端 lastSeq 与状态错位(拿旧状态配新 seq)。JSON.stringify 同步
    // 执行,事件循环内原子,无撕裂读。归属校验与 POST action 的 live 分支同源(sessionId 不符 = 404)。
    const liveOne = activeAgentRuns.get(runId);
    if (liveOne && liveOne.run) {
      if (liveOne.run.sessionId !== sessionId) return send(res, json({ ok: false, error: 'agent run not found' }, 404));
      return send(res, json({ ok: true, run: { ...liveOne.run, live: true, paused: !!liveOne.paused } }));
    }
    try {
      const run = await readAgentRunSnapshot(sessionId, runId);
      if (!run) throw new Error('invalid run');
      if (EventStreamHooks.projectAgentMessageReceipts) await EventStreamHooks.projectAgentMessageReceipts(run);
      return send(res, json({ ok: true, run }));
    } catch (error) { if (String(error && error.code || '').startsWith('work_data')) throw error; return send(res, json({ ok: false, error: 'agent run not found' }, 404)); }
  }
  return false;
}
