// ── 04f · ruyi-toolbox 服务类组件:拉起、探活、接成能力端点、回收 ─────────────────────────────────────────
// 用户 2026-09-21:「如意启动时自动探测本机上是否有这个 asr shim,有的话自动拉起并自动配置好,开箱即用」,
// 随后扩成「toolbox 下的都是这样」。对接面只有 ruyi-toolbox 仓的 docs/00-component-registry.md;登记文件的读取与
// 校验住 04(scanToolboxComponents),MCP 类组件也在 04 并进外部 MCP 清单 —— 本模块只管 kind:'service'。
// 这是 26 号文 114d 后半(「本地 HTTP 助手进程」管理器)的落地,形状比当时写的更一般:不再是 provider 上的
// localCommand 字段,而是一份住在用户主目录下的登记文件 —— 命令【只来自磁盘】,没有任何 HTTP 途径写它。
//
// 纪律:
//   ① 绝不阻塞启动。startServer 里 void 调用;探活用 fetch(异步),拉起用 spawn(异步),一发 spawnSync 都没有
//      (128f-⑬ 的教训:同步探测会把整个服务钉住)。进程退出那一刻的收尾也走 killChildTree(发出去就算,不等它)—— 那时已经没有请求要服务了。
//   ② 已经有人起好了就不起第二个:端口上站着的 /health 回 component 对得上 → 直接用(owned:false,退出时也不杀它)。
//   ③ 端口被【别人】占了 → 另挑空闲端口经 portEnv 告诉组件。component 对不上的端口绝不配成端点。
//   ④ 不经 shell、不拼接参数、不展开变量;windowsHide;stdin 忽略;stderr 只留尾巴给设置页看,不进日志正文。
//   ⑤ 自动选成语音识别端点【每个组件只发生一次】(config.toolbox.seen),且只在用户还没配过语音识别时;
//      用户后来关掉或换走,绝不再替他选回来。已经配了别的 → 只列为候选。
//   ⑥ 自动生成的服务商 id 一律 `toolbox-<id>`,这个前缀归自动发现所有:组件被停用／卸载,条目跟着撤。
//      组件只是【这次没起来】不撤条目 —— 否则一次偶发失败就会把用户的语音识别选择永久清掉(⑤ 不会再选回来)。
//   ⑦ 每次拉起／接管／失败／停止都记审计日志(组件 id、pid、端口、结果),不是悄悄的。
// 约定 §2.2 第 4 条:健康轮询 ≤ 20 秒。测试口 WCW_TEST_TOOLBOX_HEALTH_DEADLINE_MS 把窗口缩短(toolbox-discovery I3 的
// 「起来了却永不答 /health」不必真等 20 秒);产品里恒为 20 s。
const TOOLBOX_HEALTH_DEADLINE_MS = (() => {
  const raw = Number(process.env.WCW_TEST_TOOLBOX_HEALTH_DEADLINE_MS);
  return Number.isFinite(raw) && raw > 0 ? raw : 20000;
})();
const TOOLBOX_HEALTH_POLL_MS = 400;
const TOOLBOX_PROBE_TIMEOUT_MS = 1500;
const TOOLBOX_STDERR_TAIL = 2000;
const toolboxServices = new Map();          // id → { component, state, port, owned, child, pid, error, stderrTail, starting, stopping, startedAt }

function toolboxProviderId(componentId) { return 'toolbox-' + componentId; }

// 'ours' = 端口上站着的就是这个组件;'other' = 有人占着但不是它;'down' = 端口空着。
async function toolboxProbe(port, healthPath, componentTag) {
  try {
    const res = await fetch('http://127.0.0.1:' + port + healthPath, { signal: AbortSignal.timeout(TOOLBOX_PROBE_TIMEOUT_MS) });
    const text = (await res.text()).slice(0, 4096);
    const body = safeJsonParse(text, null);
    if (res.ok && body && typeof body === 'object' && body.component === componentTag) return 'ours';
    return 'other';
  } catch {
    return (await toolboxPortFree(port)) ? 'down' : 'other';
  }
}
function toolboxListenOnce(port) {
  return new Promise(resolve => {
    const probe = http.createServer();
    probe.once('error', () => resolve(0));
    probe.listen(port, '127.0.0.1', () => { const got = probe.address().port; probe.close(() => resolve(got)); });
  });
}
async function toolboxPortFree(port) { return (await toolboxListenOnce(port)) === port; }
async function toolboxFreePort() { return toolboxListenOnce(0); }

// 整棵树:Windows 上 venv 的 python.exe 是个启动器,真正的解释器是它的子进程 —— 只 kill 启动器会留下孤儿(还占着显存)。
// 走查 W1·F12:收尸一律走 04 的 killChildTree(128i:按创建时间只认自己的子孙,动手前核启动时间;发出去就算,服务正在退出时也能跑完),
// 不再自己 `taskkill /PID /T /F`(/T 按父号认子孙,父号过期撞号会带走别人的树 —— 128i 把其余 14 处调用点都换掉了,这一处当时漏了)。
// 也不再接一句立即的 child.kill():Windows 上它会在 killChildTree 的 PowerShell 做进程表快照之前先把根杀掉,孙辈就认不出来了(ROOT-GONE)。
// 进程退出那一刻的收尾同样走它(同步 / 异步没有区别,所以不再有 sync 形参)。
function toolboxKillTree(child) {
  if (!child || !child.pid || child.exitCode !== null || child.signalCode) return;
  killChildTree(child.pid);
}

function toolboxEntry(component) {
  let entry = toolboxServices.get(component.id);
  if (!entry) {
    entry = { component, state: 'idle', port: component.service.port, owned: false, child: null, pid: 0, error: '', stderrTail: '', starting: null, stopping: false, startedAt: 0 };
    toolboxServices.set(component.id, entry);
  }
  entry.component = component;
  return entry;
}

// 起一个服务(幂等、并发互斥:同一个组件同时只有一趟在起 —— 55 波「getMcpClient 必须并发互斥防孤儿」同一条教训)。
function startToolboxService(component) {
  const entry = toolboxEntry(component);
  if (entry.starting) return entry.starting;
  entry.starting = (async () => {
    const svc = component.service;
    const t0 = Date.now();
    // 还活着就不动:自己起的看子进程,接管来的再探一次。
    if (entry.state === 'running') {
      if (!entry.owned && (await toolboxProbe(entry.port, svc.health, svc.component)) === 'ours') return entry;
      // 自己起的:子进程还在【且端口上真有人】才算活着。Windows 上 venv 的 python.exe 是启动器,真解释器(/health 报的
      // 那个 pid)死了之后启动器的 exit 要晚一拍才到 —— 修前这一拍里只看 exitCode,认定「还活着」不去重起,转写被转发到
      // 一个没人听的端口(toolbox-discovery I1 在 Windows CI 上偶发 502 的根)。只认「端口已经空了」这一种死法:
      // 端口还被占着、只是探活没及时回(可能正忙着转写)的,照旧当活着,绝不误杀。
      if (entry.owned && entry.child && entry.child.exitCode === null) {
        if ((await toolboxProbe(entry.port, svc.health, svc.component)) !== 'down') return entry;
        const stale = entry.child;
        logEvent({ kind: 'toolbox_service', action: 'stale-child', id: component.id, pid: entry.pid, port: entry.port });
        entry.child = null;                 // 旧子进程的 exit 回调据此认出自己已不是现任,不再改状态
        toolboxKillTree(stale);      // 残留的启动器连同它的树一起收掉,别留孤儿
      }
    }
    entry.error = ''; entry.stderrTail = ''; entry.stopping = false;
    const first = await toolboxProbe(svc.port, svc.health, svc.component);
    if (first === 'ours') {
      Object.assign(entry, { state: 'running', port: svc.port, owned: false, child: null, pid: 0, startedAt: Date.now() });
      logEvent({ kind: 'toolbox_service', action: 'adopt', id: component.id, port: svc.port });
      return entry;
    }
    const port = first === 'down' ? svc.port : await toolboxFreePort();
    if (!port) { Object.assign(entry, { state: 'failed', error: 'no-free-port' }); logEvent({ kind: 'toolbox_service', action: 'fail', id: component.id, reason: 'no-free-port' }); return entry; }
    let child = null;
    try {
      child = cp.spawn(component.run.command, component.run.args, {
        cwd: component.run.cwd, shell: false, windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'],
        env: { ...process.env, PYTHONUTF8: '1', PYTHONUNBUFFERED: '1', ...component.run.env, [svc.portEnv]: String(port), RUYI_TOOLBOX_PARENT_PID: String(process.pid) },
      });
    } catch (err) {
      Object.assign(entry, { state: 'failed', error: 'spawn: ' + String(err && err.message || err).slice(0, 200) });
      logEvent({ kind: 'toolbox_service', action: 'fail', id: component.id, reason: 'spawn' });
      return entry;
    }
    Object.assign(entry, { state: 'starting', port, owned: true, child, pid: child.pid || 0 });
    let spawnError = '';
    let gaveUp = false;   // 健康窗口内没起来、这一趟由我们杀掉 —— 见下面「没起来」那段
    child.on('error', err => { spawnError = String(err && err.message || err).slice(0, 200); });
    if (child.stderr) {
      child.stderr.setEncoding('utf8');
      child.stderr.on('data', chunk => { entry.stderrTail = (entry.stderrTail + chunk).slice(-TOOLBOX_STDERR_TAIL); });
    }
    child.on('exit', (code, signal) => {
      if (entry.child !== child) return;
      if (gaveUp) { logEvent({ kind: 'toolbox_service', action: 'stop', id: component.id, pid: entry.pid, code, signal: signal || '' }); return; }
      const was = entry.state;
      entry.state = entry.stopping ? 'stopped' : (was === 'starting' ? 'failed' : 'exited');
      if (!entry.stopping) entry.error = 'exit ' + (code === null ? String(signal || '') : code);
      logEvent({ kind: 'toolbox_service', action: entry.stopping ? 'stop' : 'exit', id: component.id, pid: entry.pid, code, signal: signal || '' });
    });
    logEvent({ kind: 'toolbox_service', action: 'spawn', id: component.id, pid: entry.pid, port, command: path.basename(component.run.command) });
    const deadline = t0 + TOOLBOX_HEALTH_DEADLINE_MS;
    while (Date.now() < deadline) {
      if (spawnError || child.exitCode !== null || child.signalCode) break;
      if (entry.stopping) return entry;
      if ((await toolboxProbe(port, svc.health, svc.component)) === 'ours') {
        Object.assign(entry, { state: 'running', startedAt: Date.now() });
        logEvent({ kind: 'toolbox_service', action: 'ready', id: component.id, pid: entry.pid, port, ms: Date.now() - t0 });
        return entry;
      }
      await new Promise(r => setTimeout(r, TOOLBOX_HEALTH_POLL_MS));
    }
    // 没起来:不重试到天荒地老。杀掉、记一笔、把 stderr 的尾巴留给设置页。
    // 走查 2026-10-08:修前这里先置 entry.stopping=true 再杀 —— 被杀的子进程随后的 exit 回调按「正在停」把刚写下的 failed
    // 改写成 stopped,失败冷却(只认 failed)随之失效:健康超时的组件此后每按一次麦克风 / 每次转写都重拉一遍、干等 20 秒,
    // 设置页还显示「已停止」而不是「没起来」。现在用 gaveUp 标出「这一趟是我们放弃的」,exit 回调只记一笔、不动状态与 error。
    gaveUp = true;
    toolboxKillTree(child);
    Object.assign(entry, { state: 'failed', error: spawnError || (child.exitCode !== null ? 'exit ' + child.exitCode : 'health-timeout') });
    logEvent({ kind: 'toolbox_service', action: 'fail', id: component.id, pid: entry.pid, reason: entry.error });
    return entry;
  })().finally(() => {
    entry.starting = null;
    if (entry.state === 'failed') { entry.failures = (entry.failures || 0) + 1; entry.failedAt = Date.now(); }
    else if (entry.state === 'running') entry.failures = 0;
  });
  return entry.starting;
}
// 起失败之后的冷却:15 s 起、每失败一次翻倍、封顶 5 分钟。只管「转写前就地再起」这一路(ensureToolboxServiceForProvider);
// 设置页的显式启动与对账照旧立刻起。修前每按一次麦克风都重新拉起一遍,一直起不来的组件每次都让用户白等最长 20 s。
function toolboxRetryCooldownMs(failures) { return Math.min(300000, 15000 * 2 ** Math.max(0, (Number(failures) || 1) - 1)); }

function stopToolboxService(id) {
  const entry = toolboxServices.get(id);
  if (!entry) return;
  entry.stopping = true;
  if (entry.owned && entry.child) toolboxKillTree(entry.child);   // 接管来的(用户自己起的)不杀
  if (entry.state !== 'failed') entry.state = 'stopped';
}
// 进程退出那一刻(13 cleanupMcp):同步杀干净自己拉起的。如意被强杀时走不到这里 —— 那种情况靠组件自己的父进程看门狗。
function stopAllToolboxServicesSync() {
  for (const id of toolboxServices.keys()) { try { stopToolboxService(id); } catch { /* 收尾绝不抛 */ } }
}

// 把启用的服务类组件的 provides 落成配置。只在真有变化时才写盘(mutateConfig 的 abort 支)。
// 130(51 号文 §2.3):一个组件可以同时提供 asr(整段)与 asr-stream(流式),落成同一条服务商、两个带不同标记的模型;
// 两种能力各自有一对配置键(asrProviderId/asrModel 与 asrStreamProviderId/asrStreamModel),自动选中各算各的。
function toolboxDesiredProviders(config) {
  const out = [];
  for (const c of enabledToolboxComponents(config)) {
    if (c.kind !== 'service') continue;
    const asr = c.provides.find(p => p.type === 'asr') || null;
    const stream = c.provides.find(p => p.type === 'asr-stream') || null;
    if (!asr && !stream) continue;
    const entry = toolboxServices.get(c.id);
    const port = entry && entry.port ? entry.port : c.service.port;
    const base = 'http://127.0.0.1:' + port + ((asr || stream).basePath || '');
    const models = [];
    // 133:组件可以列多份模型(asr-shim 的 auto / 0.6B / 1.7B),每份带设置页要显示的 label;没列就只有 provides.model 那一份。
    if (asr) for (const m of (Array.isArray(asr.models) && asr.models.length ? asr.models : [{ id: asr.model, label: asr.model }])) models.push({ id: m.id, label: m.label || m.id, caps: ['asr'] });
    const streamHit = stream ? models.find(m => m.id === stream.model) : null;
    if (stream && !streamHit) models.push({ id: stream.model, label: stream.model, caps: ['asr-stream'] });
    else if (streamHit) streamHit.caps.push('asr-stream');
    out.push({
      componentId: c.id,
      asrModel: asr ? asr.model : '',
      streamModel: stream ? stream.model : '',
      provider: {
        id: toolboxProviderId(c.id), label: c.name, baseUrl: base, apiKey: '', model: (asr || stream).model, models,
        ...(asr && asr.protocol === 'chat-audio' ? { asrProtocol: 'chat-audio' } : {}),
      },
    });
  }
  return out;
}
async function syncToolboxProviders() {
  return mutateConfig(current => {
    const desired = toolboxDesiredProviders(current);
    const wanted = new Map(desired.map(d => [d.provider.id, d.provider]));
    let changed = false;
    const providers = [];
    for (const p of (Array.isArray(current.providers) ? current.providers : [])) {
      if (!p || !String(p.id || '').startsWith('toolbox-')) { providers.push(p); continue; }
      const want = wanted.get(p.id);
      if (!want) { changed = true; continue; }   // 组件被停用／卸载 → 条目跟着撤(01 的归一化会把指向它的语音识别选择一并清空)
      wanted.delete(p.id);
      const sameModels = JSON.stringify(Array.isArray(p.models) ? p.models : []) === JSON.stringify(want.models);
      if (p.baseUrl !== want.baseUrl || p.label !== want.label || !sameModels || (p.asrProtocol || '') !== (want.asrProtocol || '')) {
        const next = { ...p, label: want.label, baseUrl: want.baseUrl, model: want.model, models: want.models };
        if (want.asrProtocol) next.asrProtocol = want.asrProtocol; else delete next.asrProtocol;
        providers.push(next); changed = true;
      } else providers.push(p);
    }
    // 这一趟【补回】的条目:配置里本来没有它。两种来路 —— 组件刚被重新启用(04f 自己在停用时撤的),或条目被别的
    // 什么弄丢了(2026-09-21 真机:设置页整份保存把它撤掉,13 现已挡住这条路)。两种都不是「用户换走／关掉了语音识别」
    // (那种情况条目还在、只是选择为空,C1 那条),所以下面的自动选中对它们再做一次 —— 否则用户停用再启用之后
    // 语音输入就没了,得自己去设置里再选一次。
    const readded = new Set([...wanted.keys()]);
    for (const want of wanted.values()) { providers.push(want); changed = true; }
    const tb = current.toolbox || { autoDiscover: true, disabled: [], seen: [] };
    const seen = new Set(Array.isArray(tb.seen) ? tb.seen : []);
    let asrProviderId = String(current.asrProviderId || ''), asrModel = String(current.asrModel || '');
    let asrStreamProviderId = String(current.asrStreamProviderId || ''), asrStreamModel = String(current.asrStreamModel || '');
    for (const d of desired) {
      if (seen.has(d.componentId) && !readded.has(d.provider.id)) continue;
      if (!seen.has(d.componentId)) { seen.add(d.componentId); changed = true; }
      if (d.asrModel && !asrProviderId && !asrModel) {
        asrProviderId = d.provider.id; asrModel = d.asrModel;
        logEvent({ kind: 'toolbox_service', action: 'asr-auto-select', id: d.componentId, model: asrModel });
      }
      if (d.streamModel && !asrStreamProviderId && !asrStreamModel) {
        asrStreamProviderId = d.provider.id; asrStreamModel = d.streamModel;
        logEvent({ kind: 'toolbox_service', action: 'asr-stream-auto-select', id: d.componentId, model: asrStreamModel });
      }
    }
    // 131(2026-09-21 真机):组件把【自己的】模型名改了(asr-shim 登记成 auto 后 provides.model 从 qwen3-asr-0.6b 变成 qwen3-asr-auto),
    // 用户选的仍是这个服务商 → 模型名跟着走。这不是「用户换走」(服务商 id 没变),不跟的话设置页那一格会显示成「不启用」、
    // 而实际转写还在打旧名字。只在「选的是这家、而它现在的清单里没有那个名字」时才动。
    for (const d of desired) {
      const has = (id, cap) => (d.provider.models || []).some(m => m && m.id === id && Array.isArray(m.caps) && m.caps.includes(cap));
      if (asrProviderId === d.provider.id && d.asrModel && asrModel && !has(asrModel, 'asr')) {
        logEvent({ kind: 'toolbox_service', action: 'asr-model-follow', id: d.componentId, from: asrModel, to: d.asrModel });
        asrModel = d.asrModel; changed = true;
      }
      if (asrStreamProviderId === d.provider.id && d.streamModel && asrStreamModel && !has(asrStreamModel, 'asr-stream')) {
        logEvent({ kind: 'toolbox_service', action: 'asr-stream-model-follow', id: d.componentId, from: asrStreamModel, to: d.streamModel });
        asrStreamModel = d.streamModel; changed = true;
      }
    }
    if (!changed) return { abort: 'unchanged' };
    return { next: { ...current, providers, asrProviderId, asrModel, asrStreamProviderId, asrStreamModel, toolbox: { ...tb, seen: [...seen] } } };
  });
}

// 对账:该起的起、该停的停、配置跟上。启动时调一次,全局配置保存之后再调一次(设置页里停用／启用某个组件)。
let toolboxReconcileChain = Promise.resolve();
function reconcileToolbox() {
  const run = toolboxReconcileChain.then(async () => {
    const config = await readConfig();
    invalidateToolboxCache();
    const enabled = enabledToolboxComponents(config).filter(c => c.kind === 'service');
    const keep = new Set(enabled.map(c => c.id));
    for (const [id, entry] of toolboxServices) {
      if (!keep.has(id) && entry.state !== 'stopped') stopToolboxService(id);
    }
    await Promise.all(enabled.map(c => startToolboxService(c).catch(() => null)));
    await syncToolboxProviders().catch(err => { logEvent({ kind: 'toolbox_service', action: 'config-sync-failed', error: String(err && err.message || err).slice(0, 200) }); });
  });
  toolboxReconcileChain = run.catch(() => {});
  return run;
}

// 转写之前:语音识别指着的是 toolbox 组件、而它这会儿没在跑(崩了／上次没起来)→ 就地再起一次,而不是让用户去重启如意。
async function ensureToolboxServiceForProvider(providerId) {
  const id = String(providerId || '');
  if (!id.startsWith('toolbox-')) return;
  const config = await readConfig();
  const component = enabledToolboxComponents(config).find(c => c.kind === 'service' && toolboxProviderId(c.id) === id);
  if (!component) return;
  const before = toolboxServices.get(component.id);
  if (before && before.state === 'failed' && before.failures > 0 && Date.now() - (before.failedAt || 0) < toolboxRetryCooldownMs(before.failures)) return;
  const portBefore = before ? before.port : component.service.port;
  const entry = await startToolboxService(component).catch(() => null);
  if (entry && entry.state === 'running' && entry.port !== portBefore) await syncToolboxProviders().catch(() => {});
}

// 133(用户 2026-09-21「如果语音识别切换剔掉了大模型,那么立马把模型从显存里卸载」):整段识别的选择从某个 toolbox 组件
// 换走(换成别的服务商／换成它的另一份模型／关掉)→ 立刻 POST 它登记的 service.unload。只打【原来选的】那个组件;
// 换成同一组件的另一份模型也打(下一发请求会加载新的那份,旧的这会儿就该让出显存)。没登记 unload 路的组件不打。
// 出站只到 127.0.0.1:<它的端口>;5 秒超时;结果记审计日志,失败不抛(fire-and-forget,保存的回包不等它)。
function toolboxUnloadTargets(prev, next) {
  const out = [];
  const pid = String((prev && prev.asrProviderId) || ''), pm = String((prev && prev.asrModel) || '');
  if (!pid.startsWith('toolbox-') || !pm) return out;
  const nid = String((next && next.asrProviderId) || ''), nm = String((next && next.asrModel) || '');
  if (nid === pid && nm === pm) return out;
  out.push({ providerId: pid, from: pm, to: nid === pid ? nm : (nid ? nid + '/' + nm : '') });
  return out;
}
async function toolboxUnloadForProvider(providerId, why) {
  const id = String(providerId || '').replace(/^toolbox-/, '');
  const entry = toolboxServices.get(id);
  const unloadPath = entry && entry.component && entry.component.service ? String(entry.component.service.unload || '') : '';
  if (!entry || !unloadPath || entry.state !== 'running') return { skipped: !entry ? 'unknown' : (!unloadPath ? 'no-unload-path' : entry.state) };
  const url = 'http://127.0.0.1:' + entry.port + unloadPath;
  try {
    const res = await fetch(url, { method: 'POST', headers: { 'content-length': '0' }, signal: AbortSignal.timeout(5000) });
    const body = safeJsonParse((await res.text()).slice(0, 2048), null);
    const unloaded = Boolean(body && body.unloaded);
    logEvent({ kind: 'toolbox_service', action: 'unload', id, port: entry.port, status: res.status, unloaded, ...why });
    return { ok: res.ok, unloaded };
  } catch (err) {
    logEvent({ kind: 'toolbox_service', action: 'unload-failed', id, port: entry.port, error: String(err && err.message || err).slice(0, 200), ...why });
    return { ok: false, error: String(err && err.message || err).slice(0, 200) };
  }
}
async function onAsrSelectionChanged(prev, next) {
  for (const t of toolboxUnloadTargets(prev, next)) await toolboxUnloadForProvider(t.providerId, { from: t.from, to: t.to });
}

// 133f(用户 2026-09-21「标准/重度第一次又卡又不准」):语音识别开录之前问一声「这个组件的模型这会儿装着没有」。
// 只读它登记的 service.health(与探活同款:只到 127.0.0.1:<端口>、1.5 秒超时、体只取前 4 KB)。回 { running, body }:
// running=false 表示组件没在跑(调用方先 ensureForProvider);body 是 /health 的 JSON,拿不到／不是对象就是 null。
// asr-shim 的 /health 带 loaded／resolvedModel,且【不触发加载】;别的组件没这些字段也没关系,调用方按「拿不准」走真转写。
async function toolboxHealthForProvider(providerId) {
  const id = String(providerId || '').replace(/^toolbox-/, '');
  const entry = toolboxServices.get(id);
  const svc = entry && entry.component && entry.component.service;
  if (!entry || entry.state !== 'running' || !svc) return { running: false, body: null };
  try {
    const res = await fetch('http://127.0.0.1:' + entry.port + svc.health, { signal: AbortSignal.timeout(TOOLBOX_PROBE_TIMEOUT_MS) });
    const body = safeJsonParse((await res.text()).slice(0, 4096), null);
    return { running: true, body: res.ok && body && typeof body === 'object' && !Array.isArray(body) ? body : null };
  } catch { return { running: true, body: null }; }
}

// /api/status 用的只读视图:设置页据此画「扩展组件」一栏。命令只给文件名(不给全路径、不给参数、不给 env)。
function toolboxStatusView(config) {
  const tb = (config && config.toolbox) || {};
  const disabled = new Set(Array.isArray(tb.disabled) ? tb.disabled : []);
  const components = scanToolboxComponents().map(c => {
    const entry = toolboxServices.get(c.id);
    const off = tb.autoDiscover === false || disabled.has(c.id);
    return {
      id: c.id, kind: c.kind, name: c.name, version: c.version, enabled: !off,
      provides: c.kind === 'service' ? c.provides.map(p => p.type) : ['mcp'],
      state: off ? 'disabled' : (c.kind === 'mcp' ? 'registered' : (entry ? entry.state : 'idle')),
      ...(c.kind === 'service' ? { port: entry ? entry.port : c.service.port, owned: Boolean(entry && entry.owned) } : {}),
      ...(entry && entry.error ? { error: entry.error, stderrTail: redact(entry.stderrTail).slice(-600) } : {}),
    };
  });
  return { autoDiscover: tb.autoDiscover !== false, components };
}
// 消费点经 04 的 ToolboxHooks 调进来(见那里的头注:本模块零入边)。
ToolboxHooks.reconcile = reconcileToolbox;
ToolboxHooks.stopAllSync = stopAllToolboxServicesSync;
ToolboxHooks.ensureForProvider = ensureToolboxServiceForProvider;
ToolboxHooks.statusView = toolboxStatusView;
ToolboxHooks.asrSelectionChanged = onAsrSelectionChanged;
ToolboxHooks.healthForProvider = toolboxHealthForProvider;
