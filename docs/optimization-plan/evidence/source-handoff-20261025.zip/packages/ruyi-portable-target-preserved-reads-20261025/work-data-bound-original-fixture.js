'use strict';
// Test-only real crypto/owner fixture; all native calls are explicit simulations.
const assert=require('node:assert/strict'),fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),vm=require('node:vm');
const {portableFixture,hash}=require('./work-data-portable-fixture');
async function boundOriginalFixture(t,{historicalLive=false}={}){
 const f=await portableFixture(t);f.special.fx.store.Hooks.keys=f.keys;f.special.state.enabled=true;
 f.special.native.createOwnedPortable=async({root,snapshot,revision})=>{assert.equal(fs.existsSync(root),false);for(const entry of [...snapshot.entries].sort((a,b)=>a.rel.length-b.rel.length)){const file=entry.rel?path.join(root,...entry.rel.split('/')):root;if(entry.dir)await fsp.mkdir(file);else await fsp.writeFile(file,Buffer.from(entry.streams.find(row=>row.name==='').data,'base64'),{flag:'wx'});const nativeId=f.special.nativeId(file);f.special.metadata.set(nativeId,{attrs:entry.attrs,times:[...entry.times],shortName:entry.shortName});f.special.streams.set(nativeId,new Map(entry.streams.filter(row=>row.name!=='').map(row=>[row.name,Buffer.from(row.data,'base64')])));}return f.special.native.capture(root,revision);};
 const id='Tool_One',stamp='2026-10-24T00-00-00-000Z',live=path.join(f.selected.root,'skills',id),backup=path.join(f.base,'.work-data','skill-backups','objects-v1',stamp,id),original=path.join(f.root,'stable-original');
 await fsp.mkdir(live,{recursive:true});await fsp.writeFile(path.join(live,'SKILL.md'),'STABLE REPLACEMENT');await fsp.mkdir(original);await fsp.writeFile(path.join(original,'SKILL.md'),'STABLE ORIGINAL');
 const revision='5'.repeat(64),snapshot=await f.special.native.capture(original,revision),liveSnapshot=await f.special.native.capture(live,revision),descriptor=f.special.api.migrationCapsuleDescriptor(backup);
 await fsp.mkdir(path.join(backup,'objects'),{recursive:true});await fsp.writeFile(path.join(backup,'.ruyi-capsule-v1'),'\u007b"version":1}');await f.special.api.migrationCapsuleArchive(descriptor).write(require('node:zlib').gzipSync(Buffer.from(JSON.stringify(snapshot))));
 let physicalTree=liveSnapshot;
 if(historicalLive){const prior=path.join(f.root,'prior-live');await fsp.mkdir(prior);await fsp.writeFile(path.join(prior,'SKILL.md'),'STABLE REPLACEMENT');physicalTree=await f.special.native.capture(prior,revision);}
 const physical={schema:1,id,stamp,revision,phase:'published',oldRoot:snapshot.entries[0].id,newTree:f.special.api.migrationCapsuleFingerprint(physicalTree),sourceStage:'.ruyi-copy-'+id+'-'+stamp};
 await f.special.api.migrationCapsuleWriteIntent(descriptor,physical);await f.special.native.seal({root:original,container:path.join(backup,'objects'),snapshot});
 const scope='skill-backup-owner:'+hash(vm.runInContext('samePathKey',f.special.context)(f.base)).slice(0,32),bindingFile=path.join(f.selected.root,'migrations','skill-backup-bindings-v2.sealed'),store=f.fx.store.createText({file:()=>bindingFile,purpose:'backup',schema:1,scopeId:scope,recordId:'bindings:'+f.selected.id,keys:f.keys,chunked:true,maxPlaintextBytes:256*1024*1024,enabled:()=>true,writeJson:f.fx.atomicWriteJson});
 const binding=JSON.parse(await store.read()),ref=f.owner.ref(stamp,id,binding.storeId),newTree=f.special.api.migrationCapsuleFingerprint(liveSnapshot),entry={ref,physicalSkillId:id,phase:'published',archiveSha:hash(await fsp.readFile(path.join(backup,'archive'))),intentSha:hash(await fsp.readFile(path.join(backup,'intent'))),sourceGenerationId:null,eligibility:'eligible',newTree},variantFile=path.join(f.base,'.work-data','skill-backups','intents',f.selected.id,ref.backupId+'.sealed');
 const variantDescriptor={...descriptor,generationId:f.selected.id,intentFile:variantFile,intentRecordId:descriptor.recordId+':intent:'+f.selected.id,intentKeys:f.keys};
 async function writeBinding(){await store.write(JSON.stringify(binding));}
 async function writeVariant(value={...physical,newTree,generationId:f.selected.id}){await fsp.mkdir(path.dirname(variantFile),{recursive:true});await f.special.api.migrationCapsuleWriteIntent(variantDescriptor,value);}
 async function bind(){binding.entries.push(entry);await writeBinding();await writeVariant();}
 const relative='.work-data/generations/'+f.selected.id+'/migrations/'+stamp+'.json',codec=f.api.WorkDataMigrationCodecs.describe('migrations/'+stamp+'.json'),log={schema:1,id:stamp,files:[{kind:'skill-copy',file:live,backup,items:[{id,copyTreeHash:'capsule intent guards live identity'}]}]};
 await f.fx.store.createText({...codec,maxPlaintextBytes:8*1024*1024,file:()=>path.join(f.base,...relative.split('/')),keys:f.keys,enabled:()=>true,writeJson:f.fx.atomicWriteJson}).write(JSON.stringify(log,null,2)+'\n');
 await fsp.unlink(path.join(f.base,'.work-data','maintenance-v1.json'));
 return{...f,id,stamp,live,backup,descriptor,snapshot,liveSnapshot,physical,entry,binding,ref,variantFile,variantDescriptor,newTree,writeBinding,writeVariant,bind,relative,codec};
}
async function captureDecoded(f){const {captured,request}=await f.capture();try{const portable=await f.owner.capturePortable(request);try{return JSON.parse(portable.data);}finally{portable.release();}}finally{captured.release();}}
async function advanceBoundGeneration(f){
 const expected=await f.manifest.readActive(),candidate=await f.manifest.prepare({expected,mode:'encrypted'}),live=path.join(candidate.root,'skills',f.id);await fsp.mkdir(live,{recursive:true});
 // Explicit business-file copies in this fixture. Original capsule objects are
 // never copied: prepareBindings retains them through the actual stable owner.
 for(const name of ['config.json','work-data-key-v1.json'])await fsp.writeFile(path.join(candidate.root,name),await fsp.readFile(path.join(expected.root,name)),{flag:'wx'});
 await fsp.writeFile(path.join(live,'SKILL.md'),await fsp.readFile(path.join(expected.root,'skills',f.id,'SKILL.md')),{flag:'wx'});
 const token=await f.owner.prepare({expected,candidate});assert.equal((await f.owner.prepareBindings(token)).ready,true);const selected=await f.manifest.commit({expected,candidate});await f.owner.activate();return selected;
}
module.exports={boundOriginalFixture,captureDecoded,advanceBoundGeneration};
