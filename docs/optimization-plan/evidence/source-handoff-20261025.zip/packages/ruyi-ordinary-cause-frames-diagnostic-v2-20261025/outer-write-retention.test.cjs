'use strict';
const{test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),p=require('node:path'),vm=require('node:vm'),{EventEmitter}=require('node:events'),{functionBlock}=require('E:/Claude/worktrees/steward-3x-implementation/dev-harness/lib/source-slice'),source=fs.readFileSync(p.join(__dirname,'run-native-flush-probe.cjs'),'utf8');
for(const key of ['ownershipRetained','helperMayStillRun'])for(const at of [1,2,3])test('outer '+key+' survives evidence write '+at+' failure',async()=>{
 const x=new EventEmitter();Object.assign(x,{pid:23456});x.stdout=new EventEmitter();x.stderr=new EventEmitter();const fault=Object.assign(Error('synthetic write'),{code:'fixture.write_failure'});let writes=0;
 const context={assert:a,process:{platform:'win32',argv:['node','model','--native-owned-temp'],execPath:'model',env:{}},hash:file=>file==='driver'?'d':file==='support'?'s':'r',driver:'driver',support:'support',PINS:{driver:'d',support:'s',runtime:'r',runtimeSha256:'r'},cp:{spawn:()=>{queueMicrotask(()=>{x.stderr.emit('data',Buffer.from(JSON.stringify({failed:true,causeChain:[{[key]:true}]})+'\n'));x.emit('exit',0,null);x.emit('close',0,null);});return x;}},killOwnTree:()=>({killed:[23456]}),setTimeout:()=>({}),clearTimeout(){},fs:{writeFileSync(){if(++writes===at)throw fault;}},p,D:'C:/synthetic',console:{log(){}},Promise};
 const main=vm.runInNewContext(functionBlock(source,'main')+';main;',context);let caught;try{await main();}catch(error){caught=error;}a.ok(caught);a.equal(caught.cause,fault);a.equal(caught.ownershipRetained,true);a.equal(caught.helperMayStillRun,key==='helperMayStillRun');
});
test('outer final stderr emits both already-latched flags',()=>{
 const tail=source.match(/main\(\)\.catch\((error=>[\s\S]*)\);\s*$/)[1],records=[];const fail=vm.runInNewContext('('+tail+')',{console:{error:value=>records.push(JSON.parse(value))},process:{}});
 fail({code:'fixture.retained',helperMayStillRun:false,ownershipRetained:true});a.equal(records[0].ownershipRetained,true);a.equal(records[0].helperMayStillRun,false);
});
