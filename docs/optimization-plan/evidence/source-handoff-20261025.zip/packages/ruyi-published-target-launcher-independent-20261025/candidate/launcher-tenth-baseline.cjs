'use strict';
// ROOT serial outer harness. Only root-owned synthetic fixture trees are stopped.
const fs=require('node:fs'),p=require('node:path'),os=require('node:os'),c=require('node:crypto'),cp=require('node:child_process'),assert=require('node:assert/strict');
const {killOwnTree}=require('E:/Claude/worktrees/steward-3x-implementation/dev-harness/lib/kill-own-tree');
const B=__dirname,driver=p.join(B,'published-originals-package.e2e.cjs'),runtime=p.join(B,'runtime/app/server.js'),composition=p.join(B,'composition-identity.json'),hash=file=>c.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
async function main(){
 assert.equal(process.platform,'win32');assert.ok(process.argv.includes('--native-owned-temp'));
 assert.equal(hash(driver),'e19fffc8912fd196fe506e237b1da5eea037dbc7f44f23b9a2b3228f36e63629');assert.equal(hash(runtime),'c412bfdb610b48a48a531d52f8f545f60d3dd50d7f26aea31b7f04c89fb72b9f');assert.equal(hash(composition),'cbca9c11e6a7c96c4f1bc020b310679d5fb07998d3bc56ad2f237122a0d9188f');
 let out='',err='',timedOut=false,failureCleanup=false,outputExceeded=false,exited=false,exitCode,exitSignal;
 const child=cp.spawn(process.execPath,[driver,'--native-owned-temp'],{env:{...process.env,RUYI_TEST_SERVER_JS:runtime},cwd:'E:/Claude/worktrees/steward-3x-implementation',windowsHide:true,stdio:['ignore','pipe','pipe']});let cleanup;
 function terminate(){if(!cleanup)cleanup=killOwnTree(child);return cleanup;}
 function collect(name,bytes){if(outputExceeded)return;const value=String(bytes),current=name==='out'?out:err,remaining=1024*1024-current.length,next=current+value.slice(0,Math.max(remaining,0));if(name==='out')out=next;else err=next;if(value.length>remaining){outputExceeded=true;void terminate();return;}if(err.split(/\r?\n/).some(row=>row.startsWith('{"failed":true,'))&&!failureCleanup){failureCleanup=true;void terminate();}}
 child.stdout.on('data',bytes=>collect('out',bytes));child.stderr.on('data',bytes=>collect('err',bytes));child.on('exit',(code,signal)=>{exited=true;exitCode=code;exitSignal=signal;});
 const timer=setTimeout(()=>{timedOut=true;void terminate();},900000);let closed;
 try{closed=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({closed:true,code,signal}));});}finally{clearTimeout(timer);await terminate();}
 fs.writeFileSync(p.join(B,'published-native-tenth.stdout.log'),out);fs.writeFileSync(p.join(B,'published-native-tenth.stderr.log'),err);
 const result={schema:1,pid:child.pid,exited,exitCode,exitSignal,...closed,timedOut,failureCleanup,outputExceeded,driverSha256:hash(driver),runtimeSha256:hash(runtime),compositionSha256:hash(composition)};fs.writeFileSync(p.join(B,'published-native-tenth.process.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
 assert.equal(exited,true);assert.equal(closed.closed,true);assert.equal(timedOut,false);assert.equal(failureCleanup,false,'failure cleanup can never pass');assert.equal(outputExceeded,false);assert.equal(closed.code,0,err+'\n'+out);
 const receipt=out.split(/\r?\n/).filter(line=>line.startsWith('{')).map(line=>JSON.parse(line)).find(value=>value.pass===true);assert.ok(receipt);assert.equal(receipt.runtimeSha256,hash(runtime));assert.equal(p.dirname(receipt.root),p.resolve(os.tmpdir()));assert.match(p.basename(receipt.root),/^ruyi-published-originals-package-/);
 const roles=['enabled','published','restored','cold','undo','repeated','sourceCheck'];assert.equal(new Set(roles.map(name=>receipt[name].pid)).size,7);
 assert.equal(receipt.mainRoleCount,8);assert.equal(new Set([...roles,'typedHistory'].map(name=>receipt[name].pid)).size,8);
 assert.equal(receipt.typedHistory.actualTypedHistoryProducer,true);assert.equal(receipt.typedHistory.actualAdoptionMove,true);assert.equal(receipt.typedHistory.producerRootRetained,true);assert.equal(receipt.typedHistory.phase,'complete');
 for(const name of [...roles,'typedHistory']){const role=receipt[name];assert.equal(role.pass,true);assert.equal(role.nativeCSharpSha256,'45859a591ef419e93250656319c92b2ab3e773bbcd23cd59edb65e104e65595f');assert.ok(role.helpers.every(row=>row.exit&&row.close&&row.code===0&&row.closeCode===0));}
 const processRecords=[];for(const name of ['enable','typed-history-producer','publish','export-restore','cold-target','cold-undo','cold-repeat','source-check','cold-rehearsal']){const record=JSON.parse(fs.readFileSync(p.join(receipt.root,name+'.process.json')));processRecords.push(record);assert.equal(record.exited,true);assert.equal(record.closed,true);assert.equal(record.exitCode,0);assert.equal(record.code,0);for(const flag of ['timedOut','overflow','fatalReceived','pipeFailed','processFailed','cleanupFailed','helperMayStillRun','ownershipRetained'])assert.equal(record[flag],false);}
 assert.equal(new Set(processRecords.map(row=>row.pid)).size,9);assert.ok(processRecords.every(row=>Number.isSafeInteger(row.pid)&&row.pid>0));
 console.log(JSON.stringify(receipt));
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
