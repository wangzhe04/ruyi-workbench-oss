'use strict';
const Module=require('node:module'),load=Module._load;
const deny=()=>{throw Object.assign(Error('fixture.native_or_socket_forbidden'),{code:'fixture.native_or_socket_forbidden'});};
const repo='E:/Claude/worktrees/steward-3x-implementation';Object.assign(process.env,require(repo+'/dev-harness/lib/fixture-home').fixtureChildEnv({perTest:true}).env);
const blocked={child_process:['spawn','spawnSync','fork','exec','execSync','execFile','execFileSync'],net:['createServer','createConnection','connect','Socket','Server'],tls:['createServer','connect','TLSSocket','Server'],http:['createServer','request','get','Server'],https:['createServer','request','get','Server'],http2:['createServer','createSecureServer','connect'],dgram:['createSocket','Socket'],cluster:['fork']};
Module._load=function(name,...args){const key=String(name).replace(/^node:/,'');if(key==='worker_threads'){const actual=load.call(this,name,...args);return{...actual,Worker:class{constructor(){deny();}}};}if(Object.hasOwn(blocked,key)){const actual=load.call(this,name,...args),facade={...actual};for(const property of blocked[key])facade[property]=deny;return facade;}return load.call(this,name,...args);};
