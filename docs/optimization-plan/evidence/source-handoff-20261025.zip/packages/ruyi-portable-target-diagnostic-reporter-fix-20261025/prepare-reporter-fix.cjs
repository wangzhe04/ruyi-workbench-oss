'use strict';
const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict'),c=require('node:crypto');const prior='C:/Users/87179/AppData/Local/Temp/ruyi-portable-target-diagnostic-source-20261025',root=__dirname,hash=b=>c.createHash('sha256').update(b).digest('hex');
const identity=JSON.parse(fs.readFileSync(p.join(prior,'identity.json')));a.equal(hash(fs.readFileSync(p.join(prior,'identity.json'))),'6dd79531130e7020107c302c5fc54d229c3b53c6d84a3b1ddde2063f10aa6c8b');
for(const row of identity.inventory){const b=fs.readFileSync(p.join(prior,row.path));a.equal(hash(b),row.sha256);fs.writeFileSync(p.join(root,row.path),b);}fs.copyFileSync(p.join(prior,'identity.json'),p.join(root,'prior-identity.json'));
let driver=fs.readFileSync(p.join(root,'published-originals-package.e2e.cjs'),'utf8');const start=driver.indexOf('function typedCauses(error){'),end=driver.indexOf('function systemEnvironment',start);const before=driver.slice(start,end);
const after=`function typedCauses(error){
 const values=[],seen=new Set();
 function diagnosticData(input,depth,budget){
  if(++budget.nodes>2048||depth>16)throw Error('diagnostic_bound');
  if(input===null||typeof input==='boolean'||typeof input==='number'&&Number.isFinite(input))return input;
  if(typeof input==='string'){budget.chars+=input.length;if(input.length>4096||budget.chars>20000)throw Error('diagnostic_bound');return input;}
  if(!input||typeof input!=='object')throw Error('diagnostic_kind');
  const descriptors=Object.getOwnPropertyDescriptors(input),keys=Object.keys(descriptors).filter(key=>descriptors[key].enumerable),output=Array.isArray(input)?[]:Object.create(null);
  if(keys.length>128||Array.isArray(input)&&(!Number.isSafeInteger(descriptors.length?.value)||descriptors.length.value>128))throw Error('diagnostic_bound');
  for(const key of keys){const descriptor=descriptors[key];budget.chars+=key.length;if(key.length>128||budget.chars>20000||!Object.hasOwn(descriptor,'value'))throw Error('diagnostic_accessor');Object.defineProperty(output,key,{enumerable:true,configurable:true,writable:true,value:diagnosticData(descriptor.value,depth+1,budget)});}
  return output;
 }
 for(let value=error;value&&typeof value==='object'&&!seen.has(value)&&values.length<8;value=value.cause){
  seen.add(value);let code=null;try{if(/^[A-Za-z0-9_.-]{1,128}$/.test(value.code||''))code=value.code;}catch{}
  const record={code,helperMayStillRun:value.helperMayStillRun===true,ownershipRetained:value.ownershipRetained===true,targetRetained:value.targetRetained===true,retry:value.retry===false?false:null};
  let portableDiagnostic=null,frames=[];
  try{const selected=Object.getOwnPropertyDescriptor(value,'portableDiagnostic');if(selected&&Object.hasOwn(selected,'value')&&selected.value&&typeof selected.value==='object'){const candidate=diagnosticData(selected.value,0,{nodes:0,chars:0});if(candidate.schema===1&&typeof candidate.check==='string'&&/^[a-z0-9.-]{1,96}$/.test(candidate.check)){const diagnosticJson=JSON.stringify(candidate);if(diagnosticJson.length<=24576)portableDiagnostic=JSON.parse(diagnosticJson);}}}catch{}
  try{const selected=value.stack;if(typeof selected==='string')frames=selected.slice(0,16384).split(/\\r?\\n/).filter(row=>/^\\s+at /.test(row)).slice(0,8).map(row=>row.slice(0,2048));}catch{}
  values.push({...record,portableDiagnostic,frames});
 }
 return values;
}
`;
a.equal(driver.split(before).length-1,1);driver=driver.replace(before,after);fs.writeFileSync(p.join(root,'published-originals-package.e2e.cjs'),driver);fs.writeFileSync(p.join(root,'reporter-fix-span.json'),JSON.stringify({before,after},null,2)+'\n');
fs.copyFileSync('C:/Users/87179/AppData/Local/Temp/ruyi-target-diagnostic-independent-context-20261025/reporter-noninterference.test.cjs',p.join(root,'reporter-noninterference.test.cjs'));
console.log(JSON.stringify({driverSha256:hash(driver),sourceSha256:hash(fs.readFileSync(p.join(root,'13u-migration-center.js')))}));
