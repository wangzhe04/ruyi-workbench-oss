'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),assert=require('node:assert/strict');
const sourcePath='C:/Users/87179/AppData/Local/Temp/codex-ruyi-current118-durability-run-20261025/runtime/app/src/13u-migration-center.js';
const driverPath='C:/Users/87179/AppData/Local/Temp/ruyi-published-full-hash-retention-fix-20261025/published-originals-package.e2e.cjs';
const hash=b=>c.createHash('sha256').update(b).digest('hex');
let source=fs.readFileSync(sourcePath,'utf8'),driver=fs.readFileSync(driverPath,'utf8');
assert.equal(hash(source),'ee359b5d8d843c5c8c237213e7b43b9264f1c0b59adc47caad34f34e4d490c9e');assert.equal(hash(driver),'5f3e43e05eda4432bbc6136af01ed0af21de8865d203b4b084b02eaa6045d53c');
fs.writeFileSync(p.join(__dirname,'13u-baseline.js'),source);fs.writeFileSync(p.join(__dirname,'driver-baseline.cjs'),driver);
const spans=[];function swap(before,after){assert.equal(source.split(before).length-1,1);source=source.replace(before,after);spans.push({before,after});}
const helpers=`  // Diagnostic-only: runs after an unchanged refusal predicate, using existing memory.
  function portableTargetSnapshotDelta(actual,expected){
    const limited=value=>typeof value==='string'&&value.length>1024?value.slice(0,1024)+'[truncated]':value;
    const a=new Map(actual.entries.map(row=>[row.rel,row])),e=new Map(expected.entries.map(row=>[row.rel,row])),deltas=[];let changedEntries=0;
    for(const rel of new Set([...e.keys(),...a.keys()])){const old=e.get(rel),now=a.get(rel),fields={};
      if(!old||!now)fields.membership={expected:!!old,actual:!!now};else{
        for(const key of ['id','dir','attrs','shortName','times'])if(JSON.stringify(old[key])!==JSON.stringify(now[key]))fields[key]={expected:old[key],actual:now[key]};
        const oldStreams=new Map(old.streams.map(row=>[row.name,row])),newStreams=new Map(now.streams.map(row=>[row.name,row])),streams=[];let changedStreams=0;
        for(const name of new Set([...oldStreams.keys(),...newStreams.keys()])){const before=oldStreams.get(name),after=newStreams.get(name),streamFields={};if(!before||!after)streamFields.membership={expected:!!before,actual:!!after};else{for(const key of ['size','hash'])if(before[key]!==after[key])streamFields[key]={expected:before[key],actual:after[key]};if(before.data!==after.data)streamFields.dataDifferent=true;}
          if(Object.keys(streamFields).length){changedStreams++;if(streams.length<4)streams.push({name:limited(name),fields:streamFields});}}
        if(changedStreams)fields.streams={changedStreams,shown:streams.length,entries:streams};
      }
      if(Object.keys(fields).length){changedEntries++;if(deltas.length<8)deltas.push({rel:limited(rel),fields});}
    }
    return{revision:{expected:expected.revision,actual:actual.revision},count:{expected:expected.entries.length,actual:actual.entries.length},changedEntries,shown:deltas.length,entries:deltas};
  }
  function portableTargetFailure(check,details){
    try{migrationCapsuleFail('portable_target_changed');}catch(error){
      try{const diagnostic={schema:1,check,...details()};const diagnosticJson=JSON.stringify(diagnostic);error.portableDiagnostic=diagnosticJson.length<=24576?JSON.parse(diagnosticJson):{schema:1,check,detailTruncated:true};}
      catch{try{error.portableDiagnostic={schema:1,check,diagnosticUnavailable:true};}catch{}}
      throw error;
    }
  }
`;
swap('  async function verifyPortableOriginals(owned){',helpers+'  async function verifyPortableOriginals(owned){');
swap("if(info.id!==expected.entries.find(entry=>entry.rel==='').id||info.volume!==proof.volume)migrationCapsuleFail('portable_target_changed');", "if(info.id!==expected.entries.find(entry=>entry.rel==='').id||info.volume!==proof.volume)portableTargetFailure('inherited.identity',()=>({path:name,expected:{id:expected.entries.find(entry=>entry.rel==='').id,volume:proof.volume},actual:{id:info.id,volume:info.volume}}));");
swap("if(!portableProofExact(actual,expected))migrationCapsuleFail('portable_target_changed');", "if(!portableProofExact(actual,expected))portableTargetFailure('inherited.snapshot',()=>({path:name,delta:portableTargetSnapshotDelta(actual,expected)}));");
swap("if(String(root.dev)!==owned.targetIdentity.dev||String(root.ino)!==owned.targetIdentity.ino)migrationCapsuleFail('portable_target_changed');", "if(String(root.dev)!==owned.targetIdentity.dev||String(root.ino)!==owned.targetIdentity.ino)portableTargetFailure('originals.verify.root-identity',()=>({expected:owned.targetIdentity,actual:{dev:String(root.dev),ino:String(root.ino)}}));");
swap("if(info.id!==move.info.id||info.volume!==move.info.volume||!migrationCapsuleSameMetadata(snapshot,move.snapshot))migrationCapsuleFail('portable_target_changed');", "if(info.id!==move.info.id||info.volume!==move.info.volume||!migrationCapsuleSameMetadata(snapshot,move.snapshot))portableTargetFailure('originals.verify.move',()=>({path:move.path,expected:{id:move.info.id,volume:move.info.volume},actual:{id:info.id,volume:info.volume},delta:portableTargetSnapshotDelta(snapshot,move.snapshot)}));");
swap("if(await fileHash(path.join(owned.target,...row.path.split('/')))!==row.sha256||hash(row.data)!==row.sha256)migrationCapsuleFail('portable_target_changed');", "if(await fileHash(path.join(owned.target,...row.path.split('/')))!==row.sha256||hash(row.data)!==row.sha256)portableTargetFailure('originals.verify.replacement-sha256',()=>({path:row.path,expectedSha256:row.sha256,actualHashNotRetained:true}));");
swap("if(String(root.dev)!==targetIdentity.dev||String(root.ino)!==targetIdentity.ino)migrationCapsuleFail('portable_target_changed');", "if(String(root.dev)!==targetIdentity.dev||String(root.ino)!==targetIdentity.ino)portableTargetFailure('originals.install.root-identity',()=>({expected:targetIdentity,actual:{dev:String(root.dev),ino:String(root.ino)}}));");
let inverse=source;for(const span of [...spans].reverse()){assert.equal(inverse.split(span.after).length-1,1);inverse=inverse.replace(span.after,span.before);}assert.equal(inverse,fs.readFileSync(sourcePath,'utf8'));
fs.writeFileSync(p.join(__dirname,'13u-migration-center.js'),source);fs.writeFileSync(p.join(__dirname,'source-spans.json'),JSON.stringify(spans,null,2)+'\n');
const before='retry:value.retry===false?false:null});',after="retry:value.retry===false?false:null,portableDiagnostic:value.portableDiagnostic||null,frames:String(value.stack||'').split(/\\r?\\n/).filter(row=>/^\\s+at /.test(row)).slice(0,8)});";
assert.equal(driver.split(before).length-1,1);driver=driver.replace(before,after);assert.equal(driver.replace(after,before),fs.readFileSync(driverPath,'utf8'));
fs.writeFileSync(p.join(__dirname,'published-originals-package.e2e.cjs'),driver);fs.writeFileSync(p.join(__dirname,'driver-span.json'),JSON.stringify({before,after},null,2)+'\n');
for(const name of ['strict-pure-preload.cjs','strict-preload.cjs','strict-guard.test.cjs','complete-guard-contract.test.cjs'])fs.copyFileSync(p.join(p.dirname(driverPath),name),p.join(__dirname,name));
console.log(JSON.stringify({sourceSha256:hash(source),driverSha256:hash(driver),sourceSpans:spans.length}));

