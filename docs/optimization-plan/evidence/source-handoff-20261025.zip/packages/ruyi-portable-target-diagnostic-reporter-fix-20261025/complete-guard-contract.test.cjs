'use strict';
const {test}=require('node:test'),a=require('node:assert/strict');
test('raw review permanently denies native child sockets servers clusters and worker construction',()=>{
 const codes=new Set(['fixture.native_forbidden','fixture.socket_forbidden','fixture.native_or_socket_forbidden']);
 for(const [moduleName,names] of [
  ['node:child_process',['spawn','spawnSync','fork','exec','execSync','execFile','execFileSync']],
  ['node:net',['createServer','connect','createConnection','Socket','Server']],
  ['node:tls',['createServer','connect','TLSSocket','Server']],
  ['node:http',['createServer','request','get','Server']],
  ['node:https',['createServer','request','get','Server']],
  ['node:http2',['createServer','createSecureServer','connect']],
  ['node:dgram',['createSocket','Socket']],['node:cluster',['fork']]
 ])for(const name of names)a.throws(()=>require(moduleName)[name](),error=>codes.has(error.code),moduleName+'.'+name);
 a.throws(()=>new (require('node:worker_threads').Worker)(''),error=>codes.has(error.code));
});
