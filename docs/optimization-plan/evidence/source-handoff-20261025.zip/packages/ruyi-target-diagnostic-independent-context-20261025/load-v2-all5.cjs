'use strict';
const fs=require('node:fs'),p=require('node:path'),D=p.join(__dirname,'v2'),selection=JSON.parse(fs.readFileSync(p.join(D,'PURE-SELECTION.json'),'utf8'));
for(const file of selection.files)require(p.join(D,file));
console.log('REGISTERED_ALL5',selection.tests);
