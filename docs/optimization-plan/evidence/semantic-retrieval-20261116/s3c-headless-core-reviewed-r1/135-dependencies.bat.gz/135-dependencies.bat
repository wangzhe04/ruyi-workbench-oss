@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
for %%F in (C:\r31-native-headless-research\build-control\bin\*.dll C:\r31-native-headless-research\build-control\bin\*.exe C:\r31-native-headless-research\build-patched\bin\*.dll C:\r31-native-headless-research\build-patched\bin\*.exe) do (
  echo FILE %%F
  dumpbin /DEPENDENTS "%%F"
  if errorlevel 1 exit /b 1
)
