'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../..'),{fixture}=require(path.join(repo,'dev-harness/lib/fulltext-owned-producer-fixture'));
const file=path.join(repo,'ruyi-workbench/app/src/13ap-session-fulltext-index.js'),hash=()=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),before=hash();
(async()=>{const f=await fixture();try{
 for(let n=0;n<5;n++)await f.put('AWeak'+n,[{role:'user',id:'m',content:'cedar unrelated'}]);
 await f.put('ZStrong',[{role:'user',id:'m',content:'cedar '+ 'filler '.repeat(800)+'violet'}]);
 const semantic={score:async(_query,docs)=>({status:'ready',scores:docs.map(()=>.1),minScore:.34,coverage:{cached:docs.length,total:docs.length,complete:true},admission:{policyId:'synthetic-all-negative',status:'evaluated',purpose:'search-relevance',accepted:docs.map(()=>false)}})};
 const index=vm.runInNewContext('SessionFullTextIndex',f.hookContext).create({...f.host,resultUnit:'sessions',semantic});await index.step(16);
 const narrow=await index.search('cedar violet',null,1),wide=await index.search('cedar violet',null,20);
 const report={schemaVersion:1,status:narrow.results.some(row=>row.reference.sessionId==='ZStrong')&&wide.results.some(row=>row.reference.sessionId==='ZStrong')?'PASS_FILTER_PRECAP':'FAIL',sourceSha256:before,sourceStable:hash()===before,limit1:narrow.results.map(row=>row.reference.sessionId),limit20:wide.results.map(row=>row.reference.sessionId),limit1Admission:narrow.lexicalAdmission,fixture:'five fully scored negative weak sources sort before one verified same-field all-terms source spanning two windows; no acceptance data/model inference'};
 fs.writeFileSync(path.join(__dirname,'weak-lexical-cap-repro-r2.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));if(report.status!=='PASS_FILTER_PRECAP'||!report.sourceStable)process.exitCode=1;
 }finally{await f.close();}})().catch(error=>{console.error(error);process.exitCode=1;});
