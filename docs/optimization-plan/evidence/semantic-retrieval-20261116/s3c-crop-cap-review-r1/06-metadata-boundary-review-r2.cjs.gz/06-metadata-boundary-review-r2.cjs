'use strict';
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),vm=require('node:vm'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../..'),{fixture,actual}=require(path.join(repo,'dev-harness/lib/fulltext-consumer-fixture'));
const files=['13ap-session-fulltext-index.js','13as-session-fulltext-consumers.js','06ha-semantic-retrieval.js','02-session-store.js'].map(name=>path.join(repo,'ruyi-workbench/app/src',name)),hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),sources=files.map(file=>({file,sha256:hash(file)}));
const rows=[{role:'user',id:'m',turnSeq:1,content:'ordinary material'}],cases=[];
async function one(name,mode,mutation=null,heads={title:'cedar unrelated'}){
 const f=await fixture();let sunk=0,mutated=false;const texts=[];
 try{
  const api=vm.runInContext(actual('06ha-semantic-retrieval.js')+'\nSemanticRetrieval;',f.context);
  Object.assign(f.context,{SemanticRetrieval:api,SemanticRuntimeHooks:{prepare:async()=>mode==='unknown'?{available:false,reason:'unavailable'}:{available:true,modelId:'boundary-fake',modelFingerprint:'boundary-fake-v1',retrievalThresholds:{search:.44}},encode:async(input,options)=>{
   if(options.role==='document'&&mutation&&!mutated){mutated=true;await mutation(f);}
   await options.beforeEncode?.();if(options.role==='document'){sunk++;texts.push(...input);}
   if(options.role==='document'&&mode==='timeout')return{ok:false,reason:'timeout'};
   return{ok:true,modelFingerprint:'boundary-fake-v1',vectors:input.map(text=>options.role==='query'||text.includes('accepted')?[1,0]:[0,1]),...(options.role==='document'&&mode==='truncated'?{truncated:input.map(()=>true)}:{})};
  }}});
  await f.put('Synthetic',rows,{head:heads});
  if(mutation){let error;try{await f.model('cedar violet');}catch(value){error=value;}assert.ok(error&&/source_changed|destination_changed/.test(error.code),name+' rejects');assert.equal(sunk,0,'changed authority/source must not reach the encoder sink');cases.push({name,refused:error.code,documentSinks:sunk});}
  else{const value=await f.ui('cedar violet');if(['unknown','timeout','truncated'].includes(mode)){assert.ok(value.results.some(row=>row.id==='Synthetic'));assert.equal(value.lexicalAdmission.partial,true);}else{assert.equal(value.results.length,0);assert.ok(!texts.includes('accepted unrelated summary'),'unmatched metadata field must not be encoded or lent to matching title');}cases.push({name,results:value.results.map(row=>row.id),lexicalPartial:value.lexicalAdmission.partial,semantic:value.semantic,documentSinks:sunk});}
 }finally{if(path.dirname(path.resolve(f.directory))!==path.resolve(os.tmpdir())||!path.basename(f.directory).startsWith('ruyi-fulltext-unit-'))throw Error('unsafe fixture cleanup');await f.close();}
}
(async()=>{
 await one('unknown runtime preserves weak metadata as partial lexical','unknown');
 await one('document timeout preserves weak metadata as partial lexical','timeout');
 await one('truncated document is unscored and preserves partial lexical','truncated');
 await one('accepted unrelated field cannot lend score to matching title','ready',null,{title:'cedar unrelated',summary:'accepted unrelated summary'});
 await one('model cancellation before document sink','ready',async f=>f.controller.abort());
 await one('model owner replacement before document sink','ready',async f=>f.context.turnSettlers.set('Destination',{}));
 await one('config revocation before document sink','ready',async f=>f.changeConfig({sessionSearchIndexV1:false}));
 await one('physical head edit without sequence bump before document sink','ready',async f=>{const file=path.join(f.sessions,'Synthetic.json'),value=JSON.parse(await fsp.readFile(file,'utf8'));value.title='cedar changed title';await fsp.writeFile(file,JSON.stringify(value));});
 const sourceStable=sources.every(row=>hash(row.file)===row.sha256),report={schemaVersion:1,status:sourceStable?'PASS':'SOURCE_CHANGED',cases,sources,sourceStable,limits:'actual consumer/store/scorer with synthetic model vectors; no acceptance fixtures, external model, build or production changes'};
 fs.writeFileSync(path.join(__dirname,'metadata-boundary-review-r2.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:report.status,cases:cases.length,sourceStable}));if(!sourceStable)process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1;});
