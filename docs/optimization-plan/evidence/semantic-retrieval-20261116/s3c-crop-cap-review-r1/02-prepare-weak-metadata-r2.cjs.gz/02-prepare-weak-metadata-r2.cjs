'use strict';
const fs=require('node:fs'),path=require('node:path');
let cap=fs.readFileSync(path.join(__dirname,'weak-lexical-cap-repro-r1.cjs'),'utf8');
const before="status:narrow.results.length===0&&wide.results.some(row=>row.reference.sessionId==='ZStrong')?'REPRO_FILTER_AFTER_CAP':'NO_REPRO'";
if(!cap.includes(before))throw Error('cap fixture drift');
cap=cap.replace(before,"status:narrow.results.some(row=>row.reference.sessionId==='ZStrong')&&wide.results.some(row=>row.reference.sessionId==='ZStrong')?'PASS_FILTER_PRECAP':'FAIL'").replaceAll('weak-lexical-cap-repro-r1.json','weak-lexical-cap-repro-r2.json');
cap=cap.replace('console.log(JSON.stringify(report));','console.log(JSON.stringify(report));if(report.status!==\'PASS_FILTER_PRECAP\'||!report.sourceStable)process.exitCode=1;');
fs.writeFileSync(path.join(__dirname,'weak-lexical-cap-repro-r2.cjs'),cap,{flag:'wx'});
const metadata=fs.readFileSync(path.join(__dirname,'metadata-boundary-review-r1.cjs'),'utf8').replaceAll('metadata-boundary-review-r1.json','metadata-boundary-review-r2.json');fs.writeFileSync(path.join(__dirname,'metadata-boundary-review-r2.cjs'),metadata,{flag:'wx'});
