'use strict';
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../..'),{fixture,actual}=require(path.join(repo,'dev-harness/lib/fulltext-consumer-fixture')),{functionBlock}=require(path.join(repo,'dev-harness/lib/source-slice'));
const sourcePath=path.join(repo,'ruyi-workbench/app/src/13as-session-fulltext-consumers.js');
async function scenario(kind,mutation){
 const sourceSha256=crypto.createHash('sha256').update(fs.readFileSync(sourcePath)).digest('hex');
 // This option gives a mutable delegating facade over the real enhanced gateway.
 const f=await fixture({privacy:'enhanced',observeProjectSource:async()=>{}}),sid='A';let mutated=false,exitCallbacks=0;
 try{
  await f.put(sid,[{role:'user',id:'a',turnSeq:1,content:'needle old committed evidence'}],{head:{kind:'mission',cwd:f.directory,turnSeq:1,createdAt:'2026-11-16T00:00:00.000Z'}});
  if(kind==='observation')vm.runInContext(functionBlock(actual('10-context-governance.js'),'observationMainReadAllowed'),f.context);
  const ctx={...f.ctx,session:{id:sid,kind:'mission',cwd:f.directory,turnSeq:1},sessionId:sid,turnSeq:1,mainTurn:true};
  if(kind==='observation')f.context.turnSettlers.set(sid,{kind:'synthetic-current-owner'});
  const invoke=()=>kind==='model'?f.model('needle'):f.hooks.withObservation(ctx,()=>f.hooks.search('needle',20));
  const warm=await invoke();if(!warm.results.some(row=>row.snippet.includes('old committed')))throw Error('warm fixture did not produce evidence');
  const scope=kind==='model'?f.ctx.session.id:sid,original=f.privacy.withPolicy.bind(f.privacy),sequence=f.api.source.sequence(sid),epoch=await f.api.source.epoch(sid);
  f.privacy.withPolicy=(scopeId,work)=>original(scopeId,async()=>{
   const value=await work();
   if(scopeId===scope&&value?.ok===true&&Array.isArray(value.results)&&!mutated){
    exitCallbacks++;mutated=true;
    if(mutation==='source')await fsp.writeFile(path.join(f.sessions,sid+'.messages.ndjson'),JSON.stringify({role:'user',id:'a',turnSeq:1,content:'replacement unrelated evidence'})+'\n');
    else f.changeConfig({privacyModeV1:'strict'});
   }
   return value;
  });
  let outcome;try{const result=await invoke();outcome={returned:true,snippets:result.results.map(row=>row.snippet),privacyModeAtReturn:f.config.privacyModeV1};}catch(error){outcome={returned:false,code:error.code,message:error.message};}
  const sequenceUnchanged=f.api.source.sequence(sid)===sequence,epochChanged=(await f.api.source.epoch(sid))!==epoch;
  return{kind,mutation,sourceSha256,privacy:'real-enhanced-gateway',mutated,exitCallbacks,sequenceUnchanged,epochChanged,outcome,
    status:mutated&&!outcome.returned?'PASS_REJECTED_AT_POLICY_EXIT':mutated?'FAIL_STALE_RESULT_AFTER_POLICY_EXIT':'INCONCLUSIVE'};
 }finally{await f.close();}
}
(async()=>{const rows=[];for(const kind of ['model','observation'])for(const mutation of ['source','policy'])rows.push(await scenario(kind,mutation));console.log(JSON.stringify(rows,null,2));if(rows.some(row=>!row.status.startsWith('PASS')))process.exitCode=1;})().catch(error=>{console.error(error);process.exitCode=1;});
