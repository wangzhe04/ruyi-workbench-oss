'use strict';
// Synthetic encrypted-source, actual producer and cache. No model inference.
const fs = require('node:fs'), vm = require('node:vm'), crypto = require('node:crypto');
const { fixture, root } = require('../dev-harness/lib/work-data-session-fulltext-fixture');
const reportFile = root + '/output/semantic-message-append-cache-independent-v1.json';
if (fs.existsSync(reportFile)) throw Error('Use a new receipt path');
const source = fs.readFileSync(root + '/ruyi-workbench/app/src/06ha-semantic-retrieval.js','utf8');
const primitive = vm.runInNewContext(source + '\nSemanticRetrieval;', {require,Date});
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
(async () => { const f = await fixture({enabled:true}); let model = 'append-fake-v1', counts = {query:0,document:0};
  const runtime = { prepare:async()=>({available:true,modelFingerprint:model}), encode:async(texts,{role})=>{
    counts[role]+=texts.length; return {ok:true,modelFingerprint:model,vectors:texts.map(()=>[1,0])};
  }};
  const index=vm.runInNewContext('SessionFullTextIndex',f.hookContext).create({...f.host,semantic:primitive.create(runtime)});
  const rows=Array.from({length:11},(_,n)=>({role:'user',id:'m'+n,content:'synthetic distinct note '+n}));
  const report={status:'RUNNING',modelInference:false,sourceSha256:digest(source),phases:[]};
  async function search(label){counts={query:0,document:0};const result=await index.search('synthetic',null,10);
    report.phases.push({label,counts:{...counts},cached:result.semantic.cachedFragments,total:result.semantic.candidateFragments,
      coverage:result.semantic.coverage,results:result.results.length});}
  try {
    await f.put('A',rows);await index.step(16);await search('initial');await search('unchanged');
    await f.put('A',[...rows,{role:'user',id:'m11',content:'unrelated appended row'}]);await index.step(16);await search('append');
    f.changeScope();await search('scope changed');model='append-fake-v2';await search('model changed');
    f.allowed.set('A',false);const denied=await index.search('synthetic',null,10);report.revokedResults=denied.results.length;
    if(report.phases[0].counts.document!==11||report.phases[1].counts.document!==0||report.phases[2].counts.document!==12
      ||report.phases[3].counts.document!==12||report.phases[4].counts.document!==12||report.revokedResults!==0)throw Error('Unexpected reproduction result');
    report.status='PASS_OBSERVED_INEFFICIENCY_NOT_MODEL_QUALITY';
  }catch(error){report.status='FAIL';report.error=String(error?.stack||error);process.exitCode=1;}
  finally{await f.close();fs.writeFileSync(reportFile,JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));}
})().catch(error=>{console.error(error);process.exitCode=1;});
