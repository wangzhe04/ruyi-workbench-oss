import json, sys
from tokenizers import Tokenizer
tokenizer=Tokenizer.from_file(sys.argv[1])
rows=json.load(sys.stdin)
print(json.dumps([{'ids':v.ids,'mask':v.attention_mask,'special':v.special_tokens_mask} for v in [tokenizer.encode(row) for row in rows]]))
