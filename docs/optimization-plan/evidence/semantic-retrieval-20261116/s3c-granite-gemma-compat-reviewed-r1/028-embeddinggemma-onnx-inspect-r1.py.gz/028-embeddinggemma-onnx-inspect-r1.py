import json, sys, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'output/semantic-bce-reranker-v1/python-tools'))
import onnx
graph=ROOT/'output/embeddinggemma-full-onnx-q4-assets-v1/onnx/model_q4.onnx'
m=onnx.load(str(graph),load_external_data=False)
types={}
for n in m.graph.node:
    key=(n.domain or 'onnx')+'::'+n.op_type
    types[key]=types.get(key,0)+1
rows=[{'name':n.name,'op':n.op_type,'domain':n.domain,'inputs':list(n.input),'outputs':list(n.output)} for n in m.graph.node[-18:]]
v={'schema':1,'status':'STATIC_ONNX_GRAPH_INSPECTION_NOT_INFERENCE','graphSha256':hashlib.sha256(graph.read_bytes()).hexdigest(),'irVersion':m.ir_version,'opsets':[{'domain':x.domain,'version':x.version} for x in m.opset_import],'inputs':[{'name':x.name,'type':x.type.tensor_type.elem_type} for x in m.graph.input],'outputs':[{'name':x.name,'type':x.type.tensor_type.elem_type} for x in m.graph.output],'opCounts':types,'lastNodes':rows,'externalFiles':sorted(set(next((v.value for v in t.external_data if v.key=='location'),'') for t in m.graph.initializer if t.external_data))}
out=ROOT/'output/embeddinggemma-full-onnx-q4-static-inspection-r1.json'
assert not out.exists()
out.write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(v))
