# RANK buffer research notice

This experimental AVX2-only variant combines the independently recorded Qwen3 graph guard, RANK embedding HTTP endpoint guard, and RANK raw-logits buffer guard. It is restricted to a fresh dedicated Qwen3 RANK context for the pinned two-label local model, with embeddings enabled, no backend or CPU sampling, no optimizer, no dynamic mode change, and only the /rerank client path. It is not a production or portable build.

The logits getter changes from a non-null allocation to null, and llama_get_logits_ith may abort in debug builds. Neither general C API compatibility nor safety for native or HTTP clients calling unsupported endpoints is claimed. The embedding endpoint guard is not a general completion or process sandbox. The reported small synthetic samples and native process memory are not application performance or retrieval quality evidence.
