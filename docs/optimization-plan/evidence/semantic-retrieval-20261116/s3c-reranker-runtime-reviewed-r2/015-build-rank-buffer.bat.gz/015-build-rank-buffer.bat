@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
"C:\Strawberry\c\bin\cmake.exe" --build "C:\r31-native-headless-research\build-rank-buffer" --target llama-server --parallel 2
exit /b %errorlevel%
