@echo off
set "PATH=C:\Strawberry\c\bin;%SystemRoot%\System32;%SystemRoot%"
"C:\Strawberry\c\bin\cmake.exe" -S "C:\r31-gcc-rank-research\src" -B "C:\r31-gcc-rank-research\build" -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_C_FLAGS=-D_WIN32_WINNT=0x0A00" "-DCMAKE_CXX_FLAGS=-D_WIN32_WINNT=0x0A00" -DCMAKE_C_COMPILER=C:/Strawberry/c/bin/gcc.exe -DCMAKE_CXX_COMPILER=C:/Strawberry/c/bin/g++.exe -DCMAKE_MAKE_PROGRAM=C:/Strawberry/c/bin/ninja.exe -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_EXAMPLES=OFF -DLLAMA_BUILD_SERVER=ON -DLLAMA_BUILD_TOOLS=ON -DLLAMA_BUILD_UI=OFF -DLLAMA_OPENSSL=OFF -DBUILD_SHARED_LIBS=OFF -DGGML_BACKEND_DL=OFF -DGGML_NATIVE=OFF -DGGML_CPU_ALL_VARIANTS=OFF -DGGML_AVX=ON -DGGML_AVX2=ON -DGGML_FMA=ON -DGGML_F16C=ON -DGGML_BMI2=ON -DGGML_OPENMP=OFF -DGGML_CCACHE=OFF "-DCMAKE_EXE_LINKER_FLAGS=-static -static-libgcc -static-libstdc++"
if errorlevel 1 exit /b %errorlevel%
"C:\Strawberry\c\bin\cmake.exe" --build "C:\r31-gcc-rank-research\build" --target llama-server --parallel 2
exit /b %errorlevel%
