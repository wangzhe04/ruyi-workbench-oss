// In-memory semantic primitives. The host owns runtime availability and authorization.
const SemanticRetrieval = ((crypto) => {
  const searchPolicy=Object.freeze({id:'minilm-search-relevance-v1',modelId:'paraphrase-multilingual-MiniLM-L12-v2',minScore:0.34,structuredIdentifiers:true,purpose:'search-relevance',automatic:null});
  function structuredIdMatches(identifierText) {
    const normalized=String(identifierText).normalize('NFKC').toLowerCase(),matches=[];
    // Validate the complete maximal ASCII identifier token. Searching inside a
    // rejected token would conflate AB-ZZ-91, XY-ZZ-91 and overlong prefixes.
    for(const match of normalized.matchAll(/[a-z0-9_:-]+/g)){
      const token=match[0];let from=0,to=token.length;
      // Boundary separators may be prose punctuation ("OP-12:"). Trim only
      // the two edges; invalid internal segments never restart suffix parsing.
      while(from<to&&!/[a-z0-9]/.test(token[from]))from++;
      while(to>from&&!/[a-z0-9]/.test(token[to-1]))to--;
      const value=token.slice(from,to);if(value.length>256||!/^[a-z][a-z0-9]{1,15}(?:[-_:][a-z0-9]+)+$/.test(value))continue;
      if(!/\d/.test(value.slice(value.search(/[-_:]/)+1)))continue;
      matches.push({value,start:match.index+from,end:match.index+to});
    }
    return matches;
  }
  const structuredIds=text=>[...new Set(structuredIdMatches(text).map(match=>match.value))];
  function assessAdmission(query,docs,scores,{complete=true,minScore=searchPolicy.minScore}={}) {
    const required=structuredIds(query),reasons=[];
    const accepted=scores.map((score,n)=>{
      const reason=!Number.isFinite(score)?'unscored':score<minScore?'low-cosine':required.some(id=>!structuredIds(docs[n]).includes(id))?'identifier-mismatch':'accepted';
      reasons.push(reason);return reason==='unscored'?null:reason==='accepted';
    });
    return{policyId:searchPolicy.id,purpose:searchPolicy.purpose,status:complete?'evaluated':'partial',accepted,reasons,
      features:{minimumCosine:minScore,requiredIdentifiers:required.length},answerability:'not-assessed'};
  }
  function create(runtime, options={}) {
    // Queries cannot evict document vectors. One complete 4096-fragment corpus
    // fits even while another scope/model is being warmed.
    const documentLimit=Math.max(4096,Math.min(16384,options.documentLimit||8192)),queryLimit=128;
    const documents=new Map(),queries=new Map();
    // Reserve measured call cost before starting another bounded batch. A native
    // deadline still kills its owner; routine tail-budget exhaustion must not.
    const callMsPerText={query:32,document:20};
    const minimumBudget=(role,count)=>{
      const local=Math.max(64,Math.ceil(callMsPerText[role]*Math.max(1,count)*1.25+16));
      if(typeof runtime?.estimateEncodingBudget!=='function')return local;
      const hint=runtime.estimateEncodingBudget(role,count);
      if(typeof hint!=='number'||!Number.isFinite(hint)||hint<0||hint>60000)throw Error('semantic.invalid_budget_hint');
      return Math.max(local,Math.ceil(hint));
    };
    const key=(scope,model,value)=>crypto.createHash('sha256').update(JSON.stringify([scope,model,value])).digest('hex');
    const vector=value=>Array.isArray(value)&&value.length>0&&value.length<=8192&&value.every(Number.isFinite)&&value.some(n=>n!==0);
    const get=(map,k)=>{const v=map.get(k);if(v){map.delete(k);map.set(k,v);}return v;};
    function put(map,k,v,limit){map.delete(k);map.set(k,v.slice());while(map.size>limit)map.delete(map.keys().next().value);}
    async function score(query,docs,{scopeId,signal,deadlineMs=1000,deadline:outerDeadline=Infinity,identities=[],maxEncodeDocuments=128,purpose='search',resolveTexts,beforeEncode}={}) {
      const empty=status=>({status,scores:docs.map(()=>null),coverage:{cached:0,total:docs.length,complete:false}});
      if(!runtime||typeof runtime.prepare!=='function'||typeof runtime.encode!=='function')return empty('unavailable');
      const deadline=Math.min(Date.now()+Math.max(1,Math.min(1000,deadlineMs)),Number.isFinite(outerDeadline)?outerDeadline:Infinity);
      const descriptor=await runtime.prepare({scopeId,signal,deadline});
      if(beforeEncode)await beforeEncode();
      if(signal?.aborted)throw signal.reason||Error('semantic.aborted');
      if(Date.now()>=deadline)return empty('timeout');
      if(!descriptor?.available){if(['disabled','unavailable','timeout','overloaded'].includes(descriptor?.reason))return empty(descriptor.state==='loading'?'loading':descriptor.reason);throw Error('semantic.prepare_failed');}
      const minScore=descriptor.retrievalThresholds?.[purpose];
      if(purpose==='automatic'&&!(typeof minScore==='number'&&Number.isFinite(minScore)))return empty('disabled');
      const model=descriptor.modelFingerprint;if(typeof model!=='string'||!model.length||model.length>512)throw Error('semantic.invalid_model');
      const qkey=key(scopeId,model,['query',query]),keys=docs.map((text,n)=>key(scopeId,model,['document',identities[n],text]));
      let q=get(queries,qkey),status='ready';const vectors=keys.map(k=>get(documents,k)||null);
      async function encode(texts,role){
        if(signal?.aborted)throw signal.reason||Error('semantic.aborted');
        if(beforeEncode)await beforeEncode();
        if(signal?.aborted)throw signal.reason||Error('semantic.aborted');
        // Source resolution and the final authority guard can consume the
        // budget used to select a batch. Submit only the prefix that still fits;
        // an unchanged oversized batch must not block every later request.
        let encodedCount=texts.length;
        if(role==='document')while(encodedCount>1&&minimumBudget(role,encodedCount)>deadline-Date.now())encodedCount--;
        texts=texts.slice(0,encodedCount);
        const minimumBudgetMs=minimumBudget(role,texts.length);
        if(deadline-Date.now()<minimumBudgetMs)return {ok:false,reason:'timeout'};
        const began=Date.now();
        const result=await runtime.encode(texts,{role,scopeId,signal,deadline,minimumBudgetMs,...(beforeEncode?{beforeEncode}: {})});
        if(beforeEncode)await beforeEncode();
        if(signal?.aborted)throw signal.reason||Error('semantic.aborted');
        const perText=(Date.now()-began)/Math.max(1,texts.length);
        if(result?.ok)callMsPerText[role]=Math.min(250,Math.max(12,callMsPerText[role]*0.6+perText*0.4));
        else if(result?.reason==='timeout')callMsPerText[role]=Math.min(250,Math.max(callMsPerText[role]*1.5,perText));
        if(!result?.ok){if(['unavailable','disabled','timeout','overloaded'].includes(result?.reason))return result;throw Error('semantic.encode_failed');}
        if(result.modelFingerprint!==model||!Array.isArray(result.vectors)||result.vectors.length!==texts.length||!result.vectors.every(vector))throw Error('semantic.invalid_vectors');
        const dimension=result.vectors[0].length;if(result.vectors.some(v=>v.length!==dimension)||q&&q.length!==dimension)throw Error('semantic.invalid_vectors');
        return {...result,encodedCount};
      }
      if(!q){const result=await encode([query],'query');if(!result.ok)return {...empty(result.reason),modelFingerprint:model};if(result.truncated?.[0])return {...empty('truncated'),modelFingerprint:model};q=result.vectors[0];put(queries,qkey,q,queryLimit);}
      const missing=[];for(let n=0;n<vectors.length;n++)if(!vectors[n])missing.push(n);
      const budget=Math.max(0,Math.min(128,Math.floor(Number(maxEncodeDocuments)||0)));
      const selected=missing.slice(0,budget);
      for(let offset=0;offset<selected.length;){
        let count=Math.min(4,selected.length-offset);
        while(count>1&&minimumBudget('document',count)>deadline-Date.now())count--;
        let batch=selected.slice(offset,offset+count);
        if(Date.now()>=deadline){if(beforeEncode)await beforeEncode();status='timeout';break;}
        let texts=typeof resolveTexts==='function'?await resolveTexts(batch,{signal,deadline}):batch.map(n=>docs[n]);
        if(!Array.isArray(texts)||texts.length!==batch.length||texts.some(text=>text!==null&&typeof text!=='string'))throw Error('semantic.invalid_source');
        const usable=batch.map((n,i)=>({n,position:i,text:texts[i]})).filter(item=>typeof item.text==='string'&&item.text.length>0&&item.text.length<=8192);
        if(usable.length<batch.length)status='partial';if(!usable.length){offset+=count;continue;}
        batch=usable.map(item=>item.n);texts=usable.map(item=>item.text);const result=await encode(texts,'document');
        if(!result.ok){status=result.reason;break;}
        // Keep vectors aligned with the actual submitted source prefix. Entries
        // resolved but not executed remain pending, including gaps in usable rows.
        batch=batch.slice(0,result.encodedCount);
        batch.forEach((n,i)=>{if(result.truncated?.[i]){status='truncated';return;}vectors[n]=result.vectors[i];put(documents,keys[n],vectors[n],documentLimit);});
        offset+=usable[result.encodedCount-1].position+1;
        if(Date.now()>=deadline){status='timeout';break;}
      }
      const norm=v=>Math.sqrt(v.reduce((sum,n)=>sum+n*n,0)),qn=norm(q);
      const scores=vectors.map(v=>{if(!v)return null;if(v.length!==q.length)throw Error('semantic.invalid_vectors');return v.reduce((sum,n,i)=>sum+n*q[i],0)/(norm(v)*qn);});
      const cached=vectors.filter(Boolean).length,complete=cached===docs.length;
      if(status==='ready'&&!complete)status='partial';
      const effectiveMinimum=typeof minScore==='number'&&Number.isFinite(minScore)?minScore:0.85;
      const admission=purpose==='search'&&descriptor.modelId===searchPolicy.modelId?assessAdmission(query,docs,scores,{complete,minScore:Math.max(searchPolicy.minScore,effectiveMinimum)}):null;
      return {status,scores,modelFingerprint:model,minScore:admission?admission.features.minimumCosine:effectiveMinimum,coverage:{cached,total:docs.length,complete},...(admission?{admission}:{})};
    }
    return Object.freeze({score,clear:()=>{documents.clear();queries.clear();}});
  }
  return Object.freeze({create,assessAdmission,searchPolicy,structuredIds,structuredIdMatches});
})(require('node:crypto'));
