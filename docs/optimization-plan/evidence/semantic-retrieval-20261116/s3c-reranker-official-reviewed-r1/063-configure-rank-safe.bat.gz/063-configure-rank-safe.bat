@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
"C:\Strawberry\c\bin\cmake.exe" -S "C:\r31-native-headless-research\source-rank-safe" -B "C:\r31-native-headless-research\build-rank-safe" -G Ninja -DCMAKE_BUILD_TYPE=Release -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_EXAMPLES=OFF -DLLAMA_BUILD_SERVER=ON -DLLAMA_BUILD_TOOLS=ON -DLLAMA_BUILD_UI=OFF -DLLAMA_OPENSSL=OFF -DBUILD_SHARED_LIBS=ON -DGGML_NATIVE=OFF -DGGML_OPENMP=ON -DGGML_CCACHE=OFF
exit /b %errorlevel%
