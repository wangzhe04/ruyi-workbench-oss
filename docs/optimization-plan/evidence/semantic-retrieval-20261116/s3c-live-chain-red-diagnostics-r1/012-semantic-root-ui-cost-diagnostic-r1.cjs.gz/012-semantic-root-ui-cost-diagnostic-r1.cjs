'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{performance}=require('node:perf_hooks');
const {fixture}=require('../dev-harness/semantic/scalar-window-append-public-consumer-fixture.cjs');
const corpus=require('../dev-harness/semantic/calibration-fixture.cjs');
const fingerprints={modelFingerprint:'synthetic',templateFingerprint:'synthetic',runtimeFingerprint:'synthetic',policyFingerprint:'synthetic'};
let spans=null,sourceNumber=0;
function wrap(target,names,prefix){const value={...target};for(const name of names)if(typeof target[name]==='function')value[name]=async(...args)=>{
  const captured=spans,start=performance.now();try{return await target[name](...args);}finally{if(captured)captured.push({label:prefix+'.'+name,start,end:performance.now()});}};return value;}
function summary(rows){return Object.fromEntries([...new Set(rows.map(r=>r.label))].sort().map(label=>{
  const own=rows.filter(r=>r.label===label),sorted=own.slice().sort((a,b)=>a.start-b.start);let end=-Infinity,union=0;
  for(const r of sorted){union+=Math.max(0,r.end-Math.max(end,r.start));end=Math.max(end,r.end);}
  return [label,{calls:own.length,cumulativeMs:own.reduce((n,r)=>n+r.end-r.start,0),unionWallMs:union}];}));}
async function main(){
  const f=await fixture({enabled:true,privacy:'enhanced',researchDirectory:path.resolve('output/semantic-root-ui-cost-diagnostic-r1-source'),
    runtime:{prepare:async()=>({available:true,modelFingerprint:'synthetic'}),encode:async(texts,options)=>{await options.beforeEncode?.();return {ok:true,modelFingerprint:'synthetic',vectors:texts.map(()=>[1,0])};}},
    scalarHost:{prepare:async()=>({ok:true,...fingerprints}),verify:async(_query,_source,options)=>{for(let n=0;n<4;n++)await options.beforeVerify();return {ok:true,...fingerprints,score:.99,accepted:true};},stop:async()=>({workerExited:true,cleanupStatus:'observed'})}});
  const report={schema:1,status:'SYNTHETIC_MODEL_ACTUAL_UI_SOURCE_COST_DIAGNOSTIC',nativeStarts:0,rows:[],limitations:[
    'Synthetic immediate vectors/scalars, not quality, native inference latency or formal performance qualification.',
    'Spans preserve original calls and exception behavior. Per-label intervals are unioned; labels are nested and must not be added.',
    'Four fake scalar inner guards model repeated authority checks but do not establish actual native timing.']};
  try{
    const sourceFactory=f.context.createSessionFullTextSource;
    f.context.createSessionFullTextSource=()=>wrap(sourceFactory(),['inspect','epoch','scan'],'source'+sourceNumber++);
    f.context.PrivacyGateway=wrap(f.context.PrivacyGateway,['prepareLocalDisclosure','prepareDisclosure','prepareMultiSourceDisclosure','projectSource'],'privacy');
    const bind=f.hooks.bindSessions;
    f.hooks.bindSessions=disclosure=>wrap(bind(wrap(disclosure,['authorize','project'],'disclosure')),['prepare','search','coverage','revalidate'],'index');
    const search=f.hooks.search,emit=f.hooks.emitUI;
    f.hooks.search=wrap({search},['search'],'consumer').search;f.hooks.emitUI=wrap({emit},['emit'],'consumer').emit;
    for(let n=0;n<corpus.documents.length;n++)await f.put('CAL'+String(n).padStart(3,'0'),[{role:'user',id:'m1',content:corpus.documents[n].text}],{head:{title:'',summary:'',cwd:'',kind:'mission'}});
    await f.index.prepare(null);
    const selected=corpus.queries.filter(q=>q.split==='train'&&q.kind==='positive');
    const queries=[{id:'control-warmup',text:'semantic index warmup'},selected.find(q=>q.group==='zh-zh'),selected.find(q=>q.group==='en-zh'),selected.find(q=>q.group==='exact-entity')];
    for(const query of queries){spans=[];const started=performance.now(),result=await f.ui(query.text),elapsedMs=performance.now()-started,own=spans;spans=null;
      report.rows.push({queryId:query.id,elapsedMs,coverage:result.coverage,semantic:result.semantic,lexicalAdmission:result.lexicalAdmission,resultCount:result.results.length,spans:summary(own)});}
  }finally{spans=null;await f.close();}
  const files=['13as-session-fulltext-consumers.js','13ap-session-fulltext-index.js','02-session-store.js'];
  report.bindings=files.map(name=>{const file='ruyi-workbench/app/src/'+name;return{file,sha256:crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')};});
  const output='output/semantic-root-ui-cost-diagnostic-r1.json';fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({output,rows:report.rows}));
}
main().catch(error=>{console.error(error);process.exitCode=1;});
