# M5 permanent browser natural entry / copy revision3 独审 — ACCEPT

**ACCEPT：五文件增量未发现新的 P0/P1 或阻断性 P2。Root可安排永久retention HTTP/browser各两fresh及六件相关原回归，再另窗full fast。** 本审仅相关纯UI unit、语法、受限控制与静态检查，未启动browser/server/listener/HTTP/native/DPAPI/network，未访问live根/key/PID，未修改产品/候选/旧包或提交。实际批次仍由Root授权，不把本审计为actual通过。

被审冻结 `.ruyi-runtime/m5-retention-freeze-revision3-20261030/`：REPORT SHA256 `61446b4035212ed86a141395b59d04a0f97004625cb806d67cfc5912e04d19ca`；PINS SHA256 `705dd6e9521a6e584dcacbf159cc6f7e9cf4ca05a1d4d1f93e532d836a7c9e9d`；完整patch319532B/SHA256 `d3a9d4732b899909a83eb2e3f5c470249181a5a352779df02a27e9975f4612b9`。37live与冻结tree逐项相同；相对revision2只有指定五项：permanent browser、UI unit、HTML、en-US、zh-CN。11product中只三呈现文件改变，另8项逐字相同，API/backend/codec无改动。

五项new source pins完整记录于verification.json / execution-inputs.json：browser12751B/SHA `c90e879349e3372166e2d1b35d76abe72f93028bd6b8d8d6ba56c978a1e98bbf`；UI unit59904B/SHA `b0daf3dc634f7fe2ba3309f14cb5edde6dee42ce98d767781700571bdc0652b5`；HTML SHA `d1a9f2f7c9b12996a202d970b35f540ecbf37d466dcb16959ac0986430fed65c`；en-US SHA `2963eddf70fd51b484e698e4fdac53908a6f1b0e3e273ad7d9ae807603ff91ab`；zh-CN SHA `d48ca7954a230cdb6eb5fbc0d1911364f3d860f37bcaa9e14466f487278416dd`。

新natural部分放在RB旅程前，使用已审7074B natural-ready source（SHA `57c0943f85ebe58e4ab2229ffb1f279d2b2e6db700eb5d44dd77e34adc7bd949`）相同的完整pointerProbe。scroll后中心点需正尺寸、visible/display、elementFromPoint为目标或子代；仍派发原mousePressed/mouseReleased，不用DOM click替代自然部分。N0沿原200 attempts/40ms helper等待VT自然消失，无盲sleep或预算扩大。gear→settings→初始collapsed group→steward→delivery→preview全通过真实鼠标与状态门，截图仅在evidence启用时保存；原forced helper只保留给后续旧RB断言，不用于N1–N10自然可达证明。

N9明确比较ledger原bytes且commit POST为0，N10独立查provider/browser错误；preview不创建mutation owner。N11真实Escape关闭后由原可见性观察进入deactivate：external-bots.js:701清retentionPreview，retentionRequest只在显式commit时创建。若已commit且ACK未知，该全局owner按原lost-ACK合同保留，不能为了自然旅程清掉它。

独立定向纯UI控制复用原unit的synthetic DOM/API与**未修改的真实panel模块**：完成preview→关闭后preview=null、retentionPending=null；重新激活并解决原authoritative reads后commit隐藏、commit调用仍0；下一preview的requestId不同且绑定新preview。该控制不模拟真实Escape/geometry，真实自然旅程仍需下一actual。它证明controller不会把自然preview/token/request残留成RB2旧确认或自动commit。

完整最小逆核：新增自然段前缀保持旧source；从 `const open` 开始的整个旧RB1–RB18/lost-ACK后缀，除RB15等价文案断言与finally错误判定外逐字恢复revision2。RB2默认30天且commit隐藏、RB3–5 preview无变更、RB6–7真实commit丢ACK不自动POST、RB8–11重开并显式重用同request/token、RB12–13磁盘payload/receipts/移除、RB14–18locale/窄屏/provider/错误门均保留。自然preview是另一个只读请求，不占旧commit的posts索引；旧same-body replay断言未被放宽。

文案只替换同一privacy最后一句：首次回收升级机器人记录格式，旧版无法打开**整份**记录；英文对应entire record。HTML fallback与zh-CN逐字同步，两个locale除该key外所有keys/values逐项不变。原SSD非安全擦除、会话/草稿/平台副本/导出/历史备份不删除及回执有效范围保留。移除payload5实现名符合用户流；UI unit与RB15从literal实现名改为同等整份兼容拒绝语义并明确不含payload5，没有修改实际拒绝行为。

独立验证：**56/56纯UI unit通过**，browser/UI unit两项node --check exit0、git diff --check通过；完整candidate.patch在自身GIT_INDEX_FILE的隔离index从精确f72 base执行 `git apply --cached --check`通过，未动工作区/index。另四种exact finally纯控制全部通过：成功、body失败、cleanup失败、双失败；错误在runner.done之前计FAIL，exit1且无ALL PASS。body失败且cleanup成功时evidence.finish拿到原异常对象；cleanup自身抛错时finish/manifest仍可能不完整，控制明确保持红，并保留原body FAIL行（若有），不得把cleanup请求当成功或声称manifest完整。实际诊断需留原stdout/stderr与cleanup结果；本scope不改原fixture关闭实现。

首次独审核验器把Node默认spec输出误按TAP解析，工具aad785 exit1；其UI命令本身已56/56、exit0。保留review-initial-failure.json和原tool输出引用；核验器显式选TAP并缓存原输出后完整复核通过，工具ed16fc exit0/约2.57s。此为review输出格式错误，不是候选首红；候选/测试断言未改。Node仅有既有MODULE_TYPELESS_PACKAGE_JSON提示，未修改package或抑制警告。

391项独立保护快照前后完全相同，覆盖被审freeze43成员/自身PINS、旧packet与selected source/report64保护记录、37live及262静态输入。HEAD `f72f38c1933015eb4d58e0be81aeec5467beba0d`和exact dirty/untracked37不变；适用AGENTS为空/相关目录无额外文件。旧freeze/first-red与保存报告不覆写；没有声称逐一扫描所有历史actual目录。新执行闭包保持原262条路径，仅现场刷新hash；是静态保守snapshot，不是动态穷尽依赖/实际runtime全闭包。

旧encrypted revision4两次E1–E9 actual报告SHA `20ef2f73bcf55ea30d567f4c81bdd9c559bcf2b41de486624b23b047fef2f0ee`保持。报告明确：**无独立外层120s watchdog**；两件自然终态exit0，18.174s/15.416s为capture intervals，排除initial preflight且不是精确outer case duration。本审保留该限制，不追认强制120s执行证明，也不混为新permanent browser actual。

固定workdir：`C:/Users/87179/.codex/worktrees/m5-delivery-retention/ruyi-workbench-oss`。Root准入后retention argv分别为：

```text
node dev-harness/external-bots-retention.e2e.js
node dev-harness/external-bots-retention.browser.e2e.js
```

各两次fresh隔离home/AppData/TEMP/evidence，遵循原预算、精确actor/cleanup、首红保留与runtime身份记录，不自动retry；外层watchdog是否实有需按现场记录，不能以工具yield代替。六件原相关回归保持：external-bots.e2e.js、external-bots-control.e2e.js、external-bots-work-data.e2e.js、external-bots.browser.e2e.js、external-bots-retry.browser.e2e.js、external-channel-delivery.e2e.js；本审未运行这些actual。full fast另窗，由Root安排。

独审pre/post只读命令：`node .ruyi-runtime/m5-retention-permanent-browser-revision3-review-sol-20261030/preflight.cjs`。它核对新packet/源pins/静态输入，不启动产品。当前Node为C:/Program Files/nodejs/node.exe v24.14.0/SHA `63c259c81e5d472b5f11c8d506070130cb04a1ecf84b80377a34ed6ec9048088`；未来Node/Edge/native/env/tool及完整actual闭合需独立记录。ChildProcess事件非OS birth、ignoredstdio非EOF、response body非完整wire；其他M5/M3/M4/M6、active/bad-cipher/OFF/sealed crash/lost-ACK、真实平台与完整3.1仍pending。
