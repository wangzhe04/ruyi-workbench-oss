# M5-B1 revision1 同审窄复核 — 2026-10-29

结论：**前轮两处 P2 均关闭；本次相对前轮的十文件差异未发现新 P0/P1 或阻断性 P2。可在下述输入 capture 与隔离条件下进入 Terra 的限定实际 HTTP/browser 验收。** 这不是产品晋升、发布或完整 M5/3.1 通过。

## 身份与审查边界

同一 Sol 独立审查者。只读候选/冻结物，证据仅新增在本 ignored 目录；HEAD 仍 `f72f38c1933015eb4d58e0be81aeec5467beba0d`，没有修改实现、MAIN、旧冻结、旧独审、断言、预算，也没有 actual server/browser/native/network/fullunit。

- revision1 identity SHA：`1fed72f4017b965a180bbbedb4ebf320850b10cfcdfcbff9c87745aaef93bf27`；treeDigest：`e2991d40d7c2ef548bd59457d0e2e6768c71869f725c765de248298e6a34285c`。
- changed-pins SHA：`273121bb69ac558d5517e1479e8586e1920b68a307c02818031fb2550e9509c5`；作者 REPORT SHA：`381de4e437c7e4002c463e509e16f8661e2653dbc3886b8372dd8f5284597740`。
- revision-only.patch SHA：`f0f839e76405ddba0635ce4bb789d887a2d6dbbcc1eeb18b3d4e84314ceb83c4`；full patch SHA：`471e2ff041dd33730b1a010e079252869e5018189f8d52d35e1daa942d0084c0`。
- 13w SHA：`b2f8ace6d451c10d4d7248d08979dfd65256be4ab0b67331ded41916a1378e97`；server：`feabec8bc95275d638aafc1b826fa599c88d16a54b154d39fb5e34984eb4532d`；manifest：`63178bf2d4970c6b23521c5cde870ab474242c950194cfea3138a9f29a4f3a8d`。

独立重算 revision1 全部71个 identity成员、35个 live/frozen changed pins、十个 historical-before 文件；旧48份冻结成员及旧独审19个 artifacts 原样一致。所有当前 dirty/untracked 文件恰为35个 pins，无额外实现变动。不是仅信任作者清单。

## 两处 P2 关闭证据

1. `externalBotValidReceiptDelivery` 的 attemptId 新增显式 string 守卫，原字母表和长度不变。将此守卫及 setup scope/guidance 三个精确 span 逆回，13w SHA 逐字还原前轮 `d98f6d11…d7d`；发送、资格、state chain、HMAC、容量、回执重放和去重均未另改。
2. 原 null/7 × plain/sealed 四个负例复制到本新目录，**原 `a.rejects(...storage_unavailable)` 断言逐字保留**；唯一 driver 适配是 catch 其先前无条件诊断 read，使修后正确抛错能到达原断言。独立执行4/4 PASS、0 fail/skip，798.4147ms；旧四项原红及原脚本未改。见 `original-four-negatives.log`。
3. 独立执行新增永久两项：真实 accept→drain→archive→preview→commit producer 后，对12种坏类型/形状、plain/sealed冷 reader/accept/next 全拒、磁盘不变、零额外执行/发送；setup 在回收前1/1、回收后0/0，均显式 `scope:retained_bodies`，completed/sent/平台 messageId 事实仍保留。**2/2 PASS**、0 fail/skip，1149.4349ms；见 `two-permanent-fixes.log`。使用原 test-name-pattern 选定这两项，没有重跑全224或所有 runtime。
4. `externalBotStewardSetup` 的 additive scope、guidance、13f工具说明及现有 setup UI 中英 hint 明确当前保留正文计数，不作 lifetime 或“平台确认被撤销”推论，不凭0重跑重发。两locale各只有 botSetup.evidenceHint 一个键变化，原文完整保留并追加边界；未给最小receipt添加连接身份或虚构历史聚合。

同类新 receipt/request 字段沿用上次逐项检查结论；此次只有该 typeof 缺口得到修复，没有引入新的正则强转入口。

## 十文件差异及生成物

手写生产差异仅13w的上述三个span、13f工具说明、两语hint；另外是架构说明、保留完整原测试前缀后追加两项、历史reader精确逆变换、原retry browser三处产品SHA更新、官方server/manifest生成物。

独立确认永久 retention 测试原正文是新文件的逐字前缀；retry browser 撤回三处 SHA 更新后逐字还原前轮，业务断言/等待预算未变；新历史逆变换实际还原 v4 源 SHA `0f20414a8cf9af554b5bab9ba9c54f9b5e2dc4c3445f4e874fd97bfce77d1b09`。未把作者此次9项日志宣称为本审重新执行完整 reader矩阵；上次独审矩阵仍保留原身份和结果，本次验证它的源逆变换连续性。

本次官方 `build.js --check` 独跑通过，server与src/manifest新鲜且自洽；`git diff --check` exit0。作者243纯、9控制、4原反例、syntax1367及相关static结果只作为已封存作者证据，不替代本次4+2独跑，也不称fullunit或实际运行门。

## Terra 限定实际验收准入

在此次精确冻结组合上，先capture再运行；禁止与其它单件并行：

1. 实际 `node dev-harness/external-bots-retention.e2e.js` 连续两遍，每遍原runner整体120秒上限，原HTTP15秒/阶段10秒等待不改。
2. 随后实际 `node dev-harness/external-bots-retention.browser.e2e.js` 连续两遍，每遍原runner整体120秒上限，原wait/CDP预算不改。

原输入capture必须包含 HEAD、全部35 dirty/untracked文件及完整实际依赖闭合的大小/SHA、server/manifest/source/测试/helpers实际字节、Node/browser绝对路径与版本/hash、argv、真实seed和preload字节；仅记录seed生成器不足。原始stdout/stderr/exit/signal/时长、previewToken/requestID、前后ledger字节/hash、lost ACK时实际已发布事实与冷receipt核对、进程birth身份/actual close/清理记录按每遍独立保存。

使用全新隔离 HOME、USERPROFILE、LOCALAPPDATA、APPDATA、TEMP与独立data root，按原夹具关闭无关模型/MCP/后台自动任务；只用合成平台输入，不用真实账号/联系人。按原killOwnTree仅清理本件精确自有进程。失败保原根/原日志/首次红，不放宽断言/预算，不把孤立复跑拼成整轮绿。prepared browser脚本强行展开导航组的做法没有证明自然菜单可发现性，实际UI应另外检查真实菜单入口；这里没有确认或修复既有菜单问题。

以上两件通过后还需原相关HTTP/control/work-data/browser/retry-browser、真实加密/DPAPI HTTP与崩溃矩阵及统一门；这些都不是此次窄复核的已通过范围。M5 B2/C、工作流接力/模板、真实QQ/飞书、M3/M4/M6、实际包/升级回退/跨机与完整3.1仍未完成，版本仍3.0.1。
