# M4 derived Store put pre-I/O precheck — NEW one-span freeze

Storage candidate only, for independent snapshot re-review. Original77ba identity /3a80 module and all older freezes/reviewer red remain unchanged. No repository write/build/native/helper/socket/browser/live or download ran.

## Exact delta

src/13bb-media-derived-store.js adds exactly `await strictEnabled();` inside put's existing try block, immediately after bounded owned bytes/manifest validation and before authority.capture. Thus ownership is established before the first await, and an invalid/unavailable switch prevents authority capture, path lstat/open, Store.mkdir, key access and persistence. Store's existing write-time strictEnabled wrapper remains in place and checks again; read is unchanged.

put-precheck-span.json pins the unique full before/after anchor, prior3a80dc57b8e8b29b297c8fa10446ad25911929b038e52217a55a54e49c5f8b8b and newfb2aee0a8b57ee41974fe59d0079380e8d0e6a55d189bdb6f66e75e1b2e5a3e5. repair.cjs reads the pinned old source and proves raw full inverse before writing this new directory only. No broader adapter behavior or13ba recognition contract changed.

Shared01p remains exacte02dc54d162dcffaa7af1f58537c70f77a0b87d6b84f72c13504d245527ac298, with the original three opt-in spans; prepare rechecked current10cdee and private9308 positive/inverse, private-after remainsa2909078a454683baa97ea8fc6525fe7e60a6aef3e4631036c2d5a70229e53aa. No shared Store default or private captured-read behavior changed. candidate-manifest remains order-only with no generated ranges; ROOT owns official build after source admission.

## Verification

- preio-pure-final.log:41/41 green test invocations. This includes the prior33 assertions, original reviewer io-order file's seven cases (five duplicate original switch cases + two new I/O order assertions), and one additional test proving an entryfalse→write-timeunknown transition still rejects at the actual Store gate. There are36 distinct cases; do not count duplicatedfive as new unique coverage.
- Reviewer io-order.test.cjs is copied byte-for-byte. Actual new io-order-put.json and io-order-read.json both contain exactly events:["switch"]. Unknown put/read reach no authority capture/filesystem/key operation.
- old-3a80-io-probe/old-io.log runs those same two assertions against pinned old3a80: read passes, putERR_ASSERTION fails,1pass1fail,exit1. Original reviewer io-order-first.log/json are separately retained under prior-evidence/boolean-review-*.
- negative-binding-preio.log and negative-old-store-preio.log each remainexit1 with originalERR_ASSERTION; the two original guards were removed from the new source for those negative runs. Prior33 tests were retained; only the structural inverse test adds reversal/uniqueness/hash checks for this new one-span before performing all original3a80→85aef inverse assertions.
- New Store write-time recheck test observes exactly two switch calls, zero key calls and zero published file when the first returnsfalse and the second returnsundefined.
- prior-evidence/boolean-review-review-final.json is the exact approved limited review inputSHA5f8ba842be7b267026bcdfb0a883f906e810b705db87043d2834648272c5401c. Prior identity77ba, earlier85aef actual plaintext first red, old author test-access first red and all previous evidence are retained, not replaced by these green checks.

Reproduce from repository cwd:

1. node <this-directory>/repair.cjs
2. node <this-directory>/prepare.cjs
3. node --test <this-directory>/candidate.test.cjs <this-directory>/unknown-switch-original.test.cjs <this-directory>/strict-switch.test.cjs <this-directory>/io-order.test.cjs

## Still unbound

This is not productionM4 ready. Durable source/policy/processor/revocation authority; media family/codec/migration/backup/retention; root/key/activity admission and revocation broadcast; real Full decoder/OCR/code helper; actual preview route/UI; gateway media-leaf approval and provider final send remain unbound. Borrowers must assert/finallyrelease; no event-driven purge or OS-held-handle path atomicity is claimed. Existing bounded PNG/AEAD/ON-OFF semantics and path-swap/orphan/concurrency limitations in prior-evidence/README-before-preio.md remain applicable. No media is actually uploaded or sent by this candidate. Full image/document/video scope remains, ASR/strictCLI remain deferred.