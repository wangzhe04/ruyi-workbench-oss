# M4 derived Store: Temp candidate, not admitted

2026-10-26。仓库HEAD c450c2f3；根正在收口M5/M3，本候选没有改仓库、build/native/helper/socket/browser/live、下载或完整套件。新增源文件13bb约200行，唯一共享文件01p只有三处唯一span，prepare.cjs可精确重建/逆回。candidate-manifest.json仅给产品拼接顺序与行区间方案，不是运行过build的生成产物。

## 文件与重跑

- src/13bb-media-derived-store.js：真实Store adapter，无公开导出、无自动实例化/路由/初始化。只有宿主显式create后可put/read。
- src/01p-work-data-store.js：当前仓库01p + 三span：新增opt-in boundedText、guardWrite的plain fallback改用boundedText、createText的plain fallback改用boundedText。未配置maxFileBytes的旧host仍走原readFile。现有chunkHeader/chunkLines已有上限；真正缺口是非chunk旧/plain分支（OFF派生记录也会走这里），所以仅补这一条同fd、fstat、大小/增长/截短/编码检查。未重构旧Store/AEAD/keys。
- store-spans.json：两个基线摘要、三个before/after、candidate摘要；prepare.cjs检唯一并逆回整个原文件（LF归一）后才写候选。
- private-9308-store-after.js：只供冲突审。root提供9308bcd32d7b85ea939728e1b5f122aac8a15adea7a8aa9375a972eababc9a74的完整私有01p，三个同锚原样可应用，逆回全部旧内容；不表示9308获生产批准。
- candidate.test.cjs：以source-slice加载实际PrivacyCore/WorkDataCrypto/WorkDataChunks/WorkDataStore/atomicWriteJson，测试PNG从真实13ba.prepare产生；不mirror Store/AEAD、不加载server、不DPAPI。master是测试内存随机32B；durable authority是测试自有磁盘JSON实现，绝不冒称产品source/policy owner。
- pure-final.log：当前候选12测试全过。negative-binding.log、negative-old-store.log均exit1，原assert.rejects报ERR_ASSERTION Missing expected rejection；前者移除冷读绑定循环，后者替换回现有无界Store。负控没有放宽断言。

重跑：在仓库cwd执行 `node <本目录>/prepare.cjs`，再 `node --test <本目录>/candidate.test.cjs`。prepare依赖9308原文件仍位于原Temp路径；其丢失时拒绝，不能默默跳过兼容核验。独审可直接读已冻结spans与两份candidate，不必重跑prepare。

## 已做与合同

- 只接受host发行的mimg_32hex作为文件id。root是trusted composition给的一族专用绝对目录，scopeId绑定一会话/工作区；read无path参数。逐祖先lstat/realpath拒绝junction/symlink，文件自身类型/路径/大小检查。新件随机id，使用真实atomicWriteJson写临时stage，再fs.link排他发布到最终id，防覆盖既有目标；finally清stage。节点root必须先由宿主建立，本模块不替用户创造任意目录。
- purpose固定cache、schema1、scopeId、recordId精确进入真实AEAD binding；ON分块seal，OFF canonical plain JSON。不是新密钥用途，不隐式创建key，读取密件即使开关OFF仍需认证。现有Store语义保持；每次put新id，不提供覆盖/降级API。
- 受限PNG只收13ba当前新编码形状：精确IHDR/IDAT/IEND、CRC、8bit RGB非隔行、合法尺寸<=8M像素、zlib输出长度/尾部/每行filter0、载荷SHA与声明字节，禁止源metadata/任意附加chunk。最多5MiB输入、base64 canonical、JSON工程上限约7MiB、物理工程上限12MiB。显式限额先于复制。13ba零命中合同完全没动。
- 内层严格schema1含id/sourceId/issuedAt/revocationRevision/manifest/data；manifest所有字段精确白名单并验证，冻结源hash/revision、策略hash/revision/rulesHash、处理器hash/version、scope、regionsHash、transformHash、payloadHash、bytes/尺寸/coverage/authorization。TTL最多60s、过期拒绝；存储不延长TTL。name/mime固定protected.png/image/png。
- put在首await前拥有受限bytes和manifest副本，跨await持同一authority snapshot，写入及发布前后核当前authority；权威变化不返回可用id。read冷加载真实Store+PNG验证，再从authority.capture(sourceId)拿当前durable source/policy/processor/revocation binding并精确比较，完全不依赖进程ticket。返回借用bytes、manifest、assert/release；assert重核权威/TTL/hash，失效或篡改立即清借用bytes；release使用捕获的Buffer.fill intrinsic，清零后不能assert。
- read/put按id私有串行链，不提供通用覆盖/撤销日志。撤销权威来自authority，必须durable，不能拿manifest本身充当它。read出的票据不包含发送许可；manifest.authorization始终none，Store绝不证明OCR/decoder coverage真实性。

## 测试与首红

12项包括>1MiB真实13ba PNG跨多chunk加密+冷adapter读取、OFF原字节、开关OFF后密读、缺钥/错误instance/密文篡改/跨record复制、八个权威绑定变更、借用篡改/撤销/过期、路径id/字段/PNG/hash负例、plain坏base64/TTL/manifest、写入等待时policy变更、同fd实际append/truncate、真实AEAD purpose/schema/scope反控和三span双基线全逆。

首次轻测9/10通过，唯一首红为测试将chunk JSON当作chunk.envelope，而真实结构是chunk.e.envelope，TypeError读取ciphertext；只修测试访问路径，产品未为首红放宽。首红摘要见FIRST-FAILURE.md。随后增加大PNG、多chunk、实际增长/截短与AAD矩阵，12项全过；两个负控另记。轻测不代表真实Full helper/DPAPI/用户旅程/最终发送或完整M4。

## 未接依赖（不能生产ready）

1. **durable authority还没产品实现。** create要求trusted authority.capture(sourceId)（可async）及assert(snapshot,sourceId)（必须同步true）。binding必须来自不可复用源revision、完整policy/rules、固定processor和durable revocation revision；当前产品上传没有这个registry。未提供“总返回true”的产品假实现。测试磁盘JSON仅证明冷读没有靠内存ticket。需要之后实现源归属/替换/删除/root切换与gateway策略epoch等真实host owner。并要求sourceId=宿主上传记录稳定id，客户端不得授予root/scope/authority。
2. **加密迁移/恢复/清册未接。** 新目录建议<data>/media-derived/<scope>/mimg_<id>.json（scope为host受控稳定id），必须新增durable-state row/93存储族登记/01x-work-data-migration-codecs准确pattern与cache/schema1/scope/recordId/chunked/MAX_TEXT绑定、collector/restore validator/backup及retention规则。不能当未知缓存静默丢弃，也不能让M3当前41族的通过自动涵盖它。本候选不修改01x或清册，故当前迁移工具尚不能可靠识别新族；必须先完成登记后才能启用产品写入。
3. **全局owner/根活动屏障未接。** 原M3迁移、切换root/关闭加密的activity gate需收纳这族操作；authority assert必须覆盖root世代、工作数据开关/密钥世代可用性等。read借用后在最终发送前还需实际钥/root owner复核。当前read.assert只核所声明authority和bytes，不再次async解密，也不假称可在同步API核真实DPAPI状态。
4. **runtime/预览/provider未接。** 无真实decoder/OCR/码识别helper，13ba.sourceOwner等仍未产品绑定；put接受的是trusted host交来的派生载荷，不能把外部提交manifest视为像素证明。无上传路由、预览route/UI、gateway媒体leaf准入、providerModelPostOnce提交核验，不能实际外发或展示媒体已支持。
5. **剩余路径/清理实证。** JS lstat/realpath检查不是Windows held-handle原子路径安全，恶意同账户进程在await中替换目录仍超出本片证明。排他link发布在本机普通Temp文件系统轻测已跑，但Windows权限/文件系统支持、崩溃留下stage/published orphan、磁盘不足/rename后ACK丢失、cleanup失败恢复和保留回收须后续真实场景验证；失败不删除已发布且可能需要恢复的记录。authority失效后已返回借用仅在assert/release时清零，宿主最终消费者必须finally release；本片没有全局事件驱动清所有借用或定时器。不得把Store当成撤回已发送副本的机制。
6. **对象/预算。** base64+字符串+inflate有受限但非零峰值，本片按id串行而没有process-wide媒体admission；需由后续总预算owner限制并发。PNG strict parser只接13ba当前RGB编码，不扩展解码器支持矩阵；原图片/截图/PDF/Office/视频全部范围不变。

本目录待非作者code review，根可将审查发现交作者修复后再冻结；当前未授权产品集成。