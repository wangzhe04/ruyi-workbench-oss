# M4 derived Store exact-boolean repair — NEW Temp freeze

Only new candidate directory is modified. Original 448437ecc66a921ff3b7d7dcece2262ed8134863a090fa9a2658089b68ec29d2 freeze / old adapter85aef8be558564d244f4238dfba0bbbc8e1ac280d0ec519568f3f72481092812 and reviewer first red remain unchanged. This new freeze is for independent review, not source admission or production readiness.

## Narrow product change

src/13bb-media-derived-store.js has exactly three reversible spans relative to85aef:

1. A local strictEnabled async wrapper awaits the host callback and permits only exact true/false fulfilled values. Other values throw typed media_store.switch_unavailable; thrown/rejected callbacks are wrapped with the same typed code and cause.
2. Every WorkDataStore host uses enabled:strictEnabled. Legacy WorkDataStore catches switch errors on write and reports its existing work_data_store.switch_unavailable. No old global OFF compatibility is changed.
3. Since WorkDataStore read does not call enabled at all, adapter.read explicitly awaits the same strictEnabled wrapper before cold reading. Unknown state cannot serve plaintext or encrypted payload. Valid false/true continue using the existing Store's read behavior and authentication.

The rest of13bb is byte-for-byte reversible to85aef. adapter-spans.json freezes exact before/after and raw inverse hash. Only fulfilled true/false count; Promise.resolve(false) and a thenable resolving false remain valid because the host switch is asynchronous by contract. Objects, arrays, boxed false, numbers, strings, fulfilled unknowns, and thrown/rejected unknowns cannot select plaintext.

Shared01p is unchanged from the preceding candidate e02dc54d162dcffaa7af1f58537c70f77a0b87d6b84f72c13504d245527ac298: exactly the same three opt-in bounded fallback spans, current baseline10cdee and private9308 exact positive/inverse retained. Private after remains a2909078a454683baa97ea8fc6525fe7e60a6aef3e4631036c2d5a70229e53aa. Neither shared Store default semantics nor private captured-read/cleanup code was expanded.

## Manifest correction

candidate-manifest.json now has proposalOnly:true, generated:false and no startLine/endLine on any row. It provides insertion order only:13bb immediately before14-main. prepare.cjs no longer computes pretend generated line ranges. ROOT must use the official build after source admission; no service/build was produced here.

## Evidence

- new-pure-final.log:33 tests,33 pass,0fail = original12 + reviewer original5 + new16. Actual source-sliced13ba/Store/Chunks/AEAD/original atomic writer are used; no mirrored codec or fake Store.
- unknown-switch-original.test.cjs preserves all original reviewer test assertions; only the candidate directory selection becomes process.env.RUYI_M4_CANDIDATE||__dirname. The unchanged input lives at prior-evidence/unknown-switch-original.test.cjs.
- Original4unknown undefined/null/0/empty now reject. The explicitfalse positive remains green. new-original-counter.log and switch-observations.json record the final rerun.
- strict-switch.test.cjs adds14 typed put+cold-read cases: undefined/null/0/empty/object/array/string-false/one/boxed-false/fulfilled-object/thenable-object/throw-falsy/reject-falsy/throwing-then; plus valid asyncfalse and true-key-failure positive boundaries; plus exact adapter inverse/order-only manifest assertion.
- old85-original-counter.log reruns the original five unchanged assertions against85aef:1pass4fail,exit1,ERR_ASSERTION. old85-switch-observations.json preserves actual plaintext publication observations.
- old85-strong-counter.log: same16 strong tests against old85aef,14fail2pass,exit1. Eleven fulfilled-invalid values expose plaintext publication; thrown/rejected switch errors already reject put in old Store but their cold reads still bypass the switch, so all14 combined put+cold-read cases fail the original strong assertions. Two positive/structural tests pass.
- negative-binding-new.log and negative-old-store-new.log each fail the original assertion with exit1 after the same guard removals as the prior freeze. The new switch fix does not weaken original12 or the two negative controls.
- prior-evidence contains the original candidate12 log, both older negative logs, identity448437, reviewer review-final-b2fe, original independent first-red/observations and old author FIRST-FAILURE summary. First author red was the test's chunk.e.envelope access error; reviewer red was the actual unknown-switch plaintext bug. They are distinct and retained.

Reproduce from repository cwd: node <newdir>/prepare.cjs; node --test <newdir>/candidate.test.cjs <newdir>/unknown-switch-original.test.cjs <newdir>/strict-switch.test.cjs. prepare still verifies current and private9308 sources/unique spans/inverses and must refuse missing or changed inputs. repair.cjs reconstructs13bb exact fix from pinned old85aef; all mutations target this newdir only. Do not rerun preparation against newer roots without refreshing pins through review.

## Unbound product dependencies remain explicit

Durable source/policy/processor/revocation authority, media migration family/codec/register/backup/retention, global root/key/activity admission, revocation broadcast and cleanup of outstanding borrows, actual decoder/OCR/codes helper, image preview route/UI, gateway media-leaf approval and provider final submit remain unbound. authority in tests is synthetic current authority, not a ready product implementation.13ba zero-hit contract and real processing coverage were not changed. Manifest.authorization remains none and this Store cannot authorize media egress.

Original design/path-swap/crash-orphan/cleanup/concurrency-budget limitations in prior-evidence/README.md remain applicable. In particular the borrower must assert before use and finally release; this repair does not add broadcast revocation or claim OS-held-handle path atomicity. Images/screenshots/documents/video frames remain in the full3.1 scope; ASR/strictCLI remain deferred by prior decision.

No repository writes,build,server load,native/helper,DPAPI,socket,browser,live service,download or heavy test ran in this repair.