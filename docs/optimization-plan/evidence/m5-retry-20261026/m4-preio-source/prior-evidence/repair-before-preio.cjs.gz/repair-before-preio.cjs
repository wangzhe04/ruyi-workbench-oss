'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),sha=v=>crypto.createHash('sha256').update(v).digest('hex'),dir=__dirname;
const old='C:/Users/87179/AppData/Local/Temp/ruyi-m4-derived-store-candidate-20261026-37711d2e';
const original=fs.readFileSync(path.join(old,'src/13bb-media-derived-store.js'),'utf8');
if(sha(original)!=='85aef8be558564d244f4238dfba0bbbc8e1ac280d0ec519568f3f72481092812')throw Error('old module pin changed');
const spans=[
 {before:'    const chains = new Map();',after:`    // An unavailable switch is never permission to persist plaintext. Keep legacy Store defaults unchanged.
    const strictEnabled = async () => {
      let value;
      try { value = await enabled(); }
      catch (cause) { throw Object.assign(new Error('media_store.switch_unavailable', { cause }), { code:'media_store.switch_unavailable', statusCode:503 }); }
      if (value !== true && value !== false) fail('switch_unavailable');
      return value;
    };
    const chains = new Map();`},
 {before:'scopeId, recordId: id, keys, enabled, writeJson:writer, chunked: true,',after:'scopeId, recordId: id, keys, enabled:strictEnabled, writeJson:writer, chunked: true,'},
 {before:'      return serial(id,async () => {\n        const file = await checkPath(id), value = parse(await storeFor(id,file).read(),id);',after:'      return serial(id,async () => {\n        // Store reads do not consult enabled(); apply this same strict wrapper before any cold read.\n        await strictEnabled();\n        const file = await checkPath(id), value = parse(await storeFor(id,file).read(),id);'}
];
let next=original;for(const span of spans){if(next.split(span.before).length!==2)throw Error('adapter span uniqueness');next=next.replace(span.before,span.after);}
let reversed=next;for(const span of spans.slice().reverse()){if(reversed.split(span.after).length!==2)throw Error('adapter inverse uniqueness');reversed=reversed.replace(span.after,span.before);}if(reversed!==original)throw Error('adapter inverse failed');
fs.writeFileSync(path.join(dir,'src/13bb-media-derived-store.js'),next);
fs.writeFileSync(path.join(dir,'adapter-spans.json'),JSON.stringify({baselineSha256:sha(original),candidateSha256:sha(next),inverseRawExact:true,spans},null,2)+'\n');
let prepare=fs.readFileSync(path.join(dir,'prepare.cjs'),'utf8');
const start=prepare.indexOf('let line=1;for(const row of manifest.modules)'),end=prepare.indexOf("fs.writeFileSync(path.join(dir,'candidate-manifest.json')",start);
if((start<0||end<0)&&!prepare.includes('manifest.proposalOnly=true'))throw Error('manifest proposal anchor');
if(start>=0&&end>=0)prepare=prepare.slice(0,start)+"for(const row of manifest.modules){delete row.startLine;delete row.endLine;}\nmanifest.proposalOnly=true;manifest.generated=false;manifest.note='Insertion order proposal only; no generated ranges. ROOT must run official build after source admission.';\n"+prepare.slice(end);
fs.writeFileSync(path.join(dir,'prepare.cjs'),prepare);
console.log(JSON.stringify({dir,module:sha(next),spans:spans.length,inverseRawExact:true}));