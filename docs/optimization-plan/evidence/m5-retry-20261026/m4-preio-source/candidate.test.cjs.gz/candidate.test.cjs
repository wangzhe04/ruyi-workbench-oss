'use strict';
const {test,after}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),vm=require('node:vm');
const repo=process.env.RUYI_M4_REPO||process.cwd(),dir=__dirname,src=path.join(repo,'ruyi-workbench/app/src');
const {constBlock,functionBlock}=require(path.join(repo,'dev-harness/lib/source-slice'));
const fixtureApi=require(path.join(repo,'dev-harness/lib/media-image-contract-fixture'));
const read=name=>fs.readFileSync(path.join(src,name),'utf8');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'ruyi-m4-store-unit-')),master=crypto.randomBytes(32);
const source=fs.readFileSync(process.env.RUYI_M4_MODULE_SOURCE||path.join(dir,'src/13bb-media-derived-store.js'),'utf8');
const storeSource=fs.readFileSync(process.env.RUYI_M4_STORE_SOURCE||path.join(dir,'src/01p-work-data-store.js'),'utf8');
function load({moduleSource=source,storeCode=storeSource}={}){
 const code=[read('01h-privacy-core.js'),constBlock(read('01n-work-data-crypto.js'),'WorkDataCrypto'),constBlock(read('01r-work-data-chunks.js'),'WorkDataChunks'),constBlock(storeCode,'WorkDataStore'),functionBlock(read('01-config.js'),'atomicWriteJson'),moduleSource].join('\n');
 return vm.runInNewContext(code+';({adapter:MediaDerivedStore,store:WorkDataStore,chunks:WorkDataChunks,atomicWriteJson});',{require,Buffer,process,crypto,fsp,setTimeout,clearTimeout,console});
}
const api=load(),error=e=>/^(media_store|work_data)/.test(e?.code||'');
async function fixture({enabled=true,writer,large=false,api:useApi=api}={}){
 const base=fs.mkdtempSync(path.join(root,'f-')),family=path.join(base,'media');fs.mkdirSync(family);
 const pipeline=fixtureApi.fixture(large?{changeFrame:frame=>{
  frame.width=1024;frame.height=400;frame.transform={width:1024,height:400,orientation:1};frame.rgba=crypto.randomBytes(1024*400*4);
  for(let i=3;i<frame.rgba.length;i+=4)frame.rgba[i]=255;
}}:{}),ticket=await pipeline.pipeline.prepare(),image=pipeline.pipeline.borrow(ticket);
 const manifest=JSON.parse(JSON.stringify(image.manifest)),bytes=Buffer.from(image.bytes);image.release();pipeline.pipeline.release(ticket);
 const binding={};for(const key of ['sourceHash','sourceRevision','policyHash','policyRevision','rulesHash','processorHash','processorVersion'])binding[key]=manifest[key];binding.revocationRevision='r1';
 const authorityFile=path.join(base,'durable-authority.json');fs.writeFileSync(authorityFile,JSON.stringify(binding));
 const state={enabled,missing:false,time:1000,instance:'instance-m4'};
 const authority={capture:async sourceId=>{a.equal(sourceId,'file_seed');return {binding:JSON.parse(fs.readFileSync(authorityFile,'utf8'))};},assert:(snapshot,sourceId)=>sourceId==='file_seed'&&JSON.stringify(snapshot.binding)===fs.readFileSync(authorityFile,'utf8')};
 const keys={snapshot:async()=>{if(state.missing)throw Object.assign(Error('key absent'),{code:'work_data_key.absent'});return {key:master,instanceId:state.instance,release(){}};}};
 const host={root:family,scopeId:manifest.scope,keys,enabled:async()=>state.enabled,writeJson:writer||useApi.atomicWriteJson,authority,now:()=>state.time};
 const make=()=>useApi.adapter.create(host),adapter=make();
 const issue=()=>adapter.put({sourceId:'file_seed',manifest,bytes});
 const change=(key,value)=>{const next=JSON.parse(fs.readFileSync(authorityFile,'utf8'));next[key]=value;fs.writeFileSync(authorityFile,JSON.stringify(next));};
 return {base,family,state,host,adapter,make,issue,manifest,bytes,change,authorityFile};
}
after(()=>{master.fill(0);a.equal(path.dirname(root),os.tmpdir());fs.rmSync(root,{recursive:true,force:true});});

test('real 13ba PNG persists through real chunk AEAD and atomic writer; cold adapter resolves durable authority',async()=>{
 const f=await fixture({large:true}),issued=await f.issue(),file=path.join(f.family,issued.id+'.json'),physical=fs.readFileSync(file,'utf8');
 a.ok(f.bytes.length>1024*1024);a.equal(JSON.parse(physical.split('\n')[0]).workData,3);a.ok(physical.split('\n').length>3);a.ok(!physical.includes(f.manifest.sourceHash));a.ok(!physical.includes(f.bytes.toString('base64')));
 const cold=load().adapter.create(f.host),borrow=await cold.read(issued.id);a.deepEqual(borrow.bytes,f.bytes);a.equal(borrow.manifest.payloadHash,f.manifest.payloadHash);a.equal(borrow.assert(),true);borrow.release();a.ok(borrow.bytes.every(v=>v===0));a.throws(()=>borrow.assert(),{code:'media_store.released'});
});
test('OFF preserves canonical plaintext record and sealed cold read still authenticates when switch becomes OFF',async()=>{
 const f=await fixture({enabled:false}),issued=await f.issue(),raw=fs.readFileSync(path.join(f.family,issued.id+'.json'),'utf8'),value=JSON.parse(raw);
 a.equal(value.schema,1);a.equal(value.data,f.bytes.toString('base64'));a.equal(raw,JSON.stringify(value));const b=await f.adapter.read(issued.id);a.deepEqual(b.bytes,f.bytes);b.release();
 const on=await fixture(),saved=await on.issue();on.state.enabled=false;const off=await on.make().read(saved.id);a.deepEqual(off.bytes,on.bytes);off.release();
});
test('missing key, wrong instance, ciphertext tamper and relocated record fail without changing stored bytes',async()=>{
 const f=await fixture(),issued=await f.issue(),file=path.join(f.family,issued.id+'.json'),before=fs.readFileSync(file);
 f.state.missing=true;await a.rejects(()=>f.adapter.read(issued.id),error);a.deepEqual(fs.readFileSync(file),before);f.state.missing=false;
 f.state.instance='different';await a.rejects(()=>f.adapter.read(issued.id),error);f.state.instance='instance-m4';
 const id='mimg_'+crypto.randomBytes(16).toString('hex');fs.copyFileSync(file,path.join(f.family,id+'.json'));await a.rejects(()=>f.adapter.read(id),error);
 const lines=before.toString().trimEnd().split('\n');const chunk=JSON.parse(lines[1]);chunk.e.envelope.ciphertext=(chunk.e.envelope.ciphertext[0]==='A'?'B':'A')+chunk.e.envelope.ciphertext.slice(1);lines[1]=JSON.stringify(chunk);fs.writeFileSync(file,lines.join('\n')+'\n');await a.rejects(()=>f.adapter.read(issued.id),error);
});
test('every source/policy/rules/processor/revocation binding is checked from durable current authority on cold read',async()=>{
 for(const key of ['sourceHash','sourceRevision','policyHash','policyRevision','rulesHash','processorHash','processorVersion','revocationRevision']){
  const f=await fixture(),issued=await f.issue();f.change(key,key.endsWith('Hash')?'f'.repeat(64):'changed');await a.rejects(()=>f.make().read(issued.id),error);
 }
});
test('borrow rechecks revocation and mutation; expiry prevents read',async()=>{
 const f=await fixture(),issued=await f.issue(),borrow=await f.adapter.read(issued.id);f.change('revocationRevision','r2');a.throws(()=>borrow.assert(),error);borrow.release();
 const g=await fixture(),saved=await g.issue(),b=await g.adapter.read(saved.id);b.bytes[0]^=1;a.throws(()=>b.assert(),{code:'media_store.payload'});b.release();g.state.time=g.manifest.expiresAt;await a.rejects(()=>g.adapter.read(saved.id),{code:'media_store.expired'});
});
test('no request path, scope substitution, extra manifest fields, malformed PNG or hash mismatch can be stored',async()=>{
 const f=await fixture();for(const id of ['../x','C:\\x','mimg_aa','mimg_'+'A'.repeat(32)])await a.rejects(()=>f.adapter.read(id),{code:'media_store.id'});
 for(const manifest of [{...f.manifest,scope:'other'},{...f.manifest,extra:'x'},{...f.manifest,width:999},{...f.manifest,payloadHash:'f'.repeat(64)}])await a.rejects(()=>f.adapter.put({sourceId:'file_seed',manifest,bytes:f.bytes}),error);
 const bad=Buffer.from(f.bytes);bad[bad.length-1]^=1;await a.rejects(()=>f.adapter.put({sourceId:'file_seed',manifest:{...f.manifest,payloadHash:fixtureApi.h(bad)},bytes:bad}),error);
 await a.rejects(()=>f.adapter.put({sourceId:'../source',manifest:f.manifest,bytes:f.bytes}),error);
});
test('strict plaintext cold parser rejects bad base64, altered manifest, long TTL, filename/source mismatch',async()=>{
 for(const mutate of [v=>v.data+='====',v=>v.manifest.mime='image/jpeg',v=>v.manifest.expiresAt=v.issuedAt+60001,v=>v.id='mimg_'+'0'.repeat(32),v=>v.sourceId='../x',v=>v.manifest.bytes++]){
  const f=await fixture({enabled:false}),issued=await f.issue(),file=path.join(f.family,issued.id+'.json'),v=JSON.parse(fs.readFileSync(file,'utf8'));mutate(v);fs.writeFileSync(file,JSON.stringify(v));await a.rejects(()=>f.make().read(issued.id),error);
 }
});
test('authority change while atomic writer awaits never produces a readable record; publication is exclusive',async()=>{
 const f=await fixture();f.host.writeJson=async(...args)=>{await api.atomicWriteJson(...args);f.change('policyRevision','p2');};const adapter=f.make();await a.rejects(()=>adapter.put({sourceId:'file_seed',manifest:f.manifest,bytes:f.bytes}),error);a.equal(fs.readdirSync(f.family).length,0);
});
test('bounded fallback uses one fd, rejects over-limit/growth/invalid UTF8 and old source negative control accepts oversize',async()=>{
 const file=path.join(root,'bounded.json'),host={file:()=>file,purpose:'cache',schema:1,scopeId:'scope',recordId:'record',keys:{unlock:async()=>master,instance:async()=>'instance'},enabled:async()=>false,writeJson:api.atomicWriteJson,chunked:true,maxPlaintextBytes:1024,maxFileBytes:16};
 fs.writeFileSync(file,' '.repeat(17));await a.rejects(()=>api.store.createText(host).read(),{code:'work_data_store.text_file_limit'});
 const old=load({storeCode:read('01p-work-data-store.js')});a.equal((await old.store.createText(host).read()).length,17,'old source negative control exposes missing bound');
 fs.writeFileSync(file,Buffer.from([0xff]));await a.rejects(()=>api.store.createText(host).read(),{code:'work_data_store.text_file_encoding'});
 fs.writeFileSync(file,'ok');const readFile=fsp.readFile;let called=false;fsp.readFile=async()=>{called=true;throw Error('must not use readFile');};try{a.equal(await api.store.createText(host).read(),'ok');a.equal(called,false);}finally{fsp.readFile=readFile;}
});
test('bounded fallback observes actual growth and truncation after stat on its same descriptor',async()=>{
 const file=path.join(root,'changing.json'),host={file:()=>file,purpose:'cache',schema:1,scopeId:'scope',recordId:'changing',keys:{unlock:async()=>master,instance:async()=>'instance'},enabled:async()=>false,writeJson:api.atomicWriteJson,chunked:true,maxPlaintextBytes:1024,maxFileBytes:16};
 for(const mutate of [()=>fs.appendFileSync(file,'x'),()=>fs.truncateSync(file,0)]){
  fs.writeFileSync(file,'ok');const originalOpen=fsp.open;let count=0;
  fsp.open=async(...args)=>{const handle=await originalOpen(...args);if(args[0]!==file||++count!==2)return handle;
   return {stat:async(...statArgs)=>{const stat=await handle.stat(...statArgs);if(statArgs[0]?.bigint)mutate();return stat;},read:(...v)=>handle.read(...v),close:()=>handle.close()};};
  try{await a.rejects(()=>api.store.createText(host).read(),{code:'work_data_store.text_file_changed'});}finally{fsp.open=originalOpen;}
 }
});
test('AEAD purpose, schema and scope are exact, even when inner JSON looks valid',async()=>{
 for(const change of [{purpose:'queue'},{schema:2},{scopeId:'other-scope'}]){
  const f=await fixture(),issued=await f.issue(),file=path.join(f.family,issued.id+'.json');const borrowed=await f.adapter.read(issued.id);borrowed.release();
  const value={schema:1,id:issued.id,issuedAt:1000,sourceId:'file_seed',revocationRevision:'r1',manifest:f.manifest,data:f.bytes.toString('base64')};
  fs.unlinkSync(file);await api.store.createText({file:()=>file,purpose:'cache',schema:1,scopeId:f.manifest.scope,recordId:issued.id,keys:f.host.keys,enabled:async()=>true,writeJson:api.atomicWriteJson,chunked:true,maxPlaintextBytes:api.adapter.LIMITS.MAX_TEXT,...change}).write(JSON.stringify(value));
  await a.rejects(()=>f.make().read(issued.id),error);
 }
});
test('exact three spans apply to both frozen Store baselines and reverse byte normalized identity',()=>{
 const spans=JSON.parse(fs.readFileSync(path.join(dir,'store-spans.json'),'utf8'));a.equal(spans.spans.length,3);a.equal(spans.privateBaselineSha256,'9308bcd32d7b85ea939728e1b5f122aac8a15adea7a8aa9375a972eababc9a74');
 for(const [file,expected]of [[path.join(dir,'src/01p-work-data-store.js'),spans.baselineLF],[path.join(dir,'private-9308-store-after.js'),null]]){
  let value=fs.readFileSync(file,'utf8');for(const span of spans.spans.slice().reverse()){a.equal(value.split(span.after).length,2);value=value.replace(span.after,span.before);}if(expected)a.equal(fixtureApi.h(value),expected);
 }
});