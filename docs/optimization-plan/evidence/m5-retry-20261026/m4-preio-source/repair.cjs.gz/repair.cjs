'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const dir=__dirname,span=JSON.parse(fs.readFileSync(path.join(dir,'put-precheck-span.json'),'utf8'));
const original=fs.readFileSync('C:/Users/87179/AppData/Local/Temp/ruyi-m4-derived-store-boolean-20261026-b90f702a/src/13bb-media-derived-store.js','utf8');
if(sha(original)!==span.baselineSha256||original.split(span.before).length!==2)throw Error('prior module pin/unique anchor changed');
const candidate=original.replace(span.before,span.after);
if(sha(candidate)!==span.candidateSha256||candidate.split(span.after).length!==2||candidate.replace(span.after,span.before)!==original)throw Error('candidate pin/inverse');
fs.writeFileSync(path.join(dir,'src/13bb-media-derived-store.js'),candidate);
console.log(JSON.stringify({oneSpan:true,rawInverseExact:true,sha256:sha(candidate)}));