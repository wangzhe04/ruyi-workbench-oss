'use strict';const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict'),c=require('node:crypto'),H=b=>c.createHash('sha256').update(b).digest('hex'),old='C:/Users/87179/AppData/Local/Temp/ruyi-k1-observer-fix-20261026-7549454f',out=__dirname,before=fs.readFileSync(p.join(old,'13aq-work-data-native-adapters.js'),'utf8');a.equal(H(before),'099588f4a6b187c12ee480bb074688544f2df66e45779899e7cac442dae8e8d0');const start=before.indexOf('    function latch(cause) {'),end=before.indexOf('    const check =',start),eol=before.includes('\r\n')?'\r\n':'\n';const replacement=`    function latch(cause) {
      const isProxy = require('node:util').types.isProxy, active = new Set(), done = new Set();
      let nodes = 0;
      function observe(value, depth = 0) {
        if (!value || typeof value !== 'object' && typeof value !== 'function') return false;
        if (isProxy(value) || active.has(value)) return true;
        if (done.has(value)) return false;
        if (depth >= 16 || ++nodes > 128) return true;
        active.add(value);
        try {
          if (Array.isArray(value)) {
            const length = Object.getOwnPropertyDescriptor(value,'length');
            if (!length || !Object.hasOwn(length,'value') || !Number.isSafeInteger(length.value) || length.value < 0 || length.value > 64) return true;
            for (let i = 0; i < length.value; i++) {
              const item = Object.getOwnPropertyDescriptor(value,String(i));
              if (!item || !Object.hasOwn(item,'value') || observe(item.value,depth+1)) return true;
            }
          }
          let prototype = value;
          for (let level = 0; prototype !== null; level++) {
            if (level >= 16 || isProxy(prototype)) return true;
            for (const name of ['helperMayStillRun','cause','errors']) {
              const descriptor = Object.getOwnPropertyDescriptor(prototype,name);
              if (!descriptor) continue;
              if (!Object.hasOwn(descriptor,'value')) return true;
              if (name === 'helperMayStillRun') {
                if (descriptor.value !== undefined && descriptor.value !== false) return true;
              } else if (name === 'cause') {
                if (observe(descriptor.value,depth+1)) return true;
              } else {
                const errors = descriptor.value;
                if (!errors || isProxy(errors) || !Array.isArray(errors) || observe(errors,depth+1)) return true;
              }
            }
            prototype = Object.getPrototypeOf(prototype);
          }
          done.add(value); return false;
        } finally { active.delete(value); }
      }
      try {
        if (observe(cause) || bindings.helperMayStillRun() !== false) unknown = true;
      } catch { unknown = true; }
      return unknown;
    }
`.replace(/\n/g,eol);const after=before.slice(0,start)+replacement+before.slice(end);a.equal(after.replace(replacement,before.slice(start,end)),before);fs.writeFileSync(p.join(out,'13aq-work-data-native-adapters.js'),after,{flag:'wx'});fs.writeFileSync(p.join(out,'span.json'),JSON.stringify({beforeSha256:H(before),afterSha256:H(after),spans:[{name:'complete-prototype-and-array-graph',before:before.slice(start,end),after:replacement}],inverseExact:true},null,2),{flag:'wx'});
for(const file of ['adapters-pure.test.cjs','independent-counterexamples.test.cjs','observer-and-cleanup.test.cjs']){const test=fs.readFileSync(p.join(old,file),'utf8').split(old).join(out);fs.writeFileSync(p.join(out,file),test,{flag:'wx'});}fs.copyFileSync(p.join(old,'spans.json'),p.join(out,'prior-nine-spans.json'),fs.constants.COPYFILE_EXCL);fs.copyFileSync(p.join(old,'13aq-work-data-native-adapters.js'),p.join(out,'base-0995.js'),fs.constants.COPYFILE_EXCL);
const capsule=fs.readFileSync('C:/Users/87179/AppData/Local/Temp/ruyi-k1-independent-new-20261026/counter.cjs','utf8');fs.writeFileSync(p.join(out,'capsule-original-counter.cjs'),capsule,{flag:'wx'});const adapted=capsule.split(old).join(out).replace("a.equal(observed,4,'all four independently missing edges reproduce unknown ownership release')","a.equal(observed,0,'all four missing graph edges now retain owner')").replace('COUNTERS_CONFIRMED4_ACTUAL_RUNVERIFIER_UNKNOWN_LOSS_NOT_A_DIRECT_FLAG_CONSUMER','ALL4_GRAPH_EDGES_FIXED_WITH_OWNCAUSE_CONTROL');a.notEqual(adapted,capsule);fs.writeFileSync(p.join(out,'capsule-fixed-contract.cjs'),adapted,{flag:'wx'});console.log(JSON.stringify({source:H(after),bytes:Buffer.byteLength(after)}));
