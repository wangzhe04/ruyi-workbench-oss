'use strict';
const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),p=require('node:path'),vm=require('node:vm'),{EventEmitter}=require('node:events');
const source=fs.readFileSync('C:/Users/87179/AppData/Local/Temp/ruyi-k1-graph-fix-20261026-84f3af71/13aq-work-data-native-adapters.js','utf8');
const K=vm.runInNewContext(source+'\nWorkDataNativeAdapters;',{require,process,Buffer,setTimeout,clearTimeout,setInterval});
function setup(error){let released=0,held=0;const target=p.join(process.env.TEMP,'k1-synthetic-target').toLowerCase(),owner={roots:[target],release:async()=>{released++;}};
const authority={generation:1,id:'c'.repeat(48),mode:'encrypted',proof:{sha256:'d'.repeat(64)}};
const bindings={ownership:{acquire:async()=>owner,canonicalRoot:async x=>x},manifest:{create:()=>({readActive:async()=>authority})},fullSnapshot:{create:()=>({seal:async()=>{throw error;},restore:async()=>{throw error;}})},nativePublish:{createFlush:()=>async()=>{throw error;}},disposableTree:{create:()=>async()=>true},protector:{supported:()=>true,run:async()=>{throw error;}},capturePreserved:async()=>{},externalOwner:()=>{},skillOwner:()=>{},resultOwner:{},migrationHost:{create:()=>({})},worker:{create:()=>({}),spawnCold:()=>{},processChannel:()=>{}},writeJson:()=>{},appVersion:'3.1',helperMayStillRun:()=>false};
const adapter=K.create({bindings,proc:{pid:123,env:{}},clock:{setTimeout,clearTimeout,setInterval:()=>{held++;return{};}}});
const request={schema:1,kind:'verify-full',id:'a'.repeat(48),nonce:'b'.repeat(64),parentPid:122,target,password:'synthetic password',generation:1};
const channel={parentConnected:()=>true,parentPid:()=>122,readInput:async()=>Buffer.from(JSON.stringify(request)),send:async()=>{throw Error('never send on failure');}};
return{adapter,channel,target,counts:()=>({released,held})};}
const unknown=()=>Object.assign(Error('synthetic helper unknown'),{helperMayStillRun:true});
test('direct cause unknown latches and retains owner positive control',async()=>{const x=setup(Error('wrapper',{cause:unknown()}));await a.rejects(x.adapter.runVerifier(x.channel));a.equal(x.adapter.helperMayStillRun(),true);a.deepEqual(x.counts(),{released:0,held:1});});
test('AggregateError secondary unknown must permanently latch and retain owner',async()=>{const x=setup(new AggregateError([Error('primary known'),unknown()],'both failed',{cause:Error('primary known')}));await a.rejects(x.adapter.runVerifier(x.channel));a.equal(x.adapter.helperMayStillRun(),true);a.deepEqual(x.counts(),{released:0,held:1});});
test('foreign helper flag getter must not execute while observing cleanup uncertainty',async()=>{let calls=0;const error=Error('foreign');Object.defineProperty(error,'helperMayStillRun',{get(){calls++;return false;}});const x=setup(error);await a.rejects(x.adapter.flush([x.target]));a.equal(calls,0);a.equal(x.adapter.helperMayStillRun(),true);});
test('own false flag cannot hide nested aggregate unknown',async()=>{const error=Object.assign(new AggregateError([unknown()],'secondary'),{helperMayStillRun:false}),x=setup(error);await a.rejects(x.adapter.flush([x.target]));a.equal(x.adapter.helperMayStillRun(),true);});
