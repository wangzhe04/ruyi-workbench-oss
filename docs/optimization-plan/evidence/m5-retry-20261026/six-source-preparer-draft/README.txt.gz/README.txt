DRAFT ONLY. FINAL_SPEC_SHA256=null; ready=false. Do not call prepare modes.
Read author-report.json and spec.template.json. Root must finalize exact six-source/preparer approval and spec hash in a NEW reviewed identity.
Future source preparation: node prepare-six-source.draft.cjs --prepare-source <final-spec.json> <NEW originalTEMP/r31m-run>
Root then uses unchanged official builder. Future inputs only: --derive-inputs <same-final-spec.json> <same-owned-run>
Both actions are prohibited in this draft. Original native/driver/NTFS failures are retained.
