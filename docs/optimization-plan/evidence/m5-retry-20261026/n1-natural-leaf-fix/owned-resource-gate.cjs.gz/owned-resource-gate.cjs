'use strict';
// Preparation artifact only. Native execution requires the explicit execute switch.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),vm=require('node:vm'),cp=require('node:child_process'),assert=require('node:assert/strict');
const hash=value=>crypto.createHash('sha256').update(value).digest('hex'),inputPin='efae67ff4675fc84d78fec596f961d4a88503cd19529a05a55925792776ea48f';
function noAlias(file){file=path.resolve(file);const parts=[];let current=file;for(;;){parts.push(current);const parent=path.dirname(current);if(parent===current)break;current=parent;}for(const part of parts.reverse()){const stat=fs.lstatSync(part);assert.equal(stat.isSymbolicLink(),false,'no reparse ancestor');assert.equal(fs.realpathSync.native(part).toLowerCase(),part.toLowerCase(),'physical path exact');}return file;}
function verify(){noAlias(__dirname);const bytes=fs.readFileSync(path.join(__dirname,'inputs.json'));assert.equal(hash(bytes),inputPin);const inputs=JSON.parse(bytes);for(const row of inputs.members){assert.equal(path.basename(row.file),row.file);const file=path.join(__dirname,row.file);noAlias(file);const value=fs.readFileSync(file);assert.equal(value.length,row.bytes);assert.equal(hash(value),row.sha256);}const spans=JSON.parse(fs.readFileSync(path.join(__dirname,'fault-spans.json')));for(const row of spans){let value=fs.readFileSync(path.join(__dirname,'native-'+row.variant+'-fault.cs'),'utf8');assert.equal(hash(value),row.after);for(const span of row.spans.toReversed()){assert.equal(value.split(span.after).length,2);value=value.replace(span.after,span.before);}assert.equal(hash(value),row.before);assert.equal(value,fs.readFileSync(path.join(__dirname,'native-'+row.variant+'.cs'),'utf8'));}return inputs;}
const errorInfo=error=>error?{code:typeof error.code==='string'?error.code:null,helperMayStillRun:error.helperMayStillRun===true}:null;
function identity(file){noAlias(file);const s=fs.lstatSync(file,{bigint:true});assert.equal(s.isFile(),true);return{dev:String(s.dev),ino:String(s.ino),size:String(s.size),nlink:String(s.nlink)};}
function writeProbe(file){let fd;try{fd=fs.openSync(file,'r+');return{opened:true};}catch(error){return{opened:false,code:error.code};}finally{if(fd!==undefined)fs.closeSync(fd);}}
async function execute(){
 assert.equal(process.platform,'win32');const inputs=verify(),temp=noAlias(os.tmpdir());const root=fs.mkdtempSync(path.join(temp,'r31-n1-'));noAlias(root);assert.ok(root.length<125,'short controlled root');const rootId=fs.lstatSync(root,{bigint:true}),allChildren=[],results=[];let failure=null,released=false;
 const own=()=>{noAlias(root);const s=fs.lstatSync(root,{bigint:true});assert.equal(s.dev,rootId.dev);assert.equal(s.ino,rootId.ino);};
 const write=(name,data)=>{own();assert.equal(path.basename(name),name);fs.writeFileSync(path.join(root,name),JSON.stringify(data,null,2)+'\n',{flag:'wx'});own();};
 write('ownership-retained.json',{schema:1,root,rootId:{dev:String(rootId.dev),ino:String(rootId.ino)},inputPin,retained:true});
 const before=fs.readFileSync(path.join(__dirname,'native-before.cs'),'utf8'),brokerCode=fs.readFileSync(path.join(__dirname,'approved-v3-broker.js'),'utf8');
 async function session(label,native,work){
   own();const original=cp.spawn,children=[];let broker,primary,commandFailed=false,closeError,api;
   cp.spawn=function(command,args,options){
     assert.equal(command,'powershell.exe');assert.equal(hash(Buffer.from(options.env.RUYI_SKILL_CAPSULE_SOURCE,'base64')),inputs.nativePins[0]);
     const changed={...options,env:{...options.env,RUYI_SKILL_CAPSULE_SOURCE:Buffer.from(native).toString('base64')}};
     assert.deepEqual(Object.entries({...changed.env,RUYI_SKILL_CAPSULE_SOURCE:options.env.RUYI_SKILL_CAPSULE_SOURCE}),Object.entries(options.env));
     const child=Reflect.apply(original,this,[command,args,changed]),row={label,pid:child.pid,spawn:false,exit:false,close:false,nativeSha256:hash(native)};children.push(row);allChildren.push(row);
     child.once('spawn',()=>{row.spawn=true;});child.once('exit',(code,signal)=>{row.exit=true;row.exitCode=code;row.exitSignal=signal;});child.once('close',(code,signal)=>{row.close=true;row.closeCode=code;row.closeSignal=signal;});return child;
   };
   try{
     api=vm.runInNewContext(brokerCode,{require,process,Buffer,MIGRATION_SKILL_CAPSULE_NATIVE:before});broker=await api.broker();
     try{await work(broker,children);}catch(error){primary=error;commandFailed=true;}
   }catch(error){primary=error;commandFailed=true;}
   finally{try{if(broker)await broker.close();}catch(error){closeError=error;}cp.spawn=original;}
   const record={label,commandFailed,command:errorInfo(primary),closeError:errorInfo(closeError),helperMayStillRun:api?.helperMayStillRun()!==false,children};results.push(record);write(label+'-terminal.json',record);
   assert.equal(children.length,1);for(const row of children){assert.equal(row.spawn,true);assert.equal(row.exit,true);assert.equal(row.close,true);assert.equal(row.exitCode,0);assert.equal(row.closeCode,0);}assert.equal(record.helperMayStillRun,false);assert.notEqual(primary?.helperMayStillRun,true);assert.notEqual(closeError?.helperMayStillRun,true);
   return{primary,commandFailed,closeError,record};
 }
 try{
   const source=path.join(root,'source');fs.mkdirSync(source);const data=Buffer.from('N1 owned DATA\n\0\xff','binary'),ads=Buffer.from('N1 owned alternate stream\n');fs.writeFileSync(path.join(source,'fault.bin'),data,{flag:'wx'});fs.writeFileSync(path.join(source,'fault.bin:ruyi_n1:$DATA'),ads,{flag:'wx'});const revision='6'.repeat(64);let snapshot;
   const captured=await session('capture-owned-source',before,async broker=>{snapshot=await broker.command({cmd:'capture-preserved',root:source,revision});});assert.equal(captured.commandFailed,false);assert.equal(captured.closeError,undefined);assert.equal(snapshot.platform,'ntfs-objects-v1');assert.ok(snapshot.entries.some(x=>x.rel==='fault.bin'));write('source-snapshot-identity.json',{revision,entryCount:snapshot.entries.length,snapshotSha256:hash(JSON.stringify(snapshot)),metadata:Array.from(snapshot.entries).slice(0,2).map(e=>({rel:typeof e.rel==='string'?e.rel.slice(0,64):null,id:typeof e.id==='string'?e.id.slice(0,24):null,dir:e.dir===true,attrs:Number.isSafeInteger(e.attrs)?e.attrs:null,shortName:typeof e.shortName==='string'?e.shortName.slice(0,16):null,times:Array.from(e.times).slice(0,4).map(x=>typeof x==='string'?x.slice(0,20):null),streams:Array.from(e.streams).slice(0,2).map(x=>({name:typeof x.name==='string'?x.name.slice(0,64):null,size:Number.isSafeInteger(x.size)?x.size:null,hash:typeof x.hash==='string'?x.hash.slice(0,64):null}))}))});
   const logical=s=>Array.from(s.entries,e=>({rel:e.rel,dir:e.dir,attrs:e.attrs,times:Array.from(e.times),shortName:e.shortName,streams:Array.from(e.streams,x=>({name:x.name,size:x.size,hash:x.hash,data:x.data})).sort((a,b)=>a.name.localeCompare(b.name))})).sort((a,b)=>a.rel.localeCompare(b.rel));
   for(const variant of ['before','after']){
     const parent=path.join(root,variant+'-fault-parent');fs.mkdirSync(parent);const target=path.join(parent,'source'),leaf=path.join(target,'fault.bin'),native=fs.readFileSync(path.join(__dirname,'native-'+variant+'-fault.cs'),'utf8');let preId,preProbe;
     const observed=await session(variant+'-fault',native,async(broker,children)=>{
       let error,failed=false;try{await broker.command({cmd:'create-owned-portable',root:target,revision,snapshot});}catch(cause){error=cause;failed=true;}
       assert.equal(failed,true);assert.equal(error.code,'work_data_backup.n1_owned_fault_before_id');assert.equal(children[0].exit,false,'write probe precedes helper exit');assert.equal(children[0].close,false,'write probe precedes helper close');
       preId=identity(leaf);assert.equal(preId.nlink,'1');preProbe=writeProbe(leaf);assert.deepEqual(identity(leaf),preId);write(variant+'-before-close.json',{preId,preProbe,helperStillOpen:!children[0].close});throw error;
     });
     assert.equal(observed.commandFailed,true);assert.equal(observed.primary.code,'work_data_backup.n1_owned_fault_before_id');assert.equal(observed.closeError?.code,'work_data_backup.n1_owned_fault_before_id');assert.ok(preId);assert.deepEqual(identity(leaf),preId);
     const postProbe=writeProbe(leaf);assert.equal(postProbe.opened,true,'same file is writable after actual terminal');assert.deepEqual(identity(leaf),preId);write(variant+'-after-close.json',{preId,preProbe,postProbe,rootPreserved:fs.statSync(target).isDirectory()});
     if(variant==='before'){assert.equal(preProbe.opened,false,'unfixed strong-held unregistered handle must deny parent write');assert.ok(['EACCES','EPERM','EBUSY'].includes(preProbe.code));}else assert.equal(preProbe.opened,true,'fixed catch must dispose unregistered handle before negative ACK');
   }
   for(const variant of ['before','after']){
     const parent=path.join(root,variant+'-normal-parent');fs.mkdirSync(parent);const target=path.join(parent,'source'),native=fs.readFileSync(path.join(__dirname,'native-'+variant+'.cs'),'utf8');let created;
     const observed=await session(variant+'-normal',native,async broker=>{created=await broker.command({cmd:'create-owned-portable',root:target,revision,snapshot});});assert.equal(observed.commandFailed,false);assert.equal(observed.closeError,undefined);assert.deepEqual(logical(created),logical(snapshot));const ids=created.entries.map(x=>x.id);assert.equal(new Set(ids).size,ids.length);assert.ok(ids.every(id=>/^[a-f0-9]{24}$/.test(id)));assert.ok(created.entries.every(e=>e.id!==snapshot.entries.find(x=>x.rel===e.rel).id));assert.deepEqual(fs.readFileSync(path.join(target,'fault.bin')),data);assert.deepEqual(fs.readFileSync(path.join(target,'fault.bin:ruyi_n1:$DATA')),ads);assert.equal(writeProbe(path.join(target,'fault.bin')).opened,true);write(variant+'-normal-identity.json',{entryCount:created.entries.length,snapshotSha256:hash(JSON.stringify(created)),ids,DATA:hash(data),ADS:hash(ads),allMetadataAndContentExact:true});
   }
   assert.equal(allChildren.length,5);own();for(const row of allChildren){assert.equal(row.spawn&&row.exit&&row.close,true);assert.equal(row.exitCode,0);assert.equal(row.closeCode,0);}write('ownership-released.json',{schema:1,inputPin,allActualTerminal:true,helperMayStillRun:false,targetsRetained:true});released=true;
 }catch(error){failure=errorInfo(error);if(!failure?.code)failure={...failure,code:'N1_GATE_ASSERTION_OR_PREPARATION_FAILED'};}
 const report={schema:1,root,inputPin,success:failure===null,failure,ownershipRetained:!released,targetsRetained:true,children:allChildren,results,scope:'Owned Windows resource-only gate; not production, full native support, NativePath or JS cleanup acceptance'};write('actual-result.json',report);console.log(JSON.stringify(report,null,2));if(failure)process.exitCode=1;return report;
}
if(require.main===module){if(process.argv.length===3&&process.argv[2]==='--verify-source-only'){verify();console.log('N1 GATE SOURCE ONLY VERIFIED; NO NATIVE EXECUTED');}else if(process.argv.length===3&&process.argv[2]==='--execute-owned-windows'){execute().catch(error=>{console.error(errorInfo(error));process.exitCode=1;});}else{console.error('Use --verify-source-only. Root serial execution after independent review: --execute-owned-windows');process.exitCode=2;}}
module.exports={verify,execute};
