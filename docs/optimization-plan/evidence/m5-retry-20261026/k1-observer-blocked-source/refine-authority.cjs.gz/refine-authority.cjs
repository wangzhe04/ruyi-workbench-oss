'use strict';const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict'),c=require('node:crypto'),H=b=>c.createHash('sha256').update(b).digest('hex'),file=p.join(__dirname,'13aq-work-data-native-adapters.js'),proof=p.join(__dirname,'spans.json');let source=fs.readFileSync(file,'utf8');const spans=JSON.parse(fs.readFileSync(proof));const E=source.includes('\r\n')?'\r\n':'\n';function patch(name,before,after){before=before.replace(/\n/g,E);after=after.replace(/\n/g,E);a.equal(source.split(before).length-1,1,name);source=source.replace(before,after);spans.spans.push({name,before,after});}
patch('observe-errors-container',`            const length = Object.getOwnPropertyDescriptor(errors,'length');`,`            if (observe(errors,depth+1)) return true;
            const length = Object.getOwnPropertyDescriptor(errors,'length');`);
patch('authority-cleanup-primary-state',`      const handle = await io.open(file,'r'); let bytes;
      try {`,`      const handle = await io.open(file,'r'); let bytes, primary, failed = false;
      try {`);
patch('authority-buffer-scope',`        const buffer = Buffer.alloc(Number(before.size) + 1); let used = 0;`,`        const buffer = Buffer.alloc(Number(before.size) + 1); bytes = buffer; let used = 0;`);
patch('authority-independent-cleanup',`      } finally { bytes?.fill(0); await handle.close(); }
    }); }`,`      } catch(error) { failed = true; primary = error; throw error; }
      finally {
        const cleanup = [];
        try { bytes?.fill(0); } catch(error) { cleanup.push(error); }
        try { await handle.close(); } catch(error) { cleanup.push(error); }
        if (cleanup.length) {
          const causes = failed ? [primary,...cleanup] : cleanup;
          for (const cause of causes) latch(cause);
          throw Object.assign(new AggregateError(causes,'work_data_adapter.authority_cleanup_failed',{cause:causes[0]}), {
            code:'work_data_adapter.authority_cleanup_failed',retry:false,...(latch(null) ? {helperMayStillRun:true} : {}),
          });
        }
      }
    }); }`);
let inverse=source;for(const s of [...spans.spans].reverse()){a.equal(inverse.split(s.after).length-1,1,s.name);inverse=inverse.replace(s.after,s.before);}a.equal(H(inverse),spans.beforeSha256);spans.afterSha256=H(source);fs.writeFileSync(file,source);fs.writeFileSync(proof,JSON.stringify(spans,null,2));console.log(JSON.stringify({sha:H(source),bytes:Buffer.byteLength(source),spans:spans.spans.length}));
