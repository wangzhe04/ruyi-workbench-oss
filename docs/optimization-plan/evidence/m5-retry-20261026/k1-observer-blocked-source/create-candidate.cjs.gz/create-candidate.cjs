'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),a=require('node:assert/strict');const old='C:/Users/87179/AppData/Local/Temp/ruyi-m3-k1-adapters-20261026-798a69d7',out=__dirname,H=b=>c.createHash('sha256').update(b).digest('hex');
const original=fs.readFileSync(p.join(old,'files/ruyi-workbench/app/src/13aq-work-data-native-adapters.js'),'utf8');a.equal(H(original),'0ade4b57e56f6a4d6e76a9859ad1efb173daee4c48c736b1b999a97e003abb48');const eol=original.includes('\r\n')?'\r\n':'\n';let source=original;const spans=[];const patch=(name,before,after)=>{before=before.replace(/\n/g,eol);after=after.replace(/\n/g,eol);a.equal(source.split(before).length-1,1,name);source=source.replace(before,after);spans.push({name,before,after});};
const start=source.indexOf('    function latch(cause) {'),end=source.indexOf('    const check =',start);
patch('bounded-uncertainty-observer',source.slice(start,end).replace(/\r\n/g,'\n'),`    function latch(cause) {
      const isProxy = require('node:util').types.isProxy, active = new Set(), done = new Set();
      let nodes = 0;
      function observe(value, depth = 0) {
        if (!value || typeof value !== 'object' && typeof value !== 'function') return false;
        if (isProxy(value) || depth >= 16 || ++nodes > 128 || active.has(value)) return true;
        if (done.has(value)) return false;
        active.add(value);
        try {
          let prototype = value;
          for (let level = 0; prototype !== null; level++) {
            if (level >= 16 || isProxy(prototype)) return true;
            const flag = Object.getOwnPropertyDescriptor(prototype,'helperMayStillRun');
            if (flag && (!Object.hasOwn(flag,'value') || flag.value !== undefined && flag.value !== false)) return true;
            prototype = Object.getPrototypeOf(prototype);
          }
          for (const name of ['cause','errors']) {
            const descriptor = Object.getOwnPropertyDescriptor(value,name);
            if (!descriptor) continue;
            if (!Object.hasOwn(descriptor,'value')) return true;
            if (name === 'cause') { if (observe(descriptor.value,depth+1)) return true; continue; }
            const errors = descriptor.value;
            if (!errors || isProxy(errors) || !Array.isArray(errors)) return true;
            const length = Object.getOwnPropertyDescriptor(errors,'length');
            if (!length || !Object.hasOwn(length,'value') || !Number.isSafeInteger(length.value) || length.value < 0 || length.value > 64) return true;
            for (let i = 0; i < length.value; i++) {
              const item = Object.getOwnPropertyDescriptor(errors,String(i));
              if (!item || !Object.hasOwn(item,'value') || observe(item.value,depth+1)) return true;
            }
          }
          done.add(value); return false;
        } finally { active.delete(value); }
      }
      try {
        if (observe(cause) || bindings.helperMayStillRun() !== false) unknown = true;
      } catch { unknown = true; }
      return unknown;
    }
`);
patch('guard-read-authority-start',`    async function readAuthority(base) {
      check(); const value = await bindings.manifest.create({base}).readActive();`,`    async function readAuthority(base) { return guarded(async () => {
      const value = await bindings.manifest.create({base}).readActive();`);
patch('guard-read-authority-end',`      } finally { bytes?.fill(0); await handle.close(); }
    }
    async function runVerifier`,`      } finally { bytes?.fill(0); await handle.close(); }
    }); }
    async function runVerifier`);
patch('verifier-primary-state',`      const bytes = await channel.readInput(INPUT_LIMIT); let request, owner, active = false;
      try {
        if (!Buffer.isBuffer(bytes)`,`      let bytes, request, owner, active = false, primary, failed = false;
      try {
        bytes = await guarded(() => channel.readInput(INPUT_LIMIT));
        if (!Buffer.isBuffer(bytes)`);
patch('verifier-independent-cleanup',`      } catch(error) { latch(error); throw error; }
      finally {
        if (Buffer.isBuffer(bytes)) bytes.fill(0); if (request) request.password = null;
        if (owner && !latch(null)) { active = false; await owner.release(); }
        else if (owner && heldTimer === null) heldTimer = clock.setInterval(() => {},60000);
      }`,`      } catch(error) { failed = true; primary = error; latch(error); throw error; }
      finally {
        const cleanup = [];
        const record = error => { cleanup.push(error); latch(error); };
        try { if (Buffer.isBuffer(bytes)) bytes.fill(0); } catch(error) { record(error); }
        try { if (request) request.password = null; } catch(error) { record(error); }
        if (owner && !latch(null)) {
          try { await owner.release(); active = false; }
          catch(error) { record(error); unknown = true; }
        }
        if (owner && active && heldTimer === null) {
          try { heldTimer = clock.setInterval(() => {},60000); }
          catch(error) { record(error); unknown = true; }
        }
        if (cleanup.length) {
          const causes = failed ? [primary,...cleanup] : cleanup;
          throw Object.assign(new AggregateError(causes,'work_data_adapter.verifier_cleanup_failed',{cause:causes[0]}), {
            code:'work_data_adapter.verifier_cleanup_failed', retry:false, ...(latch(null) ? {helperMayStillRun:true} : {}),
          });
        }
      }`);
let inverse=source;for(const span of [...spans].reverse()){a.equal(inverse.split(span.after).length-1,1,span.name);inverse=inverse.replace(span.after,span.before);}a.equal(inverse,original);
fs.writeFileSync(p.join(out,'13aq-work-data-native-adapters.js'),source,{flag:'wx'});fs.writeFileSync(p.join(out,'spans.json'),JSON.stringify({beforeSha256:H(original),afterSha256:H(source),spans,inverseExact:true},null,2),{flag:'wx'});
const originalTest=fs.readFileSync(p.join(old,'adapters-pure.test.cjs'),'utf8');fs.writeFileSync(p.join(out,'adapters-pure.test.cjs'),originalTest.replace("p.join(__dirname,'files/ruyi-workbench/app/src/13aq-work-data-native-adapters.js')","p.join(__dirname,'13aq-work-data-native-adapters.js')"),{flag:'wx'});
const counter=fs.readFileSync('C:/Users/87179/AppData/Local/Temp/ruyi-k1-independent-20261026-3c04055f/independent-counterexamples.test.cjs','utf8');fs.writeFileSync(p.join(out,'independent-counterexamples.test.cjs'),counter.replace('C:/Users/87179/AppData/Local/Temp/ruyi-m3-k1-adapters-20261026-798a69d7/files/ruyi-workbench/app/src/13aq-work-data-native-adapters.js',p.join(out,'13aq-work-data-native-adapters.js').replace(/\\/g,'/')),{flag:'wx'});console.log(JSON.stringify({source:H(source),bytes:Buffer.byteLength(source),spans:spans.length}));
