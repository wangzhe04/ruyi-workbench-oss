# M3 preserved-read 有界诊断（只读源码 + 无 native 轻纯）

2026-10-26。未改仓库、build、native、协议或角色预算；未启动 helper/socket/browser/live；原失败树、before及时间均保留。已读 CLAUDE、CONTRIBUTING、92§12.24–26；仓库及已检查祖先无 AGENTS。Node v24.14.0。新证据在本目录 count-proof.cjs / count-proof.json。

## 实际身份与journal

PRIVATE server b2f7f89a80286ce080d0588f7837ec7a487ad44df8d88b00828fbd41608d9d8d；旧server e1b925d187aae2d6c948676b026f74761dd3bd78d66b96814613898a9a0aa31a。
新native491cee21c881189594c105141675b51088e62b850078dbec58d7305fc8b3bdc8（实际角色stdout所绑定身份，未调用native）。

实际 stdout journal：

|角色|B1dJYe helpers / DPAPI /其余|HbovwZ helpers / DPAPI /其余|增加|
|---|---|---|---|
|seed|0 / 0 / 0|0 / 0 / 0|0|
|mode0|66 / 6 / 60|54 / 6 / 48|12|
|mode1|93 / 9 / 84|59 / 9 / 50|34|
|mode2|102 / 10 / 92|62 / 10 / 52|40|

所有上述实际记录exit/close/code/closeCode均0。其余栏是“没有DPAPI标签”，不能称逐PID已记录capture-preserved。driver observeHelpers/observeOperations（30、97行）只保存pid/终态和DPAPI首行标签；没有native verb、时间、root或stack。故本报告不编造逐PID映射。具体原journal SHA和完整源码SHA写入 count-proof.json。
旧restore58（DPAPI11）、cold-restored2（DPAPI1）通过；新restore stdout没有成功终态清单，外层250秒超时退出1。因此这次整体失败是预算终止，不能改写成metadata断言失败，也不能声称失败角色helpers已全部清点。

## 精确真实源码闭包与次数

以下行为均针对 r31m-a61cf3/runtime/app/src，行号以该冻结输入为准。

1. 01aa createPreserved.census:268–317，每次270与304各调用一次capturePreserved；最终native close后只owner assertion，不重开文件。capture:321–331调用census一次，所以=2；verify:333–345调用census一次，所以=2；fingerprint及同步assert不发native。
2. 13u migrationCapsuleCapturePreserved:2000–2004，每次创建broker，command capture-preserved，再finally close；broker于1786启动PowerShell。单次该adapter调用对应一个helper，未做native合批。
3. 01aa checkedCapturedFile:34–36调用capture.verify；readCapturedFile:60–63调用checked；verifyCapturedFile:65也调用checked。01p withCapturedFile:148–174在bridge.read之后先verify，再work，之后再verify。因此一个成功captured store read有3次完整tree.verify，=6 native helper。borrow本身仅owner、路径、hash、copy，无native。
4. HostV4 01ad:59 sourceTree切到preserved。checkSource:154–171每次sourceTree.capture(base)=2。成功普通transition有5次调用：209初始、216 candidate、222 key-ready、246 prepare末、251 publish前，合计10；209另capture(expected.root)=2。固定新增共12。
5. 01ad existingSpecial:228–231完整base capture与末端verify分别2，共4。229 readCaptured用Store capturedFile lease，因此每次callback新增6。13u collectPortable:3812–3852先读catalog、relocation，再逐个旧generation binding；该空特殊根无representation/history/object。mode1拥有catalog+relocation+1旧binding=3次，mode2拥有前两项+2旧binding=4次。因此对应新增18/24。
6. 合计mode0=12；mode1=12+4+3×6=34；mode2=12+4+4×6=40，与实际差逐角色一致。该公式是实际source闭包推导与journal交叉吻合；由于journal缺标签，不能称逐PID唯一因果证明。
7. 01ab full seal:280–287本来就preserved capture+三次verify（=8）；207借external credential source lease，13y:216–242 readCapturedFile+verifyCapturedFile（=4）。这几模块新旧逐文件SHA完全相同，所以不能把既有成本再次算作Host新增。

相同SHA：01p 9308bcd32d7b85ea939728e1b5f122aac8a15adea7a8aa9375a972eababc9a74；01aa fcfbed6b129887b2e0766b56041964da25b3858fcb62168ffbbc800e6e501c8c；01ab 92b8650db59e74c7ad71297c2d11e4f1943769243a782018487a1f216ecce269；13y ad2dc2ed042eb0952a822a7963b50696a6672d80ed2cd11b48d17859c3638c51。
Host新9f00d87b7184cd77dac7397c29313773091b6ad8180b025117ef512c6670fd12、旧cba97dea06ec29e6b77550c1a3dad92d5733e9e583d9aac5935b258076ae8bd6；13u新887d9aea7ba297b99c42cd2b873f2403bb52154d02db74c6d87d22f7731b2ee6、旧02d2edd58e4463723e592f1ba56a64b718c903382541b436aa14c8ddc1f827fb。

## 轻纯证据和优化建议

count-proof.cjs用完整真实01aa源码、source-slice.functionBlock抽取真实01p.withCapturedFile，虚拟fs和native返回值，实际零spawn。实测capture=2、一次Store captured read=6；owner撤销拒绝、内存hash篡改拒绝；native metadata变化改变fingerprint。最后一条只证明metadata仍进入fingerprint，不声称普通tree.verify本身拒绝历史合法metadata变化（该方法更新当前nativeSha，由checkpoint owner与耐久proof严格比较）。

最小候选slice：先只考虑01p与01aa之间的“verified read”组合原语，把read中已完成的完整验证及发放字节，与紧随其后的store pre-work完整验证合并为一个不可伪造、同一owner的完整lease交接；保持read进入时身份/内容/native metadata全证、同步owner/hash守卫、异步work后完整验证、释放/unknown聚合和最后native close barrier。理论每callback少一次census=2helper（mode1最多6、mode2最多8）；不实现native批处理、不改协议、不缩fixture。它未必足以使整个七角色落入250秒，不能据次数直接许诺速度。

这不是批准直接删store的pre-work await verify：原read与verify之间存在await微任务边界，恶意调度、owner撤销、磁盘突变可能使看似重复检查有意义。候选必须先证明完整lease交接覆盖原边界；做不到就保持当前实现。应由独立审查确认再准入。

必要正控：同身份/ID/所有DATA/ADS/hash/attrs/shortName/四项Basic metadata完整守恒、普通与chunked/异步key获取、同owner lease、正常释放与最后barrier、模式0/1/2原断言和原预算全部保留。必要负控：read完成至work前微任务中换ID/内容/ADS/metadata、回调或key-await中撤销owner、伪造/跨文件/已release/二次消费token、缓冲篡改、最后verify失败与unknown cleanup保留owner；旧源码负控必须在目标节省计数断言红。先纯计数和对抗调度，获审后才独占真实helper运行；完整七角色新根实跑必须保固定before、原240/250/2秒、恢复和special末端inventory，不复用这次失败现场。

53/76/90秒只作实际总体观察；上述次数能解释增加的helper工作量，不能把调度、PowerShell启动成本、树增长或机器争用排除为耗时因素，更不把速度差当唯一metadata自扰原因。

## 追加：优先保全部native验证而复用broker/session的可行性

真实13u migrationCapsuleBroker:1774–1889提供多command串行的broker；close不是可继续用的reset，而是stdin.end并等实际child close，2秒close边界不变。migrationCapsuleCapturePreserved:2000–2004目前每次创建一个broker、发一次capture-preserved、finally await close，所以每次重新PowerShell/Add-Type；这项事实可解释新增capture必有新增spawn，不能把53/76/90秒唯一归因于编译或机器。

关键阻断：嵌入native的Nodes为static Dictionary（556）；Capture:738–739要求Nodes.Count==0；CapturePreserved:1294–1297在finally只RestoreBasic并恢复PreserveTimeHandles，未Close/清Nodes。首次capture后Nodes、Snapshot及handles仍在，重复capture必在already_open拒绝。Close:1048–1050会dispose全部stream/handle并清Nodes/Snapshot/OriginalRoot/Capsule；但Run的现有cmd close分支会调用Close后return终止整个进程。EOF也在Run finally关闭。因此“原C#session已支持无遗留多次capture-preserved”不成立，不能仅缓存broker跨调用，也不能在JS调用现有close后复用。

保全部native检查的最窄后续设计是仅在一个census内部复用一个owner-scoped broker：first capture → 原生关闭全部capture handles且确认清空状态 → JS原身份/namespace checks → second capture → 最后actual process close barrier。两次捕获、native metadata比较、所有owner/hash/身份断言全保，只省重复PowerShell启动。当前协议没有“释放capture但不退出Run”的ACK，故这需要一个新的严格read-only release/reset命令及独立native审查；不是当前约束下可实施的JS-only优化，本轮未实现、不批准复用、不写协议。

该未来slice负控须涵盖连续capture的原already_open反例、每轮Nodes/stream/Handle无遗留、第一次或第二次capture部分失败、RestoreBasic失败、reset ACK丢失/伪造、reset期间owner撤销、第二次ID/DATA/ADS/attrs/shortName/四项时间变化、command并发拒绝、EOF/非零exit/close超时未知保owner、以及最后实际exit/close清单。正控要求同原两个独立broker完整snapshot及fingerprint逐项相同，原预算不变。没有这个新命令及其证明，当前保全部native验证的broker优化保持阻断；Store verified-read组合原语亦须先证明await边界没有变弱，不直接删验证。
