'use strict';
const fs=require('node:fs'),p=require('node:path'),cp=require('node:child_process');
const steps=[
['snapshots-final','dev-harness/architecture-contract-snapshots.js',120000,'--write'],
['browser-original-second','dev-harness/external-bots.browser.e2e.js',600000],
['browser-retry-second','dev-harness/external-bots-retry.browser.e2e.js',600000],
['dpapi-retry-second','dev-harness/external-bots-work-data.e2e.js',240000,'--keep-root'],
['http-retry-second','dev-harness/external-bots-control.e2e.js',240000],
['bots-general-final','dev-harness/external-bots.e2e.js',240000],
['syntax-final','dev-harness/syntax-gate.js',600000],
['build-check-final','ruyi-workbench/app/build.js',120000,'--check'],
['fast-final','dev-harness/run-all.js',1200000,'--fast','--parallel','2']
];
const results=[];
(async()=>{for(const step of steps){const result=await new Promise(resolve=>{const child=cp.spawn(process.execPath,[p.join(__dirname,'run-serial-gate.cjs'),...step.map(String)],{cwd:__dirname,windowsHide:true,stdio:'inherit'});child.once('error',error=>resolve({name:step[0],error:error.message}));child.once('close',(code,signal)=>resolve({name:step[0],code,signal}));});results.push(result);fs.writeFileSync(p.join(__dirname,'final-validation-progress.json'),JSON.stringify(results,null,2)+'\n');if(result.code!==0){process.exitCode=1;return;}}})().catch(error=>{console.error(error);process.exitCode=1;});
