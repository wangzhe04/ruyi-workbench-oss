'use strict';
const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict');
let source=fs.readFileSync(p.join(__dirname,'verify-final-source.cjs'),'utf8');
const before='}else{a.equal(actual,row.sha256,row.file);a.equal(bytes.length,row.bytes,row.file);}}';
const after="}else if(row.file==='dev-harness/external-bots-retry.browser.e2e.js'){a.equal(actual,'abc49ba3f70b49707703e3af560ad8f7210e3757b462d3327325a4b0084be8bb');a.equal(row.sha256,'a5488cd9ed1fc50c917da4ea7b8ee500eb57a8a5255fdacedf2d7f7899ecd08f');const original=fs.readFileSync(p.join(__dirname,'browser-before-eol-normalization.js'));a.equal(hash(original),row.sha256);a.ok(Buffer.from(original.toString().replace(/\\r\\n/g,'\\n')).equals(bytes));derived.push({file:row.file,before:row.sha256,after:actual});}else{a.equal(actual,row.sha256,row.file);a.equal(bytes.length,row.bytes,row.file);}}";
a.equal(source.split(before).length,2);source=source.replace(before,after).replaceAll('final-source-verification.json','final-source-verification-v2.json');
const marker='const report={pinsVerified:';a.equal(source.split(marker).length,2);source=source.replace(marker,"const overlayFile=p.join(repo,'ruyi-workbench/tools/build-overlay.js');a.equal(hash(fs.readFileSync(overlayFile)),'ef523e95e29f7cc06d910b5f531c9cb05e94588dbe7c7bb53f9a620f02586514');a.equal(require(overlayFile).PAYLOAD_FILES.filter(file=>file==='app/public/js/external-bot-retry-state.js').length,1);\n"+marker);
fs.writeFileSync(p.join(__dirname,'verify-final-source-v2.cjs'),source,{flag:'wx'});
