'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),z=require('node:zlib'),cp=require('node:child_process'),a=require('node:assert/strict');
const repo='C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss',temp='C:/Users/87179/AppData/Local/Temp',out=p.join(repo,'docs/optimization-plan/evidence/m5-retry-20261026'),hash=b=>c.createHash('sha256').update(b).digest('hex');
const expected=['snapshots-final','browser-original-second','browser-retry-second','dpapi-retry-second','http-retry-second','bots-general-final','syntax-final','build-check-final','fast-final'];
const progress=JSON.parse(fs.readFileSync(p.join(__dirname,'final-validation-progress.json')));a.deepEqual(progress.map(x=>x.name),expected);a.ok(progress.slice(0,-1).every(x=>x.code===0));a.equal(progress.at(-1).code,1);
const finalFast=JSON.parse(fs.readFileSync(p.join(__dirname,'fast-second-process.json')));a.equal(finalFast.code,0);a.equal(finalFast.timeout,false);
const fast=fs.readFileSync(p.join(__dirname,'fast-second.log'),'utf8');a.match(fast,/[ℹ#] fail 0/);a.match(fast,/82 pass \/ 0 fail/);
const canonical=JSON.parse(fs.readFileSync(p.join(__dirname,'canonical-validation-progress.json')));a.equal(canonical.length,7);a.ok(canonical.every(row=>row.code===0));
for(const name of ['dpapi-canonical-first','dpapi-canonical-second']){const result=JSON.parse(fs.readFileSync(p.join(__dirname,name+'-process.json')));a.equal(result.code,0);a.equal(result.timeout,false);}
const durable=[];fs.mkdirSync(out,{recursive:true});
function keep(name,file){const bytes=fs.readFileSync(file),dest=p.join(out,name+'.gz');a.ok(bytes.length<64*1024*1024,'bounded selected evidence');if(fs.existsSync(dest))a.ok(z.gunzipSync(fs.readFileSync(dest)).equals(bytes),'immutable '+name);else{fs.mkdirSync(p.dirname(dest),{recursive:true});fs.writeFileSync(dest,z.gzipSync(bytes),{flag:'wx'});}const stored=fs.readFileSync(dest);durable.push({file:p.relative(repo,dest).replaceAll('\\','/'),source:file,bytes:bytes.length,sha256:hash(bytes),storedBytes:stored.length,storedSha256:hash(stored),gzip:true});}
function group(label,dir,recursive=false,filter=()=>true){a.ok(fs.statSync(dir).isDirectory(),dir);for(const name of fs.readdirSync(dir).sort()){const file=p.join(dir,name),stat=fs.lstatSync(file);a.equal(stat.isSymbolicLink(),false);if(stat.isDirectory()){if(recursive)group(label+'/'+name,file,true,filter);}else if(filter(name))keep(label+'/'+name,file);}}
const frozen=[
['retry-ui-permanent','ruyi-retry-ui-permanent-20261026-PQcjUt'],
['retry-dpapi-old-candidate','ruyi-retry-dpapi-candidate-20261026-s9nvXK'],
['retry-dpapi-old-review-blocked','ruyi-retry-dpapi-independent-20261026-q09H13'],
['retry-dpapi-retain-candidate','ruyi-retry-dpapi-retain-fix-20261026-BnsNgb'],
['retry-dpapi-retain-independent','ruyi-retry-dpapi-delta-independent-20261026-1BnPyr'],
['retry-browser-old-candidate','ruyi-retry-browser-candidate-20261026-TrQEqB'],
['retry-browser-old-independent','ruyi-retry-browser-independent-20261026-WmHpVh'],
['retry-browser-real-close-candidate','ruyi-retry-browser-real-close-fix-20261026-Rx5h5t'],
['retry-browser-real-close-independent','ruyi-retry-browser-delta-independent-20261026-vFFvX7'],
['host-v4-candidate','ruyi-migration-host-v4-20261026-codex'],
['host-v4-independent','ruyi-host-v4-independent-20261026'],
['historical-plain-fix','ruyi-historical-plain-fix-no-debug-20261026'],
['historical-plain-repeat','ruyi-historical-plain-repeat-20261026']
 ,['historical-plain-independent','ruyi-historical-plain-independent-20261026']
 ,['dpapi-eol-independent','ruyi-dpapi-eol-independent-20261026']
 ,['m5-final-independent','ruyi-m5-final-independent-20261026-dVchV6']
 ,['six-source-preparer-draft','ruyi-m3-six-source-preparer-draft-20261026-50MTwk']
 ,['six-source-preparer-draft-independent','ruyi-six-preparer-independent-20261026']
 ,['six-source-preparer-final','ruyi-six-preparer-final-kOoY9t']
 ,['six-source-preparer-final-independent','ruyi-six-preparer-final-independent-20261026']
 ,['six-source-combination-review','ruyi-m3-combination-root-review-V16OAW']
 ,['kernel-gap-analysis','ruyi-m3-kernel-gap-20261026-yYlm72']
 ,['packaging-and-browser-eol-independent','ruyi-final-packaging-eol-independent-20261026']
 ,['six-source-postbuild-independent','ruyi-r31m-postbuild-independent-20261026']
 ,['k1-first-blocked-source','ruyi-m3-k1-adapters-20261026-798a69d7']
 ,['k1-first-blocked-independent','ruyi-k1-independent-20261026-3c04055f']
 ,['k1-observer-blocked-source','ruyi-k1-observer-fix-20261026-7549454f']
 ,['k1-observer-blocked-independent','ruyi-k1-independent-new-20261026']
 ,['k1-complete-graph-source','ruyi-k1-graph-fix-20261026-84f3af71']
 ,['k1-complete-graph-independent','ruyi-k1-graph-independent-20261026']
 ,['m4-first-blocked-source','ruyi-m4-derived-store-candidate-20261026-37711d2e']
 ,['m4-first-blocked-independent','ruyi-m4-derived-independent-20261026-YOKr8T']
 ,['m4-boolean-source','ruyi-m4-derived-store-boolean-20261026-b90f702a']
 ,['m4-boolean-independent','ruyi-m4-boolean-independent-20261026-bCmnG0']
 ,['m4-preio-source','ruyi-m4-derived-preio-20261026-a53c2e1d']
 ,['m4-preio-independent','ruyi-m4-preio-independent-20261026-EPI5Mt']
 ,['preserved-read-performance','m3-preserved-read-perf-8d381b36']
 ,['capture-scope-proposal-blocked','m3-capture-scope-proposal-0a4ee4ed']
];for(const [label,dir]of frozen)group(label,p.join(temp,dir),true);
keep('six-source-preparation/source-preparation-proof.json',p.join(temp,'r31m-a61cf3/source-preparation-proof.json'));
const privateRoot=p.join(temp,'r31m-a61cf3');keep('six-source-preparation/runtime/app/server.js',p.join(privateRoot,'runtime/app/server.js'));keep('six-source-preparation/runtime/app/src/manifest.json',p.join(privateRoot,'runtime/app/src/manifest.json'));
for(const row of JSON.parse(fs.readFileSync(p.join(temp,'ruyi-six-preparer-final-kOoY9t/spec.json'))).exceptions)keep('six-source-preparation/runtime/app/src/'+row.module,p.join(privateRoot,'runtime/app/src',row.module));
group('six-source-execution-inputs',p.join(privateRoot,'ordinary'));
group('six-source-actual-first-owned',p.join(temp,'ruyi-ordinary-modes-B1dJYe'),false,name=>/\.(?:json|log)$/.test(name));
group('integration-and-validation',__dirname,false,name=>/\.(?:json|log|cjs)$/.test(name));
for(const [label,dir]of [
['store-capture-independent','ruyi-store-capture-independent-20261026'],['capsule-js-independent','ruyi-13u-js-independent-20261026'],
['n1-env-fix','ruyi-n1-env-fields-fix-20261026-fFeXRF'],['n1-env-independent','ruyi-n1-env-independent-20261026-4VtU0y'],
['n1-target-parent-fix','ruyi-n1-target-parents-fix-20261026-QIaqVa'],['n1-target-parent-independent','ruyi-n1-parents-independent-20261026-5NzF5M'],
['n1-natural-leaf-fix','ruyi-n1-source-leaf-fix-20261026-8RJLK3'],['n1-natural-leaf-independent','ruyi-n1-leaf-independent-20261026-w35hRf'],
['n1-second-controller','r31-n1run-BhvgPV'],['n1-second-owned','r31-n1-6Iq4yX'],['n1-third-controller','r31-n1run-lKOUQM'],['n1-third-owned','r31-n1-staBA7'],['n1-fourth-controller','r31-n1run-jDvEdB'],['n1-fourth-owned','r31-n1-0MAGkn']
])group(label,p.join(temp,dir),false,name=>/\.(?:json|log|cjs|txt|diff|cs)$/.test(name));
const browser=[];for(const name of ['browser-retry-first','browser-retry-second','browser-canonical-first','browser-canonical-second']){const log=fs.readFileSync(p.join(__dirname,name+'.log'),'utf8'),match=log.match(/RETRY BROWSER EVIDENCE ([^\r\n]+)/);a.ok(match,name);const dir=match[1].trim();group(name,dir,true);const proof=JSON.parse(fs.readFileSync(p.join(dir,'actual-proof.json')));a.equal(proof.items,18);a.equal(proof.histories,16);browser.push({name,root:dir,proof});}
const sourceFiles=cp.execFileSync('git',['diff','--name-only','HEAD'],{cwd:repo,encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean);
const untracked=cp.execFileSync('git',['ls-files','--others','--exclude-standard'],{cwd:repo,encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean).filter(file=>!file.startsWith('docs/optimization-plan/evidence/m5-retry-20261026'));
const products=[...new Set([...sourceFiles,...untracked])].filter(file=>!file.startsWith('docs/optimization-plan/evidence/')).sort().map(file=>{const bytes=fs.readFileSync(p.join(repo,file));return{file,bytes:bytes.length,sha256:hash(bytes)};});
const report={schema:1,date:'2026-10-26',baselineCommit:'c450c2f3a85cd54946fc6ec24618309a6bae9dfc',version:'3.0.1',status:'M5 manual retry integrated; full 3.1 continues',products,progress,canonical,finalFast,validation:{firstFast:{unit:{tests:4047,pass:4021,skip:26,fail:0},static:{pass:80,fail:2},failures:['browser test trailing CRLF','new runtime module missing overlay payload registration']},secondFast:{wholeGreen:true,unit:{tests:4047,pass:4021,skip:26,fail:0},static:{pass:82,fail:0}},syntax:{fullFiles:1335,fail:0,finalChangedFilesIndependentlyChecked:true}},browser,egress:JSON.parse(fs.readFileSync(p.join(__dirname,'egress-delta.json'))),durable,scope:'Synthetic isolated local adapters and actual Windows DPAPI. No real QQ/Feishu account acceptance, user-data encryption activation, package release or full3.1 completion. Selected private M3 source/model/resource evidence does not promote the whole six-source composition.'};
for(const row of durable){const stored=fs.readFileSync(p.join(repo,row.file));a.equal(hash(stored),row.storedSha256);a.equal(hash(z.gunzipSync(stored)),row.sha256);}
fs.writeFileSync(p.join(repo,'docs/optimization-plan/evidence/m5-retry-20261026.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({members:durable.length,storedBytes:durable.reduce((sum,row)=>sum+row.storedBytes,0),products:products.length}));
