'use strict';
const fs=require('node:fs'),p=require('node:path'),cp=require('node:child_process');
const steps=[
['dpapi-canonical-first','dev-harness/external-bots-work-data.e2e.js',240000,'--keep-root'],
['dpapi-canonical-second','dev-harness/external-bots-work-data.e2e.js',240000,'--keep-root'],
['browser-canonical-first','dev-harness/external-bots-retry.browser.e2e.js',600000],
['browser-canonical-second','dev-harness/external-bots-retry.browser.e2e.js',600000],
['overlay-registration-final','dev-harness/overlay-payload-lock.static.e2e.js',120000],
['eol-canonical-final','dev-harness/eol-policy.static.e2e.js',120000],
['packaging-related-units','--test',180000,'--test-concurrency=2','dev-harness/unit/release-checks.test.js','dev-harness/unit/release-audit-w4-gates.test.js','dev-harness/unit/web-payload-gate.test.js','dev-harness/unit/visual-image-payload.test.js']
];
const results=[];
(async()=>{for(const step of steps){const result=await new Promise(resolve=>{const child=cp.spawn(process.execPath,[p.join(__dirname,'run-serial-gate.cjs'),...step.map(String)],{cwd:__dirname,windowsHide:true,stdio:'inherit'});child.once('error',error=>resolve({name:step[0],error:error.message}));child.once('close',(code,signal)=>resolve({name:step[0],code,signal}));});results.push(result);fs.writeFileSync(p.join(__dirname,'canonical-validation-progress.json'),JSON.stringify(results,null,2)+'\n');if(result.code!==0){process.exitCode=1;return;}}})().catch(error=>{console.error(error);process.exitCode=1;});
