'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),a=require('node:assert/strict'),cp=require('node:child_process');
const dir=__dirname,file=p.join(dir,'integration.json'),old=fs.readFileSync(file),doc=JSON.parse(old),repo='C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss';
const hash=b=>c.createHash('sha256').update(b).digest('hex');
fs.writeFileSync(p.join(dir,'integration-before-metadata-correction.json'),old,{flag:'wx'});
const changes=[];
for(const row of doc.files){const first=doc.lineage.find(x=>x.file===row.file);a.ok(first,row.file);if(row.initialSha256!==first.base){changes.push({file:row.file,before:row.initialSha256,after:first.base});row.initialSha256=first.base;}
 const actual=fs.readFileSync(p.join(repo,row.file));a.equal(hash(actual),row.sha256,row.file);
 let baseline=null;try{baseline=hash(cp.execFileSync('git',['show',doc.baseCommit+':'+row.file],{cwd:repo,stdio:['ignore','pipe','ignore']}));}catch(error){a.equal(first.base,null,row.file+' missing baseline');}
 a.equal(row.initialSha256,baseline,row.file+' baseline');
}
doc.metadataCorrection={reason:'Preserve null for files first introduced in this overlay; final product bytes unchanged.',originalSha256:hash(old),changes};
fs.writeFileSync(file,JSON.stringify(doc,null,2)+'\n');
console.log(JSON.stringify({members:doc.files.length,changes,sha256:hash(fs.readFileSync(file))}));
