'use strict';
const fs=require('node:fs'),p=require('node:path'),a=require('node:assert/strict'),c=require('node:crypto');
const file='C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss/dev-harness/external-bots-work-data.e2e.js',before=fs.readFileSync(file),hash=b=>c.createHash('sha256').update(b).digest('hex'),text=before.toString('utf8');
a.equal(hash(before),'43e3b7af58a51fdf7f0d36b60c0957dda118fd2d2c821e7dbceb795aebd957e0');a.equal((text.match(/\r\n/g)||[]).length,1);a.equal(text.includes('    }\n  }\r\n\n})().catch(error => { failed = true;'),true);
const after=Buffer.from(text.replace(/\r\n/g,'\n'));a.equal(hash(after),'ffa261b0c9f3640d4595ed12d5bbe744f6f9123ff1a2ae374e353648b0cf64f1');
fs.writeFileSync(p.join(__dirname,'dpapi-before-eol-normalization.js'),before,{flag:'wx'});fs.writeFileSync(file,after);
const report={file,beforeSha256:hash(before),beforeBytes:before.length,afterSha256:hash(after),afterBytes:after.length,changed:'Removed exactly one CR at a statement/block separator outside literals. Original candidate remains frozen; actual canonical DPAPI gates and standalone syntax still required.',offset:before.indexOf(13)};fs.writeFileSync(p.join(__dirname,'dpapi-eol-derivation.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));
