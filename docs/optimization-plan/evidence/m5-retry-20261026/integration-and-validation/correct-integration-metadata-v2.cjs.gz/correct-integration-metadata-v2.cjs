'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),a=require('node:assert/strict'),cp=require('node:child_process');
const dir=__dirname,file=p.join(dir,'integration.json'),prior=fs.readFileSync(file),original=fs.readFileSync(p.join(dir,'integration-before-metadata-correction.json')),doc=JSON.parse(original),repo='C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss';
const hash=b=>c.createHash('sha256').update(b).digest('hex');
fs.writeFileSync(p.join(dir,'integration-first-correction-wrong-field.json'),prior,{flag:'wx'});
const changes=[];
for(const row of doc.files){const first=doc.lineage.find(x=>x.file===row.file);a.ok(first,row.file);if(row.baseSha256!==first.base){changes.push({file:row.file,before:row.baseSha256,after:first.base});row.baseSha256=first.base;}
 a.equal(hash(fs.readFileSync(p.join(repo,row.file))),row.sha256,row.file);
 let baseline=null;try{baseline=hash(cp.execFileSync('git',['show',doc.baseCommit+':'+row.file],{cwd:repo,stdio:['ignore','pipe','ignore']}));}catch(error){a.equal(first.base,null,row.file+' missing baseline');}
 a.equal(row.baseSha256,baseline,row.file+' baseline');
}
doc.metadataCorrection={reason:'Preserve null baseSha256 for first-introduced files overlaid again; product bytes unchanged. First correction used an unused field and is retained separately.',originalSha256:hash(original),firstCorrectionSha256:hash(prior),changes};
fs.writeFileSync(file,JSON.stringify(doc,null,2)+'\n');
console.log(JSON.stringify({members:doc.files.length,changes,sha256:hash(fs.readFileSync(file))}));
