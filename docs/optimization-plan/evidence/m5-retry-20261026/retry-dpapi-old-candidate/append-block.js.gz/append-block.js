  // Independent small producer: real DPAPI and the original no-network HTTPS boundary.
  // Keep every earlier large/key/corruption/OFF assertion unchanged.
  {
    const retryRoot = fs.mkdtempSync(path.join(root, 'payload4-'));
    const retryEnvironment = require('./lib/release-checks').releaseEnvironment(path.join(retryRoot, 'home'), path.join(retryRoot, 'data'));
    const savedEnvironment = new Map(Object.keys(retryEnvironment).map(key => [key, process.env[key]]));
    const { historicalSource } = require('./lib/external-bots-source-history');
    const historicalPins = { v1: '5bf225988e7a0744c6f13c87e82defd9f93612e88c917b25ad1cb26bc308938d', v2: '1ad6064fb9e31079e2b07c85353e56a1a94c33eff5d5abbf18f9efc87938d1f0', v3: 'c82cef972e46ae42d58f74d775a6a6a09e52caeb7d3d368a71fcaa57074504c6' };
    let retryApi; const oldReaders = [];
    assert.equal(process.__ruyiExternalRetryRuns, undefined);
    process.__ruyiExternalRetryRuns = 0;
    try {
      Object.assign(process.env, retryEnvironment);
      retryApi = require('./lib/server-internals').loadServerInternals([
        'externalBotReadState', 'externalBotUpdateConnection', 'externalBotAcceptCallback', 'externalBotDrain',
        'externalBotChains', 'runKeyedChain', 'readConfig', 'writeConfig', 'workDataKeys', 'paths',
      ], { withEval: true });
      assert.notEqual(retryApi.paths.data, api.paths.data);
      assert.equal(path.dirname(retryApi.paths.data), retryRoot);
      const retryConfig = await retryApi.readConfig(); retryConfig.workDataEncryptionV1 = true; await retryApi.writeConfig(retryConfig);
      await retryApi.workDataKeys.ensure();
      retryApi.__eval('runStewardTurn = async () => { process.__ruyiExternalRetryRuns++; return { ok: true, say: "DPAPI_RETRY_PRIVATE_ORIGINAL_REPLY" }; };');
      const retryUpdate = body => retryApi.runKeyedChain(retryApi.externalBotChains, 'state', () => retryApi.externalBotUpdateConnection(body));
      const originalWire = qqWire(qqEvent({ messageId: 'dpapi_retry_original', eventId: 'dpapi_retry_original_event', text: 'DPAPI_RETRY_PRIVATE_SIGNED_INPUT' }));
      const retryCallback = wire => retryApi.runKeyedChain(retryApi.externalBotChains, 'state', () => retryApi.externalBotAcceptCallback('qq', 'qq_test', wire.headers, wire.bytes));
      const retryFile = path.join(retryApi.paths.data, 'external-bots', 'state-v1.json');
      const retryBytes = () => fs.readFileSync(retryFile, 'utf8');
      const retrySends = sends;
      await retryUpdate({ op: 'upsert', connection: { ...qqConnection(), mode: 'control', ownerSenderId: 'qq_person', ownerConversationId: 'qq_room', ownerConversationType: 'group' }, controlConfirmed: true });
      await retryCallback(originalWire);
      await retryApi.externalBotDrain();
      const schema1 = await retryApi.externalBotReadState(), predecessor = schema1.items[0], schema1Bytes = retryBytes();
      assert.equal(schema1.schema, 1); assert.equal(schema1.items.length, 1);
      assert.equal(predecessor.execution.status, 'completed'); assert.equal(predecessor.execution.replyText, 'DPAPI_RETRY_PRIVATE_ORIGINAL_REPLY');
      assert.equal(predecessor.delivery.status, 'failed'); assert.equal(predecessor.delivery.errorCode, 'external_delivery.predispatch');
      assert.equal(process.__ruyiExternalRetryRuns, 1); assert.equal(sends, retrySends + 1);
      assert.equal(JSON.parse(schema1Bytes.split('\n')[0]).workData, 3);
      assert.ok(Buffer.byteLength(schema1Bytes) < 1024 * 1024);
      t.ok(!schema1Bytes.includes('DPAPI_RETRY_PRIVATE_ORIGINAL_REPLY') && !schema1Bytes.includes('DPAPI_RETRY_PRIVATE_SIGNED_INPUT'), 'P4 real signed callback and one business run produce a small DPAPI schema1 ledger with known token-phase pre-MESSAGE refusal');
      for (const version of ['v1', 'v2', 'v3']) {
        const oldSource = historicalSource(version);
        assert.equal(crypto.createHash('sha256').update(oldSource).digest('hex'), historicalPins[version]);
        // Complete historical 13w in THIS real server namespace: same actual Store,
        // queue AAD, paths, config, DPAPI key owner and physical ledger; no fake codec.
        const old = retryApi.__eval(oldSource + '\n;({ read: externalBotReadState, valid: externalBotValidState, accept: externalBotAcceptCallback, update: externalBotUpdateConnection, drain: externalBotDrain, chains: externalBotChains, stop: () => { externalBotWorkerStopped = true; } });');
        oldReaders.push({ version, old });
        const readable = await old.read();
        assert.deepEqual(readable, schema1); assert.equal(old.valid(schema1), true);
        assert.equal(retryBytes(), schema1Bytes); assert.equal(process.__ruyiExternalRetryRuns, 1); assert.equal(sends, retrySends + 1);
        t.ok(readable.items.length === 1 && readable.items[0].delivery.attemptId === predecessor.delivery.attemptId, 'P4 exact old ' + version + ' reader decrypts the SAME complete schema1 DPAPI ledger before retry (positive crypto/cap/namespace control)');
      }
      const localRetry = retryApi.__eval('body => runKeyedChain(externalBotChains, "state", () => externalBotRetryReply(body, EXTERNAL_BOT_LOCAL_REPLY_RETRY))');
      const body = { id: predecessor.id, expectedAttemptId: predecessor.delivery.attemptId, retryRequestId: 'dpapi_retry_request_00000001' };
      const receipt = await localRetry(body), schema4 = await retryApi.externalBotReadState(), successor = schema4.items[0], schema4Bytes = retryBytes();
      assert.equal(receipt.ok, true); assert.equal(receipt.alreadyRetried, false); assert.equal(schema4.schema, 4); assert.equal(schema4.items.length, 1);
      assert.notEqual(successor.delivery.attemptId, predecessor.delivery.attemptId); assert.equal(successor.delivery.status, 'pending');
      assert.equal(successor.replyHistory.length, 1); assert.deepEqual(successor.replyHistory[0].attempt, predecessor.delivery);
      assert.equal(successor.replyHistory[0].nextAttemptId, successor.delivery.attemptId); assert.equal(successor.replyHistory[0].retryRequestId, body.retryRequestId);
      assert.equal(receipt.receipt.itemId, predecessor.id); assert.equal(receipt.receipt.previousAttemptId, predecessor.delivery.attemptId); assert.equal(receipt.receipt.attemptId, successor.delivery.attemptId); assert.equal(receipt.receipt.retryRequestId, body.retryRequestId); assert.equal(receipt.receipt.requestedAt, successor.replyHistory[0].requestedAt);
      assert.deepEqual(successor.execution, predecessor.execution); assert.equal(successor.sourceKey, predecessor.sourceKey);
      assert.equal(process.__ruyiExternalRetryRuns, 1); assert.equal(sends, retrySends + 1);
      t.ok(!schema4Bytes.includes(body.retryRequestId) && !schema4Bytes.includes('DPAPI_RETRY_PRIVATE_ORIGINAL_REPLY') && !schema4Bytes.includes('replyHistory'), 'P4 private local capability persists one sealed payload4 successor and complete old attempt before any new send or business work');
      const replayPending = await localRetry(body);
      assert.equal(replayPending.alreadyRetried, true); assert.deepEqual(replayPending.receipt, receipt.receipt); assert.equal(retryBytes(), schema4Bytes);
      await retryApi.externalBotDrain();
      const attempted = await retryApi.externalBotReadState(), attemptedBytes = retryBytes();
      assert.equal(attempted.schema, 4); assert.equal(attempted.items[0].delivery.attemptId, successor.delivery.attemptId); assert.equal(attempted.items[0].delivery.status, 'failed');
      assert.equal(attempted.items[0].delivery.errorCode, 'external_delivery.predispatch'); assert.equal(attempted.items[0].replyHistory.length, 1);
      assert.deepEqual(attempted.items[0].execution, predecessor.execution); assert.equal(process.__ruyiExternalRetryRuns, 1); assert.equal(sends, retrySends + 2);
      const replayFailed = await localRetry(body);
      assert.equal(replayFailed.alreadyRetried, true); assert.deepEqual(replayFailed.receipt, receipt.receipt); assert.equal(retryBytes(), attemptedBytes);
      await retryCallback(originalWire);
      assert.equal(retryBytes(), attemptedBytes); assert.equal((await retryApi.externalBotReadState()).items.length, 1);
      t.ok(process.__ruyiExternalRetryRuns === 1 && sends === retrySends + 2, 'P4 pending and terminal same-ID retry plus signed callback redelivery preserve one successor/history and never rerun business or add a third token attempt');
      retryApi.workDataKeys.clear();
      const reopened = await retryApi.externalBotReadState();
      assert.deepEqual(reopened, attempted); assert.equal(retryBytes(), attemptedBytes);
      t.ok(!attemptedBytes.includes(body.retryRequestId) && !attemptedBytes.includes('DPAPI_RETRY_PRIVATE_ORIGINAL_REPLY'), 'P4 clear-key cold DPAPI read preserves complete payload4 while physical request ID and reply remain sealed');
      for (const { version, old } of oldReaders) {
        assert.equal(old.valid(reopened), false);
        await assert.rejects(() => old.read(), stateError);
        await assert.rejects(() => retryApi.runKeyedChain(old.chains, 'state', () => old.accept('qq', 'qq_test', originalWire.headers, originalWire.bytes)), stateError);
        await assert.rejects(() => retryApi.runKeyedChain(old.chains, 'state', () => old.update({ op: 'disable', id: 'qq_test' })), stateError);
        await old.drain();
        assert.equal(retryBytes(), attemptedBytes); assert.equal(process.__ruyiExternalRetryRuns, 1); assert.equal(sends, retrySends + 2);
        assert.deepEqual(await retryApi.externalBotReadState(), reopened);
        t.ok(true, 'P4 exact old ' + version + ' refuses entire REAL DPAPI payload4 ledger with zero overwrite/dedupe loss/business/new outbound calls');
      }
      const off = await retryApi.readConfig(); off.workDataEncryptionV1 = false; await retryApi.writeConfig(off);
      await assert.rejects(() => retryCallback(qqWire(qqEvent({ messageId: 'dpapi_retry_no_off_overwrite', text: 'DPAPI_RETRY_NO_DOWNGRADE' }))), stateError);
      await assert.rejects(() => retryUpdate({ op: 'disable', id: 'qq_test' }), stateError);
      await retryApi.externalBotDrain();
      t.ok(retryBytes() === attemptedBytes && process.__ruyiExternalRetryRuns === 1 && sends === retrySends + 2, 'P4 OFF refuses the sealed history-bearing ledger without plaintext rewrite, dedupe reset or new execution/send');
    } finally {
      for (const { old } of oldReaders) old.stop();
      if (retryApi) { retryApi.__eval('externalBotWorkerStopped = true;'); retryApi.workDataKeys.clear(); }
      delete process.__ruyiExternalRetryRuns;
      for (const [key, value] of savedEnvironment) { if (value === undefined) delete process.env[key]; else process.env[key] = value; }
    }
  }
