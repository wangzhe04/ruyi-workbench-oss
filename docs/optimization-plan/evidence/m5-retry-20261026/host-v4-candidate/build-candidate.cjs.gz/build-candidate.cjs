'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto');
const root=__dirname,prior=p.join(root,'frozen-v3'),out=p.join(root,'v4');
const hash=x=>c.createHash('sha256').update(x).digest('hex');
fs.cpSync(prior,out,{recursive:true,errorOnExist:true,force:false});
const name='01ad-work-data-migration-host.js',before=fs.readFileSync(p.join(prior,name),'utf8');
if(hash(before)!=='82df6b34d0be2fbb5a8e60a65dfbfba5d8caf745f5f60e16a1e813744389a1c5')throw Error('baseline hash mismatch');
const start=before.indexOf('    const sourceUnknown = value => {'),end=before.indexOf('    const sourceFailure=',start);
if(start<0||end<0)throw Error('span missing');
const unknown=`    const sourceUnknown = value => {
      const active=new Set(),done=new Set();let visited=0;
      // Shared completed evidence is a DAG; only a back edge is a cycle.
      const visit=item=>{
        if(item===null||!['object','function'].includes(typeof item))return false;
        if(require('node:util').types.isProxy(item))return true;
        if(active.has(item))return true;if(done.has(item))return false;
        if(++visited>64)return true;active.add(item);
        if(Array.isArray(item)) {
          const length=Object.getOwnPropertyDescriptor(item,'length');if(!length||!Object.hasOwn(length,'value')||length.value>64)return true;
          for(let index=0;index<length.value;index++){const entry=Object.getOwnPropertyDescriptor(item,String(index));if(!entry||!Object.hasOwn(entry,'value')||visit(entry.value))return true;}
        }
        let current=item;
        for(let depth=0;current!==null;depth++) {
          if(depth>=8||require('node:util').types.isProxy(current))return true;
          for(const name of ['helperMayStillRun','cause','errors']) {
            const descriptor=Object.getOwnPropertyDescriptor(current,name);if(!descriptor)continue;
            if(!Object.hasOwn(descriptor,'value'))return true;
            if(name==='helperMayStillRun'){if(descriptor.value!==false&&descriptor.value!==undefined)return true;}
            else if(name==='cause'){if(visit(descriptor.value))return true;}
            else if(descriptor.value!==undefined) {
              const list=descriptor.value;if(!Array.isArray(list)||require('node:util').types.isProxy(list))return true;
              const length=Object.getOwnPropertyDescriptor(list,'length');if(!length||!Object.hasOwn(length,'value')||length.value>64)return true;
              for(let index=0;index<length.value;index++){const entry=Object.getOwnPropertyDescriptor(list,String(index));if(!entry||!Object.hasOwn(entry,'value')||visit(entry.value))return true;}
            }
          }
          current=Object.getPrototypeOf(current);
        }
        active.delete(item);done.add(item);return false;
      };
      try{return visit(value);}catch{return true;}
    };
`.replace(/\n/g,'\r\n');
const ackOld='Reflect.apply(then,value,[undefined,()=>{}]);',ackNew='Reflect.apply(then,value,[()=>{},()=>{}]);';
if(before.split(ackOld).length!==2)throw Error('ACK span not unique');
const after=before.slice(0,start)+unknown+before.slice(end);
const candidate=after.replace(ackOld,ackNew);
fs.writeFileSync(p.join(out,name),candidate);
fs.writeFileSync(p.join(out,name+'.v3-before'),before);
const identity=JSON.parse(fs.readFileSync(p.join(out,'identity.json'),'utf8'));identity.host.candidateSha256=hash(candidate);fs.writeFileSync(p.join(out,'identity.json'),JSON.stringify(identity,null,2)+'\n');
const test=fs.readFileSync(p.join(prior,'pure.test.cjs'),'utf8');
const prefix=test.slice(0,test.indexOf('(async()=>{'));
if(!prefix.includes('function fixture('))throw Error('fixture not found');
const extra=`
(async()=>{
 let count=0;const pass=label=>{count++;console.log('PASS '+label);};
 const capture=async(options)=>{let error;try{await fixture(candidate,{preserved:true,sync:true,coverage:true,...options}).prepare();}catch(cause){error=cause;}a.ok(error);return error;};
 const leaf=new Error('ordinary known-closed leaf'),primary=Object.assign(new AggregateError([leaf],'ordinary',{cause:leaf}),{helperMayStillRun:false});
 const known=await capture({portableFault:primary});a.equal(known.cause,primary);a.equal(known.helperMayStillRun,undefined);a.equal(known.ownershipRetained,undefined);pass('root known-closed shared DAG preserves cause without inventing helper unknown');
 const cycle=Object.assign(new Error('cycle'),{helperMayStillRun:false});cycle.cause=cycle;
 const cycleError=await capture({portableFault:cycle});a.equal(cycleError.cause,cycle);a.equal(cycleError.helperMayStillRun,true);a.equal(cycleError.ownershipRetained,true);pass('real back-edge cycle remains unknown');
 const nested={helperMayStillRun:false,cause:{errors:[leaf,{cause:leaf,helperMayStillRun:true}]}};
 a.equal((await capture({portableFault:nested})).helperMayStillRun,true);pass('shared completed leaf cannot hide a later nested true flag');
 let getterCalls=0;const getter=Object.defineProperty({},'cause',{get(){getterCalls++;return leaf;}});a.equal((await capture({portableFault:getter})).helperMayStillRun,true);a.equal(getterCalls,0);pass('own accessor evidence remains unknown without invoking getter');
 let proxyCalls=0;const proxy=new Proxy({},{getOwnPropertyDescriptor(){proxyCalls++;throw Error('trap');},getPrototypeOf(){proxyCalls++;throw Error('trap');}});a.equal((await capture({portableFault:{cause:proxy}})).helperMayStillRun,true);a.equal(proxyCalls,0);pass('Proxy evidence remains unknown without invoking traps');
 const long={};let tail=long;for(let i=0;i<65;i++){tail.cause={};tail=tail.cause;}a.equal((await capture({portableFault:long})).helperMayStillRun,true);a.equal((await capture({portableFault:{errors:Array(65).fill(leaf)}})).helperMayStillRun,true);pass('node and list bounds remain unknown');
 let ackGetterCalls=0;const ack={},pending=Promise.resolve(ack);Object.defineProperty(ack,'then',{get(){ackGetterCalls++;return undefined;}});
 const ackError=await capture({releaseFaults:{1:()=>pending}});await new Promise(resolve=>setImmediate(resolve));a.equal(ackGetterCalls,0,'fulfilled release ACK must not be re-assimilated');a.equal(ackError.code,'work_data_migration_host.source_cleanup');a.equal(ackError.errors[0].message,'source_release_unproven');a.equal(ackError.helperMayStillRun,true);a.equal(ackError.ownershipRetained,true);pass('root fulfilled native Promise ACK getter stays zero and release stays unproven');
 console.log('V4 REGRESSION PURE SOURCE VM: ALL PASS ('+count+'); no native, socket or Windows causality claim');
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
`;
fs.writeFileSync(p.join(out,'v4-regression.test.cjs'),prefix+extra);
for(const counter of ['known-dag-counter','ack-then-counter']){
 const input=fs.readFileSync(p.join(root,counter+'.cjs.input'),'utf8');
 const oldDir="dir='C:/Users/87179/AppData/Local/Temp/ruyi-migration-host-preserved-author-0b3dc7cbe5bb40b784caf240a1131dd0/v3'";
 if(input.split(oldDir).length!==2)throw Error('counter dir span not unique');
 fs.writeFileSync(p.join(out,counter+'.cjs'),input.replace(oldDir,'dir=__dirname'));
}
for(const [label,source]of [['minus-dag',candidate.replace(unknown,before.slice(start,end))],['minus-ack',candidate.replace(ackNew,ackOld)]]){
 const mutant=p.join(root,label);fs.cpSync(out,mutant,{recursive:true,errorOnExist:true,force:false});fs.writeFileSync(p.join(mutant,name),source);
 const identity=JSON.parse(fs.readFileSync(p.join(mutant,'identity.json'),'utf8'));identity.host.candidateSha256=hash(source);fs.writeFileSync(p.join(mutant,'identity.json'),JSON.stringify(identity,null,2)+'\n');
}
fs.writeFileSync(p.join(root,'unique-spans.json'),JSON.stringify({baselineSha256:hash(before),candidateSha256:hash(candidate),spans:[{name:'sourceUnknown',beforeStart:start,beforeEnd:end,before:before.slice(start,end),after:unknown},{name:'observeSourcePromise-fulfillment',before:ackOld,after:ackNew}],unchangedInputs:['pure.test.cjs','01ad-work-data-migration-host.js.before','01aa-work-data-tree.js.input','01ab-work-data-full-snapshot.js.input','01p-work-data-store.js.input','01x-work-data-migration-codecs.js.input','13u-migration-center.js.input','create-owned-v2-reference.js.input','ordinary-mode-gate.cjs']},null,2)+'\n');
console.log(JSON.stringify({root,before:hash(before),after:hash(candidate)}));
