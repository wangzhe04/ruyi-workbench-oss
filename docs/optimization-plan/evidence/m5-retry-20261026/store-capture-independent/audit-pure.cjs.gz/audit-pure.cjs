'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),vm=require('node:vm'),a=require('node:assert/strict');
const freeze=p.join(process.env.TEMP,'ruyi-complete-js-review-ac3fe725c52a4ac0b9e25458f6cd8bfe');
const guard=p.join(process.env.TEMP,'ruyi-31-resume-20261026-c4672ee3/packages/ruyi-m4-image-cleanup-flags-fix-20261025/strict-pure-preload.cjs');
const hash=x=>c.createHash('sha256').update(x).digest('hex');
a.equal(require.cache[guard]?.loaded,true);a.equal(hash(fs.readFileSync(guard)),'850f258c4836c9f79df0b6e38ecd5b4516d6e44c74698e47988959c9e83252cd');
for(const name of ['child_process','net','tls','http','https','dgram','http2','cluster','worker_threads'])a.equal(Object.isFrozen(require('node:'+name)),true);
const id=JSON.parse(fs.readFileSync(p.join(freeze,'identity.json'),'utf8'));
const source=JSON.parse(fs.readFileSync(p.join(process.env.TEMP,'ruyi-m3-complete-support-review-20261026-75be2919/input-identity.json'),'utf8'));a.equal(hash(JSON.stringify(source)),id.sourceIdentitySha256);
const selected=['01p-work-data-store.js','01aa-work-data-tree.js','01ab-work-data-full-snapshot.js','13y-external-bot-credentials.js'];
let hunks=0;
for(const name of selected){const row=id.rows.find(r=>r.file===name),original=source.rows.find(r=>r.file===name);for(const suffix of ['head','private','diff']){const raw=fs.readFileSync(p.join(freeze,name+'.'+suffix));a.equal(hash(raw),row[suffix+'Sha256']);if(suffix==='private'){a.equal(raw.length,original.private.bytes);a.deepEqual(raw,fs.readFileSync(original.private.file));}}
const count=[...fs.readFileSync(p.join(freeze,name+'.diff'),'utf8').matchAll(/^@@ /mg)].length;a.equal(count,row.hunks.length);hunks+=count;console.log('IDENTITY',name,JSON.stringify({headBytes:fs.statSync(p.join(freeze,name+'.head')).size,privateBytes:original.private.bytes,hunks:count,privateSha256:row.privateSha256}));}
a.equal(hunks,13);
const code=name=>fs.readFileSync(p.join(freeze,name+'.private'),'utf8');
const load=(name,symbol,globals={},io)=>vm.runInNewContext(code(name)+'\n;'+symbol,{require:name=>name==='node:fs/promises'&&io?io:require(name),Buffer,process,console,...globals},{filename:name+'.private'});
function fakeStat(file,root){const isFile=file.toLowerCase()===p.join(root,'one.txt').toLowerCase();return{dev:1n,ino:isFile?2n:1n,size:isFile?3n:0n,nlink:1n,isDirectory:()=>!isFile,isFile:()=>isFile,isSymbolicLink:()=>false};}
async function main(){
const root='C:\\pure-owner',ownership={roots:[root]};let opaque='0'.repeat(64),exclusive=true;
const io={lstat:async file=>fakeStat(file,root),realpath:async file=>file,open(){throw Error('forbidden Node open');},readFile(){throw Error('forbidden Node read');},readdir(){throw Error('forbidden Node readdir');}};
const store=load('01p-work-data-store.js','WorkDataStore');
const tree=load('01aa-work-data-tree.js','WorkDataTree',{WorkDataStore:store},io);
const entry=(rel,dir,ino)=>({attrs:dir?16:32,dir,id:'00000001'+ino.toString(16).padStart(16,'0'),opaque,rel,shortName:'',times:['1','2','3','4'],streams:dir?[]:[{name:'',size:3,hash:hash(Buffer.from('abc')),data:Buffer.from('abc').toString('base64')}]});
const capturePreserved=async()=>({schema:1,platform:'ntfs-objects-v1',revision:'a'.repeat(64),entries:[entry('',true,1),entry('one.txt',false,2)]});
const reader=tree.createPreserved({capturePreserved,ownership,assertExclusive:()=>exclusive,assertExclusiveSync:()=>exclusive});
const cap=await reader.capture(root),finger=reader.fingerprint(cap);
await a.rejects(tree.borrowCapturedFile(cap,p.join(root,'one.txt'),{roots:[root]}));await a.rejects(tree.readCapturedFile({},p.join(root,'one.txt')));
const token=await tree.borrowCapturedFile(cap,p.join(root,'one.txt'),ownership),raw=await tree.readCapturedFile(token,p.join(root,'one.txt'));a.equal(raw.toString(),'abc');raw[0]=120;await a.rejects(tree.verifyCapturedFile(token,p.join(root,'one.txt')),{code:'work_data_tree.snapshot_changed'});token.release();a.equal(raw.every(x=>x===0),true);
const token2=await tree.borrowCapturedFile(cap,p.join(root,'one.txt'),ownership);a.equal(await store.createText({file:()=>p.join(root,'one.txt'),capturedFile:token2}).read(),'abc');await a.rejects(tree.verifyCapturedFile(token2,p.join(root,'one.txt')),{code:'work_data_tree.captured_file_invalid'});
exclusive=false;await a.rejects(tree.borrowCapturedFile(cap,p.join(root,'one.txt'),ownership));exclusive=true;
opaque='1'.repeat(64);const changed=await reader.verify(cap);a.equal(changed.nativeSha256,finger.nativeSha256);console.log('COUNTER_OPAQUE_CHANGE_ACCEPTED',JSON.stringify({before:finger.nativeSha256,after:changed.nativeSha256}));cap.release();
let acquisition;try{await store.acquireSnapshot({snapshot:async()=>({key:Buffer.alloc(1),instanceId:'x',release(){throw false;}})});}catch(e){acquisition=e;}a.equal(acquisition.cleanupFailed,true);a.equal(acquisition.helperMayStillRun,true);a.equal(acquisition.errors[1],false);console.log('PASS_CAPABILITY_AND_FALSY_CLEANUP');
const base='C:\\pure-source',target='C:\\pure-target',sourceOwner={roots:[base]},targetOwner={roots:[target]};let created=false,ordinaryReleased=0,openedReleased=0;
const fakeIO={lstat:async file=>{if(p.resolve(file)===target&&!created)throw Object.assign(Error('absent'),{code:'ENOENT'});return{isDirectory:()=>true,isSymbolicLink:()=>false};},realpath:async file=>file,mkdir:async()=>{created=true;}};
const unknown=Object.assign(Error('helper pending'),{code:'fixture.pending',helperMayStillRun:true,ownershipRetained:true});
const ordinary={capture:async()=>({files:[],directories:[],release(){ordinaryReleased++;}})};
const full=load('01ab-work-data-full-snapshot.js','WorkDataFullSnapshot',{WorkDataTree:{create:()=>ordinary},WorkDataRecovery:{create:()=>({open:async()=>({snapshot:{keys:[],files:[],directories:[],auxiliaries:[],generation:0},manifestSha256:'b'.repeat(64),release(){openedReleased++;}})})}},fakeIO);
const api=full.create({base,ownership:sourceOwner,assertExclusive:()=>true,protector:{supported:()=>true,run(){}},externalOwner(){},restoredTreeFor:async()=>({capture:async()=>{throw unknown;},verify(){},fingerprint(){}})});
let received;try{await api.restore({serialized:'fixture',password:'p',target,targetOwnership:targetOwner});}catch(e){received=e;}
a.equal(received.code,'work_data_full.restore_failed');a.equal(received.cause,unknown);a.equal(received.helperMayStillRun,undefined);a.equal(received.ownershipRetained,undefined);a.equal(received.targetRetained,true);a.equal(ordinaryReleased,1);a.equal(openedReleased,1);console.log('COUNTER_RESTORE_UNKNOWN_FLAG_LOSS',JSON.stringify({code:received.code,helperMayStillRun:received.helperMayStillRun??null,ownershipRetained:received.ownershipRetained??null,causeHelper:received.cause.helperMayStillRun,targetRetained:received.targetRetained}));
console.log('ALL_PURE_COUNTERS_COMPLETED');
}
main().catch(error=>{console.error(error);process.exitCode=1;});
