'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),vm=require('node:vm'),a=require('node:assert/strict');
const guard=p.join(process.env.TEMP,'ruyi-31-resume-20261026-c4672ee3/packages/ruyi-m4-image-cleanup-flags-fix-20261025/strict-pure-preload.cjs');a.equal(require.cache[guard]?.loaded,true);
const file=p.join(process.env.TEMP,'ruyi-complete-js-review-ac3fe725c52a4ac0b9e25458f6cd8bfe/13y-external-bot-credentials.js.private'),source=fs.readFileSync(file,'utf8');a.equal(c.createHash('sha256').update(source).digest('hex'),'ad2dc2ed042eb0952a822a7963b50696a6672d80ed2cd11b48d17859c3638c51');
const owner={connectionId:'qq1',platform:'qq',appId:'a',tenantId:'t',botUserId:''};const state={schema:1,records:[{binding:owner,revision:'a'.repeat(32),cipher:'eA==',present:['botSecret']}]};
const physical=Buffer.from(JSON.stringify(state)),target='C:\\pure\\external-bot-credentials.json',token={};let read=0,verified=0,asserted=0,opens=0,localAlive=true,raw,decrypted;
const tree={readCapturedFile:async(t,file)=>{a.equal(t,token);a.equal(file,target);read++;return raw=Buffer.from(physical);},verifyCapturedFile:async()=>{verified++;return localAlive;},assertCapturedFile(){asserted++;if(!localAlive)throw Object.assign(Error('owner gone'),{code:'fixture.owner_gone'});return true;}};
const fsp={open:async()=>{opens++;let consumed=false;return{read:async scratch=>{if(consumed)return{bytesRead:0};consumed=true;physical.copy(scratch);return{bytesRead:physical.length};},close:async()=>{}};}};
let invalidateDuringDecrypt=false;
const globals={require,Buffer,TextDecoder,process,console,path:p,crypto:c,paths:{data:'C:\\pure'},fsp,WorkDataTree:tree,runKeyedChain:async(map,key,fn)=>fn(),DurableJsonStore:{create:opts=>({filePath:opts.file})},LocalSecretCrypto:{run:async()=>{if(invalidateDuringDecrypt)localAlive=false;return decrypted=Buffer.from(JSON.stringify({botSecret:'secret'}));}}};
const moduleAPI=vm.runInNewContext(source+'\n;ExternalBotCredentials',globals,{filename:file}).create({file:target});
async function main(){
const value=await moduleAPI.snapshotForWorkDataRecovery(token);a.equal(opens,0);a.equal(read,1);a.equal(verified,1);a.equal(asserted,4);a.equal(value.source.data.equals(physical),true);a.equal(value.source.sha256,c.createHash('sha256').update(physical).digest('hex'));a.equal(JSON.parse(value.portable).records[0].values.botSecret,'secret');a.equal(decrypted.every(x=>x===0),true);value.release();a.equal(raw.every(x=>x===0),true);a.equal(value.portable.every(x=>x===0),true);
const legacy=await moduleAPI.snapshotForWorkDataRecovery();a.equal(opens,1);a.equal(legacy.present,true);legacy.release();
invalidateDuringDecrypt=true;await a.rejects(moduleAPI.snapshotForWorkDataRecovery(token),{code:'fixture.owner_gone'});a.equal(raw.every(x=>x===0),true);a.equal(decrypted.every(x=>x===0),true);
console.log('PASS_13Y_CAPTURED_SOURCE_HASH_BYTES_NO_IO_POST_AWAIT_ASSERT_AND_LEGACY_CALL');
}
main().catch(e=>{console.error(e);process.exitCode=1;});
