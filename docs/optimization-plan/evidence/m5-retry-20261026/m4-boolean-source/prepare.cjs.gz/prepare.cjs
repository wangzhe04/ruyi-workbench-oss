'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=process.argv[2]||process.cwd(),dir=__dirname,sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const target='01p-work-data-store.js',original=fs.readFileSync(path.join(repo,'ruyi-workbench/app/src',target),'utf8');
if(sha(original)!=='10cdee7ef20946a83573d7672300b45f407315027ae216b3aa9e071502926285')throw Error('current Store baseline pin changed');
const helper=`  // Opt-in bounded plaintext fallback for hosts that own strict file budgets. Existing hosts keep readFile semantics.
  const boundedText = async (host, target) => {
    if (host.maxFileBytes === undefined) return fsp.readFile(target, 'utf8');
    const cap = host.maxFileBytes;
    if (!Number.isSafeInteger(cap) || cap < 1 || cap > WorkDataChunks.MAX_PLAINTEXT_BYTES * 2) fail('text_file_limit');
    const handle = await fsp.open(target, 'r'); let bytes;
    try {
      const before = await handle.stat({ bigint:true });
      if (!before.isFile() || before.size > BigInt(cap)) fail('text_file_limit');
      bytes = Buffer.alloc(Number(before.size)); let used = 0;
      while (used < bytes.length) {
        const result = await handle.read(bytes,used,Math.min(65536,bytes.length-used),used);
        if (!result.bytesRead) fail('text_file_changed'); used += result.bytesRead;
      }
      const extra = Buffer.alloc(1), result = await handle.read(extra,0,1,used);
      if (result.bytesRead) fail('text_file_changed');
      const after = await handle.stat({ bigint:true });
      if (['dev','ino','size','mtimeNs','ctimeNs'].some(key=>before[key]!==after[key])) fail('text_file_changed');
      const resultText = bytes.toString('utf8');
      if (!Buffer.from(resultText,'utf8').equals(bytes)) fail('text_file_encoding');
      return resultText;
    } finally { if (bytes) bytes.fill(0); await handle.close(); }
  };
`;
const spans=[
{before:'  const chunkHeader = async target => {',after:helper+'  const chunkHeader = async target => {'},
{before:"    try { rawText = await fsp.readFile(target, 'utf8'); }\n    catch (error) { if (error && error.code !== 'ENOENT') fail('storage_unavailable'); return enabled; }",after:"    try { rawText = await boundedText(host, target); }\n    catch (error) { if (error && error.code !== 'ENOENT') fail('storage_unavailable'); return enabled; }"},
{before:"      const rawText = await fsp.readFile(file(), 'utf8');",after:"      const rawText = await boundedText(host, file());"}
];
function apply(source){let normalized=source.replace(/\r\n/g,'\n');for(const span of spans){if(normalized.split(span.before).length!==2)throw Error('span not unique');normalized=normalized.replace(span.before,span.after);}return normalized;}
const candidate=apply(original),privateFile='C:/Users/87179/AppData/Local/Temp/r31p-sgNqTk/runtime/app/src/01p-work-data-store.js';
fs.writeFileSync(path.join(dir,'src',target),candidate);
const privateBefore=fs.readFileSync(privateFile);if(sha(privateBefore)!=='9308bcd32d7b85ea939728e1b5f122aac8a15adea7a8aa9375a972eababc9a74')throw Error('private Store baseline pin changed');const privateAfter=apply(privateBefore.toString('utf8'));
fs.writeFileSync(path.join(dir,'private-9308-store-after.js'),privateAfter);
const inverse=source=>spans.slice().reverse().reduce((s,v)=>{if(s.split(v.after).length!==2)throw Error('reverse not unique');return s.replace(v.after,v.before);},source);
if(inverse(candidate)!==original.replace(/\r\n/g,'\n')||inverse(privateAfter)!==privateBefore.toString('utf8').replace(/\r\n/g,'\n'))throw Error('inverse failed');
fs.writeFileSync(path.join(dir,'store-spans.json'),JSON.stringify({baselineSha256:sha(original),baselineLF:sha(original.replace(/\r\n/g,'\n')),candidateSha256:sha(candidate),privateBaselineSha256:sha(privateBefore),privateAfterSha256:sha(privateAfter),spans},null,2));
const manifest=JSON.parse(fs.readFileSync(path.join(repo,'ruyi-workbench/app/src/manifest.json'),'utf8'));
manifest.modules.splice(manifest.modules.findIndex(r=>r.file==='14-main.js'),0,{file:'13bb-media-derived-store.js',note:'M4 derived storage candidate only; durable authority/runtime/codec unbound'});
for(const row of manifest.modules){delete row.startLine;delete row.endLine;}
manifest.proposalOnly=true;manifest.generated=false;manifest.note='Insertion order proposal only; no generated ranges. ROOT must run official build after source admission.';
fs.writeFileSync(path.join(dir,'candidate-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({dir,spans:spans.length,candidate:sha(candidate),privateBefore:sha(privateBefore),privateAfter:sha(privateAfter),inverseExact:true}));