'use strict';
const {test,after}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),io=require('node:fs/promises'),p=require('node:path'),os=require('node:os'),vm=require('node:vm'),crypto=require('node:crypto');
const repo=process.cwd(),dir=__dirname,{constBlock,functionBlock}=require(p.join(repo,'dev-harness/lib/source-slice'));
const src=p.join(repo,'ruyi-workbench/app/src'),read=name=>fs.readFileSync(p.join(src,name),'utf8'),imageFx=require(p.join(repo,'dev-harness/lib/media-image-contract-fixture'));
const code=[read('01h-privacy-core.js'),constBlock(read('01n-work-data-crypto.js'),'WorkDataCrypto'),constBlock(read('01r-work-data-chunks.js'),'WorkDataChunks'),constBlock(fs.readFileSync(p.join(dir,'src/01p-work-data-store.js'),'utf8'),'WorkDataStore'),functionBlock(read('01-config.js'),'atomicWriteJson'),fs.readFileSync(process.env.RUYI_M4_MODULE_SOURCE||p.join(dir,'src/13bb-media-derived-store.js'),'utf8')].join('\n');
const api=vm.runInNewContext(code+';({store:MediaDerivedStore,write:atomicWriteJson});',{require,Buffer,process,crypto,fsp:io,setTimeout,clearTimeout,console});
const root=fs.mkdtempSync(p.join(os.tmpdir(),'ruyi-m4-switch-strong-'));
after(()=>fs.rmSync(root,{recursive:true,force:true}));
const unknowns=[['undefined',()=>undefined],['null',()=>null],['zero',()=>0],['empty',()=>''],['object',()=>({})],['array',()=>[]],['string-false',()=>'false'],['one',()=>1],['boxed-false',()=>new Boolean(false)],['fulfilled-object',()=>Promise.resolve({})],['thenable-object',()=>({then(resolve){resolve({});}})],['throw-falsy',()=>{throw 0;}],['reject-falsy',()=>Promise.reject(null)],['throwing-then',()=>Object.defineProperty({},'then',{get(){throw Error('then getter');}})]];
async function fixture(){
 const family=fs.mkdtempSync(p.join(root,'f-')),f=imageFx.fixture(),ticket=await f.pipeline.prepare(),borrow=f.pipeline.borrow(ticket),manifest=JSON.parse(JSON.stringify(borrow.manifest)),bytes=Buffer.from(borrow.bytes);borrow.release();f.pipeline.release(ticket);
 const binding={};for(const key of ['sourceHash','sourceRevision','policyHash','policyRevision','rulesHash','processorHash','processorVersion'])binding[key]=manifest[key];binding.revocationRevision='r1';
 const state={enabled:()=>false,keyCalls:0},host={root:family,scopeId:manifest.scope,enabled:()=>state.enabled(),writeJson:api.write,now:()=>1000,authority:{capture:async()=>({binding}),assert:()=>true},keys:{snapshot:async()=>{state.keyCalls++;throw Object.assign(Error('key unavailable'),{code:'work_data_key.unavailable'});}}};
 const create=()=>api.store.create(host),adapter=create(),put=()=>adapter.put({sourceId:'owned_file',manifest,bytes});return{family,state,host,adapter,create,put};
}
const switchError=e=>typeof e?.code==='string'&&/^(media_store|work_data_store)\.switch_unavailable$/.test(e.code);
for(const [name,enabled]of unknowns)test('strict switch '+name+' rejects put and cold read with typed error, no key/plain publication',async()=>{
 const f=await fixture(),seed=await f.put(),before=fs.readFileSync(p.join(f.family,seed.id+'.json'));f.state.enabled=enabled;
 await a.rejects(f.put,switchError);a.equal(f.state.keyCalls,0);a.deepEqual(fs.readdirSync(f.family),[seed.id+'.json']);
 await a.rejects(()=>f.create().read(seed.id),switchError);a.equal(f.state.keyCalls,0);a.deepEqual(fs.readFileSync(p.join(f.family,seed.id+'.json')),before);
});
test('fulfilled false Promise/thenable is explicit false; true uses key path and never falls back to plaintext',async()=>{
 for(const enabled of [()=>false,()=>Promise.resolve(false),()=>({then(resolve){resolve(false);}})]){const f=await fixture();f.state.enabled=enabled;const result=await f.put();a.ok(result.id);a.equal(f.state.keyCalls,0);const b=await f.create().read(result.id);b.release();}
 const f=await fixture();f.state.enabled=()=>true;await a.rejects(f.put,{code:'work_data_key.unavailable'});a.equal(f.state.keyCalls,1);a.deepEqual(fs.readdirSync(f.family),[]);
});
test('new adapter three unique spans inverse raw to old85aef; manifest proposal omits all generated ranges',()=>{
 const spans=JSON.parse(fs.readFileSync(p.join(dir,'adapter-spans.json'),'utf8'));let value=fs.readFileSync(p.join(dir,'src/13bb-media-derived-store.js'),'utf8');for(const span of spans.spans.slice().reverse()){a.equal(value.split(span.after).length,2);value=value.replace(span.after,span.before);}a.equal(crypto.createHash('sha256').update(value).digest('hex'),'85aef8be558564d244f4238dfba0bbbc8e1ac280d0ec519568f3f72481092812');
 const manifest=JSON.parse(fs.readFileSync(p.join(dir,'candidate-manifest.json'),'utf8'));a.equal(manifest.proposalOnly,true);a.equal(manifest.generated,false);for(const row of manifest.modules){a.equal('startLine'in row,false);a.equal('endLine'in row,false);}a.equal(manifest.modules.findIndex(r=>r.file==='13bb-media-derived-store.js')+1,manifest.modules.findIndex(r=>r.file==='14-main.js'));
});