(function installRetryWriteFault(flags){
 const fs=require('node:fs'),path=require('node:path'),io=fs.promises,rename=io.rename;
 const stateFile=path.resolve(process.env.RUYI_HOME,'external-bots','state-v1.json');
 io.rename=async function(from,to){
  if(path.resolve(String(to))!==stateFile||!fs.existsSync(flags.arm))return rename.call(this,from,to);
  const arm=JSON.parse(fs.readFileSync(flags.arm,'utf8')),state=JSON.parse(fs.readFileSync(from,'utf8'));
  const item=state.items.find(row=>row.messageId===arm.messageId&&row.delivery?.status==='pending'
   &&row.replyHistory?.at(-1)?.attempt?.attemptId===arm.previousAttemptId&&row.replyHistory.at(-1).nextAttemptId===row.delivery.attemptId);
  if(!item)return rename.call(this,from,to);
  const result=await rename.call(this,from,to); // Actual persistence, never a fabricated ACK.
  fs.unlinkSync(flags.arm);fs.writeFileSync(flags.committed,JSON.stringify({messageId:item.messageId,previousAttemptId:arm.previousAttemptId,attemptId:item.delivery.attemptId,retryRequestId:item.replyHistory.at(-1).retryRequestId}),{flag:'wx'});
  throw Object.assign(Error('synthetic retry result lost after actual rename'),{code:'EIO'});
 };
})({"arm":"C:\\Users\\87179\\AppData\\Local\\Temp\\ruyi-retry-browser-evidence-0NCD57\\armed-commit-loss.json","committed":"C:\\Users\\87179\\AppData\\Local\\Temp\\ruyi-retry-browser-evidence-0NCD57\\committed-retry.json"});
