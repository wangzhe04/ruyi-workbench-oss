function migrationCapsuleFail(reason, uncertain = false) {
  const code = 'work_data_backup.' + reason;
  throw Object.assign(new Error(code), { code, apiCode: code, statusCode: 503,
    ...(uncertain ? { operationMayHaveExecuted: true, resultUnavailable: true, retry: false } : {}) });
}
function migrationCapsuleShape(snapshot) {
  if (!snapshot || snapshot.schema !== 1 || snapshot.platform !== 'ntfs-objects-v1'
      || !/^[a-f0-9]{64}$/.test(snapshot.revision || '') || !Array.isArray(snapshot.entries)
      || snapshot.entries.length < 1 || snapshot.entries.length > 10000) return false;
  const names = new Set(), ids = new Set(), opaque = new Set();
  let total = 0;
  for (const entry of snapshot.entries) {
    if (!entry || typeof entry.rel !== 'string' || entry.rel.length > 30000 || typeof entry.dir !== 'boolean'
        || !/^[a-f0-9]{24}$/.test(entry.id || '') || !/^[a-f0-9]{64}$/.test(entry.opaque || '')
        || !Number.isInteger(entry.attrs) || entry.attrs < 0 || entry.attrs > 0xffffffff
        || (entry.attrs & ~0x31b7) !== 0
        || !!(entry.attrs & 0x10) !== entry.dir || !Array.isArray(entry.times) || entry.times.length !== 4
        || typeof entry.shortName !== 'string' || entry.shortName.length > 12
        || entry.shortName && (/[\\/:*?"<>|\x00-\x20]/.test(entry.shortName) || ['.', '..'].includes(entry.shortName))
        || !entry.times.every(time => typeof time === 'string' && /^\d{1,19}$/.test(time) && BigInt(time) <= 9223372036854775807n)
        || !Array.isArray(entry.streams) || entry.streams.length > 1024) return false;
    const segments = entry.rel.split('/');
    if (entry.rel && (segments.length > 256 || segments.some(part => !part || part === '.' || part === '..'
        || /[\\:*?"<>|\x00-\x1f]/.test(part) || /[. ]$/.test(part) || part.length > 255))) return false;
    const key = entry.rel.toLowerCase();
    if (names.has(key) || ids.has(entry.id) || opaque.has(entry.opaque)) return false;
    names.add(key); ids.add(entry.id); opaque.add(entry.opaque);
    const streams = new Set();
    for (const stream of entry.streams) {
      if (!stream || typeof stream.name !== 'string' || stream.name.length > 1024
          || stream.name !== '' && !/^:[^:\\/*?"<>|\x00-\x1f]+:\$DATA$/.test(stream.name)
          || entry.dir && stream.name === '' || !Number.isSafeInteger(stream.size) || stream.size < 0
          || !/^[a-f0-9]{64}$/.test(stream.hash || '') || typeof stream.data !== 'string'
          || stream.data.length % 4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(stream.data)) return false;
      const streamKey = stream.name.toLowerCase();
      if (streams.has(streamKey)) return false;
      streams.add(streamKey);
      const bytes = Buffer.from(stream.data, 'base64');
      const valid = bytes.length === stream.size && bytes.toString('base64') === stream.data
        && crypto.createHash('sha256').update(bytes).digest('hex') === stream.hash;
      total += bytes.length; bytes.fill(0);
      if (!valid || total > 96000000) return false;
    }
    if (!entry.dir && !streams.has('')) return false;
  }
  if (!names.has('') || !snapshot.entries.find(entry => entry.rel === '').dir) return false;
  const dirs = new Set(snapshot.entries.filter(entry => entry.dir).map(entry => entry.rel.toLowerCase()));
  const aliases = new Set();
  return snapshot.entries.every(entry => {
    const parent = entry.rel.includes('/') ? entry.rel.slice(0, entry.rel.lastIndexOf('/')).toLowerCase() : '';
    if (entry.rel && !dirs.has(parent)) return false;
    // The root alias belongs to the external skills parent, not its own child namespace.
    if (!entry.rel || !entry.shortName) return true;
    const alias = (parent ? parent + '/' : '') + entry.shortName.toLowerCase();
    if (aliases.has(alias) || names.has(alias) && alias !== entry.rel.toLowerCase()) return false;
    aliases.add(alias); return true;
  });
}
function migrationCapsulePortableShape(snapshot) {
  const keys=(value,names)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join(',')===names;
  return migrationCapsuleShape(snapshot)&&keys(snapshot,'entries,platform,revision,schema')
    &&snapshot.entries.every(entry=>keys(entry,'attrs,dir,id,opaque,rel,shortName,streams,times')
      &&entry.streams.every(stream=>keys(stream,'data,hash,name,size')));
}
function migrationCapsuleFingerprint(snapshot) {
  return snapshot.entries.map(entry => ({ rel: entry.rel, id: entry.id, dir: entry.dir,
    streams: entry.streams.map(stream => ({ name: stream.name, size: stream.size, hash: stream.hash })).sort((a, b) => a.name.localeCompare(b.name))
  })).sort((a, b) => a.rel.localeCompare(b.rel));
}
function migrationCapsuleFingerprintShape(entries) {
  if (!Array.isArray(entries) || !entries.length || entries.length > 10000) return false;
  const names = new Set(), ids = new Set(), directories = new Set();
  let total = 0;
  for (const entry of entries) {
    if (!entry || typeof entry.rel !== 'string' || entry.rel.length > 30000 || typeof entry.dir !== 'boolean'
        || !/^[a-f0-9]{24}$/.test(entry.id || '') || !Array.isArray(entry.streams) || entry.streams.length > 1024) return false;
    const segments = entry.rel.split('/');
    if (entry.rel && (segments.length > 256 || segments.some(part => !part || part === '.' || part === '..'
        || /[\\:*?"<>|\x00-\x1f]/.test(part) || /[. ]$/.test(part) || part.length > 255))) return false;
    const key = entry.rel.toLowerCase();
    if (names.has(key) || ids.has(entry.id)) return false;
    names.add(key); ids.add(entry.id); if (entry.dir) directories.add(key);
    const streams = new Set();
    for (const stream of entry.streams) {
      if (!stream || typeof stream.name !== 'string' || stream.name.length > 1024
          || stream.name !== '' && !/^:[^:\\/*?"<>|\x00-\x1f]+:\$DATA$/.test(stream.name)
          || entry.dir && stream.name === '' || !Number.isSafeInteger(stream.size) || stream.size < 0
          || !/^[a-f0-9]{64}$/.test(stream.hash || '') || streams.has(stream.name.toLowerCase())) return false;
      streams.add(stream.name.toLowerCase()); total += stream.size;
      if (total > 96000000) return false;
    }
    if (!entry.dir && !streams.has('')) return false;
  }
  return directories.has('') && entries.every(entry => !entry.rel || directories.has(entry.rel.includes('/')
    ? entry.rel.slice(0, entry.rel.lastIndexOf('/')).toLowerCase() : ''));
}
function migrationCapsuleSame(snapshot, fingerprint) {
  return JSON.stringify(migrationCapsuleFingerprint(snapshot)) === JSON.stringify(fingerprint);
}
function migrationCapsuleSameMetadata(actual, expected) {
  if (!migrationCapsuleSame(actual, migrationCapsuleFingerprint(expected))) return false;
  const expectedById = new Map(expected.entries.map(entry => [entry.id, entry]));
  return actual.entries.every(entry => {
    const source = expectedById.get(entry.id);
    return source && entry.attrs === source.attrs && entry.shortName === source.shortName && JSON.stringify(entry.times) === JSON.stringify(source.times);
  });
}
function migrationCapsuleIntentShape(value, descriptor) {
  const converted = value?.conversion;
  if (converted !== undefined && (!converted || converted.schema !== 1 || !/^[a-f0-9]{48}$/.test(converted.operationId || '')
    || !['eligible', 'edited', 'gone'].includes(converted.eligibility))) return false;
  const missing = converted?.eligibility === 'gone' && Array.isArray(value.newTree) && value.newTree.length === 0;
  if (value?.historyPublish !== undefined && (!descriptor.plainRoot || value.phase !== 'complete'
    || Object.keys(value.historyPublish || {}).sort().join(',') !== 'id,name,schema' || value.historyPublish.schema !== 1
    || !/^[a-f0-9]{48}$/.test(value.historyPublish.name || '') || !/^[a-f0-9]{24}$/.test(value.historyPublish.id || ''))) return false;
  return !!value && value.schema === 1 && value.id === descriptor.id && value.stamp === descriptor.stamp
    && /^[a-f0-9]{64}$/.test(value.revision || '') && ['preparing', 'ready', 'published', 'restoring', 'complete', 'aborted'].includes(value.phase)
    && /^[a-f0-9]{24}$/.test(value.oldRoot || '') && (missing || migrationCapsuleFingerprintShape(value.newTree))
    && (missing || value.newTree.find(entry => entry.rel === '').id !== value.oldRoot)
    && (!descriptor.generationId || value.generationId === descriptor.generationId)
    && value.sourceStage === MIGRATION_SKILL_STAGE_PREFIX + descriptor.id + '-' + descriptor.stamp;
}
function migrationCapsuleCarrierHeaderValid(header,descriptor,kind) { return !(!header || Array.isArray(header)
        || Object.keys(header).sort().join(',') !== 'format,instanceId,keyId,manifest,purpose,recordId,revision,schema,scopeId,seq,workData'
        || header.workData !== 3 || header.format !== 'chunks-v1' || header.purpose !== 'backup'
        || header.schema !== 1 || header.seq !== 1 || header.scopeId !== descriptor.scopeId
        || header.recordId !== (kind === 'intent' && descriptor.intentRecordId || descriptor.recordId + ':' + kind)
        || typeof header.instanceId !== 'string' || typeof header.keyId !== 'string'
        || !/^[a-f0-9]{32}$/.test(header.revision || '') || !header.manifest || typeof header.manifest !== 'object' || Array.isArray(header.manifest)); }
function migrationCapsuleDecode(bytes) {
  let decoded;
  try { decoded = require('node:zlib').gunzipSync(bytes, { maxOutputLength: MIGRATION_CAPSULE_ARCHIVE_LIMIT }); }
  catch { migrationCapsuleFail('archive'); }
  try {
    const snapshot = JSON.parse(decoded.toString('utf8'));
    if (!migrationCapsuleShape(snapshot)) migrationCapsuleFail('shape');
    return snapshot;
  } catch (error) {
    if (String(error?.code || '').startsWith('work_data')) throw error;
    migrationCapsuleFail('shape');
  } finally { decoded.fill(0); }
}
function migrationBackupHistoryBinding(descriptor) { return { purpose:'backup',schema:1,scopeId:'skill-backup-history:'+descriptor.stamp,recordId:descriptor.recordId+':history' }; }
function migrationBackupHistoryShape(value, descriptor) {
  return value && Object.keys(value).sort().join(',') === 'historyOnly,id,phase,schema,snapshot,stamp,type'
    && value.schema === 1 && value.type === 'terminal-skill-backup-history' && value.historyOnly === true
    && value.id === descriptor.id && value.stamp === descriptor.stamp && ['complete', 'aborted'].includes(value.phase)
    && migrationCapsuleShape(value.snapshot);
}
function createMigrationBackupOwner({ base, readActive, sourceKeys, targetKeys = sourceKeys, native, ownership, assertExclusive, assertExclusiveSync, preservedRead } = {}) {
  if (typeof base !== 'string' || !path.isAbsolute(base) || typeof readActive !== 'function') migrationCapsuleFail('owner_host');
  // This local batch keeps one existing work-data master. Rotation/portable keys
  // need a per-backup key-reference map and are deliberately not implied here.
  if (targetKeys !== sourceKeys) migrationCapsuleFail('owner_key_rotation_unavailable');
  base = path.resolve(base);
  if (preservedRead !== undefined && (!preservedRead || preservedRead.profile !== 'bounded-native-v1'
    || typeof preservedRead.capturePreserved !== 'function' || typeof assertExclusive !== 'function'
    || typeof assertExclusiveSync !== 'function' || !ownership)) migrationCapsuleFail('owner_preserved_host');
  const preservedTree = preservedRead ? WorkDataTree.createPreserved({ capturePreserved: preservedRead.capturePreserved,
    ownership, assertExclusive, assertExclusiveSync, limits: preservedRead.limits || {} }) : null;
  const capturedReads = preservedTree ? new (require('node:async_hooks').AsyncLocalStorage)() : null;
  const portableTargetReads = preservedTree ? new (require('node:async_hooks').AsyncLocalStorage)() : null;
  function capturedFile(file, maximum = 256 * 1024 * 1024) {
    const targetRead = portableTargetReads?.getStore(), captured = targetRead?.captured || capturedReads?.getStore();
    if (!captured) return undefined;
    return () => WorkDataTree.borrowCapturedFile(captured, file, targetRead ? targetRead.ownership : ownership, { maxBytes: maximum });
  }
  function capturedDescriptor(descriptor) {
    return capturedReads?.getStore() || portableTargetReads?.getStore() ? { ...descriptor, capturedFile } : descriptor;
  }
  async function withCapturedReads(work) {
    if (!preservedTree) return work();
    const captured = await preservedTree.capture(base);let result,failed=false,primary;
    try {
      result=await capturedReads.run(captured, async () => {
        const value = await work();
        await preservedTree.verify(captured);
        if (assertExclusiveSync(ownership) !== true) migrationCapsuleFail('owner_preserved_host');
        return value;
      });
    } catch(cause){failed=true;primary=cause;}
    const cleanupErrors=[];let releaseFailed=false;
    try {const released=captured.release();if(released!==undefined){Promise.resolve(released).catch(()=>{});throw new Error('captured_release_unproven');}}
    catch(cause){releaseFailed=true;cleanupErrors.push(cause);}
    if(cleanupErrors.length)throw migrationCapturedCleanupFailure(primary,failed,cleanupErrors,releaseFailed);
    if(failed)throw primary;return result;
  }
  const control = path.join(base, '.work-data', 'skill-backups');
  const legacyRoot = path.join(base, 'migrations', MIGRATION_SKILL_BACKUP_DIR), stableRoot = path.join(control, 'objects-v1');
  const generationRoot = id => path.join(base, '.work-data', 'generations', id);
  const hash = value => crypto.createHash('sha256').update(value).digest('hex');
  const id48 = value => typeof value === 'string' && /^[a-f0-9]{48}$/.test(value);
  const id24 = value => typeof value === 'string' && /^[a-f0-9]{24}$/.test(value);
  const hex = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
  const exact = (value, keys) => value && !Array.isArray(value) && typeof value === 'object' && Object.keys(value).sort().join(',') === keys.split(',').sort().join(',');
  const eq = (a, b) => samePathKey(a) === samePathKey(b);
  const plans = new WeakMap();
  const platform = native || {
    info: async root => { const broker = await migrationCapsuleBroker(); try { return await broker.command({ cmd: 'store-info', root }); } finally { await broker.close(); } },
    move: async args => { const broker = await migrationCapsuleBroker(); try { return await broker.command({ cmd: 'store-move', ...args }); } finally { await broker.close(); } },
    capture: migrationCapsuleCapture,
  };
  if (typeof platform.info !== 'function' || typeof platform.move !== 'function' || typeof platform.capture !== 'function') migrationCapsuleFail('owner_host');
  async function stat(file) { try { return await fsp.lstat(file); } catch (error) { if (error.code === 'ENOENT') return null; throw error; } }
  async function directory(file, missing = false) {
    const absolute = path.resolve(file), volume = path.parse(absolute).root;
    let cursor = volume;
    for (const part of ['', ...absolute.slice(volume.length).split(path.sep).filter(Boolean)]) {
      if (part) cursor = path.join(cursor, part);
      const value = await stat(cursor);
      if (!value) { if (missing) return false; migrationCapsuleFail('owner_directory'); }
      if (!value.isDirectory() || value.isSymbolicLink() || !eq(await fsp.realpath(cursor), cursor)) migrationCapsuleFail('owner_directory');
    }
    return true;
  }
  async function ensureControl() {
    await directory(base); await directory(control, true);
    await fsp.mkdir(control, { recursive: true }); await directory(control);
  }
  function ref(stamp, skillId, storeId) {
    if (typeof stamp !== 'string' || !/^[0-9TZ-]+$/.test(stamp) || typeof skillId !== 'string' || !SKILL_ID_RE.test(skillId) || !id48(storeId)) migrationCapsuleFail('backup_ref');
    const canonical = process.platform === 'win32' ? skillId.toLowerCase() : skillId;
    return Object.freeze({ schema: 2, storeId, stamp, skillId: canonical, backupId: hash(stamp + '/' + canonical) });
  }
  function refValid(value) {
    if (!exact(value, 'schema,storeId,stamp,skillId,backupId') || value.schema !== 2) return false;
    try { const canonical = ref(value.stamp, value.skillId, value.storeId); return canonical.skillId === value.skillId && canonical.backupId === value.backupId; } catch { return false; }
  }
  function journalValid(value) {
    return exact(value, 'schema,operationId,storeId,rootId,volume,sourceProof,targetId,phase') && value.schema === 1
      && id48(value.operationId) && id48(value.storeId) && id24(value.rootId) && typeof value.volume === 'string'
      && (value.sourceProof === null || hex(value.sourceProof)) && id48(value.targetId)
      && ['prepared', 'moved', 'kept', 'canceled'].includes(value.phase);
  }
  function catalogValid(value) {
    return exact(value, 'schema,storeId,rootId,volume') && value.schema === 1 && id48(value.storeId) && id24(value.rootId) && typeof value.volume === 'string';
  }
  function bindingValid(value) {
    return (exact(value, 'schema,generationId,storeId,sourceProof,sourceRootIds,ready,entries') || exact(value, 'schema,generationId,storeId,sourceProof,sourceRootIds,mode,ready,entries'))
      && (value.mode === undefined || ['plain', 'encrypted'].includes(value.mode)) && value.schema === 2 && id48(value.generationId)
      && id48(value.storeId) && (value.sourceProof === null || hex(value.sourceProof)) && typeof value.ready === 'boolean'
      && Array.isArray(value.sourceRootIds) && value.sourceRootIds.length > 0 && value.sourceRootIds.length <= 10000
      && value.sourceRootIds.every(id => id === null || id48(id)) && new Set(value.sourceRootIds).size === value.sourceRootIds.length
      && Array.isArray(value.entries) && value.entries.every(entry => refValid(entry.ref) && entry.ref.storeId === value.storeId
        && (entry.kind === undefined || entry.kind === 'plain' && value.mode === 'plain' && ['published', 'complete'].includes(entry.phase)
          || entry.kind === 'history' && entry.historyMode === (value.mode || 'encrypted') && ['complete', 'aborted'].includes(entry.phase))
        && SKILL_ID_RE.test(entry.physicalSkillId || '') && ref(entry.ref.stamp, entry.physicalSkillId, value.storeId).skillId === entry.ref.skillId
        && ['published', 'complete', 'aborted', 'plain'].includes(entry.phase)
        && ['eligible', 'edited', 'gone', 'terminal', 'plain-owner-required'].includes(entry.eligibility)
        && (entry.phase === 'plain' || entry.sourceGenerationId === null || id48(entry.sourceGenerationId))
        && (entry.phase === 'plain' || hex(entry.archiveSha) && hex(entry.intentSha))
        && (entry.eligibility !== 'eligible' || migrationCapsuleFingerprintShape(entry.newTree)));
  }
  const ownerScope = sourceBase => 'skill-backup-owner:' + hash(samePathKey(sourceBase)).slice(0, 32);
  function sealed(file, recordId, validate, keys = targetKeys, scopeBase = base) {
    const store = authenticated => WorkDataStore.createText({ file: () => file, ...(capturedReads?.getStore() ? { capturedFile: capturedFile(file) } : {}), purpose: 'backup', schema: 1, scopeId: ownerScope(scopeBase), recordId,
      keys, chunked: true, maxPlaintextBytes: 256 * 1024 * 1024, enabled: async () => true, writeJson: atomicWriteJson,
      validateSealedText: text => { const valid = validate(safeJsonParse(text, null)); if (valid && authenticated) authenticated(); return valid; } });
    return { write: async value => { if (!validate(value)) migrationCapsuleFail('owner_shape'); await store().write(JSON.stringify(value)); }, read: async () => {
      if (!await stat(file)) return null;
      let authenticated = false; const text = await store(() => { authenticated = true; }).read();
      if (!authenticated) migrationCapsuleFail('carrier'); return JSON.parse(text);
    } };
  }
  const journalStore = () => sealed(path.join(control, 'relocation-v1.sealed'), 'relocation-v1', journalValid);
  const catalogStore = () => sealed(path.join(control, 'catalog-v1.sealed'), 'catalog-v1', catalogValid);
  const bindingsStore = (id, keys = targetKeys) => sealed(path.join(generationRoot(id), 'migrations', 'skill-backup-bindings-v2.sealed'), 'bindings:' + id, bindingValid, keys);
  async function active() {
    const value = await readActive();
    if (!value || !value.proof || (value.proof.raw !== null && typeof value.proof.raw !== 'string')
        || value.proof.sha256 !== (value.proof.raw === null ? null : hash(value.proof.raw))
        || value.id !== null && !id48(value.id)
        || !eq(value.root, value.id === null ? base : generationRoot(value.id))) migrationCapsuleFail('owner_manifest');
    return value;
  }
  async function current(expected) {
    const value = await active();
    if (!expected?.proof || typeof expected.root !== 'string' || !eq(value.root, expected.root) || value.proof.raw !== expected.proof.raw || value.proof.sha256 !== expected.proof.sha256 || value.id !== expected.id) migrationCapsuleFail('generation_changed');
    return value;
  }
  function candidateValid(candidate) { return candidate && id48(candidate.id) && typeof candidate.root === 'string' && eq(candidate.root, generationRoot(candidate.id)); }
  async function location(journal) {
    const rows = [];
    for (const root of [legacyRoot, stableRoot]) {
      if (!await directory(root, true)) continue;
      const info = await platform.info(root);
      if (info.id !== journal.rootId || info.volume !== journal.volume) migrationCapsuleFail('store_identity', true);
      rows.push({ root, info });
    }
    if (rows.length !== 1) migrationCapsuleFail('store_location', true);
    return rows[0].root;
  }
  async function relocate(journal, target) {
    const source = await location(journal);
    if (eq(source, target)) return;
    await directory(path.dirname(target));
    let moved;
    try { moved = await platform.move({ source, target, id: journal.rootId }); }
    catch (error) { error.operationMayHaveExecuted = true; error.resultUnavailable = true; error.retry = false; throw error; }
    if (!moved || moved.id !== journal.rootId || moved.volume !== journal.volume || !eq(await location(journal), target)) migrationCapsuleFail('store_identity', true);
  }
  async function prepare({ expected, candidate } = {}) {
    expected = Object.freeze({ id: expected?.id, root: expected?.root, proof: Object.freeze({ ...expected?.proof }) });
    candidate = Object.freeze({ id: candidate?.id, root: candidate?.root, mode: candidate?.mode });
    await current(expected);
    if (!candidateValid(candidate)) migrationCapsuleFail('owner_candidate');
    await directory(candidate.root); await ensureControl();
    const catalog = await catalogStore().read();
    if (catalog) {
      await directory(stableRoot); const info = await platform.info(stableRoot);
      if (info.id !== catalog.rootId || info.volume !== catalog.volume) migrationCapsuleFail('store_identity');
      const token = Object.freeze({ storeId: catalog.storeId, root: stableRoot, moved: false });
      plans.set(token, { expected, candidate, catalog }); return token;
    }
    let journal = await journalStore().read();
    if (journal && ['prepared', 'moved'].includes(journal.phase)) {
      if (journal.targetId !== candidate.id || journal.sourceProof !== expected.proof.sha256) migrationCapsuleFail('owner_busy', true);
    } else {
      if (await stat(stableRoot)) migrationCapsuleFail('store_unowned');
      if (!await directory(legacyRoot, true)) { await fsp.mkdir(legacyRoot, { recursive: true }); await directory(legacyRoot); }
      const info = await platform.info(legacyRoot);
      if (!id24(info.id) || typeof info.volume !== 'string') migrationCapsuleFail('store_identity');
      journal = { schema: 1, operationId: crypto.randomBytes(24).toString('hex'), storeId: crypto.randomBytes(24).toString('hex'),
        rootId: info.id, volume: info.volume, sourceProof: expected.proof.sha256, targetId: candidate.id, phase: 'prepared' };
      await journalStore().write(journal);
    }
    await current(expected); await relocate(journal, stableRoot);
    journal.phase = 'moved'; await journalStore().write(journal);
    const token = Object.freeze({ storeId: journal.storeId, root: stableRoot, moved: true });
    plans.set(token, { expected, candidate, journal }); return token;
  }
  async function recover() {
    await recoverRepresentation();
    await directory(control, true); const journal = await journalStore().read();
    if (!journal || ['kept', 'canceled'].includes(journal.phase)) return journal;
    const selected = await active(), keep = selected.id === journal.targetId;
    if (!keep && selected.proof.sha256 !== journal.sourceProof) migrationCapsuleFail('owner_manifest', true);
    const existingCatalog = await catalogStore().read();
    if (existingCatalog && (!keep || existingCatalog.storeId !== journal.storeId || existingCatalog.rootId !== journal.rootId || existingCatalog.volume !== journal.volume)) migrationCapsuleFail('owner_catalog', true);
    await relocate(journal, keep ? stableRoot : legacyRoot);
    if (keep) await catalogStore().write({ schema: 1, storeId: journal.storeId, rootId: journal.rootId, volume: journal.volume });
    journal.phase = keep ? 'kept' : 'canceled'; await journalStore().write(journal);
    return Object.freeze({ phase: journal.phase, root: keep ? stableRoot : legacyRoot, storeId: journal.storeId });
  }
  function descriptor(root, stamp, skillId) {
    return { backup: path.join(root, stamp, skillId), stamp, id: skillId, scopeId: 'skill-backups:' + stamp,
      recordId: 'skill-backup:' + (process.platform === 'win32' ? skillId.toLowerCase() : skillId), archiveKeys: sourceKeys, intentKeys: sourceKeys };
  }
  async function fileHash(file) {
    if (capturedReads?.getStore() || portableTargetReads?.getStore()) return migrationWithCapturedBytes({ capturedFile }, file, 256 * 1024 * 1024,
      bytes => crypto.createHash('sha256').update(bytes).digest('hex'));
    const digest = crypto.createHash('sha256'); for await (const bytes of fs.createReadStream(file)) digest.update(bytes); return digest.digest('hex');
  }
  async function provenance(root, skillId, keys) {
    return WorkDataStore.createText({ file: () => path.join(root, SKILL_IMPORT_RECORD), purpose: 'backup', schema: 1, scopeId: 'skills',
      recordId: 'skill-import:' + (process.platform === 'win32' ? skillId.toLowerCase() : skillId), keys, chunked: true, maxPlaintextBytes: 16 * 1024,
      enabled: async () => true, writeJson: atomicWriteJson, validateSealedText: text => Buffer.byteLength(text, 'utf8') <= 16 * 1024 }).read();
  }
  async function equivalent(source, target, sourcePath, targetPath, skillId) {
    const expected = migrationCapsuleFingerprint(source), actual = migrationCapsuleFingerprint(target);
    if (expected.length !== actual.length) migrationCapsuleFail('binding_tree');
    let reencoded = false;
    for (let index = 0; index < expected.length; index++) {
      const a = expected[index], b = actual[index];
      if (a.rel !== b.rel || a.dir !== b.dir || a.streams.length !== b.streams.length) migrationCapsuleFail('binding_tree');
      for (let ordinal = 0; ordinal < a.streams.length; ordinal++) {
        const left = a.streams[ordinal], right = b.streams[ordinal];
        if (left.name !== right.name) migrationCapsuleFail('binding_tree');
        if (left.hash === right.hash && left.size === right.size) continue;
        if (a.rel !== SKILL_IMPORT_RECORD || left.name !== '') migrationCapsuleFail('binding_tree');
        if (await provenance(sourcePath, skillId, sourceKeys) !== await provenance(targetPath, skillId, targetKeys)) migrationCapsuleFail('binding_provenance');
        reencoded = true;
      }
    }
    return reencoded;
  }
  function plainDescriptor(entry, generationId) {
    const source = descriptor(stableRoot, entry.ref.stamp, entry.physicalSkillId);
    return { ...source, backup: path.join(control, 'plain-v1', generationId, entry.ref.backupId), plainRoot: source.backup, generationId,
      intentRecordId: source.recordId + ':intent:' + generationId, archiveKeys: sourceKeys, intentKeys: targetKeys,
      historyHost: Object.freeze({ ...conversionNative, directory }) };
  }
  async function preparePlainBinding(owned, token, backupRef, physicalSkillId, priorBinding) {
    requireConversionNative();
    const entry = { ref: backupRef, physicalSkillId, kind: 'plain', phase: 'published', eligibility: 'edited', newTree: null,
      archiveSha: '', intentSha: '', sourceGenerationId: null };
    const source = plainDescriptor(entry, owned.candidate.id), revision = hash('plain:' + owned.candidate.id + ':' + backupRef.backupId);
    const captured = await conversionNative.capture(source.plainRoot, revision);
    if (!migrationCapsuleShape(captured)) migrationCapsuleFail('plain_backup_shape');
    const currentRepresentation = await representationStore().read();
    const row = currentRepresentation?.targetId === owned.candidate.id && currentRepresentation.entries.find(row => row.backupId === backupRef.backupId);
    let proof;
    if (row) {
      const record = await representationRecordStore(currentRepresentation, row).read();
      if (!record || record.phase !== 'forward' || !migrationCapsuleSameMetadata(captured, record.target)) migrationCapsuleFail('plain_backup_changed');
      proof = { eligibility: record.eligibility, newTree: record.newTree };
    } else {
      const prior = priorBinding?.entries.find(row => row.ref.backupId === backupRef.backupId);
      if (prior?.kind === 'plain') {
        const previous = await migrationCapsuleRead(plainDescriptor(prior, owned.expected.id));
        if (previous.intent.phase !== 'published' || !migrationCapsuleSameMetadata(captured, previous.snapshot)) migrationCapsuleFail('plain_backup_changed');
        proof = { eligibility: previous.intent.conversion.eligibility, newTree: previous.intent.newTree };
        const live = path.join(owned.expected.root, 'skills', physicalSkillId);
        if (!await stat(live)) proof = { eligibility: 'gone', newTree: [] };
        else if (proof.eligibility === 'eligible' && !migrationCapsuleSame(await conversionNative.capture(live, revision), proof.newTree)) proof.eligibility = 'edited';
      } else proof = await plainReceipt(owned.expected, { stamp: backupRef.stamp, skillId: physicalSkillId }, revision);
    }
    entry.eligibility = proof.eligibility;
    let targetTree = proof.newTree;
    if (proof.eligibility === 'eligible') {
      const live = path.join(owned.expected.root, 'skills', physicalSkillId), target = path.join(owned.candidate.root, 'skills', physicalSkillId);
      const original = await platform.capture(live, revision), copied = await platform.capture(target, revision);
      if (!migrationCapsuleSame(original, proof.newTree)) entry.eligibility = 'edited';
      else { entry.reencodedProvenance = await equivalent(original, copied, live, target, physicalSkillId); entry.newTree = migrationCapsuleFingerprint(copied); targetTree = entry.newTree; }
    }
    const intent = { schema: 1, id: physicalSkillId, stamp: backupRef.stamp, revision, phase: 'published', oldRoot: rootId(captured), newTree: targetTree,
      generationId: owned.candidate.id, sourceStage: MIGRATION_SKILL_STAGE_PREFIX + physicalSkillId + '-' + backupRef.stamp,
      conversion: { schema: 1, operationId: currentRepresentation?.targetId === owned.candidate.id ? currentRepresentation.operationId : owned.candidate.id, eligibility: entry.eligibility } };
    await directory(source.backup, true); await fsp.mkdir(source.backup, { recursive: true }); await directory(source.backup);
    await directory(path.join(source.backup, 'objects'), true); await fsp.mkdir(path.join(source.backup, 'objects')).catch(error => { if (error.code !== 'EEXIST') throw error; }); await directory(path.join(source.backup, 'objects'));
    if (await stat(path.join(source.backup, 'archive'))) {
      const previous = await migrationCapsuleRead(source);
      if (!migrationCapsuleSameMetadata(captured, previous.snapshot) || JSON.stringify(previous.intent) !== JSON.stringify(intent)) migrationCapsuleFail('binding_conflict');
    } else {
      const raw = Buffer.from(JSON.stringify(captured), 'utf8'); let bytes;
      try { if (raw.length > MIGRATION_CAPSULE_ARCHIVE_LIMIT) migrationCapsuleFail('capacity'); bytes = require('node:zlib').gzipSync(raw); }
      finally { raw.fill(0); }
      try { await migrationCapsuleArchive(source).write(bytes); } finally { bytes.fill(0); }
      await migrationCapsuleIntent(source).write(JSON.stringify(intent)); await migrationCapsuleRead(source);
    }
    entry.archiveSha = await fileHash(path.join(source.backup, 'archive')); entry.intentSha = await fileHash(path.join(source.backup, 'intent'));
    await conversionNative.flush([source.backup, path.dirname(source.backup), path.dirname(path.dirname(source.backup)), control]);
    return entry;
  }
  async function prepareBindings(token) {
    const owned = plans.get(token); if (!owned) migrationCapsuleFail('owner_token');
    await current(owned.expected); await directory(stableRoot);
    const priorBinding = owned.expected.id ? await bindingsStore(owned.expected.id, sourceKeys).read() : null;
    if (owned.expected.id && (!priorBinding || priorBinding.generationId !== owned.expected.id || priorBinding.storeId !== token.storeId)) migrationCapsuleFail('binding_missing');
    const representation = await representationStore().read();
    const targetMode = owned.candidate.mode || (representation?.targetId === owned.candidate.id ? representation.mode : 'encrypted');
    const entries = []; let ready = true;
    for (const batch of await fsp.readdir(stableRoot, { withFileTypes: true })) {
      if (!batch.isDirectory() || batch.isSymbolicLink() || !/^[0-9TZ-]+$/.test(batch.name)) migrationCapsuleFail('store_entry');
      for (const item of await fsp.readdir(path.join(stableRoot, batch.name), { withFileTypes: true })) {
        if (!item.isDirectory() || item.isSymbolicLink() || !SKILL_ID_RE.test(item.name)) migrationCapsuleFail('store_entry');
        const backupRef = ref(batch.name, item.name, token.storeId), source = descriptor(stableRoot, batch.name, item.name);
        const history = await migrationReadBackupHistory(source.backup, source);
        if (history) {
          if (history.mode !== targetMode) migrationCapsuleFail('representation_mode');
          entries.push({ ref: backupRef, physicalSkillId: item.name, kind: 'history', historyMode: history.mode, phase: history.phase, eligibility: 'terminal', newTree: null,
            archiveSha: await fileHash(path.join(source.backup, 'history')), intentSha: await fileHash(path.join(source.backup, MIGRATION_BACKUP_HISTORY_MARKER)), sourceGenerationId: null });
          continue;
        }
        if (!await migrationCapsulePresent(source.backup, source)) {
          if (targetMode === 'plain') entries.push(await preparePlainBinding(owned, token, backupRef, item.name, priorBinding));
          else { ready = false; entries.push({ ref: backupRef, physicalSkillId: item.name, phase: 'plain', eligibility: 'plain-owner-required' }); }
          continue;
        }
        if (targetMode !== 'encrypted') migrationCapsuleFail('representation_mode');
        const prior = priorBinding?.entries.find(entry => entry.ref.backupId === backupRef.backupId && entry.kind === undefined && entry.phase !== 'plain');
        if (prior) Object.assign(source, { generationId: owned.expected.id, intentFile: path.join(control, 'intents', owned.expected.id, backupRef.backupId + '.sealed'), intentRecordId: source.recordId + ':intent:' + owned.expected.id });
        const record = await migrationCapsuleRead(source), phase = record.intent.phase;
        if (!['published', 'complete', 'aborted'].includes(phase)) migrationCapsuleFail('backup_unsettled');
        const entry = { ref: backupRef, physicalSkillId: item.name, phase, archiveSha: await fileHash(path.join(source.backup, 'archive')),
          intentSha: await fileHash(source.intentFile || path.join(source.backup, 'intent')), sourceGenerationId: prior ? owned.expected.id : null, eligibility: 'terminal', newTree: null };
        if (phase === 'published') {
          await migrationCapsuleVerifyReady(source, record.snapshot);
          if (['edited', 'gone'].includes(record.intent.conversion?.eligibility)) entry.eligibility = record.intent.conversion.eligibility;
          else {
            const sourceLive = path.join(owned.expected.root, 'skills', item.name), targetLive = path.join(owned.candidate.root, 'skills', item.name);
            if (!await stat(sourceLive)) entry.eligibility = 'gone';
            else {
              const original = await platform.capture(sourceLive, record.intent.revision);
              if (!migrationCapsuleSame(original, record.intent.newTree)) entry.eligibility = 'edited';
              else {
                const target = await platform.capture(targetLive, record.intent.revision);
                entry.reencodedProvenance = await equivalent(original, target, sourceLive, targetLive, item.name);
                entry.eligibility = 'eligible'; entry.newTree = migrationCapsuleFingerprint(target);
              }
            }
          }
        }
        const variant = { ...record.intent, generationId: owned.candidate.id, ...(entry.newTree ? { newTree: entry.newTree } : {}) };
        const variantDescriptor = { ...source, generationId: owned.candidate.id,
          intentFile: path.join(control, 'intents', owned.candidate.id, backupRef.backupId + '.sealed'),
          intentRecordId: source.recordId + ':intent:' + owned.candidate.id, intentKeys: targetKeys };
        await directory(path.dirname(variantDescriptor.intentFile), true); await fsp.mkdir(path.dirname(variantDescriptor.intentFile), { recursive: true });
        const variantText = JSON.stringify(variant);
        if (await stat(variantDescriptor.intentFile)) {
          if (await migrationCapsuleIntent(variantDescriptor).read() !== variantText) migrationCapsuleFail('binding_intent');
        } else await migrationCapsuleIntent(variantDescriptor).write(variantText);
        const verified = safeJsonParse(await migrationCapsuleIntent(variantDescriptor).read(), null);
        if (!migrationCapsuleIntentShape(verified, variantDescriptor)) migrationCapsuleFail('binding_intent');
        entries.push(entry);
      }
    }
    const sourceRootIds = [...new Set([...(priorBinding?.sourceRootIds || []), owned.expected.id])];
    const binding = { schema: 2, generationId: owned.candidate.id, storeId: token.storeId, sourceProof: owned.expected.proof.sha256, sourceRootIds, mode: targetMode, ready, entries };
    await fsp.mkdir(path.join(owned.candidate.root, 'migrations'), { recursive: true });
    const previous = await bindingsStore(owned.candidate.id).read();
    if (previous && JSON.stringify(previous) !== JSON.stringify(binding)) migrationCapsuleFail('binding_conflict');
    if (!previous) await bindingsStore(owned.candidate.id).write(binding);
    await current(owned.expected);
    return Object.freeze({ ready, storeId: token.storeId, generationId: owned.candidate.id, entries: entries.length });
  }
  async function storedPhysical(backupRef, binding, selected) {
    if (!refValid(backupRef) || backupRef.storeId !== binding.storeId) migrationCapsuleFail('backup_ref');
    await current(selected);
    const bound = binding.entries.find(row => row.ref.backupId === backupRef.backupId && row.ref.skillId === backupRef.skillId && row.ref.stamp === backupRef.stamp);
    if (bound?.kind === 'plain') {
      const source = plainDescriptor(bound, selected.id), record = await migrationCapsuleRead(source);
      if (!['published', 'restoring', 'complete'].includes(record.intent.phase)) migrationCapsuleFail('binding_intent');
      if (record.intent.phase === 'complete') await migrationFinishPlainHistory(source, record.snapshot, record.intent);
      else await directory(source.plainRoot, record.intent.phase === 'restoring');
      await current(selected); return source.plainRoot;
    }
    const batch = path.join(stableRoot, backupRef.stamp); await directory(batch);
    const matches = (await fsp.readdir(batch, { withFileTypes: true })).filter(item => SKILL_ID_RE.test(item.name)
      && ref(backupRef.stamp, item.name, backupRef.storeId).skillId === backupRef.skillId);
    if (matches.length !== 1 || !matches[0].isDirectory() || matches[0].isSymbolicLink()) migrationCapsuleFail('backup_ref');
    const entry = binding.entries.find(row => row.ref.backupId === backupRef.backupId && row.ref.skillId === backupRef.skillId && row.ref.stamp === backupRef.stamp);
    const physicalSkillId = matches[0].name;
    if (entry && entry.physicalSkillId !== physicalSkillId) migrationCapsuleFail('binding_source_changed');
    const source = descriptor(stableRoot, backupRef.stamp, physicalSkillId);
    await directory(source.backup);
    const history = await migrationReadBackupHistory(source.backup, source);
    if (history) {
      if (entry && (entry.kind !== 'history' || entry.phase !== history.phase || entry.historyMode !== history.mode
        || await fileHash(path.join(source.backup, 'history')) !== entry.archiveSha
        || await fileHash(path.join(source.backup, MIGRATION_BACKUP_HISTORY_MARKER)) !== entry.intentSha)) migrationCapsuleFail('binding_source_changed');
      await current(selected); return source.backup;
    }
    if (entry?.kind === 'history') migrationCapsuleFail('binding_source_changed');
    if (!entry && binding.mode === 'plain') { await current(selected); return source.backup; } // New ordinary OFF backups retain whole-directory undo.
    if (entry) Object.assign(source, { generationId: selected.id, intentKeys: targetKeys,
      intentFile: path.join(control, 'intents', selected.id, backupRef.backupId + '.sealed'),
      intentRecordId: source.recordId + ':intent:' + selected.id });
    // Newly published backups after activation use their original authenticated
    // intent. Enumerating the actual name preserves its exact intent ID on NTFS.
    await migrationCapsuleRead(source); await current(selected);
    return source.backup;
  }
  async function finishPlainHistoryReadOnly(source, snapshot, intent) {
    const captured = capturedReads?.getStore();
    if (!captured) return migrationFinishPlainHistory(source, snapshot, intent);
    // A previously completed plain history can be authenticated without the
    // mutating finish routine. Pending publication belongs to recovery first.
    const target = source.plainRoot, publication = intent.historyPublish;
    const selected = captured.directories.some(name => eq(path.join(base, ...name.split('/')), target));
    if (!selected || !publication) migrationCapsuleFail('plain_history_pending');
    const names = [];
    for (const row of captured.files) { const file = path.join(base, ...row.path.split('/')); if (eq(path.dirname(file), target)) names.push(path.basename(file)); }
    for (const name of captured.directories) { const file = path.join(base, ...name.split('/')); if (eq(path.dirname(file), target)) names.push(path.basename(file) + '/'); }
    if (names.sort().join(',') !== [MIGRATION_BACKUP_HISTORY_MARKER, 'history'].sort().join(',')) migrationCapsuleFail('plain_history_conflict');
    if ((await source.historyHost.info(target)).id !== publication.id) migrationCapsuleFail('plain_history_conflict');
    const history = await migrationReadBackupHistory(target, capturedDescriptor({ ...source, backup: target }));
    if (!history || history.mode !== 'plain' || history.phase !== 'complete'
      || JSON.stringify(history.snapshot) !== JSON.stringify(snapshot)) migrationCapsuleFail('plain_history_conflict');
  }
  async function activate() {
    await recover();
    const prepared = await withCapturedReads(async () => {
    const selected = await active();
    if (!selected.id) migrationCapsuleFail('owner_manifest');
    const catalog = await catalogStore().read(), binding = await bindingsStore(selected.id).read();
    if (!catalog || !binding || !binding.ready || binding.storeId !== catalog.storeId || binding.generationId !== selected.id) migrationCapsuleFail('binding_missing');
    if (safeJsonParse(selected.proof.raw, null)?.mode !== (binding.mode || 'encrypted')) migrationCapsuleFail('representation_mode');
    await directory(stableRoot); const info = await platform.info(stableRoot);
    if (info.id !== catalog.rootId || info.volume !== catalog.volume) migrationCapsuleFail('store_identity');
    const variants = new Map(), eligibility = new Map(), plainRecords = [];
    for (const entry of binding.entries) {
      const physical = path.join(stableRoot, entry.ref.stamp, entry.physicalSkillId);
      if (entry.kind === 'plain') {
        const source = plainDescriptor(entry, selected.id); await directory(source.backup);
        if (await fileHash(path.join(source.backup, 'archive')) !== entry.archiveSha) migrationCapsuleFail('binding_source_changed');
        const record = await migrationCapsuleRead(capturedDescriptor(source));
        if (!['published', 'restoring', 'complete'].includes(record.intent.phase) || record.intent.conversion?.eligibility !== entry.eligibility
          || entry.newTree && JSON.stringify(record.intent.newTree) !== JSON.stringify(entry.newTree)) migrationCapsuleFail('binding_intent');
        if (record.intent.phase === 'published') {
          const actual = await conversionNative.capture(physical, record.intent.revision);
          if (!migrationCapsuleSameMetadata(actual, record.snapshot)) migrationCapsuleFail('plain_backup_changed');
        } else if (record.intent.phase === 'complete') await finishPlainHistoryReadOnly(source, record.snapshot, record.intent);
        const key = entry.ref.stamp + '/' + entry.ref.skillId;
        if (eligibility.has(key)) migrationCapsuleFail('binding_duplicate');
        variants.set(key, source); eligibility.set(key, entry.eligibility); plainRecords.push({ stamp: entry.ref.stamp, id: entry.physicalSkillId, backup: physical }); continue;
      }
      await directory(physical);
      if (entry.kind === 'history') {
        const history = await migrationReadBackupHistory(physical, capturedDescriptor(descriptor(stableRoot, entry.ref.stamp, entry.physicalSkillId)));
        if (!history || history.mode !== entry.historyMode || history.phase !== entry.phase || await fileHash(path.join(physical, 'history')) !== entry.archiveSha
          || await fileHash(path.join(physical, MIGRATION_BACKUP_HISTORY_MARKER)) !== entry.intentSha) migrationCapsuleFail('binding_source_changed');
        const key = entry.ref.stamp + '/' + entry.ref.skillId;
        if (eligibility.has(key)) migrationCapsuleFail('binding_duplicate');
        eligibility.set(key, 'terminal'); continue;
      }
      const sourceIntent = entry.sourceGenerationId ? path.join(control, 'intents', entry.sourceGenerationId, entry.ref.backupId + '.sealed') : path.join(physical, 'intent');
      if (await fileHash(path.join(physical, 'archive')) !== entry.archiveSha || await fileHash(sourceIntent) !== entry.intentSha) migrationCapsuleFail('binding_source_changed');
      const key = entry.ref.stamp + '/' + entry.ref.skillId;
      if (eligibility.has(key)) migrationCapsuleFail('binding_duplicate');
      const variant = { generationId: selected.id, archiveKeys: sourceKeys, intentKeys: targetKeys,
        intentFile: path.join(control, 'intents', selected.id, entry.ref.backupId + '.sealed'),
        intentRecordId: 'skill-backup:' + entry.ref.skillId + ':intent:' + selected.id };
      const record = await migrationCapsuleRead(capturedDescriptor({ ...descriptor(stableRoot, entry.ref.stamp, entry.physicalSkillId), ...variant }));
      const phases = entry.phase === 'published' ? ['published', 'restoring', 'complete'] : [entry.phase];
      if (!phases.includes(record.intent.phase) || entry.newTree && JSON.stringify(record.intent.newTree) !== JSON.stringify(entry.newTree)) migrationCapsuleFail('binding_intent');
      variants.set(key, variant);
      eligibility.set(key, entry.eligibility);
    }
    const resolveLegacy = async absolute => {
      const normalized = path.resolve(String(absolute)), candidates = [legacyRoot, stableRoot];
      for (const root of candidates) {
        const pieces = path.relative(root, normalized).split(path.sep);
        if (pieces.length === 2 && /^[0-9TZ-]+$/.test(pieces[0]) && SKILL_ID_RE.test(pieces[1])) {
          return storedPhysical(ref(pieces[0], pieces[1], catalog.storeId), binding, selected);
        }
      }
      migrationCapsuleFail('backup_ref');
    };
    const authority = Object.freeze({ root: stableRoot, activeRoot: selected.root, skillsRoot: path.join(selected.root, 'skills'),
      legacySkillRoots: Object.freeze(binding.sourceRootIds.map(id => path.join(id === null ? base : generationRoot(id), 'skills'))), storeId: catalog.storeId, variants, eligibility, plainRecords, resolveLegacy,
      makeRef: (stamp, skillId) => ref(stamp, skillId, catalog.storeId),
      resolveRef: value => { if (!refValid(value) || value.storeId !== catalog.storeId) migrationCapsuleFail('backup_ref'); return storedPhysical(value, binding, selected); }, assertCurrent: () => current(selected) });
    const result = Object.freeze({ generationId: selected.id, storeId: catalog.storeId, root: stableRoot });
    // The ordinary host keeps its previous publication point. Only the explicit
    // captured profile defers installation until its final physical proof.
    if (!preservedTree) { migrationBackupAuthority = authority; migrationRecoveryNeeded = true; }
    return { authority, result };
    });
    if (!preservedTree) return prepared.result;
    if (assertExclusiveSync(ownership) !== true) migrationCapsuleFail('owner_preserved_host');
    migrationBackupAuthority = prepared.authority;
    migrationRecoveryNeeded = true;
    return prepared.result;
  }
  async function resolve(backupRef) {
    if (!refValid(backupRef)) migrationCapsuleFail('backup_ref');
    const selected = await active(), catalog = await catalogStore().read();
    if (!selected.id || !catalog || backupRef.storeId !== catalog.storeId) migrationCapsuleFail('backup_ref');
    const binding = await bindingsStore(selected.id).read();
    if (!binding?.ready || binding.storeId !== catalog.storeId || binding.generationId !== selected.id) migrationCapsuleFail('binding_missing');
    const info = await platform.info(stableRoot);
    if (info.id !== catalog.rootId || info.volume !== catalog.volume) migrationCapsuleFail('store_identity');
    return storedPhysical(backupRef, binding, selected);
  }
  // Conversion is a separately recoverable representation transaction. The host
  // keeps the global writer exclusion until recoverRepresentation settles it.
  // This API neither publishes a manifest nor replays a historical skill copy.
  const representationRoot = path.join(control, 'representations-v1');
  const representationValid = value => exact(value, 'schema,operationId,storeId,sourceId,sourceProof,targetId,mode,phase,entries')
    && value.schema === 1 && id48(value.operationId) && id48(value.storeId) && (value.sourceId === null || id48(value.sourceId))
    && (value.sourceProof === null || hex(value.sourceProof)) && id48(value.targetId) && ['plain', 'encrypted'].includes(value.mode)
    && ['prepared', 'converted', 'kept', 'canceled'].includes(value.phase) && Array.isArray(value.entries)
    && value.entries.every(row => exact(row, 'stamp,skillId,backupId') && typeof row.stamp === 'string' && /^[0-9TZ-]+$/.test(row.stamp)
      && typeof row.skillId === 'string' && SKILL_ID_RE.test(row.skillId) && row.backupId === hash(row.stamp + '/' + (process.platform === 'win32' ? row.skillId.toLowerCase() : row.skillId)))
    && new Set(value.entries.map(row => row.backupId)).size === value.entries.length;
  const representationStore = () => sealed(path.join(control, 'representation-v1.sealed'), 'representation-v1', representationValid, sourceKeys);
  function representationPaths(journal, row) {
    const anchor = path.join(representationRoot, journal.operationId, row.backupId);
    return { anchor, backup: path.join(stableRoot, row.stamp, row.skillId), capsule: path.join(anchor, 'capsule'), history: path.join(anchor, 'history'), restored: path.join(anchor, 'restored') };
  }
  function representationRecordValid(value) {
    if (!exact(value, 'schema,operationId,stamp,skillId,oldType,oldMode,oldPhase,eligibility,capsuleId,historyId,historyTree,revision,original,target,newTree,sourceGenerationId,archiveSha,intentSha,phase') || value.schema !== 1
      || !id48(value.operationId) || typeof value.stamp !== 'string' || !/^[0-9TZ-]+$/.test(value.stamp)
      || typeof value.skillId !== 'string' || !SKILL_ID_RE.test(value.skillId) || !['plain', 'capsule', 'history'].includes(value.oldType) || !['plain', 'encrypted'].includes(value.oldMode)
      || !['published', 'complete', 'aborted'].includes(value.oldPhase) || !['eligible', 'edited', 'gone', 'terminal'].includes(value.eligibility)
      || !id24(value.capsuleId) || !hex(value.revision) || !migrationCapsuleShape(value.original) || !migrationCapsuleShape(value.target)
      || !(value.sourceGenerationId === null || id48(value.sourceGenerationId)) || !hex(value.archiveSha) || !hex(value.intentSha)
      || (value.eligibility === 'terminal' ? !id24(value.historyId) || !migrationCapsuleFingerprintShape(value.historyTree) : value.historyId !== null || value.historyTree !== null)
      || value.original.revision !== value.revision || value.target.revision !== value.revision
      || !['prepared', 'forward', 'canceled'].includes(value.phase)
      || (value.eligibility !== 'gone' && value.eligibility !== 'terminal' && !migrationCapsuleFingerprintShape(value.newTree))) return false;
    const left = JSON.parse(JSON.stringify(value.original)), right = JSON.parse(JSON.stringify(value.target));
    for (const snapshot of [left, right]) for (const entry of snapshot.entries) if (entry.rel === SKILL_IMPORT_RECORD)
      for (const stream of entry.streams) if (stream.name === '') { delete stream.data; delete stream.hash; delete stream.size; }
    return JSON.stringify(left) === JSON.stringify(right);
  }
  const representationRecordStore = (journal, row) => sealed(path.join(representationPaths(journal, row).anchor, 'record-v1.sealed'),
    'representation:' + journal.operationId + ':' + row.backupId, representationRecordValid, sourceKeys);
  const rootId = snapshot => snapshot.entries.find(entry => entry.rel === '').id;
  async function conversionRoots(paths, snapshot) {
    const roots = [];
    for (const root of [paths.backup, path.join(paths.restored, rootId(snapshot))]) {
      const value = await stat(root);
      if (value && value.isDirectory() && !value.isSymbolicLink()
        && (await fsp.stat(root, { bigint: true })).ino.toString(16).padStart(16, '0') === rootId(snapshot).slice(8)) roots.push(root);
    }
    const objects = path.join(paths.capsule, 'objects'); await directory(objects);
    for (const entry of await fsp.readdir(objects)) roots.push(path.join(objects, entry));
    return roots;
  }
  const conversionNative = native || {
    createOwnedPortable: async ({root,snapshot,revision}) => migrationCapsuleCreateOwnedPortable(root,snapshot,revision),
    ...platform,
    capture: async (root, revision) => { const broker = await migrationCapsuleBroker(); try { return await broker.command({ cmd: 'capture-preserved', root, revision }); } finally { await broker.close(); } },
    flush: async roots => { const broker = await migrationCapsuleBroker(); try { for (const root of roots) await broker.command({ cmd: 'store-flush', root }); } finally { await broker.close(); } },
    seal: async ({ root, container, snapshot }) => { const broker = await migrationCapsuleBroker(); try {
      await broker.command({ cmd: 'attach', roots: [root], snapshot });
      await broker.command({ cmd: 'seal-attached', container }); await broker.command({ cmd: 'verify', cleared: true });
    } finally { await broker.close(); } },
    materialize: async ({ roots, snapshot, alternate, paths }) => { const broker = await migrationCapsuleBroker(); try {
      await broker.command({ cmd: 'attach', roots, snapshot }); await broker.command({ cmd: 'publish-check', target: paths.backup });
      await broker.command({ cmd: 'restore', target: path.join(paths.restored, rootId(snapshot)), container: path.join(paths.capsule, 'objects'), allowedSnapshot: alternate });
      await broker.command({ cmd: 'publish', target: paths.backup, container: path.join(paths.capsule, 'objects') });
    } finally { await broker.close(); } },
  };
  function requireConversionNative() {
    if (['info', 'move', 'capture', 'flush', 'seal', 'materialize'].some(name => typeof conversionNative[name] !== 'function')) migrationCapsuleFail('representation_host');
  }
  async function conversionLocation(paths, record) {
    const matches = [];
    for (const root of [paths.backup, paths.capsule]) {
      if (!await directory(root, true)) continue;
      const info = await conversionNative.info(root);
      if (info.id === record.capsuleId) matches.push(root);
      else if (info.id !== rootId(record.original) && info.id !== record.historyId) migrationCapsuleFail('representation_identity', true);
    }
    if (matches.length !== 1) migrationCapsuleFail('representation_location', true);
    return matches[0];
  }
  async function moveConversionCapsule(paths, record, target) {
    const source = await conversionLocation(paths, record);
    if (eq(source, target)) return;
    if (await stat(target)) migrationCapsuleFail('representation_target', true);
    const before = await conversionNative.info(source), moved = await conversionNative.move({ source, target, id: record.capsuleId });
    if (!moved || moved.id !== record.capsuleId || moved.volume !== before.volume) migrationCapsuleFail('representation_identity', true);
  }
  async function verifyConversionCarrier(journal, row, record) {
    const paths = representationPaths(journal, row), capsule = await conversionLocation(paths, record);
    const source = descriptor(stableRoot, row.stamp, row.skillId); source.backup = capsule;
    if (record.sourceGenerationId) Object.assign(source, { generationId: record.sourceGenerationId,
      intentFile: path.join(control, 'intents', record.sourceGenerationId, row.backupId + '.sealed'),
      intentRecordId: source.recordId + ':intent:' + record.sourceGenerationId });
    if (record.oldType === 'history') {
      const history = await migrationReadBackupHistory(capsule, source);
      if (!history || history.mode !== record.oldMode || JSON.stringify(history.snapshot) !== JSON.stringify(record.original)
        || await fileHash(path.join(capsule, 'history')) !== record.archiveSha
        || await fileHash(path.join(capsule, MIGRATION_BACKUP_HISTORY_MARKER)) !== record.intentSha) migrationCapsuleFail('representation_carrier_changed', true);
      return;
    }
    if (await fileHash(path.join(capsule, 'archive')) !== record.archiveSha
      || await fileHash(source.intentFile || path.join(capsule, 'intent')) !== record.intentSha) migrationCapsuleFail('representation_carrier_changed', true);
    const authenticated = await migrationCapsuleRead(source);
    if (JSON.stringify(authenticated.snapshot) !== JSON.stringify(record.oldType === 'plain' ? record.target : record.original)) migrationCapsuleFail('representation_carrier_changed', true);
  }
  function importShape(text) {
    const value = safeJsonParse(text, null);
    return Buffer.byteLength(text, 'utf8') <= 16 * 1024 && value && typeof value === 'object' && !Array.isArray(value)
      && value.schema === 1 && SKILL_IMPORT_SOURCES.includes(value.source)
      && ['plugin', 'sourcePath', 'importedAt', 'sourceTreeHash', 'copyTreeHash'].every(name => typeof value[name] === 'string');
  }
  async function representationSnapshot(snapshot, mode, paths, skillId) {
    const target = JSON.parse(JSON.stringify(snapshot)), entry = target.entries.find(entry => entry.rel === SKILL_IMPORT_RECORD);
    if (!entry) return target;
    if (entry.dir) migrationCapsuleFail('representation_provenance');
    const stream = entry.streams.find(stream => stream.name === ''), raw = Buffer.from(stream.data, 'base64');
    try {
      const text = raw.toString('utf8'); if (!Buffer.from(text, 'utf8').equals(raw)) migrationCapsuleFail('representation_provenance');
      const first = safeJsonParse(text.split('\n')[0], null), whole = safeJsonParse(text, null);
      const carrier = first && typeof first === 'object' && Object.hasOwn(first, 'workData') ? first : whole;
      const marked = carrier && typeof carrier === 'object' && Object.hasOwn(carrier, 'workData');
      let logical = text;
      const host = { purpose: 'backup', schema: 1, scopeId: 'skills', recordId: 'skill-import:' + (process.platform === 'win32' ? skillId.toLowerCase() : skillId),
        keys: sourceKeys, chunked: true, maxPlaintextBytes: 16 * 1024, validateSealedText: importShape, writeJson: atomicWriteJson, enabled: async () => true };
      if (marked) {
        if (raw.length > WorkDataChunks.maxFileBytes(16 * 1024)) migrationCapsuleFail('representation_provenance');
        const generation = /\.k(\d{1,2})$/.exec(String(carrier.keyId || ''));
        if (!generation || !['2', '3'].includes(String(carrier.workData))) migrationCapsuleFail('representation_provenance');
        const lease = await WorkDataStore.acquireSnapshot(sourceKeys);
        try {
          const expected = { purpose: host.purpose, instanceId: lease.instanceId, schema: host.schema, scopeId: host.scopeId,
            recordId: host.recordId, seq: carrier.workData === 3 ? 1 : carrier.seq, generation: Number(generation[1]) };
          if (carrier.workData === 3) {
            if (!text.endsWith('\n')) migrationCapsuleFail('representation_provenance');
            const lines = text.slice(0, -1).split('\n');
            logical = await WorkDataChunks.openLines(lines, lease.key, expected, 16 * 1024);
          } else { const { workData, ...container } = whole || {}; if (workData !== 2) migrationCapsuleFail('representation_provenance'); logical = WorkDataCrypto.open(container, lease.key, expected); }
        } finally { await lease.release(); }
      }
      if (!importShape(logical)) migrationCapsuleFail('representation_provenance');
      let data;
      if (mode === 'encrypted') {
        const targetFile = path.join(paths.anchor, 'import-target.sealed');
        const store = WorkDataStore.createText({ ...host, keys: targetKeys, file: () => targetFile });
        await store.write(logical); if (await store.read() !== logical) migrationCapsuleFail('representation_provenance');
        data = await fsp.readFile(targetFile);
      } else data = Buffer.from(logical, 'utf8');
      try { stream.size = data.length; stream.hash = hash(data); stream.data = data.toString('base64'); } finally { data.fill(0); }
      if (!migrationCapsuleShape(target)) migrationCapsuleFail('representation_capacity');
      return target;
    } finally { raw.fill(0); }
  }
  async function plainReceipt(expected, row, revision) {
    const live = path.join(expected.root, 'skills', row.skillId);
    if (!await stat(live)) return { eligibility: 'gone', newTree: [] };
    const captured = await conversionNative.capture(live, revision);
    const currentTree = migrationCapsuleFingerprint(captured);
    let logical = null;
    const log = WorkDataStore.createText({ file: () => path.join(expected.root, 'migrations', row.stamp + '.json'), purpose: 'migration', schema: 1,
      scopeId: 'global', recordId: 'migration-log:' + row.stamp, keys: sourceKeys, chunked: true, maxPlaintextBytes: 256 * 1024 * 1024,
      enabled: async () => true, validateSealedText: text => migrationLogShape(safeJsonParse(text, null), row.stamp), writeJson: atomicWriteJson });
    try { logical = safeJsonParse(await log.read(), null); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    const receipt = migrationLogShape(logical, row.stamp) && logical.files.find(file => file.kind === 'skill-copy'
      && file.items.length === 1 && file.items[0].id === row.skillId && eq(file.file, live)
      && typeof file.backup === 'string'
      && [path.join(legacyRoot, row.stamp, row.skillId), path.join(stableRoot, row.stamp, row.skillId)].some(root => eq(file.backup, root)));
    const digest = crypto.createHash('sha256');
    for (const entry of captured.entries.filter(entry => !entry.dir && entry.rel !== SKILL_IMPORT_RECORD).sort((a, b) => a.rel < b.rel ? -1 : a.rel > b.rel ? 1 : 0))
      digest.update(entry.rel + '\0' + entry.streams.find(stream => stream.name === '').hash + '\n');
    const contentHash = digest.digest('hex');
    // Legacy receipts did not bind object IDs/ADS. Do not bless unknown DATA
    // streams merely because their default-stream content still matches a log.
    const ordinaryStreams = captured.entries.every(entry => entry.streams.every(stream => stream.name === ''));
    return { eligibility: receipt && receipt.items[0].copyTreeHash === contentHash && ordinaryStreams ? 'eligible' : 'edited', newTree: currentTree };
  }
  async function writeConversionCapsule(paths, row, record) {
    const source = descriptor(paths.anchor, row.stamp, row.skillId); source.backup = paths.capsule;
    await atomicWriteJson(path.join(paths.capsule, MIGRATION_CAPSULE_MARKER), { version: 1 });
    await fsp.mkdir(path.join(paths.capsule, 'objects')); await directory(path.join(paths.capsule, 'objects'));
    const raw = Buffer.from(JSON.stringify(record.target), 'utf8'); let bytes;
    try { bytes = require('node:zlib').gzipSync(raw); } finally { raw.fill(0); }
    try { await migrationCapsuleArchive(source).write(bytes); } finally { bytes.fill(0); }
    const intent = { schema: 1, id: row.skillId, stamp: row.stamp, revision: record.revision, phase: 'published', oldRoot: rootId(record.target),
      newTree: record.newTree, sourceStage: MIGRATION_SKILL_STAGE_PREFIX + row.skillId + '-' + row.stamp,
      conversion: { schema: 1, operationId: record.operationId, eligibility: record.eligibility } };
    await migrationCapsuleIntent(source).write(JSON.stringify(intent)); await migrationCapsuleRead(source);
  }
  async function prepareHistory(paths, row, record, mode) {
    await fsp.mkdir(paths.history); await directory(paths.history);
    const descriptor = { ...descriptorForHistory(row), backup: paths.history, archiveKeys: targetKeys };
    const payload = { schema: 1, type: 'terminal-skill-backup-history', historyOnly: true, id: row.skillId, stamp: row.stamp, phase: record.oldPhase, snapshot: record.target };
    await migrationBackupHistoryStore(descriptor, mode).write(JSON.stringify(payload));
    await atomicWriteJson(path.join(paths.history, MIGRATION_BACKUP_HISTORY_MARKER), { schema: 1, mode });
    const read = await migrationReadBackupHistory(paths.history, descriptor); if (!read || read.phase !== record.oldPhase) migrationCapsuleFail('history_carrier');
    const captured = await conversionNative.capture(paths.history, record.revision);
    record.historyId = rootId(captured); record.historyTree = migrationCapsuleFingerprint(captured);
  }
  function descriptorForHistory(row) { return descriptor(stableRoot, row.stamp, row.skillId); }
  async function moveHistory(paths, record, target) {
    const found = [];
    for (const source of [paths.history, paths.backup]) if (await directory(source, true) && (await conversionNative.info(source)).id === record.historyId) found.push(source);
    if (found.length !== 1) migrationCapsuleFail('representation_history_location', true);
    const source = found[0], captured = await conversionNative.capture(source, record.revision);
    if (!migrationCapsuleSame(captured, record.historyTree)) migrationCapsuleFail('representation_history_changed', true);
    if (eq(source, target)) return;
    if (await stat(target)) migrationCapsuleFail('representation_target', true);
    const before = await conversionNative.info(source), result = await conversionNative.move({ source, target, id: record.historyId });
    if (!result || result.id !== record.historyId || result.volume !== before.volume) migrationCapsuleFail('representation_identity', true);
  }
  async function runRepresentation(journal, row, record, forward) {
    const paths = representationPaths(journal, row), wantCapsule = forward ? journal.mode === 'encrypted' : record.oldType === 'capsule';
    await verifyConversionCarrier(journal, row, record);
    if (record.eligibility === 'terminal') {
      // These IDs now belong to live/retained objects elsewhere. Preserve only
      // typed history and the original wrapper; never instantiate or move them.
      if (forward) { await moveConversionCapsule(paths, record, paths.capsule); await moveHistory(paths, record, paths.backup); }
      else { await moveHistory(paths, record, paths.history); await moveConversionCapsule(paths, record, paths.backup); }
    } else if (wantCapsule) {
      // First materialize the exact representation that is being sealed. This
      // reconciles any interrupted flatten/write using only two authenticated snapshots.
      await moveConversionCapsule(paths, record, paths.capsule);
      const snapshot = forward ? record.original : record.target, desired = forward ? record.target : record.original;
      await fsp.mkdir(paths.restored, { recursive: true }); await directory(paths.restored);
      await conversionNative.materialize({ paths, snapshot, alternate: desired, roots: await conversionRoots(paths, snapshot) });
      await conversionNative.flush([paths.anchor, paths.capsule, path.dirname(paths.backup), control]);
      await conversionNative.seal({ root: paths.backup, container: path.join(paths.capsule, 'objects'), snapshot });
      await moveConversionCapsule(paths, record, paths.backup);
    } else {
      await moveConversionCapsule(paths, record, paths.capsule);
      const snapshot = forward ? record.target : record.original, alternate = forward ? record.original : record.target;
      await fsp.mkdir(paths.restored, { recursive: true }); await directory(paths.restored);
      await conversionNative.materialize({ paths, snapshot, alternate, roots: await conversionRoots(paths, snapshot) });
    }
    await conversionNative.flush([paths.anchor, path.dirname(paths.backup), control]);
    record.phase = forward ? 'forward' : 'canceled'; await representationRecordStore(journal, row).write(record);
  }
  async function prepareRepresentation(token, { mode } = {}) {
    requireConversionNative(); const owned = plans.get(token); if (!owned || !['plain', 'encrypted'].includes(mode)) migrationCapsuleFail('representation_host');
    if (owned.candidate.mode !== undefined && owned.candidate.mode !== mode) migrationCapsuleFail('representation_mode');
    await current(owned.expected); await directory(stableRoot);
    const prior = await representationStore().read();
    if (prior && !['kept', 'canceled'].includes(prior.phase)) migrationCapsuleFail('representation_busy', true);
    const journal = { schema: 1, operationId: crypto.randomBytes(24).toString('hex'), storeId: token.storeId, sourceId: owned.expected.id,
      sourceProof: owned.expected.proof.sha256, targetId: owned.candidate.id, mode, phase: 'prepared', entries: [] };
    const records = [];
    // Capture and persist every supported record before clearing any original DATA.
    for (const batch of await fsp.readdir(stableRoot, { withFileTypes: true })) {
      if (!batch.isDirectory() || batch.isSymbolicLink() || !/^[0-9TZ-]+$/.test(batch.name)) migrationCapsuleFail('store_entry');
      for (const item of await fsp.readdir(path.join(stableRoot, batch.name), { withFileTypes: true })) {
        if (!item.isDirectory() || item.isSymbolicLink() || !SKILL_ID_RE.test(item.name)) migrationCapsuleFail('store_entry');
        const row = { stamp: batch.name, skillId: item.name, backupId: ref(batch.name, item.name, token.storeId).backupId }, paths = representationPaths(journal, row);
        const source = descriptor(stableRoot, row.stamp, row.skillId), history = await migrationReadBackupHistory(source.backup, source);
        const capsule = !history && await migrationCapsulePresent(source.backup, source), oldMode = history ? history.mode : capsule ? 'encrypted' : 'plain';
        if (oldMode === mode) continue;
        await directory(paths.anchor, true); await fsp.mkdir(paths.anchor, { recursive: true }); await directory(paths.anchor);
        let original, oldPhase = 'published', eligibility, newTree, revision, sourceGenerationId = null;
        if (history) {
          original = history.snapshot; revision = original.revision; oldPhase = history.phase; eligibility = 'terminal'; newTree = [];
        } else if (capsule) {
          const sourceBinding = owned.expected.id ? await bindingsStore(owned.expected.id, sourceKeys).read() : null;
          if (sourceBinding?.entries.some(entry => entry.ref.backupId === row.backupId)) {
            sourceGenerationId = owned.expected.id;
            Object.assign(source, { generationId: sourceGenerationId, intentFile: path.join(control, 'intents', sourceGenerationId, row.backupId + '.sealed'),
              intentRecordId: source.recordId + ':intent:' + sourceGenerationId });
          }
          const existing = await migrationCapsuleRead(source); original = existing.snapshot; revision = original.revision;
          oldPhase = existing.intent.phase; if (!['published', 'complete', 'aborted'].includes(oldPhase)) migrationCapsuleFail('backup_unsettled');
          if (oldPhase !== 'published') {
            const objects = path.join(paths.backup, 'objects'); await directory(objects);
            if ((await fsp.readdir(objects)).length || await stat(path.join(paths.backup, 'retired'))) migrationCapsuleFail('representation_terminal_unsettled');
            eligibility = 'terminal'; newTree = [];
          }
          else {
            await migrationCapsuleVerifyReady(source, original); eligibility = existing.intent.conversion?.eligibility || 'eligible'; newTree = existing.intent.newTree;
            const live = path.join(owned.expected.root, 'skills', row.skillId);
            if (!await stat(live)) { eligibility = 'gone'; newTree = []; }
            else {
              const captured = await conversionNative.capture(live, revision);
              if (eligibility === 'eligible' && !migrationCapsuleSame(captured, existing.intent.newTree)) eligibility = 'edited';
              newTree = migrationCapsuleFingerprint(captured);
            }
          }
        } else { revision = crypto.randomBytes(32).toString('hex'); original = await conversionNative.capture(paths.backup, revision);
          const priorBinding = owned.expected.id ? await bindingsStore(owned.expected.id, sourceKeys).read() : null;
          const prior = priorBinding?.entries.find(entry => entry.ref.backupId === row.backupId);
          if (prior?.kind === 'plain') {
            const previous = await migrationCapsuleRead(plainDescriptor(prior, owned.expected.id));
            if (previous.intent.phase !== 'published' || !migrationCapsuleSameMetadata(original, previous.snapshot)) migrationCapsuleFail('plain_backup_changed');
            eligibility = previous.intent.conversion.eligibility; newTree = previous.intent.newTree;
            const live = path.join(owned.expected.root, 'skills', row.skillId);
            if (!await stat(live)) { eligibility = 'gone'; newTree = []; }
            else if (eligibility === 'eligible' && !migrationCapsuleSame(await conversionNative.capture(live, revision), newTree)) eligibility = 'edited';
          } else ({ eligibility, newTree } = await plainReceipt(owned.expected, row, revision)); }
        if (!migrationCapsuleShape(original)) migrationCapsuleFail('representation_shape');
        const target = await representationSnapshot(original, mode, paths, row.skillId);
        if (!capsule && !history) { await fsp.mkdir(paths.capsule); await directory(paths.capsule); }
        const info = await conversionNative.info(capsule || history ? paths.backup : paths.capsule);
        const record = { schema: 1, operationId: journal.operationId, stamp: row.stamp, skillId: row.skillId, oldType: history ? 'history' : capsule ? 'capsule' : 'plain', oldMode,
          oldPhase, eligibility, capsuleId: info.id, historyId: null, historyTree: null, revision, original, target, newTree, sourceGenerationId, archiveSha: '', intentSha: '', phase: 'prepared' };
        if (eligibility === 'terminal') await prepareHistory(paths, row, record, mode);
        else if (!capsule) await writeConversionCapsule(paths, row, record);
        const carrier = capsule || history ? paths.backup : paths.capsule;
        record.archiveSha = await fileHash(path.join(carrier, history ? 'history' : 'archive'));
        record.intentSha = await fileHash(history ? path.join(carrier, MIGRATION_BACKUP_HISTORY_MARKER) : source.intentFile || path.join(carrier, 'intent'));
        if (!representationRecordValid(record)) migrationCapsuleFail('representation_shape');
        await representationRecordStore(journal, row).write(record); journal.entries.push(row); records.push(record);
      }
    }
    if (!journal.entries.length) return Object.freeze({ mode, entries: 0, phase: 'unchanged' });
    await representationStore().write(journal); await current(owned.expected);
    try {
      const durableDirectories = [control, stableRoot, representationRoot, path.join(representationRoot, journal.operationId)];
      for (let index = 0; index < journal.entries.length; index++) {
        const paths = representationPaths(journal, journal.entries[index]), record = records[index];
        durableDirectories.push(paths.anchor, path.dirname(paths.backup), record.oldType === 'plain' ? paths.capsule : paths.backup);
        if (record.sourceGenerationId) durableDirectories.push(path.join(control, 'intents', record.sourceGenerationId));
        if (record.eligibility === 'terminal') durableDirectories.push(paths.history);
      }
      await conversionNative.flush([...new Set(durableDirectories)]);
      for (let index = 0; index < journal.entries.length; index++) await runRepresentation(journal, journal.entries[index], records[index], true);
      journal.phase = 'converted'; await representationStore().write(journal); await current(owned.expected);
      return Object.freeze({ operationId: journal.operationId, mode, entries: journal.entries.length, phase: journal.phase });
    } catch (error) { throw representationUncertain(error); }
  }
  function representationUncertain(cause) {
    // Native/host failures may be frozen errors, primitives or objects with
    // throwing getters. Never trust their writable flags after DATA mutation.
    let code = 'work_data_backup.representation_uncertain';
    try { if (typeof cause?.code === 'string' && /^[a-zA-Z0-9_.-]{1,128}$/.test(cause.code)) code = cause.code; } catch { /* retain controlled code */ }
    return Object.assign(new Error(code, { cause }), { code, apiCode: code, statusCode: 503,
      operationMayHaveExecuted: true, resultUnavailable: true, retry: false });
  }
  async function recoverRepresentation() {
    const journal = await representationStore().read(); if (!journal || ['kept', 'canceled'].includes(journal.phase)) return journal;
    requireConversionNative(); const selected = await active(), keep = selected.id === journal.targetId;
    if (!keep && (selected.id !== journal.sourceId || selected.proof.sha256 !== journal.sourceProof)) migrationCapsuleFail('generation_changed', true);
    if (keep && safeJsonParse(selected.proof.raw, null)?.mode !== journal.mode) migrationCapsuleFail('representation_mode', true);
    try { for (const row of journal.entries) {
      const record = await representationRecordStore(journal, row).read();
      if (!record || record.operationId !== journal.operationId || record.stamp !== row.stamp || record.skillId !== row.skillId) migrationCapsuleFail('representation_missing', true);
      await runRepresentation(journal, row, record, keep);
    }
    journal.phase = keep ? 'kept' : 'canceled'; await representationStore().write(journal); return Object.freeze({ phase: journal.phase, mode: journal.mode, entries: journal.entries.length });
    } catch (error) { throw representationUncertain(error); }
  }

  // Read-only completion proof for the ordinary host's empty stable store.
  // Recovery/activate may mutate journals; never invoke them from this verifier.
  async function verifyPublished({ expected } = {}) {
    const selected = await current(expected), catalog = await catalogStore().read(), binding = await bindingsStore(selected.id).read(), journal = await journalStore().read();
    if (!selected.id || !catalog || !binding || !journal || !binding.ready || binding.entries.length
      || binding.generationId !== selected.id || binding.storeId !== catalog.storeId || (binding.mode || 'encrypted') !== safeJsonParse(selected.proof.raw, null)?.mode
      || journal.phase !== 'kept' || journal.targetId !== selected.id && !binding.sourceRootIds.includes(journal.targetId) || journal.storeId !== catalog.storeId
      || journal.rootId !== catalog.rootId || journal.volume !== catalog.volume || journal.targetId === selected.id && binding.sourceProof !== journal.sourceProof) migrationCapsuleFail('published_empty_proof');
    await directory(control); await directory(stableRoot); const info = await platform.info(stableRoot);
    if (info.id !== catalog.rootId || info.volume !== catalog.volume) migrationCapsuleFail('store_identity');
    const names = (await fsp.readdir(control)).sort();
    if (names.join(',') !== ['catalog-v1.sealed', 'objects-v1', 'relocation-v1.sealed'].sort().join(',') || (await fsp.readdir(stableRoot)).length) migrationCapsuleFail('published_empty_proof');
    await current(selected);
    return Object.freeze({ generationId: selected.id, storeId: catalog.storeId, rootId: catalog.rootId, volume: catalog.volume,
      mode: binding.mode || 'encrypted', entries: 0, readOnly: true });
  }
  // Portable layer 1 owns only settled controls and terminal typed history.
  // Any live or retained original-object capsule is refused until its separate
  // create-owned-portable native staging path is available.
  const portableStages = new WeakMap();
  const portableFold = value => process.platform === 'win32' ? value.toLowerCase() : value;
  const portableSort = (a,b) => a < b ? -1 : a > b ? 1 : 0;
  const portableJSON = value => JSON.stringify(value);
  const portableClone = value => JSON.parse(portableJSON(value));
  function portableAuthority(files) {
    const row = files.find(file => portableFold(file.path) === '.work-data/active-v1.json');
    if (!row) return { id:null,generation:0,mode:'plain',raw:null,sha256:null };
    const raw = row.data.toString('utf8');
    if (!Buffer.from(raw).equals(row.data)) migrationCapsuleFail('portable_authority');
    const value = safeJsonParse(raw,null);
    if (!exact(value,'schema,id,generation,mode,activeRoot') || value.schema !== 1 || !id48(value.id)
      || !Number.isSafeInteger(value.generation) || value.generation < 1 || !['plain','encrypted'].includes(value.mode)
      || value.activeRoot !== 'generations/' + value.id) migrationCapsuleFail('portable_authority');
    return {id:value.id,generation:value.generation,mode:value.mode,raw,sha256:hash(row.data)};
  }
  function portableInput(request) {
    if (!request || !Array.isArray(request.files) || !Array.isArray(request.directories)
      || !request.source || typeof request.source.sourcePath !== 'string' || !hex(request.source.sourceSha256)
      || !Array.isArray(request.source.files) || !Array.isArray(request.source.directories)
      || typeof request.readCaptured !== 'function') migrationCapsuleFail('portable_host');
    const completeSource=WorkDataRecovery.skillBackupSource(request.files,request.directories);
    if(request.source.sourcePath!==completeSource.sourcePath||request.source.sourceSha256!==completeSource.sourceSha256
      ||portableJSON(request.source.files)!==portableJSON(completeSource.files)||portableJSON(request.source.directories)!==portableJSON(completeSource.directories))migrationCapsuleFail('portable_source');
    const files = new Map();
    for (const row of request.files) {
      if (!row || typeof row.path !== 'string' || !Buffer.isBuffer(row.data) || files.has(portableFold(row.path))) migrationCapsuleFail('portable_source');
      files.set(portableFold(row.path),row);
    }
    const scoped = new Map();
    for (const row of request.source.files) {
      const actual=files.get(portableFold(row.path));
      if (!actual || actual.path !== row.path || actual.data.length !== row.size || hash(actual.data) !== row.sha256
        || scoped.has(portableFold(row.path))) migrationCapsuleFail('portable_source');
      scoped.set(portableFold(row.path),actual);
    }
    const dirs=new Map(request.source.directories.map(name=>[portableFold(name),name]));
    if (dirs.size !== request.source.directories.length || request.source.directories.some(name=>!request.directories.includes(name))) migrationCapsuleFail('portable_source');
    return {files,scoped,dirs,source:request.source,read:request.readCaptured};
  }
  const portableDurabilityProofs=new WeakMap();
  function portableRequireDurabilityHost(){if(native&&typeof native.openPortableDurability!=='function')migrationCapsuleFail('portable_durability_required');}
  function portableProofRows(snapshot){return snapshot.entries.map(entry=>({rel:entry.rel,id:entry.id,dir:entry.dir,attrs:entry.attrs,shortName:entry.shortName,times:entry.times,streams:entry.streams.map(stream=>({name:stream.name,size:stream.size,hash:stream.hash,data:stream.data})).sort((a,b)=>portableSort(a.name,b.name))})).sort((a,b)=>portableSort(a.rel,b.rel));}
  function portableProofExact(actual,expected){return migrationCapsuleShape(actual)&&migrationCapsuleShape(expected)&&actual.revision===expected.revision&&migrationCapsuleSameMetadata(actual,expected)&&portableJSON(portableProofRows(actual))===portableJSON(portableProofRows(expected));}
  function portableWithin(root,file){const relative=path.relative(samePathKey(root),samePathKey(file));return relative===''||relative!=='..'&&!relative.startsWith('..'+path.sep)&&!path.isAbsolute(relative);}
  async function portableWithDurabilityBroker(work){
    portableRequireDurabilityHost();const broker=await(native?native.openPortableDurability():migrationCapsuleBroker());let result,failure,failed=false;
    if(!broker||typeof broker.command!=='function'||typeof broker.close!=='function'){let closed=false;try{if(broker&&typeof broker.close==='function')closed=await broker.close()===undefined;}catch{}throw Object.assign(new Error('work_data_backup.portable_durability_host'),{code:'work_data_backup.portable_durability_host',helperMayStillRun:!closed,operationMayHaveExecuted:true,resultUnavailable:true,retry:false});}
    try{result=await work(broker);}catch(cause){failure=cause;failed=true;}
    try{if(await broker.close()!==undefined)throw Error('portable_close_unproven');}catch(cause){throw Object.assign(new Error('work_data_backup.portable_durability_uncertain',{cause}),{code:'work_data_backup.portable_durability_uncertain',helperMayStillRun:true,operationMayHaveExecuted:true,resultUnavailable:true,retry:false,...(failed?{operationCause:failure}:{})});}
    if(failed)throw failure;return result;
  }
  async function portableBindExternal(roots,role,admission){
    if(!Array.isArray(roots)||!['external-parent','new-target-ancestor'].includes(role))migrationCapsuleFail('portable_durability_binding');
    const unique=new Map();for(const root of roots){if(typeof root!=='string'||!path.isAbsolute(root)||path.resolve(root)!==root)migrationCapsuleFail('portable_durability_binding');unique.set(samePathKey(root),root);}
    const ordered=[...unique.values()].sort((a,b)=>b.length-a.length||portableSort(a,b)),bindings=[],identities=new Set();
    for(const root of ordered){await admission();await directory(root);const info=await platform.info(root);await admission();if(!info||!id24(info.id)||typeof info.volume!=='string'||info.volume.length<1||info.volume.length>128||identities.has(info.volume+':'+info.id))migrationCapsuleFail('portable_durability_binding');identities.add(info.volume+':'+info.id);bindings.push(Object.freeze({root,id:info.id,volume:info.volume,role,ordinal:bindings.length}));}
    return Object.freeze(bindings);
  }
  async function portableFlushBound(bindings,admission){
    if(!Array.isArray(bindings)||bindings.some((row,index)=>!row||row.ordinal!==index))migrationCapsuleFail('portable_durability_binding');
    if(bindings.length===0)return Object.freeze([]);
    return portableWithDurabilityBroker(async broker=>{const receipts=[];for(const binding of bindings){await admission();const reply=await broker.command({cmd:'store-flush-bound',...binding});await admission();if(!exact(reply,'flushed,id,kind,ordinal,role,root,schema,volume')||reply.schema!==1||reply.kind!=='bound-directory-flush-v1'||reply.flushed!==true||['root','id','volume','role','ordinal'].some(key=>reply[key]!==binding[key]))migrationCapsuleFail('portable_durability_receipt');receipts.push(Object.freeze({...reply}));}return Object.freeze(receipts);});
  }
  async function portableStageDurability(root,fixedProof,identity,requestedRoots,externalBindings,admission){
    if(typeof root!=='string'||!migrationCapsuleShape(fixedProof)||!identity||!id24(identity.id)||typeof identity.volume!=='string'||fixedProof.entries.find(entry=>entry.rel==='')?.id!==identity.id)migrationCapsuleFail('portable_durability_binding');
    const boundIdentity=Object.freeze({id:identity.id,volume:identity.volume}),fixed=portableClone(fixedProof),dirs=fixed.entries.filter(entry=>entry.dir),idList=Object.freeze(dirs.map(entry=>entry.id)),dirPaths=new Set(dirs.map(entry=>samePathKey(entry.rel?path.join(root,...entry.rel.split('/')):root))),external=new Map(externalBindings.map(row=>[samePathKey(row.root),row]));
    for(const wanted of requestedRoots){if(portableWithin(root,wanted)){if(!dirPaths.has(samePathKey(wanted)))migrationCapsuleFail('portable_durability_binding');}else if(!external.has(samePathKey(wanted)))migrationCapsuleFail('portable_durability_binding');}
    if(externalBindings.some(row=>portableWithin(root,row.root)||row.volume!==boundIdentity.volume||fixed.entries.some(entry=>entry.id===row.id)))migrationCapsuleFail('portable_durability_binding');
    const nativeReceipt=await portableWithDurabilityBroker(async broker=>{
      await admission();const ready=await broker.command({cmd:'capture-owned-flush-ready',root,revision:fixed.revision,scope:'owned-stage',preserveMetadata:true,expectedVolume:boundIdentity.volume});await admission();
      if(!exact(ready,'schema,scope,snapshot,token,volume')||ready.schema!==1||ready.scope!=='owned-stage'||ready.volume!==boundIdentity.volume||!hex(ready.token)||!portableProofExact(ready.snapshot,fixed))migrationCapsuleFail('portable_stage_changed');
      const receipt=await broker.command({cmd:'flush-captured-directories',root,revision:fixed.revision,token:ready.token,directoryIds:idList,expectedVolume:boundIdentity.volume});await admission();
      if(!exact(receipt,'allFlushed,count,directories,kind,metadataExact,revision,role,root,schema,token,volume')||receipt.schema!==1||receipt.kind!=='captured-directory-flush-v1'||receipt.role!=='owned-stage'||receipt.root!==root||receipt.revision!==fixed.revision||receipt.token!==ready.token||receipt.volume!==boundIdentity.volume||receipt.allFlushed!==true||receipt.metadataExact!==true||receipt.count!==dirs.length||!Array.isArray(receipt.directories)||receipt.directories.length!==dirs.length)migrationCapsuleFail('portable_durability_receipt');
      const expected=new Map(dirs.map(entry=>[entry.id,entry.rel])),seen=new Set();let lastLength=Infinity;for(const entry of receipt.directories){if(!exact(entry,'id,rel')||!expected.has(entry.id)||expected.get(entry.id)!==entry.rel||seen.has(entry.id)||entry.rel.length>lastLength)migrationCapsuleFail('portable_durability_receipt');seen.add(entry.id);lastLength=entry.rel.length;}
      return portableClone(receipt);
    });
    await portableFlushBound(externalBindings,admission);await admission();const observed=await portableCapture(root,fixed.revision);await admission();if(!portableProofExact(observed,fixed))migrationCapsuleFail('portable_stage_changed');
    const token=Object.freeze({});portableDurabilityProofs.set(token,{root,volume:boundIdentity.volume,rootId:boundIdentity.id,proof:fixed,receipt:nativeReceipt});return token;
  }
  function portableAssertDurability(token,root,identity,observed){const proof=portableDurabilityProofs.get(token);if(!proof||!eq(proof.root,root)||proof.rootId!==identity?.id||proof.volume!==identity?.volume||!portableProofExact(observed,proof.proof))migrationCapsuleFail('portable_stage_changed');return proof;}
  function portableDurabilitySlice(proof,name){const anchor=proof.entries.find(entry=>entry.dir&&portableFold(entry.rel)===portableFold(name))?.rel;if(typeof anchor!=='string'||anchor==='')migrationCapsuleFail('portable_durability_binding');const prefix=anchor+'/',entries=proof.entries.filter(entry=>entry.rel===anchor||entry.rel.startsWith(prefix)).map(entry=>({...portableClone(entry),rel:entry.rel===anchor?'':entry.rel.slice(prefix.length)}));const snapshot={...portableClone(proof),entries};if(!migrationCapsuleShape(snapshot))migrationCapsuleFail('portable_durability_binding');return snapshot;}
  async function portableVerifyInherited(token,stageRoot,target,identity,names,admission){
    const proof=portableDurabilityProofs.get(token);if(!proof||!eq(proof.root,stageRoot)||proof.rootId!==identity?.id||proof.volume!==identity?.volume)migrationCapsuleFail('portable_durability_binding');
    const protectedRoots=[];for(const name of names){const expected=portableDurabilitySlice(proof.proof,name),root=path.join(target,...name.split('/'));await admission();const info=await platform.info(root);if(info.id!==expected.entries.find(entry=>entry.rel==='').id||info.volume!==proof.volume)portableTargetFailure('inherited.identity',()=>({path:name,expected:{id:expected.entries.find(entry=>entry.rel==='').id,volume:proof.volume},actual:{id:info.id,volume:info.volume}}));const actual=await portableCapture(root,expected.revision);await admission();if(!portableProofExact(actual,expected))portableTargetFailure('inherited.snapshot',()=>({path:name,delta:portableTargetSnapshotDelta(actual,expected)}));protectedRoots.push(root);}
    return protectedRoots;
  }
  function portableAssertExternal(token,bindings){const proof=portableDurabilityProofs.get(token);if(!proof||bindings.some(row=>row.volume!==proof.volume||proof.proof.entries.some(entry=>entry.id===row.id)))migrationCapsuleFail('portable_durability_binding');}
  function portableExternalOnly(roots,protectedRoots){return roots.filter(root=>!protectedRoots.some(protectedRoot=>portableWithin(protectedRoot,root)));}

  // Portable source/live/stage evidence must not leave read-induced Basic time
  // changes behind. Keep the older local migration platform unchanged.
  // A supplied native model must explicitly implement the preserved capability.
  // Production uses the same native command with a strict, opt-in time scope.
  const portableFlush = async (roots,anchor) => {
    if(native){
      if(typeof native.flushPreservedRelative!=='function')migrationCapsuleFail('portable_preserved_flush_required');
      return native.flushPreservedRelative(roots,anchor);
    }
    const broker=await migrationCapsuleBroker();
    try{for(const root of roots)await broker.command({cmd:'store-flush',root,anchor,preserveMetadata:true});}
    finally{await broker.close();}
  };
  const portableCapture = (root, revision) => native
    ? (typeof native.capturePreserved === 'function' ? native.capturePreserved(root, revision) : native.capture(root, revision))
    : migrationCapsuleCapturePreserved(root, revision);
  async function collectPortable(request,sourceBase,evidence) {
    const input=portableInput(request),remaining=new Map(input.scoped),claimedDirectories=new Set(),records=[],histories=new Map();
    const take=name=>{const row=remaining.get(portableFold(name));if(!row)migrationCapsuleFail('portable_source');remaining.delete(portableFold(name));return row;};
    const dir=name=>{const actual=input.dirs.get(portableFold(name));if(!actual)migrationCapsuleFail('portable_source');claimedDirectories.add(portableFold(name));return actual;};
    const ancestors=name=>{let current=name;for(;;){if(input.dirs.has(portableFold(current)))claimedDirectories.add(portableFold(current));const at=current.lastIndexOf('/');if(at<0)break;current=current.slice(0,at);}};
    const read=async(path,kind,recordId,validate,{scopeId=ownerScope(sourceBase),mode='encrypted'}={})=>{
      const row=take(path);
      if(kind==='capsule-archive'||kind==='capsule-intent'){
        const end=row.data.indexOf(10),header=end>=0&&end<=16*1024?safeJsonParse(row.data.subarray(0,end).toString('utf8'),null):null,privateKind=kind==='capsule-archive'?'archive':'intent',descriptor={scopeId,recordId:privateKind==='archive'?recordId.slice(0,-8):recordId.split(':intent')[0],...(privateKind==='intent'?{intentRecordId:recordId}:{})};
        if(!migrationCapsuleCarrierHeaderValid(header,descriptor,privateKind))migrationCapsuleFail('carrier');
      }
      const result=await input.read(row,{purpose:'backup',schema:1,scopeId,recordId,chunked:true,maxPlaintextBytes:256*1024*1024});
      if (!result || typeof result.text !== 'string' || result.authenticated !== (mode==='encrypted')) migrationCapsuleFail('portable_carrier');
      const value=safeJsonParse(result.text,null);if(!validate(value))migrationCapsuleFail('portable_shape');
      const record={path:row.path,kind,recordId,scopeId,mode,value};records.push(record);ancestors(row.path.slice(0,row.path.lastIndexOf('/')));return record;
    };
    const authority=portableAuthority(request.files),controlPrefix='.work-data/skill-backups';
    let catalog=null,journal=null,representation=null;
    if(input.dirs.has(controlPrefix)){
      dir(controlPrefix);
      if(remaining.has(controlPrefix+'/catalog-v1.sealed'))catalog=await read(controlPrefix+'/catalog-v1.sealed','catalog','catalog-v1',catalogValid);
      if(remaining.has(controlPrefix+'/relocation-v1.sealed'))journal=await read(controlPrefix+'/relocation-v1.sealed','relocation','relocation-v1',journalValid);
      if(remaining.has(controlPrefix+'/representation-v1.sealed')){
        representation=await read(controlPrefix+'/representation-v1.sealed','representation','representation-v1',representationValid);
        if(!['kept','canceled'].includes(representation.value.phase))migrationCapsuleFail('portable_pending');
        // Nonempty settled records are authenticated below; unresolved phases still refuse.
      }
      if(!journal || !['kept','canceled'].includes(journal.value.phase))migrationCapsuleFail('portable_pending');
      if(catalog){if(journal.value.phase!=='kept'||journal.value.storeId!==catalog.value.storeId||journal.value.rootId!==catalog.value.rootId||journal.value.volume!==catalog.value.volume)migrationCapsuleFail('portable_store');dir(controlPrefix+'/objects-v1');}
      else if(journal.value.phase!=='canceled'||input.dirs.has(controlPrefix+'/objects-v1'))migrationCapsuleFail('portable_store');
    }
    const bindingPattern=new RegExp('^\\.work-data/generations/([a-f0-9]{48})/migrations/skill-backup-bindings-v2\\.sealed$',process.platform==='win32'?'i':'');
    const bindings=[];
    for(const row of [...remaining.values()]){
      const match=bindingPattern.exec(row.path);if(!match)continue;const generationId=portableFold(match[1]);
      const record=await read(row.path,'binding','bindings:'+generationId,bindingValid);
      if(!catalog||record.value.generationId!==generationId||record.value.storeId!==catalog.value.storeId||!record.value.ready)migrationCapsuleFail('portable_binding');
      if(record.value.entries.some(entry=>entry.kind==='history'?entry.eligibility!=='terminal':!['plain',undefined].includes(entry.kind)||!['published','complete','aborted'].includes(entry.phase)))migrationCapsuleFail('portable_original_capsule_required');
      bindings.push(record);
    }
    const activeBinding=bindings.find(row=>row.value.generationId===authority.id);
    if(catalog&&(!authority.id||!activeBinding||(activeBinding.value.mode||'encrypted')!==authority.mode))migrationCapsuleFail('portable_binding');
    const roots=[catalog?controlPrefix+'/objects-v1':null,input.dirs.has('migrations/skill-backups')?'migrations/skill-backups':null].filter(Boolean);
    for(const root of roots){
      dir(root);
      const markerPattern=new RegExp('^'+root.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'/([0-9TZ-]+)/([A-Za-z0-9_-]{1,64})/\\.ruyi-backup-history-v1$',process.platform==='win32'?'i':'');
      for(const row of [...remaining.values()]){
        const match=markerPattern.exec(row.path);if(!match)continue;const stamp=match[1],skillId=match[2],wrapper=row.path.slice(0,row.path.lastIndexOf('/'));
        const marker=take(row.path),header=safeJsonParse(marker.data.toString('utf8'),null);
        if(!exact(header,'schema,mode')||header.schema!==1||!['plain','encrypted'].includes(header.mode))migrationCapsuleFail('portable_history');
        const descriptor={stamp,id:skillId,recordId:'skill-backup:'+(process.platform==='win32'?skillId.toLowerCase():skillId)};
        const binding=migrationBackupHistoryBinding(descriptor),history=await read(wrapper+'/history','history',binding.recordId,value=>migrationBackupHistoryShape(value,descriptor),{scopeId:binding.scopeId,mode:header.mode});
        for(const entry of history.value.snapshot.entries)if(portableFold(entry.rel)===portableFold(SKILL_IMPORT_RECORD)){
          const stream=entry.streams.find(stream=>stream.name==='');if(!stream||entry.dir)migrationCapsuleFail('portable_history');const bytes=Buffer.from(stream.data,'base64');
          try{const opened=await input.read({path:history.path,data:bytes},{purpose:'backup',schema:1,scopeId:'skills',recordId:'skill-import:'+portableFold(skillId),chunked:true,maxPlaintextBytes:16*1024});if(!opened||typeof opened.text!=='string'||Buffer.byteLength(opened.text,'utf8')>16*1024)migrationCapsuleFail('portable_history');}finally{bytes.fill(0);}
        }
        if(histories.has(stamp+'/'+portableFold(skillId)))migrationCapsuleFail('portable_binding');
        histories.set(stamp+'/'+portableFold(skillId),{history,marker:{path:marker.path,sha256:hash(marker.data)},wrapper,stamp,skillId});
        ancestors(wrapper);
      }
      // Empty stamp directories are legitimate retained names, not capabilities.
      for(const name of input.dirs.values())if(new RegExp('^'+root.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'/[0-9TZ-]+$',process.platform==='win32'?'i':'').test(name))claimedDirectories.add(portableFold(name));
    }
    // Fixed published capsule families. Other representation/pending forms stay
    // explicit special-owner-required until their complete private closure exists.
    const originalPattern=new RegExp('^(?:(?:\\.work-data/generations/[a-f0-9]{48}/)?migrations/skill-backups|\\.work-data/skill-backups/objects-v1)/([0-9TZ-]+)/([A-Za-z0-9_-]{1,64})/\\.ruyi-capsule-v1$',process.platform==='win32'?'i':'');
    if(evidence!==undefined&&!Array.isArray(evidence))migrationCapsuleFail('portable_native_evidence');
    const nativeEvidence=[],providedEvidence=evidence===undefined?null:new Map((Array.isArray(evidence)?evidence:[]).map(row=>[portableFold(row.path),row]));
    if(providedEvidence&&providedEvidence.size!==evidence.length)migrationCapsuleFail('portable_source');
    const evidenceFor=async(relative,revision)=>{
      const snapshot=providedEvidence?providedEvidence.get(portableFold(relative))?.snapshot:await portableCapture(path.join(sourceBase,...relative.split('/')),revision);
      if(!migrationCapsulePortableShape(snapshot)||snapshot.revision!==revision)migrationCapsuleFail('portable_native_evidence');
      const paths=new Set(),fileRows=[...input.files.values()].filter(row=>portableFold(row.path).startsWith(portableFold(relative)+'/'));
      for(const entry of snapshot.entries){const name=entry.rel?relative+'/'+entry.rel:relative;paths.add(portableFold(name));if(entry.dir){if(!request.directories.some(dir=>portableFold(dir)===portableFold(name)))migrationCapsuleFail('portable_source');}
        else{const row=input.files.get(portableFold(name)),stream=entry.streams.find(stream=>stream.name==='');if(!row||!stream||stream.hash!==hash(row.data)||stream.size!==row.data.length)migrationCapsuleFail('portable_source');}}
      if(fileRows.some(row=>!paths.has(portableFold(row.path)))||request.directories.some(dir=>portableFold(dir).startsWith(portableFold(relative)+'/')&&!paths.has(portableFold(dir))))migrationCapsuleFail('portable_source');
      nativeEvidence.push({path:relative,snapshot});return snapshot;
    };
    const provenanceRefs=async(snapshot,slot,anchor)=>{
      for(const entry of snapshot.entries)if(portableFold(entry.rel)===portableFold(SKILL_IMPORT_RECORD)){
        const stream=entry.streams.find(row=>row.name==='');if(entry.dir||!stream)migrationCapsuleFail('portable_history');const bytes=Buffer.from(stream.data,'base64');
        try{const opened=await input.read({path:anchor,data:bytes},{purpose:'backup',schema:1,scopeId:'skills',recordId:'skill-import:'+portableFold(slot.skillId),chunked:true,maxPlaintextBytes:16*1024});if(!opened||typeof opened.text!=='string'||!importShape(opened.text))migrationCapsuleFail('portable_provenance');}finally{bytes.fill(0);}
      }
    };
    const originals=[],terminalCapsules=[],rawTrees=[],originalByRef=new Map(),liveTrees=new Map(),originalSources=new Map();
    for(const row of [...remaining.values()]){
      const match=originalPattern.exec(row.path);if(!match)continue;const stamp=match[1],skillId=match[2],wrapper=row.path.slice(0,row.path.lastIndexOf('/')),slot={stamp,skillId},source=descriptor(path.join(sourceBase,...wrapper.split('/').slice(0,-2)),stamp,skillId),marker=take(row.path),backupRef=ref(stamp,skillId,catalog?.value.storeId||'0'.repeat(48));
      const archive=await read(wrapper+'/archive','capsule-archive',source.recordId+':archive',value=>value&&Object.keys(value).sort().join(',')==='data,encoding'&&value.encoding==='gzip-base64-v1'&&typeof value.data==='string',{scopeId:source.scopeId});
      const zipped=Buffer.from(archive.value.data,'base64');let snapshot;try{if(zipped.toString('base64')!==archive.value.data)migrationCapsuleFail('portable_archive');snapshot=migrationCapsuleDecode(zipped);}finally{zipped.fill(0);}if(!migrationCapsulePortableShape(snapshot))migrationCapsuleFail('portable_snapshot_owner_required');archive.value=snapshot;
      const intent=await read(wrapper+'/intent','capsule-intent',source.recordId+':intent',value=>migrationCapsuleIntentShape(value,source),{scopeId:source.scopeId});
      if(!['published','complete','aborted'].includes(intent.value.phase)||intent.value.revision!==snapshot.revision||intent.value.oldRoot!==rootId(snapshot))migrationCapsuleFail('portable_original_capsule_required');
      const selectedEntry=activeBinding?.value.entries.find(entry=>entry.ref.backupId===backupRef.backupId&&entry.ref.stamp===stamp&&entry.ref.skillId===portableFold(skillId));
      let selectedIntent=intent;
      if(selectedEntry){
        if(selectedEntry.kind!==undefined||selectedEntry.physicalSkillId!==skillId)migrationCapsuleFail('portable_binding');
        const relative=controlPrefix+'/intents/'+authority.id+'/'+backupRef.backupId+'.sealed',variant={...source,generationId:authority.id};
        if(!remaining.has(portableFold(relative)))migrationCapsuleFail('portable_binding');
        selectedIntent=await read(relative,'capsule-intent',source.recordId+':intent:'+authority.id,value=>migrationCapsuleIntentShape(value,variant),{scopeId:source.scopeId});
        if(!['published','complete','aborted'].includes(selectedIntent.value.phase)||selectedIntent.value.revision!==snapshot.revision||selectedIntent.value.oldRoot!==rootId(snapshot))migrationCapsuleFail('portable_binding');
      }
      const terminal=['complete','aborted'].includes(selectedIntent.value.phase)?selectedIntent.value.phase:null;
      if(!terminal&&intent.value.phase!=='published'||terminal&&intent.value.phase!=='published'&&intent.value.phase!==terminal)migrationCapsuleFail('portable_binding');
      await provenanceRefs(snapshot,slot,archive.path);const objects=wrapper+'/objects';dir(objects);
      const physical=await evidenceFor(objects,hash('portable-objects:'+wrapper));
      if(physical.entries.some(entry=>entry.rel===''?entry.streams.length!==0:entry.streams.some(stream=>stream.name!=='')))migrationCapsuleFail('portable_native_streams');
      if(terminal){if(physical.entries.length!==1||physical.entries[0].rel!==''||!physical.entries[0].dir||physical.entries[0].streams.length)migrationCapsuleFail('portable_terminal_objects');}
      else if(physical.entries.length!==snapshot.entries.length+1)migrationCapsuleFail('portable_objects');
      for(const original of terminal?[]:snapshot.entries){const opaque=objects+'/'+original.opaque,current=physical.entries.find(entry=>entry.rel===original.opaque);
        if(!current||current.id!==original.id||current.dir!==original.dir||current.streams.some(stream=>stream.name!==''||stream.size!==0))migrationCapsuleFail('portable_objects');
        if(original.dir)dir(opaque);else if(take(opaque).data.length)migrationCapsuleFail('portable_objects');
      }
      if(terminal){const restored=wrapper+'/restored';if(input.dirs.has(portableFold(restored))){dir(restored);const empty=await evidenceFor(restored,hash('portable-terminal-restored:'+wrapper));if(empty.entries.length!==1||empty.entries[0].rel!==''||!empty.entries[0].dir||empty.entries[0].streams.length)migrationCapsuleFail('portable_terminal_objects');}}
      const livePrefix=authority.id?'.work-data/generations/'+authority.id+'/':'',liveName=livePrefix+'skills/'+skillId;let live=null;
      if(request.directories.some(name=>portableFold(name)===portableFold(liveName))){const actualName=request.directories.find(name=>portableFold(name)===portableFold(liveName));if(!liveTrees.has(portableFold(actualName))){live=await evidenceFor(actualName,hash('portable-live:'+actualName));await provenanceRefs(live,slot,archive.path);liveTrees.set(portableFold(actualName),{path:actualName,snapshot:live});}else live=liveTrees.get(portableFold(actualName)).snapshot;}
      let eligibility=terminal?'terminal':selectedIntent.value.conversion?.eligibility;if(!terminal&&!['edited','gone'].includes(eligibility))eligibility=live&&migrationCapsuleSame(live,selectedIntent.value.newTree)?'eligible':live?'edited':'gone';
      const original={wrapper,stamp,skillId,backupId:backupRef.backupId,archive:archive.path,intent:intent.path,marker:{path:marker.path,sha256:hash(marker.data)},live:live?liveName:null,eligibility,...(terminal?{phase:terminal}:{})};
      if(originalByRef.has(stamp+'/'+portableFold(skillId)))migrationCapsuleFail('portable_binding');originalByRef.set(stamp+'/'+portableFold(skillId),original);originalSources.set(original,{snapshot,live});(terminal?terminalCapsules:originals).push(original);ancestors(wrapper);
    }
    // Whole raw legacy backups are user trees, not capsule/control records.
    // Their actual native owner snapshot authenticates the complete namespace
    // against captured default bytes; preserved user streams stay in the aux.
    const rawPattern=new RegExp('^((?:\\.work-data/generations/[a-f0-9]{48}/)?migrations/skill-backups|\\.work-data/skill-backups/objects-v1)/([0-9TZ-]+)/([A-Za-z0-9_-]{1,64})$',process.platform==='win32'?'i':'');
    for(const wrapper of input.dirs.values()){
      const match=rawPattern.exec(wrapper);if(!match||input.files.has(portableFold(wrapper+'/.ruyi-capsule-v1'))||input.files.has(portableFold(wrapper+'/'+MIGRATION_BACKUP_HISTORY_MARKER))||!input.files.has(portableFold(wrapper+'/SKILL.md')))continue;
      const stamp=match[2],skillId=match[3],snapshot=await evidenceFor(wrapper,hash('portable-raw:'+wrapper));
      if(!snapshot.entries.some(entry=>!entry.dir&&portableFold(entry.rel)===portableFold('SKILL.md')))migrationCapsuleFail('portable_raw_shape');
      await provenanceRefs(snapshot,{stamp,skillId},wrapper+'/'+SKILL_IMPORT_RECORD);
      for(const entry of snapshot.entries){const name=entry.rel?wrapper+'/'+entry.rel:wrapper;if(entry.dir)dir(name);else take(name);}
      ancestors(wrapper);rawTrees.push({path:wrapper,wrapper,stamp,skillId,snapshot});
      const prefix=portableFold(match[1]).startsWith('.work-data/skill-backups/')?(authority.id?'.work-data/generations/'+authority.id+'/':''):match[1].slice(0,-'migrations/skill-backups'.length),liveName=prefix+'skills/'+skillId,actualName=request.directories.find(name=>portableFold(name)===portableFold(liveName));
      if(actualName&&!liveTrees.has(portableFold(actualName))){const live=await evidenceFor(actualName,hash('portable-live:'+actualName));await provenanceRefs(live,{stamp,skillId},actualName+'/'+SKILL_IMPORT_RECORD);liveTrees.set(portableFold(actualName),{path:actualName,snapshot:live});}
    }
    // Settled representation records retain their authenticated history. They
    // do not authorize a conversion replay or instantiate historical objects.
    const settledRepresentations=[],retainedCapsules=[],plainBackups=[];
    const recordPattern=new RegExp('^\\.work-data/skill-backups/representations-v1/([a-f0-9]{48})/([a-f0-9]{64})/record-v1\\.sealed$',process.platform==='win32'?'i':'');
    const retainedByPath=new Map();
    const historicalHistory=async(wrapper,slot)=>{
      const marker=take(wrapper+'/'+MIGRATION_BACKUP_HISTORY_MARKER),header=safeJsonParse(marker.data.toString('utf8'),null);
      if(!exact(header,'schema,mode')||header.schema!==1||!['plain','encrypted'].includes(header.mode))migrationCapsuleFail('portable_history');
      const d={...slot,id:slot.skillId,recordId:'skill-backup:'+portableFold(slot.skillId)},binding=migrationBackupHistoryBinding(d),history=await read(wrapper+'/history','history',binding.recordId,payload=>migrationBackupHistoryShape(payload,d),{scopeId:binding.scopeId,mode:header.mode});
      await provenanceRefs(history.value.snapshot,slot,history.path);dir(wrapper);ancestors(wrapper);return history;
    };
    const emptyPortable=async name=>{
      if(!input.dirs.has(portableFold(name)))return;
      dir(name);ancestors(name);const proof=await evidenceFor(name,hash('portable-empty:'+name));
      if(proof.entries.length!==1||!proof.entries[0].dir||proof.entries[0].rel!==''||proof.entries[0].streams.length)migrationCapsuleFail('portable_representation_unsettled');
    };
    const historicalCapsule=async(wrapper,slot,{plain=false,generationId=null}={})=>{
      if(retainedByPath.has(portableFold(wrapper)))return retainedByPath.get(portableFold(wrapper));
      const d=descriptor(stableRoot,slot.stamp,slot.skillId),archive=await read(wrapper+'/archive','capsule-archive',d.recordId+':archive',value=>exact(value,'encoding,data')&&value.encoding==='gzip-base64-v1'&&typeof value.data==='string',{scopeId:d.scopeId});
      const zipped=Buffer.from(archive.value.data,'base64');let snapshot;try{if(zipped.toString('base64')!==archive.value.data)migrationCapsuleFail('portable_archive');snapshot=migrationCapsuleDecode(zipped);}finally{zipped.fill(0);}
      if(!migrationCapsulePortableShape(snapshot))migrationCapsuleFail('portable_snapshot_owner_required');archive.value=snapshot;archive.kind=plain?'plain-archive':'representation-archive';
      const intentId=d.recordId+':intent'+(generationId?':'+generationId:''),intent=await read(wrapper+'/intent','capsule-intent',intentId,value=>migrationCapsuleIntentShape(value,{...d,...(plain?{plainRoot:path.join(sourceBase,...(controlPrefix+'/objects-v1/'+slot.stamp+'/'+slot.skillId).split('/'))}:{}),...(generationId?{generationId}:{})}),{scopeId:d.scopeId});intent.kind=plain?'plain-intent':'representation-intent';
      if(!['published','complete','aborted'].includes(intent.value.phase)||intent.value.revision!==snapshot.revision||intent.value.oldRoot!==rootId(snapshot))migrationCapsuleFail('portable_representation_unsettled');
      if(!plain){const marker=take(wrapper+'/'+MIGRATION_CAPSULE_MARKER);if(!exact(safeJsonParse(marker.data.toString('utf8'),null),'version')||safeJsonParse(marker.data.toString('utf8'),null).version!==1)migrationCapsuleFail('portable_shape');}
      dir(wrapper);await emptyPortable(wrapper+'/objects');await emptyPortable(wrapper+'/restored');ancestors(wrapper);await provenanceRefs(snapshot,slot,archive.path);
      const value={wrapper,stamp:slot.stamp,skillId:slot.skillId,backupId:hash(slot.stamp+'/'+portableFold(slot.skillId)),archive:archive.path,intent:intent.path,generationId,snapshot,phase:intent.value.phase,plain};
      retainedByPath.set(portableFold(wrapper),value);if(!plain)retainedCapsules.push(value);return value;
    };
    for(const file of [...remaining.values()]){
      const match=recordPattern.exec(file.path);if(!match)continue;const operationId=portableFold(match[1]),backupId=portableFold(match[2]),anchor=file.path.slice(0,-'/record-v1.sealed'.length);
      const record=await read(file.path,'representation-record','representation:'+operationId+':'+backupId,representationRecordValid),value=record.value;
      if(value.operationId!==operationId||backupId!==hash(value.stamp+'/'+portableFold(value.skillId))||!['forward','canceled'].includes(value.phase))migrationCapsuleFail('portable_representation_unsettled');
      const slot={stamp:value.stamp,skillId:value.skillId};await provenanceRefs(value.original,slot,record.path);await provenanceRefs(value.target,slot,record.path);
      const row={path:record.path,anchor,operationId,backupId,stamp:value.stamp,skillId:value.skillId,archive:null,intent:null};
      if(input.dirs.has(portableFold(anchor+'/capsule'))){
        if(input.files.has(portableFold(anchor+'/capsule/'+MIGRATION_BACKUP_HISTORY_MARKER)))await historicalHistory(anchor+'/capsule',slot);
        else{const carrier=await historicalCapsule(anchor+'/capsule',slot);row.archive=carrier.archive;row.intent=carrier.intent;}
      }
      if(input.dirs.has(portableFold(anchor+'/history'))){
        await historicalHistory(anchor+'/history',slot);
      }
      if(remaining.has(portableFold(anchor+'/import-target.sealed'))){
        const row=take(anchor+'/import-target.sealed'),target=value.target.entries.find(entry=>portableFold(entry.rel)===portableFold(SKILL_IMPORT_RECORD)),stream=target?.streams.find(stream=>stream.name==='');
        if(!stream||stream.hash!==hash(row.data)||stream.size!==row.data.length)migrationCapsuleFail('portable_provenance');
        const opened=await input.read(row,{purpose:'backup',schema:1,scopeId:'skills',recordId:'skill-import:'+portableFold(slot.skillId),chunked:true,maxPlaintextBytes:16*1024});
        if(!opened||typeof opened.text!=='string'||!importShape(opened.text)||!opened.authenticated)migrationCapsuleFail('portable_provenance');
        records.push({path:row.path,kind:'representation-provenance',recordId:'skill-import:'+portableFold(slot.skillId),scopeId:'skills',mode:'encrypted',value:opened.text});
      }
      dir(anchor);ancestors(anchor);await emptyPortable(anchor+'/restored');await evidenceFor(anchor,hash('portable-representation:'+anchor));settledRepresentations.push(row);
    }
    if(settledRepresentations.length&&!representation)migrationCapsuleFail('portable_representation_missing');
    if(representation?.value.entries.length){
      if(!catalog||representation.value.storeId!==catalog.value.storeId)migrationCapsuleFail('portable_store');
      const current=representation.value.phase==='kept'?representation.value.targetId:representation.value.sourceId;
      if(current!==authority.id&&!activeBinding?.value.sourceRootIds.includes(current)||representation.value.phase==='kept'&&representation.value.mode!==authority.mode
        ||representation.value.phase==='canceled'&&representation.value.sourceId===authority.id&&representation.value.sourceProof!==authority.sha256)migrationCapsuleFail('portable_representation_authority');
      for(const entry of representation.value.entries){const row=settledRepresentations.find(row=>row.operationId===representation.value.operationId&&row.backupId===entry.backupId&&row.stamp===entry.stamp&&row.skillId===entry.skillId);
        if(!row)migrationCapsuleFail('portable_representation_missing');const record=records.find(record=>record.path===row.path).value;
        if(record.phase!==(representation.value.phase==='kept'?'forward':'canceled'))migrationCapsuleFail('portable_representation_unsettled');
      }
    }
    for(const binding of bindings)for(const entry of binding.value.entries.filter(entry=>entry.kind==='plain')){
      const wrapper=controlPrefix+'/plain-v1/'+binding.value.generationId+'/'+entry.ref.backupId,slot={stamp:entry.ref.stamp,skillId:entry.physicalSkillId},carrier=await historicalCapsule(wrapper,slot,{plain:true,generationId:binding.value.generationId});
      if(entry.ref.backupId!==carrier.backupId||entry.archiveSha!==hash(input.files.get(portableFold(carrier.archive)).data)||entry.intentSha!==hash(input.files.get(portableFold(carrier.intent)).data)&&carrier.phase!=='complete')migrationCapsuleFail('portable_binding');
      const intent=records.find(row=>row.path===carrier.intent).value;
      if(intent.conversion?.eligibility!==entry.eligibility||entry.newTree&&portableJSON(entry.newTree)!==portableJSON(intent.newTree))migrationCapsuleFail('portable_binding');
      const physical=controlPrefix+'/objects-v1/'+slot.stamp+'/'+slot.skillId,liveName=(authority.id?'.work-data/generations/'+authority.id+'/':'')+'skills/'+slot.skillId,live=liveTrees.get(portableFold(liveName))||null;
      const current=binding.value.generationId===authority.id,raw=rawTrees.find(row=>portableFold(row.path)===portableFold(physical)),history=histories.get(slot.stamp+'/'+portableFold(slot.skillId));
      if(current&&intent.phase==='published'&&(!raw||!migrationCapsuleSameMetadata(raw.snapshot,carrier.snapshot)))migrationCapsuleFail('portable_plain_changed');
      if(current&&intent.phase==='complete'&&(!history||history.history.value.phase!=='complete'||portableJSON(history.history.value.snapshot)!==portableJSON(carrier.snapshot)))migrationCapsuleFail('portable_plain_changed');
      plainBackups.push({...carrier,physical,live:live?.path||null,eligibility:intent.phase!=='published'?'terminal':!current?'edited':!live?'gone':entry.eligibility==='eligible'&&migrationCapsuleSame(live.snapshot,intent.newTree)?'eligible':entry.eligibility==='gone'?'gone':'edited'});
    }
    for(const row of [...remaining.values()]){
      const match=new RegExp('^\\.work-data/skill-backups/plain-v1/([a-f0-9]{48})/([a-f0-9]{64})/archive$',process.platform==='win32'?'i':'').exec(row.path);if(!match)continue;
      const binding=bindings.find(row=>row.value.generationId===portableFold(match[1])),entry=binding?.value.entries.find(entry=>entry.ref.backupId===portableFold(match[2])&&entry.kind==='history');if(!entry)migrationCapsuleFail('portable_binding');
      const slot={stamp:entry.ref.stamp,skillId:entry.physicalSkillId},carrier=await historicalCapsule(row.path.slice(0,-'/archive'.length),slot,{plain:true,generationId:binding.value.generationId});
      if(carrier.phase!=='complete')migrationCapsuleFail('portable_representation_unsettled');
      plainBackups.push({...carrier,physical:controlPrefix+'/objects-v1/'+slot.stamp+'/'+slot.skillId,live:null,eligibility:'terminal'});
    }
    for(const slot of plainBackups)if(slot.phase==='complete'){
      await emptyPortable(slot.wrapper+'/history-stage');const intent=records.find(row=>row.path===slot.intent).value,publish=intent.historyPublish;if(!publish)migrationCapsuleFail('portable_plain_changed');
      const history=records.find(row=>row.kind==='history'&&portableJSON(row.value.snapshot)===portableJSON(slot.snapshot));if(!history)migrationCapsuleFail('portable_plain_changed');
      const relative=history.path.slice(0,history.path.lastIndexOf('/')),proof=nativeEvidence.find(row=>portableFold(row.path)===portableFold(relative))?.snapshot||await evidenceFor(relative,hash('portable-plain-history:'+relative));if(rootId(proof)!==publish.id)migrationCapsuleFail('portable_plain_changed');slot.historyPublishPath=relative;
    }
    // Every retained generation variant is also source provenance, including
    // intents referenced by old representation records but no current binding.
    for(const row of [...remaining.values()]){
      const match=new RegExp('^\\.work-data/skill-backups/intents/([a-f0-9]{48})/([a-f0-9]{64})\\.sealed$',process.platform==='win32'?'i':'').exec(row.path);if(!match)continue;
      const slot=settledRepresentations.find(slot=>slot.backupId===portableFold(match[2]));if(!slot)continue;const d=descriptor(stableRoot,slot.stamp,slot.skillId);
      const intent=await read(row.path,'capsule-intent',d.recordId+':intent:'+portableFold(match[1]),value=>migrationCapsuleIntentShape(value,{...d,generationId:portableFold(match[1])}),{scopeId:d.scopeId});intent.kind='representation-variant';
      if(!['published','complete','aborted'].includes(intent.value.phase)||!records.some(record=>['capsule-archive','representation-archive','plain-archive'].includes(record.kind)&&record.value.revision===intent.value.revision&&rootId(record.value)===intent.value.oldRoot))migrationCapsuleFail('portable_binding');
    }
    for(const row of settledRepresentations){
      const record=records.find(record=>record.path===row.path).value,archiveCandidates=records.filter(item=>['capsule-archive','representation-archive','plain-archive','history'].includes(item.kind)&&hash(input.files.get(portableFold(item.path)).data)===record.archiveSha),intentCandidates=records.filter(item=>['capsule-intent','representation-intent','plain-intent','representation-variant'].includes(item.kind)&&hash(input.files.get(portableFold(item.path)).data)===record.intentSha);
      if(record.oldType==='history'){
        const marker=[...input.files.values()].find(file=>hash(file.data)===record.intentSha&&file.path.endsWith('/'+MIGRATION_BACKUP_HISTORY_MARKER));if(!marker||!archiveCandidates.length)migrationCapsuleFail('portable_representation_carrier');row.archive=archiveCandidates[0].path;row.intent=marker.path;
      }else{
        if(!archiveCandidates.length||!intentCandidates.length)migrationCapsuleFail('portable_representation_carrier');row.archive=archiveCandidates[0].path;row.intent=intentCandidates[0].path;
        const snapshot=archiveCandidates[0].value;if(portableJSON(snapshot)!==portableJSON(record.oldType==='plain'?record.target:record.original))migrationCapsuleFail('portable_representation_carrier');
      }
      if(record.sourceGenerationId&&row.intent!==controlPrefix+'/intents/'+record.sourceGenerationId+'/'+row.backupId+'.sealed')migrationCapsuleFail('portable_binding');
      for(const relative of [row.archive.slice(0,row.archive.lastIndexOf('/')),...(record.oldType==='history'?[row.intent.slice(0,row.intent.lastIndexOf('/'))]:[])])
        if(!nativeEvidence.some(proof=>portableFold(proof.path)===portableFold(relative)))await evidenceFor(relative,hash('portable-carrier:'+relative));
      const carrierProof=nativeEvidence.find(proof=>portableFold(proof.path)===portableFold(row.archive.slice(0,row.archive.lastIndexOf('/'))));
      if(!carrierProof||rootId(carrierProof.snapshot)!==record.capsuleId)migrationCapsuleFail('portable_representation_identity');
      if(record.historyId){
        let targetProof=null;
        for(const history of records.filter(item=>item.kind==='history'&&portableJSON(item.value.snapshot)===portableJSON(record.target))){
          const relative=history.path.slice(0,history.path.lastIndexOf('/')),proof=nativeEvidence.find(proof=>portableFold(proof.path)===portableFold(relative))?.snapshot||await evidenceFor(relative,hash('portable-carrier:'+relative));
          if(rootId(proof)===record.historyId)targetProof=proof;
        }
        if(!targetProof||!migrationCapsuleSame(targetProof,record.historyTree))migrationCapsuleFail('portable_representation_identity');
      }
    }
    for(const slot of settledRepresentations){
      const liveName=(authority.id?'.work-data/generations/'+authority.id+'/':'')+'skills/'+slot.skillId,actualName=request.directories.find(name=>portableFold(name)===portableFold(liveName));
      if(actualName&&!liveTrees.has(portableFold(actualName))){const snapshot=await evidenceFor(actualName,hash('portable-live:'+actualName));await provenanceRefs(snapshot,slot,actualName+'/'+SKILL_IMPORT_RECORD);liveTrees.set(portableFold(actualName),{path:actualName,snapshot});}
    }

    // Each bound generation owns a mandatory authenticated intent. Physical
    // intent bytes are archive provenance, not the selected generation's live
    // identity authority after prepareBindings copied its replacement tree.
    const linkedVariant=async(original,entry,generationId)=>{
      const source=descriptor(stableRoot,original.stamp,original.skillId),relative=controlPrefix+'/intents/'+generationId+'/'+entry.ref.backupId+'.sealed',variant={...source,generationId};
      let record=records.find(row=>portableFold(row.path)===portableFold(relative));
      if(!record){if(!remaining.has(portableFold(relative)))migrationCapsuleFail('portable_binding');record=await read(relative,'capsule-intent',source.recordId+':intent:'+generationId,value=>migrationCapsuleIntentShape(value,variant),{scopeId:source.scopeId});}
      const snapshot=originalSources.get(original).snapshot;
      if(!['capsule-intent','representation-variant'].includes(record.kind)||record.recordId!==source.recordId+':intent:'+generationId||record.scopeId!==source.scopeId
        ||!migrationCapsuleIntentShape(record.value,variant)||!(original.phase?['published',original.phase].includes(record.value.phase):record.value.phase==='published')||record.value.revision!==snapshot.revision||record.value.oldRoot!==rootId(snapshot))migrationCapsuleFail('portable_binding');
      return record;
    };
    for(const binding of bindings){const seen=new Set();for(const entry of binding.value.entries){
      if(seen.has(entry.ref.backupId))migrationCapsuleFail('portable_binding');seen.add(entry.ref.backupId);if(['history','plain'].includes(entry.kind))continue;
      const original=[...originals,...terminalCapsules,...retainedCapsules].find(row=>row.stamp===entry.ref.stamp&&portableFold(row.skillId)===entry.ref.skillId&&hash(input.files.get(portableFold(row.archive)).data)===entry.archiveSha);if(original&&!originalSources.has(original))originalSources.set(original,{snapshot:original.snapshot,live:null});if(!original||entry.physicalSkillId!==original.skillId||entry.kind!==undefined||!(original.phase?['published',original.phase].includes(entry.phase):entry.phase==='published'))migrationCapsuleFail('portable_original_capsule_required');
      const variant=await linkedVariant(original,entry,binding.value.generationId);
      if(!(original.phase?['terminal','eligible','edited','gone']:['eligible','edited','gone']).includes(entry.eligibility)||entry.eligibility==='eligible'&&portableJSON(entry.newTree)!==portableJSON(variant.value.newTree)
        ||entry.eligibility!=='eligible'&&entry.newTree!==null||['edited','gone'].includes(variant.value.conversion?.eligibility)&&entry.eligibility!==variant.value.conversion.eligibility)migrationCapsuleFail('portable_binding');
      if(entry.sourceGenerationId){if(!binding.value.sourceRootIds.includes(entry.sourceGenerationId))migrationCapsuleFail('portable_binding');await linkedVariant(original,entry,entry.sourceGenerationId);}
      const sourceIntent=entry.sourceGenerationId?controlPrefix+'/intents/'+entry.sourceGenerationId+'/'+entry.ref.backupId+'.sealed':original.intent;
      if(entry.archiveSha!==hash(input.files.get(portableFold(original.archive)).data)||entry.intentSha!==hash(input.files.get(portableFold(sourceIntent))?.data||Buffer.alloc(0)))migrationCapsuleFail('portable_binding');
      if(!original.phase&&binding.value.generationId===authority.id){const live=originalSources.get(original).live;original.eligibility=!live?'gone':entry.eligibility!=='eligible'?entry.eligibility:migrationCapsuleSame(live,variant.value.newTree)?'eligible':'edited';}
    }}
    const logPattern=new RegExp('^(?:\\.work-data/generations/[a-f0-9]{48}/)?migrations/[0-9TZ-]+\\.json$',process.platform==='win32'?'i':'');
    for(const row of request.files){
      if(!logPattern.test(row.path))continue;const logical=row.path.replace(new RegExp('^\\.work-data/generations/[a-f0-9]{48}/',process.platform==='win32'?'i':''),''),binding=WorkDataMigrationCodecs.describe(logical),opened=await input.read(row,binding);
      if(!opened||typeof opened.text!=='string')migrationCapsuleFail('portable_log');const text=opened.text,bom=text.startsWith('\uFEFF')?'\uFEFF':'',clean=text.slice(bom.length),value=safeJsonParse(clean,null);if(!value||!Array.isArray(value.files))continue;
      const rewrites=[];
      for(const [index,file]of value.files.entries()){
        if(!file||file.kind!=='skill-copy'||typeof file.backup!=='string')continue;const original=[...originals,...terminalCapsules,...rawTrees,...plainBackups.filter(row=>row.phase==='complete').map(row=>({...row,wrapper:row.physical})),...settledRepresentations.filter(row=>histories.has(row.stamp+'/'+portableFold(row.skillId))).map(row=>({...row,wrapper:histories.get(row.stamp+'/'+portableFold(row.skillId)).wrapper}))].find(original=>eq(file.backup,path.join(sourceBase,...original.wrapper.split('/')))||settledRepresentations.length&&eq(file.backup,path.join(sourceBase,'migrations','skill-backups',original.stamp,original.skillId)));if(!original)continue;
        if(!Array.isArray(file.items)||file.items.length!==1||file.items[0]?.id!==original.skillId||typeof file.file!=='string'||!path.isAbsolute(file.file))migrationCapsuleFail('portable_log');
        const relative=path.relative(sourceBase,file.file).split(path.sep).join('/'),allowed=['skills/'+original.skillId,...bindings.flatMap(row=>[row.value.generationId,...row.value.sourceRootIds.filter(Boolean)].map(id=>'.work-data/generations/'+id+'/skills/'+original.skillId))];
        if(!allowed.some(name=>portableFold(name)===portableFold(relative)))migrationCapsuleFail('portable_log');rewrites.push({index,file:relative,backup:original.wrapper});
      }
      if(!rewrites.length)continue;let format=null;
      for(const indent of [null,2])for(const ending of ['','\n','\r\n'])if(JSON.stringify(value,null,indent)+ending===clean)format={indent,ending,bom};
      if(!format)migrationCapsuleFail('portable_log_owner_required');
      records.push({path:row.path,kind:'migration-log',recordId:binding.recordId,scopeId:binding.scopeId,purpose:binding.purpose,mode:opened.authenticated?'encrypted':'plain',value,format,rewrites});
    }

    if(providedEvidence&&nativeEvidence.length!==providedEvidence.size)migrationCapsuleFail('portable_native_evidence');
    nativeEvidence.sort((a,b)=>portableSort(a.path,b.path));originals.sort((a,b)=>portableSort(a.wrapper,b.wrapper));terminalCapsules.sort((a,b)=>portableSort(a.wrapper,b.wrapper));rawTrees.sort((a,b)=>portableSort(a.path,b.path));

    for(const binding of bindings)for(const entry of binding.value.entries.filter(entry=>entry.kind==='history')){const history=histories.get(entry.ref.stamp+'/'+entry.ref.skillId);if(!history||entry.physicalSkillId!==history.skillId||entry.phase!==history.history.value.phase||entry.historyMode!==history.history.mode||entry.archiveSha!==hash(input.files.get(portableFold(history.history.path)).data)||entry.intentSha!==history.marker.sha256)migrationCapsuleFail('portable_binding');}
    if(remaining.size)migrationCapsuleFail([...remaining.keys()].some(name=>/(?:\/.ruyi-capsule-v1$|\/archive$|\/intent$|\/objects\/|\/plain-v1\/|\/intents\/|\/representations-v1\/)/.test(name))?'portable_original_capsule_required':'portable_unknown');
    for(const name of input.dirs.values())if(!claimedDirectories.has(portableFold(name))){
      // Empty fixed control ancestors preserve names without granting authority.
      if(new RegExp('^\\.work-data/skill-backups/(?:intents|plain-v1|representations-v1)(?:/[a-f0-9]{48}){0,2}$',process.platform==='win32'?'i':'').test(name))claimedDirectories.add(portableFold(name));
      else migrationCapsuleFail('portable_unknown');
    }
    records.sort((a,b)=>portableSort(a.path,b.path));
    return {schema:1,type:'skill-backup-portable',sourceBase,source:{sourcePath:input.source.sourcePath,sourceSha256:input.source.sourceSha256},authority,records,...(originals.length||terminalCapsules.length||rawTrees.length||settledRepresentations.length?{originals,...(settledRepresentations.length||retainedCapsules.length||plainBackups.length?{settledRepresentations,retainedCapsules,plainBackups}:{}),...(terminalCapsules.length?{terminalCapsules}:{}),...(rawTrees.length?{rawTrees}:{}),nativeEvidence,liveTrees:[...liveTrees.values()].sort((a,b)=>portableSort(a.path,b.path))}:{}),
      profile:{originalObjects:originals.length||terminalCapsules.length||rawTrees.length||settledRepresentations.length?'new-owned-portable':'refused',terminalSnapshots:'source-history-only',nativeStreams:rawTrees.length?'enumerated-user-streams':'enumerated-default-only',destinationSecurity:'inherited; no source ACL replay'}};
  }
  async function capturePortable(request) {
    if(base.length>4096)migrationCapsuleFail('portable_capacity');
    const selected=await active(),expected=request?.expected;
    if(!expected?.proof||selected.proof.raw!==expected.proof.raw||selected.proof.sha256!==expected.proof.sha256)migrationCapsuleFail('generation_changed');
    const value=await collectPortable(request,base);
    if(value.authority.raw!==selected.proof.raw||value.authority.sha256!==selected.proof.sha256)migrationCapsuleFail('portable_authority');
    const input=portableInput(request),roots=new Set();
    for(const name of input.dirs.values())if(portableFold(name)==='.work-data/skill-backups'
      ||new RegExp('^(?:\\.work-data/generations/[a-f0-9]{48}/)?migrations/skill-backups$',process.platform==='win32'?'i':'').test(name))roots.add(name);
    for(const row of input.scoped.values())if(/\/migrations\/skill-backup-bindings-v2\.sealed$/i.test(row.path))roots.add(row.path.slice(0,row.path.lastIndexOf('/')));
    for(const name of roots){
      const absolute=path.join(base,...name.split('/')),snapshot=await portableCapture(absolute,hash(request.source.sourceSha256+':'+name));
      const insideRaw=entry=>(value.rawTrees||[]).some(row=>portableFold(name+'/'+entry.rel)===portableFold(row.path)||portableFold(name+'/'+entry.rel).startsWith(portableFold(row.path)+'/'));
      if(!migrationCapsuleShape(snapshot)||snapshot.entries.some(entry=>!insideRaw(entry)&&entry.streams.some(stream=>stream.name!=='')))migrationCapsuleFail('portable_native_streams');
      if(value.settledRepresentations?.length||value.plainBackups?.length)for(const proof of value.nativeEvidence){
        if(portableFold(proof.path)!==portableFold(name)&&!portableFold(proof.path).startsWith(portableFold(name)+'/'))continue;
        const prefix=proof.path.slice(name.length).replace(/^\//,'');
        for(const expected of proof.snapshot.entries){
          const relative=prefix+(prefix&&expected.rel?'/':'')+expected.rel,actual=snapshot.entries.find(entry=>portableFold(entry.rel)===portableFold(relative));
          if(!actual)migrationCapsuleFail('portable_source');const {rel:a,opaque:actualTransport,...actualMetadata}=actual,{rel:b,opaque:expectedTransport,...expectedMetadata}=expected;
          if(portableJSON(actualMetadata)!==portableJSON(expectedMetadata))migrationCapsuleFail('portable_native_changed');
        }
      }

      const expectedFiles=[...input.files.values()].filter(row=>portableFold(row.path).startsWith(portableFold(name)+'/'));
      const actual=snapshot.entries.filter(entry=>!entry.dir);if(actual.length!==expectedFiles.length)migrationCapsuleFail('portable_source');
      for(const entry of actual){const row=input.files.get(portableFold(name+'/'+entry.rel));const stream=entry.streams.find(item=>item.name==='');if(!row||!stream||!insideRaw(entry)&&entry.streams.length!==1||stream.hash!==hash(row.data)||stream.size!==row.data.length)migrationCapsuleFail('portable_source');}
      if(portableFold(name)==='.work-data/skill-backups'&&value.records.some(row=>row.kind==='catalog')){
        const catalog=value.records.find(row=>row.kind==='catalog').value,info=await platform.info(stableRoot);
        if(info.id!==catalog.rootId||info.volume!==catalog.volume)migrationCapsuleFail('store_identity');
      }
    }
    await current(selected);const data=Buffer.from(portableJSON(value));let released=false;
    return Object.freeze({type:'skill-backup-portable',schema:1,sourcePath:request.source.sourcePath,sourceSha256:request.source.sourceSha256,data,
      profile:Object.freeze({...value.profile}),release(){if(!released){released=true;data.fill(0);}}});
  }
  async function validatePortable({data,...request}={}) {
    if(!Buffer.isBuffer(data)||data.length<1||data.length>256*1024*1024)migrationCapsuleFail('portable_shape');
    const text=data.toString('utf8');if(!Buffer.from(text).equals(data))migrationCapsuleFail('portable_shape');const value=safeJsonParse(text,null);
    const optional=['originals','terminalCapsules','rawTrees','nativeEvidence','liveTrees','settledRepresentations','retainedCapsules','plainBackups'],mandatory=['schema','type','sourceBase','source','authority','records','profile'];
    if(!value||mandatory.some(name=>!Object.hasOwn(value,name))||Object.keys(value).some(name=>!mandatory.includes(name)&&!optional.includes(name))||value.schema!==1||value.type!=='skill-backup-portable'
      ||typeof value.sourceBase!=='string'||value.sourceBase.length>4096||!path.isAbsolute(value.sourceBase)||path.resolve(value.sourceBase)!==value.sourceBase)migrationCapsuleFail('portable_shape');
    const collected=await collectPortable(request,value.sourceBase,value.nativeEvidence);
    if(portableJSON(collected)!==text)migrationCapsuleFail('portable_binding');
    return portableClone(collected);
  }
  async function stagePortableOriginals({target,keysFor,assertTargetExclusive,targetOwnership,assertTargetExclusiveSync,request,value}) {
    if(typeof conversionNative.createOwnedPortable!=='function')migrationCapsuleFail('portable_native_create_required');
    const admission=async()=>{if(await assertTargetExclusive()!==true)migrationCapsuleFail('portable_owner');};
    await admission();await directory(path.dirname(target));if(await stat(target))migrationCapsuleFail('portable_target_exists');
    const stageRoot=path.join(path.dirname(target),'.ruyi-skill-portable-'+crypto.randomBytes(24).toString('hex')),input=portableInput(request),replacements=[],mappings=[],moves=[];let mutated=false;
    const originals=value.originals,terminals=value.terminalCapsules||[],rawTrees=value.rawTrees||[],physicalTrees=[...value.liveTrees,...rawTrees],archives=new Map(),liveTrees=new Map(),recordByPath=new Map(value.records.map(row=>[portableFold(row.path),row]));
    const inside=(name,root)=>portableFold(name)===portableFold(root)||portableFold(name).startsWith(portableFold(root)+'/');
    const oldOpaque=name=>originals.some(original=>{const snapshot=recordByPath.get(portableFold(original.archive)).value;return snapshot.entries.some(entry=>inside(name,original.wrapper+'/objects/'+entry.opaque));});
    const catalog=value.records.find(row=>row.kind==='catalog'),roots=[catalog?input.source.directories.find(name=>portableFold(name)==='.work-data/skill-backups/objects-v1'):null,
      ...input.source.directories.filter(name=>/^(?:\.work-data\/generations\/[a-f0-9]{48}\/)?migrations\/skill-backups$/i.test(name)),...value.liveTrees.map(row=>row.path),...(((value.settledRepresentations||[]).length||(value.plainBackups||[]).length||(value.retainedCapsules||[]).length)?['.work-data/skill-backups/representations-v1','.work-data/skill-backups/plain-v1','.work-data/skill-backups/intents'].filter(name=>input.dirs.has(portableFold(name))):[])].filter(Boolean);
    const parents=new Set([path.dirname(stageRoot)]),stagePath=name=>path.join(stageRoot,...name.split('/'));
    const retained=value.retainedCapsules||[],plainBackups=value.plainBackups||[],settled=value.settledRepresentations||[],newOriginals=new Map(),extraCopies=[];
    const rememberOriginal=(before,after)=>{if(before.entries.length!==after.entries.length)migrationCapsuleFail('portable_create_changed');newOriginals.set(rootId(before),after);};
    const translatedSnapshot=before=>{
      const actual=newOriginals.get(rootId(before));if(!actual)return portableClone(before);
      const result=portableClone(before);result.revision=actual.revision;
      for(const entry of result.entries){const replacement=actual.entries.find(row=>row.rel===entry.rel);if(!replacement||replacement.dir!==entry.dir)migrationCapsuleFail('portable_create_changed');entry.id=replacement.id;entry.opaque=replacement.opaque;}
      if(!migrationCapsulePortableShape(result))migrationCapsuleFail('portable_create_changed');return result;
    };
    const extraArchive=async row=>{
      const record=recordByPath.get(portableFold(row.archive)),snapshot=translatedSnapshot(record.value),source=descriptor('',row.stamp,row.skillId),copy={...source,backup:stagePath(row.wrapper),archiveKeys:await keysFor(row.archive)};
      await make(row.wrapper+'/objects');const bytes=require('node:zlib').gzipSync(Buffer.from(portableJSON(snapshot)));try{await migrationCapsuleArchive(copy).write(bytes);}finally{bytes.fill(0);}
      const reopened=await migrationCapsuleArchive(copy).read();try{if(portableJSON(migrationCapsuleDecode(reopened))!==portableJSON(snapshot))migrationCapsuleFail('portable_create_changed');}finally{reopened.fill(0);}
      archives.set(portableFold(row.archive),snapshot);
    };
    const extraIntent=async(record,slot,snapshot,{current=false,eligibility='edited'}={})=>{
      const liveName=(value.authority.id?'.work-data/generations/'+value.authority.id+'/':'')+'skills/'+slot.skillId,live=liveTrees.get(portableFold(liveName)),terminal=['complete','aborted'].includes(record.value.phase),staged={...portableClone(record.value),revision:snapshot.revision,oldRoot:rootId(snapshot)};
      if(terminal&&staged.historyPublish&&slot.historyPublishPath)staged.historyPublish.id=(await platform.info(stagePath(slot.historyPublishPath))).id;
      if(!terminal){staged.newTree=current&&live?migrationCapsuleFingerprint(live):record.value.newTree;staged.conversion={schema:1,operationId:record.value.conversion?.operationId||crypto.randomBytes(24).toString('hex'),eligibility:current?eligibility:'edited'};}
      const copy={...descriptor('',slot.stamp,slot.skillId),backup:stagePath(slot.wrapper),...(slot.plain?{plainRoot:stagePath(slot.physical)}:{}),intentFile:stagePath(record.path),intentRecordId:record.recordId,intentKeys:await keysFor(record.path),...(record.value.generationId?{generationId:record.value.generationId}:{})};
      await make(record.path.slice(0,record.path.lastIndexOf('/')));await migrationCapsuleIntent(copy).write(portableJSON(staged));if(portableJSON(safeJsonParse(await migrationCapsuleIntent(copy).read(),null))!==portableJSON(staged))migrationCapsuleFail('portable_binding');
      extraCopies.push({slot,record,snapshot,staged});
    };
    const transformBinding=async(staged,entry)=>{
      const current=staged.generationId===value.authority.id;
      if(entry.kind==='plain'){
        const slot=plainBackups.find(row=>row.generationId===staged.generationId&&row.backupId===entry.ref.backupId);if(!slot)migrationCapsuleFail('portable_binding');
        if(current&&slot.phase==='complete'){
          const history=value.records.find(row=>row.kind==='history'&&portableFold(row.path)===portableFold(slot.physical+'/history')),marker=slot.physical+'/'+MIGRATION_BACKUP_HISTORY_MARKER;if(!history)migrationCapsuleFail('portable_binding');
          entry.kind='history';entry.phase='complete';entry.historyMode=history.mode;entry.eligibility='terminal';entry.newTree=null;entry.archiveSha=await fileHash(stagePath(history.path));entry.intentSha=await fileHash(stagePath(marker));entry.sourceGenerationId=null;return;
        }
        const live=slot.live?liveTrees.get(portableFold(slot.live)):null;entry.eligibility=slot.phase!=='published'?'terminal':current?slot.eligibility:'edited';entry.newTree=entry.eligibility==='eligible'?migrationCapsuleFingerprint(live):null;
        entry.archiveSha=await fileHash(stagePath(slot.archive));entry.intentSha=await fileHash(stagePath(slot.intent));return;
      }
      const original=[...originals,...terminals,...retained].find(row=>row.stamp===entry.ref.stamp&&portableFold(row.skillId)===entry.ref.skillId&&hash(input.files.get(portableFold(row.archive)).data)===entry.archiveSha);if(!original)migrationCapsuleFail('portable_binding');
      const live=original.live?liveTrees.get(portableFold(original.live)):null,terminal=original.phase&&original.phase!=='published';if(terminal)entry.phase=original.phase;entry.eligibility=terminal?'terminal':current?original.eligibility:'edited';entry.newTree=entry.eligibility==='eligible'?migrationCapsuleFingerprint(live):null;
      entry.archiveSha=await fileHash(stagePath(original.archive));entry.intentSha=await fileHash(stagePath(entry.sourceGenerationId?'.work-data/skill-backups/intents/'+entry.sourceGenerationId+'/'+entry.ref.backupId+'.sealed':original.intent));
    };

    const make=async name=>{await admission();const absolute=stagePath(name);await fsp.mkdir(absolute,{recursive:true});await directory(absolute);let cursor=absolute;for(;;){parents.add(cursor);if(eq(cursor,stageRoot))break;cursor=path.dirname(cursor);}return absolute;};
    const write=async(name,data)=>{await make(name.slice(0,name.lastIndexOf('/')));await admission();const handle=await fsp.open(stagePath(name),'wx',0o600);try{await handle.writeFile(data);await handle.sync();}finally{await handle.close();}};
    try {
      await admission();await fsp.mkdir(stageRoot,{mode:0o700});mutated=true;const stageIdentity=await platform.info(stageRoot);
      for(const name of input.source.directories.filter(name=>roots.some(root=>inside(name,root))&&!physicalTrees.some(row=>inside(name,row.path))&&!oldOpaque(name)).sort((a,b)=>a.split('/').length-b.split('/').length||portableSort(a,b)))await make(name);
      for(const row of input.scoped.values())if(roots.some(root=>inside(row.path,root))&&!originals.some(original=>inside(row.path,original.wrapper))&&!rawTrees.some(raw=>inside(row.path,raw.path))&&recordByPath.get(portableFold(row.path))?.kind!=='representation-record')await write(row.path,row.data);
      // Relevant live trees are reconstructed first, so every newTree identity is
      // known before target mkdir and belongs to a real staged object.
      for(const row of physicalTrees){await make(row.path.slice(0,row.path.lastIndexOf('/')));await admission();const snapshot=await conversionNative.createOwnedPortable({root:stagePath(row.path),snapshot:row.snapshot,revision:hash('portable-new-live:'+crypto.randomBytes(32).toString('hex'))});
        if(!migrationCapsuleShape(snapshot))migrationCapsuleFail('portable_create_changed');liveTrees.set(portableFold(row.path),snapshot);if(rawTrees.includes(row))rememberOriginal(row.snapshot,snapshot);
      }
      for(const original of originals){
        const record=recordByPath.get(portableFold(original.archive)),old=record.value,scratch='.owned-originals/'+crypto.randomBytes(24).toString('hex');await make(scratch);const root=stagePath(scratch+'/'+original.skillId);await admission();
        const snapshot=await conversionNative.createOwnedPortable({root,snapshot:old,revision:hash('portable-new-original:'+crypto.randomBytes(32).toString('hex'))});if(!migrationCapsuleShape(snapshot)||snapshot.entries.length!==old.entries.length)migrationCapsuleFail('portable_create_changed');
        rememberOriginal(old,snapshot);archives.set(portableFold(original.archive),snapshot);await make(original.wrapper+'/objects');await admission();await conversionNative.seal({root,container:stagePath(original.wrapper+'/objects'),snapshot});
        // This maps only owned opaque object names; semantic skill IDs stay exact.
        for(const entry of old.entries){const next=snapshot.entries.find(row=>row.rel===entry.rel);if(!next||next.dir!==entry.dir)migrationCapsuleFail('portable_create_changed');mappings.push({source:original.wrapper+'/objects/'+entry.opaque,target:original.wrapper+'/objects/'+next.opaque,dir:entry.dir});}
        const marker=input.files.get(portableFold(original.marker.path));await write(marker.path,marker.data);
        const source=descriptor('',original.stamp,original.skillId),keys=await keysFor(original.archive),targetDescriptor={...source,backup:stagePath(original.wrapper),archiveKeys:keys};
        const bytes=require('node:zlib').gzipSync(Buffer.from(portableJSON(snapshot)));try{await migrationCapsuleArchive(targetDescriptor).write(bytes);}finally{bytes.fill(0);}
        const reopened=await migrationCapsuleArchive(targetDescriptor).read();try{if(portableJSON(migrationCapsuleDecode(reopened))!==portableJSON(snapshot))migrationCapsuleFail('portable_create_changed');}finally{reopened.fill(0);}
      }
      // Terminal capsules retain authenticated historical snapshots and IDs.
      // They never enter createOwnedPortable/seal: only their real current live
      // tree (if any) is newly owned. Every intent is terminalized below.
      for(const terminal of terminals){
        const record=recordByPath.get(portableFold(terminal.archive)),source=descriptor('',terminal.stamp,terminal.skillId),keys=await keysFor(terminal.archive),copy={...source,backup:stagePath(terminal.wrapper),archiveKeys:keys};
        const bytes=require('node:zlib').gzipSync(Buffer.from(portableJSON(record.value)));try{await migrationCapsuleArchive(copy).write(bytes);}finally{bytes.fill(0);}
        const reopened=await migrationCapsuleArchive(copy).read();try{if(portableJSON(migrationCapsuleDecode(reopened))!==portableJSON(record.value))migrationCapsuleFail('portable_terminal_changed');}finally{reopened.fill(0);}
      }
      // Rebind every fixed intent to the staged originals. Only the selected
      // live generation can retain eligible undo; older views become edited.
      for(const record of value.records.filter(row=>row.kind==='capsule-intent')){
        const original=[...originals,...terminals].find(row=>row.stamp===record.value.stamp&&row.skillId===record.value.id);if(!original)migrationCapsuleFail('portable_binding');const snapshot=original.phase?recordByPath.get(portableFold(original.archive)).value:archives.get(portableFold(original.archive)),live=original.live?liveTrees.get(portableFold(original.live)):null;
        const isCurrent=record.value.generationId===undefined||record.value.generationId===value.authority.id,eligibility=isCurrent?original.eligibility:'edited',staged=original.phase?{...portableClone(record.value),phase:original.phase}:{...portableClone(record.value),revision:snapshot.revision,oldRoot:rootId(snapshot),newTree:live?migrationCapsuleFingerprint(live):[],conversion:{schema:1,operationId:crypto.randomBytes(24).toString('hex'),eligibility:live?eligibility:'gone'}};
        const keys=await keysFor(record.path),descriptor={id:original.skillId,stamp:original.stamp,backup:stagePath(original.wrapper),scopeId:record.scopeId,recordId:'skill-backup:'+portableFold(original.skillId),intentFile:stagePath(record.path),intentRecordId:record.recordId,intentKeys:keys,...(record.value.generationId?{generationId:record.value.generationId}:{})};
        await make(record.path.slice(0,record.path.lastIndexOf('/')));await admission();await migrationCapsuleIntent(descriptor).write(portableJSON(staged));const checked=safeJsonParse(await migrationCapsuleIntent(descriptor).read(),null);if(portableJSON(checked)!==portableJSON(staged))migrationCapsuleFail('portable_binding');
      }
      for(const row of [...retained,...plainBackups])await extraArchive(row);
      for(const row of [...retained,...plainBackups]){
        const record=recordByPath.get(portableFold(row.intent)),snapshot=archives.get(portableFold(row.archive));await extraIntent(record,row,snapshot,{current:row.generationId===value.authority.id,eligibility:row.eligibility});
      }
      for(const record of value.records.filter(row=>row.kind==='representation-variant')){
        const generationId=record.value.generationId,backupId=hash(record.value.stamp+'/'+portableFold(record.value.id)),binding=value.records.find(row=>row.kind==='binding'&&row.value.generationId===generationId),bound=binding?.value.entries.find(entry=>entry.ref.backupId===backupId);
        const slot=[...originals,...terminals,...retained,...plainBackups].find(row=>row.stamp===record.value.stamp&&row.skillId===record.value.id&&(!bound||hash(input.files.get(portableFold(row.archive)).data)===bound.archiveSha));if(!slot)migrationCapsuleFail('portable_binding');
        const sourceSnapshot=recordByPath.get(portableFold(slot.archive)).value,snapshot=archives.get(portableFold(slot.archive))||translatedSnapshot(sourceSnapshot);
        await extraIntent(record,slot,snapshot,{current:generationId===value.authority.id,eligibility:slot.eligibility});
      }

      const verifyCopies=async root=>{
        for(const check of extraCopies){const slot=check.slot,copy={...descriptor('',slot.stamp,slot.skillId),backup:path.join(root,...slot.wrapper.split('/')),...(slot.plain?{plainRoot:path.join(root,...slot.physical.split('/'))}:{}),archiveKeys:await keysFor(slot.archive),intentKeys:await keysFor(check.record.path),intentFile:path.join(root,...check.record.path.split('/')),intentRecordId:check.record.recordId,...(check.staged.generationId?{generationId:check.staged.generationId}:{})},reopened=await migrationCapsuleRead(capturedDescriptor(copy));if(portableJSON(reopened.snapshot)!==portableJSON(check.snapshot)||portableJSON(reopened.intent)!==portableJSON(check.staged))migrationCapsuleFail('portable_binding');}

        for(const record of value.records.filter(row=>row.kind==='capsule-intent')){
          const original=[...originals,...terminals].find(row=>row.stamp===record.value.stamp&&row.skillId===record.value.id),source=descriptor('',original.stamp,original.skillId),copy={...source,backup:path.join(root,...original.wrapper.split('/')),archiveKeys:await keysFor(original.archive),intentKeys:await keysFor(record.path),intentFile:path.join(root,...record.path.split('/')),intentRecordId:record.recordId,...(record.value.generationId?{generationId:record.value.generationId}:{})};
          const current=await migrationCapsuleRead(capturedDescriptor(copy)),expected=original.phase?recordByPath.get(portableFold(original.archive)).value:archives.get(portableFold(original.archive));if(portableJSON(current.snapshot)!==portableJSON(expected)||current.intent.oldRoot!==rootId(expected)||original.phase&&current.intent.phase!==original.phase)migrationCapsuleFail('portable_binding');
        }
      };await verifyCopies(stageRoot);
      let objectsInfo=null;if(catalog)objectsInfo=await platform.info(stagePath(roots.find(root=>portableFold(root)==='.work-data/skill-backups/objects-v1')));
      const validators={catalog:catalogValid,relocation:journalValid,representation:representationValid,'representation-record':representationRecordValid,binding:bindingValid};
      for(const record of value.records){
        if(record.kind==='migration-log'){
          const staged=portableClone(record.value);for(const row of record.rewrites){staged.files[row.index].file=path.join(target,...row.file.split('/'));staged.files[row.index].backup=path.join(target,...row.backup.split('/'));}
          const text=record.format.bom+JSON.stringify(staged,null,record.format.indent)+record.format.ending;await make(record.path.slice(0,record.path.lastIndexOf('/')));const keys=record.mode==='encrypted'?await keysFor(record.path):undefined;
          const store=WorkDataStore.createText({file:()=>stagePath(record.path),purpose:record.purpose,schema:1,scopeId:record.scopeId,recordId:record.recordId,chunked:true,maxPlaintextBytes:256*1024*1024,keys,enabled:()=>record.mode==='encrypted',writeJson:atomicWriteJson});await admission();await store.write(text);if(await store.read()!==text)migrationCapsuleFail('portable_log');continue;
        }
        if(['history','capsule-archive','capsule-intent','representation-archive','representation-intent','representation-variant','plain-archive','plain-intent','representation-provenance'].includes(record.kind))continue;const validate=validators[record.kind];if(!validate)migrationCapsuleFail('portable_shape');const staged=portableClone(record.value);
        if(record.kind==='catalog'||record.kind==='relocation'&&staged.phase==='kept'){if(!objectsInfo)migrationCapsuleFail('portable_store');staged.rootId=objectsInfo.id;staged.volume=objectsInfo.volume;}
        if(record.kind==='binding')for(const entry of staged.entries)if(entry.kind!=='history')await transformBinding(staged,entry);
        if(record.kind==='representation-record'){
          const history=settled.find(row=>row.path===record.path);if(!history)migrationCapsuleFail('portable_binding');
          staged.original=translatedSnapshot(record.value.original);staged.target=translatedSnapshot(record.value.target);staged.revision=staged.original.revision;
          if(staged.eligibility!=='terminal'){staged.eligibility=record.value.eligibility==='gone'?'gone':'edited';}
          staged.archiveSha=await fileHash(stagePath(history.archive));staged.intentSha=await fileHash(stagePath(history.intent));
          // Wrapper IDs are derived from the same closed source native evidence;
          // historical original IDs without a physical owner remain unchanged.
          for(const field of ['capsuleId','historyId'])if(staged[field]){
            let name=null;for(const proof of value.nativeEvidence||[])for(const entry of proof.snapshot.entries)if(entry.id===record.value[field])name=entry.rel?proof.path+'/'+entry.rel:proof.path;
            if(name){const actual=await platform.info(stagePath(name));staged[field]=actual.id;if(field==='historyId'){const proof=await portableCapture(stagePath(name),staged.revision);staged.historyTree=migrationCapsuleFingerprint(proof);}}
          }
        }

        await make(record.path.slice(0,record.path.lastIndexOf('/')));const keys=await keysFor(record.path);await admission();await sealed(stagePath(record.path),record.recordId,validate,keys,target).write(staged);if(portableJSON(await sealed(stagePath(record.path),record.recordId,validate,keys,target).read())!==portableJSON(staged))migrationCapsuleFail('portable_binding');
      }
      for(const record of value.records.filter(row=>row.kind!=='history')){const bytes=await fsp.readFile(stagePath(record.path));replacements.push({path:record.path,data:bytes,sha256:hash(bytes)});}
      for(const name of roots){const snapshot=await portableCapture(stagePath(name),hash('portable-stage:'+name));if(!migrationCapsuleShape(snapshot))migrationCapsuleFail('portable_stage_changed');moves.push({path:name,info:await platform.info(stagePath(name)),snapshot});}
      const parentBindings=await portableBindExternal([...parents].filter(root=>!portableWithin(stageRoot,root)),'external-parent',admission);
      const stageProof=await portableCapture(stageRoot,hash('portable-stage-root:'+crypto.randomBytes(32).toString('hex')));await admission();if(await stat(target))migrationCapsuleFail('portable_target_exists');const stageDurability=await portableStageDurability(stageRoot,stageProof,stageIdentity,[...parents],parentBindings,admission);
      const skipFiles=request.files.filter(row=>roots.some(root=>inside(row.path,root))).map(row=>row.path),token=Object.freeze({stageRoot,stageIdentity:Object.freeze({...stageIdentity}),files:Object.freeze(replacements.map(row=>Object.freeze({...row}))),skipDirectories:Object.freeze(roots),skipFiles:Object.freeze(skipFiles),pathMappings:Object.freeze(mappings.map(row=>Object.freeze({...row}))),profile:Object.freeze({...value.profile}),release(){for(const row of replacements)row.data.fill(0);}});
      portableStages.set(token,{originals:true,verifyCopies,target,targetOwnership,assertTargetExclusiveSync,stageRoot,stageIdentity,stageProof,stageDurability,moves,replacements,admission,installed:false,installStarted:false,targetIdentity:null});return token;
    }catch(cause){if(!mutated)throw cause;throw Object.assign(new Error('work_data_backup.portable_stage_failed',{cause}),{code:'work_data_backup.portable_stage_failed',apiCode:'work_data_backup.portable_stage_failed',statusCode:409,operationMayHaveExecuted:true,resultUnavailable:true,retry:false,stageRetained:stageRoot,...(cause?.helperMayStillRun===true?{helperMayStillRun:true}:{})});}
  }
  function portableTargetReadAdmission(owned,selected){
    const targetOwner=owned.targetOwnership;
    if(selected!==targetOwner||!targetOwner||!Array.isArray(targetOwner.roots)||!targetOwner.roots.some(root=>typeof root==='string'&&path.isAbsolute(root)&&eq(path.resolve(root),owned.target))||typeof owned.assertTargetExclusiveSync!=='function')migrationCapsuleFail('portable_target_owner');
    const proof=owned.assertTargetExclusiveSync(targetOwner);
    if(proof&&typeof proof.then==='function'){Promise.resolve(proof).catch(()=>{});throw Object.assign(new Error('work_data_backup.portable_target_owner_uncertain'),{code:'work_data_backup.portable_target_owner_uncertain',helperMayStillRun:true,ownershipRetained:true,operationMayHaveExecuted:true,resultUnavailable:true,retry:false});}
    if(proof!==true)migrationCapsuleFail('portable_target_owner');return true;
  }
  async function withPortableTargetReads(owned,work){
    if(!preservedTree)return work();
    await owned.admission();portableTargetReadAdmission(owned,owned.targetOwnership);
    const targetOwner=owned.targetOwnership,tree=WorkDataTree.createPreserved({capturePreserved:portableCapture,ownership:targetOwner,
      assertExclusive:async selected=>{await owned.admission();return portableTargetReadAdmission(owned,selected);},assertExclusiveSync:selected=>portableTargetReadAdmission(owned,selected),limits:preservedRead.limits||{}});
    let captured,result,failed=false,primary;
    try{captured=await tree.capture(owned.target);result=await portableTargetReads.run({captured,ownership:targetOwner},work);await tree.verify(captured);portableTargetReadAdmission(owned,targetOwner);}
    catch(cause){failed=true;primary=cause;}
    let cleanupFailed=false,cleanup;try{if(captured){const released=captured.release();if(released!==undefined){if(released&&typeof released.then==='function')Promise.resolve(released).catch(()=>{});throw new Error('portable_target_read_release_unproven');}}}catch(cause){cleanupFailed=true;cleanup=cause;}
    if(cleanupFailed){
      const error=migrationCapturedCleanupFailure(primary,failed,[cleanup],true);
      Object.assign(error,{code:'work_data_backup.portable_target_read_cleanup_uncertain',message:'work_data_backup.portable_target_read_cleanup_uncertain'});
      throw error;
    }
    if(failed)throw primary;return result;
  }
  // Diagnostic-only: runs after an unchanged refusal predicate, using existing memory.
  function portableTargetSnapshotDelta(actual,expected){
    const limited=value=>typeof value==='string'&&value.length>1024?value.slice(0,1024)+'[truncated]':value;
    const a=new Map(actual.entries.map(row=>[row.rel,row])),e=new Map(expected.entries.map(row=>[row.rel,row])),deltas=[];let changedEntries=0;
    for(const rel of new Set([...e.keys(),...a.keys()])){const old=e.get(rel),now=a.get(rel),fields={};
      if(!old||!now)fields.membership={expected:!!old,actual:!!now};else{
        for(const key of ['id','dir','attrs','shortName','times'])if(JSON.stringify(old[key])!==JSON.stringify(now[key]))fields[key]={expected:old[key],actual:now[key]};
        const oldStreams=new Map(old.streams.map(row=>[row.name,row])),newStreams=new Map(now.streams.map(row=>[row.name,row])),streams=[];let changedStreams=0;
        for(const name of new Set([...oldStreams.keys(),...newStreams.keys()])){const before=oldStreams.get(name),after=newStreams.get(name),streamFields={};if(!before||!after)streamFields.membership={expected:!!before,actual:!!after};else{for(const key of ['size','hash'])if(before[key]!==after[key])streamFields[key]={expected:before[key],actual:after[key]};if(before.data!==after.data)streamFields.dataDifferent=true;}
          if(Object.keys(streamFields).length){changedStreams++;if(streams.length<4)streams.push({name:limited(name),fields:streamFields});}}
        if(changedStreams)fields.streams={changedStreams,shown:streams.length,entries:streams};
      }
      if(Object.keys(fields).length){changedEntries++;if(deltas.length<8)deltas.push({rel:limited(rel),fields});}
    }
    return{revision:{expected:expected.revision,actual:actual.revision},count:{expected:expected.entries.length,actual:actual.entries.length},changedEntries,shown:deltas.length,entries:deltas};
  }
  function portableTargetFailure(check,details){
    try{migrationCapsuleFail('portable_target_changed');}catch(error){
      try{const diagnostic={schema:1,check,...details()};const diagnosticJson=JSON.stringify(diagnostic);error.portableDiagnostic=diagnosticJson.length<=24576?JSON.parse(diagnosticJson):{schema:1,check,detailTruncated:true};}
      catch{try{error.portableDiagnostic={schema:1,check,diagnosticUnavailable:true};}catch{}}
      throw error;
    }
  }
  async function verifyPortableOriginals(owned){
    return withPortableTargetReads(owned,async()=>{
    if(!owned.installed)migrationCapsuleFail('portable_token');await owned.admission();await directory(owned.target);const root=await fsp.lstat(owned.target,{bigint:true});if(String(root.dev)!==owned.targetIdentity.dev||String(root.ino)!==owned.targetIdentity.ino)portableTargetFailure('originals.verify.root-identity',()=>({expected:owned.targetIdentity,actual:{dev:String(root.dev),ino:String(root.ino)}}));
    for(const move of owned.moves){const file=path.join(owned.target,...move.path.split('/')),info=await platform.info(file),snapshot=await portableCapture(file,move.snapshot.revision);if(info.id!==move.info.id||info.volume!==move.info.volume||!migrationCapsuleSameMetadata(snapshot,move.snapshot))portableTargetFailure('originals.verify.move',()=>({path:move.path,expected:{id:move.info.id,volume:move.info.volume},actual:{id:info.id,volume:info.volume},delta:portableTargetSnapshotDelta(snapshot,move.snapshot)}));}
    for(const row of owned.replacements)if(await fileHash(path.join(owned.target,...row.path.split('/')))!==row.sha256||hash(row.data)!==row.sha256)portableTargetFailure('originals.verify.replacement-sha256',()=>({path:row.path,expectedSha256:row.sha256,actualHashNotRetained:true}));
    await owned.verifyCopies(owned.target);await owned.admission();return Object.freeze({target:owned.target,readOnly:true,originalObjects:'new-owned-portable',terminalSnapshots:'source-history-only'});
    });
  }
  async function installPortableOriginals(owned,{targetIdentity}={}){
    if(owned.installed||owned.installStarted||!targetIdentity||!['dev','ino'].every(key=>typeof targetIdentity[key]==='string'))migrationCapsuleFail('portable_token');await owned.admission();await directory(owned.target);const root=await fsp.lstat(owned.target,{bigint:true});if(String(root.dev)!==targetIdentity.dev||String(root.ino)!==targetIdentity.ino)portableTargetFailure('originals.install.root-identity',()=>({expected:targetIdentity,actual:{dev:String(root.dev),ino:String(root.ino)}}));
    const stage=await portableCapture(owned.stageRoot,owned.stageProof.revision);if(!migrationCapsuleSameMetadata(stage,owned.stageProof))migrationCapsuleFail('portable_stage_changed');portableAssertDurability(owned.stageDurability,owned.stageRoot,owned.stageIdentity,stage);
    const moveNames=owned.moves.map(row=>row.path),protectedRoots=moveNames.map(name=>path.join(owned.target,...name.split('/'))),requiredFlushRoots=[owned.target,...new Set(owned.moves.map(row=>path.dirname(path.join(owned.target,...row.path.split('/')))))],targetBindings=await portableBindExternal(portableExternalOnly(requiredFlushRoots,protectedRoots),'new-target-ancestor',owned.admission);portableAssertExternal(owned.stageDurability,targetBindings);
    try{owned.installStarted=true;for(const move of owned.moves){await owned.admission();const source=path.join(owned.stageRoot,...move.path.split('/')),target=path.join(owned.target,...move.path.split('/'));await directory(path.dirname(target));if(await stat(target))migrationCapsuleFail('portable_target_exists');const result=await platform.move({source,target,id:move.info.id,preserveMetadata:true});if(!result||result.id!==move.info.id||result.volume!==move.info.volume)migrationCapsuleFail('portable_store');}
      owned.installed=true;owned.targetIdentity=Object.freeze({...targetIdentity});await portableVerifyInherited(owned.stageDurability,owned.stageRoot,owned.target,owned.stageIdentity,moveNames,owned.admission);await portableFlushBound(targetBindings,owned.admission);return await verifyPortableOriginals(owned);
    }catch(cause){throw Object.assign(new Error('work_data_backup.portable_install_uncertain',{cause}),{code:'work_data_backup.portable_install_uncertain',apiCode:'work_data_backup.portable_install_uncertain',statusCode:409,operationMayHaveExecuted:true,resultUnavailable:true,retry:false,stageRetained:owned.stageRoot,targetRetained:owned.target,...(cause?.helperMayStillRun===true?{helperMayStillRun:true}:{})});}
  }

  async function stagePortable({target,keysFor,assertTargetExclusive,targetOwnership,assertTargetExclusiveSync,data,...request}={}) {
    if(typeof target!=='string'||!path.isAbsolute(target)||!eq(target,path.resolve(target))||typeof keysFor!=='function'||typeof assertTargetExclusive!=='function')migrationCapsuleFail('portable_host');
    if(preservedTree)portableTargetReadAdmission({target,targetOwnership,assertTargetExclusiveSync},targetOwnership);
    const within=(a,b)=>{const relative=path.relative(samePathKey(a),samePathKey(b));return relative===''||relative!=='..'&&!relative.startsWith('..'+path.sep)&&!path.isAbsolute(relative);};
    if(within(base,target)||within(target,base))migrationCapsuleFail('portable_target');
    const admission=async()=>{if(await assertTargetExclusive()!==true)migrationCapsuleFail('portable_owner');};
    await admission();const value=await validatePortable({...request,data});portableRequireDurabilityHost();if(value.originals?.length||value.terminalCapsules?.length||value.rawTrees?.length||value.settledRepresentations?.length)return stagePortableOriginals({target,keysFor,assertTargetExclusive,targetOwnership,assertTargetExclusiveSync,request,value});await directory(path.dirname(target));
    const absent=async file=>{if(await stat(file))migrationCapsuleFail('portable_target_exists');};await absent(target);
    const stageRoot=path.join(path.dirname(target),'.ruyi-skill-portable-'+crypto.randomBytes(24).toString('hex'));
    let mutated=false;
    try{
      await admission();await fsp.mkdir(stageRoot,{mode:0o700});mutated=true;await directory(stageRoot);
      const stageIdentity=await platform.info(stageRoot),input=portableInput(request),catalog=value.records.find(row=>row.kind==='catalog'),replacements=[];
      const allDirs=new Set([stageRoot,path.dirname(stageRoot)]),objectsName=catalog?input.source.directories.find(name=>portableFold(name)==='.work-data/skill-backups/objects-v1'):null;
      let objectInfo=null,objectProof=null;
      const makeParents=async relative=>{const parent=path.dirname(path.join(stageRoot,...relative.split('/')));await fsp.mkdir(parent,{recursive:true});await directory(parent);let cursor=parent;for(;;){allDirs.add(cursor);if(eq(cursor,stageRoot))break;cursor=path.dirname(cursor);}};
      if(catalog){
        if(!objectsName)migrationCapsuleFail('portable_store');
        for(const name of input.source.directories.filter(name=>portableFold(name)===portableFold(objectsName)||portableFold(name).startsWith(portableFold(objectsName)+'/')).sort((a,b)=>a.split('/').length-b.split('/').length||portableSort(a,b))){await makeParents(name+'/placeholder');await directory(path.join(stageRoot,...name.split('/')));}
        const objectRoot=path.join(stageRoot,...objectsName.split('/'));objectInfo=await platform.info(objectRoot);
        if(!id24(objectInfo.id)||typeof objectInfo.volume!=='string')migrationCapsuleFail('portable_store');
        for(const row of input.scoped.values())if(portableFold(row.path).startsWith(portableFold(objectsName)+'/')){
          await makeParents(row.path);const handle=await fsp.open(path.join(stageRoot,...row.path.split('/')),'wx',0o600);try{await handle.writeFile(row.data);await handle.sync();}finally{await handle.close();}
        }
        objectProof=await portableCapture(objectRoot,hash(value.source.sourceSha256+':target-store'));
        if(!migrationCapsuleShape(objectProof)||objectProof.entries.some(entry=>entry.streams.some(stream=>stream.name!=='')))migrationCapsuleFail('portable_native_streams');
      }
      const validators={catalog:catalogValid,relocation:journalValid,representation:representationValid,binding:bindingValid};
      for(const record of value.records){
        if(record.kind==='history')continue;const validate=validators[record.kind];if(!validate)migrationCapsuleFail('portable_shape');
        const staged=portableClone(record.value);
        if(record.kind==='catalog'||record.kind==='relocation'&&staged.phase==='kept'){if(!objectInfo)migrationCapsuleFail('portable_store');staged.rootId=objectInfo.id;staged.volume=objectInfo.volume;}
        await makeParents(record.path);const file=path.join(stageRoot,...record.path.split('/')),keys=await keysFor(record.path);
        if(!keys||typeof keys.snapshot!=='function')migrationCapsuleFail('portable_keys');
        await sealed(file,record.recordId,validate,keys,target).write(staged);
        const reopened=await sealed(file,record.recordId,validate,keys,target).read();if(portableJSON(reopened)!==portableJSON(staged))migrationCapsuleFail('portable_binding');
        const bytes=await fsp.readFile(file);replacements.push({path:record.path,data:bytes,sha256:hash(bytes)});
      }
      const parentBindings=await portableBindExternal([...allDirs].filter(root=>!portableWithin(stageRoot,root)),'external-parent',admission);
      const stageProof=await portableCapture(stageRoot,hash(value.source.sourceSha256+':stage'));if(!migrationCapsuleShape(stageProof)||stageProof.entries.some(entry=>entry.streams.some(stream=>stream.name!=='')))migrationCapsuleFail('portable_native_streams');
      await admission();await absent(target);const stageDurability=await portableStageDurability(stageRoot,stageProof,stageIdentity,[...allDirs],parentBindings,admission);
      const token=Object.freeze({stageRoot,stageIdentity:Object.freeze({...stageIdentity}),objectsRoot:objectsName,files:Object.freeze(replacements.map(row=>Object.freeze({...row}))),
        skipDirectories:Object.freeze(objectsName?[objectsName]:[]),skipFiles:Object.freeze(objectsName?[...input.scoped.values()].filter(row=>portableFold(row.path).startsWith(portableFold(objectsName)+'/')).map(row=>row.path):[]),
        profile:Object.freeze({...value.profile}),release(){for(const row of replacements)row.data.fill(0);}});
      portableStages.set(token,{target,stageRoot,stageIdentity,stageProof,stageDurability,objectsName,objectInfo,objectProof,replacements,admission,installed:false,targetIdentity:null});return token;
    }catch(cause){if(!mutated)throw cause;throw Object.assign(new Error('work_data_backup.portable_stage_failed',{cause}),{code:'work_data_backup.portable_stage_failed',apiCode:'work_data_backup.portable_stage_failed',statusCode:409,operationMayHaveExecuted:true,resultUnavailable:true,retry:false,stageRetained:stageRoot,...(cause?.helperMayStillRun===true?{helperMayStillRun:true}:{})});}
  }
  async function verifyPortableInstalled(token){
    const owned=portableStages.get(token);if(owned?.originals)return verifyPortableOriginals(owned);if(!owned?.installed)migrationCapsuleFail('portable_token');await owned.admission();
    await directory(owned.target);const actualRoot=await fsp.lstat(owned.target,{bigint:true});
    if(String(actualRoot.dev)!==owned.targetIdentity.dev||String(actualRoot.ino)!==owned.targetIdentity.ino)migrationCapsuleFail('portable_target_changed');
    for(const row of owned.replacements){if(hash(row.data)!==row.sha256||await fileHash(path.join(owned.target,...row.path.split('/')))!==row.sha256)migrationCapsuleFail('portable_target_changed');}
    for(const parent of new Set(owned.replacements.map(row=>path.dirname(path.join(owned.target,...row.path.split('/')))))){const actual=await portableCapture(parent,owned.stageProof.revision);if(!migrationCapsuleShape(actual)||actual.entries.some(entry=>entry.streams.some(stream=>stream.name!=='')))migrationCapsuleFail('portable_native_streams');}
    if(owned.objectsName){const root=path.join(owned.target,...owned.objectsName.split('/')),info=await platform.info(root),actual=await portableCapture(root,owned.objectProof.revision);if(info.id!==owned.objectInfo.id||info.volume!==owned.objectInfo.volume||!migrationCapsuleSame(actual,migrationCapsuleFingerprint(owned.objectProof)))migrationCapsuleFail('portable_target_changed');}
    await owned.admission();return Object.freeze({target:owned.target,readOnly:true,originalObjects:'refused',terminalSnapshots:'source-history-only'});
  }
  async function installPortable(token,{targetIdentity}={}){
    const owned=portableStages.get(token);if(owned?.originals)return installPortableOriginals(owned,{targetIdentity});if(!owned||owned.installed||owned.installStarted)migrationCapsuleFail('portable_token');await owned.admission();
    if(!targetIdentity||!['dev','ino'].every(name=>typeof targetIdentity[name]==='string'))migrationCapsuleFail('portable_target');
    await directory(owned.target);const actual=await fsp.lstat(owned.target,{bigint:true});if(String(actual.dev)!==targetIdentity.dev||String(actual.ino)!==targetIdentity.ino)migrationCapsuleFail('portable_target_changed');
    const stage=await platform.info(owned.stageRoot);if(stage.id!==owned.stageIdentity.id||stage.volume!==owned.stageIdentity.volume)migrationCapsuleFail('portable_stage_changed');
    const stageCurrent=await portableCapture(owned.stageRoot,owned.stageProof.revision);if(!migrationCapsuleSame(stageCurrent,migrationCapsuleFingerprint(owned.stageProof)))migrationCapsuleFail('portable_stage_changed');portableAssertDurability(owned.stageDurability,owned.stageRoot,owned.stageIdentity,stageCurrent);
    const inheritedNames=owned.objectsName?[owned.objectsName]:[],protectedRoots=inheritedNames.map(name=>path.join(owned.target,...name.split('/'))),requiredFlushRoots=[owned.target,path.join(owned.target,'.work-data'),path.join(owned.target,'.work-data','skill-backups')].filter(root=>owned.objectsName||eq(root,owned.target)),targetBindings=await portableBindExternal(portableExternalOnly(requiredFlushRoots,protectedRoots),'new-target-ancestor',owned.admission);portableAssertExternal(owned.stageDurability,targetBindings);
    for(const row of owned.replacements)if(hash(row.data)!==row.sha256||await fileHash(path.join(owned.target,...row.path.split('/')))!==row.sha256)migrationCapsuleFail('portable_target_changed');
    try{
      owned.installStarted=true;
      if(owned.objectsName){const source=path.join(owned.stageRoot,...owned.objectsName.split('/')),target=path.join(owned.target,...owned.objectsName.split('/'));await directory(path.dirname(target));if(await stat(target))migrationCapsuleFail('portable_target_exists');const current=await portableCapture(source,owned.objectProof.revision);if(!migrationCapsuleSame(current,migrationCapsuleFingerprint(owned.objectProof)))migrationCapsuleFail('portable_stage_changed');const moved=await platform.move({source,target,id:owned.objectInfo.id,preserveMetadata:true});if(moved.id!==owned.objectInfo.id||moved.volume!==owned.objectInfo.volume)migrationCapsuleFail('portable_store');}
      owned.installed=true;owned.targetIdentity=Object.freeze({...targetIdentity});await portableVerifyInherited(owned.stageDurability,owned.stageRoot,owned.target,owned.stageIdentity,inheritedNames,owned.admission);await portableFlushBound(targetBindings,owned.admission);
      return await verifyPortableInstalled(token);
    }catch(cause){throw Object.assign(new Error('work_data_backup.portable_install_uncertain',{cause}),{code:'work_data_backup.portable_install_uncertain',apiCode:'work_data_backup.portable_install_uncertain',statusCode:409,operationMayHaveExecuted:true,resultUnavailable:true,retry:false,targetRetained:owned.target,stageRetained:owned.stageRoot,...(cause?.helperMayStillRun===true?{helperMayStillRun:true}:{})});}
  }

  // Narrow first-enable retirement. The authenticated original package proves
  // that this control namespace did not predate the pending transition. Tokens
  // remain private to this owner; a boolean recovery result grants no deletion.
  const emptyCancellations = new WeakMap();
  const emptyNames = ['relocation-v1.sealed', 'representation-v1.sealed'];
  async function emptyPhysical(file) {
    await directory(path.dirname(file)); const before = await fsp.lstat(file, { bigint: true });
    if (!before.isFile() || before.isSymbolicLink() || before.nlink !== 1n || before.size < 1n || before.size > 128n * 1024n) migrationCapsuleFail('empty_cancel_changed');
    const handle = await fsp.open(file, 'r'); let bytes;
    try {
      const opened = await handle.stat({ bigint: true }); bytes = Buffer.alloc(Number(before.size) + 1);let count = 0;
      while (count < bytes.length) {const read = await handle.read(bytes, count, bytes.length - count, null);if (!read.bytesRead) break;count += read.bytesRead;}
      const after = await handle.stat({ bigint: true }), current = await fsp.lstat(file, { bigint: true });
      for (const value of [opened, after, current]) if (!value.isFile() || value.isSymbolicLink() || value.nlink !== 1n
        || value.dev !== before.dev || value.ino !== before.ino || value.size !== before.size || value.mtimeNs !== before.mtimeNs || value.ctimeNs !== before.ctimeNs) migrationCapsuleFail('empty_cancel_changed');
      if (count !== Number(before.size)) migrationCapsuleFail('empty_cancel_changed');
      return { sha256: hash(bytes.subarray(0, count)), dev: String(before.dev), ino: String(before.ino) };
    } finally { bytes?.fill(0); await handle.close(); }
  }
  const sameEmptyPhysical = (a, b) => a.sha256 === b.sha256 && a.dev === b.dev && a.ino === b.ino;
  async function emptyNative(root) {
    const snapshot = await platform.capture(root, crypto.randomBytes(32).toString('hex'));
    if (!migrationCapsuleShape(snapshot) || snapshot.entries.some(row => row.attrs !== (row.dir ? 16 : 32) && !(row.dir === false && row.attrs === 128)
      || row.streams.length !== (row.dir ? 0 : 1) || row.streams.some(stream => stream.name !== ''))) migrationCapsuleFail('empty_cancel_native');
    return snapshot;
  }
  async function emptyAdmission(known, assertUnchanged) {
    if (typeof assertUnchanged !== 'function' || await assertUnchanged() !== true) migrationCapsuleFail('empty_cancel_ownership');
    const selected = await active();
    if (selected.id !== null || selected.proof.raw !== null || selected.proof.sha256 !== null) migrationCapsuleFail('empty_cancel_authority');
    await directory(path.join(base, '.work-data'));
    const names = await fsp.readdir(path.join(base, '.work-data'));
    if (names.some(name => !['generations', 'maintenance-v1.json', 'skill-backups'].includes(name))) migrationCapsuleFail('empty_cancel_external_reference');
    await directory(path.join(base, '.work-data', 'generations'));
    const generations = await fsp.readdir(path.join(base, '.work-data', 'generations'));
    if (!(generations.length === 1 && generations[0] === known.candidateId || generations.length === 0 && (known.retired || known.allowMissing)) || await stat(path.join(base, 'work-data-key-v1.json'))) migrationCapsuleFail('empty_cancel_external_reference');
  }
  async function emptyLayout(known, allowStable) {
    if (!await directory(control, true)) { if (known.controlIdentity && !known.retired) migrationCapsuleFail('empty_cancel_changed'); return []; }
    if (known.controlIdentity) {const observed = await fsp.lstat(control, { bigint: true });if (String(observed.dev) !== known.controlIdentity.dev || String(observed.ino) !== known.controlIdentity.ino) migrationCapsuleFail('empty_cancel_changed');}
    const names = (await fsp.readdir(control)).sort();
    if (names.some(name => !emptyNames.includes(name) && !(allowStable && name === 'objects-v1'))) migrationCapsuleFail('empty_cancel_external_reference');
    for (const root of [legacyRoot, stableRoot]) if (await stat(root)) {
      await directory(root);
      if (eq(root, legacyRoot) && known.legacyIdentity) {const observed = await fsp.lstat(root, { bigint: true });if (String(observed.dev) !== known.legacyIdentity.dev || String(observed.ino) !== known.legacyIdentity.ino) migrationCapsuleFail('empty_cancel_changed');}
      if ((await fsp.readdir(root)).length) migrationCapsuleFail('empty_cancel_nonempty');
      const captured = await emptyNative(root); if (captured.entries.length !== 1 || !captured.entries[0].dir) migrationCapsuleFail('empty_cancel_nonempty');
    }
    if (!allowStable && await stat(stableRoot)) migrationCapsuleFail('empty_cancel_unsettled');
    for (const name of names.filter(value => emptyNames.includes(value))) await emptyPhysical(path.join(control, name));
    const snapshot = await emptyNative(control);
    if (snapshot.entries.length !== names.length + 1) migrationCapsuleFail('empty_cancel_changed');
    for (const row of snapshot.entries) if (row.rel && (!names.includes(row.rel) || row.dir !== (row.rel === 'objects-v1'))) migrationCapsuleFail('empty_cancel_changed');
    return names.filter(name => emptyNames.includes(name));
  }
  async function prepareEmptyCancellation({ serialized, password, state, assertUnchanged } = {}) {
    let copied; try { copied = JSON.parse(JSON.stringify(state)); } catch { migrationCapsuleFail('empty_cancel_request'); }
    if (typeof serialized !== 'string' || !hex(copied?.backup?.sha256) || hash(serialized) !== copied.backup.sha256
      || copied.schema !== 2 || copied.operation !== 'enable' || !['candidate', 'key-ready', 'canceling'].includes(copied.phase)
      || copied.expectedAuthority?.generation !== 0 || copied.expectedAuthority.id !== null || copied.expectedAuthority.sha256 !== null || copied.expectedAuthority.mode !== 'plain'
      || !id48(copied.id) || !id48(copied.candidate?.id) || copied.candidate.mode !== 'encrypted') migrationCapsuleFail('empty_cancel_request');
    const known = { candidateId: copied.candidate.id, backupSha256: copied.backup.sha256, records: null, retired: false, allowMissing: copied.phase === 'canceling' };
    const opened = await WorkDataRecovery.open(serialized, password);
    try {
      const snapshot = opened.snapshot, lower = value => process.platform === 'win32' ? value.toLowerCase() : value;
      if (snapshot.generation !== 0 || snapshot.keys.some(row => row.purpose === 'work-data')
        || [...snapshot.files.map(row => row.path), ...snapshot.directories].some(relative => {
          const name = lower(relative); return name === 'migrations/skill-backups' || name === '.work-data' || name.startsWith('.work-data/') || name === 'work-data-key-v1.json'
            || name.startsWith('migrations/skill-backups/');
        }) || snapshot.auxiliaries.some(row => row.type === 'skill-backup-portable')) migrationCapsuleFail('empty_cancel_preexisting');
      const config = snapshot.files.find(row => lower(row.path) === 'config.json');
      if (!config) migrationCapsuleFail('empty_cancel_source');
      const text = config.data.toString('utf8'); let value;
      try { if (!Buffer.from(text).equals(config.data)) migrationCapsuleFail('empty_cancel_source'); value = JSON.parse(text.replace(/^\uFEFF/, '')); } catch { migrationCapsuleFail('empty_cancel_source'); }
      if (!value || typeof value !== 'object' || Array.isArray(value) || value.workDataEncryptionV1 !== undefined && value.workDataEncryptionV1 !== false) migrationCapsuleFail('empty_cancel_source');
    } finally { opened.release(); }
    await emptyAdmission(known, assertUnchanged); await emptyLayout(known, true);
    const before = new Map();
    for (const name of emptyNames) if (await stat(path.join(control, name))) before.set(name, await emptyPhysical(path.join(control, name)));
    const relocation = await journalStore().read(), representation = await representationStore().read();
    if (relocation && (relocation.targetId !== known.candidateId || relocation.sourceProof !== null || !['prepared', 'moved', 'canceled'].includes(relocation.phase))
      || representation && relocation && representation.storeId !== relocation.storeId
      || representation && (representation.targetId !== known.candidateId || representation.sourceId !== null || representation.sourceProof !== null
        || representation.mode !== 'encrypted' || representation.entries.length || !['prepared', 'converted', 'canceled'].includes(representation.phase))) migrationCapsuleFail('empty_cancel_unsettled');
    for (const [name, proof] of before) if (!sameEmptyPhysical(proof, await emptyPhysical(path.join(control, name)))) migrationCapsuleFail('empty_cancel_changed');
    // Only this authenticated empty transition may move its root back. Unknown
    // operation journals, old controls, and nonempty objects never reach recover.
    await emptyAdmission(known, assertUnchanged); await recoverRepresentation(); await recover();
    const names = await emptyLayout(known, false), canceled = await journalStore().read(), represented = await representationStore().read();
    if (canceled && (canceled.phase !== 'canceled' || canceled.targetId !== known.candidateId || canceled.sourceProof !== null)
      || represented && (represented.phase !== 'canceled' || represented.entries.length || represented.targetId !== known.candidateId)) migrationCapsuleFail('empty_cancel_unsettled');
    if (canceled) {
      await directory(legacyRoot); const identity = await platform.info(legacyRoot);
      if (identity.id !== canceled.rootId || identity.volume !== canceled.volume) migrationCapsuleFail('empty_cancel_changed');
    }
    if (canceled && represented && canceled.storeId !== represented.storeId) migrationCapsuleFail('empty_cancel_unsettled');
    if (await stat(control)) {const observed = await fsp.lstat(control, { bigint: true });known.controlIdentity = {dev: String(observed.dev), ino: String(observed.ino)};}
    if (await stat(legacyRoot)) {const observed = await fsp.lstat(legacyRoot, { bigint: true });known.legacyIdentity = {dev: String(observed.dev), ino: String(observed.ino)};}
    known.records = new Map(); for (const name of names) known.records.set(name, await emptyPhysical(path.join(control, name)));
    await emptyAdmission(known, assertUnchanged);
    const proof = Object.freeze({ candidateId: known.candidateId, backupSha256: known.backupSha256, profile: 'first-enable-empty-canceled' });
    emptyCancellations.set(proof, known); return proof;
  }
  async function retireEmptyCancellation(proof, { assertUnchanged, flush } = {}) {
    const known = emptyCancellations.get(proof); if (!known || known.retired || typeof flush !== 'function') migrationCapsuleFail('empty_cancel_proof');
    await emptyAdmission(known, assertUnchanged); const names = await emptyLayout(known, false);
    if (names.length !== known.records.size || names.some(name => !known.records.has(name))) migrationCapsuleFail('empty_cancel_changed');
    for (const [name, expected] of known.records) if (!sameEmptyPhysical(expected, await emptyPhysical(path.join(control, name)))) migrationCapsuleFail('empty_cancel_changed');
    const remaining = new Set(names);
    for (const [name, expected] of known.records) {
      await emptyAdmission(known, assertUnchanged); const actualNames = await emptyLayout(known, false);
      if (actualNames.length !== remaining.size || actualNames.some(value => !remaining.has(value)) || !sameEmptyPhysical(expected, await emptyPhysical(path.join(control, name)))) migrationCapsuleFail('empty_cancel_changed');
      await fsp.unlink(path.join(control, name)); remaining.delete(name); await flush([control, path.dirname(control), base]);
    }
    if (await stat(control)) {
      await emptyAdmission(known, assertUnchanged); if ((await emptyLayout(known, false)).length || (await fsp.readdir(control)).length) migrationCapsuleFail('empty_cancel_changed');
      await fsp.rmdir(control); await flush([path.dirname(control), base]);
    } else if (known.controlIdentity) migrationCapsuleFail('empty_cancel_changed');
    known.retired = true; return await verifyEmptyCancellation(proof, { assertUnchanged });
  }
  async function verifyEmptyCancellation(proof, { assertUnchanged } = {}) {
    const known = emptyCancellations.get(proof); if (!known || !known.retired) migrationCapsuleFail('empty_cancel_proof');
    await emptyAdmission(known, assertUnchanged);
    if (await stat(control)) migrationCapsuleFail('empty_cancel_external_reference');
    if (await directory(legacyRoot, true)) {
      const observed = await fsp.lstat(legacyRoot, { bigint: true });
      if (known.legacyIdentity && (String(observed.dev) !== known.legacyIdentity.dev || String(observed.ino) !== known.legacyIdentity.ino)) migrationCapsuleFail('empty_cancel_changed');
      if ((await fsp.readdir(legacyRoot)).length) migrationCapsuleFail('empty_cancel_nonempty');
      const snapshot = await emptyNative(legacyRoot); if (snapshot.entries.length !== 1) migrationCapsuleFail('empty_cancel_nonempty');
    }
    if (known.legacyIdentity && !await stat(legacyRoot)) migrationCapsuleFail('empty_cancel_changed');
    await emptyAdmission(known, assertUnchanged); return true;
  }

  return Object.freeze({ prepare, prepareBindings, recover, activate, resolve, ref, prepareRepresentation, recoverRepresentation, prepareEmptyCancellation, retireEmptyCancellation, verifyEmptyCancellation, verifyPublished, capturePortable, validatePortable, stagePortable, installPortable, verifyPortableInstalled, testCollect:collectPortable, testBindingValid:bindingValid });
}