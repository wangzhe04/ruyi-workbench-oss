'use strict';
const fs=require('node:fs'),p=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),c=require('node:crypto'),{EventEmitter}=require('node:events');
const {constBlock,functionBlock,bracedBlock}=require(p.join(process.cwd(),'dev-harness/lib/source-slice.js'));
const src=fs.readFileSync(p.join(__dirname,'fullbefore/13u-migration-center.js'),'utf8');
const ctx={};vm.createContext(ctx);vm.runInContext(constBlock(src,'MIGRATION_SKILL_CAPSULE_NATIVE')+'\nthis.native=MIGRATION_SKILL_CAPSULE_NATIVE;',ctx);const native=ctx.native;
fs.writeFileSync(p.join(__dirname,'native.fullbefore.cs'),native,{flag:'wx'});
const nativeSha=c.createHash('sha256').update(native).digest('hex');assert.equal(nativeSha,'491cee21c881189594c105141675b51088e62b850078dbec58d7305fc8b3bdc8');
const capture=bracedBlock(native,'static object Capture(Dictionary<string,object> args)'),preserved=bracedBlock(native,'static object CapturePreserved(Dictionary<string,object> args)'),close=bracedBlock(native,'static void Close()'),run=bracedBlock(native,'public static void Run()');
assert.ok(capture.includes('if (Nodes.Count != 0) Reject("already_open")'));assert.ok(preserved.includes('RestoreBasic(new List<Node>(Nodes.Values))'));assert.ok(!preserved.includes('Close()'));
assert.ok(close.includes('stream.Dispose()')&&close.includes('node.Handle.Dispose()')&&close.includes('Nodes.Clear()'));assert.ok(!close.includes('CloseHandle')&&!close.includes('GetHandleInformation'));
assert.ok(run.includes('else if (command == "close") { Close(); Console.WriteLine("{\\"ok\\":true}"); return; }'));
let spawns=0,commands=0,closed=0,children=[];
const fakeCp={spawn(){spawns++;const child=new EventEmitter();child.pid=100+spawns;child.stdout=new EventEmitter();child.stderr=new EventEmitter();child.stderr.resume=()=>{};child.stdin=new EventEmitter();child.stdin.write=(wire,cb)=>{commands++;queueMicrotask(()=>{cb?.();child.stdout.emit('data',Buffer.from(JSON.stringify({ok:true,value:{schema:1,revision:'0'.repeat(64),entries:[],platform:'ntfs-objects-v1'}})+'\n'));});};child.stdin.end=()=>{queueMicrotask(()=>child.emit('exit',0));};child.kill=()=>{};children.push(child);return child;}};
const timers={next:1,setTimeout(){return this.next++;},clearTimeout(){}};
const jsctx={Buffer,process,Promise,console,require:name=>name==='node:child_process'?fakeCp:name==='node:timers'?timers:require(name),MIGRATION_SKILL_CAPSULE_NATIVE:native,MIGRATION_CAPSULE_ARCHIVE_LIMIT:160*1024*1024,migrationCapsuleFail:reason=>{throw Error(reason)},migrationCapsuleShape:()=>true};vm.createContext(jsctx);
vm.runInContext(functionBlock(src,'migrationCapsuleBroker')+'\n'+functionBlock(src,'migrationCapsuleCapturePreserved')+'\nthis.capture=migrationCapsuleCapturePreserved;this.broker=migrationCapsuleBroker;',jsctx);
(async()=>{for(let i=0;i<2;i++){let escaped=false;const promise=jsctx.capture('C:\\Synthetic',String(i).padStart(64,'0')).then(v=>{escaped=true;return v});for(let j=0;j<10;j++)await Promise.resolve();assert.equal(escaped,false,'exit without actual close cannot release snapshot');children.at(-1).emit('close',0);closed++;await promise;assert.equal(escaped,true);}
assert.equal(spawns,2);assert.equal(commands,2);assert.equal(closed,2);
jsctx.broker.helperMayStillRun=true;await assert.rejects(()=>jsctx.capture('C:\\Synthetic','0'.repeat(64)),e=>e.helperMayStillRun===true);assert.equal(spawns,2);
// Deliberately insufficient reset proposal: managed Dispose success says nothing about a checked kernel release.
const fakeHandle={managedClosed:false,kernelOpen:true,Dispose(){this.managedClosed=true;}};fakeHandle.Dispose();assert.equal(fakeHandle.managedClosed,true);assert.equal(fakeHandle.kernelOpen,true);
const proof={nativeSha,actualSourceChecks:{captureRejectsOutstandingNodes:true,preservedDoesNotResetNodes:true,CloseOnlyUsesDispose:true,closeCommandTerminatesRun:true},actualJsPure:{captures:commands,spawns,actualCloses:closed,noEscapeOnExitBeforeClose:true,inheritedUnknownRefusesWithoutSpawn:true},counter:{managedDisposeCanReportClosedWithoutKernelReleaseEvidence:true},newSessionImplemented:false,status:'BLOCKED_SOURCE_PROPOSAL_ONLY',noNative:true};
fs.writeFileSync(p.join(__dirname,'pure-proof.json'),JSON.stringify(proof,null,2),{flag:'wx'});console.log(JSON.stringify(proof));})().catch(e=>{console.error(e);process.exitCode=1});
