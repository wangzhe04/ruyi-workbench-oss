# Capture-only census session：source proposal，阻断状态

本次仅Temp复制/读取与强pure。未改仓库、build、native执行、socket、浏览器、live；未运行任何PowerShell helper。没有可准入的after候选，不声称新1spawn路径通过。现有Dispose不能证明原生handle已关闭，因此按任务的停步条件停在source proposal。

## 冻结与实际pure

fullbefore/保存实际PRIVATE输入01aa fcfb、Host9f00、13u887d及原ordinary driver。native.fullbefore.cs从实际13u String.raw常量提取，UTF8 SHA=491cee21c881189594c105141675b51088e62b850078dbec58d7305fc8b3bdc8。manifest.json逐文件记录完整SHA。

pure-controls.cjs通过source-slice提取真实C#方法作结构性断言，并真正执行原JS migrationCapsuleBroker/capturePreserved函数（仅child/timer替身）。证实2capture=2spawn=2actualclose；单有exit0没有close时snapshot不能逃逸；继承永久unknown时零新spawn并拒绝。pure-proof.json保持原结果。

C#结构性证据：Capture:738–739拒绝Nodes非空；CapturePreserved:1294–1297仅RestoreBasic不Close；Close:1048–1050只是Dispose后clear；Run close分支调用Close后return；原Run没有capture-only reset。pure中的managed Dispose成功但kernelOpen仍true是逻辑反例，说明这种模型可满足当前检查，绝不是实测Win32 Dispose失败。

## 明确阻断

不能把SafeFileHandle.IsClosed或Dispose未抛当作OS closure证明，不能让Close()+ACK替代原actual helper exit/close。当前Close没有检查kernel释放结果；异常时还可能只dispose了一部分Nodes。正常命令ACK也不能证明其他捕获期间临时handle、BackupRead context已按严格合同完成。这里没有足够现成原语可以直接给reset“无遗留handle”的严格ACK。

因此不生成“调用原Close()+返回成功”的伪安全实现。也不把一份替身模型的new1spawn断言写成真实C#执行证据。已保存原代码，after与reverse补丁均标absent，不创建零内容patch冒充已实施span。

## 最窄后续source设计

建议增加隔离的RunCaptureOnly入口而不改原Run/close状态机。它只接受最多两次同root的capture-preserved-reset，禁止CreateOwned、attach、restore、publish、store-move、flush及任何已登记目标操作；第一次进入必须Nodes空、Snapshot/Capsule/OriginalRoot空，固定root和scope，任何未知态永久poison，不允许再读。不跨census、Store或owner缓存session。

每次命令：CapturePreserved原捕获完整运行 → 在success或failure路径完成可证明的capture-only资源清理 → 成功时仅在所有登记Node/ADS handles及capture临时资源闭合后返回snapshot。第一ACK返回Node原metadata检查；第二同样清理。原两次完整capture、所有source identity/native metadata/hash/owner比较和顺序保持。

安全原语候选是单独审查的checked kernel close与SafeHandle ownership转移：持有DangerousAddRef防finalizer，检查CloseHandle返回，成功后SetHandleAsInvalid避免双关，再DangerousRelease；逐项聚合所有失败，失败/Dispose/转换不确定永久poison。它不是现有Close的等价单行替换，必须审查重复引用、未登记/部分初始化handles、失败Open/Walk及异常聚合，否则仍保持阻断。不得在未独立证实该原语前批准新reset命令。

JS optional接口建议withCaptureScope({root,ownership,assertExclusive},work)。仅新ownerProfile启用；default capturePreserved及所有现有reader行为保持。01aa.census在admitted+realDirectory后建立scope，在其try/finally内保留两次capture、所有原检查、first/second释放和result清零。success=true只能在scope final await实际exit/close0及最后owner assertion之后设置；close未知/falsy/继承unknown合并主原因并永久unknown保owner，不允许返回snapshot/Buffer。任何已经构造的result buffer须在scope close错误时全部清零。

broker可以复用原串行pending/120秒command/2秒close状态机，但新入口选择必须独立并默认Run，禁止对普通调用暴露可回退scope。scope一个helper，两命令，最终stdin.end→actualexit0→actualclose0；每次reset ACK仅允许继续Node checks，不能释放outer ownership或提供census结果。close未知永久latch必须先于错误逃逸，晚到close不能洗白。

接线只通过ownerProfile新字段，转发到01ab readTree、01ad sourceTree及13u native preserved owner构造。driver变化单独span/逆补丁，7roles、原fixture、业务断言和240000/250000/2000ms预算不动。最终应把每capture序号/command/实际exit-close分开记录到无内容journal，不能凭PID推测命令。

## 准入前必须补齐的证据

真实C#资源原语审查优先，其后才有after/full逆与可运行候选。强pure不得替代Win32 handle closure实际门。

- 正控：新census两capture+两reset，1spawn和最后actualclose；旧baseline2spawn。完整双snapshot/opaque transport、ID、DATA/ADS/hash、attrs/shortName/四Basic时间与全部原verify/barrier逐项守恒；原节点检查严格位于两reset之间。
- reset拒绝：CreateOwned或已有目标/Nodes/Capsule、跨root、第三次capture、并发command、reset前/后owner撤销；部分登记与未登记Open/Walk/ADS失败；Dispose、CloseHandle、SafeHandle ownership转移任意失败永久unknown并保owner。
- JS拒绝：command/reset失败、reset ACK丢失/重复、只exit不close、close非0、2秒超时、继承unknown、lateclose、falsy主原因与cleanup组合；任何结果Buffer零化且不逃逸。当前pure已钉原actualclose与继承unknown两点。
- 原谓词负控：两次snapshot间改ID、内容、ADS、attrs/shortName/任一时间，Node namespace别名/硬链接/size变化，memory hash篡改和末端owner撤销；每个移除对应检查的旧/反补丁必须红。
- 所有after source全文SHA、actualnative文本SHA、每唯一span及整逆核验、driver接线独立身份；非作者native/JS审通过后，由ROOT独占实际helper跑完整新根七角色和末端inventory。不得调预算、缩fixture或借旧绿灯。

现有源组合B1dJYe helper实际261、终态记录实际0，与外层timeout分开；本报告不把首因归咎机器，也不据启动次数许诺整个门能进250秒。后续真实门是否获益仍待测量。

## 追加：现有同session verify强度逐谓词矩阵

全部依据native491文本，无Win32实跑、无先验等价声明。Run:1446的cmd verify仅调用Verify(Convert.ToBoolean(args["cleared"]),true)。不存在verify-source、VerifyData或VerifyMetadata命令/函数。用cleared=false才是未清空的读取校验；cleared=true是清空状态检查，不能替代原census。

|原第二完整census要求|Verify(false,true):817–837|其他现有函数|结论|
|---|---|---|---|
|完整expected对象数|expected.Count==Nodes.Count；held Nodes计数|VerifyEntries:838–846拒绝未知目录子项|部分覆盖；不是重捕获对象集|
|原始root/rel布局|VerifyEntries把当前PathOf收进集合，不比较Entry.rel或OriginalRoot|VerifyOriginalLayout:847–855/VerifyNames:956–962会比较root/rel；普通cmd verify均未调用|缺原始布局钉住|
|对象ID|逐held Id与Entry.id比较；Id也拒不支持attrs和多链接|目录检查也比较ID|已覆盖held ID；缺重新按原路径打开的等价证明|
|default及ADS集合|StreamNames当前/expected双向比较，缺失/新增拒绝|目录同样参与|已覆盖held流集合|
|default及ADS内容|每expected stream Read+Hash与保存hash比较|Read检查长度、末尾；snapshot size/hash也参与原census|覆盖held字节hash；不能凭此补metadata|
|精确attrs|Id只验证支持mask/类型/链接，不与Entry.attrs相等|RestoreNodeBasic会先回写旧attrs后比较；CheckCapturedDirectory精确比较但只dirs|缺全对象只读精确attrs|
|四Basic时间|无Creation/Access/Write/Change比较|RestoreNodeBasic先回写旧时间；CheckCapturedDirectory精确比较仅dirs|缺全对象只读4times；回写不能替代拒绝|
|精确shortName|false分支完全不比较shortName；true只要求空|VerifyNames/OriginalLayout使用OrdinalIgnoreCase；CheckCapturedDirectory用Ordinal但仅dirs|缺全对象精确shortName|
|新实际完整snapshot/nativeSha|verify响应value为空，保留旧Snapshot；没有第二实际snapshot|VerifyPortableReadback:1304–1330按rel/ID/dir/attrs/4times/Ordinal shortName/streams size/hash/data全比，但参数actual来自CreateOwnedPortable:1410再次CapturePreserved|不能返回旧Snapshot冒充第二实测|
|metadata自扰守恒/最后close|verify无CapturePreserved的RestoreBasic finally；最终actualprocessclose仍必要|对held handle的时间抑制不能先验等同整个namespace枚举的闭环|缺同等closed reader完整证明|

最直接反例方向：仅在支持mask内改变attrs或四项时间、保持ID与字节不变，Verify(false,true)没有读取/比较对应expected字段，无法证明拒绝；false分支的alias变化也无判据。只用普通verify再返回旧metadata会将此变化作为旧值假通过。这里是源码谓词缺项证明，不冒充实际Win32反例。

VerifyOriginalLayout或VerifyNames即使额外暴露也不能补齐attrs/4times，且alias比较还比原census的nativeSha精确字符串弱。RestoreBasic是修复旧值，不是读取并拒绝变化，禁止拿它填这个缺项。CheckCapturedDirectory专用于新owned-stage/owned-target的capture-owned-flush-ready，FlushCapturedDirectories具有刷盘副作用及专属token/volume/ownership绑定，既不覆盖file也不能借到source。

因此不存在当前可调用、纯只读且完整等价于原第二census的verify组合；保留原两次完整捕获要求。要实现held-source强verify需要新的全对象metadata/namespace/stream闭包和时间抑制审查，已经超出最小现有命令复用，不在本轮偷偷扩大native片。reset方案也仍须可证明closure原语，保持BLOCKED_SOURCE_PROPOSAL_ONLY。
