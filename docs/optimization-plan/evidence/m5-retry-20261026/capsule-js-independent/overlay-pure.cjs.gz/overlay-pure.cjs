'use strict';
const fs=require('node:fs'),p=require('node:path'),c=require('node:crypto'),a=require('node:assert/strict'),{constBlock,functionBlock}=require('C:/Users/87179/Documents/Claude Code/ruyi-workbench-oss/dev-harness/lib/source-slice');
const tmp='C:/Users/87179/AppData/Local/Temp',hash=b=>c.createHash('sha256').update(b).digest('hex'),baseline=fs.readFileSync(p.join(tmp,'ruyi-complete-js-review-ac3fe725c52a4ac0b9e25458f6cd8bfe/13u-migration-center.js.private'),'utf8'),v3=fs.readFileSync(p.join(tmp,'ruyi-create-owned-cleanup-v3-20261026-936be00c/13u-after.js'),'utf8'),overlay=fs.readFileSync(p.join(tmp,'ruyi-n1-root-review-20261026/13u-v3-resource-native-path.js'),'utf8');
a.equal(hash(baseline),'02d2edd58e4463723e592f1ba56a64b718c903382541b436aa14c8ddc1f827fb');a.equal(hash(v3),'5b8ac5381b9cca2a8c004b8257a4889cad0d0f0ea256fd048cb22f1ab57727ba');a.equal(hash(overlay),'7647e3e8d4dfbb41fc9344bfd1ce756f4511647942e0d22077bb0e9b0f383377');
const nativeName='MIGRATION_SKILL_CAPSULE_NATIVE',functionName='migrationCapsuleCreateOwnedPortable';for(const s of [baseline,v3,overlay]){a.ok(constBlock(s,nativeName).length>10000);a.ok(functionBlock(s,functionName).length>1000);}
a.equal(functionBlock(v3,functionName),functionBlock(overlay,functionName));a.equal(v3.replace(functionBlock(v3,functionName),functionBlock(baseline,functionName)),baseline);
a.equal(overlay.replace(constBlock(overlay,nativeName),constBlock(v3,nativeName)),v3);
console.log('PASS_EXACT_V3_ONE_JS_FUNCTION_OVERLAY_NATIVE_ONLY_REMAINDER');
