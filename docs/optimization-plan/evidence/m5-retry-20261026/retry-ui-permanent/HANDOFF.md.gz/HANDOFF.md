# Permanent UI49 + real-source window/history4

Two authoritative files are under files/:
- dev-harness/unit/external-bots-ui.test.js: original c450c2f3 file is an exact byte prefix, with only nine new UI cases appended. Original40 test bodies, shared fixture, actual relative ESM imports and locale reads are not adapted.
- dev-harness/unit/external-bots-retry-window.test.js: four tests read the actual repository 13w, actual source-history/contracts/history fixtures and directly import the actual public retry-state module. No TEMP/env/Git path or filesystem shim is used by either product test.

products.json gives base/new SHA. spans.json gives one unique append-only source span and full inverse to original UI40 file. The backend/UI source remains the independently reviewed UI candidate: backend0f20414a, frontend0b9c20ab, module5d265f02. This package changes no production source, fixture or browser assertion.

Limited pure evidence:
- In a new source mirror, exact candidate UI/backend/fixtures and original public JS dependencies were placed at normal repository-relative paths. No server.js, build, app main, socket, browser, native helper or real platform was started.
- These actual permanent two files pass53/53 first run and53/53 after restoring negative controls.
- The exact unmodified original UI40 file separately passes40/40 against the same actual ESM initialization.
- Six current negatives each fail exit1/ERR_ASSERTION: module-local owner, new ID for uncertain replay, missing reload recovery, old completion unlocking another owner, widened backend window and missing v5 source inverse.
- Negatives mutate only mirror copies, never authoritative files or live checkout, and restore bytes afterward.
- mirror-manifest.json binds the source tree used by those runs; the mirror also retains an extra original40 comparison file. It is evidence, not an installation payload. Only files/ contains requested tests.

No new port first failures occurred. The prior temporary UI preparation's three locale-path ENOENT errors remain in its original frozen package; those TEMP adaptations were not brought into the permanent file.

After root independent review, apply only the two products alongside approved M5 backend + portable test fixture layers + UI/hint layer. Then run repository native Node24 focused tests and actual HTTP/browser gates serially as root already planned. The existing233 browser assertions are unchanged and not executed here. This is not B1 or3.1 completion.
