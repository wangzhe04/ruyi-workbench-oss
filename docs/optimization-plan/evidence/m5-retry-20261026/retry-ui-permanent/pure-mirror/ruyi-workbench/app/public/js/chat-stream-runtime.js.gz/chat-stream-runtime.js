'use strict';

export function applyToolUseUpdate(card, evt, deps = {}) {
  if (!card || !evt) return;
  const { humanizeToolName, safeStringify, toolArgSummary } = deps;
  if (evt.name) {
    card.name = evt.name;
    if (card.nameEl) card.nameEl.textContent = evt.name;
    if (card.verbEl) card.verbEl.textContent = humanizeToolName(evt.name);
  }
  if (evt.input && typeof evt.input === 'object') {
    if (card.inp) card.inp.textContent = safeStringify(evt.input);
    const arg = toolArgSummary(evt.input);
    if (card.argEl) { card.argEl.textContent = arg; card.argEl.title = arg || ''; }
  }
}

const THINKING_NARRATIVE_BOUNDARY_TYPES = new Set([
  'assistant_delta',
  'tool_use',
  'mission',
  'ask_user',
  'permission_request',
  'plan',
  'kimi_plan_snapshot',
  'plan_note',
  'turn_summary',
  'result',
  'compact',
  'error',
]);

// A thinking panel is a chronological narrative segment, not a transport-event bucket. Keep telemetry and
// updates to already-rendered cards out of this decision: they may arrive between two thinking deltas without
// representing a new step in the conversation. A positive list also makes future UI-only event additions safe
// by default. Keep this aligned with the events that insert a new narrative item below.
export function isThinkingNarrativeBoundary(evt) { // 批 3·D:导出只为 thinking-boundary.static 直测(不再 vm 切源码)
  const type = String(evt?.type || '');
  // 子代理自己的 tool_use / compact(带 subagentId)只进它自己的卡片,不是父回合叙事里的新一步;后台 run 晚到的节点 / 工作流起头同理(它们的卡片挂在思考块下面,不把父回合还没写完的思考切成几块)。
  if (!type || (evt.subagentId && (type === 'tool_use' || type === 'compact'))) return false;
  if (type === 'subagent') return evt.state === 'start' && evt.background !== true;
  if (type === 'agent_workflow') return (evt.state === 'start' || evt.state === 'running') && evt.background !== true;
  return THINKING_NARRATIVE_BOUNDARY_TYPES.has(type);
}

export function createChatStreamRuntime(deps = {}) {
  const {
    $,
    api,
    apiErrText,
    privacyFailure = () => null,
    // Agent CLI 登记表的查询函数（js/agent-cli-registry.js 的 agentCliMeta）。本模块零 import，由组合根注入。
    agentCliMeta,
    appendToolOutput,
    authHeaders,
    autoGrow,
    cliMissingCard,
    compactNarrativeProcessRuns,
    // 112c: 回合活动状态机。本文件全篇零 import(vm 直跑的 unit 会编译失败),故与其它协作者一样走 deps 注入。
    createTurnActivity = null,
    describeTurnActivity = null,
    currentEngineMeta,
    currentWorkspace,
    el,
    engineLabel,
    errorCard,
    activeTurnUserIsPersisted = () => false,
    emitSessionStream = () => {},
    fmtTokens,
    handleAgentWorkflowEvent,
    handlePermissionRequest,
    handlePlanEvent,
    // 回合停止 / 失败收尾:把本回合壳里还没决定的计划卡标成已失效(tool-runtime.js);缺省空实现(vm 直跑的单测不注入)。
    expirePendingPlanCards = () => 0,
    // 事件流里看到 plan_decision(含超时自动拒绝、重放):把对应计划卡就地收起成已决(tool-runtime.js);缺省空实现。
    resolvePlanIntervention = () => false,
    humanizeToolName,
    highlightIn,
    iconTextBtn,
    isProviderMode,
    isUntitledTitle,
    latestUsage,
    loadAutonomyGrants,
    maybeScrollToBottom,
    messageShell,
    msgActions,
    narrativeQuestionCard,
    narrativeSemanticCard,
    narrativeToolAnchor,
    newSession,
    sessionSelectionSeq = () => 0,
    openModal,
    pushRawEvent,
    refreshSessions,
    refreshToolPane = () => {},
    renderAttachments,
    messageAttachmentStrip = () => null,
    // F13:发送出去后释放托盘缩略图的 blob URL(组合根注入;缺省空实现)。
    revokeAttachmentPreview = () => {},
    renderAutonomyBar,
    renderContextMeter,
    renderCurrentSession,
    renderGitDiffInto,
    renderMarkdown,
    renderMissionBar,
    // 109b: 工具产出图内联缩略图,tool_result 到达后与 renderGitDiffInto 同一趟补渲染(见下方 case 'tool_result')。
    renderToolImageInto = () => {}, renderToolResultInto = null, // N11: renderToolResultInto = 结果框富渲染(多行文本块/截图缩略图),缺省退回整份 JSON 文本
    // 125-P2:缓存徽标。与上面那两个补渲染同一个模具 —— 摘要行的徽标位在 tool_use 阶段是空的,
    // 结果到达才知道这次是不是回落了缓存。
    renderStaleBadgeInto = () => {},
    renderResumeBanner,
    renderSessions,
    renderStaticMessage,
    renderStepBar, paintSessionMeta = () => {},   // 走查 #12:线程头下那一行(util.js 注入)
    safeStringify,
    scrollMessagesToBottom,
    settleLiveThinking,
    showAskUserModal,
    // 135:事件流里看到结果(permission_decision / question_answer)就把队列里那一条撤掉。
    settlePrompt = () => {},
    state,
    suggestMemoryFromTurn = async () => {},
    syncContextWindowManual = async () => {},
    switchSettingsTab,
    t,
    thinkingPanel,
    toast,
    toolCard,
    toolArgSummary,
    toolGroupSummaryText,
    turnSummaryCard,
    turnToolIndexCard,
    updateContextMeter,
    updateJumpLatest,
    usageLine,
    wbNativeClaudeFinalize,
    wbNativeClaudeOnSubagent,
    wrapPreWithCopy,
  } = deps;

  /* ---------------- streaming turn ---------------- */
  // One live stream per session. Switching sessions only changes which entry drives the composer; it never
  // aborts another session's request. Streams for background sessions keep draining so the server connection
  // stays alive, and their final persisted message appears when that session is opened again.
  const activeTurns = new Map(); // sessionId -> { abort, startedAt, eventLines, eventChars, live, main }
  let replayingStream = false;   // mountActiveTurn 重放事件期间为真:handleStreamLine 里的一次性副作用据此跳过
  // 重放期间「正在重放的那一行事件【最初到达】的时刻」(rememberTurnLine 记的 eventTimes;0 = 没有)。
  // 工具卡的耗时靠它算:重放是一口气回放的,performance.now() 的差恒为 ~0,修前切回来的已完成工具全显「· 0.0s」。
  let replayEventAt = 0;
  function notifySessionStream(event) {
    try { emitSessionStream(event); } catch { /* Preview observer is best-effort and never owns execution */ }
  }
  // One-shot preference for the next ordinary user message. It is intentionally not persisted in a
  // session or localStorage: sending the message consumes the preference and immediately resets the UI.
  let agentTeamTurnEnabled = false;
  function agentTeamAvailable() {
    return Number(state.config && state.config.subagentMaxPerTurn) > 0;
  }
  function updateAgentTeamButton() {
    const btn = $('agentTeamBtn');
    if (!btn) return;
    const available = agentTeamAvailable();
    if (!available) agentTeamTurnEnabled = false;
    btn.disabled = Boolean(state.streaming) || !available;
    btn.setAttribute('aria-pressed', agentTeamTurnEnabled ? 'true' : 'false');
    btn.title = available
      ? t(agentTeamTurnEnabled ? 'composer.agentTeam.activeTitle' : 'composer.agentTeam.title')
      : t('composer.agentTeam.unavailableTitle');
    btn.setAttribute('aria-label', t('composer.agentTeam.label'));
    iconTextBtn(btn, 'agents', t(agentTeamTurnEnabled ? 'composer.agentTeam.active' : 'composer.agentTeam.label'));
  }
  function toggleAgentTeamTurn() {
    if (!agentTeamAvailable() || state.streaming) return;
    agentTeamTurnEnabled = !agentTeamTurnEnabled;
    updateAgentTeamButton();
  }
  const ACTIVE_TURN_EVENT_CAP = 2_000_000;
  // Re-parsing an ever-growing Markdown document on every token is O(n^2) and eventually monopolizes the UI
  // thread. Stream as incremental plain text, then perform one bounded Markdown pass when the turn settles.
  const MARKDOWN_SYNC_MAX_CHARS = 48_000;
  function attachLiveTextNode(live, bubble) {
    bubble.textContent = '';
    bubble.classList.add('live-plain');
    live.bubble = bubble;
    live.textNode = document.createTextNode('');
    live.renderedChars = 0;
    bubble.appendChild(live.textNode);
  }
  // perf(长回复):流式期间正文是 .live-plain 里的一个文本节点,每帧追加都让整段重新断行排版(4 万字时每帧 5 ms 以上,
  // 且随长度增长,maybeScrollToBottom 那一次读布局全数付清)。尾巴攒到 LIVE_TEXT_CHUNK_CHARS 且里面有换行时,把最后一个
  // 换行(含)之前的部分封进一个块级 div、插在尾巴前面 —— 之后每帧只重排尾巴那一小块。换行符留在前一块末尾:块尾单个换行
  // 不多出空行(实测各种换行组合高度逐像素相同),textContent 与单节点逐字相同。一整段没有换行时不切(与修前一样)。
  // 思维链面板(.think-body)同理:scheduleLiveThinkingFollow 每帧读 scrollHeight,15 万字时布局 2.4 s。
  // 用户正在尾巴里选字(双击 / 拖选)时不切 —— 挪走文本会把选区清掉;松手之后下一帧照常切(审查轮复现过)。
  const LIVE_TEXT_CHUNK_CHARS = 1500;
  function sealTextTailChunk(node) {
    const host = node && node.parentNode;
    if (!host || node.length < LIVE_TEXT_CHUNK_CHARS) return;
    const sel = typeof document.getSelection === 'function' ? document.getSelection() : null;
    if (sel && sel.rangeCount && !sel.isCollapsed && (host.contains(sel.anchorNode) || host.contains(sel.focusNode))) return;
    const cut = node.data.lastIndexOf('\n');
    if (cut < 0) return;
    const chunk = document.createElement('div');
    chunk.className = 'live-chunk';
    chunk.textContent = node.data.slice(0, cut + 1);
    node.deleteData(0, cut + 1);
    host.insertBefore(chunk, node);
  }
  function sealLiveTextChunk(live) { if (live.bubble) sealTextTailChunk(live.textNode); }
  function startLiveTextSegment(live) {
    if (!live || !live.narrative) return null;
    compactNarrativeProcessRuns(live.narrative);
    live.completedRun = [];
    live.completedGroup = null;
    const bubble = el('div', 'bubble md stream-cursor');
    live.bufferText = '';
    attachLiveTextNode(live, bubble);
    live.narrative.appendChild(bubble);
    return bubble;
  }
  function ensureLiveTextSegment(live) {
    return live && live.bubble && live.bubble.isConnected ? live.bubble : startLiveTextSegment(live);
  }
  function sealLiveTextSegment(live, dropIfText) {
    if (!live || !live.bubble) return;
    if (live.rafId) { cancelAnimationFrame(live.rafId); live.rafId = 0; }
    live.rafPending = false;
    const bubble = live.bubble;
    const text = String(live.bufferText || '');
    const drop = dropIfText != null && text.trim() === String(dropIfText || '').trim();
    bubble.classList.remove('stream-cursor', 'live-plain');
    if (!text || drop) bubble.remove();
    else if (text.length <= MARKDOWN_SYNC_MAX_CHARS) {
      bubble.classList.remove('plain'); bubble.innerHTML = renderMarkdown(text); highlightIn(bubble);
    } else { bubble.classList.add('plain'); bubble.textContent = text; }
    live.bubble = null; live.textNode = null; live.bufferText = ''; live.renderedChars = 0;
  }
  function registerNarrativeTool(live, evt, card) {
    if (!live || !card) return;
    sealLiveTextSegment(live);
    const anchorId = narrativeToolAnchor(evt.id, state.currentSession && state.currentSession.turnSeq);
    if (anchorId !== 'turn-tool-') card.d.id = anchorId;
    live.narrative.appendChild(card.d);
    const batchId = String(evt.batchId || `single-${evt.id || live.toolIndex.length}`);
    let batch = live.toolBatches.get(batchId);
    if (!batch) { batch = { id: batchId, items: [], group: null }; live.toolBatches.set(batchId, batch); }
    const item = { id: evt.id, card: card.d, done: false, error: false, status: 'running', anchorId, tc: { id: evt.id, name: evt.name, input: evt.input } };
    batch.items.push(item); live.toolIndex.push(item);
    if (batch.group) {
      batch.group._tgBody.appendChild(card.d);
      batch.group._tgLabel.textContent = toolGroupSummaryText(batch.items.length);
    }
  }
  function settleNarrativeTool(live, id, isError) {
    if (!live) return;
    let owner = null, item = null;
    for (const batch of live.toolBatches.values()) {
      item = batch.items.find(candidate => String(candidate.id) === String(id));
      if (item) { owner = batch; break; }
    }
    if (!owner || !item) return;
    item.done = true; item.error = Boolean(isError); item.status = isError ? 'error' : 'done';
    if (owner.items.length < 2) {
      if (item.error) { live.completedRun = []; live.completedGroup = null; return; }
      if (!Array.isArray(live.completedRun)) live.completedRun = [];
      live.completedRun.push(item);
      if (live.completedRun.length === 2) {
        const group = el('details', 'tool-group narrative-tool-batch narrative-completed-run');
        const sum = el('summary', 'tool-group-sum');
        sum.append(el('span', 'tg-caret', '▸'), el('span', 'tg-label', toolGroupSummaryText(live.completedRun.length)));
        const body = el('div', 'tool-group-body');
        group.append(sum, body);
        live.completedRun[0].card.before(group);
        for (const entry of live.completedRun) body.appendChild(entry.card);
        group._tgBody = body; group._tgLabel = sum.querySelector('.tg-label');
        live.completedGroup = group;
      } else if (live.completedRun.length > 2 && live.completedGroup) {
        live.completedGroup._tgBody.appendChild(item.card);
        live.completedGroup._tgLabel.textContent = toolGroupSummaryText(live.completedRun.length);
      }
      return;
    }
    live.completedRun = []; live.completedGroup = null;
    // A parallel Claude/provider batch remains as individual rows while any member is still running. Folding
    // only after the whole batch settles keeps the current action visible instead of hiding it mid-flight.
    if (!owner.items.every(entry => entry.done)) return;
    if (!owner.group) {
      const first = owner.items[0].card;
      const group = el('details', 'tool-group narrative-tool-batch');
      const sum = el('summary', 'tool-group-sum');
      sum.append(el('span', 'tg-caret', '▸'), el('span', 'tg-label', toolGroupSummaryText(owner.items.length)));
      const body = el('div', 'tool-group-body');
      group.append(sum, body); group._tgBody = body; group._tgLabel = sum.querySelector('.tg-label');
      first.before(group);
      for (const entry of owner.items) body.appendChild(entry.card);
      owner.group = group;
    }
    owner.group._tgLabel.textContent = toolGroupSummaryText(owner.items.length);
  }
  function createLiveAssistantShell() {
    const box = $('messages');
    const { row, main } = messageShell('assistant', new Date().toISOString(), currentEngineMeta());
    const live = { thinkingText: '', thinkingActive: false, bufferText: '', thinkingEl: null, thinkingNode: null, bubble: null, textNode: null, renderedChars: 0, toolCards: new Map(), toolBatches: new Map(), toolIndex: [], subCards: new Map(), workflowCards: new Map(), semanticCards: new Map(), semanticData: new Map(), completedRun: [], completedGroup: null, rendered: false, rafPending: false, rafId: 0, thinkingFollowTimer: 0, followThinkingPanel: false };
    live.narrative = el('div', 'turn-narrative');
    main.appendChild(live.narrative);
    live.toolsWrap = live.narrative; // compatibility host for sub-agent/workflow cards
    startLiveTextSegment(live);
    box.appendChild(row); scrollMessagesToBottom(); // EC-D 57: 新 turn 开始 -> 恢复跟随最新
    return { live, main };
  }
  // 旧实时壳让位前的收尾:只停它身上的计时器与 rAF,不动 DOM(它已不在屏上)。
  // 否则每张还在跑的工具卡的 1s 秒表会在脱离文档的节点上一直走到页面关闭。
  function disposeLive(live) {
    if (!live) return;
    for (const card of (live.toolCards || new Map()).values()) {
      if (card && card.durationTimer) { clearInterval(card.durationTimer); card.durationTimer = 0; }
    }
    if (live.rafId) { cancelAnimationFrame(live.rafId); live.rafId = 0; }
    live.rafPending = false;
    if (live.thinkingRafId) { cancelAnimationFrame(live.thinkingRafId); live.thinkingRafId = 0; }
  }
  function rememberTurnLine(turn, line) {
    if (!turn || !line || !line.trim()) return;
    if (line.includes('"session"')) {
      try { const frame = JSON.parse(line); if (frame.type === 'session') turn.execution = frame.execution; } catch { /* invalid frame has no authority */ }
    }
    // raw_line is already available in the debug stream and can be extremely large; the visible
    // progress replay only needs normalized events.
    // 只有提到 "raw_line" 的行才值得整行解析去认它(大块 tool_result 行不再为这一问多 parse 一遍);
    // 其余行即使不是合法 JSON 也无妨 —— 重放时解析失败的行本就跳过。
    if (line.includes('"raw_line"')) { try { if (JSON.parse(line).type === 'raw_line') return; } catch { return; } }
    // eventTimes 与 eventLines 逐下标对齐(到达时刻,重放时给工具卡算真实耗时);老形状的 turn 没有它就按 0 补齐。
    if (!Array.isArray(turn.eventTimes)) turn.eventTimes = new Array(turn.eventLines.length).fill(0);
    turn.eventLines.push(line); turn.eventTimes.push(Date.now()); turn.eventChars += line.length;
    turn.eventHead = Number(turn.eventHead) || 0;
    while (turn.eventChars > ACTIVE_TURN_EVENT_CAP && turn.eventLines.length - turn.eventHead > 1) {
      turn.eventChars -= turn.eventLines[turn.eventHead++].length;
    }
    // Array.shift() moved the entire replay log on every post-cap delta. A logical head makes eviction O(1);
    // compact only occasionally so a multi-megabyte stream never creates an input/scroll freeze.
    if (turn.eventHead > 2048 && turn.eventHead * 2 >= turn.eventLines.length) {
      turn.eventLines = turn.eventLines.slice(turn.eventHead);
      turn.eventTimes = turn.eventTimes.slice(turn.eventHead);
      turn.eventHead = 0;
    }
  }
  const BACKGROUND_PROMPT_EVENT_RE = /"(?:ask_user|permission_request|permission_decision|question_answer)"/;
  function surfaceBackgroundQuestion(line, sessionId) {
    if (!BACKGROUND_PROMPT_EVENT_RE.test(line)) return; // 后台回合的每一行都过这里:不是这四类就不整行解析
    let evt; try { evt = JSON.parse(line); } catch { return; }
    if (evt?.type === 'ask_user') showAskUserModal(evt.questionId || evt.id, evt.questions, sessionId, evt.context || '', Number(evt.deadlineAt) || 0);
    // 135:后台线程的权限申请修前只能等你切过去、或在 120 s 后被自动拒绝;现在同样进「等你处理」队列。
    else if (evt?.type === 'permission_request') handlePermissionRequest(evt, sessionId);
    else if (evt?.type === 'permission_decision') settlePrompt(evt.requestId);
    else if (evt?.type === 'question_answer') settlePrompt(evt.questionId || evt.id);
  }
  function mountActiveTurn(sessionId) {
    const turn = activeTurns.get(sessionId);
    if (!turn || state.currentSession?.id !== sessionId) return;
    // 124（用户 2026-09-14 走查③「从管家线切回工作台，同一个回合出现两张 AI 输出框」）：
    // 这一只壳【只属于这个回合】。组合根的 openSession 是「先 renderCurrentSession() 再
    // mountActiveTurn(id)」，而 renderCurrentSession 会把已经挂在屏上的那一只实时壳原样 append 回来
    // （它头上的 `activeRow.isConnected` 那两行）；切视角走的正是「在工作台打开」= applyShellMode +
    // openSession(同一条会话)，于是这里又造一只【新壳】并按 eventLines 全量重放：旧壳从此不再收到
    // 增量、冻在切走那一刻的次数上，新壳按切回来的时刻重新打时间戳、把这一回合重画一遍 —— 屏幕上就
    // 是同一个回合两张卡（实测截图里那两张：10 次工具·3 段思考 与 17 次工具·6 段思考）。
    // 壳还在屏上就什么都不做：真正的「重建」只发生在它不在屏上时（换回来的是另一条会话、或整块被
    // 重画掉了），那一条路下面全量重放的逻辑一个字没动。
    if (turn.main?.isConnected || turn.live?.narrative?.isConnected) return;
    const box = $('messages');
    box.querySelector('.empty-state')?.remove();
    const persistedUser = activeTurnUserIsPersisted(state.currentSession?.messages, turn);
    if (turn.optimisticUserRow && !turn.optimisticUserRow.isConnected && !persistedUser) box.appendChild(turn.optimisticUserRow);
    disposeLive(turn.live);
    const shell = createLiveAssistantShell(); turn.live = shell.live; turn.main = shell.main;
    // 112c: 回到一个仍在跑的后台会话 —— 事件全量重放,状态机也从零重建,否则状态条会显示切走之前的旧阶段。
    if (turnActivity) { turnActivity.reset(); turnActivity.start(turn.startedAt); activityBoundSession = sessionId; }
    // Coalesce tiny deltas while preserving tool/workflow boundaries. Keep this shell live: finalizing it here
    // detaches its text node, so subsequent deltas otherwise remain invisible until the terminal full reload.
    let textParts = [], thinkingParts = [];
    const flush = () => {
      if (thinkingParts.length) { handleStreamLine(JSON.stringify({ type: 'thinking_delta', text: thinkingParts.join('') }), turn.live, turn.main, sessionId); thinkingParts = []; }
      if (textParts.length) { handleStreamLine(JSON.stringify({ type: 'assistant_delta', text: textParts.join('') }), turn.live, turn.main, sessionId); textParts = []; }
    };
    // 135:重放按时间顺序走,已经有结果的申请会先入队(弹一下)再被结果撤掉。先把有结果的记成已决,重放时就不入队。
    for (let index = Number(turn.eventHead) || 0; index < turn.eventLines.length; index++) {
      const line = turn.eventLines[index];
      if (!line.includes('"permission_decision"') && !line.includes('"question_answer"')) continue;
      let evt; try { evt = JSON.parse(line); } catch { continue; }
      if (evt.type === 'permission_decision') settlePrompt(evt.requestId);
      else if (evt.type === 'question_answer') settlePrompt(evt.questionId || evt.id);
    }
    // 重放只重建画面:toast、调试面板追加、授权刷新这类「一次性副作用」在第一次到达时已经发生过,不再重来
    // (修前每切回一次就再弹一遍「已切换备用服务商」「权限已暂停」、调试面板再追加一份 meta/stderr)。
    replayingStream = true;
    try {
      for (let index = Number(turn.eventHead) || 0; index < turn.eventLines.length; index++) {
        const line = turn.eventLines[index];
        let evt; try { evt = JSON.parse(line); } catch { continue; }
        if (evt.type === 'session') continue;
        replayEventAt = Number(turn.eventTimes && turn.eventTimes[index]) || 0;
        if (evt.type === 'ask_user' && turn.answeredQuestions?.has(String(evt.questionId || evt.id || ''))) continue;
        if (evt.type === 'assistant_delta') { if (thinkingParts.length) flush(); textParts.push(evt.text || ''); continue; }
        if (evt.type === 'thinking_delta') { if (textParts.length) flush(); thinkingParts.push(evt.text || ''); continue; }
        flush(); handleStreamLine(line, turn.live, turn.main, sessionId);
      }
      flush();
    } finally { replayingStream = false; replayEventAt = 0; }
  }
  // The proc-dot moved into the model chip (.mc-dot) in v0.7b. setProc now drives that dot's three
  // states (running/stopped/idle) + an engine-aware title, reusing the pulse animation via CSS.
  function setProc(state_) {
    const dot = document.querySelector('#modelChip .mc-dot');
    if (!dot) return;
    dot.className = 'mc-dot' + (state_ ? ` ${state_}` : ' idle');
    dot.title = t('status.processState', { engine: engineLabel(), state: state_ || 'idle' });
  }
  // Send⇄Stop same-position toggle (§4.3). While streaming, #sendBtn becomes "■ 停止" (danger) wired to
  // stopTurn; otherwise it is "发送 ▷" (primary) wired to sendPrompt. The old topbar #stopBtn is gone.
  // 50-fix(三态):流式中按钮按输入内容分态 —— 输入框【有文本】→「插话」(sendPrompt 路由 /api/steer,不打扰
  // 当前回合);【空输入】→「■ 停止」(stopTurn)。旧行为流式中恒为停止,插话只剩 Enter 一条隐藏路径,
  // 用户"输入后还是停止,不会变成 Steer"(ChatGPT 同款三态:generating + typing → send)。
  // 117s-G(27 号文 §11.13.1 ②;真浏览器复现的丢回合 bug)————————————————————————
  // activeTurns 里只有【本页自己起的那条流】。管家经 stewardLaunchTurn 在服务端起的回合没有任何
  // 客户端挂在它的流上,于是「2.0 视窗」里的经典壳把一条正在跑的线程当成空闲:发送门放行 → 新回合 →
  // 09:1347 的 `activeChildren.has -> stopSession('superseded')` 把跑着的回合就地杀掉,几分钟的工作
  // 连同它的正文一起没了,界面零提示。修法不新造判据:服务端 13h stewardRelayChannelFor(全仓递话
  // 唯一那处阶梯 answer > permission > queued > steer > turn)把结论随会话信封下发,前端只读结论。
  function sessionRelayChannel(sessionId) {
    const relay = state.sessionRelay;
    if (!sessionId || !relay || relay.sessionId !== sessionId) return '';
    return String(relay.channel || '');
  }
  // 「此刻有一个回合在跑,这句话该当插话递进去」。两个来源同一个答案:本页自己的流(activeTurns,
  // 既有语义一字不动),或服务端说别处起的回合在跑。
  // 'answer'(它挂在 request_user_input 上等回答)也走插话:经典壳的回答面是 ask_user 事件弹出的那张
  // 模态框,而别处起的回合根本不往这条连接上发事件,壳里没有第二条能安全递进去的通路;插话至少
  // 不丢数据、不杀回合(服务端 13h 的 relayDeliver 有真正的 answer 通道,那是管家壳的面)。
  function sessionAcceptsSteer(sessionId) {
    if (!sessionId) return false;
    if (activeTurns.has(sessionId)) return true;
    const channel = sessionRelayChannel(sessionId);
    return channel === 'steer' || channel === 'answer';
  }
  // 排队中 / 等批准:这句话【不能】变成一个新回合(前者会让排队项与新回合前后脚放行、互相 supersede,
  // 后者等于绕过一个正等着用户点头的动作),壳里也没有别的通路能把它递进去 —— 诚实地退回来。
  function relayBlockNote(sessionId) {
    const channel = sessionRelayChannel(sessionId);
    if (channel === 'queued') return t('chat.relayQueued');
    if (channel === 'permission') return t('chat.relayPermission');
    return '';
  }
  function updateSendBtn() {
    const btn = $('sendBtn');
    if (!btn) return;
    const streaming = Boolean(state.streaming);
    const hasText = !!(($('promptInput')?.value || '').trim()) || (state.attachments || []).length > 0;
    const steerCapability = activeTurnSteerCapability();
    // 117s-G:按钮与发送门读【同一个】判据 —— 「它正在跑(这一回合是在别处起的)」那张卡在屏上时,
    // 按钮就该写「插话」,而不是写「发送」骗用户去杀掉那个回合。
    const sid = state.currentSession?.id || '';
    const live = streaming || sessionAcceptsSteer(sid) || (state.sessionRelay?.sessionId === sid && state.sessionRelay.live === true);
    const steer = live && hasText && steerCapability.ok;
    const blockedSteer = live && hasText && !steerCapability.ok;
    let delivery = $('steerDeliveryMode');
    if (!delivery) {
      delivery = el('select', 'steer-delivery-mode');
      delivery.id = 'steerDeliveryMode';
      for (const mode of ['queue', 'interrupt']) {
        const option = document.createElement('option');
        option.value = mode;
        delivery.appendChild(option);
      }
      btn.before(delivery);
    }
    // U14 走查：这枚 select 只建一次(上面那段),它的 aria-label 与两个 option 文案如果也焊在
    // 「只建一次」那个分支里，赶上还没等到 setLocale(en-US) 落定就先建好的那一拍(冷启动/开局
    // 就是 en-US 的场景最容易撞上)，就会一直停在建它那一刻的语言 —— updateSendBtn() 本来每次
    // 输入/切换时都会跑，这里挪出来跟着一起刷新，零额外监听就治好。typeof 兜底：foreign-turn-composer
    // 那份单测用一个不含 setAttribute/options 的极简桩子占位 $('steerDeliveryMode')（它测的是
    // 别的事，不关心这枚 select），生产环境里 el() 建出来的永远是真元素。
    if (typeof delivery.setAttribute === 'function') delivery.setAttribute('aria-label', t('chat.steerDelivery'));
    if (delivery.options) for (const option of delivery.options) option.textContent = t('chat.steerDelivery.' + option.value);
    const engine = activeTurns.get(state.currentSession?.id)?.engine || (isProviderMode() ? 'openai' : 'claude');
    delivery.hidden = !steer || engine !== 'openai';
    if (!steer) delivery.value = 'queue';
    btn.classList.toggle('danger', live && !steer && !blockedSteer);
    btn.classList.toggle('primary', !live || steer);
    if (steer) { iconTextBtn(btn, 'send', t('chat.steer')); btn.onclick = () => sendPrompt(); btn.title = t('chat.steerHint'); }
    else if (blockedSteer) { iconTextBtn(btn, 'settings', t('chat.steerEnable')); btn.onclick = showClaudeSteerSetup; btn.title = t('chat.steerEnableHint'); }
    // Every live turn uses the same stop action, regardless of its initiator.
    else if (live) { iconTextBtn(btn, 'stop', t('common.stop')); btn.onclick = stopTurn; btn.title = ''; }
    else { iconTextBtn(btn, 'send', t('chat.send')); btn.onclick = () => sendPrompt(); btn.title = ''; }
  }
  function activeTurnSteerCapability() {
    const sid = state.currentSession?.id || '';
    const turn = sid ? activeTurns.get(sid) : null;
    if (turn && turn.engine === 'claude' && !turn.claudeInteractive) {
      return { ok: false, reason: 'claude_requires_interactive' };
    }
    return { ok: true, reason: '' };
  }
  function showClaudeSteerSetup() {
    toast(t('toast.steerRequiresInteractive'), 'err');
    openModal('settingsModal');
    switchSettingsTab('claude', true);
    setTimeout(() => { const mode = $('cfgEngineMode'); if (mode) { mode.focus(); mode.scrollIntoView({ block: 'center' }); } }, 0);
  }
  function setStreaming(on) {
    state.streaming = on;
    // v3 (§B6): 有活动回合即让上下文电量表现身(不再等 60%,两模式一致);无用量数据时 renderContextMeter 自持隐藏。
    if (on) { try { updateContextMeter(); } catch { /* ignore */ } }
    // v0.9-S5: clear any lingering 「AI 在等你批准计划」 hint when a turn ends (stop/error can bypass the card's
    // own finish()). Set fresh by handlePlanEvent while a plan is pending.
    if (!on) { const h = $('composerHint'); if (h) { h.innerHTML = ''; h.style.display = 'none'; } steerPendingList.length = 0; steeredSeen.length = 0; }
    // v1.0.2 (F3): Claude 模式的 /compact 是流式回合 —— 回合结束(setStreaming(false))即压缩完成,收指示条。
    if (!on && compactState.active) endCompactIndicator();
    updateSendBtn(); // 50-fix:发送/插话/停止 三态(原:流式恒停止)
    updateAgentTeamButton();
    updateJumpLatest();
    updateAgentTeamButton();
  }
  function syncStreamingUi() {
    const sid = state.currentSession?.id || '';
    const on = !!sid && activeTurns.has(sid);
    // 112c: 换会话即清状态条 —— 上一条会话的「正在调用 file_read」绝不能挂在新会话头上。
    // 同会话内不清:回合结束后停在「等你拍板」是有效状态,settle() 已经保留了待决。
    if (turnActivity && sid !== activityBoundSession) {
      activityBoundSession = sid;
      turnActivity.reset();
      renderTurnActivityBar();
    }
    setStreaming(on);
    setProc(on ? 'running' : 'idle');
  }

  // v1.0.2 (F3): 压缩进行中的持续指示。compactState.active 防重入(进行中再点=忽略);indicator 是 composer
  // 上方一条带 spinner 的持续提示条;compactBtn 禁用 + 文案变「压缩中…」;90s 兜底超时恢复防卡死。
  // 流内 compact 'started'(自动 L2 压缩)起的指示条传 { stream: sessionId }:服务端对它必发 completed/failed,
  // 不挂 5 分钟超时(否则长回合里会误报「压缩超时」);改由该回合收尾(end/stop/error)时静默收掉,绝不活过回合。
  // seq 让「谁开的谁收」:异步路径收尾前比对,别把后来别处起的指示条误收。
  const compactState = { active: false, timer: 0, stream: '', seq: 0 };
  function beginCompactIndicator(options = {}) {
    compactState.active = true;
    compactState.seq += 1;
    compactState.stream = options.stream ? String(options.stream) : '';
    const btn = $('compactBtn');
    if (btn) { btn.disabled = true; btn.dataset.label = btn.textContent; btn.textContent = t('chat.compacting'); }
    // 持续指示条:插在 composer 顶部(resumeBanner 之上),复用 chip/toast 令牌,自带 spinner。
    let bar = $('compactIndicator');
    if (!bar) {
      bar = el('div', 'compact-indicator'); bar.id = 'compactIndicator';
      bar.append(el('span', 'compact-spinner'), el('span', '', t('chat.compactHint')));
      const composer = document.querySelector('.composer');
      if (composer) composer.insertBefore(bar, composer.firstChild);
    }
    bar.classList.remove('hidden');
    // External map-reduce can run several sequential local-model calls (a real 65K Ollama chunk takes
    // ~3 minutes on the reference machine). Keep the stale-UI guard, but do not declare failure while
    // the HTTP request is still legitimately reducing a long history.
    clearTimeout(compactState.timer); compactState.timer = 0;
    if (compactState.stream) return compactState.seq;
    const indicatorTimeoutMs = state.config?.compactProviderId ? 30 * 60 * 1000 : 5 * 60 * 1000;
    compactState.timer = setTimeout(() => { if (compactState.active) { endCompactIndicator(); toast(t("toast.compactTimeout"), 'err'); } }, indicatorTimeoutMs);
    return compactState.seq;
  }
  function endCompactIndicator() {
    compactState.active = false;
    compactState.stream = '';
    clearTimeout(compactState.timer); compactState.timer = 0;
    const btn = $('compactBtn');
    if (btn) { btn.disabled = false; if (btn.dataset.label) { btn.textContent = btn.dataset.label; delete btn.dataset.label; } }
    const bar = $('compactIndicator');
    if (bar) bar.classList.add('hidden');
  }

  // ── 112b/112c: 统一活动状态条 ────────────────────────────────────────────────────────────────
  // 一句话回答三问:【在干什么】阶段+当前动作、【干到哪】已运行多久+本回合第几次工具调用、
  // 【在等什么】等你拍板 / 等资源(谁占着)。数据来自 turn-activity.js 状态机,本处只负责画。
  // 只画【当前打开的会话】:后台会话的流照常收,切回来时 mountActiveTurn 会重放全部事件重建状态。
  // 注入缺失(老 composition root / vm 直跑)时整条降级为不存在,不影响任何既有渲染。
  const turnActivity = typeof createTurnActivity === 'function' ? createTurnActivity() : null;
  let activityBarTimer = 0;
  let activityBarFrame = 0;
  let activityBoundSession = '';

  function ensureActivityBar() {
    let bar = $('turnActivityBar');
    if (bar) return bar;
    const composer = document.querySelector('.composer');
    if (!composer) return null;
    bar = el('div', 'turn-activity hidden'); bar.id = 'turnActivityBar';
    bar.setAttribute('role', 'status');
    bar.setAttribute('aria-live', 'polite');
    const dot = el('span', 'ta-dot'); dot.setAttribute('aria-hidden', 'true');
    // head 与 parts 分开成元素:窄屏靠 CSS 丢掉尾部细节,而不是让省略号从句子中间切断
    // (390px 实测:整句会被截成「正在调用工具 · powershell_run · 本次已跑 8s · 本回合已…」)。
    bar.append(dot, el('span', 'ta-text'), el('span', 'ta-parts'), el('span', 'ta-notices'));
    composer.insertBefore(bar, composer.querySelector('.composer-box') || composer.firstChild);
    return bar;
  }

  function renderTurnActivityBar() {
    if (!turnActivity || typeof describeTurnActivity !== 'function') return;
    const snapshot = turnActivity.snapshot();
    const bar = ensureActivityBar();
    if (!bar) return;
    const view = describeTurnActivity(snapshot, t);
    const visible = snapshot.phase !== 'idle' && Boolean(view.text);
    bar.classList.toggle('hidden', !visible);
    if (!visible) {
      // 收起时把文本清掉:留着上一回合的「正在调用 powershell_run」既没意义,也可能被读屏器读到。
      bar.querySelector('.ta-text').textContent = '';
      bar.querySelector('.ta-parts').replaceChildren();
      activityClock(false);
      return;
    }
    bar.dataset.phase = snapshot.phase;
    bar.dataset.severity = view.severity;
    const textEl = bar.querySelector('.ta-text');
    if (textEl && textEl.textContent !== view.head) textEl.textContent = view.head;
    const partsEl = bar.querySelector('.ta-parts');
    if (partsEl && partsEl.dataset.signature !== view.parts.join('|')) {
      partsEl.dataset.signature = view.parts.join('|');
      partsEl.replaceChildren(...view.parts.map(part => el('span', 'ta-part', part)));
    }
    const noticeEl = bar.querySelector('.ta-notices');
    if (noticeEl) {
      const notices = view.notices.slice(-2);
      const signature = notices.map(n => `${n.severity}:${n.text}`).join('|');
      if (noticeEl.dataset.signature !== signature) {
        noticeEl.dataset.signature = signature;
        noticeEl.replaceChildren(...notices.map(n => el('span', `ta-notice ${n.severity}`, n.text)));
      }
    }
    // 只在真的有活动回合时开秒表(每秒重画一行文本,零请求);等你拍板/空闲态不空转。
    activityClock(snapshot.turnActive);
  }

  function activityClock(on) {
    if (!on) { if (activityBarTimer) clearInterval(activityBarTimer); activityBarTimer = 0; return; }
    if (activityBarTimer) return;
    activityBarTimer = setInterval(() => renderTurnActivityBar(), 1000);
  }

  // delta 洪峰下每条事件都重画会浪费一整帧;合到下一帧画一次。
  function scheduleActivityBar() {
    if (!turnActivity || activityBarFrame) return;
    activityBarFrame = requestAnimationFrame(() => { activityBarFrame = 0; renderTurnActivityBar(); });
  }

  // One-click context compaction, engine-aware (§5.2). Claude mode: send the CLI's built-in /compact (a
  // streaming turn — the indicator clears when that turn ends, via setStreaming(false) → endCompactIndicator).
  // Provider mode: POST /api/provider/compact (server makes one non-streaming summary call and collapses
  // providerHistory), then reload the session and show the before/after estimate.
  async function compactContext() {
    if (compactState.active) return; // F3⑥ 进行中再点=忽略
    if (state.streaming) { toast(t("toast.compactWaitTurn"), ''); return; }
    if (!state.currentSession || !(state.currentSession.messages || []).length) { toast(t("toast.compactEmpty"), ''); return; }
    const sid = state.currentSession.id;
    // 117s-G 同一判据:别处起的回合在跑(插话/回答)或排队中/等批准 —— 这时压缩既不能当新回合发
    // (sendPrompt 会把 '/compact' 当插话递进去),也不该去动正在用的上下文。说一句,不开指示条。
    if (sessionAcceptsSteer(sid) || relayBlockNote(sid)) { toast(relayBlockNote(sid) || t("toast.compactWaitTurn"), ''); return; }
    if (!isProviderMode() && agentCliMeta(currentEngineMeta().agentCliType).nativeCompact === 'slash-command' && !state.config?.compactProviderId) {
      // Claude 模式:/compact 是流式回合。开指示,sendPrompt 走完流后 setStreaming(false) 会调 endCompactIndicator。
      // sendPrompt 也可能根本没起回合就返回(同步窗口失败、await 期间被判成插话/排队)——那时 setStreaming 不会再来收,
      // 这里兜底:本次开的指示条还挂着就收掉。
      const seq = beginCompactIndicator();
      toast(t("toast.compactRequested"), 'ok');
      Promise.resolve(sendPrompt('/compact')).catch(() => {}).finally(() => {
        if (compactState.active && compactState.seq === seq) endCompactIndicator();
      });
      return;
    }
    beginCompactIndicator();
    try {
      const endpoint = isProviderMode() ? '/api/provider/compact' : '/api/agent/compact';
      const r = await api(endpoint, { method: 'POST', body: JSON.stringify({ sessionId: sid }) });
      if (!r || !r.ok) { toast(t("toast.compactFail", { p1: apiErrText(r && r.error) || t('common.unknownError') }), 'err'); return; }
      if (state.currentSession?.id === sid) {
        const s = await api(`/api/sessions/${sid}`);
        // await 期间可能已切走:再判一次,别用被压缩那条覆盖当前打开的会话。
        if (state.currentSession?.id === sid) { state.currentSession = s.session; renderCurrentSession(); }
      }
      await refreshSessions();
      toast(r.level === 0 ? t("toast.compactNothingSince", { p1: fmtTokens(r.freshTokens || 0), p2: fmtTokens(r.beforeTokens || 0) }) : t(r.level === 1 ? "toast.compactL1Done" : "toast.compactDone", { p1: fmtTokens(r.beforeTokens || 0), p2: fmtTokens(r.afterTokens || 0) }), r.level === 0 ? '' : 'ok'); // level 1 = 只做了免费的 L1(没调摘要);level 0 = 已摘要过、之后新增太少,没压也没调模型
    } catch (e) { toast(t("toast.compactFail", { p1: apiErrText(e) }), 'err'); }
    finally { endCompactIndicator(); }
  }

  // 「发送前置阶段」标志:从核对上下文窗口到会话就绪(必要时 newSession)这一串 await 期间为真。
  // 修前空会话里对同一句连按两下 Enter:第一下的 newSession() 还在 await,输入框没清、发送没禁,第二下又走一遍
  // —— 建出两个会话、把同一句话发两遍。前置阶段在飞时再进来的发送直接丢掉(话还在输入框里,第一下已经在发了)。
  // 前置阶段【之后】到 activeTurns.set 之间没有 await,所以标志只管这一段;回合开始后再按 Enter 走插话那条路。
  let sendPreflight = false;
  // 鼠标点「发送」后焦点留在这枚按钮上,而 updateSendBtn 随后把同一枚按钮换成「停止」:接着按空格/回车就把回合停了。
  // 清空输入框之后把焦点还给输入框(只在焦点确实停在发送钮上时才动)。
  function releaseSendBtnFocus() {
    const btn = $('sendBtn');
    if (btn && document.activeElement === btn) { const input = $('promptInput'); if (input && typeof input.focus === 'function') input.focus(); }
  }
  function clearSentComposerDraft(value, text) {
    const input = $('promptInput');
    input.dispatchEvent(new CustomEvent('ruyi:composer-sent', { bubbles: true, detail: { text } }));
    if (input.value !== value) return; // 发送事件仍带原话，请求在飞时用户继续写的草稿仍留在框里。
    input.value = ''; autoGrow(input); releaseSendBtnFocus();
    try { localStorage.removeItem('wcw.draft'); } catch { /* ignore */ }
  }
  async function sendPrompt(overrideText, options = {}) {
    // v0.8-S7 steering (§4 A3) + 47a 双引擎:任何引擎回合流式中,composer 的发送都变为插话路由到 /api/steer。
    // provider 经队列在下一边界注入;Claude(interactive)经 stdin 即时注入;Claude print 模式由服务器返回
    // 人话错误(print 不支持),toast 呈现——前端不再按引擎静默吞掉输入。
    // 117s-G:判据从 activeTurns(只有本页自己起的流)换成 sessionAcceptsSteer(本页的流 ∪ 服务端说
    // 别处起的回合在跑)。修前管家起的回合在这里判成空闲,一路走到 09:1347 被 supersede 杀掉。
    const selectedId = state.currentSession?.id || '';
    const selectedSeq = sessionSelectionSeq();
    if (selectedId && !options.skipSteer && sessionAcceptsSteer(selectedId)) return steerPrompt(overrideText, options);
    // F13:托盘里还有附件在上传 —— 这一条会漏掉它们、附件反而挂到下一条消息上。话留在框里,等上传完再发。
    // (交办台经 options.attachments 显式给附件,不经托盘,不受这道门管。)
    if (!Array.isArray(options.attachments) && Number(state.uploading) > 0) { toast(t('toast.uploadInProgress'), ''); return; }
    const composerDraft = overrideText == null ? $('promptInput').value : options.composerDraft;
    const message = (overrideText != null ? overrideText : composerDraft).trim();
    const hasAttachments = Array.isArray(options.attachments) ? options.attachments.length > 0 : state.attachments.length > 0;
    if (!message && !hasAttachments) return;
    // 117s-G:排队中 / 等批准 —— 不发,给一句人话。放在空输入那道门之后:空输入本来就不该弹提示。
    const relayBlocked = relayBlockNote(selectedId);
    if (relayBlocked) { toast(relayBlocked, ''); return; }
    if (sendPreflight) return;
    sendPreflight = true;
    try {
      // Migrate a browser-only manual window before the server decides whether this turn needs compacting.
      // On failure preserve the draft/attachments and do not send with a different context limit.
      try { await syncContextWindowManual(); }
      catch (e) { toast(apiErrText(e), 'err'); return; }
      // await 期间换了会话:这句话是对着原来那条会话打的,不能发进新打开的这条。不发、不清输入框,由用户决定。
      if (sessionSelectionSeq() !== selectedSeq || (state.currentSession?.id || '') !== selectedId) return;
      // 117s-G:await 之后再判一次(同上,判据同一个)—— syncContextWindowManual 期间回合可能刚起来。
      if (state.currentSession?.id && !options.skipSteer && sessionAcceptsSteer(state.currentSession.id)) return steerPrompt(message, { ...options, composerDraft });
      if (!state.currentSession) {
        const created = await newSession();
        if (!created || state.currentSession?.id !== created.id) return;
      }
    } finally { sendPreflight = false; }

    const turnSessionId = state.currentSession.id;
    // Slash-command/override turns (for example /compact) must neither consume nor inherit the visible toggle.
    const agentTeam = composerDraft != null && agentTeamTurnEnabled && agentTeamAvailable();
    if (agentTeam) { agentTeamTurnEnabled = false; updateAgentTeamButton(); }
    if (composerDraft != null) clearSentComposerDraft(composerDraft, message);

    const box = $('messages');
    box.querySelector('.empty-state')?.remove();
    // Capture & clear attachments now so a failed/aborted turn doesn't silently re-send them.
    // 第96波(P4):交办台(Pretender)经 options.attachments 显式注入附件 —— 不经经典托盘,
    // 也不清空/重绘经典托盘(预览壳下它根本未挂载)。
    const sentAttachments = Array.isArray(options.attachments) ? options.attachments.slice() : state.attachments;
    if (!Array.isArray(options.attachments)) { for (const a of sentAttachments) revokeAttachmentPreview(a); state.attachments = []; renderAttachments(); }
    else if (Array.isArray(options.composerAttachments)) {
      for (const a of options.composerAttachments) revokeAttachmentPreview(a);
      state.attachments = state.attachments.filter(a => !options.composerAttachments.includes(a)); renderAttachments();
    }
    // 第69波:留住乐观 user 行的引用 —— 它是合成对象(无 turnSeq、不在 session.messages),其操作条里的
    // 「回溯到此处」必然 toast「无法定位该消息的回合」;回合拿到持久化真身后必须重绑(见下方 finally 前)。
    const optimisticUserRow = renderStaticMessage({ role: 'user', content: message, createdAt: new Date().toISOString(), attachments: sentAttachments });
    box.appendChild(optimisticUserRow);
    // 把乐观行的操作条重绑到持久化的真实 user 消息(按文本自尾向前匹配,跳过 steered)。
    // 成功路径直接用回合末已重取的 session;失败/中止路径单独拉一次。重绑失败无碍 —— 下次全量重渲染自然换真行。
    const rebindOptimisticUserRow = sess => {
      try {
        if (!optimisticUserRow.isConnected || !sess) return;
        const msgs = Array.isArray(sess.messages) ? sess.messages : [];
        let real = null;
        for (let i = msgs.length - 1; i >= 0; i--) {
          const m = msgs[i];
          if (m && m.role === 'user' && !m.steered && String(m.content || '') === String(message || '')) { real = m; break; }
        }
        if (!real) return;
        const bar = optimisticUserRow.querySelector('.msg-actions');
        if (bar) bar.replaceWith(msgActions(real));
      } catch { /* best-effort */ }
    };

    // Live assistant container — tag it with the current engine so its badge/avatar match the engine
    // producing this reply (the server sends the authoritative meta on the persisted message).
    const shell = createLiveAssistantShell();
    let live = shell.live, main = shell.main;

    const turnAbort = new AbortController();
    const turnEngine = isProviderMode() ? 'openai' : 'claude';
    const turnMeta = currentEngineMeta();
    const turnState = { abort: turnAbort, startedAt: Date.now(), initialTurnSeq: Number(state.currentSession?.turnSeq) || 0, message, optimisticUserRow, eventLines: [], eventHead: 0, eventChars: 0, answeredQuestions: new Set(), live, main,
      engine: turnEngine, agentCliType: agentCliMeta(turnMeta.agentCliType).id,
      claudeInteractive: turnEngine !== 'claude' || agentCliMeta(turnMeta.agentCliType).alwaysInteractive || state.config.engineMode === 'interactive' };
    // 手上已有前 N 条(服务端给过戳)就告诉服务端,回合起点那条 session 事件只回尾巴;knownPrefix 是拼接用的那一个数组。
    if (state.currentSession?.id === turnSessionId) {
      turnState.knownMessages = knownMessagesFor(state.currentSession);
      if (turnState.knownMessages) turnState.knownPrefix = state.currentSession.messages;
    }
    activeTurns.set(turnSessionId, turnState);
    // 112c: 新回合 = 状态机清零重开(状态条只反映当前打开的会话)。
    if (turnActivity && state.currentSession?.id === turnSessionId) {
      turnActivity.reset(); turnActivity.start(turnState.startedAt); renderTurnActivityBar();
    }
    notifySessionStream({ type: 'start', sessionId: turnSessionId, message, createdAt: new Date().toISOString() });
    syncStreamingUi();
    renderSessions();
    let turnEndedBadly = false;   // 走了 catch(停止 / 断流 / 出错):服务端那头的计划等待已随回合作废,收尾时据此清计划态
    try {
      const res = await fetch('/api/chat/stream', {
        method: 'POST', headers: authHeaders(), signal: turnAbort.signal,
        body: JSON.stringify({
          sessionId: turnSessionId,
          message,
          cwd: currentWorkspace(),
          attachments: sentAttachments,
          agentTeam,
          ...(options.permissionMode ? { permissionMode: options.permissionMode } : {}),
          ...(turnState.knownMessages ? { knownMessages: turnState.knownMessages } : {}),
        }),
      });
      if (!res.ok || !res.body) throw new Error(await res.text());
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const lines = buf.split(/\r?\n/);
        buf = lines.pop() || '';
        // Keep a bounded normalized event log for background replay. Returning to this session while
        // it is still running reconstructs all progress instead of showing only the initial user message.
        for (const line of lines) {
          rememberTurnLine(turnState, line);
          notifySessionStream({ type: 'event', sessionId: turnSessionId, line });
          if (state.currentSession?.id === turnSessionId) {
            live = turnState.live; main = turnState.main;
            handleStreamLine(line, live, main, turnSessionId);
          } else surfaceBackgroundQuestion(line, turnSessionId);
        }
      }
      if (buf.trim()) {
        rememberTurnLine(turnState, buf);
        notifySessionStream({ type: 'event', sessionId: turnSessionId, line: buf });
        if (state.currentSession?.id === turnSessionId) handleStreamLine(buf, turnState.live, turnState.main, turnSessionId);
        else surfaceBackgroundQuestion(buf, turnSessionId);
      }
      finalizeLive(turnState.live);
      await refreshSessions();
      if (state.currentSession?.id === turnSessionId) {
        // perf:手上那份若是回合起点带戳下发的,只取 messages[N..] 拼回去(见文件末 fetchSessionAfterTurn);否则整份取,与修前一致。
        const r = await fetchSessionAfterTurn(api, turnSessionId, state.currentSession);
        // await 期间用户可能已切到别的会话:再判一次,别拿本回合会话覆盖掉刚打开的那条。
        if (state.currentSession?.id === turnSessionId) {
          state.currentSession = r.session; state.resumable = r.resumable || null;
          rebindOptimisticUserRow(r.session); // 第69波:乐观行的「回溯到此处」重绑到持久化真身
          // The live DOM already contains this complete turn. Rebuilding it here parses/highlights the same long
          // answer a second time and causes the characteristic end-of-stream stall.
          $('sessionTitle').textContent = isUntitledTitle(r.session?.title) ? t('session.untitled') : r.session.title.trim();
          paintSessionMeta($('sessionMeta'), r.session);
          renderStepBar(r.session && r.session.todos);
          renderMissionBar(r.session && r.session.mission);
          renderContextMeter(latestUsage(r.session));
          renderResumeBanner();
        }
      }
      // 不阻塞回合解锁：两引擎都可能通过 workbench_memory_propose 提交待确认候选；provider 还会
      // 运行自动审稿。服务端通常静默返回 proposal:null，只有真正的 pending 才追加卡片。
      if (turnState.live && turnState.live.resultOk === true && state.currentSession?.id === turnSessionId) {
        Promise.resolve().then(() => suggestMemoryFromTurn(turnSessionId, turnState.live.narrative || turnState.main)).catch(() => {});
      }
    } catch (err) {
      // C6: aborts read as a neutral note (.msg-note), real failures as a red .msg-error block — not
      // stuffed into the markdown buffer. finalizeLive still renders whatever text streamed before this.
      // 取 turnState 上的当前壳(与 finally/成功路径同源):切走再切回时 mountActiveTurn 已换了新壳,
      // 闭包里的 live/main 可能还指着那只已脱离文档的旧壳,「已停止」会画到看不见的地方。
      live = turnState.live; main = turnState.main;
      turnEndedBadly = true;
      if (err.name === 'AbortError') { appendMsgNote(main, live, t('status.stopped')); toast(t("toast.turnStopped")); }
      else if (/"session\.turn_busy_elsewhere"/.test(String(err && err.message || ''))) { /* 线程正被别处起的回合占着(后台代理唤醒 / 管家 / 定时任务)而本页的插话快照还没跟上:服务端 409、这句没发出 —— 放回输入框,不吞 */ appendMsgNote(main, live, t('chat.turnBusyElsewhere')); const box = $('promptInput'); if (box && !box.value.trim()) { box.value = message; autoGrow(box); updateSendBtn(); } toast(t('chat.turnBusyElsewhere')); } else { if (privacyFailure(err)) main.appendChild(errorCard('', err, false)); else appendMsgError(main, live, apiErrText(err)); toast(t("toast.error", { p1: apiErrText(err) }), 'err'); }
      finalizeLive(live);
      // 失败/中止路径没有成功路径的回合末重取 —— 单独拉一次,把乐观行的操作条重绑到持久化真身。
      // 也把重取回来的会话装回 state(与成功路径同口径,不重画):中止/断流时服务端已经落了半截回答,修前 state 里没有它,
      // 之后任何一次 renderCurrentSession(固定、改名、加载更早……)都会把屏上那段回答抹掉,直到重新打开会话。
      // 只在「还停在这条会话、而且没有新回合接着跑」时装 —— 新回合的状态由它自己的流维护。
      fetchSessionAfterTurn(api, turnSessionId, state.currentSession?.id === turnSessionId ? state.currentSession : null)
        .then(s => {
          if (s && s.session && state.currentSession?.id === turnSessionId && !activeTurns.has(turnSessionId)) {
            state.currentSession = s.session; state.resumable = s.resumable || null;
          }
          rebindOptimisticUserRow(s && s.session);
        }).catch(() => {});
    } finally {
      // 只收拾【自己这一回合】:回合末 await(重取会话、刷新列表)期间用户可能已经发出下一句 —— 插话被服务端回
      // 「没有进行中的回合」后落回 sendPrompt,新回合已经把 activeTurns 这一格换成了它自己。修前这里无条件 delete,
      // 新回合还在流,页面却以为空闲(按钮回到「发送」;再发一句就 supersede 掉正在跑的回合;切走切回也重建不了实时壳)。
      const ownsTurn = activeTurns.get(turnSessionId) === turnState;
      if (ownsTurn) activeTurns.delete(turnSessionId);
      // 124 真机 bug（用户 2026-09-15：「回合结束后新发送东西，却显示插话且插话失败」）：
      // **回合一结束，这条会话那份 relay 快照的依据就没了**，必须当场作废。
      // 它全仓只有一个写入口 —— session-experience 的 captureLiveTurn（跟着 GET /api/sessions/:id
      // 回来）；而推送驱动的那次重取 pushLiveTurn 有一道门「本页自己在跑流就不拉」
      // （!activeTurns.has(id) && !state.streaming）—— 本页自己起的回合，整个回合期间那道门都关着，
      // 而 thread.done 恰恰在这一刻到达，于是没人接。此后这条线程再无推送（它已经空闲），
      // 快照就永远停在 'steer' 上：发送门把用户之后的每一句话都路由到 /api/steer，
      // 服务端如实回「当前没有进行中的回合」，话卡在框里发不出去。
      // 用户当时是按了「交给管家盯」才恢复的 —— 那个 PATCH 顺带派了一条推送，
      // 碰巧补上了这里本该发生的那一次刷新。
      // 作废是安全的：一条会话同一时刻只有一个回合（09 的 supersede 就是在保这条），
      // 刚结束的正是它；真有新回合（比如管家接着起一条），下一次 GET 会把它重新写回来。
      if (ownsTurn) {
        if (state.sessionRelay && state.sessionRelay.sessionId === turnSessionId) state.sessionRelay = null;
        // 计划待批准时按「停止」/ 断流 / 出错:turn-activity 的 endTurn 故意保留 plan 待决(正常收尾停在「等你拍板」是有效状态),
        // 可这几条路上服务端的等待已随回合作废 —— 状态条不能再停在「等你拍板」,本回合还亮着的计划卡也得标成已失效(禁用按钮)。
        const endedInfo = turnActivity ? turnActivity.snapshot().ended : null;
        const planInvalid = turnEndedBadly || Boolean(endedInfo && endedInfo.ok === false);
        if (planInvalid) expirePendingPlanCards(turnState.main);
        if (turnActivity && state.currentSession?.id === turnSessionId) { turnActivity.settle({ dropPlan: planInvalid }); renderTurnActivityBar(); }
        // 流内 'started' 起的压缩指示条随本回合收尾静默收掉(回合被停/断流时服务端的 completed 到不了)。
        if (compactState.active && compactState.stream === turnSessionId) endCompactIndicator();
        notifySessionStream({ type: 'settled', sessionId: turnSessionId });
      }
      syncStreamingUi();
      renderSessions();
      updateSendBtn();   // 同上：判据刚变，按钮要在同一拍从「插话」回到「发送」
    }
  }

  // v0.8-S7 steering (§4 A3) + Agent CLI adapters. Called when the composer sends WHILE a turn streams.
  // Provider injects at an iteration boundary, Claude interactive writes stdin immediately, and Kimi ACP
  // queues a same-session follow-up prompt (the current ACP revision has no native mid-prompt steer method).
  // On success clears the input, toasts (按 r.injected 区分即时/下步生效), and optimistically renders the user's
  // interjection in the message flow with a muted 「插话」 badge. The server also emits a `steered` event when it
  // actually injects the text — steeredSeen dedups that echo against this optimistic render (by text within a short time window).
  const steeredSeen = []; // [{text, ts}] recently rendered locally, for `steered`-event dedup(不限时,逐条 splice;cap 50)

  // v1.9.0: 插话队列可视化——在客户端维护一份「已发送但尚未被模型消费」的待注入列表。
  // 每次 steerPrompt 排队成功后 push;收到 steered 事件时 splice 已注入项;回合结束清空。
  // composerHint 从纯文本升级为卡片列表,每条显示截断文本 + ×撤回按钮 + 清空队列。
  const steerPendingList = []; // [{text, ts}]

  function renderSteerQueue() {
    const h = $('composerHint');
    if (!h) return;
    if (!steerPendingList.length) { h.innerHTML = ''; h.style.display = 'none'; return; }
    h.style.display = '';
    const n = steerPendingList.length;
    const queuedCount = steerPendingList.filter(p => !p.injected).length; // v1.9.1: provider 排队项数(Claude injected 不计)
    // Never interpolate user-provided steer text into innerHTML or inline onclick. Besides XSS, quoted text
    // would break the old onclick attribute. textContent + listeners keep both short and truncated strings safe.
    const card = el('div', 'steer-queue' + (queuedCount ? '' : ' injected'));
    const header = el('div', 'steer-queue-head');
    const title = el('span', 'steer-queue-title');
    // v1.9.1: 混合态优先显「插话队列」(还有排队项);全已注入显「已注入」(Claude 即时注入确认)
    title.textContent = `${t(queuedCount > 0 ? 'chat.steerQueueTitle' : 'chat.steerInjectedTitle')} · ${n}`;
    header.appendChild(title);
    if (queuedCount > 1) {
      const clear = el('button', 'steer-queue-clear');
      clear.type = 'button'; clear.textContent = t('chat.steerClearAll');
      clear.addEventListener('click', () => { void window.cancelSteer('', true); });
      header.appendChild(clear);
    }
    card.appendChild(header);
    const items = el('div', 'steer-queue-items');
    for (const pending of steerPendingList) {
      const item = el('div', 'steer-queue-item' + (pending.injected ? ' is-injected' : ''));
      const text = el('span', 'steer-queue-text');
      text.title = pending.text;
      const truncated = pending.text.length > 80 ? pending.text.slice(0, 80) + '…' : pending.text;
      text.textContent = truncated;
      item.append(text, el('span', 'steer-queue-state', pending.injected ? t('chat.steerInjectedTitle') : t('chat.steerQueueTitle')));
      if (pending.injected) {
        // Claude 即时注入不可撤回(后端 DELETE 会拒绝),不显示 × 按钮
      } else {
        const cancel = el('button', 'steer-queue-cancel');
        cancel.type = 'button'; cancel.textContent = '×'; cancel.title = t('chat.steerCancelAria'); cancel.setAttribute('aria-label', t('chat.steerCancelAria'));
        cancel.addEventListener('click', () => { void window.cancelSteer(encodeURIComponent(pending.text), false, pending.attachmentKey || ''); });
        item.append(cancel);
      }
      items.appendChild(item);
    }
    card.appendChild(items);
    h.replaceChildren(card);
  }
  // cancelSteer: 从队列中撤回一条插话。clearAll 是独立控制参数，绝不复用用户文本作哨兵值。
  window.cancelSteer = async function(encodedText, clearAll = false, attachmentKey) {
    let text = '';
    if (!clearAll) {
      try { text = decodeURIComponent(encodedText); } catch { return; }
    }
    if (!state.currentSession?.id) return;
    const sessionId = state.currentSession.id;
    const selectionSeq = sessionSelectionSeq();
    const sameSelection = () => state.currentSession?.id === sessionId && sessionSelectionSeq() === selectionSeq;
    if (clearAll) {
      // 批量撤回:逐条调用 DELETE,忽略单条失败(可能已被模型消费)。跳过 Claude injected 项(不可撤回,DELETE 恒失败)。
      const items = [...steerPendingList];
      for (const p of items) {
        if (p.injected) continue; // v1.9.1: Claude injected 项不可撤回,跳过
        try { await api('/api/steer', { method: 'DELETE', body: JSON.stringify({ sessionId, text: p.text, attachmentKey: p.attachmentKey }) }); } catch {}
      }
      // v1.9.1: 只移除快照中的非 injected 项,不 length=0 --否则 await 期间并发新 steer 会被误清(对抗验证发现)。
      for (const p of items) {
        if (p.injected) continue;
        const i = steerPendingList.indexOf(p);
        if (i >= 0) steerPendingList.splice(i, 1);
      }
    } else {
      const pending = steerPendingList.find(p => p.text === text && !p.injected && (attachmentKey == null || (p.attachmentKey || '') === attachmentKey));
      try {
        const r = await api('/api/steer', { method: 'DELETE', body: JSON.stringify({ sessionId, text, attachmentKey }) });
        if (r && r.ok) {
          const idx = steerPendingList.indexOf(pending);
          if (idx >= 0) steerPendingList.splice(idx, 1);
        } else if (sameSelection()) {
          toast(t('toast.steerFail', { p1: r?.error ? apiErrText(r.error) : t('common.unknownError') }), 'err');
        }
      } catch (e) { if (sameSelection()) toast(t('toast.steerFail', { p1: apiErrText(e) }), 'err'); }
    }
    if (sameSelection()) renderSteerQueue();
  };

  async function steerPrompt(overrideText, options = {}) {
    if (!Array.isArray(options.attachments) && Number(state.uploading) > 0) { toast(t('toast.uploadInProgress'), ''); return; }
    const composerDraft = overrideText == null ? $('promptInput').value : options.composerDraft;
    const sentAttachments = (Array.isArray(options.attachments) ? options.attachments : state.attachments).slice();
    const rawText = (overrideText != null ? overrideText : composerDraft).trim();
    if (!rawText && !sentAttachments.length) return;
    const text = rawText || t('chat.attachmentOnly', { names: sentAttachments.map(a => a.name).join(', ') }).slice(0, 2000);
    if (!state.currentSession?.id) return;
    const sessionId = state.currentSession.id;
    const selectionSeq = sessionSelectionSeq();
    const sameSelection = () => state.currentSession?.id === sessionId && sessionSelectionSeq() === selectionSeq;
    if (!activeTurnSteerCapability().ok) { showClaudeSteerSetup(); return; }
    try {
      const delivery = $('steerDeliveryMode');
      const mode = delivery && !delivery.hidden ? delivery.value : 'queue';
      const r = await api('/api/steer', { method: 'POST', body: JSON.stringify({ sessionId, text, mode, attachments: sentAttachments }) });
      if (!sameSelection()) return; // 包括 A→B→A；旧现场的回包不更新输入框、队列或触发重发。
      // 124 真机 bug（用户 2026-09-15：「回合结束后新发送东西，却显示插话且插话失败」）：
      // **服务端才是权威。** 它说这条线程此刻没有在途回合，就说明我们手上那份「可以插话」的信念
      // 已经过期（它唯一的来源是一次 GET 带回的 relay 快照）。这时把用户的话卡在框里、只弹一句
      // 「插话失败」是最坏的处理 —— 用户按发送想做的事很清楚：**把这句话发出去**。
      // 所以：作废那份信念，按普通回合重发一次。判据是【码】不是中文句子（38 号文 §7 ④ 的裁决）。
      // skipSteer 兜住极端情形下的来回弹跳：这一发只许走普通回合那条路，不许再回到插话。
      if (r && r.ok !== true && String((r.error && r.error.code) || '') === 'steer.no_live_turn') {
        if (state.sessionRelay && state.sessionRelay.sessionId === sessionId) state.sessionRelay = null;
        updateSendBtn();
        return sendPrompt(rawText, { ...options, attachments: sentAttachments,
          ...(!Array.isArray(options.attachments) ? { composerAttachments: sentAttachments } : {}), skipSteer: true, composerDraft });
      }
      if (!r || !r.ok) { toast(t("toast.steerFail", { p1: r?.error ? apiErrText(r.error) : t('common.unknownError') }), 'err'); return; }
      if (!Array.isArray(options.attachments)) {
        for (const a of sentAttachments) revokeAttachmentPreview(a);
        state.attachments = state.attachments.filter(a => !sentAttachments.includes(a));
        renderAttachments();
      }
      if (composerDraft != null) { clearSentComposerDraft(composerDraft, text); updateSendBtn(); }
      steeredSeen.push({ text, attachmentKey: steerAttachmentKey(sentAttachments), ts: Date.now() });
      if (steeredSeen.length > 50) steeredSeen.splice(0, steeredSeen.length - 50); // 50-fix:cap 防无限积
      renderSteeredMessage(text, false, sentAttachments);
      // v1.9.1: 两条路径都显示卡片(provider 排队可撤回 / Claude 已注入确认 2.5s)。
      if (r.queued) {
        // provider: 排队等待下次迭代边界注入,卡片可撤回
        if (state.streaming) { steerPendingList.push({ text, attachmentKey: steerAttachmentKey(sentAttachments), ts: Date.now(), injected: false }); renderSteerQueue(); }
        toast(t('toast.steerQueued'), 'ok'); // v1.9.1: turn 已结束(POST 迟到)只 toast 不显卡片(无 drain 事件移除会持久残留)
      } else if (r.injected) {
        // v1.9.1: Claude 即时注入也显示卡片(「已注入」确认,不可撤回),2.5 秒后自动消失。
        //   Claude 不排队(无迭代边界),steered 事件几乎与 POST 响应同时到 -> 不依赖事件移除,否则卡片一闪而过。
        if (!state.streaming) { toast(t('toast.steerInjected'), 'ok'); } // v1.9.1: turn 已结束(POST 迟到)不显示卡片,避免在已结束 turn 残留 2.5s
        else {
          const item = { text, ts: Date.now(), injected: true };
          steerPendingList.push(item);
          renderSteerQueue();
          toast(t('toast.steerInjected'), 'ok');
          setTimeout(() => {
            const i = steerPendingList.indexOf(item);
            if (i >= 0) { steerPendingList.splice(i, 1); renderSteerQueue(); }
          }, 2500);
        }
      } else {
        toast(t('toast.steerInjected'), 'ok');
      }
    } catch (e) { if (sameSelection()) toast(t("toast.steerFail", { p1: apiErrText(e) }), 'err'); }
  }

  // Render a user interjection row with a muted 「插话」 badge. Used by steerPrompt (optimistic) and by the
  // `steered` stream event (when the UI didn't already show it locally — e.g. a steer from another tab).
  // v1.9.1: 闪绿插话徽章 3 秒(注入确认)。从 steered 事件内联抽出复用--乐观行/事件行/已存在行补闪都走它。
  function flashSteerBadge(row) {
    const badge = row && row.querySelector('.steered-badge');
    if (!badge) return;
    badge.textContent = t('chat.steerInjectedBadge');
    badge.style.color = '#16a34a';
    badge.style.fontWeight = '600';
    badge.style.background = 'rgba(22,163,74,.1)';
    setTimeout(() => { badge.style.color = ''; badge.style.fontWeight = ''; badge.style.background = ''; }, 3000);
  }
  // EC-D 56b: 构造 turn narrative 内的内嵌插话 segment(live renderSteeredMessage 与静态 renderStaticTurnNarrative 共享,
  //   确保流式与刷新后视觉一致)。用户插话原文用 textContent(不进 markdown,防 XSS 与引用断裂)。
  function steerAttachmentKey(attachments) {
    return attachments.length ? JSON.stringify(attachments.map(a => [a.id || '', a.name || ''])) : '';
  }
  function buildNarrativeSteerSegment(text, attachments = []) {
    const seg = el('div', 'turn-segment narrative-steer');
    seg.dataset.steerAttachments = steerAttachmentKey(attachments);
    seg.appendChild(el('span', 'steered-badge', t('chat.steer')));
    const bubble = el('div', 'bubble');
    bubble.textContent = String(text || '');
    seg.appendChild(bubble);
    const strip = messageAttachmentStrip({ attachments });
    if (strip) seg.appendChild(strip);
    return seg;
  }
  function renderSteeredMessage(text, justInjected, attachments = []) {
    const box = $('messages');
    box.querySelector('.empty-state')?.remove();
    // v1.9.1 幂等:同文本插话只渲染一次。防 SSE 比 POST 响应先到的竞态双写
    //   (事件先到 -> steeredSeen 空 -> 下方 steered case 渲染行A;POST 返回 -> 乐观再渲染行B = 两条)。
    //   DOM 文本去重不依赖时序,第二次调用发现同文本 steered 行已存在则跳过。
    const now = Date.now();
    // v1.9.1 幂等加时间窗口:同文本且 1.5 秒内才算同一条的乐观/事件重复(跳过);超窗视为不同条同文本插话(跨回合重发或连发),各自渲染。纯文本去重会误杀不同条(对抗验证发现)。
    for (const node of box.querySelectorAll('[data-steered="true"]')) {
      if ((node.dataset.steerAttachments || '') !== steerAttachmentKey(attachments)) continue;
      if (node.dataset.steerTs && now - Number(node.dataset.steerTs) > 1500) continue; // v1.9.1: 只对设了 steerTs 的乐观/事件行判窗;历史行(静态重渲染无 steerTs)始终参与文本去重,防会话切回 mountActiveTurn 重放双写
      const md = node.querySelector('.bubble'); // steered 行是 user .plain bubble(.markdown 类不存在);直接 .bubble 匹配
      if (md && md.textContent.trim() === String(text || '').trim()) {
        if (justInjected) flashSteerBadge(node); // 行已存在(事件先到,乐观尚未渲染),补闪绿
        return;
      }
    }
    // EC-D 56(插话插入点):有活动 live turn 时,把插话作为 turn narrative 内的 segment 落在当前流式位置--
    //   seal 当前文本段(插话前的助手文字)-> 插入 narrative-steer segment -> startLiveTextSegment(后续文字流入新 bubble)。
    //   不再追加到 #messages 末尾钉死底部。无活动 turn(回合已结束/事件迟到)回退原独立 user 行。
    const sid = state.currentSession?.id || '';
    const turn = sid ? activeTurns.get(sid) : null;
    const narrative = turn && turn.live && turn.live.narrative && turn.live.narrative.isConnected ? turn.live.narrative : null;
    if (narrative) {
      sealLiveTextSegment(turn.live); // 封存插话前的助手文本 -> 插话落在其后(无文本则移除空 bubble)
      const seg = buildNarrativeSteerSegment(text, attachments);
      seg.dataset.steered = 'true'; // 幂等检查/闪绿匹配覆盖
      seg.dataset.steerTs = String(now); // 时间戳供幂等窗口判定(静态重渲染行无此标记 -> 超窗 -> 不阻止新插话)
      narrative.appendChild(seg);
      startLiveTextSegment(turn.live); // 插话后开新文本段,后续助手文本流入新 bubble(空则 finalizeLive 移除)
      if (justInjected) flashSteerBadge(seg); // 事件触发的渲染直接闪绿(乐观行可能尚未出现,等不到事件来闪)
      maybeScrollToBottom();
      return;
    }
    // 回退:无活动 live turn -> 独立 user 行(刷新后静态渲染同源)
    const row = renderStaticMessage({ role: 'user', content: text, attachments, createdAt: new Date().toISOString(), steered: true });
    row.dataset.steered = 'true'; // renderStaticMessage 已设,此处冗余保留
    row.dataset.steerAttachments = steerAttachmentKey(attachments);
    row.dataset.steerTs = String(now); // v1.9.1: 时间戳供幂等窗口判定(静态重渲染行无此标记 -> 超窗 -> 不阻止新插话)
    box.appendChild(row);
    if (justInjected) flashSteerBadge(row); // 事件触发的渲染直接闪绿(乐观行可能尚未出现,等不到事件来闪)
    maybeScrollToBottom();
  }

  async function stopTurn() {
    const sid = state.currentSession?.id || '';
    const turn = sid ? activeTurns.get(sid) || null : null;
    const expectedExecution = turn ? turn.execution : state.sessionExecution?.sessionId === sid ? state.sessionExecution.execution : undefined;
    if (!sid || (turn && turn.stopRequested)) return;
    const identityKey = value => value === undefined ? 'unknown' : value === null ? 'idle' : JSON.stringify([value.serverInstanceId, value.driverRunId]);
    const actionKey = identityKey(expectedExecution);
    const ownsReceipt = () => {
      if (state.currentSession?.id !== sid) return false;
      const currentTurn = activeTurns.get(sid) || null;
      if (currentTurn !== turn) return false;
      const currentExecution = currentTurn ? currentTurn.execution : state.sessionExecution?.sessionId === sid ? state.sessionExecution.execution : undefined;
      return identityKey(currentExecution) === actionKey;
    };
    if (turn) turn.stopRequested = true;
    try {
      const receipt = await api('/api/stop', { method: 'POST', body: JSON.stringify({ sessionId: sid, expectedExecution }) });
      if (!ownsReceipt()) return;
      if (receipt?.ok === true && (receipt.stopped === true || receipt.queuedStopped === true)) {
        if (turn && activeTurns.get(sid) === turn && turn.abort) turn.abort.abort();
        if (state.currentSession?.id === sid && (!turn || activeTurns.get(sid) === turn)) setProc('stopped');
      } else if (receipt?.ok !== true && state.currentSession?.id === sid) toast(t('stewardShell.stop.unknown'), 'err');
    } catch (error) {
      if (ownsReceipt()) toast(Number(error?.status) >= 400 && Number(error?.status) < 500
        ? t('stewardShell.chat.errConflict') : t('stewardShell.stop.unknown'), 'err');
    } finally { if (turn) turn.stopRequested = false; }
  }

  function scheduleRender(live) {
    if (live.rafPending) return;
    live.rafPending = true;
    live.rafId = requestAnimationFrame(() => {
      live.rafPending = false;
      live.rafId = 0;
      const pending = live.bufferText.slice(live.renderedChars || 0);
      if (pending && live.textNode) { live.textNode.appendData(pending); sealLiveTextChunk(live); }
      live.renderedChars = live.bufferText.length;
      // EC-D 57: 正文/思考/工具统一走聊天滚动控制器；DOM 增长不再伪装成用户 scroll。
      maybeScrollToBottom();
    });
  }
  function finalizeLive(live) {
    // Every terminal path settles and collapses the active reasoning note unless the user toggled it.
    flushThinkingBuffer(live); // rAF 合批未写出的思维链增量先落盘，摘要字数才准确
    settleLiveThinking(live);
    // A transport failure can close the turn after tool_use but before its tool_result line reaches the
    // browser. Never leave that card claiming it is still running after the owning turn has settled.
    for (const [id, card] of (live?.toolCards || new Map())) {
      if (card.durationTimer) { clearInterval(card.durationTimer); card.durationTimer = 0; }
      if (!card.statusbar?.classList.contains('running')) continue;
      card.status.textContent = t('status.stopped');
      card.status.classList.remove('ok', 'err'); card.status.classList.add('err');
      card.statusbar.classList.remove('running', 'ok', 'err'); card.statusbar.classList.add('err');
      if (card.dur && card.t0 != null) card.dur.textContent = `· ${((performance.now() - card.t0) / 1000).toFixed(1)}s`;
      if (card.resPre && !card.resPre.textContent) card.resPre.textContent = t('chat.toolResultMissing');
      settleNarrativeTool(live, id, true);
    }
    compactNarrativeProcessRuns(live && live.narrative);
    if (live.bubble && !live.bufferText && (live.errorShown || live.noteShown || live.narrative.childElementCount > 1)) sealLiveTextSegment(live);
    else if (live.bubble) {
      if (!live.bufferText) live.bufferText = t('chat.noTextOutput');
      sealLiveTextSegment(live);
    }
    // 回合收尾连做折叠(思考面板/过程组)+ markdown 定版，高度变化集中在这一步；
    // 同任务内补一次粘性跟随，避免回合结束时视口先塌后跳。
    maybeScrollToBottom();
  }
  // C6: insert an independent .msg-error block (red) into the live container. Text via textContent so
  // it is never markdown-parsed. Placed after the tools wrap so it reads as the turn's terminal state.
  function appendMsgError(main, live, text, container) {
    if (live) sealLiveTextSegment(live);
    const box = el('div', 'msg-error'); box.textContent = text;
    (container || main).appendChild(box);
    if (live) live.errorShown = true;
    maybeScrollToBottom();
  }
  // C6: a neutral, muted variant for benign notes ("已停止"). Same structure, no alarm coloring.
  // v2.6.2-r2: 可选 container —— 长回合中途的压缩标记要落在 live.narrative(时序流)内部,
  // 而不是 main 尾部( narrative 之后),否则多条标记会全部堆在回合最底部,脱离发生位置。
  function appendMsgNote(main, live, text, container) {
    if (live) sealLiveTextSegment(live);
    const box = el('div', 'msg-note'); box.textContent = text;
    (container || main).appendChild(box);
    if (live) live.noteShown = true;
    maybeScrollToBottom();
  }

  /* ---------------- ↓ 回到最新 (§4.4 / EC-D 57 chat-scroll domain) ---------------- */
  // 思维链流式渲染的 rAF 合批入口：thinking_delta 事件只累加 buffer，渲染收敛到每帧一次。
  // 后台标签页 rAF 会暂停，但回合结束时 flush 会把全部 buffer 落盘、切回前台后 rAF 恢复继续，
  // 内容不丢（原 setTimeout 方案的"后台也逐事件渲染"对不可见的页面没有价值）。
  function scheduleLiveThinkingFollow(live) {
    if (!live || live.thinkingRafId) return;
    live.thinkingRafId = requestAnimationFrame(() => {
      live.thinkingRafId = 0;
      flushThinkingBuffer(live);
      // 内层 think-body 跟随：每帧读一次布局；用户已上滑（距底 ≥36px）则不打扰。
      if (live.thinkingEl && live.thinkingPanelObj?.d.open
          && live.thinkingEl.scrollHeight - live.thinkingEl.scrollTop - live.thinkingEl.clientHeight < 36) {
        live.thinkingEl.scrollTop = live.thinkingEl.scrollHeight;
      }
      // 外层消息区跟随同样收敛到每帧一次（原实现在每个 thinking_delta 事件上各起一个
      // setTimeout(0)，事件风暴下产生大量定时器与重复布局读）。
      maybeScrollToBottom();
    });
  }
  // 把累积的思维链文本一次性写入 DOM 文本节点。所有 settle/flush 路径之前必须调用，
  // 确保折叠摘要字数（读 body.textContent）与面板正文一致。
  function flushThinkingBuffer(live) {
    if (!live || !live.thinkingBuffer) return;
    if (live.thinkingNode) { live.thinkingNode.appendData(live.thinkingBuffer); sealTextTailChunk(live.thinkingNode); }
    live.thinkingBuffer = '';
  }

  function registerLiveSemanticCard(live, segment) {
    if (!live || !live.narrative) return null;
    sealLiveTextSegment(live);
    live.completedRun = []; live.completedGroup = null;
    const key = String(segment.requestId || segment.questionId || segment.workflowId || segment.missionId || segment.id || '');
    if (key && live.semanticCards.has(key)) return live.semanticCards.get(key);
    const card = segment.type === 'question' ? narrativeQuestionCard(segment) : narrativeSemanticCard(segment);
    live.narrative.appendChild(card);
    if (key) { live.semanticCards.set(key, card); live.semanticData.set(key, { ...segment }); }
    return card;
  }
  function updateLiveSemanticCard(live, key, segment) {
    if (!live) return;
    const normalizedKey = String(key || '');
    const old = live.semanticCards.get(normalizedKey);
    if (!old) return;
    const merged = { ...(live.semanticData.get(normalizedKey) || {}), ...segment };
    const fresh = merged.type === 'question' ? narrativeQuestionCard(merged) : narrativeSemanticCard(merged);
    old.replaceWith(fresh);
    live.semanticCards.set(normalizedKey, fresh);
    live.semanticData.set(normalizedKey, merged);
  }

  function handleStreamLine(line, live, main, streamSessionId) {
    if (!line.trim()) return;
    let evt;
    try { evt = JSON.parse(line); } catch { return; }
    // 112b: 状态机吃【全部】事件(含二十种此前落进 default 被静默丢弃的),再由状态条统一呈现。
    // 放在 switch 之前:即使某个事件在下面没有 DOM 分支,它对「在干什么」的贡献也不会丢。
    if (turnActivity) { turnActivity.consume(evt); scheduleActivityBar(); }
    // Only a new narrative item closes the active reasoning phase. In particular, context_estimate is emitted
    // every ~800ms by provider turns and only updates the meter; treating it as a boundary split one reasoning
    // chain into several panels even though the persisted turn segment remained continuous.
    if (live?.thinkingActive && isThinkingNarrativeBoundary(evt)) {
      flushThinkingBuffer(live); // 面板收拢前把合批中的思维链增量写进 DOM
      settleLiveThinking(live);
      compactNarrativeProcessRuns(live.narrative);
      // 思考面板折叠是一次大幅高度塌陷：同任务内立即重新跟随，否则塌陷帧先画出、
      // 下一个事件才把视口拽回底部，表现为页面先跳上去再跳下来（上下抖动）。
      maybeScrollToBottom();
    }
    switch (evt.type) {
      case 'session':
        if (evt.session && state.currentSession?.id === streamSessionId) {
          // 回合起点的增量版(发送时带了 knownMessages):拼回发送那一刻手上的前缀;拼不上(前缀在途中被整个换掉)就整份取一次。
          const turn = activeTurns.get(streamSessionId);
          const merged = Number.isInteger(evt.messagesFrom) ? spliceSessionDelta(turn?.knownPrefix, evt) : evt;
          if (merged) { state.currentSession = merged.session; rememberMessagesStamp(merged.session.messages, merged.messagesStamp); renderSessions(); }
          else api(`/api/sessions/${streamSessionId}`).then(p => {
            if (p?.session && state.currentSession?.id === streamSessionId && activeTurns.get(streamSessionId) === turn) { state.currentSession = p.session; renderSessions(); }
          }).catch(() => {});
        }
        break;
      case 'raw_line':
        pushRawEvent(evt.seq, evt.line, streamSessionId);
        break;
      case 'meta': {
        // Engine-aware prefix: provider turns show the provider label, claude turns show 'claude'.
        const engTag = evt.engine === 'openai' ? (evt.providerLabel || 'provider') : (evt.agentCliLabel || agentCliMeta(evt.agentCliType).eventTag);
        const mc = evt.memoryCheck;
        const memoryLine = !mc ? '' : (!mc.enabled
          ? '\n' + t('memory.check.disabled')
          : (!mc.checked ? '\n' + t('memory.check.unavailable') : '\n' + t('memory.check.done', { candidates: mc.candidateCount || 0, matches: mc.matchCount || 0, project: mc.projectMatches || 0, global: mc.globalMatches || 0 }) + (mc.ruleFillCount > 0 ? t('memory.check.fill', { fill: mc.ruleFillCount }) : '')));
        if (!replayingStream) appendToolOutput(`[${engTag}] ${evt.command} ${(evt.args || []).join(' ')}\ncwd=${evt.cwd}\n${t('chat.meta.modelPermission', { model: String(evt.model), permission: String(evt.permissionMode) })}${memoryLine}`);
        // v0.8-S0 cwd guardrail: warn once per turn when the working dir is the user's home/Desktop/
        // Documents/Downloads root (acting on everything the user owns is the highest-risk misfire).
        if (evt.cwdWarning && live && !live.cwdWarned) {
          live.cwdWarned = true;
          if (!replayingStream) toast(t("toast.homeCwdWarn"), 'err');
        }
        break;
      }
      case 'process':
        setProc(evt.state);
        break;
      case 'assistant_delta':
        ensureLiveTextSegment(live);
        live.bufferText += evt.text || '';
        scheduleRender(live);
        break;
      case 'thinking_delta':
        {
        if (!live.thinkingActive) {
          sealLiveTextSegment(live);
          // Reasoning is a real chronological boundary: tools on opposite sides must never be pulled into
          // one tool group, or their expanded order would disagree with the actual event stream.
          live.completedRun = [];
          live.completedGroup = null;
          const tp = thinkingPanel('', true); // live shimmer summary "思考中…"
          live.thinkingEl = tp.body; live.thinkingPanelObj = tp;
          live.thinkingEl.textContent = '';
          live.thinkingNode = document.createTextNode(''); live.thinkingEl.appendChild(live.thinkingNode);
          // Respect a manual toggle when this reasoning phase settles.
          tp.summary.addEventListener('click', () => { tp.userToggled = true; });
          (live.narrative || main).appendChild(tp.d); tp.d.open = true;
          live.thinkingActive = true;
        }
        live.thinkingText += evt.text || '';
        // 超长超快思维链合批：事件只入 buffer，DOM 写与滚动跟随收敛到每帧最多一次。
        // 正文 assistant_delta 已有 scheduleRender 合批；思维链此前每事件同步 appendData +
        // 读一次布局 + 起一个 setTimeout(0)（内部再读布局写两个容器），事件风暴下形成
        // "读-写-读"布局抖动（单 textNode 全文换行重排 O(n·L)），是长链卡死的根源。
        if (live.thinkingBuffer == null) live.thinkingBuffer = '';
        live.thinkingBuffer += evt.text || '';
        scheduleLiveThinkingFollow(live);
        break;
        }
      case 'subagent':
        // v0.9-S6 (子代理): a delegated sub-turn started/ended. `start` opens a nested collapsed card that will
        // hold the sub-turn's own tool_use/tool_result (routed here by subagentId). `end` stamps the head with
        // ✓/✗ + a short conclusion summary. See handleSubagentEvent.
        if (evt.state === 'start' && !(evt.background === true && live.thinkingActive)) { live.thinkingActive = false; sealLiveTextSegment(live); } // 后台节点晚到(父回合还在写思考)就不收口思考块
        handleSubagentEvent(evt, live, streamSessionId);
        maybeScrollToBottom(); // EC-D 56: 子代理卡入列也走粘性跟随
        break;
      case 'subagent_progress':
        // v1.4.6 (C): a tool-less Claude sub-turn reporting streamed-text growth. Refresh its card head so the
        // live chat view shows "生成中 · N 字" instead of a silent stall until the ✓/✗ (routed by subagentId).
        handleSubagentEvent(evt, live, streamSessionId);
        break;
      case 'subagent_no_progress':
      case 'adaptive_tool_budget':
        // 112b: 子代理「连续几轮没动静」与「工具预算被自适应改了」。两族此前都落进 default 被丢弃 ——
        // 用户看到的是一张卡片长时间不动,却没有任何解释。都走同一条子代理卡片状态行。
        handleSubagentEvent(evt, live, streamSessionId);
        break;
      case 'agent_workflow':
        if ((evt.state === 'start' || evt.state === 'running') && !(evt.background === true && live.thinkingActive)) { live.thinkingActive = false; sealLiveTextSegment(live); }
        handleAgentWorkflowEvent(evt, live);
        maybeScrollToBottom(); // EC-D 56: 工作流卡入列也走粘性跟随
        break;
      case 'tool_use': {
        if (!evt.subagentId) live.thinkingActive = false; // 子代理的 tool_use 不收口父回合的思考块(见 isThinkingNarrativeBoundary)
        const card = toolCard({ name: evt.name, input: evt.input });
        // start the clock; tool_result computes the elapsed seconds。重放时用这条事件最初到达的时刻起算:
        // t0 往回拨「到达至今」那么久(仍在跑的工具秒表接着真实已用时走),wallStart 供重放里的 tool_result 取差。
        card.wallStart = replayingStream && replayEventAt ? replayEventAt : Date.now();
        card.t0 = performance.now() - Math.max(0, Date.now() - card.wallStart);
        const updateDuration = () => {
          if (card.dur && card.t0 != null) card.dur.textContent = `· ${((performance.now() - card.t0) / 1000).toFixed(0)}s`;
        };
        card.durationTimer = setInterval(updateDuration, 1000);
        live.toolCards.set(evt.id, card);
        // v0.9-S6: a sub-turn's tool_use carries subagentId → nest it inside that sub-agent's card body (indented,
        // via toolCard reuse). No subagentId → the normal top-level tools wrap.
        // 代理模式 v2:带 subagentId 却找不到子卡(卡已不在/事件迟到)时【不】画到父回合顶层 —— 子代理过程只属于它自己的卡。
        const subHost = evt.subagentId && live.subCards.get(evt.subagentId);
        if (subHost) {
          subHost.body.appendChild(card.d);
        } else if (!evt.subagentId) {
          registerNarrativeTool(live, evt, card);
        }
        maybeScrollToBottom(); // EC-D 56: 工具卡入列也走粘性跟随(用户要"页面跟着滚动",上滑阅读时不打扰)
        break;
      }
      case 'tool_use_update': {
        const card = live.toolCards.get(evt.id);
        applyToolUseUpdate(card, evt, { humanizeToolName, safeStringify, toolArgSummary });
        break;
      }
      case 'tool_progress': {
        // 112b: 长工具心跳。此前整族落进 default 被丢弃 —— 一条十分钟的命令在卡片上只有一个本地秒表
        // 在走,时间预算的软警告/硬终态用户完全看不到。这里把服务端的权威计时与预算状态画上去。
        const card = live.toolCards.get(evt.id);
        if (!card) break;
        const seconds = Number(evt.elapsedMs) / 1000;
        // 服务端计时是权威的:标签页被后台节流时本地 setInterval 会停,心跳到达即纠正。
        if (card.dur && Number.isFinite(seconds)) card.dur.textContent = `· ${seconds.toFixed(0)}s`;
        if (evt.state === 'budget_soft' && card.status) {
          card.status.textContent = t('turnActivity.tool.budgetSoft', { p1: Math.round(Number(evt.warnMs) / 1000) || 0 });
          card.status.classList.remove('ok', 'err'); card.status.classList.add('warn');
        } else if (evt.state === 'budget_hard' && card.status) {
          card.status.textContent = t('turnActivity.tool.budgetHard', { p1: Math.round(Number(evt.deadlineMs) / 1000) || 0 });
          card.status.classList.remove('ok', 'warn'); card.status.classList.add('err');
        }
        break;
      }
      case 'tool_result': {
        const card = live.toolCards.get(evt.id);
        if (card) {
          if (card.durationTimer) { clearInterval(card.durationTimer); card.durationTimer = 0; }
          if (renderToolResultInto) renderToolResultInto(card.resPre, card.name, evt.content); else card.resPre.textContent = safeStringify(evt.content);
          // v1.0-S4: if this was git_diff, paint the colorized diff view now that the result is in.
          if (!evt.isError) renderGitDiffInto(card.diffHost, card.name, evt.content);
          // 109b: 工具产出图内联缩略图。tool_use 阶段 toolCard() 还没有 result,这里补一次(imageHost
          // 上的 dataset 闸门保证不会跟任何其它调用路径重复请求)。
          if (!evt.isError) renderToolImageInto(card.imageHost, card.name, evt.content);
          // 125-P2(42 号文 §1 ③):这次到底是现抓的还是回落了缓存,只有结果里那两个字段知道。
          // 不判 isError:web_fetch 回落缓存时【回的是 ok:true】—— 那正是这一刀要说破的事。
          renderStaleBadgeInto(card.staleHost, card.name, evt.content);
          card.status.textContent = evt.isError ? t('status.error') : t('status.done');
          card.status.classList.remove('ok', 'err'); card.status.classList.add(evt.isError ? 'err' : 'ok');
          // Status bar: running → ok/err.
          if (card.statusbar) { card.statusbar.classList.remove('running', 'ok', 'err'); card.statusbar.classList.add(evt.isError ? 'err' : 'ok'); }
          // Duration: performance.now() delta since tool_use, shown as "· 1.2s".
          // 重放:用两条事件各自的到达时刻取差;没有时间戳(老形状)就不写,宁可空也不写一个恒为 0.0s 的假耗时。
          if (card.dur && card.t0 != null) {
            if (!replayingStream) card.dur.textContent = `· ${((performance.now() - card.t0) / 1000).toFixed(1)}s`;
            else if (replayEventAt && card.wallStart) card.dur.textContent = `· ${(Math.max(0, replayEventAt - card.wallStart) / 1000).toFixed(1)}s`;
            else card.dur.textContent = '';
          }
          settleNarrativeTool(live, evt.id, evt.isError);
          compactNarrativeProcessRuns(live.narrative);
          // 工具完成收组/过程段压实会塌陷高度（用户报告的「新工具展开→成功后快速收起」抽动源）：
          // 与 DOM 变更同帧重新跟随，浏览器只画一次终态，不再先陷后拽。
          maybeScrollToBottom();
        }
        break;
      }
      case 'todo':
        // v0.8-S3: live task-list update → refresh the step-bar and cache on the current session so a later
        // static re-render (session reload) keeps showing it.
        if (state.currentSession) state.currentSession.todos = evt.items || [];
        renderStepBar(evt.items || []);
        break;
      case 'mission':
        // 第26波b: 任务账本进度/状态。缓存到会话 + 刷新进度条;完成/停滞/预算耗尽额外插一张卡片。
        if (state.currentSession) state.currentSession.mission = evt.mission || null;
        renderMissionBar(evt.mission || null);
        {
          const mission = evt.mission || {};
          const missionId = String(mission.id || mission.createdAt || 'active');
          const milestones = Array.isArray(mission.milestones) ? mission.milestones : [];
          const segment = {
            type: 'mission', missionId, goal: mission.goal || '', state: evt.state || 'updated',
            completed: milestones.filter(item => item && item.status === 'done').length,
            total: milestones.length,
            status: evt.state === 'complete' ? 'done'
              : (evt.state === 'stuck' || evt.state === 'budget_exhausted' ? 'error' : 'updated'),
            note: evt.reason || '',
          };
          if (live.semanticCards.has(missionId)) updateLiveSemanticCard(live, missionId, segment);
          else registerLiveSemanticCard(live, segment);
          maybeScrollToBottom();
        }
        break;
      case 'autonomy_grant':
        // 第27波:授权书列表变更(签发/撤销/过期)→ 刷新抽屉。
        renderAutonomyBar(evt.grants || []);
        break;
      case 'autonomy_grant_consumed':
        // 第27波:一次范围内的免弹窗放行 —— 低调提示 + 刷新计数(可观测,不打断)。
        if (!replayingStream) {
          toast(t('toast.grantAuto', { tool: evt.tool || '', remaining: evt.remaining != null ? evt.remaining : '?' }), 'ok');
          loadAutonomyGrants();
        }
        break;
      case 'steered': {
        // v0.8-S7: the server injected a steering interjection at a boundary. If this UI already rendered it
        // optimistically (steerPrompt pushed steeredSeen), dedup against that echo; else render it now.
        // 50-fix(用户真机报告「Steer 一次发两条」):provider 引擎的 echo 在【下一次迭代边界 drain】时才发,
        // 慢工具下可远超旧 15s 窗口 → 窗口失效回声双写。改为【不限时文本队列】去重:同文本逐条 splice,
        // 两条相同插话仍各消各的(正确),回声多晚到都能命中。cap 50 防无限积。
        const idx = steeredSeen.findIndex(s => s.text === evt.text && (s.attachmentKey || '') === steerAttachmentKey(evt.attachments || []));
        if (idx >= 0) { steeredSeen.splice(idx, 1); }
        // v1.9.1: 从 pendingList 移除已注入项。只移除 provider 排队项(!injected);
        //   Claude injected 项由 steerPrompt 的 setTimeout 管理--否则 steered 事件(与 POST 几乎同时到)立即移除,Claude 卡片一闪而过看不见。
        const pidx = steerPendingList.findIndex(p => p.text === evt.text && !p.injected && (p.attachmentKey || '') === steerAttachmentKey(evt.attachments || []));
        if (pidx >= 0) { steerPendingList.splice(pidx, 1); renderSteerQueue(); }
        // v1.9.1: 闪绿消息行「✓ 已注入」。关键:steered 行 append 到 $('messages') 顶层(非 assistant main 内部),
        //   旧代码用 main.querySelectorAll 永远匹配不到 -> 闪绿失效(用户报告"看不到插话插到哪里")。
        // v1.9.1: 闪绿只在 idx>=0(乐观行已存在)时做;idx<0(事件先到)交给 renderSteeredMessage justInjected 闪新行,
        //   否则预闪会打在历史同文本行上(跨回合闪错行)+ 双重闪绿(对抗验证发现)。匹配最后一个(DOM 序=最新)。
        if (evt.text && idx >= 0) {
          const box = $('messages');
          let target = null;
          for (const node of box.querySelectorAll('[data-steered="true"]')) {
            const md = node.querySelector('.bubble');
            if (md && md.textContent.trim() === evt.text.trim()) target = node;
          }
          if (target) flashSteerBadge(target);
        }
        // v1.9.1: justInjected-事件触发渲染直接闪绿(乐观行可能尚未出现,等不到事件来闪)
        if (idx < 0) renderSteeredMessage(evt.text || '', true, evt.attachments || []);
        break;
      }
      case 'turn_summary':
        // v0.8-S3: render the 「本轮变更」card at the tail of the live assistant message. finalizeLive keeps
        // the streamed markdown bubble intact; this card sits after the tools wrap.
        { const record = turnToolIndexCard(live && live.toolIndex ? live.toolIndex : [], main); if (record) main.appendChild(record); }
        main.appendChild(turnSummaryCard(evt));
        if (live && live.pendingUsage) { main.appendChild(usageLine(live.pendingUsage)); live.pendingUsage = null; }
        // v0.9-S1 (C6): remember whether anything actually changed, so a following error `result` can decide
        // whether to append the 「本次未改动任何文件」 reassurance line.
        if (live) live.filesTouched = (Array.isArray(evt.filesChanged) && evt.filesChanged.length > 0)
          || (Array.isArray(evt.artifacts) && evt.artifacts.some(artifact => artifact && artifact.path && !artifact.reverted))
          || (Number(evt.commands) || 0) > 0;
        maybeScrollToBottom();
        break;
      case 'result':
        if (live) live.resultOk = evt.ok === true && !evt.errorClass && !evt.aborted;
        wbNativeClaudeFinalize(streamSessionId, evt);
        // v0.9-S1 (C6): error human-card. On a failed turn (or any turn carrying an errorClass) render a plain-
        // language card with the zh copy + one 「下一步」 action (from ERROR_CLASSES). A clean turn has no
        // errorClass and ok:true → nothing renders. noFilesChanged reassurance shows only when the turn_summary
        // was empty (live.filesTouched is falsy) — a failure that touched nothing shouldn't leave the user guessing.
        if (evt.errorClass || evt.ok === false) {
          // v1.0.2 (F6c): CLI 缺失 → 友好引导卡(向后兼容:无 code 字段走原 errorCard)。
          const noFiles = !(live && live.filesTouched);
          (live && live.narrative ? live.narrative : main).appendChild(evt.code === 'cli-missing' ? cliMissingCard() : errorCard(evt.errorClass, privacyFailure(evt) ? evt : evt.error, noFiles));
          maybeScrollToBottom();
        }
        // v2.7.2: 每轮对话结束自动刷新工具面板(已打开页签;files/artifacts/changes/audit/usage/agent-runs)。
        refreshToolPane();
        break;
      case 'usage':
        if (live) live.pendingUsage = evt; else main.appendChild(usageLine(evt));
        renderContextMeter(evt);
        break;
      case 'context_estimate':
        // 服务端流式估算(≈):只刷新电量表,不进 pendingUsage/usageLine;真实 usage 帧到达时自动覆盖校正。
        // 压缩后的下一次迭代边界会推降低后的估算,电量表即时回落(配合 renderContextMeter 的数字补间平滑显示)。
        renderContextMeter(evt);
        break;
      case 'compact': {
        // 代理模式 v2:子代理自己的压缩(带 subagentId)只更新它的卡片状态行 —— 不进父叙事、不改父电量表、不碰压缩指示条。
        if (evt.subagentId) {
          const subHost = live && live.subCards.get(String(evt.subagentId));
          if (subHost && subHost.status) {
            const tags = `${subHost.roleTag || ''}${subHost.tierTag || ''}${subHost.modelTag || ''}${subHost.driverTag || ''}${subHost.dependencyTag || ''}`;
            subHost.status.textContent = (evt.phase === 'failed' ? t('chat.agentCompactFailed') : evt.afterTokens != null ? t('chat.agentCompacted') : t('chat.agentCompacting')) + tags;
          }
          break;
        }
        const phase = evt.phase || (evt.afterTokens != null ? 'completed' : 'running');
        if (phase === 'started') {
          if (!compactState.active) beginCompactIndicator({ stream: streamSessionId || state.currentSession?.id || 'stream' });
          const label = $('compactIndicator')?.querySelector('span:last-child');
          if (label) label.textContent = evt.mode === 'kimi-native' ? t('chat.compactStartedKimi') : t('chat.compactStartedGeneric');
        } else if (phase === 'running' || phase === 'applied') {
          const label = $('compactIndicator')?.querySelector('span:last-child');
          if (label) label.textContent = phase === 'applied'
            ? (evt.compactedCount ? t('chat.compactAppliedCount', { count: evt.compactedCount }) : t('chat.compactApplied'))
            : (evt.elapsedMs ? t('chat.compactRunningElapsed', { seconds: Math.round(evt.elapsedMs / 1000) }) : t('chat.compactRunning'));
        } else if (phase === 'completed') {
          // v2.6.2-r2: 标记插入 live.narrative(时序流),随当前思考/工具位置就地显示;不再沉到回合最底部。
          const markerBox = live && live.narrative ? live.narrative : null;
          if (evt.beforeTokens || evt.afterTokens) appendMsgNote(main, live, t('chat.compactCompleted', { before: fmtTokens(evt.beforeTokens || 0), after: fmtTokens(evt.afterTokens || 0) }), markerBox);
          // A compact event is newer than the previous persisted usage row. Reflect its post-compact
          // numerator immediately instead of waiting for the next model response's usage frame.
          if (Number.isFinite(Number(evt.afterTokens)) && Number(evt.afterTokens) >= 0) {
            const previous = state.shownUsage || latestUsage(state.currentSession) || {};
            const meta = currentEngineMeta() || {};
            const routeUsage = meta.engine === 'openai' || meta.providerId
              ? { contextEngine: 'openai', contextProviderId: String(meta.providerId || ''), contextModel: String(meta.model || '') }
              : { contextEngine: 'agent', contextAgentCliType: agentCliMeta(meta.agentCliType).id, contextModel: String(meta.model || '') };
            renderContextMeter({ ...previous, ...routeUsage, contextTokens: Number(evt.afterTokens), contextWindow: Number(evt.contextWindow) || previous.contextWindow });
          }
          endCompactIndicator();
        } else if (phase === 'failed') {
          const markerBox = live && live.narrative ? live.narrative : null;
          appendMsgError(main, live, t('chat.compactFailed', { error: evt.error || t('chat.compactUnknownError') }), markerBox);
          endCompactIndicator();
        }
        break;
      }
      case 'stderr':
        if (!replayingStream) appendToolOutput(`[stderr] ${evt.text}`, true);
        break;
      case 'ask_user':
        registerLiveSemanticCard(live, { ...evt, type: 'question', status: 'pending' });
        showAskUserModal(evt.questionId || evt.id, evt.questions, streamSessionId, evt.context || '', Number(evt.deadlineAt) || 0);
        maybeScrollToBottom(); // EC-D 56: 提问卡入列走粘性跟随(模态浮层不影响消息区滚动)
        break;
      case 'question_answer':
        updateLiveSemanticCard(live, evt.questionId || evt.id, {
          ...evt, type: 'question', status: evt.ok === false ? 'cancelled' : 'answered',
          answerSummary: evt.summary || '',
        });
        settlePrompt(evt.questionId || evt.id);
        // 回答落定后仍保持跟随最新：回答卡替换成已答状态，视口停在提问/最新位置。
        maybeScrollToBottom();
        break;
      case 'permission_request':
        registerLiveSemanticCard(live, { ...evt, type: 'permission', status: 'pending' });
        handlePermissionRequest(evt, streamSessionId);
        maybeScrollToBottom(); // EC-D 56: 权限卡入列走粘性跟随
        break;
      case 'permission_paused':
        // 第27f波:无人值守回合的权限弹窗超时后【存档暂停】(不立即拒),延长等待窗口。弹窗仍在,你的决定仍被接受;
        // 超过设定时限(autonomyPauseTtlMs)才回落拒绝。低调提示,不打断。
        updateLiveSemanticCard(live, evt.requestId, { ...evt, type: 'permission', status: 'paused' });
        if (!replayingStream) toast(t("toast.permPaused", { p1: Math.round((evt.ttlMs || 2700000) / 60000) }), 'warn');
        break;
      case 'permission_decision':
        updateLiveSemanticCard(live, evt.requestId, {
          ...evt, type: 'permission', status: evt.behavior === 'allow' ? 'allowed' : 'denied',
        });
        settlePrompt(evt.requestId);
        break;
      case 'plan':
        // v0.9-S5 (真流程 plan mode): the model proposed an execution plan and the turn is paused. Render an
        // in-flow plan card (assistant-bubble variant) with the plan markdown + 批准执行 / 修改意见 / 放弃; the
        // decision POSTs to /api/plan/decision and the turn resumes (or ends). Composer hints while pending.
        handlePlanEvent(evt, live && live.narrative ? live.narrative : main, live);
        break;
      case 'kimi_plan_snapshot':
        // Kimi ACP plan updates are read-only native snapshots. ExitPlanMode remains the separate ask_user
        // event above/below and must keep the classic plan option IDs and answer flow.
        handlePlanEvent(evt, live && live.narrative ? live.narrative : main, live);
        break;
      case 'plan_note':
        // The user attached a note when approving (修改意见). Show it as a muted interjection so the flow reads.
        if (evt.text) appendMsgNote(live && live.narrative ? live.narrative : main, live, t('chat.planNoteContinued', { text: evt.text }));
        break;
      case 'plan_decision':
        // The interactive plan card settles synchronously after the decision POST. The stream event exists so
        // service-side replay can persist the same state without creating a second live card.
        // 卡已决时这一句是空操作;卡还亮着(切会话再切回后重放、服务端超时自动拒绝、别处决定)就在这里收起成已决。
        if (evt.planId) resolvePlanIntervention({ interventionId: evt.planId, action: evt.decision, feedback: evt.note });
        break;
      case 'failover':
        // v1.0-S6 (B4): the provider's primary endpoint failed pre-first-byte and the turn switched to a backup.
        // Surface a warn-level toast so the user knows the request is now going elsewhere. The raw event is also
        // visible in the 调试 (debug) 原始事件流 automatically — no extra work needed there.
        if (!replayingStream) toast(t("toast.failoverSwitched", { p1: evt.to || '' }), 'warn');
        break;
      case 'error':
        // v1.0.2 (F6c): CLI 缺失 → 友好引导卡(向后兼容:无 code 字段走原始 .msg-error 文本块)。
        if (evt.code === 'cli-missing') { (live && live.narrative ? live.narrative : main).appendChild(cliMissingCard()); if (live) live.errorShown = true; maybeScrollToBottom(); break; }
        // C6: a real .msg-error block (red tint + left bar), text via textContent — never folded into the
        // markdown buffer where it would render as bold prose and could be mis-parsed.
        if (privacyFailure(evt)) { (live && live.narrative ? live.narrative : main).appendChild(errorCard(evt.errorClass, evt, false)); if (live) live.errorShown = true; maybeScrollToBottom(); }
        else appendMsgError(live && live.narrative ? live.narrative : main, live, String(evt.error ?? ''));
        break;
      default: break;
    }
  }

  /* ---------------- interactive: AskUserQuestion + permission modals ---------------- */
  // Dynamic modals are tagged 'dynamic' and carry a __cancel hook so Escape/✕/backdrop resolve the
  // held server request (deny/cancel) instead of leaving the CLI child hanging.


  function isNativeClaudeBackgroundAck(evt) {
    if (!evt || evt.native !== true || evt.engine !== 'claude' || typeof evt.result !== 'string') return false;
    const text = evt.result;
    return /\b(?:async|background)\s+(?:agent|task)\b[\s\S]{0,160}\b(?:launched|started|running)\b/i.test(text)
      || /\b(?:agentId|output_file)\s*[:=]/i.test(text)
      || /\b(?:agent|task)\b[\s\S]{0,160}\bworking in the background\b/i.test(text)
      || /(?:后台|异步)(?:代理|任务)?.{0,40}(?:已启动|运行中)/.test(text);
  }

  function handleSubagentEvent(evt, live, streamSessionId) {
    wbNativeClaudeOnSubagent(evt, streamSessionId);
    const id = evt.id || '';
    if (evt.type === 'subagent_progress') {
      // v1.4.6 (C): keyed by subagentId (not id); refresh the sub-card head with the streamed-text milestone
      // so a long tool-less Claude sub-turn shows "生成中 · N 字" instead of a silent stall until the ✓/✗.
      const host = live.subCards.get(evt.subagentId);
      if (host && host.status) host.status.textContent = `${(evt.noteCode && t('chat.subagent.note.' + evt.noteCode, { chars: Number(evt.chars) || 0, secs: Number(evt.secs) || 0, reason: String(evt.reason || '') })) || evt.note || t('chat.subagent.generating', { chars: Number(evt.chars) || 0 })}${host.roleTag || ''}${host.tierTag || ''}${host.modelTag || ''}${host.driverTag || ''}${host.dependencyTag || ''}`;
      return;
    }
    if (evt.type === 'subagent_no_progress' || evt.type === 'adaptive_tool_budget') {
      // 112b: 与 subagent_progress 同一条状态行,同样按 subagentId 定位(不是 id)。
      const host = live.subCards.get(String(evt.subagentId || ''));
      if (!host || !host.status) return;
      const tags = `${host.roleTag || ''}${host.tierTag || ''}${host.modelTag || ''}${host.driverTag || ''}${host.dependencyTag || ''}`;
      if (evt.type === 'subagent_no_progress') {
        host.status.textContent = t('turnActivity.subagent.stalled', { p1: Number(evt.count) || 0 }) + tags;
        host.status.classList.remove('ok', 'err'); host.status.classList.add('warn');
      } else {
        host.status.textContent = t('turnActivity.subagent.budget', { p1: Number(evt.previousLimit) || 0, p2: Number(evt.nextLimit) || 0 }) + tags;
      }
      return;
    }
    if (evt.state === 'start') {
      if (live.subCards.has(id)) return; // idempotent (a duplicate start should never re-open)
      const d = el('details', 'subagent-card'); d.open = false; // collapsed by default (spec)
      const sum = el('summary', 'subagent-head');
      const task = String(evt.task || '').replace(/\s+/g, ' ').trim();
      const taskShort = task.length > 40 ? task.slice(0, 40) + '…' : task;
      // 安全走查 S3:项目角色被线程权限夹过时,卡片显示的是夹后的档位(evt.toolTier 已是夹后值),并如实注明。
      const tierTag = (evt.toolTier ? ` · ${evt.toolTier}` : '') + (evt.roleClamped ? t('chat.subagent.roleClamped') : '');
      const roleTag = (evt.roleLabel || evt.roleId) ? ` · ${evt.roleLabel || evt.roleId}` : '';
      const modelTag = evt.model ? ` · ${evt.model}` : '';
      const driverTag = evt.native && evt.engine === 'claude' ? t('chat.claudeNative') : '';
      const keyTag = evt.agentKey ? `[${evt.agentKey}] ` : '';
      const dependencyTag = Array.isArray(evt.dependsOn) && evt.dependsOn.length ? t('chat.subagent.dependsOn', { deps: evt.dependsOn.join(', ') }) : '';
      sum.append(
        el('span', 'sa-icon', '🤖'),
        el('span', 'sa-title', `${keyTag}${t('chat.subtask',{desc:taskShort||t('chat.noDescription')})}`),
        el('span', 'sa-status', `${t('chat.subagent.running')}${roleTag}${tierTag}${modelTag}${driverTag}${dependencyTag}`),
      );
      d.appendChild(sum);
      const body = el('div', 'subagent-body');
      d.appendChild(body);
      live.toolsWrap.appendChild(d);
      live.subCards.set(id, { d, body, status: sum.querySelector('.sa-status'), tierTag, roleTag, modelTag, driverTag, dependencyTag });
      if (evt.background === true) {
        // 代理模式 v2:后台 run 的节点 —— 卡片标成后台样式;回合结束它照跑,结果经后台任务条/信封送达。
        d.classList.add('sa-background');
        const st = sum.querySelector('.sa-status');
        if (st) { st.textContent = t('chat.agentBackground') + `${roleTag}${tierTag}${modelTag}${driverTag}${dependencyTag}`; st.classList.add('running'); }
      }
      return;
    }
    if (evt.state === 'background') {
      const host = live.subCards.get(id);
      if (host) {
        host.d.classList.add('sa-background');
        if (host.status) {
          host.status.textContent = `${t('chat.claudeBackgroundRunning')}${host.roleTag || ''}${host.tierTag || ''}${host.modelTag || ''}${host.driverTag || ''}${host.dependencyTag || ''}`;
          host.status.classList.remove('ok', 'err');
          host.status.classList.add('running');
        }
      }
      return;
    }
    if (evt.state === 'retry') {
      // v1.4.5: a Claude/CLI sub-agent's transient failure is being retried inline (bounded). Surface it
      // on the card head so the user sees "retrying" rather than a silent stall before the final ✓/✗.
      const host = live.subCards.get(id);
      if (host && host.status) host.status.textContent = t('chat.subagent.retrying', { attempt: evt.attempt || '', max: evt.maxAttempts || '', reason: (String(evt.error || evt.reason || '')).slice(0, 80) });
      return;
    }
    if (evt.state === 'end') {
      const host = live.subCards.get(id);
      if (!host) return;
      const ok = evt.ok === true;
      const backgroundAck = ok && isNativeClaudeBackgroundAck(evt);
      host.d.classList.remove('sa-background', 'sa-ok', 'sa-err');
      host.d.classList.add(backgroundAck ? 'sa-background' : (ok ? 'sa-ok' : 'sa-err'));
      // Native Claude Agent/Task calls do not stream the child's internal tool events through the
      // parent CLI. The tool_result is either a real conclusion or a background-launch receipt.
      // Keep it visible and distinguish those states; textContent preserves the normal XSS boundary.
      if (typeof evt.result === 'string' && evt.result) {
        if (!host.resultWrap) {
          host.resultWrap = el('div', 'sa-result');
          host.resultLabel = el('div', 'sa-result-label');
          host.resultPre = el('pre', 'sa-result-text');
          host.resultWrap.append(host.resultLabel, wrapPreWithCopy(host.resultPre));
          host.body.appendChild(host.resultWrap);
        }
        host.resultLabel.textContent = backgroundAck ? t('chat.claudeCliReceipt') : (ok ? t('chat.subtaskConclusion') : t('chat.subtaskError'));
        host.resultPre.textContent = evt.result;
        if (evt.resultTruncated) {
          const note = el('div', 'sa-result-note', t('chat.resultTooLong'));
          if (host.resultNote) host.resultNote.replaceWith(note);
          else host.resultWrap.appendChild(note);
          host.resultNote = note;
        }
      }
      if (host.status) {
        const chars = Number(evt.resultChars) || 0;
        host.status.textContent = backgroundAck
          ? `${t('chat.subagent.backgroundHandedOff')}${host.roleTag || ''}${host.tierTag}${host.modelTag || ''}${host.driverTag || ''}${host.dependencyTag || ''}`
          : `${ok ? t('chat.subagent.done') : t('status.failed')} · ${t('chat.subagent.resultChars', { chars })}${host.roleTag || ''}${host.tierTag}${host.modelTag || ''}${host.driverTag || ''}${host.dependencyTag || ''}`;
        host.status.classList.remove('running', 'ok', 'err');
        host.status.classList.add(backgroundAck ? 'running' : (ok ? 'ok' : 'err'));
      }
      if (!ok) host.d.open = true; // surface a failed sub-turn automatically
    }
  }

  // v1.0.2 (F1d): 计划决策状态的前端持久化。实证:持久化的会话消息里【没有】planId / 计划决策字段 —— 计划在
  // provider 模式下就是一条 content 以 "PLAN:" 开头的普通 assistant 消息(见交付报告 F1d 取舍说明)。因此这里用
  // localStorage 按 planId 记 { decision, note, ts },只在【本次流式生命周期】内让已决策卡保持收起(不改 server /
  // 会话 schema)。跨整页重载时,由于消息无 planId 锚点无法把决策映射回去,计划会退回普通 "PLAN:" markdown 气泡
  // —— 这是硬约束(禁改 server)下的已知降级,已在报告注明。key 前缀 wcw.plan. 。

  /* ---------------- bindings ---------------- */
  return {
    activeTurns,
    buildNarrativeSteerSegment,
    compactContext,
    mountActiveTurn,
    scheduleRender,
    sealLiveTextSegment,
    sendPrompt,
    setStreaming,
    syncStreamingUi,
    steerPendingList,
    steeredSeen,
    stopTurn,
    toggleAgentTeamTurn,
    updateAgentTeamButton,
    updateSendBtn,
  };
}

// ── perf(前端长会话):回合收尾的增量取 ─────────────────────────────────────────────────────────────────────
// 修前本页自己起的回合一收尾就整份重取会话(2000 条消息 7.8–19 MB、主线程 1.1–1.7 s),可前面那些消息手上早有:
// 回合起点服务端那条 session 事件整份下发过一次,还带着它的前缀戳 messagesStamp(02 sessionMessagesStamp)。
// 收尾时带 ?fromIndex=N&prefixStamp=S 只要 messages[N..];服务端对【此刻】的前 N 条重算戳,相等才回尾巴(信封上
// messagesFrom=N),否则回与无参 GET 逐字节相同的全量 —— 历史被改写过(撤回、压缩、惰性清理、编辑……)一律自动落回。
// 戳按【数组对象】记(WeakMap):只有「手上这份 messages 恰好就是服务端给过戳的那一份、而且没长没短」才发增量;
// 会话对象被别处整个换掉(PATCH 回包、切会话重开)就查不到戳,照旧整份取。
// 本模块零 import;导出一律写成 `export function`(vm 单测按这个前缀剥导出,别写 export const / export async)。
const sessionMessagesStamps = new WeakMap();
export function rememberMessagesStamp(messages, stamp) {
  if (Array.isArray(messages) && typeof stamp === 'string' && stamp) sessionMessagesStamps.set(messages, stamp);
}
// 手上这份 messages 服务端给过戳、且没长没短 → { count, stamp };否则 null(只能整份)。
export function knownMessagesFor(base) {
  const messages = base && Array.isArray(base.messages) ? base.messages : null;
  const stamp = messages ? sessionMessagesStamps.get(messages) : '';
  if (!stamp || !stamp.startsWith(`m1.${messages.length}.`)) return null;
  return { count: messages.length, stamp };
}
// 回合收尾该发哪一发:能增量就带参数,否则就是修前那条无参路径(逐字不变)。
export function sessionRefetchPath(sessionId, base) {
  const path = `/api/sessions/${sessionId}`;
  const known = knownMessagesFor(base);
  if (!known) return path;
  return `${path}?fromIndex=${known.count}&prefixStamp=${encodeURIComponent(known.stamp)}`;
}
// 把增量回包拼回与全量同形的信封:session.messages = 手上前 N 条 + 尾巴(新数组,不动任何人手里的旧数组),
// 去掉 messagesFrom / messageCount / messagesStamp 三个增量专用键(新戳记到新数组上,下次还能接着增量)。
// 回包本身就是全量(服务端落回了)→ 原样返回;拼不上(前缀在请求期间长短变了、条数自检不符)→ null,调用方整份重取。
export function spliceSessionDelta(prefix, payload) {
  if (!payload || !payload.session || !Number.isInteger(payload.messagesFrom)) return payload;
  const tail = Array.isArray(payload.session.messages) ? payload.session.messages : null;
  if (!Array.isArray(prefix) || !tail || prefix.length !== payload.messagesFrom
    || prefix.length + tail.length !== payload.messageCount) return null;
  const { messagesFrom: _from, messageCount: _count, messagesStamp, ...envelope } = payload;
  const messages = prefix.concat(tail);
  rememberMessagesStamp(messages, messagesStamp);
  return { ...envelope, session: { ...payload.session, messages } };
}
// 回合收尾(与失败/中止路径)取会话:返回与无参 GET 同形的信封(增量时 session 上没有 providerHistory —— 前端从不读它)。
export function fetchSessionAfterTurn(api, sessionId, base) {
  const fullPath = `/api/sessions/${sessionId}`;
  const path = sessionRefetchPath(sessionId, base);
  if (path === fullPath) return api(fullPath);
  const prefix = base.messages;   // 请求发出这一刻的那一个数组;回包时它的长度必须还是 N(见 spliceSessionDelta)
  return api(path).then(payload => spliceSessionDelta(prefix, payload) || api(fullPath));
}
