'use strict';

// EC-D：主题、界面密度、工作区选择与最近工作区领域。
import { state } from './state.js';
import { api } from './net.js';
import { $, el, toast, visibleFavoriteWorkspaces, stripWrappingQuotes, looksAbsolutePath } from './util.js';   // 两个纯判定住 util.js：顶栏粘贴路径与设置页「添加/默认工作文件夹」共用同一口径
import { t } from './i18n.js';
import { icon } from './icons.js';

export function createWorkspacePreferencesDomain({
  apiErrText = error => String(error && error.message || error || ''),
  saveConfigPartial = async () => false,
  iconTextBtn = () => {},
  syncMoreMenuLabels = () => {},
  normalizeTabsForUiMode = () => {},
  newSession = async () => {},
  patchSession = async () => {},
  loadFileTree = async () => {},
  popover = () => null,
} = {}) {
function effectiveTheme(pref) {
  return pref === 'system'
    ? (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    : (pref === 'light' ? 'light' : 'dark');
}
function themeOverrideFromUrl() {
  try {
    const value = new URLSearchParams(window.location.search).get('theme');
    return value === 'dark' || value === 'light' ? value : '';
  } catch { return ''; }
}
let _themeMediaWired = false;
function applyTheme(theme) {
  // Deterministic visual-regression entry point. It affects only this page load and never broadens the
  // persisted three-state preference contract.
  const forced = themeOverrideFromUrl();
  const pref = forced || (theme === 'light' || theme === 'dark' ? theme : 'system');   // 体验走查 #17：没存过／未知值＝跟随系统
  const eff = effectiveTheme(pref);
  // v1.0.2 (F5): 同 applyUiMode —— 值未变不重写 data-theme,避免 config 到达后与预绘同值时的无谓重排。
  // 主题预绘(index.html)默认 'system',与 server defaultConfig().theme 一致(体验走查 #17),新装机无闪;此处仅回写 localStorage。
  if (document.documentElement.getAttribute('data-theme') !== eff) document.documentElement.setAttribute('data-theme', eff);
  $('hljs-dark').disabled = eff !== 'dark';
  $('hljs-light').disabled = eff === 'dark';
  const tbtn = $('themeToggle');
  if (tbtn) {
    iconTextBtn(tbtn, pref === 'system' ? 'monitor' : 'theme', '');
    tbtn.title = t('navigation.switchTheme') + ' · ' + t('navigation.theme.' + pref);
    tbtn.setAttribute('aria-label', tbtn.title);
  }
  // system 档监听 OS 主题变更(注册一次;非 system 档变更时无害——applyTheme 只在 pref=system 时响应)。
  if (!_themeMediaWired && window.matchMedia) {
    _themeMediaWired = true;
    try {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
        let cur = 'dark'; try { cur = localStorage.getItem('wcw.theme') || 'dark'; } catch { /* ignore */ }
        if (cur === 'system') applyTheme('system');
      });
    } catch { /* ignore */ }
  }
  if (!forced) { try { localStorage.setItem('wcw.theme', pref); } catch { /* ignore */ } }
}
function toggleTheme() {
  const cur = (() => { try { return localStorage.getItem('wcw.theme') || 'system'; } catch { return 'system'; } })();
  const next = cur === 'dark' ? 'light' : cur === 'light' ? 'system' : 'dark';
  applyTheme(next);
  saveConfigPartial({ theme: next });
}

/* ---------------- v0.9-S1 (C1): uiMode simple/pro ---------------- */
// Mirrors applyTheme: sets [data-ui-mode] (CSS drives the simple-mode hides + font bump), swaps the toggle
// glyph/title, and caches to localStorage so the head pre-paint avoids a flash on next load.
function applyUiMode(mode) {
  const m = mode === 'simple' ? 'simple' : 'pro';
  // v1.0.2 (F5): 值未变时不写 DOM 属性(避免无谓的样式重算/重排 —— 尤其 config 到达后 applyUiMode 常与
  // 预绘值相同)。localStorage 仍回写以保证下次预绘一致。
  const cur = document.documentElement.getAttribute('data-ui-mode');
  if (cur !== m) document.documentElement.setAttribute('data-ui-mode', m);
  // v1.5 (§3.4): 密度随分级联动 —— 简易=舒适(更大点击区/留白)、专家=紧凑(信息密度高)。data-density
  // 驱动间距/点击区 token 缩放(styles.css [data-density] 块)。与 data-ui-mode 同步写,避免脱钩。
  const dens = m === 'simple' ? 'comfortable' : 'compact';
  if (document.documentElement.getAttribute('data-density') !== dens) document.documentElement.setAttribute('data-density', dens);
  // v3 (§B2): agent-runs 页签在简易模式显示「AI 工作」(聚合工作流+用量/审计 mini 入口),专家模式保留「Agent 工作流」。
  { const tab = document.querySelector('.tool-pane .tool-tabs button[data-tab="agent-runs"]'); if (tab) tab.textContent = (m === 'simple' ? t('workflow.simpleTitle') : t('workflow.title')); }
  const btn = $('uiModeToggle');
  if (btn) {
    // 第89波 emoji 清零:界面模式切换与 themeToggle 同走 icons.js(精简=sparkles / 专家=toolbox)。
    iconTextBtn(btn, m === 'simple' ? 'sparkles' : 'toolbox', '');
    btn.title = t(m === 'simple' ? 'navigation.switchToExpert' : 'navigation.switchToSimple');
    btn.setAttribute('aria-label', t('navigation.toggleUiMode'));
  }
  try { localStorage.setItem('wcw.uiMode', m); } catch { /* ignore */ }
  // v1.0-S2 (IA): 更新「⋯」菜单里的界面模式项文案（若菜单当前打开）。
  syncMoreMenuLabels();
  normalizeTabsForUiMode(m);
}
function toggleUiMode() {
  const next = document.documentElement.getAttribute('data-ui-mode') === 'simple' ? 'pro' : 'simple';
  applyUiMode(next);
  if (state.config) state.config.uiMode = next;
  saveConfigPartial({ uiMode: next });
  toast(next === 'simple' ? t('toast.uiModeSimple') : t('toast.uiModeExpert'), 'ok');
}

/* ---------------- v0.9-S3 (C3): working-folder ---------------- */
// The effective working folder for the CURRENT session: session.cwd first (set by the picker / folder-drag
// switch), falling back to the configured defaultWorkspace, then '' (server folds that to home). The turn
// sender (sendPrompt) uses THIS as the request cwd so a per-session switch actually drives the next turn.
function currentWorkspace() {
  return (state.currentSession && state.currentSession.cwd) || (state.config && state.config.defaultWorkspace) || '';
}
// Reflect the top-bar picker: short (basename) label + full path in the title. Called on boot, session
// switch, and after a workspace change.
function renderWorkspacePicker() {
  const btn = $('workspacePicker'); if (!btn) return;
  const full = currentWorkspace();
  const nameEl = btn.querySelector('.wp-name');
  // basename that tolerates both \ and / and a trailing separator.
  const short = full ? (full.replace(/[\\/]+$/, '').split(/[\\/]/).pop() || full) : t('navigation.workbench');
  if (nameEl) nameEl.textContent = short;         // textContent → XSS-safe (paths are attacker-influenced)
  btn.title = full || t('workspace.select');
  // v2.7.2: 文件面板常用工作区 chips 与顶栏选择器同步刷新(boot/会话切换/工作区变更均经此)。
  renderWorkspaceFavChips();
}
// 代码走查 C14:同一个文件夹带不带结尾的「\」、用「\」还是「/」都是同一个(Windows 不分大小写)。修前只比小写,
// 粘贴一个带结尾斜杠的路径就多出一条重复的常用文件夹。存的时候去掉结尾分隔符(盘符根 C:\ 与 / 保留)。
const folderKey = p => String(p || '').trim().replace(/[\\/]+$/, '').replace(/\\/g, '/').toLowerCase();
function trimFolderPath(p) {
  const s = String(p || '').trim();
  const stripped = s.replace(/[\\/]+$/, '');
  if (!stripped || /^[A-Za-z]:$/.test(stripped)) return s.slice(0, stripped.length + 1);
  return stripped;
}
// LRU-insert a path at the front of config.recentWorkspaces (≤10, de-duped case-insensitively).
// Persistence is deliberately owned by setWorkspace, which writes recentWorkspaces + favorite workspaces in
// one POST. The old two-fire-and-forget-write path could race and resurrect the stale favorite list on restart.
function pushRecentWorkspace(p) {
  if (!p) return [];
  const prev = Array.isArray(state.config.recentWorkspaces) ? state.config.recentWorkspaces : [];
  const filtered = prev.filter(w => folderKey(w) !== folderKey(p));
  const next = [p, ...filtered].slice(0, 10);
  state.config.recentWorkspaces = next;
  return next;
}
// Switch the current session's working folder to `dir`. Persists session.cwd (patchSession) + LRU + toast +
// refreshes the picker and the file tree (if its tab is showing). When alsoDefault is true, also writes
// config.defaultWorkspace (the 「设为默认工作区」 secondary option).
async function setWorkspace(dir, { alsoDefault = false } = {}) {
  dir = trimFolderPath(dir);
  if (!dir) return;
  // 走查 U1：还没有线程时（首跑引导「用一个专用文件夹」就是这样）选文件夹 = 以后新线程的默认文件夹。
  // 修前这里先建一条空线程再改它的文件夹 —— 新用户一进来就有一条「排队」的空线程，管家还说「你回来了」。
  if (!state.currentSession) alsoDefault = true;
  else {
    try {
      await patchSession(state.currentSession.id, { cwd: dir });
    } catch (e) { toast(t('workspace.switch.failed', { reason: apiErrText(e) }), 'err'); return; }
  }
  const recent = pushRecentWorkspace(dir);
  // Browsing/pasting a folder is also the natural "add favorite" action in this picker. Keep the existing
  // primary first and append a new folder; only the explicit alsoDefault path promotes it to index 0.
  const ws = (Array.isArray(state.config.workspaces) ? state.config.workspaces : [])
    .map(w => ({ path: w.path, read: w.read !== false, write: w.write !== false, execute: w.execute !== false }));
  let idx = ws.findIndex(w => folderKey(w.path) === folderKey(dir));
  if (idx < 0) { ws.push({ path: dir, read: true, write: true, execute: true }); idx = ws.length - 1; }
  if (alsoDefault && idx > 0) { const [x] = ws.splice(idx, 1); ws.unshift(x); }
  const defaultWorkspace = alsoDefault ? dir : (ws[0]?.path || state.config.defaultWorkspace || dir);
  state.config.workspaces = ws;
  state.config.defaultWorkspace = defaultWorkspace;
  await saveConfigPartial({ recentWorkspaces: recent, workspaces: ws, defaultWorkspace });
  if (alsoDefault) {
    // 同步设置面板的默认工作区输入框：fillSettings 仅在 boot 与 doctor tab 时被调，
    // 不在此刷新则用户打开设置看到旧值，点保存还会把后端 defaultWorkspace 回写成旧值（数据丢失）。
    const wi = document.getElementById('workspaceInput');
    if (wi && document.activeElement !== wi) wi.value = dir;
  }
  renderWorkspacePicker();
  const treeTabActive = document.querySelector('.tool-pane .tool-tabs button[data-tab="files"]')?.classList.contains('active');
  if (treeTabActive) loadFileTree();
  toast(t('workspace.switch.success', { directory: dir }), 'ok');
}
// Native folder dialog → on success, switch the workspace. Shared by the picker popover's 浏览 button.
// 返回 { ok, path?, cancelled?, error?, hint? } —— 向导据此就地说清「为什么没弹出来、该怎么办」并露出手填框
// （走查 #8：修前失败只有一闪而过的 toast，被向导弹层盖着，看起来就是「点了没反应」）。
async function pickWorkspaceNative({ alsoDefault = false } = {}) {
  toast(t('workspace.picker.opening'), '');
  let r;
  // 3.0 收口:对话框从【当前工作文件夹】打开(服务端只认本机盘符绝对路径,别的忽略),标题说清这一次在选什么。
  const body = JSON.stringify({ title: t('workspace.chooseTitle'), initialDir: currentWorkspace() });
  try { r = await api('/api/pick-folder', { method: 'POST', body }); }
  catch (e) { toast(t('workspace.picker.failed', { reason: apiErrText(e) }), 'err'); return { ok: false, error: apiErrText(e) }; }
  if (!r || !r.ok) {
    // 服务端把错误包成 {code, message} 信封：取人话那一句（修前 toast 里是「[object Object]」）。
    const raw = r && r.error;
    const error = typeof raw === 'string' ? raw : (raw && typeof raw.message === 'string' ? raw.message : '');
    toast(t('workspace.picker.failed', { reason: `${error || t('common.unknown')}${r && r.hint ? ' (' + r.hint + ')' : ''}` }), 'err');
    return { ok: false, error, hint: String((r && r.hint) || '') };
  }
  if (r.cancelled) return { ok: true, cancelled: true }; // silent — user backed out
  if (r.path) await setWorkspace(r.path, { alsoDefault });
  return { ok: true, path: r.path || '' };
}
// v1.0.2 (G6): 顶栏工作文件夹选择器点击 → 小 popover:「浏览文件夹…」(原生选择器,主力) + 「或粘贴文件夹路径」
// 输入框(兜底,视觉次要)。粘贴路径:前端仅初查非空 + 看起来是绝对路径,然后走现有 setWorkspace(带 cwd 护栏);
// 无效路径后端会拒,toast 其错误。回车提交。
// v1.0.2 返修(stripWrappingQuotes／looksAbsolutePath 现住 util.js):Windows「复制文件地址」会给路径包上双引号("C:\path"),部分终端复制还带单引号/全角引号——
// 先剥掉成对的包裹引号再校验,否则用户按系统习惯复制的路径全被误拒。只剥【成对且在首尾】的引号,不动路径内部。
// 3.0 收口:校验失败就地说(onError 写进弹层里输入框下面那一行),不再一闪而过的 toast —— 弹层开着,用户眼睛在输入框上。
// 没传 onError 的老调用方照旧 toast。
async function submitPastedWorkspace(input, close, onError) {
  const raw = stripWrappingQuotes(input.value);
  const fail = key => { if (typeof onError === 'function') onError(t(key)); else toast(t(key), 'err'); input.focus(); };
  if (!raw) { fail('workspace.pathRequired'); return; }
  if (!looksAbsolutePath(raw)) { fail('workspace.pathAbsoluteRequired'); return; }
  if (close) close();
  await setWorkspace(raw); // 现有链路带 cwd 护栏与人话警告;无效路径后端拒并 toast
}
/* ---------------- v2.7.2: 常用工作区优先级(对话页快速调整) ---------------- */
// 「常用工作区」= config.workspaces(priority-ordered,index 0 = 默认/最高优先级,由后端 normalize 与
// defaultWorkspace 同步)。这里提供对话页快速切换 + ↑↓/★ 调整优先级,与设置页「工作区权限」同一数据源。
// W7(用户 2026-09-24「如意自己开的工作区,默认不显示在常用工作区中」):显示用 favoriteList(去掉如意
// 自己的目录,判据见 util.js isRuyiOwnedWorkspace),保存用 allFavorites(整张表)—— 只在显示时过滤,
// 保存整张表,否则藏起来的行会在下一次调整优先级时被删掉。服务端已把老版本塞进来的如意目录挪了出去,
// 这里是第二道:数据目录里的路径一律不当常用工作区显示。
function allFavorites() {
  return Array.isArray(state.config.workspaces) ? state.config.workspaces : [];
}
function favoriteList() {
  return visibleFavoriteWorkspaces(allFavorites(), {
    dataRoot: (state.status && state.status.dataRoot) || '',
    dataRootAliases: (state.status && state.status.dataRootAliases) || [],
    owned: state.config.stewardManagedWorkspaces,
  });
}
function workspaceShortName(p) {
  const s = String(p || '');
  return s ? (s.replace(/[\\/]+$/, '').split(/[\\/]/).pop() || s) : '';
}
function persistWorkspaces(ws, defaultPath) {
  state.config.workspaces = ws;
  state.config.defaultWorkspace = defaultPath || (ws.length ? ws[0].path : state.config.defaultWorkspace);
  saveConfigPartial({
    workspaces: ws.map(w => ({ path: w.path, read: w.read !== false, write: w.write !== false, execute: w.execute !== false })),
    defaultWorkspace: state.config.defaultWorkspace,
  });
  renderWorkspacePicker();
}
// 上移/下移(调整优先级顺序);from/to 触碰 0 时 defaultWorkspace 同步(后端 normalize 同样兜底)。
// from/to 是【显示列表】里的下标(↑↓ 只在相邻两行之间动);落到整张表上就是交换这两行的位置,
// 中间夹着的隐藏行原地不动。
function reorderFavorite(from, to) {
  const visible = favoriteList();
  if (!visible.length || from < 0 || from >= visible.length || to < 0 || to >= visible.length || from === to) return;
  const ws = allFavorites();
  const a = ws.indexOf(visible[from]);
  const b = ws.indexOf(visible[to]);
  if (a < 0 || b < 0) return;
  [ws[a], ws[b]] = [ws[b], ws[a]];
  persistWorkspaces(ws, ws[0].path);
}
// 置顶 = 设为最高优先级(同时也是默认工作区)。
function promoteFavorite(dir) {
  const ws = allFavorites();
  const idx = ws.findIndex(w => folderKey(w.path) === folderKey(dir));
  if (idx <= 0) return; // 已在首位或不存在
  const [x] = ws.splice(idx, 1); ws.unshift(x);
  persistWorkspaces(ws, x.path);
}
// 弹层里的一行文件夹:左边文件夹图标,中间「名字 + 完整路径」两行(路径过长时从【左边】省略,留住最有辨识度的末几级),
// 整块是一枚按钮(键盘可达,回车 / 空格即切换);当前文件夹打「当前」标。行尾动作钮(只有常用工作区有)悬停或键盘聚焦时出现。
// 3.0 收口(用户「选择路径的界面太古老」):修前一行只有一个名字,同名文件夹分不清,完整路径只在悬停提示里。
function workspaceRow(p, { current = false, onPick, actions = [] } = {}) {
  const row = el('div', 'wp-fav-item' + (current ? ' current' : ''));
  const main = el('button', 'wp-fav-main'); main.type = 'button'; main.title = p;
  const ic = icon('folder', 16); if (ic) { ic.classList.add('wp-fav-icon'); main.append(ic); }
  const text = el('span', 'wp-fav-text');
  const nameLine = el('span', 'wp-fav-nameline');
  nameLine.append(el('span', 'wp-fav-name', workspaceShortName(p)));
  if (current) nameLine.append(el('span', 'wp-fav-badge', t('workspace.currentBadge')));
  const pathEl = el('span', 'wp-fav-path');
  pathEl.append(el('bdi', '', p));   // 外层 direction:rtl 让省略号落在左边;bdi 保证路径本身按从左到右读
  text.append(nameLine, pathEl);
  main.append(text);
  main.onclick = () => onPick(p);
  if (current) main.setAttribute('aria-current', 'true');
  row.append(main);
  if (actions.length) {
    const btns = el('span', 'wp-fav-btns');
    for (const a of actions) {
      const b = el('button', 'wp-fav-btn'); b.type = 'button'; b.title = a.title; b.setAttribute('aria-label', a.title + ' · ' + workspaceShortName(p));
      const glyph = icon(a.icon, 14); if (glyph) b.append(glyph);
      if (a.disabled) b.disabled = true;
      b.onclick = e => { e.stopPropagation(); a.run(); };
      btns.append(b);
    }
    row.append(btns);
  }
  return row;
}
// popover 内的常用工作区列表。行点击=切换会话 cwd 并收起弹层;上移 / 下移 / 设为默认就地调整优先级(不关弹层,实时刷新)。
function renderFavoritesInto(close) {
  const list = el('div', 'wp-fav-list');
  const pick = p => { if (close) close(); setWorkspace(p); };
  const refresh = () => {
    const ws = favoriteList();
    const cur = currentWorkspace();
    list.textContent = '';
    if (!ws.length) { list.append(el('div', 'wp-fav-empty', t('workspace.favorites.empty'))); return; }
    ws.forEach((w, i) => {
      const p = String(w.path || ''); if (!p) return;
      const after = fn => () => { fn(); refresh(); };
      list.append(workspaceRow(p, {
        current: folderKey(p) === folderKey(cur),
        onPick: pick,
        actions: [
          { icon: 'up', title: t('workspace.favorites.up'), disabled: i === 0, run: after(() => reorderFavorite(i, i - 1)) },
          { icon: 'down', title: t('workspace.favorites.down'), disabled: i === ws.length - 1, run: after(() => reorderFavorite(i, i + 1)) },
          { icon: 'pin', title: t('workspace.favorites.promote'), disabled: i === 0, run: after(() => promoteFavorite(p)) },
        ],
      }));
    });
  };
  refresh();
  return list;
}
// 「最近用过」:config.recentWorkspaces 里不在常用工作区的那几条(最多 4 条)。选中后 setWorkspace 会顺手把它加进常用。
function recentOnlyWorkspaces() {
  const fav = new Set(allFavorites().map(w => folderKey(w.path)));
  const recent = Array.isArray(state.config && state.config.recentWorkspaces) ? state.config.recentWorkspaces : [];
  const seen = new Set();
  const out = [];
  for (const p of recent) {
    const key = folderKey(p);
    if (!p || fav.has(key) || seen.has(key)) continue;
    seen.add(key);
    out.push(String(p));
    if (out.length >= 4) break;
  }
  return out;
}
// 工具面板「文件」tab 的常用工作区快速切换条(chips)。点击切换会话 cwd + 刷新文件树;当前高亮。
function renderWorkspaceFavChips() {
  const box = $('workspaceFavChips'); if (!box) return;
  const ws = favoriteList();
  const cur = currentWorkspace();
  box.textContent = '';
  if (!ws.length) return;
  ws.forEach(w => {
    const p = String(w.path || ''); if (!p) return;
    const chip = el('button', 'ws-fav-chip' + (folderKey(p) === folderKey(cur) ? ' current' : ''), workspaceShortName(p));
    chip.type = 'button'; chip.title = p;
    chip.onclick = () => setWorkspace(p);
    box.append(chip);
  });
}
function pickWorkspace(anchor) {
  // Preview has its own visible workspace fact. Accept an explicit anchor so the shared picker
  // opens beside the control the user actually pressed; classic onclick still passes a MouseEvent
  // and therefore falls back to #workspacePicker.
  const btn = anchor && anchor.nodeType === 1 ? anchor : $('workspacePicker'); if (!btn) return;
  popover(btn, close => {
    const wrap = el('div', 'wp-pop');
    // 3.0 收口:从上到下 = 主力动作(浏览,系统文件夹窗口)→ 常用工作区 → 最近用过 → 粘贴路径兜底。
    const browse = el('button', 'wp-pop-browse'); browse.type = 'button';
    const browseIcon = icon('folder', 18); if (browseIcon) browse.append(browseIcon);
    const browseText = el('span', 'wp-pop-browse-text');
    browseText.append(el('span', 'wp-pop-browse-label', t('workspace.browse')), el('span', 'wp-pop-browse-hint', t('workspace.browseHint')));
    browse.append(browseText);
    browse.onclick = () => { close(); pickWorkspaceNative(); };
    wrap.append(browse);
    // v2.7.2: 常用工作区(按优先级)— 快速切换 + 上移 / 下移 / 设为默认。
    const favTitle = el('div', 'wp-fav-title', t('workspace.favorites'));
    favTitle.title = t('workspace.favorites.hint');
    wrap.append(favTitle, renderFavoritesInto(close));
    const recent = recentOnlyWorkspaces();
    if (recent.length) {
      wrap.append(el('div', 'wp-fav-title', t('workspace.recent')));
      const list = el('div', 'wp-fav-list wp-recent-list');
      for (const p of recent) list.append(workspaceRow(p, { onPick: q => { close(); setWorkspace(q); } }));
      wrap.append(list);
    }
    const pasteLabel = el('label', 'wp-pop-or', t('workspace.pastePath'));
    const row = el('div', 'wp-pop-row');
    const input = el('input', 'wp-pop-input'); input.type = 'text'; input.placeholder = t('workspace.pastePlaceholder');
    input.id = 'wpPopPathInput'; pasteLabel.htmlFor = input.id;
    input.spellcheck = false; input.autocomplete = 'off';
    const err = el('div', 'wp-pop-err'); err.setAttribute('role', 'alert'); err.hidden = true;
    // 弹层本身有 max-height(60vh)且可滚:常用 + 最近较多时错误行可能落在可视区外,出现时滚到看得见。
    const showErr = msg => { err.textContent = msg; err.hidden = !msg; input.setAttribute('aria-invalid', msg ? 'true' : 'false'); if (msg && typeof err.scrollIntoView === 'function') err.scrollIntoView({ block: 'nearest' }); };
    input.addEventListener('input', () => { if (!err.hidden) showErr(''); });
    input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); submitPastedWorkspace(input, close, showErr); } });
    const go = el('button', 'wp-pop-go', t('workspace.switch')); go.type = 'button';
    go.onclick = () => submitPastedWorkspace(input, close, showErr);
    row.append(input, go);
    wrap.append(pasteLabel, row, err);
    setTimeout(() => { browse.focus(); }, 0);
    return wrap;
  }, { placement: 'bottom-start' });
}

/* ---------------- sessions ---------------- */
  return Object.freeze({
    applyTheme,
    applyUiMode,
    currentWorkspace,
    pickWorkspace,
    pickWorkspaceNative,
    renderWorkspaceFavChips,
    renderWorkspacePicker,
    setWorkspace,
    toggleTheme,
    toggleUiMode,
  });
}
