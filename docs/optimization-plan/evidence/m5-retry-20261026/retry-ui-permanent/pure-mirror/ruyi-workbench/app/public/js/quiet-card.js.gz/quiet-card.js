'use strict';

import { byId, doc, el, clear } from './steward-chips.js';
import { icon } from './icons.js';
import { stewardThreadHueFor } from './steward-conversation.js';
import { isQuietSuppressed, readNotifySettings } from './notify-policy.js';
import { apiErrorInfo, NETWORK_ERROR_CODE } from './net.js';   // 走查 S-10：候选答案失败要分「断网（卡留着可重试）」与「那件事已经过去了（撤卡）」

// ─────────────────────────────────────────────────────────────────────────────
// quiet-card.js — 安静卡（121 波 K6a，34 号文 §4.3「在场信号与打扰纪律」／§2.6）。
//
// 工作台里管家的唯一打扰形态：用户在工作台、坐在【别的】线程上时，管家开的（或被交给管家盯的）
// 线程有事要说，右下角起一张卡——不弹窗、不切视角、不抢焦点（本体 aria-live="polite"，按钮可
// Tab 到但不自动 focus，见 mount() 里【没有】任何 .focus() 调用）。
//
// 数据源：src/13i-steward-inbox.js 的在场门已经把「要不要出卡」判完（②情形打 payload.quiet:true），
// 本文件【只消费】事件流的 inbox.appended 帧（quiet／ask／options／interventionId／answerQuestionId），
// 不重新判一次在场——但仍在客户端补两条属于渲染层、不属于在场门的规则：
//   · 视角必须是工作台（data-shell-mode==='classic'）——管家视角下服务端在场门③已经不会给这类
//     事件打 quiet，这里只是双保险，不新起第二套判据；
//   · 静默时段（js/notify-policy.js 的 quietStart／quietEnd）——不出卡，只让左栏（已经在吃
//     thread.needs_you／thread.state 那几路推送）照常更新。走查 S-15：时段只在用户【开启了本机通知】时才生效
//     （isQuietSuppressed）；默认 enabled:false 而时段默认 22:00–08:00，不这样限定，没动过设置的人夜里就收不到卡。
//
// 去重／基线／静默三件事全部问 notify-policy.js 要（isQuietTime 直接复用）；系统通知的「去重」
// 没有套用它的 reconcileNotifications——那份 API 是为轮询快照设计的（每一拍给「当前完整待决集合」，
// 靠 primed 基线避免启动时把历史积压一次性炸出来）。安静卡是纯事件驱动：每一帧都是刚刚发生的
// 新鲜事（13i 自己的 30s 合并窗 + 本文件的 5 分钟同线程同类合并已经把重复摊平成一次「新建」），
// 不存在「启动时的历史积压」——所以系统通知按「只在新建卡片那一刻发一次」去重，足够、且不必再引入
// 第二套为快照设计的状态机。
// ─────────────────────────────────────────────────────────────────────────────

export const QUIET_CARD_MERGE_WINDOW_MS = 5 * 60 * 1000; // §4.3：5 分钟同线程同类合并成一张
export const QUIET_CARD_HOST_ID = 'quietCardHost';
// done 永不出卡（§4.3 明说）；服务端的在场门②本来就不会给 done 打 quiet:true，这里再挡一次
// 双保险——反向验证（拔掉这道过滤）在 quiet-card.browser.e2e.js 里钉。
// 123-M2（37 号文 §3.5）：第五类 reminder —— 定时任务到点／错过跳过／连败熔断。它与前四类的
// 不同在于**它可以不属于任何一条线程**：「明天九点提醒我交周报」那条 reminder 没有 sessionId，
// 而前四类恒有（它们都在说某条线程怎么样了）。所以下面 isEligible 对它松一格，卡的身份改用
// quietCardIdentity（无线程时退到 taskId）。
export const QUIET_CARD_KINDS = Object.freeze(['needs_you', 'failed', 'stalled', 'budget', 'reminder']);

export function quietCardKey(sessionId, kind) {
  return `${String(sessionId || '')}|${String(kind || '')}`;
}
// 一张卡的身份：有线程就是线程，没有线程（只可能是 reminder）就是那条定时任务。
// **不能只用 kind**：那样两条不同的提醒会互相合并成一张，第二条的正文把第一条顶掉。
export function quietCardIdentity(frame) {
  const sessionId = String((frame && frame.sessionId) || '');
  if (sessionId) return sessionId;
  const taskId = String((frame && frame.taskId) || '');
  return taskId ? `task:${taskId}` : '';
}

// needs_you 印问句前 22 字；failed/stalled/budget 印一句事实（同一个 ask 字段，见 13i 头注）。
export function quietCardHeadline(kind, ask) {
  const text = String(ask || '').trim();
  if (!text) return '';
  return kind === 'needs_you' && text.length > 22 ? text.slice(0, 22) + '…' : text;
}

// 123-M2（37 号文 §3.5）：「稍后」＝真 snooze。它建的是一条【真的】 once reminder，
// 而不是把卡藏起来——修前按下去只是 removeCard()，那件事从此再也不会回来，「稍后」在说谎。
export const QUIET_CARD_SNOOZE_PATH = '/api/scheduler/tasks';
export const QUIET_CARD_SNOOZE_MINUTES_DEFAULT = 30;   // 与 01-config 的 quietCardSnoozeMinutes 出厂值同数
// 本地墙钟的 {date, at}：29 号文 §4「只存本地时区语义」——不能拿 toISOString()（那是 UTC）。
export function quietCardSnoozeSchedule(atMs) {
  const when = new Date(Number(atMs));
  const p2 = n => String(n).padStart(2, '0');
  return {
    kind: 'once',
    date: `${when.getFullYear()}-${p2(when.getMonth() + 1)}-${p2(when.getDate())}`,
    at: `${p2(when.getHours())}:${p2(when.getMinutes())}`,
  };
}

export function createQuietCard({
  t = key => key,
  state = null,
  api = async () => null,
  // 稍后失败时的一句提示（组合根注入 util.js 的 toast；缺席时静默——卡本来就没收，用户看得见）。
  notifyFailure = () => {},
  // 推迟多少分钟：唯一事实源是服务端的 config.quietCardSnoozeMinutes（01-config 已钳 [1,1440]），
  // 客户端不抄第二份钳位，读不到就用出厂值。
  snoozeMinutesOf = () => QUIET_CARD_SNOOZE_MINUTES_DEFAULT,
  // 当前视角：唯一状态源是 documentElement 的 data-shell-mode（js/shell-mode.js 写），本文件不
  // 缓存第二份、只读。
  shellModeOf = () => { const d = doc(); return d ? String(d.documentElement.dataset.shellMode || '') : ''; },
  // 左栏已经取回来的那一行（GET /api/missions）——问它要任务名与色号，不裸发第二份（thread-head.js
  // 同一手法：missionRowOf 由 steward-shell.js 迟绑定到 board.missionRowFor）。
  missionRowOf = () => null,
  // 「去看」＝换焦点／选中该会话，不切视角（安静卡只在工作台出现，本来就不需要切）。
  openSession = async () => {},
  notifySettingsOf = () => readNotifySettings(),
  notificationApi = globalThis.Notification,
  now = () => Date.now(),
} = {}) {
  const cards = new Map(); // key -> { node, sessionId, kind, count, updatedAt, frame }
  const notified = new Set(); // 已经发过系统通知的 key（同一张卡合并更新期间不再发第二次）

  function host() {
    return byId(QUIET_CARD_HOST_ID);
  }
  function currentSessionId() {
    return state && state.currentSession ? String(state.currentSession.id || '') : '';
  }
  // 桌面壳（WebView2）的宿主桥：有就返回那个 webview 对象（postMessage 住在上面），没有就 null。
  // 走查 S-09：修前桌面壳里 notificationPermission() 恒报 'granted'，可投递仍只用 new Notification(...)，而 WebView2 里
  // Notification 的真实权限是 default —— 静默不显示；宿主（RuyiDesktop.cs OnWebMessage）等的是
  // chrome.webview.postMessage({ ruyiNotification:{ title, body } })，前端却再没有任何一处发送方。
  function desktopBridge() {
    const bridge = globalThis.chrome && globalThis.chrome.webview;
    return globalThis.__ruyiDesktop === 1 && bridge && typeof bridge.postMessage === 'function' ? bridge : null;
  }
  function notificationPermission() {
    if (desktopBridge()) return 'granted';
    return notificationApi && typeof notificationApi.permission === 'string' ? notificationApi.permission : 'unsupported';
  }

  function isEligible(frame) {
    if (!frame || frame.quiet !== true) return false;
    if (!QUIET_CARD_KINDS.includes(String(frame.kind || ''))) return false;
    const sessionId = String(frame.sessionId || '');
    // 123-M2：reminder 允许没有线程（「九点提醒我交周报」不属于任何线程），但仍要有一个身份
    // ——否则两条提醒会合并成一张。其余四类必须有 sessionId（它们讲的就是某条线程的事）。
    if (!quietCardIdentity(frame)) return false;
    if (!sessionId && String(frame.kind || '') !== 'reminder') return false;
    if (shellModeOf() !== 'classic') return false;          // 只在工作台
    if (sessionId && sessionId === currentSessionId()) return false; // 不是当前坐着的那条（双保险）
    return true;
  }

  function removeCard(key) {
    const entry = cards.get(key);
    if (!entry) return false;
    try { entry.node.remove(); } catch { /* 已经不在树上 */ }
    cards.delete(key);
    notified.delete(key);
    return true;
  }

  // 走查 S-10：卡片的「该不该还在」此前只在【新帧 upsert】时才顺手核一次（dismissStale），问题在别处答了／线程收工了／
  // 人已经点进那条线程，卡都不撤。下面几个撤卡口由事件流与会话切换驱动，不靠计时器。
  function removeCardsOf(sessionId, kinds) {
    const sid = String(sessionId || '');
    if (!sid) return 0;
    let removed = 0;
    for (const [key, entry] of [...cards]) {
      if (entry.sessionId !== sid) continue;
      if (kinds && !kinds.includes(entry.kind)) continue;
      if (removeCard(key)) removed += 1;
    }
    return removed;
  }
  // 人已经坐在这条线程上了：它的卡再留着只会重复说同一件事。
  function dismissCurrent() {
    return removeCardsOf(currentSessionId());
  }
  // thread.state：这条线程不再「等你」了（答完了／被停了／回合重新跑起来了）→ 撤它的 needs_you 卡。
  // failed／stalled／budget 说的是别的事实，不由「是否在等你」决定，这里不碰。
  function onThreadState(frame) {
    if (!frame || String(frame.state || '') === 'needs_you') return;
    removeCardsOf(frame.sessionId, ['needs_you']);
  }
  // 收工／线程没了：与它有关的卡都过期。
  function onThreadGone(frame) {
    removeCardsOf(frame && frame.sessionId);
  }

  function dismissStale() {
    const cutoff = now() - QUIET_CARD_MERGE_WINDOW_MS;
    for (const [key, entry] of cards) if (entry.updatedAt < cutoff) removeCard(key);
  }

  async function answerOption(entry, option) {
    const frame = entry.frame;
    if (!frame || !frame.interventionId || !frame.answerQuestionId || !option || !option.id) return null;
    let response = null;
    let failure = null;
    try {
      response = await api('/api/chat/answer', {
        method: 'POST',
        body: JSON.stringify({
          sessionId: frame.sessionId,
          questionId: frame.interventionId,
          answers: [{ questionId: frame.answerQuestionId, selectedOptionIds: [option.id] }],
        }),
      });
    } catch (error) { failure = error; }
    if (response && response.ok === true) { removeCard(entry.key); return response; }
    // 走查 S-10：修前失败被吞（没提示、卡也不动）。这张卡带的是当时那一个 questionId，问题多半已经在别处答了／线程已收工，
    // 再点永远失败 —— 说一句并把卡收起来；只有断网（那件事可能还在等）才留着卡让人重试。
    const info = failure ? apiErrorInfo(failure) : null;
    if (info && info.code === NETWORK_ERROR_CODE) {
      notifyFailure(t('quietCard.answerFailed', { reason: info.message }));
      return null;
    }
    notifyFailure(t('quietCard.answerGone'));
    removeCard(entry.key);
    return response;
  }

  function buildActions(entry) {
    const wrap = el('div', 'quiet-card-actions');
    const frame = entry.frame;
    // 候选答案（needs_you 有 options 时）。
    if (frame.kind === 'needs_you' && Array.isArray(frame.options) && frame.options.length) {
      for (const option of frame.options.slice(0, 4)) {
        const button = el('button', 'quiet-card-btn quiet-card-btn-option', option.label);
        button.type = 'button';
        button.onclick = () => {
          button.disabled = true;   // 在飞期间别连点（一个 questionId 只能答一次）
          void answerOption(entry, option).finally(() => { button.disabled = false; });
        };
        wrap.appendChild(button);
      }
    }
    // 「去看」只在真有线程可看时才画（123-M2：不属于任何线程的 reminder 没有落点，
    // 画一枚按下去什么都不发生的按钮比不画更糟）。
    if (entry.sessionId) {
      const goButton = el('button', 'quiet-card-btn quiet-card-btn-go', t('quietCard.go'));
      goButton.type = 'button';
      goButton.onclick = () => { void openSession(entry.sessionId); removeCard(entry.key); };
      wrap.appendChild(goButton);
    }
    const laterButton = el('button', 'quiet-card-btn quiet-card-btn-later', t('quietCard.later'));
    laterButton.type = 'button';
    // 「稍后」＝真 snooze：**成功才收卡**。建不成（调度器关着 / 断网 / 200 条上限）就 toast 一句、
    // 卡不动——收了卡又没排上，那件事就真的消失了。按下去期间禁用按钮，防连点建出两条。
    laterButton.onclick = () => {
      laterButton.disabled = true;
      void snooze(entry).finally(() => { laterButton.disabled = false; });
    };
    wrap.appendChild(laterButton);
    return wrap;
  }

  // 建一条 now + N 分钟 的 once reminder，sourceRef 指回它是从哪一行收件箱来的。
  // 正文整句在【这里】拼（i18n 在客户端做，服务端只把 payload.text 原样当那句事实印出来）。
  async function snooze(entry) {
    const minutes = Math.max(1, Math.min(1440, Math.round(Number(snoozeMinutesOf()) || QUIET_CARD_SNOOZE_MINUTES_DEFAULT)));
    const frame = entry.frame || {};
    const row = missionRowOf(entry.sessionId) || {};
    const title = String(row.missionTitle || row.title || '').trim() || t('quietCard.fallbackTitle');
    const ask = quietCardHeadline(entry.kind, frame.ask) || title;
    let response = null;
    try {
      response = await api(QUIET_CARD_SNOOZE_PATH, {
        method: 'POST',
        body: JSON.stringify({
          title: t('quietCard.snooze.title', { title }),
          schedule: quietCardSnoozeSchedule(now() + minutes * 60000),
          payload: {
            kind: 'reminder',
            text: t('quietCard.snooze.text', { minutes, ask }),
            sourceRef: { inboxSeq: Number(frame.inboxSeq) || 0, sessionId: entry.sessionId, kind: entry.kind },
          },
        }),
      });
    } catch { response = null; }
    if (!response || response.ok !== true) {
      notifyFailure(t('quietCard.snooze.failed'));
      return false;
    }
    removeCard(entry.key);
    return true;
  }

  function renderInto(entry) {
    const node = entry.node;
    clear(node);
    const dot = el('span', 'quiet-card-dot');
    dot.dataset.threadHue = String(stewardThreadHueFor(entry.sessionId));
    node.appendChild(dot);
    const body = el('div', 'quiet-card-body');
    const row = missionRowOf(entry.sessionId) || {};
    const title = String(row.missionTitle || row.title || '').trim();
    if (title) body.appendChild(el('div', 'quiet-card-title', title));
    const line = el('div', 'quiet-card-line', quietCardHeadline(entry.kind, entry.frame && entry.frame.ask));
    if (entry.count > 1) {
      const countBadge = el('span', 'quiet-card-count', String(entry.count));
      line.appendChild(countBadge);
    }
    body.appendChild(line);
    body.appendChild(buildActions(entry));
    node.appendChild(body);
    const closeButton = el('button', 'quiet-card-close');
    closeButton.type = 'button';
    // 「×」与「稍后」是两件事（123-M2）：「稍后」排一条真的提醒，「×」只是把这张卡收起来、
    // 不进调度器。所以它有自己的可访问名——共用「稍后」那一句会让读屏用户以为按了会再提醒。
    closeButton.setAttribute('aria-label', t('quietCard.dismiss'));
    closeButton.title = t('quietCard.dismiss');
    const closeGlyph = icon('close', 13);
    if (closeGlyph) closeButton.appendChild(closeGlyph);
    closeButton.onclick = () => removeCard(entry.key);
    node.appendChild(closeButton);
  }

  function buildCard(entry) {
    const node = el('div', 'quiet-card');
    node.dataset.sessionId = entry.sessionId;
    node.dataset.kind = entry.kind;
    node.setAttribute('role', 'status');
    // 不抢焦点：卡片本体只报告，不代表交互式控件——aria-live 让读屏在下一次空闲时念出，
    // 不用 alert/assertive 打断用户正在做的事（F5a 纪律：图标永不作为唯一信号，文案永远同时在场）。
    node.setAttribute('aria-live', 'polite');
    entry.node = node;
    return node;
  }

  function maybeNotify(entry) {
    if (notified.has(entry.key)) return;
    notified.add(entry.key);
    const settings = notifySettingsOf();
    if (settings.enabled !== true) return;
    if (notificationPermission() !== 'granted') return;
    const row = missionRowOf(entry.sessionId) || {};
    const title = String(row.missionTitle || row.title || t('quietCard.fallbackTitle'));
    const body = quietCardHeadline(entry.kind, entry.frame && entry.frame.ask);
    // 桌面壳走宿主托盘气泡（字段名对着 RuyiDesktop.cs 的解析：ruyiNotification.title／.body；id 宿主不读，带上方便对账）。
    const bridge = desktopBridge();
    if (bridge) {
      try { bridge.postMessage({ ruyiNotification: { id: entry.key, title, body } }); } catch { /* 通知失败不影响卡片 */ }
      return;
    }
    if (typeof notificationApi !== 'function') return;
    try { new notificationApi(title, { body, tag: entry.key }); } catch { /* 通知失败不影响卡片 */ }
  }

  function upsert(frame) {
    dismissStale();
    const key = quietCardKey(quietCardIdentity(frame), frame.kind);
    const existing = cards.get(key);
    const nowMs = now();
    if (existing && (nowMs - existing.updatedAt) <= QUIET_CARD_MERGE_WINDOW_MS) {
      existing.count += 1;
      existing.updatedAt = nowMs;
      existing.frame = frame;
      renderInto(existing);
      return existing;
    }
    if (existing) removeCard(key);
    const entry = { key, sessionId: String(frame.sessionId || ''), kind: String(frame.kind || ''), count: 1, updatedAt: nowMs, frame, node: null };
    buildCard(entry);
    renderInto(entry);
    const h = host();
    if (h) h.appendChild(entry.node);
    cards.set(key, entry);
    maybeNotify(entry);
    return entry;
  }

  function onFrame(frame) {
    if (!isEligible(frame)) return;
    // 静默时段（§4.3）：不出卡，只更新左栏——左栏已经在吃 thread.needs_you／thread.state 那几路
    // 推送（K2b 交付），本文件什么都不用做就是「只更新左栏」。
    if (isQuietSuppressed(new Date(now()), notifySettingsOf())) return;
    upsert(frame);
  }

  // 128f-⑪（Brief §4.2 第 7 条前半；用户 2026-09-19 拍板 A「立刻通知你，请求挂 600 秒等你处理」）：
  // 管家看过一条权限请求、没替你批，回合结束时它还挂着 —— 留给你了（服务端 13q 的 steward.deferred 帧）。
  //   · 工作台里、且没坐在那条线程上：起一张 needs_you 安静卡（同一套合并、静默时段与系统通知 —— upsert 里那一处）；
  //   · 管家视角里：管家那句「留给你」已经在对话流里，不出卡；只在页面不在前台时发一条系统通知 ——
  //     人不在屏幕前时这是唯一叫得到他的办法，否则「还等你 10 分钟」就白等。
  // 一句话把「还等多久」放在最前面：needs_you 的卡头与系统通知只印前 22 字（quietCardHeadline）。
  function deferredAsk(frame) {
    const ask = String((frame && frame.ask) || '');
    const deadline = Date.parse(String((frame && frame.deadlineAt) || ''));
    if (!Number.isFinite(deadline)) return t('quietCard.deferredNoDeadline', { ask });
    const minutes = Math.max(1, Math.round((deadline - now()) / 60000));
    return t('quietCard.deferred', { ask, minutes });
  }
  function onDeferred(frame) {
    const sessionId = String((frame && frame.sessionId) || '');
    if (!sessionId) return;
    if (isQuietSuppressed(new Date(now()), notifySettingsOf())) return;
    const ask = deferredAsk(frame);
    if (shellModeOf() === 'classic') {
      if (sessionId === currentSessionId()) return;          // 他就坐在这条线程上：请求是当面弹着的
      upsert({ kind: 'needs_you', sessionId, quiet: true, ask, interventionId: String((frame && frame.interventionId) || '') });
      return;
    }
    const d = doc();
    const away = !d || d.hidden === true || (typeof d.hasFocus === 'function' && !d.hasFocus());
    if (!away) return;
    maybeNotify({ key: `deferred|${String((frame && frame.interventionId) || sessionId)}`, sessionId, kind: 'needs_you', frame: { ask } });
  }

  // 129f(31 号文 §2.4「叫得到你」):管家自己要说的一句话。与 onDeferred 同一条路、同一套判据 ——
  // 静默时段不出;经典壳里、没坐在那条线程上就起一张安静卡;管家视角里只在页面不在前台时发系统通知
  // (对话流里那句话已经在了,人在看就别再弹一次)。服务端已经管过「该不该叫」(三类事 + 一小时上限),
  // 这里只判「此刻该不该打扰」—— 两边各管一头,不互相复制。
  function onStewardNotify(frame) {
    const text = String((frame && frame.text) || '').trim();
    if (!text) return;
    const kind = String((frame && frame.kind) || 'needs_you');
    if (!QUIET_CARD_KINDS.includes(kind)) return;
    if (isQuietSuppressed(new Date(now()), notifySettingsOf())) return;
    const sessionId = String((frame && frame.sessionId) || '');
    if (shellModeOf() === 'classic') {
      if (sessionId && sessionId === currentSessionId()) return;   // 他就坐在这条线程上
      upsert({ kind, sessionId, quiet: true, ask: text });
      return;
    }
    const d = doc();
    const away = !d || d.hidden === true || (typeof d.hasFocus === 'function' && !d.hasFocus());
    if (!away) return;
    maybeNotify({ key: `steward-notify|${sessionId}|${text.slice(0, 40)}`, sessionId, kind, frame: { ask: text } });
  }

  function bind(eventStream) {
    if (!eventStream || typeof eventStream.on !== 'function') return false;
    eventStream.on('inbox.appended', onFrame);
    eventStream.on('steward.deferred', onDeferred);   // 128f-⑪
    eventStream.on('steward.notify', onStewardNotify);   // 129f
    // 走查 S-10：线程状态一变就核对卡片（答完／收工／删除 → 撤）；事件名见 event-stream.js 的 EVENT_STREAM_ROW_EVENTS。
    eventStream.on('thread.state', onThreadState);
    eventStream.on('thread.done', onThreadGone);
    eventStream.on('thread.removed', onThreadGone);
    // 打开某条会话时撤它的卡：#sessionTitle 由 session-experience 的 renderCurrentSession 单点写入，
    // 观察它就知道「换了一条线程」（thread-head.js 的先例；MutationObserver 不是计时器）。
    const title = byId('sessionTitle');
    if (globalThis.MutationObserver && title) {
      new globalThis.MutationObserver(() => { dismissCurrent(); })
        .observe(title, { childList: true, characterData: true, subtree: true });
    }
    return true;
  }

  return Object.freeze({
    bind,
    onFrame,
    onDeferred,   // 128f-⑪
    onThreadState,   // 走查 S-10（真夹具直接喂帧）
    onThreadGone,
    dismissCurrent,
    // 供真夹具直接断言（不必去解析 DOM 文案）：当前有几张卡、某张卡的原始帧是什么。
    cardCount: () => cards.size,
    cardFor: sessionId => {
      for (const entry of cards.values()) if (entry.sessionId === String(sessionId || '')) return entry;
      return null;
    },
  });
}
