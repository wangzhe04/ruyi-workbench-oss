'use strict';

// 118a: shell-agnostic welcome wizard.
//
// Why a zero-import factory: the workbench view (`session-experience.js`) and the settings page must be
// able to open the SAME wizard (before 121-K1 the retired dispatch desk was a third caller), and the
// 117 steward line has to be able to
// replay the same step definitions as a conversation. So every environment dependency (state / api / el /
// t / toast / picker / settings opener) is injected, and the pure parts (step list, shape validators,
// first-run gate) are plain named exports that a test or the steward can call without a DOM.
//
// Discipline: zero innerHTML (DOM is built with the injected el() + textContent), the API key is never
// stored in module state beyond the live form nor echoed back into the UI after the save, and provider
// serialization is NOT reimplemented here: providerDraftFromPreset() is injected from provider-settings.js
// so the settings page and the wizard write byte-identical provider entries.

export const ONBOARDING_VERSION = 1;

// Step ids in presentation order. The steward (117) drives the same list conversationally.
// 121-K7（34 号文 §8.4 拍板③的代价、§13.1 登记）：`stewardEnabledV1` 默认改成 true 之后，
// 新装的第一天管家就在后台跑回合 —— 那是要花钱的，所以向导必须问一句「管家用哪个模型」。
// 位置排在 provider 之后：那一步刚把服务商配好，这一步才有得挑（选了 CLI 引擎跳过 provider 的
// 用户在这里仍然能填一个模型名或留空跟随主端点）。
export const ONBOARDING_STEP_IDS = Object.freeze(['language', 'engine', 'provider', 'steward', 'workspace', 'safety', 'done']);
// Engine choice on step 2. 'cloud' = a hosted preset, 'local' = any OpenAI-compatible endpoint (Ollama /
// LM Studio / an intranet gateway), 'cli' = an already installed Claude Code / Kimi Code binary.
export const ONBOARDING_ENGINE_CHOICES = Object.freeze(['cloud', 'local', 'cli']);
// Human-worded safety profiles on step 5, mapped 1:1 to config.permissionMode values.
export const ONBOARDING_SAFETY_MODES = Object.freeze(['default', 'acceptEdits', 'plan', 'auto']);
// The three most universal built-in playbooks offered on the completion page.
export const ONBOARDING_PLAYBOOK_IDS = Object.freeze(['clean-downloads', 'meeting-minutes', 'translate-document']);
// Example only. The wizard prefills it for the local choice but the user must confirm/edit it before saving.
export const LOCAL_ENDPOINT_EXAMPLE = 'http://127.0.0.1:11434/v1';
// 118a-fix: the manual is read INSIDE Ruyi. The completion page used to print a relative file location
// plus a button that put it on the system pasteboard, i.e. it sent the user off to a file manager;
// the product owner ruled that out. The button now calls the injected openHelpViewer(), which fetches
// GET /api/help/doc and renders the markdown in-app. Only this document id crosses the wire.
export const ONBOARDING_MANUAL_DOC_ID = 'user-guide';
// 118e: the built-in LOCAL provider presets. These ids must stay in lockstep with the entries carrying
// `keyOptional: true` in PROVIDER_PRESETS (05-claude-engine.js); a static gate asserts both lists match.
// They are the ONLY place the wizard knows "this preset does not need an API key" without a live /api/status
// payload, so the pure validators below stay callable offline (and by the 117 steward).
export const KEY_OPTIONAL_PRESET_IDS = Object.freeze(['ollama', 'lmstudio']);
// The manual section the "read the local-models chapter" button jumps to. The value is an i18n key whose
// text must equal a `##` heading in both manuals verbatim (same discipline as the settings tab anchors).
export const LOCAL_MODELS_ANCHOR_KEY = 'help.anchor.localModels';

// True when a blank API key is normal for this preset: any local endpoint (the free-form 'local' choice)
// plus the two zero-config local presets. Pure, so both shells and the steward can ask the same question.
// 两个文件夹路径是不是同一个（Windows 不分大小写、尾部斜杠不算）。纯函数，只用于提示，不是安全判据。
export function sameFolder(a, b) {
  const norm = p => String(p || '').trim().replace(/[\\/]+$/, '').replace(/\\/g, '/').toLowerCase();
  return Boolean(norm(a)) && norm(a) === norm(b);
}

export function presetAllowsEmptyKey(presetId) {
  const id = String(presetId || '');
  return id === 'local' || KEY_OPTIONAL_PRESET_IDS.includes(id);
}

// True for a loopback / link-local endpoint address. Mirrors the server's providerIsLocal() intent for the
// ONE thing the UI needs it for: deciding whether a blank API key deserves a nudge. Never a security gate.
export function isLocalEndpointUrl(url) {
  const raw = String(url || '').trim();
  if (!raw) return false;
  try {
    const host = new URL(raw).hostname.toLowerCase().replace(/^\[|\]$/g, '');
    return host === 'localhost' || host === '::1' || host.endsWith('.localhost') || /^127\./.test(host);
  } catch { return false; }
}

// Whether the SETTINGS page should treat this saved provider entry as "no API key required". Preset id
// first (survives an edited base URL), address second (covers a hand-built local endpoint and the
// `<id>-2` de-duplicated copies the settings page can create).
export function providerKeyOptional(provider) {
  const p = asObject(provider);
  return presetAllowsEmptyKey(String(p.id || '').replace(/-\d+$/, '')) || isLocalEndpointUrl(p.baseUrl);
}

// The human sentence key for "your local model server is not running". Empty for anything that is not one
// of the local presets, because for a hosted endpoint the server's own error sentence is the right answer.
// Deliberately NO command line and NO download link: the product rule is that Ruyi never hands the user a
// command to run. The wizard pairs this sentence with an in-app manual button instead.
export function localEndpointDownKey(presetId) {
  const id = String(presetId || '');
  return KEY_OPTIONAL_PRESET_IDS.includes(id) ? 'onboarding.wizard.provider.localDown.' + id : '';
}

// 118d: 全应用共用的向导实例登记处(与 help-viewer.js 的 registerHelpViewer 完全同一口径)。
// 帮助菜单住在 navigation-controls(popover 原语在那里),但向导实例由经典壳持有:经典壳建好后登记
// 在这里,菜单只调 openSharedOnboarding(),于是仍然只有一个向导实例,组合根一行不加。
// 没有登记(例如预览壳单独跑)时返回 null,调用方按「没有这个入口」处理。
let sharedOnboardingWizard = null;
export function registerOnboardingWizard(instance) { sharedOnboardingWizard = instance || null; return instance; }
export function openSharedOnboarding(options) {
  return sharedOnboardingWizard && typeof sharedOnboardingWizard.openOnboardingWizard === 'function'
    ? sharedOnboardingWizard.openOnboardingWizard(options)
    : null;
}
export function hasSharedOnboarding() { return Boolean(sharedOnboardingWizard); }

const STEP_META = Object.freeze({
  language: { titleKey: 'onboarding.wizard.language.title', shortKey: 'onboarding.wizard.step.language' },
  engine: { titleKey: 'onboarding.wizard.engine.title', shortKey: 'onboarding.wizard.step.engine' },
  provider: { titleKey: 'onboarding.wizard.provider.title', shortKey: 'onboarding.wizard.step.provider' },
  steward: { titleKey: 'onboarding.wizard.steward.title', shortKey: 'onboarding.wizard.step.steward' },
  workspace: { titleKey: 'onboarding.wizard.workspace.title', shortKey: 'onboarding.wizard.step.workspace' },
  safety: { titleKey: 'onboarding.wizard.safety.title', shortKey: 'onboarding.wizard.step.safety' },
  done: { titleKey: 'onboarding.wizard.done.title', shortKey: 'onboarding.wizard.step.done' },
});

function asArray(value) { return Array.isArray(value) ? value : []; }
function asObject(value) { return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }

// The pure first-run gate. It is the classic isFirstRun() derivation (no sessions AND no remembered
// workspaces) narrowed by the persisted record: once the user finished OR explicitly said 「以后再说」,
// the wizard stops offering itself and only the explicit settings entry reopens it.
export function shouldShowOnboarding(config, sessions) {
  const record = asObject(asObject(config).onboarding);
  if (record.completedAt) return false;
  if (record.skipped === true) return false;
  const noSessions = !asArray(sessions).length;
  const noWorkspaces = !asArray(asObject(config).recentWorkspaces).length;
  return noSessions && noWorkspaces;
}

// Data-driven step list. Always the same six steps in the same order (the wizard may fast-forward through
// one at runtime, e.g. the provider step when the user already has a CLI, but the definition never shrinks
// so 117 can render the identical checklist). `done` is derived from config only, never from live UI state.
// 只做语音的服务商不算「对话引擎」（判据的事实源在 util.js 的 isSpeechOnlyProvider）。本模块零 import 是锁死的纪律
// （壳无关、可在 Node 里经 data: URL 直接加载），所以这里放一份【逐字相同】的副本 —— asr-config-ui.static 钉住两份函数体一字不差，
// 改一处不改另一处当场红。
function isSpeechOnlyProvider(provider) {
  const models = provider && Array.isArray(provider.models) ? provider.models : [];
  return models.length > 0 && models.every(m => m && typeof m === 'object' && Array.isArray(m.caps) && (m.caps.includes('asr') || m.caps.includes('asr-stream')));
}
export function onboardingStepsFor(config) {
  const c = asObject(config);
  const providers = asArray(c.providers).filter(p => p && !isSpeechOnlyProvider(p));   // 自动接入的本地语音识别不是对话引擎:不能让它把「配置引擎」这一步标成已完成
  const engineReady = providers.length > 0 || Boolean(c.claudePath) || Boolean(c.kimiPath);
  // 走查 #10：defaultWorkspace 永远有值（缺省＝整个用户目录）、permissionMode 永远有出厂值 —— 拿它们判「做过了」
  // 等于新装第一秒就把「文件夹」「安全档」画成绿的。改成要有真凭据：选过文件夹（recentWorkspaces）、选过档位（显式键）或整套向导走完过。
  const completed = Boolean(asObject(c.onboarding).completedAt);
  const workspaceReady = asArray(c.recentWorkspaces).length > 0 || (completed && Boolean(c.defaultWorkspace));
  const doneFlag = {
    language: typeof c.locale === 'string' && c.locale !== '' && c.locale !== 'auto',
    engine: engineReady,
    provider: providers.length > 0,
    // 121-K7：「跟随主端点」（stewardModel 留空）也是一个【做过的选择】，可它和「还没看过这一步」
    // 在 config 里长得一模一样。所以 done 位读的是【引擎准备好了没有】—— 管家有得跑就算这一步
    // 有着落（与 engine 同一条判据，不给「留空」硬造一个新字段来记「他真的看过了」）。
    steward: engineReady,
    workspace: workspaceReady,
    // 2026-10:出厂档改成智能自动后,「不等于 default」不再是「选过」的凭据(新装第一秒就是 auto)。改看显式键:
    // 用户在任何地方选过档位,服务端就把 permissionMode 记进 configExplicitKeysV1(存量用户经 to:14 迁移也在里面)。
    safety: typeof c.permissionMode === 'string' && c.permissionMode !== ''
      && (completed || (Array.isArray(c.configExplicitKeysV1) && c.configExplicitKeysV1.includes('permissionMode'))),
    done: Boolean(asObject(c.onboarding).completedAt),
  };
  return ONBOARDING_STEP_IDS.map((id, index) => ({
    id,
    index,
    titleKey: STEP_META[id].titleKey,
    shortKey: STEP_META[id].shortKey,
    optional: id === 'provider',
    done: doneFlag[id] === true,
  }));
}

// Front-of-the-line API key shape check. It never talks to the network: it only catches the mistakes that
// otherwise turn into an opaque HTTP 401 (empty paste, a copied line break, half a key, the masked value
// read back from /api/status). `presetId === 'local'` means a local endpoint, where a blank key is normal.
export function validateApiKeyShape(presetId, key) {
  const preset = String(presetId || '');
  const raw = key == null ? '' : String(key);
  // 118e: 'local' (free-form endpoint) plus the ollama/lmstudio presets all run without a key.
  const allowsEmpty = presetAllowsEmptyKey(preset);
  if (!raw.trim()) return allowsEmpty ? { ok: true, code: '', warn: '' } : { ok: false, code: 'keyEmpty', warn: '' };
  if (/[\s]/.test(raw)) return { ok: false, code: 'keyWhitespace', warn: '' };
  if (raw.startsWith('•')) return { ok: false, code: 'keyMasked', warn: '' };
  if (raw.length < 8) return { ok: false, code: 'keyTooShort', warn: '' };
  if (raw.length > 512) return { ok: false, code: 'keyTooLong', warn: '' };
  // Non-blocking nudge: most hosted OpenAI-compatible vendors issue sk-prefixed keys. A local or
  // custom endpoint may legitimately use anything, so this never blocks the flow.
  const wantsSkPrefix = preset === 'openai' || preset === 'openai-compatible';
  const warn = wantsSkPrefix && !raw.startsWith('sk-') ? 'keyPrefixWarning' : '';
  return { ok: true, code: '', warn };
}

// Front-of-the-line base URL shape check. Same intent: catch 「粘贴了控制台首页地址」 before the request.
// 向导再存一次时该复用的已有服务商：同一预设谱系（id 为 presetId 或 presetId-N，providerDraftFromPreset
// 就是这么起号的）且地址相同（忽略首尾空白、末尾斜杠与大小写）。没有就返回 null，照旧新建一条。
// normalizeUrl(可选):地址比较前先过的收拾函数。已存的服务商地址是保存时剥过端点后缀的(…/anthropic),用户重开向导再粘完整端点
// (…/anthropic/v1/messages)直接比对比不上 —— 不复用、重复建 -2、还要求重填 key。向导把注入的 normalizeProviderDraftEndpoint 包成它传进来。
export function reusableProviderFor(providers, presetId, baseUrl, normalizeUrl) {
  const id = String(presetId || '');
  if (!id) return null;
  const prep = typeof normalizeUrl === 'function' ? normalizeUrl : value => value;
  const norm = value => String(prep(String(value || '').trim()) || '').trim().replace(/\/+$/, '').toLowerCase();
  const target = norm(baseUrl);
  const lineage = new RegExp('^' + id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(-\\d+)?$');
  return asArray(providers).find(p => p && lineage.test(String(p.id || '')) && norm(p.baseUrl) === target) || null;
}

export function validateBaseUrlShape(url) {
  const raw = url == null ? '' : String(url);
  if (!raw.trim()) return { ok: false, code: 'urlEmpty' };
  if (/\s/.test(raw)) return { ok: false, code: 'urlSpace' };
  if (!/^https?:\/\//i.test(raw)) return { ok: false, code: 'urlScheme' };
  if (!/^https?:\/\/[^/\s?#]+/i.test(raw)) return { ok: false, code: 'urlScheme' };
  return { ok: true, code: '' };
}

// A failed API response carries `error` either as a plain sentence or as the structured
// {code, params, message} envelope the server wraps strings into. Read the human sentence out of
// both shapes so the wizard never shows "[object Object]" on the most common first-run failure.
export function errorMessageOf(payload) {
  const raw = payload && payload.error;
  if (typeof raw === 'string') return raw;
  if (raw && typeof raw === 'object' && typeof raw.message === 'string') return raw.message;
  return '';
}

// Module-level singleton guard. Two shells may each build a domain instance; only one wizard may be open.
let openBackdrop = null;

export function createOnboardingWizardDomain({
  state = { config: {}, sessions: [], status: null, playbooks: [] },
  api = async () => ({}),
  el = (tag) => ({ tag }),
  t = key => key,
  toast = () => {},
  apiErrText = error => String((error && error.message) || error || ''),
  getLocale = () => 'zh-CN',
  setLocale = async locale => locale,
  providerDraftFromPreset = null,
  // 2026-10:按地址收拾草稿(剥端点后缀、地址明显是 Anthropic / Responses 时补协议)—— 与设置页同一实现,由 provider-settings.js 注入。
  normalizeProviderDraftEndpoint = null,
  // 「测试连接」失败文案:按服务端稳定 code(provider.test_*)取本地化句子,与设置页同一个函数(provider-settings.js 的 providerTestErrorText)。
  providerTestErrorText = null,
  pickWorkspace = async () => {},
  // 走查 #8：原生选择器用不了（非 Windows、WinForms 起不来）时的兜底 —— 手填一个完整路径，设成默认工作文件夹。
  setWorkspacePath = async () => {},
  openSettings = () => {},
  openPlaybook = () => {},
  onConfigChanged = () => {},
  // 121-K7（34 号文 §8.4「完成页落在管家视角」）：走完向导之后把视角切回管家。**注入**而不是
  // import js/shell-mode.js —— data-shell-mode 的唯一写者仍是那一份 applyShellMode，向导只是调它；
  // 而且向导本身要保持壳无关（117 管家复述同一份清单时不该顺手改视角）。缺席时什么都不做。
  onFinished = () => {},
  doc = globalThis.document,
  // 118a-fix: 应用内手册阅读器入口(help-viewer.js)。组合根注入,向导本身仍壳无关。
  openHelpViewer = () => {},
} = {}) {

  // U14 走查：provider preset 卡片标题直接印服务端 label 字面量，几条带中文描述的
  // （"自定义 (OpenAI 兼容 / 内网自建)"／通义千问／智谱／本机模型这几处）在 en-US 下会照原样露出。
  // 与 provider-settings.js 的 populateProviderPresets 同一份查法（那边走 util.js 的
  // presetDisplayLabel；本模块按「零 import」纪律自己重复这几行，不建立新的模块依赖）。
  function presetTitle(preset) {
    if (!preset) return '';
    const key = `provider.preset.${String(preset.id || '').replace(/[-_](\w)/g, (_, c) => c.toUpperCase())}.label`;
    const translated = t(key);
    return translated === `[${key}]` ? (preset.label || preset.id) : translated;
  }

  /* ---------------- persistence ---------------- */
  // The single config write path used by every step. Mirrors provider-settings' saveConfigPartial (POST
  // /api/config merges a partial patch, the response is the normalized config) so the wizard never keeps
  // a divergent copy of the config.
  async function persist(patch) {
    try {
      const res = await api('/api/config', { method: 'POST', body: JSON.stringify(patch) });
      if (res && res.config) state.config = res.config;
      try { onConfigChanged(); } catch { /* host redraw is best-effort */ }
      return true;
    } catch (error) {
      toast(t('onboarding.wizard.saveFailed', { reason: apiErrText(error) }), 'err');
      return false;
    }
  }

  function markOnboarding(record) {
    return persist({ onboarding: { completedAt: record.completedAt || null, version: ONBOARDING_VERSION, skipped: record.skipped === true } });
  }

  /* ---------------- modal frame ---------------- */
  function focusableIn(root) {
    if (!root || typeof root.querySelectorAll !== 'function') return [];
    const selector = 'input:not([type="hidden"]):not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex]:not([tabindex="-1"])';
    try { return [...root.querySelectorAll(selector)]; } catch { return []; }
  }

  function buildFrame(onCancel) {
    const backdrop = el('div', 'modal-backdrop dynamic onboard-wizard-backdrop');
    const trigger = doc && doc.activeElement;
    let closed = false;
    const finish = cancelled => {
      if (closed) return;
      closed = true;
      if (openBackdrop === backdrop) openBackdrop = null;
      if (cancelled && onCancel) { try { onCancel(); } catch { /* ignore */ } }
      try { backdrop.remove(); } catch { /* already detached */ }
      if (trigger && typeof trigger.focus === 'function') { try { trigger.focus(); } catch { /* ignore */ } }
    };
    // The global Esc handler in app.js calls __cancel on every open backdrop, so Esc means 「以后再说」.
    backdrop.__cancel = () => finish(true);
    backdrop.__close = () => finish(false);

    const modal = el('div', 'modal onboard-wizard');
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', t('onboarding.wizard.title'));

    const head = el('div', 'modal-head');
    const heading = el('div', 'onboard-wiz-heading');
    const title = el('h3', '', t('onboarding.wizard.title'));
    const counter = el('div', 'onboard-wiz-counter muted', '');
    heading.append(title, counter);
    const closeBtn = el('button', 'icon-btn onboard-wiz-close', '✕');
    closeBtn.type = 'button';
    closeBtn.setAttribute('aria-label', t('common.close'));
    closeBtn.onclick = () => finish(true);
    head.append(heading, closeBtn);

    const rail = el('div', 'onboard-wiz-rail');
    rail.setAttribute('aria-hidden', 'true');
    const body = el('div', 'modal-body onboard-wiz-body');
    const status = el('div', 'onboard-wiz-status');
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');
    const foot = el('div', 'modal-foot onboard-wiz-foot');

    modal.append(head, rail, body, status, foot);
    backdrop.appendChild(modal);
    if (typeof backdrop.addEventListener === 'function') {
      backdrop.addEventListener('mousedown', e => { if (e && e.target === backdrop) finish(true); });
      // Focus trap: Tab/Shift+Tab cycle inside the dialog, matching interaction-prompts' installFocusTrap.
      backdrop.addEventListener('keydown', e => {
        if (!e || e.key !== 'Tab') return;
        const nodes = focusableIn(modal).filter(n => n && n.offsetParent !== null);
        if (!nodes.length) return;
        const first = nodes[0];
        const last = nodes[nodes.length - 1];
        const active = doc && doc.activeElement;
        const inside = typeof modal.contains === 'function' ? modal.contains(active) : true;
        if (e.shiftKey && (active === first || !inside)) { e.preventDefault(); if (typeof last.focus === 'function') last.focus(); }
        else if (!e.shiftKey && (active === last || !inside)) { e.preventDefault(); if (typeof first.focus === 'function') first.focus(); }
      });
    }
    if (doc && doc.body && typeof doc.body.appendChild === 'function') doc.body.appendChild(backdrop);
    return { backdrop, modal, title, closeBtn, counter, rail, body, status, foot, close: () => finish(false), cancel: () => finish(true) };
  }

  /* ---------------- small builders ---------------- */
  function fieldBlock(labelText, control) {
    const block = el('div', 'field-block onboard-wiz-field');
    block.append(el('label', '', labelText), control);
    return block;
  }

  function choiceCard({ selected, title, description, onSelect, extra }) {
    const card = el('button', 'onboard-wiz-card' + (selected ? ' selected' : ''));
    card.type = 'button';
    card.setAttribute('aria-pressed', selected ? 'true' : 'false');
    card.append(el('div', 'onboard-wiz-card-title', title));
    if (description) card.append(el('div', 'onboard-wiz-card-desc', description));
    if (extra) card.append(el('div', 'onboard-wiz-card-extra', extra));
    card.onclick = () => onSelect();
    return card;
  }

  /* ---------------- the wizard ---------------- */
  function openOnboardingWizard(options = {}) {
    if (openBackdrop) return openBackdrop; // never stack two wizards
    const config = asObject(state.config);
    const wiz = {
      step: 0,
      engineChoice: 'cloud',
      presetId: '',
      apiKey: '',
      baseUrl: '',
      model: '',
      models: [],
      testing: false,
      tested: false,
      saving: false,
      message: '',
      messageKind: '',
      messageAction: null, // 118e: {label, onClick} for the in-app manual jump on a local-endpoint failure
      // 照实记盘上的档(含全自动 / dontAsk 这类不在四张卡里的档:那时一张卡都不亮)。修前把它们折成 'default' 显示选中,
      // 「已是这一档就不落盘」的短路会让这些用户点「每步都问」收紧变成空操作。
      permissionMode: typeof config.permissionMode === 'string' ? config.permissionMode : '',
      workspaceError: '',  // 走查 #8：选择器失败时就地显示的那句（服务端给的 hint 优先）
      workspacePath: '',   // 手填框里的草稿（重画不丢）
      stewardCustom: false, // 管家步「另挑一个」卡被点中（还没填模型名时也要显示选中态）
    };
    const presets = asArray(state.status && state.status.providerPresets);
    // 用户 2026-09-27：不再内置厂商预设。云端一支默认落在第一条【要密钥】的模板上（即「自定义」，地址由用户填），
    // 不再是列表第一条 —— 那现在是本机的 Ollama。
    const cloudPreset = presets.find(p => p && !p.keyOptional) || presets[0] || null;
    if (cloudPreset) {
      wiz.presetId = cloudPreset.id;
      wiz.baseUrl = cloudPreset.baseUrl || '';
      wiz.model = cloudPreset.defaultModel || '';
    }
    // opts.startStep opens directly on one step id (a settings deep link, or 117 resuming a conversation
    // mid-checklist). An unknown id simply starts at the beginning.
    const requestedStep = ONBOARDING_STEP_IDS.indexOf(String(options.startStep || ''));
    if (requestedStep > 0) wiz.step = requestedStep;

    // 走查 W1-13：已完成引导的用户从设置里重开向导再关掉，修前这里写 {completedAt:null, skipped:true}，把完成记录整个盖没了。
    // 开向导那一刻已经有 completedAt → 关闭不写盘（「以后再说」对一个早就走完的人没有意义）。
    const priorCompletedAt = asObject(config.onboarding).completedAt || null;
    const frame = buildFrame(async () => {
      if (priorCompletedAt) return;
      await markOnboarding({ skipped: true });
      toast(t('onboarding.wizard.skipped'), '');
    });
    openBackdrop = frame.backdrop;

    // 118e: a status line may now carry ONE in-app action button (today: 「read the manual's local-models
    // section」). It is always a real in-app destination, never a path, a command or an external link.
    const setMessage = (text, kind, action) => {
      wiz.message = String(text || '');
      wiz.messageKind = kind || '';
      wiz.messageAction = action && action.label && typeof action.onClick === 'function' ? action : null;
      paintStatus();
    };
    function paintStatus() {
      frame.status.className = 'onboard-wiz-status' + (wiz.messageKind ? ' ' + wiz.messageKind : '');
      // Keep the empty state literally empty so the `:not(:empty)` padding rule still works.
      if (!wiz.message && !wiz.messageAction) { frame.status.replaceChildren(); return; }
      const nodes = [el('span', 'onboard-wiz-status-text', wiz.message)];
      if (wiz.messageAction) {
        const action = el('button', 'file-label onboard-wiz-status-action', wiz.messageAction.label);
        action.type = 'button';
        action.onclick = wiz.messageAction.onClick;
        nodes.push(action);
      }
      frame.status.replaceChildren(...nodes);
    }

    // Runtime step order: choosing an installed CLI skips the API-key step (the definition still has six).
    function activeStepIds() {
      return ONBOARDING_STEP_IDS.filter(id => !(id === 'provider' && wiz.engineChoice === 'cli'));
    }
    function currentStepId() {
      const ids = activeStepIds();
      return ids[Math.max(0, Math.min(wiz.step, ids.length - 1))];
    }
    function goto(delta) {
      const ids = activeStepIds();
      wiz.step = Math.max(0, Math.min(wiz.step + delta, ids.length - 1));
      wiz.message = '';
      wiz.messageKind = '';
      wiz.messageAction = null;
      render();
    }

    function render() {
      const ids = activeStepIds();
      const stepId = currentStepId();
      const steps = onboardingStepsFor(state.config);
      const meta = STEP_META[stepId];
      frame.modal.setAttribute('aria-label', t('onboarding.wizard.title'));
      // 走查 W1-10：标题与关闭钮的 aria-label 原来只在 buildFrame 写一次，第一步切语言后停在旧语言 —— 每次 render 都按当前语言重写。
      frame.title.textContent = t('onboarding.wizard.title');
      frame.closeBtn.setAttribute('aria-label', t('common.close'));
      frame.counter.textContent = t('onboarding.wizard.stepCounter', {
        current: wiz.step + 1, total: ids.length, title: t(stepId === 'provider' && wiz.engineChoice === 'local' ? 'onboarding.wizard.provider.titleLocal' : meta.titleKey),   // 走查 U11：本机服务那一支，步骤计数行也别写「填入 API Key」
      });
      // Step rail (decorative; the counter carries the same information for screen readers).
      const railItems = ids.map(id => {
        const def = steps.find(s => s.id === id);
        // 走查 #10：只有【这一趟已经走过】且真配好了的步骤才画绿；当前与后面的步骤不预先画成「已完成」。
        const passed = ids.indexOf(id) < wiz.step;
        const dot = el('span', 'onboard-wiz-rail-item' + (id === stepId ? ' current' : '') + (passed && def && def.done ? ' done' : ''), t(STEP_META[id].shortKey));
        return dot;
      });
      frame.rail.replaceChildren(...railItems);
      frame.body.replaceChildren(buildStep(stepId));
      frame.foot.replaceChildren(...buildFoot(stepId));
      paintStatus();
      // Focus the first control of the new step so keyboard users land inside the dialog.
      const first = focusableIn(frame.body)[0];
      if (first && typeof first.focus === 'function') setTimeout(() => { try { first.focus(); } catch { /* ignore */ } }, 0);
    }

    function buildFoot(stepId) {
      const nodes = [];
      // 走查 #10：「退出引导」（整个向导以后再走，设置里能重开）与服务商那一步的「这一步先跳过」分开说；最后一步不再给它。
      if (stepId !== 'done') {
        const skip = el('button', 'ghost onboard-wiz-skip', t('onboarding.wizard.skip'));
        skip.type = 'button';
        skip.title = t('onboarding.wizard.skipTitle');
        skip.onclick = () => frame.cancel();
        nodes.push(skip);
      }
      nodes.push(el('span', 'onboard-wiz-foot-spacer'));
      if (wiz.step > 0) {
        const back = el('button', 'file-label onboard-wiz-back', t('onboarding.wizard.back'));
        back.type = 'button';
        back.onclick = () => goto(-1);
        nodes.push(back);
      }
      if (stepId === 'done') {
        const finishBtn = el('button', 'primary onboard-wiz-finish', t('onboarding.wizard.finish'));
        finishBtn.type = 'button';
        finishBtn.onclick = async () => {
          finishBtn.disabled = true;
          const saved = await markOnboarding({ completedAt: new Date().toISOString(), skipped: false });
          finishBtn.disabled = false;
          if (!saved) return;
          toast(t('onboarding.wizard.completed'), 'ok');
          frame.close();
          // 121-K7（§8.4）：新装走完向导落在【管家视角】。放在 frame.close() 之后 —— 切视角会走
          // View Transitions 拍一帧旧画面，向导还开着的话那一帧里会有它。失败不影响「已完成」这件事。
          try { onFinished(); } catch { /* 视角切换是旁路，向导已经完成了 */ }
        };
        nodes.push(finishBtn);
      } else if (stepId !== 'provider') {
        const next = el('button', 'primary onboard-wiz-next', t('onboarding.wizard.next'));
        next.type = 'button';
        next.onclick = () => goto(1);
        nodes.push(next);
      }
      if (stepId === 'provider') {
        // A user with no key yet must still be able to reach the folder/safety steps and the task cards,
        // otherwise the wizard becomes a wall. The engine stays unconfigured and the first-run card keeps
        // pointing at settings, which is the honest state.
        const skipStep = el('button', 'file-label onboard-wiz-skipstep', t('onboarding.wizard.provider.skipStep'));
        skipStep.type = 'button';
        skipStep.onclick = () => goto(1);
        nodes.push(skipStep);
        const save = el('button', 'primary onboard-wiz-save', t('onboarding.wizard.provider.saveAndNext'));
        save.type = 'button';
        save.disabled = wiz.saving;
        save.onclick = () => saveProvider();
        nodes.push(save);
      }
      return nodes;
    }

    function buildStep(stepId) {
      if (stepId === 'language') return buildLanguageStep();
      if (stepId === 'engine') return buildEngineStep();
      if (stepId === 'provider') return buildProviderStep();
      if (stepId === 'steward') return buildStewardStep();
      if (stepId === 'workspace') return buildWorkspaceStep();
      if (stepId === 'safety') return buildSafetyStep();
      return buildDoneStep();
    }

    /* ① language */
    function buildLanguageStep() {
      const wrap = el('div', 'onboard-wiz-step onboard-wiz-language');
      wrap.append(el('h4', 'onboard-wiz-step-title', t('onboarding.wizard.language.title')));
      wrap.append(el('p', 'onboard-wiz-step-hint muted', t('onboarding.wizard.language.hint')));
      const select = el('select', 'onboard-wiz-locale');
      for (const [value, key] of [['auto', 'settings.language.auto'], ['zh-CN', 'settings.language.zhCN'], ['en-US', 'settings.language.enUS']]) {
        const option = el('option', '', t(key));
        option.value = value;
        select.appendChild(option);
      }
      const configured = String(asObject(state.config).locale || 'auto');
      select.value = ['auto', 'zh-CN', 'en-US'].includes(configured) ? configured : 'auto';
      select.onchange = async () => {
        const value = select.value;
        await persist({ locale: value });
        const resolved = await setLocale(value);
        // 'auto' persists the resolved locale exactly like boot() does, so a later launch stays put.
        if (value === 'auto' && resolved) await persist({ locale: resolved });
        render();
      };
      wrap.append(fieldBlock(t('settings.language'), select));
      wrap.append(el('p', 'onboard-wiz-note muted', t('onboarding.wizard.language.current', { locale: getLocale() })));
      return wrap;
    }

    /* ② engine */
    function buildEngineStep() {
      const wrap = el('div', 'onboard-wiz-step onboard-wiz-engine');
      wrap.append(el('h4', 'onboard-wiz-step-title', t('onboarding.wizard.engine.title')));
      wrap.append(el('p', 'onboard-wiz-step-hint muted', t('onboarding.wizard.engine.hint')));
      const cards = el('div', 'onboard-wiz-cards');
      const pick = choice => {
        wiz.engineChoice = choice;
        wiz.tested = false;
        wiz.models = [];
        if (choice === 'local') {
          wiz.presetId = 'local';
          wiz.baseUrl = wiz.baseUrl && !presets.some(p => p.baseUrl === wiz.baseUrl) ? wiz.baseUrl : LOCAL_ENDPOINT_EXAMPLE;
          wiz.apiKey = '';
          wiz.model = '';
        } else if (choice === 'cloud') {
          const preset = cloudPreset;
          wiz.presetId = preset ? preset.id : '';
          wiz.baseUrl = preset ? (preset.baseUrl || '') : '';
          wiz.model = preset ? (preset.defaultModel || '') : '';
        }
        render();
      };
      cards.append(choiceCard({
        selected: wiz.engineChoice === 'cloud',
        title: t('onboarding.wizard.engine.cloud.title'),
        description: t('onboarding.wizard.engine.cloud.description'),
        onSelect: () => pick('cloud'),
      }));
      cards.append(choiceCard({
        selected: wiz.engineChoice === 'local',
        title: t('onboarding.wizard.engine.local.title'),
        description: t('onboarding.wizard.engine.local.description'),
        onSelect: () => pick('local'),
      }));
      cards.append(choiceCard({
        selected: wiz.engineChoice === 'cli',
        title: t('onboarding.wizard.engine.cli.title'),
        description: t('onboarding.wizard.engine.cli.description'),
        onSelect: () => pick('cli'),
      }));
      wrap.append(cards);
      // The CLI path is folded away: it points at the existing settings tab instead of duplicating it.
      const details = el('details', 'onboard-wiz-details');
      const summary = el('summary', '', t('onboarding.wizard.engine.cli.summary'));
      details.append(summary);
      details.append(el('p', 'muted', t('onboarding.wizard.engine.cli.hint')));
      const cliBtn = el('button', 'file-label', t('onboarding.wizard.engine.cli.action'));
      cliBtn.type = 'button';
      cliBtn.onclick = () => { openSettings('claude'); };
      details.append(cliBtn);
      details.open = wiz.engineChoice === 'cli';
      wrap.append(details);
      return wrap;
    }

    /* ③ provider (API key only, advanced folded) */
    function buildProviderStep() {
      const wrap = el('div', 'onboard-wiz-step onboard-wiz-provider');
      wrap.append(el('h4', 'onboard-wiz-step-title', t(wiz.engineChoice === 'local' ? 'onboarding.wizard.provider.titleLocal' : 'onboarding.wizard.provider.title')));   // 本机服务不要密钥：标题别写「填入 API Key」
      wrap.append(el('p', 'onboard-wiz-step-hint muted', wiz.engineChoice === 'local'
        ? t('onboarding.wizard.provider.localHint')
        : t('onboarding.wizard.provider.hint')));

      // 118e: the 「本地端点」 engine choice used to hide every preset card, so the zero-config Ollama /
      // LM Studio templates were reachable only through the cloud branch. Both routes now show them:
      // the local branch narrows the list to the key-optional ones, the cloud branch shows everything.
      const visiblePresets = wiz.engineChoice === 'local' ? presets.filter(p => p && p.keyOptional) : presets;
      if (visiblePresets.length || wiz.engineChoice !== 'local') {
        const cards = el('div', 'onboard-wiz-presets');
        for (const preset of visiblePresets) {
          cards.append(choiceCard({
            selected: wiz.presetId === preset.id,
            title: presetTitle(preset),
            description: preset.baseUrl || t('onboarding.wizard.provider.noBaseUrl'),
            extra: preset.keyOptional ? t('onboarding.wizard.provider.noKeyNeeded') : (preset.defaultModel || ''),
            onSelect: () => {
              wiz.presetId = preset.id;
              wiz.baseUrl = preset.baseUrl || '';
              wiz.model = preset.defaultModel || '';
              wiz.models = [];
              wiz.tested = false;
              wiz.messageAction = null;
              render();
            },
          }));
        }
        if (!visiblePresets.length) cards.append(el('div', 'muted', t('onboarding.wizard.provider.noPresets')));
        wrap.append(cards);
      }

      // The only always-visible field: the API key. Password type, with an explicit reveal toggle.
      const keyWrap = el('div', 'prov-key-wrap onboard-wiz-keywrap');
      const keyInput = el('input', 'onboard-wiz-key');
      keyInput.type = 'password';
      keyInput.autocomplete = 'off';
      keyInput.spellcheck = false;
      keyInput.value = wiz.apiKey;
      // 118e: the two local presets need no key at all, so the placeholder must not imply one is required.
      const keyOptional = presetAllowsEmptyKey(currentPresetKey());
      keyInput.placeholder = keyOptional
        ? t('onboarding.wizard.provider.apiKeyOptionalPlaceholder')
        : t('onboarding.wizard.provider.apiKeyPlaceholder');
      keyInput.oninput = () => { wiz.apiKey = keyInput.value; wiz.tested = false; };
      const eye = el('button', 'prov-key-eye onboard-wiz-key-eye', '\u{1F441}');
      eye.type = 'button';
      eye.setAttribute('aria-label', t('onboarding.wizard.provider.showKey'));
      eye.onclick = () => {
        const reveal = keyInput.type === 'password';
        keyInput.type = reveal ? 'text' : 'password';
        eye.classList.toggle('on', reveal);
      };
      keyWrap.append(keyInput, eye);
      wrap.append(fieldBlock(t('onboarding.wizard.provider.apiKey'), keyWrap));
      wrap.append(el('p', 'onboard-wiz-note muted', keyOptional
        ? t('onboarding.wizard.provider.keyOptionalNote')
        : t('onboarding.wizard.provider.keyPrivacy')));

      // Advanced: base URL + model. Auto-open for the local choice, where the address IS the decision, and
      // after a successful probe (118e), when the freshly discovered model list is what the user must pick from.
      const advanced = el('details', 'onboard-wiz-details onboard-wiz-advanced');
      advanced.open = wiz.engineChoice === 'local' || wiz.models.length > 0 || !currentPreset().baseUrl;   // 「自定义」没有预填地址：地址就是要填的那一项
      advanced.append(el('summary', '', t('onboarding.wizard.provider.advanced')));
      const urlInput = el('input', 'onboard-wiz-baseurl');
      urlInput.type = 'text';
      urlInput.value = wiz.baseUrl;
      urlInput.placeholder = wiz.engineChoice === 'local' ? LOCAL_ENDPOINT_EXAMPLE : 'https://api.example.com/v1';
      urlInput.oninput = () => { wiz.baseUrl = urlInput.value.trim(); wiz.tested = false; };
      advanced.append(fieldBlock(t('onboarding.wizard.provider.baseUrl'), urlInput));
      const modelHost = el('div', 'onboard-wiz-model-host');
      modelHost.appendChild(buildModelControl());
      advanced.append(fieldBlock(t('onboarding.wizard.provider.model'), modelHost));
      wrap.append(advanced);

      const testBtn = el('button', 'file-label onboard-wiz-test', wiz.testing ? t('onboarding.wizard.provider.testing') : t('onboarding.wizard.provider.test'));
      testBtn.type = 'button';
      testBtn.disabled = wiz.testing;
      testBtn.onclick = () => testConnection();
      wrap.append(testBtn);
      return wrap;
    }

    // A datalist-backed text input before a successful probe; a real <select> once the endpoint returned a
    // model list (same enrichment idea as provider-settings' testProvider, minus the settings-only chrome).
    function buildModelControl() {
      if (wiz.models.length) {
        const select = el('select', 'onboard-wiz-model');
        for (const model of wiz.models) {
          const option = el('option', '', model.label || model.id);
          option.value = model.id;
          select.appendChild(option);
        }
        if (wiz.models.some(m => m.id === wiz.model)) select.value = wiz.model;
        else { wiz.model = wiz.models[0].id; select.value = wiz.model; }
        select.onchange = () => { wiz.model = select.value; };
        return select;
      }
      const input = el('input', 'onboard-wiz-model');
      input.type = 'text';
      input.value = wiz.model;
      input.placeholder = t('onboarding.wizard.provider.modelPlaceholder');
      input.oninput = () => { wiz.model = input.value.trim(); };
      return input;
    }

    // 118e: a named preset wins in BOTH engine branches (the local branch can now select ollama/lmstudio).
    // Only when nothing is selected does the local branch fall back to the free-form 'local' template.
    function currentPreset() {
      const chosen = presets.find(p => p.id === wiz.presetId);
      if (chosen) return chosen;
      if (wiz.engineChoice === 'local') {
        return { id: 'local', label: t('onboarding.wizard.engine.local.title'), baseUrl: wiz.baseUrl, defaultModel: wiz.model, models: [] };
      }
      return cloudPreset || { id: 'openai-compatible', label: 'OpenAI', baseUrl: wiz.baseUrl, defaultModel: wiz.model, models: [] };
    }
    // The id the pure validators reason about: a selected preset id, else the free-form local marker.
    function currentPresetKey() {
      return presets.some(p => p.id === wiz.presetId) ? wiz.presetId : (wiz.engineChoice === 'local' ? 'local' : wiz.presetId);
    }

    // Build the provider entry with the SAME serializer the settings page uses, then overlay the three
    // fields the wizard collected. No second provider shape lives here.
    // 重开向导、对同一个端点再存一次时，就地更新已有那一条（沿用它的 id），不再追加 local-2、local-3……
    // 用户没重填密钥就原样回传掩码 —— 服务端 unmaskSecrets 按「同一 id、同一地址」还原真密钥，测试连接同理。
    // 比较地址前的收拾:与保存时同一道(剥端点后缀),由注入的 normalizeProviderDraftEndpoint 给出,不在向导里另写一份。
    function comparableUrl(url) {
      return typeof normalizeProviderDraftEndpoint === 'function' ? String(normalizeProviderDraftEndpoint({ baseUrl: url }).baseUrl || '') : String(url || '');
    }
    function buildDraft() {
      const preset = currentPreset();
      const providers = asArray(asObject(state.config).providers);
      const existing = providers.map(p => p && p.id).filter(Boolean);
      const reuse = reusableProviderFor(providers, preset && preset.id, wiz.baseUrl, comparableUrl);
      const draft = reuse
        ? { ...reuse, models: asArray(reuse.models).map(m => ({ ...m })) }
        : (typeof providerDraftFromPreset === 'function' ? providerDraftFromPreset(preset, existing) : null);
      if (!draft) return null;
      draft.baseUrl = wiz.baseUrl;
      if (typeof normalizeProviderDraftEndpoint === 'function') normalizeProviderDraftEndpoint(draft);
      if (!reuse || wiz.apiKey) draft.apiKey = wiz.apiKey;
      if (wiz.model) draft.model = wiz.model;
      if (wiz.models.length) {
        const seen = new Set(asArray(draft.models).map(m => m && m.id));
        for (const model of wiz.models) if (model.id && !seen.has(model.id)) { seen.add(model.id); draft.models.push({ id: model.id, label: model.label || model.id }); }
      }
      return draft;
    }

    function validateForm() {
      const presetKey = currentPresetKey();
      const url = validateBaseUrlShape(wiz.baseUrl);
      if (!url.ok) { setMessage(t('onboarding.wizard.validate.' + url.code), 'err'); return null; }
      // 同一端点已存过密钥（服务端回来的是掩码）且这次没重填：不逼用户再贴一遍，沿用已存的那把。
      const saved = reusableProviderFor(asObject(state.config).providers, currentPreset() && currentPreset().id, wiz.baseUrl, comparableUrl);
      const keepsSavedKey = !String(wiz.apiKey || '').trim() && !!saved && String(saved.apiKey || '').startsWith('•');
      const key = keepsSavedKey ? { ok: true, code: '', warn: '' } : validateApiKeyShape(presetKey, wiz.apiKey);
      if (!key.ok) { setMessage(t('onboarding.wizard.validate.' + key.code), 'err'); return null; }
      if (key.warn) setMessage(t('onboarding.wizard.validate.' + key.warn), 'warn');
      return buildDraft();
    }

    async function testConnection() {
      const draft = validateForm();
      if (!draft) return;
      wiz.testing = true;
      render();
      try {
        const result = await api('/api/provider/test', { method: 'POST', body: JSON.stringify({ provider: draft }) });
        if (result && result.ok) {
          wiz.tested = true;
          wiz.models = asArray(result.models).map(m => ({ id: String((m && m.id) || ''), label: String((m && (m.label || m.id)) || '') })).filter(m => m.id);
          if (wiz.models.length && !wiz.models.some(m => m.id === wiz.model)) wiz.model = wiz.model || wiz.models[0].id;
          wiz.testing = false;
          render();
          setMessage(wiz.models.length
            ? t('onboarding.wizard.provider.testSuccess', { count: wiz.models.length })
            : t('onboarding.wizard.provider.testSuccessNoModels'), 'ok');
          return;
        }
        wiz.testing = false;
        render();
        // The server already returns a human sentence; errorClass adds the 「怎么办」 line from the same
        // catalog the error cards use, so the wizard never invents its own diagnosis.
        // 带稳定 code(provider.test_*)的失败按 code 取本地化文案(与设置页同一个函数);修前这里只认服务端的中文兜底句,英文界面里照样弹中文。
        const coded = typeof providerTestErrorText === 'function' && result && /^provider\.test_/.test(String(result.code || ''));
        const detail = (coded ? providerTestErrorText(result) : errorMessageOf(result)) || t('provider.testFailure');
        const nextKey = result && result.errorClass === 'network_down' ? 'error.networkDown.next'
          : result && result.errorClass === 'provider_misconfigured' ? 'error.providerMisconfigured.next' : '';
        // 118e: for a LOCAL preset an unreachable endpoint has exactly one plain-language meaning -- the
        // model server is not running on this machine. Say that instead of a transport-level sentence, and
        // offer the in-app manual chapter (no command line, no download link, no leaving Ruyi).
        const downKey = localEndpointDownKey(currentPresetKey());
        if (downKey && result && result.errorClass === 'network_down') {
          setMessage(t(downKey), 'err', manualAction());
          return;
        }
        setMessage(nextKey ? detail + ' ' + t('onboarding.wizard.provider.whatNow', { next: t(nextKey) }) : detail, 'err',
          downKey ? manualAction() : null);
      } catch (error) {
        wiz.testing = false;
        render();
        setMessage(apiErrText(error), 'err', localEndpointDownKey(currentPresetKey()) ? manualAction() : null);
      }
    }

    // 118e: the one in-app destination a local-endpoint failure offers. It opens the manual reader on the
    // 「用本机模型」 section; the reader owns Esc, so closing it returns to the wizard.
    function manualAction() {
      return {
        label: t('onboarding.wizard.provider.localDown.readManual'),
        onClick: () => { openHelpViewer({ docId: ONBOARDING_MANUAL_DOC_ID, anchor: t(LOCAL_MODELS_ANCHOR_KEY) }); },
      };
    }

    async function saveProvider() {
      const draft = validateForm();
      if (!draft) return;
      // 118e: 本机预设的 defaultModel 是空的(本机装了哪些模型只有探测才知道)。不拦一下的话,用户可以
      // 存下一个【没有模型】的端点,然后在第一条消息上撞一个看不懂的错误 -- 那正是本波要消灭的体验。
      // 真机走查亲眼看到:选 Ollama 直接「保存并继续」-> providers[0].model === ''。
      if (presetAllowsEmptyKey(currentPresetKey()) && !String(wiz.model || '').trim()) {
        setMessage(t('onboarding.wizard.provider.localNeedModel'), 'warn');
        return;
      }
      // 走查 W1-9：只拦本机预设的空模型还不够 —— 云端唯一的预设「自定义」既没地址也没默认模型，却一样能存成 model:""，
      // 首条消息才撞一句看不懂的报错。所有分支都要有模型：本机（上面）让用户先测试连接再选，云端让用户在「高级」里填模型名。
      if (!String(wiz.model || '').trim()) {
        setMessage(t('onboarding.wizard.provider.cloudNeedModel'), 'warn');
        try {
          const advanced = frame.body.querySelector('.onboard-wiz-advanced');
          if (advanced) advanced.open = true;
          const field = frame.body.querySelector('.onboard-wiz-model');
          if (field && typeof field.focus === 'function') field.focus();
        } catch { /* 无 DOM */ }
        return;
      }
      wiz.saving = true;
      render();
      const providers = asArray(asObject(state.config).providers).filter(p => p && p.id !== draft.id);
      const saved = await persist({ providers: [...providers, draft], activeProvider: draft.id });
      wiz.saving = false;
      if (!saved) { render(); return; }
      // The plaintext key leaves the browser once and is never held for redraw.
      wiz.apiKey = '';
      toast(t('onboarding.wizard.provider.saved', { name: draft.label || draft.id }), 'ok');
      goto(1);
    }

    /* ④ workspace */
    function buildWorkspaceStep() {
      const wrap = el('div', 'onboard-wiz-step onboard-wiz-workspace');
      wrap.append(el('h4', 'onboard-wiz-step-title', t('onboarding.wizard.workspace.title')));
      wrap.append(el('p', 'onboard-wiz-step-hint muted', t('onboarding.wizard.workspace.hint')));
      const zone = el('button', 'onboard-drop onboard-wiz-drop');
      zone.type = 'button';
      zone.append(el('div', 'onboard-drop-icon', '\u{1F4C1}'));
      zone.append(el('div', 'onboard-drop-title', t('onboarding.drop.title')));
      zone.append(el('div', 'onboard-drop-sub', t('onboarding.drop.description')));
      const pick = async () => {
        const r = await pickWorkspace({ alsoDefault: true });
        // 原因用服务端的 error（「仅支持 Windows」这类）—— 「去下面粘贴路径」这半句由文案自己说，不重复 hint。
        wiz.workspaceError = r && r.ok === false ? errorMessageOf(r) || String(r.hint || '') || t('common.unknown') : '';
        render();
        // render() 下一拍会把焦点给这一步的第一个控件；失败时要落在手填框上，所以也排在下一拍、且排在它后面。
        if (wiz.workspaceError) setTimeout(() => { try { frame.body.querySelector('.onboard-wiz-path-input')?.focus(); } catch { /* 无 DOM */ } }, 0);
      };
      zone.onclick = pick;
      if (typeof zone.addEventListener === 'function') {
        zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragging'); });
        zone.addEventListener('dragleave', () => zone.classList.remove('dragging'));
        zone.addEventListener('drop', () => zone.classList.remove('dragging'));
      }
      wrap.append(zone);
      const chooseBtn = el('button', 'file-label onboard-wiz-pick', t('onboarding.wizard.workspace.choose'));
      chooseBtn.type = 'button';
      chooseBtn.onclick = pick;
      wrap.append(chooseBtn);
      if (wiz.workspaceError) {
        const err = el('p', 'onboard-wiz-note onboard-wiz-error', t('onboarding.wizard.workspace.pickFailed', { reason: wiz.workspaceError }));
        if (typeof err.setAttribute === 'function') err.setAttribute('role', 'alert');
        wrap.append(err);
      }
      // 手填兜底：常驻（不只在失败之后出现）—— 知道路径的人直接粘贴更快，选择器坏了的人也不会被卡死。
      const pathRow = el('div', 'onboard-wiz-path');
      const pathInput = el('input', 'onboard-wiz-path-input');
      pathInput.type = 'text';
      pathInput.value = wiz.workspacePath;
      pathInput.placeholder = t('onboarding.wizard.workspace.pathPlaceholder');
      if (typeof pathInput.setAttribute === 'function') pathInput.setAttribute('aria-label', t('onboarding.wizard.workspace.pathLabel'));
      pathInput.oninput = () => { wiz.workspacePath = pathInput.value; };
      const useBtn = el('button', 'btn btn-sm onboard-wiz-path-use', t('onboarding.wizard.workspace.pathUse'));
      useBtn.type = 'button';
      const usePath = async () => {
        const raw = String(pathInput.value || '').trim().replace(/^["'“‘](.*)["'”’]$/, '$1').trim();
        if (!raw) { pathInput.focus && pathInput.focus(); return; }
        await setWorkspacePath(raw);
        if (String(asObject(state.config).defaultWorkspace || '') === raw) { wiz.workspaceError = ''; wiz.workspacePath = ''; }
        render();
      };
      useBtn.onclick = usePath;
      pathInput.onkeydown = e => { if (e && e.key === 'Enter' && !e.isComposing && e.keyCode !== 229) { e.preventDefault && e.preventDefault(); usePath(); } };
      pathRow.append(pathInput, useBtn);
      wrap.append(el('p', 'onboard-wiz-note muted', t('onboarding.wizard.workspace.pathHint')));
      wrap.append(pathRow);
      const current = String(asObject(state.config).defaultWorkspace || '');
      // 走查 #7：默认工作文件夹就是整个用户目录（读／写／执行全开），而这一步的文案说「AI 只在这个文件夹里干活」。
      // 醒目提示一句，并给一枚「用一个专用文件夹」：服务端建（或复用）「文档\如意工作区」，再走同一条设默认的路。
      const home = String(asObject(state.status).homeDir || '');
      if (home && sameFolder(current, home)) {
        const warn = el('div', 'onboard-wiz-warn');
        warn.append(el('p', 'onboard-wiz-note', t('onboarding.wizard.workspace.homeWarning')));
        const dedicated = el('button', 'primary onboard-wiz-dedicated', t('onboarding.wizard.workspace.useDedicated'));
        dedicated.type = 'button';
        dedicated.onclick = async () => {
          dedicated.disabled = true;
          try {
            const r = await api('/api/workspace/dedicated', { method: 'POST', body: '{}' });
            if (r && r.ok && r.path) await setWorkspacePath(String(r.path));
            else wiz.workspaceError = errorMessageOf(r) || t('common.unknown');
          } catch (error) { wiz.workspaceError = apiErrText(error); }
          render();
        };
        warn.append(dedicated);
        wrap.append(warn);
      }
      wrap.append(el('p', 'onboard-wiz-note muted', current
        ? t('onboarding.wizard.workspace.current', { path: current })
        : t('onboarding.wizard.workspace.none')));
      return wrap;
    }

    /* ④ steward（121-K7；34 号文 §8.4 拍板③「118a 向导多一步『管家用哪个模型』」）*/
    // 两张卡：跟随主端点（写空串）／另挑一个（露出一个模型名输入框，失焦即存）。
    // 写的是 config.stewardModel —— 与设置·管家页那一个 #cfgStewardModel 是【同一个字段、同一条
    // 写口】（persist → POST /api/config），向导不新造第二个键，也不碰 stewardProviderId
    // （服务商在上一步已经定了；管家默认就用主端点那一个）。
    function buildStewardStep() {
      const wrap = el('div', 'onboard-wiz-step onboard-wiz-steward');
      wrap.append(el('h4', 'onboard-wiz-step-title', t('onboarding.wizard.steward.title')));
      wrap.append(el('p', 'onboard-wiz-step-hint muted', t('onboarding.wizard.steward.hint')));
      // 123-P1 ③（38 号文；用户 2026-09-14 真机 bug 的上游）：那台机器配的是 deepseek-v4-flash
      // 这个快档，模型七轮都只回一个 say 键、一个工具都不调，却在话里把动作说成已办。系统侧的
      // 兜底（13o/13q 的契约完整性 + 那句灰字回执）只能【说清楚】，说不出一个能用的管家；
      // 真正的修法是别在这一步挑一个守不住输出契约的模型。所以这句提示挂在选模型的当口，
      // 而不是等出了事再在对话流里解释。**只加一句提示**：#cfgStewardModel 的写口与向导步数
      // 一个字不动（rail-pocket.browser I3b 钉着七格步骤条）。
      wrap.append(el('p', 'onboard-wiz-step-hint muted', t('onboarding.wizard.steward.contractHint')));
      const current = String(asObject(state.config).stewardModel || '').trim();
      const group = el('div', 'onboard-wiz-cards onboard-wiz-steward-cards');
      group.setAttribute('role', 'radiogroup');
      group.setAttribute('aria-label', t('onboarding.wizard.steward.title'));
      const customPicked = Boolean(current) || wiz.stewardCustom === true;
      const follow = choiceCard({
        selected: !customPicked,
        title: t('onboarding.wizard.steward.follow'),
        description: t('onboarding.wizard.steward.followHint'),
        onSelect: async () => {
          if (!(await persist({ stewardModel: '' }))) return;
          wiz.stewardCustom = false;
          render();
          setMessage(t('onboarding.wizard.steward.savedFollow'), 'ok');
        },
      });
      follow.setAttribute('role', 'radio');
      follow.setAttribute('aria-checked', customPicked ? 'false' : 'true');
      group.append(follow);
      const custom = choiceCard({
        selected: customPicked,
        title: t('onboarding.wizard.steward.custom'),
        description: t('onboarding.wizard.steward.customHint'),
        // 已经填过就不清掉他填的那个（点一下只是把这张卡选中）。走查 W1：没填过时点它修前毫无反应（render 画回原样）——
        // 现在记下「选了它」，卡片亮起选中态并把光标送进模型名输入框。
        onSelect: () => {
          wiz.stewardCustom = true;
          render();
          setTimeout(() => { try { frame.body.querySelector('#onboardStewardModel')?.focus(); } catch { /* 无 DOM */ } }, 0);
        },
      });
      custom.setAttribute('role', 'radio');
      custom.setAttribute('aria-checked', customPicked ? 'true' : 'false');
      group.append(custom);
      wrap.append(group);
      const input = el('input', '');
      input.id = 'onboardStewardModel';
      input.type = 'text';
      input.value = current;
      input.placeholder = t('onboarding.wizard.steward.modelPlaceholder');
      // 失焦即存（与本向导其余控件同款：一步一存，不攒到最后一起写）。
      input.onchange = async () => {
        const next = String(input.value || '').trim();
        if (next === current) return;
        if (!(await persist({ stewardModel: next }))) return;
        render();
        setMessage(next
          ? t('onboarding.wizard.steward.saved', { model: next })
          : t('onboarding.wizard.steward.savedFollow'), 'ok');
      };
      wrap.append(fieldBlock(t('onboarding.wizard.steward.modelLabel'), input));
      return wrap;
    }

    /* ⑤ safety */
    function buildSafetyStep() {
      const wrap = el('div', 'onboard-wiz-step onboard-wiz-safety');
      wrap.append(el('h4', 'onboard-wiz-step-title', t('onboarding.wizard.safety.title')));
      wrap.append(el('p', 'onboard-wiz-step-hint muted', t('onboarding.wizard.safety.hint')));
      const group = el('div', 'onboard-wiz-cards onboard-wiz-safety-cards');
      group.setAttribute('role', 'radiogroup');
      group.setAttribute('aria-label', t('onboarding.wizard.safety.title'));
      // W6（缺陷②）：修前选「智能自动」直接 persist({ permissionMode:'auto' }) —— 服务端 applyConfigPatch 那道门
      // （116-3 B1：切全自动缺 confirm:true 就 409 permission.confirm_required）把它挡回来，而卡片先被标成选中、
      // 保存失败只剩一句 toast。现在：要二次确认的那一档先在本步里【就地】展开一段确认（与设置页、盾牌菜单同一条纪律：
      // 不跳走、不叠第二层模态），点「确定」才带 confirm:true 落盘；落盘成功之后才把卡片标成选中。
      // 本模块零 import（壳无关），「哪一档要确认」按服务端那张 PERMISSION_MODES_REQUIRING_CONFIRM 的前端投影写在这里。
      const needsConfirm = mode => mode === 'auto';
      const choose = async (mode, extra) => {
        if (!(await persist({ permissionMode: mode, ...(extra || {}) }))) { render(); return false; }
        wiz.permissionMode = mode;
        wiz.pendingSafety = '';
        render();
        setMessage(t('onboarding.wizard.safety.saved', { name: t('onboarding.wizard.safety.' + mode + '.title') }), 'ok');
        return true;
      };
      for (const mode of ONBOARDING_SAFETY_MODES) {
        const selected = wiz.permissionMode === mode;
        const card = choiceCard({
          selected,
          title: t('onboarding.wizard.safety.' + mode + '.title'),
          description: t('onboarding.wizard.safety.' + mode + '.description'),
          onSelect: async () => {
            // 已是这一档就不再落盘:出厂档是智能自动(2026-10),新用户点一下已选中的卡片会不带 confirm 回写 auto,
            // 被服务端那道二次确认门 409 挡回来,只剩一句报错。
            if (wiz.permissionMode === mode) { wiz.pendingSafety = ''; render(); return; }
            if (needsConfirm(mode)) { wiz.pendingSafety = mode; render(); return; }
            wiz.pendingSafety = '';
            await choose(mode);
          },
        });
        card.setAttribute('role', 'radio');
        card.setAttribute('aria-checked', selected ? 'true' : 'false');
        group.append(card);
      }
      wrap.append(group);
      if (wiz.pendingSafety && needsConfirm(wiz.pendingSafety)) {
        const pending = wiz.pendingSafety;
        const box = el('div', 'steward-settings-confirm onboard-wiz-safety-confirm');   // 就地确认的外观复用设置页那一族（steward-settings.css 全局类）
        box.setAttribute('role', 'group');
        box.append(el('strong', '', t('onboarding.wizard.safety.autoConfirm.title')));
        box.append(el('p', 'onboard-wiz-step-hint muted', t('onboarding.wizard.safety.autoConfirm.body')));
        const actions = el('div', 'steward-settings-confirm-actions');
        const cancel = el('button', 'btn btn-sm onboard-wiz-safety-cancel', t('onboarding.wizard.safety.autoConfirm.cancel'));
        cancel.type = 'button';
        cancel.onclick = () => { wiz.pendingSafety = ''; render(); };
        const ok = el('button', 'btn btn-sm primary onboard-wiz-safety-ok', t('onboarding.wizard.safety.autoConfirm.ok'));
        ok.type = 'button';
        ok.onclick = async () => { ok.disabled = true; await choose(pending, { confirm: true }); };
        actions.append(cancel, ok);
        box.append(actions);
        wrap.append(box);
      }
      return wrap;
    }

    /* ⑥ done */
    function buildDoneStep() {
      const wrap = el('div', 'onboard-wiz-step onboard-wiz-done');
      wrap.append(el('h4', 'onboard-wiz-step-title', t('onboarding.wizard.done.title')));
      wrap.append(el('p', 'onboard-wiz-step-hint muted', t('onboarding.wizard.done.hint')));
      const grid = el('div', 'onboard-wiz-playbooks');
      const all = asArray(state.playbooks);
      for (const id of ONBOARDING_PLAYBOOK_IDS) {
        const playbook = all.find(p => p && p.id === id);
        const card = el('button', 'onboard-wiz-card onboard-wiz-playbook');
        card.type = 'button';
        // W2-F7b：卡面文字只认本地化键。修前优先取 state.playbooks 的 title/desc，那份是向导【打开前】按当时语言取回来的 ——
        // 在第一步切到 English 之后第七步三张卡仍是中文。键（zh/en 各一份）本来就齐，playbook 对象只管点开（openPlaybook）。
        card.append(el('div', 'onboard-wiz-card-title', t('onboarding.wizard.done.playbook.' + id)));
        card.append(el('div', 'onboard-wiz-card-desc', t('onboarding.wizard.done.playbookHint.' + id)));
        card.onclick = () => {
          if (!playbook) { setMessage(t('onboarding.wizard.done.playbookMissing'), 'warn'); return; }
          frame.close();
          openPlaybook(playbook);
        };
        grid.append(card);
      }
      wrap.append(grid);
      // 118a-fix: manual entry. One button, and it opens the manual right here in the app.
      // The wizard stays open underneath: the reader consumes Esc itself, so closing the manual
      // returns the user to the completion page instead of cancelling the wizard.
      const manual = el('div', 'onboard-wiz-manual');
      manual.append(el('div', 'onboard-wiz-manual-title', t('onboarding.wizard.done.manual')));
      manual.append(el('p', 'muted', t('onboarding.wizard.done.manualHint')));
      const readBtn = el('button', 'file-label onboard-wiz-manual-open', t('help.doc.open'));
      readBtn.type = 'button';
      readBtn.onclick = () => { openHelpViewer({ docId: ONBOARDING_MANUAL_DOC_ID }); };
      manual.append(readBtn);
      wrap.append(manual);
      return wrap;
    }

    render();
    return frame.backdrop;
  }

  return Object.freeze({
    ONBOARDING_VERSION,
    onboardingStepsFor,
    openOnboardingWizard,
    shouldShowOnboarding: (config, sessions) => shouldShowOnboarding(config === undefined ? state.config : config, sessions === undefined ? state.sessions : sessions),
    validateApiKeyShape,
    validateBaseUrlShape,
  });
}
