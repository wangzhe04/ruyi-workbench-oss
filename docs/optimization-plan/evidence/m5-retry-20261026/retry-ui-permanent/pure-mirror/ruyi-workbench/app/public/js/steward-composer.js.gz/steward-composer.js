'use strict';

// 第117波 117c：管家输入区与递话（27 号文 §8.12「递话：输入即预判」逐条照做／§8.8 键盘与无障碍）。
//
// 把路由从「发出后再确认」改成「输入时就看得见」，像邮件的收件人栏：
//   ① 输入即预判：输入变化后 150ms 去抖调 GET /api/steward/preroute?q=，按 kind 更新左侧的递送目标
//      chip（请求带序号，过期响应一律丢弃——慢的那一次回来时不许覆盖新的判定）；
//   ② Enter 直接递：目标是线程时【不经管家回合】，直接 POST /api/steward/act 跑
//      steward_thread_continue；目标是如意（含 question／unsure／schedule）时走 /api/steward/message 流；
//   ③ 10 秒撤回、之后换一条：由 steward-conversation.js 的 handOff/undoHandOff 负责（回执与按钮住在
//      对话流里，不住输入区）；
//   ④ 用户随时可指定：点 chip 循环、Tab 循环、输入 @ 开候选列表；手选后 chip 实底带 ×，本次发送后
//      自动恢复「→ 如意」。
//
// 边界：零 innerHTML；预判只在管家模式且管家开关开时才发（非管家模式一律不请求，延续 117b 的门控
// 纪律）；本模块唯一的 timer 是去抖 setTimeout（一处 setTimeout ＋ 一处 clearTimeout，都锁在
// schedulePreroute/cancelPreroute 里）。

import { stewardEscapeStack, doc, byId, el, isSubmitEnter } from './steward-chips.js';   // 117j UX-F3：候选列表走同一个 Esc 栈；117n-M1：DOM 基础件复用（doc/byId/el 不再本地重复）；33 号文 §4：回车发送的输入法守卫也只有那一条
// 32 号文 §4（M2）：候选列表的开合（Esc／点外／焦点归还／同一时刻只允许一个浮层）交给两壳共用的
// 浮层原语。它住在 js/popover.js，本模块只取那一套【开合】，把 3.0 自己的 .steward-target-picker
// 经 opts.layer 交给它 —— 容器、id、类名、role、[hidden] 与「就地在 .stewardComposer 里」一个字不改。
import { popover, closePopover, popoverAnchor } from './popover.js';
// F5a 收编（33 号文 §4「F5a 漏网图标」）：字形一律走全仓唯一那张 ICONS 表，本文件零 SVG path 字面量。
import { icon } from './icons.js';
import { privacyComposerMenuItem } from './privacy-settings.js';
// 117r-D3（用户第八轮走查②「关键词匹配……最好不要和输入框放同一行」「而且匹配的没法删掉/关掉」）：
// 线程标题截短复用【唯一那一份】实现（util.js 的 stewardShortTitle，STEWARD_TITLE_MAX=24），不在本文件里另起一份——
// 抽屉页签、灰字回执、2.0 的工具卡/工作流节点卡早就走这条口径，chip 是唯一漏掉的一处。
// 33 号文 §4：那份实现的落点从 steward-conversation.js 搬到 util.js（无状态格式化叶子），函数体逐字未改。
import { stewardShortTitle } from './util.js';
import { fmtTime } from './util.js';
import { autoGrow, fmtBytes } from './util.js';   // 133e：输入框随内容长高（与工作台 #promptInput 同一个 autoGrow）；附件 pill 的体积
// 127-⑦（45 号文 §2-quinquies）：输入行里发送键前那枚麦克风。录音计时器、转写与回填全住 composer-voice.js ——
// 本文件「恰好一处 setTimeout、零 setInterval」的纪律（I3/I4）因此一个字不用动。
import { createComposerVoice, composerSent } from './composer-voice.js';
import { privacyFailure, privacyVoiceFailure } from './privacy-failure.js';

// 121-K5（34 号文 §13.7 登记⑧）：F2 频道条那条 steward:pick-channel 的常量与监听器已删。
// K4-3 删掉了频道条与它【唯一】的生产者（steward-conversation.js 的 pickChannelTarget），此后
// 这条监听器永远不会被触发 —— 留着它不是「留了个接口」，是让后人以为手选态还有第二条来路。
export const STEWARD_PREROUTE_DEBOUNCE_MS = 150;   // §8.12 第 1 条：目标 ≤50ms 出判定，150ms 去抖不抢跑
export const STEWARD_PICKER_MAX = 8;               // 候选列表最多 8 条
export const STEWARD_RECENT_MAX = 8;               // 见过的线程做「最近线程」回忆池（零新增路由）

// kind → chip 文案键（§8.12 第 1 条五种形态；question／steward 都回落到「→ 如意」）。
const STEWARD_TARGET_KEYS = Object.freeze({
  thread: 'stewardShell.compose.targetThread',
  schedule: 'stewardShell.compose.targetSchedule',
  unsure: 'stewardShell.compose.targetUnsure',
  new: 'stewardShell.compose.targetNew',
  // 117d：抽屉「＋ 线程」按下后的形态 —— 目标仍是如意（创建经管家、委托书表单归 117e），
  // 但下一句话默认落在【当前事项】下，而不是另起一件。
  missionNew: 'stewardShell.compose.targetMissionNew',
  question: 'stewardShell.compose.targetSteward',
  steward: 'stewardShell.compose.targetSteward',
});

export function stewardTargetKey(kind) {
  return STEWARD_TARGET_KEYS[String(kind || '')] || 'stewardShell.compose.targetSteward';
}

// 候选行（纯函数，导出给单测直调）：sessionId 是身份，标题只在重名时才带区分后缀。
// hits 是预判命中（displayTitle 优先），remembered 是本次页面见过的线程回忆池；同 sessionId 只留先出现的。
export function stewardCandidateRows(hits, remembered, limit = STEWARD_PICKER_MAX) {
  const rows = [];
  const seen = new Set();
  const take = row => {
    const sessionId = String((row && row.sessionId) || '');
    if (!sessionId || seen.has(sessionId) || rows.length >= limit) return;
    seen.add(sessionId);
    const title = String(row.title || '').trim();
    rows.push({ sessionId, title: title || sessionId, updatedAt: String(row.updatedAt || '') });
  };
  for (const hit of (Array.isArray(hits) ? hits : [])) take({ sessionId: hit && hit.sessionId,
    title: String((hit && (hit.displayTitle || hit.title)) || ''), updatedAt: String((hit && hit.updatedAt) || '') });
  for (const row of (Array.isArray(remembered) ? remembered : [])) take(row);
  const counts = new Map();
  for (const row of rows) counts.set(row.title, (counts.get(row.title) || 0) + 1);
  const labelled = rows.map(row => {
    if (counts.get(row.title) < 2) return { ...row, label: row.title };
    // 同名的两条必须看得出区别：本地化时间优先，缺时间退到 sessionId 尾段（可复述、稳定）。
    // 畸形时间串不算时间（否则会把 "Invalid Date" 印进列表）。
    const when = row.updatedAt && Number.isFinite(Date.parse(row.updatedAt)) ? fmtTime(row.updatedAt) : '';
    return { ...row, label: row.title + ' · ' + (when || row.sessionId.slice(-6)) };
  });
  // 时间只到分钟：同一分钟建的两条同名线程会撞成同一个标签 —— 再撞一次就补 sessionId 尾段。
  const labelCounts = new Map();
  for (const row of labelled) labelCounts.set(row.label, (labelCounts.get(row.label) || 0) + 1);
  const tailed = labelled.map(row => labelCounts.get(row.label) > 1 ? { ...row, label: row.label + ' · ' + row.sessionId.slice(-6) } : row);
  // 尾段也可能相撞（自定义/极短的 sessionId）：仍相撞就退回整段 id，保证两行必然不同。
  const tailCounts = new Map();
  for (const row of tailed) tailCounts.set(row.label, (tailCounts.get(row.label) || 0) + 1);
  return tailed.map(row => tailCounts.get(row.label) > 1 ? { ...row, label: row.label + ' · ' + row.sessionId } : row);
}

export function externalBotReferenceText(item, translate) {
  const t = typeof translate === 'function' ? translate : key => key;
  const source = [t(item.platform === 'qq' ? 'externalBots.qq' : 'externalBots.feishu'), item.connectionLabel || item.connectionId].filter(Boolean).join(' / ');
  const lines = [t('externalBots.referenceSource', { source }),
    t('externalBots.referenceIdentity', { sender: item.senderId || '', conversation: item.conversationId || '' }),
    t('externalBots.referenceMessage', { id: item.messageId || item.eventId || item.id || '' }), '', item.text];
  return t('externalBots.referenceIntro') + '\n\n' + lines.join('\n').replace(/\r\n?/g, '\n').split('\n').map(line => '> ' + line).join('\n');
}

export function createStewardComposer({
  api = async () => null,
  state = null,
  t = key => key,
  isStewardMode = () => false,
  conversation = null,
  // 128h-J03:用户此刻看着的那条线程(右栏「现在这一件」)。预判拿它裁「继续那个」这种纯指代与并列;缺省没有焦点。
  focusThreadId = () => '',
} = {}) {
  // 117n-M1：doc/byId/el 从 steward-chips.js import（六个消费方零本地重复定义）。

  // 117i：输入框右侧两枚圆键的线条图标（原型 .ic）。
  // F5a 收编（33 号文 §4「F5a 漏网图标」）：本文件不再自带图标构造器、也不再存 path 字面量 —— 字形
  // 一律取自 icons.js 的 ICONS 表（全仓唯一词汇表；「零 innerHTML」那条纪律由它内部的
  // createElementNS 承担）。steward-icon 这个 class 仍由本文件打上：steward-conversation.css 那枚
  // 1em 尺寸规则按它命中（本轮不碰 CSS），字形尺寸/描边因此与收编前逐像素同。
  function paintGlyph(node, name) {
    const svg = icon(name, 16);
    if (!svg) return;                       // 未知名子只 console.warn，这里不塞空节点
    svg.classList.add('steward-icon');
    node.appendChild(svg);
  }

  // 预判实况：kind ＋ 候选（hits）。手选（picked）优先于预判，直到本次发送完成。
  let routeKind = 'steward';
  let routeHits = [];
  let routeReason = '';
  let picked = null;             // { sessionId, title } —— 用户手选的目标
  let targetGeneration = 0;     // 显式换目标后，上一句的迟到回执不能清掉下一份草稿的目标。
  let newTarget = false;       // 自动预判也会返回 new；只有用户明选的新建目标才保持到发送/取消。
  // 117r-D3 ③（用户第八轮走查②「匹配的没法删掉/关掉」）：用户点过 chip 的 × 把这次自动预判否掉之后
  // 置真——在它被复位之前，runPreroute() 拿到的响应不再写回 routeKind/routeHits/routeReason（也就不会
  // 再把 chip 从「→ 如意」翻回「像是接着『X』」）。复位三处：submit() 的 finally、resetComposer()、
  // 以及 runPreroute() 自己的空查询分支（= 输入框被清空）——见下方各处标了「117r-D3 ③」的行。
  let hintDismissed = false;
  // 121-K5（34 号文 §13.7 登记⑧）：F2 频道条的那两支临时目标（channelPick / pickedBeforeChannel）
  // 随它一起退役 —— K4-3 删掉了频道条与它唯一的生产者 pickChannelTarget，此后这两支恒为 null，
  // 发完一句之后的那一行因此逐字回到修前的 `picked = null;`（当初的注释自己写明了这一点）。
  // 目标仍然只有 picked 一个（currentTarget() 一个字没改）。
  const recent = [];             // 见过的线程回忆池（@ 列表里「最近线程」那一半）
  // 127-⑦：麦克风只回填不发送 —— 它手里没有 submit，填完只派发 input（预判照常跟着走）。
  const voice = createComposerVoice({ state, t, privacyFailure, privacyVoiceFailure, id: 'stewardComposerVoice', input: () => byId('stewardComposerInput'), anchor: () => byId('stewardComposerSend') });

  function rememberHits(hits) {
    for (const hit of (Array.isArray(hits) ? hits : [])) {
      if (!hit || !hit.sessionId) continue;
      const index = recent.findIndex(row => row.sessionId === hit.sessionId);
      if (index >= 0) recent.splice(index, 1);
      // 116-5b:候选列表显示的是服务端算好的 displayTitle(06i stewardPrerouteHit;判据在 02 的
      // sessionDisplayTitle)。缺席时逐字等于 title,老载荷零变化。updatedAt 只用于同名消歧后缀。
      recent.unshift({ sessionId: String(hit.sessionId), title: String(hit.displayTitle || hit.title || hit.sessionId), updatedAt: String(hit.updatedAt || '') });
    }
    while (recent.length > STEWARD_RECENT_MAX) recent.pop();
  }

  // 117l D1（用户第四轮走查②「无论关键词匹配到什么，都要发给管家让它决定」）：
  // **只有 picked 才是目标**。自动预判从「目标」降级成「提示」—— 它进 routeHint 随请求走，由管家
  // 在回合里决定接着办／新开／直接答（服务端只信 sessionId，标题自己重查）。修前这里把 routeHits[0]
  // 当成目标返回，于是 submit() 走 handOff 直递：用户说「大A这周走势会怎么样」被「走势」命中美股那条
  // 线程，一句新话直接递进去，把那条线程正在等的提问 supersede 掉（§11.9.2 ①⑥ 同一起事故）。
  function currentTarget() {
    return picked;   // null = 递给如意（预判不再是目标，见 hintedThread）
  }
  function creatingNew() { return newTarget; }
  function cancelTarget() {
    cancelPreroute(); prerouteSeq += 1; closePicker();
    targetGeneration += 1;
    newTarget = false;
    picked = null; routeKind = 'steward'; routeHits = []; routeReason = ''; hintDismissed = true;
    const input = byId('stewardComposerInput');
    if (input) { input.placeholder = t('stewardShell.compose.placeholder'); input.focus({ preventScroll: true }); }
    note(t('stewardShell.compose.targetCancelled')); renderChip();
  }
  function selectTarget(target) {
    cancelPreroute(); prerouteSeq += 1; closePicker(); targetGeneration += 1;
    if (creatingNew()) { routeKind = 'steward'; routeHits = []; routeReason = ''; }
    newTarget = false; picked = target;
    // 选择目标不等于取消匹配依据；递话回执仍须说明这次手选之前命中了什么。
    const input = byId('stewardComposerInput');
    if (input) { input.placeholder = t('stewardShell.compose.placeholder'); input.focus(); }
    note(''); renderChip();
  }

  // 预判命中的线程：只用来显示 chip 上那句「像是接着『X』」并组装 routeHint，永远不是递送目标。
  function hintedThread() {
    if (picked) return null;
    if (routeKind === 'thread' && routeHits.length) {
      // 117k（用户走查③）：与上面 recent／candidates 同一口径 —— 显示名优先。缺席时逐字等于 title。
      return { sessionId: String(routeHits[0].sessionId), title: String(routeHits[0].displayTitle || routeHits[0].title || routeHits[0].sessionId) };
    }
    return null;
  }

  // 随 POST /api/steward/message 一起走的提示（§11.9 D1）。前端给的文字一个字都不进提示词 ——
  // 服务端只认 sessionId，标题它自己重查；这里只带 sessionId 与命中理由，最多 3 条。
  function routeHintPayload() {
    return {
      kind: String(routeKind || 'steward'),
      hits: routeHits.slice(0, 3).map(hit => ({ sessionId: String((hit && hit.sessionId) || ''), reason: String((hit && hit.reason) || '') })),
      picked: null,
    };
  }

  function renderChip() {
    const chip = byId('stewardTarget');
    if (!chip) return;
    const label = chip.querySelector('.steward-target-label');
    const clear = chip.querySelector('.steward-target-clear');
    const target = currentTarget();
    const hint = hintedThread();
    const revision = Boolean(target && target.deliverySource);
    const explicitMode = revision || creatingNew();
    // A delivery reference cannot be moved to another thread through the ordinary picker.
    chip.disabled = revision;
    const cancel = byId('stewardComposerCancelTarget');
    if (cancel) {
      cancel.hidden = !explicitMode;
      cancel.classList.toggle('hidden', !explicitMode);
      cancel.textContent = t(revision ? 'delivery.cancelRevision' : 'stewardShell.compose.cancelNew');
      cancel.setAttribute('aria-label', cancel.textContent);
    }
    // 117r-D3 ①（用户第八轮走查②「关键词匹配……会把输入框内容挤没」）：hintedThread() 返回的是
    // routeHits[0] 的原话，常常是用户说的一整句话——在它被塞进 chip 之前统一截短。hintedThread()
    // 每次调用都返回一个全新对象（不是共享状态），这里改它的 .title 不会影响别处。
    if (hint) hint.title = stewardShortTitle(hint.title);
    const active = Boolean(target || hint);   // 手选或自动命中，两者之一在，chip 上就有「东西可撤」
    chip.classList.toggle('is-thread', active);
    chip.classList.toggle('is-picked', Boolean(picked));
    // W4b（用户 2026-09-25 走查⑥「→如意 前缀 chip 含义不清」）：没有任何东西可说的那一态（不是手选、
    // 不是预判命中、也不是「另起一件／定时／会问你」那几种形态）就是【默认递给如意】——这时印一枚
    // 「→ 如意」等于把缺省值当信息印出来。收成一枚安静的「@」圆键（样式层按 .is-quiet 换皮：label 收起、
    // 「@」露出），它仍是同一枚按钮：点开候选、Tab 循环、输入 @ 三条路一个没动，aria-label 仍是「递给谁」。
    // label 的 textContent 照旧写「→ 如意」—— 读屏与既有断言读的是它，换皮不换字。
    chip.classList.toggle('is-quiet', !active && stewardTargetKey(routeKind) === 'stewardShell.compose.targetSteward');
    // 117r-D3 ③（用户第八轮走查②「匹配的没法删掉/关掉」）：修前 × 只在【手选】时才出——自动预判命中
    // 的「像是接着『X』」没有任何关闭出口。判据从「只看 picked」改成「有没有东西可撤」（手选或自动命中）。
    if (clear) clear.hidden = !active || explicitMode;
    if (!label) return;
    // 同一条纪律的另一支：手选目标的标题也过 stewardShortTitle（这支不动 target/picked 本身——
    // picked 是持续状态，handOff() 会再读一次 title，不能在这里被悄悄改掉）。
    if (target && target.deliverySource) label.textContent = t('delivery.target', { title: stewardShortTitle(target.title), seq: target.deliverySource.turnSeq });
    else if (target) label.textContent = t('stewardShell.compose.targetThread', { title: stewardShortTitle(target.title) });
    else if (hint) label.textContent = t('stewardShell.compose.targetSteward.hint', { title: hint.title });
    else label.textContent = t(stewardTargetKey(routeKind));
  }

  // ── 输入即预判：去抖 ＋ 序号丢弃 ─────────────────────────────────────────────
  let debounceTimer = 0;
  let prerouteSeq = 0;
  function cancelPreroute() {
    if (!debounceTimer) return;
    clearTimeout(debounceTimer);
    debounceTimer = 0;
  }
  function schedulePreroute(text) {
    cancelPreroute();
    debounceTimer = setTimeout(() => { debounceTimer = 0; runPreroute(text); }, STEWARD_PREROUTE_DEBOUNCE_MS);
  }
  async function runPreroute(text) {
    if (picked || creatingNew()) return;
    const query = String(text || '').trim();
    // 117r-D3 ③ 复位点之一：输入框被清空 = 用户在打一句新的话，之前否掉的那次预判不该再拦后面的响应。
    // hunt2-steward ⑦:清空时也让在途预判作废(序号 +1)——否则输入框清空之前发出去的那一趟慢响应回来,
    // 会把刚复位的 chip 又写回「像是接着『X』」。
    if (!query) { prerouteSeq += 1; routeKind = 'steward'; routeHits = []; routeReason = ''; hintDismissed = false; renderChip(); return; }
    if (!isStewardMode()) return;
    if (!(state && state.config && state.config.stewardEnabledV1 === true)) return;
    const seq = ++prerouteSeq;
    let result = null;
    let focus = '';
    try { focus = String(focusThreadId() || ''); } catch { focus = ''; }
    const focusParam = focus ? `&focus=${encodeURIComponent(focus)}` : '';
    try { result = await api(`/api/steward/preroute?q=${encodeURIComponent(query)}${focusParam}`); }
    catch { return; }
    if (seq !== prerouteSeq) return;   // 过期响应：慢的那一次回来时新的判定已经在屏幕上了，丢弃
    if (!result || result.ok !== true) return;
    // 117r-D3 ③：这一趟输入已经被用户点 × 否掉了——响应回来也不许再往 chip 上写，
    // 否则「关掉」只是骗人的动画，下一拍又自己变回去（用户第八轮走查②「匹配的没法删掉/关掉」）。
    if (hintDismissed) return;
    routeKind = String(result.kind || 'steward');
    routeHits = Array.isArray(result.hits) ? result.hits : [];
    routeReason = routeHits.length ? String(routeHits[0].reason || '') : '';
    rememberHits(routeHits);
    renderChip();
  }

  // ── 候选列表（点 chip／输入 @／Tab 循环共用同一份候选）────────────────────────
  // 117j W2-2 曾按标题去重（「同一件事开过好几条线程，三四行一模一样的字」）。62 号第三轮 E04 推翻了
  // 这条判据：同名但不同 session 是两件事，折成一行等于用户没法选。现在只按 sessionId 保留身份，
  // 重名的行追加一个区分后缀（本地化时间；缺时间用 sessionId 尾段）—— 后缀只进列表显示，
  // picked 里存的仍是原话标题，chip 与 handOff 的既有口径不变。
  function candidates() {
    return stewardCandidateRows(routeHits, recent, STEWARD_PICKER_MAX);
  }

  // 117j UX-F3：候选列表也进 Esc 栈。输入框那条 keydown 保留（焦点在里面时的近路），
  // 但焦点跑到别处（比如刚点完 chip）时，只有栈这一路收得到。
  let releasePickerEscape = null;
  // 32 号文 §4（M2）：开合本身（Esc／点外／焦点归还／同一时刻只允许一个浮层）交给两壳共用的
  // js/popover.js。这里只留【3.0 自己的那一份事实】—— 列表是就地节点（.steward-target-picker 靠
  // .stewardComposer 定位、靠自己的 [hidden] 开合），所以走 opts.layer：不新建 .popover、不外挂
  // body、关闭只 hidden 不 remove。本函数仍是「关掉我这张列表」的唯一入口（submit／resetComposer／
  // 选项点击都调它），列表正开着（原语记的锚点就是那枚 chip）才动手，不会误关别人的浮层。
  // 焦点归还照旧：popover 归还给它收到的锚点，也就是那枚 chip。
  function closePicker() {
    if (popoverAnchor() !== byId('stewardTarget')) return false;
    closePopover();
    return true;
  }

  // 任何一条关闭路径（Esc／点外／自己 close／被下一个浮层顶掉）都到这里：摘 aria、注销 Esc 层。
  // 列表本身的 hidden 由 popover 按 layer 语义做（只藏不 remove），不必在这里再来一次。
  function forgetOpenPicker() {
    const chip = byId('stewardTarget');
    if (chip) chip.setAttribute('aria-expanded', 'false');
    if (releasePickerEscape) { releasePickerEscape(); releasePickerEscape = null; }
  }

  // 候选内容的写手：列表每次打开都由它重画一遍（原语在开之前会清空容器）。
  function fillPicker(picker) {
    const rows = candidates();
    const options = [{ sessionId: '', title: t('stewardShell.compose.targetSteward') }, ...rows];
    for (const row of options) {
      // 列表显示 label（重名带区分后缀），选中的仍是原话 title —— 后缀不进入 picked/handOff。
      const option = el('button', 'steward-target-option', row.label || row.title);
      option.type = 'button';
      option.setAttribute('role', 'option');
      option.setAttribute('aria-selected', String(Boolean(picked && picked.sessionId === row.sessionId)));
      option.addEventListener('click', () => {
        selectTarget(row.sessionId ? { sessionId: row.sessionId, title: row.title } : null);
      });
      picker.appendChild(option);
    }
    picker.appendChild(el('p', 'muted', t('stewardShell.compose.searchScope')));
  }

  function openPicker() {
    if (picked && picked.deliverySource) return;
    const picker = byId('stewardTargetPicker');
    const chip = byId('stewardTarget');
    if (!picker || !chip) return;
    // 已经开着（比如话里连着打了个「@」）：只重画候选，不麻烦原语 —— 原语那一下是 toggle 语义，
    // 锚点相同就当成「再点一次」，会把列表关掉；而这里要的是「还在挑目标，候选刷新一遍」。
    if (popoverAnchor() === chip) { fillPicker(picker); return; }
    popover(chip, () => { fillPicker(picker); }, {
      layer: { mount: picker.parentNode, node: picker },
      onOpen: () => {
        chip.setAttribute('aria-expanded', 'true');
        chip.setAttribute('aria-controls', 'stewardTargetPicker');   // copy-P2-4
        // 117j UX-F3：管家壳的 Esc 只有 steward-shell.js 那一处监听（走 stewardEscapeStack），
        // 所以这张列表照旧要 push 自己那一个关闭器 + owns —— 改走 popover 之后这条接线【不能省】：
        // 少了它就「Esc 关不掉」，或者两路各关一层。
        releasePickerEscape = stewardEscapeStack.push(() => {
          if (popoverAnchor() !== chip) return false;
          closePicker();
          return true;
        // 117k：候选列表本来就有自己那条 document 监听（W2-2 加的），这里补上同款判据是为了
        // 让「所有浮层点别处就收回」这件事在【一个地方】说得清；两路都关是幂等的。
        }, node => {
          const own = byId('stewardTargetPicker');
          const trigger = byId('stewardTarget');
          return Boolean(node && ((own && own.contains(node)) || (trigger && trigger.contains(node))));
        });
      },
      onClose: forgetOpenPicker,
    });
  }

  // Tab 在「如意 → 各候选线程」间循环（§8.8）。没有候选时不劫持 Tab，Shift+Tab 永远是正常的
  // 反向焦点移动 —— 键盘用户必须能离开输入框。
  function cycleTarget() {
    if ((picked && picked.deliverySource) || creatingNew()) return false;
    const rows = candidates();
    if (!rows.length) return false;
    const ring = [null, ...rows];
    const index = ring.findIndex(row => (row ? (picked && picked.sessionId === row.sessionId) : !picked));
    selectTarget(ring[(index + 1) % ring.length]);
    return true;
  }

  // ── 发送 ────────────────────────────────────────────────────────────────────
  // 117l D3：这里【没有】「上一句还没发完就不许再发」的闸。修前那道 `sending` 守卫与
  // conversation 里的 `streaming` 守卫叠在一起，用户连着说两句时第二句被无声丢弃（走查⑥）。
  // 清空输入框仍然是发送的第一步 —— 它同时也是天然的重入保护：第二次 submit 拿到的是空串。
  async function submit() {
    const input = byId('stewardComposerInput');
    if (!input || !conversation) return;
    const text = String(input.value || '').trim();
    if (!text) return;
    const target = currentTarget();
    const submittedGeneration = targetGeneration;
    // 走查 S-13：两种「发不出去」都要在【清空输入框之前】拦下，话与附件原样留着（修前先清后发，那句话既不上屏也不保留）：
    // 管家那条路上一句还在跑、排队已满时不能把话吞掉。直递附件由服务端按目标通道校验。
    if (!target && typeof conversation.sendQueueFull === 'function' && conversation.sendQueueFull()) {
      note(t('stewardShell.chat.queueFull'));
      return;
    }
    const prepared = target && conversation.prepareHandOff?.({ sessionId: target.sessionId, title: target.title, message: text, reason: routeReason, hits: routeHits, attachments: attachments.slice(), deliverySource: target.deliverySource });
    if (prepared?.error) { note(prepared.error); return; }
    const files = attachments.splice(0, attachments.length);   // 133e：这一句带走托盘里全部附件，托盘随即清空
    note('');
    renderTray();
    composerSent(input, text);                                 // 59 号文 §6：麦克风拿这次机器写的几句与发出去的字去学改字
    input.value = '';
    input.style.height = '';                                   // 133e：发完收回一行高
    input.placeholder = t('stewardShell.compose.placeholder');
    cancelPreroute();
    closePicker();
    prerouteSeq += 1;   // hunt2-steward ⑦:发出去之后,这一句的在途预判作废 —— 慢响应回来不许把 chip 又填回去
    try {
      // 117l D1：**手选的目标才直递**（那是用户明示，§8.12 第 4 条）；其余一律发给管家，预判只
      // 随 routeHint 走一趟提示（§11.9 D1「无论关键词匹配到什么，都要发给管家让它决定」）。
      if (target) await conversation.handOff({ sessionId: target.sessionId, title: target.title, message: text, reason: routeReason, hits: routeHits, attachments: files, prepared, ...(target.deliverySource ? { deliverySource: { ...target.deliverySource } } : {}) });
      else await conversation.sendToSteward(text, { routeHint: routeHintPayload(), ...(files.length ? { attachments: files } : {}) });
    } finally {
      // 手选只管这一次发送，之后自动回到「→ 如意」（§8.12 第 4 条）。
      // 等回执期间手选了别的目标,那是下一份草稿,迟到响应不能把它清掉。
      if (picked === target && targetGeneration === submittedGeneration) {
        newTarget = false;
        picked = null;
        routeKind = 'steward';
        routeHits = [];
        routeReason = '';
        hintDismissed = false;     // 117r-D3 ③ 复位点之一：发完这一句，下一句的预判不该被上一句否掉的状态拦住
      }
      renderChip();
    }
  }

  // ── 133e 附件托盘：与工作台 uploadFiles 同一条路（dataURL → /api/upload），记录形状同 04 makeAttachmentRecord ──
  const attachments = [];
  let pendingUploads = 0;
  const STEWARD_ATTACH_MAX_BYTES = 90 * 1048576;
  const STEWARD_ATTACH_MAX = 12;
  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsDataURL(file); });
  }
  function renderTray() {
    const tray = byId('stewardAttachTray');
    if (!tray) return;
    tray.textContent = '';
    attachments.forEach((f, i) => {
      const pill = el('span', 'attachment-pill');
      pill.append(el('span', '', `${f.name} · ${fmtBytes(f.size)}`));
      const x = el('button', 'attach-x'); x.type = 'button'; x.appendChild(icon('close', 12));
      x.setAttribute('aria-label', t('chat.attachRemoveAria')); x.title = t('common.remove');
      x.onclick = () => { attachments.splice(i, 1); renderTray(); };
      pill.appendChild(x);
      tray.appendChild(pill);
    });
  }
  function note(text) { const n = byId('stewardComposerNote'); if (n) n.textContent = String(text || ''); }
  async function addFiles(files) {
    pendingUploads += 1;
    try {
      for (const file of files) {
        if (attachments.length >= STEWARD_ATTACH_MAX) { note(t('stewardShell.compose.attachMax', { n: STEWARD_ATTACH_MAX })); break; }
        if (file.size > STEWARD_ATTACH_MAX_BYTES) { note(t('toast.fileTooLarge', { p1: file.name })); continue; }
        try {
          const data = await fileToDataUrl(file);
          const res = await api('/api/upload', { method: 'POST', body: JSON.stringify({ name: file.name, data }) });
          if (res && res.file) { attachments.push(res.file); note(''); }
        } catch (e) { note(t('toast.uploadFail', { p1: String((e && e.message) || e) })); }
      }
      renderTray();
      const input = byId('stewardComposerInput'); if (input) input.focus();
    } finally { pendingUploads -= 1; }
  }

  // An explicit local draft action only. Never dispatch input, submit, handOff or sendToSteward.
  function importExternalReference(item) {
    const input = byId('stewardComposerInput');
    if (!input || !isStewardMode()) return { ok: false, reason: 'unavailable' };
    if (String(input.value || '').length || attachments.length || pendingUploads || picked || creatingNew()
        || ['starting', 'warming', 'recording', 'transcribing'].includes(voice.phase())) return { ok: false, reason: 'draftBusy' };
    if (!item || !['qq', 'feishu'].includes(item.platform) || typeof item.text !== 'string' || !item.text.trim()) return { ok: false, reason: 'invalid' };
    cancelPreroute(); prerouteSeq += 1;
    targetGeneration += 1;
    newTarget = false;
    closePicker();
    picked = null; routeKind = 'steward'; routeHits = []; routeReason = ''; hintDismissed = true;
    input.value = externalBotReferenceText(item, t);
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight || 100, 240) + 'px';
    input.focus({ preventScroll: true });
    renderChip(); note(t('externalBots.draftAdded'));
    return { ok: true };
  }
  function beginDeliveryRevision(source) {
    const input = byId('stewardComposerInput');
    if (!input || !isStewardMode()) return { ok: false };
    if (String(input.value || '').length || attachments.length || pendingUploads || picked || creatingNew() || ['starting', 'warming', 'recording', 'transcribing'].includes(voice.phase())) return { ok: false, reason: 'draftBusy' };
    if (!source || !source.sessionId || !(source.turnSeq > 0)) return { ok: false };
    cancelPreroute(); prerouteSeq += 1; closePicker();
    targetGeneration += 1;
    newTarget = false;
    picked = { sessionId: source.sessionId, title: source.title, deliverySource: { turnSeq: source.turnSeq, latestTurnSeq: source.latestTurnSeq, sourceStamp: source.sourceStamp, fileStamp: source.fileStamp } };
    routeKind = 'steward'; routeHits = []; routeReason = ''; hintDismissed = true;
    input.placeholder = t('delivery.revisionPlaceholder');
    note(t('delivery.revisionReady')); renderChip(); input.focus({ preventScroll: true });
    return { ok: true };
  }
  function restoreHandOffDraft(attempt) {
    const input = byId('stewardComposerInput');
    if (!input || !isStewardMode() || input.value || attachments.length || pendingUploads || picked || creatingNew() || ['starting', 'warming', 'recording', 'transcribing'].includes(voice.phase())) return { ok: false };
    cancelPreroute(); prerouteSeq += 1; closePicker();
    targetGeneration += 1;
    newTarget = false;
    picked = { sessionId: attempt.sessionId, title: attempt.title, ...(attempt.deliverySource ? { deliverySource: { ...attempt.deliverySource } } : {}) };
    routeKind = 'steward'; routeHits = []; routeReason = ''; hintDismissed = true;
    input.value = attempt.text; attachments.push(...attempt.attachments.map(file => ({ ...file })));
    input.placeholder = t(attempt.deliverySource ? 'delivery.revisionPlaceholder' : 'stewardShell.compose.placeholder');
    renderTray(); renderChip(); input.focus({ preventScroll: true }); return { ok: true };
  }

  // U14/U16 走查：chip／picker／「+」／发送键这几处的 aria-label／title 都是 buildComposer()
  // 建这枚节点【那一次】用 t() 焊死的静态文案（不像 renderChip() 里那句会跟着 target/picked 状态
  // 变——它们本身就不依赖状态，纯粹是控件的固定无障碍名/提示）。买家早的那一拍如果还没等到
  // setLocale(en-US) 落定（冷启动就是 en-US，或运行时切语言不刷新页面），就会一直停在建它那一刻
  // 的语言。抽成一个可重复调用的函数，buildComposer() 建完调一次，i18n:change 来了再调一次
  // （见文件尾的监听），不必假装这几处「反正状态一变就会重画」。
  function relabelComposerChrome() {
    const input = byId('stewardComposerInput');
    if (input) {
      const needsModel = input.disabled && input.getAttribute('data-i18n-attr') === 'placeholder:stewardShell.compose.needModel';
      input.placeholder = t(needsModel ? 'stewardShell.compose.needModel'
        : picked && picked.deliverySource ? 'delivery.revisionPlaceholder' : 'stewardShell.compose.placeholder');
    }
    const chip = byId('stewardTarget');
    if (chip) chip.setAttribute('aria-label', t('stewardShell.compose.targetLabel'));
    const picker = byId('stewardTargetPicker');
    if (picker) picker.setAttribute('aria-label', t('stewardShell.compose.pick'));
    const plus = byId('stewardComposerPlus');
    if (plus) { plus.title = t('stewardShell.compose.plus'); plus.setAttribute('aria-label', t('stewardShell.compose.plus')); }
    const send = byId('stewardComposerSend');
    if (send) { send.title = t('stewardShell.compose.send'); send.setAttribute('aria-label', t('stewardShell.compose.send')); }
  }
  try { globalThis.addEventListener('i18n:change', () => { relabelComposerChrome(); renderChip(); }); } catch { /* ignore */ }

  // ── 装配：chip / picker / 「+」浮层 / 附件托盘，全部 createElement，零 innerHTML ─────────
  function buildComposer() {
    const composer = byId('stewardComposer');
    const input = byId('stewardComposerInput');
    if (!composer || !input || byId('stewardTarget')) return false;

    const chip = el('button', 'steward-target');
    chip.type = 'button';
    chip.id = 'stewardTarget';
    chip.setAttribute('aria-haspopup', 'listbox');
    chip.setAttribute('aria-expanded', 'false');
    chip.setAttribute('aria-label', t('stewardShell.compose.targetLabel'));
    // W4b：默认态露出的那一枚「@」（is-quiet 时样式层显它、收 label）。纯装饰，可访问名在 chip 的 aria-label 上。
    const at = el('span', 'steward-target-at', '@');
    at.setAttribute('aria-hidden', 'true');
    chip.appendChild(at);
    chip.appendChild(el('span', 'steward-target-label', t('stewardShell.compose.targetSteward')));
    const clear = el('span', 'steward-target-clear', '×');
    clear.hidden = true;
    chip.appendChild(clear);
    chip.addEventListener('click', event => {
      if (event.target === clear) {
        cancelTarget();
        return;
      }
      const picker = byId('stewardTargetPicker');
      if (picker && !picker.hidden) closePicker(); else openPicker();
    });

    const cancel = el('button', 'steward-act hidden');
    cancel.id = 'stewardComposerCancelTarget'; cancel.type = 'button'; cancel.hidden = true;
    cancel.addEventListener('click', cancelTarget);

    const picker = el('div', 'steward-target-picker');
    picker.id = 'stewardTargetPicker';
    picker.setAttribute('role', 'listbox');
    picker.setAttribute('aria-label', t('stewardShell.compose.pick'));
    picker.hidden = true;

    // 133e（用户 2026-09-21「管家层这个加号点不了，修一下，最好复用线台类似的东西」）：「＋」不再是占位 ——
    // 与工作台 #composerMoreBtn 同款的小浮层（同一个 popover 原语、同一套 .composer-more-pop/.cm-item 样式），两项：
    //   · 添加文件：与工作台同一条路（本地读成 dataURL → POST /api/upload → 记录进附件托盘），发送时随这句话一起给
    //     /api/steward/message，服务端把它们原样交给管家回合（runSessionTurn 的 attachments，与工作台回合同一条管线）；
    //   · 另起一件：把 chip 摆成「→ 如意 · 另起一件」（就是抽屉「＋ 线程」那条路 markNewInMission('')）。
    // 技能库／压缩不进来：前者是 CLI 概念（管家线程只走 OpenAI 端点），后者管家会话自己有节流。
    const plus = el('button', 'steward-plus');
    plus.type = 'button';
    plus.id = 'stewardComposerPlus';
    plus.title = t('stewardShell.compose.plus');
    plus.setAttribute('aria-label', t('stewardShell.compose.plus'));
    plus.setAttribute('aria-haspopup', 'menu');
    paintGlyph(plus, 'plus');
    const fileInput = doc().createElement('input');
    fileInput.type = 'file';
    fileInput.multiple = true;
    fileInput.id = 'stewardComposerFile';
    fileInput.hidden = true;
    fileInput.addEventListener('change', () => { const files = [...(fileInput.files || [])]; fileInput.value = ''; void addFiles(files); });
    plus.addEventListener('click', () => {
      popover(plus, close => {
        const wrap = el('div', 'composer-more-pop');
        const attach = el('button', 'cm-item'); attach.type = 'button';
        attach.append(icon('paperclip', 16), doc().createTextNode(t('composer.attachFile')));
        attach.onclick = () => { close(); fileInput.click(); };
        const fresh = el('button', 'cm-item'); fresh.type = 'button';
        fresh.append(icon('plus', 16), doc().createTextNode(t('rail.newTask')));
        fresh.onclick = () => { close(); composerApi.markNewInMission(''); };   // 点击时 composerApi 早已建好（下面 return 的那份）
        wrap.append(attach, fresh);
        wrap.append(privacyComposerMenuItem('stewardPrivacyIndicator', close));
        return wrap;
      }, { placement: 'top-start' });
    });

    // 117i：圆形发送键（原型 .send）。Enter 一直是主路径，这枚键只是把同一个 submit() 摆到
    // 手指够得着的地方 —— 触屏与「不知道按什么」的第一次都需要一个看得见的出口。
    const send = el('button', 'steward-send');
    send.type = 'button';
    send.id = 'stewardComposerSend';
    send.title = t('stewardShell.compose.send');
    send.setAttribute('aria-label', t('stewardShell.compose.send'));
    paintGlyph(send, 'send');   // 121-K8（§2.10.1 一套词汇表）：与工作台那枚发送同一个字形
    send.addEventListener('click', () => { submit(); });

    // 117r-D3 ②（用户第八轮走查②「最好不要和输入框放同一行，会把输入框内容挤没，要不放在输入框
    // 上面」）：chip 独占一行，挪到输入框上面；input/plus/send 三个一起挪进一个新的行容器
    // .steward-composer-row。picker 仍然是 .stewardComposer 的直接子节点、紧跟在 chip 后面——
    // 它是 position:absolute; bottom:100%（steward-conversation.css），锚点是 .steward-composer
    // 自己的 position:relative，不是 chip；新加的 inputRow【不】设 position，不会抢那个定位基准。
    const inputRow = el('div', 'steward-composer-row');
    composer.insertBefore(inputRow, input);
    composer.insertBefore(chip, inputRow);
    composer.insertBefore(cancel, inputRow);
    composer.insertBefore(picker, inputRow);
    // 133e：附件托盘独占一行、在输入行上面（与工作台 #attachmentTray 同一套 pill 样式）；没附件时 :empty 收掉高度。
    const tray = el('div', 'attachment-tray steward-attach-tray');
    tray.id = 'stewardAttachTray';
    composer.insertBefore(tray, inputRow);
    composer.appendChild(fileInput);
    inputRow.appendChild(input);
    inputRow.appendChild(plus);
    inputRow.appendChild(send);
    voice.sync();   // 127-⑦：此刻 config 多半还没到，不建；到了由组合根的 syncComposerVoices() 再判

    input.disabled = false;
    input.placeholder = t('stewardShell.compose.placeholder');
    input.addEventListener('input', () => {
      autoGrow(input);                                        // 133e：多打几行就长高（上限在 CSS max-height），不再只见一行
      if (picked || creatingNew()) return;                    // 显式目标不被自动预判改写
      const value = String(input.value || '');
      if (value.endsWith('@')) openPicker();
      schedulePreroute(value);
    });
    // 117j W2-2 那条「点列表【外】任意处收起」不再自己挂 document 监听（32 号文 §4 M2）：这件事现在
    // 归两处、共用本层下面 push 的那一份 owns 判据 —— popover 原语的捕获阶段 mousedown，以及
    // steward-shell.js 那处捕获阶段 click（stewardEscapeStack.handleOutsideClick）。两条都幂等，而且
    // 都天然满足 W2-2 那条次序要求：撤回之后的「换一条」在【别的按钮的 click 处理器里】打开列表，
    // 而那一刻（mousedown 已成过去、栈里还没有这一层）谁都还没动手，目标处理器随后才把它打开 ——
    // 不会刚开就被自己关掉（实测 G2a 曾经退化成 0 项，就是这个次序问题）。
    input.addEventListener('keydown', event => {
      // 33 号文 §4：回车发送的判据（Enter ＋ 非 Shift ＋ 非输入法组合中）全仓只有 steward-chips.js
      // 一份；这个监听器还兼管 Esc 与 Tab，所以读判据、不换整框接线。
      if (isSubmitEnter(event)) { event.preventDefault(); submit(); return; }
      if (event.key === 'Escape') { closePicker(); return; }
      if (event.key === 'Tab' && !event.shiftKey && cycleTarget()) event.preventDefault();
    });
    renderChip();
    return true;
  }

  // 离开管家壳：清去抖计时器并让过期响应作废（序号 +1），不留任何后台活动。
  function resetComposer() {
    cancelPreroute();
    prerouteSeq += 1;
    targetGeneration += 1;
    newTarget = false;
    voice.cancel();   // 127-⑦：离开管家壳时还在录的那一段直接丢弃（不转写、不回填）
    attachments.length = 0; renderTray();   // 133e：离开管家壳，托盘里没发出去的附件丢掉（已上传的文件留在 uploads 目录，与工作台同）
    closePicker();
    picked = null;
    routeKind = 'steward';
    routeHits = [];
    routeReason = '';
    hintDismissed = false;   // 117r-D3 ③ 复位点之一：离开管家壳，否掉的状态不该带到下一次进壳
    relabelComposerChrome(); note('');
    renderChip();
  }

  function bindStewardComposer() {
    return buildComposer();
  }

  const composerApi = Object.freeze({
    bindStewardComposer,
    resetComposer,
    importExternalReference,
    beginDeliveryRevision,
    restoreHandOffDraft,
    submit,
    // 117c：撤回／换一条之后由对话流回调，把候选列表就地打开 ——「那递给谁？」问完就得让用户
    // 能立刻挑，而不是让他自己再去点 chip（§8.12 第 3 条「改递时同样先回退再递」）。
    openPicker: () => { openPicker(); const input = byId('stewardComposerInput'); if (input) input.focus(); },
    // 117d：抽屉的「＋ 线程」把输入区 chip 置为「→ 如意 · 在事项下新开」并记住目标事项。
    // 只改 chip 形态，不发请求 —— 真正的创建仍要用户说一句话、由管家的委托书完成。
    markNewInMission: missionId => {
      if (picked && picked.deliverySource) {
        note(t('delivery.cancelBeforeNew'));
        byId('stewardComposerInput')?.focus();
        return null;
      }
      cancelPreroute(); prerouteSeq += 1; closePicker(); targetGeneration += 1;
      newTarget = true;
      picked = null;
      // 117l-B2 ②：看板空态那枚「＋ 线程」没有事项可挂（一条线程都还没有），派来的 missionId 是空串。
      // 这种时候 chip 说「在事项下新开」是句假话 —— 没有那个「事项」。空 id 一律落到「另起一件」。
      routeKind = missionId ? 'missionNew' : 'new';
      routeHits = [];
      routeReason = String(missionId || '');
      hintDismissed = true;
      relabelComposerChrome(); note(t('stewardShell.compose.newReady'));
      renderChip();
      const input = byId('stewardComposerInput');
      if (input && typeof input.focus === 'function') input.focus();
      return routeReason;
    },
    routeState: () => ({ kind: routeKind, hits: routeHits.slice(), picked: picked ? { ...picked } : null }),
  });
  return composerApi;
}
