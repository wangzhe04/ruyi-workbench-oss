// 如意 Ruyi — client state module (v1.3-FE1 前端模块化 Phase 1)。
//
// 纯搬家:此文件把原 app.js 顶部的 `state` 对象骨架与消息窗口化常量原样搬来,结构一字未改。
// app.js 通过 `import { state, MSG_WINDOW_* } from './js/state.js'` 取回同名绑定,全文件引用不变。
//
// 兼容层:此前 state 在经典脚本里是函数作用域顶层 const,浏览器控制台/preview 调试事实上可访问。
// 转为 ES Module 后模块作用域不再自动全局,故显式 `window.state = state` 挂回,保住调试/预览契约
// (dom-contract.e2e 的 ⑤ 断言此行存在)。

// 客户端运行时状态。字段与原 app.js 完全一致(仅搬家,不改结构/不改初值)。
export const state = {
  status: null,
  config: {},
  sessions: [],
  currentSession: null,
  attachments: [],
  uploading: 0,           // F13: 在飞的附件上传数(app.js uploadFiles 维护;sendPrompt 据此拦发送,免得附件漏掉挂到下一条)
  streaming: false,
  rawEvents: [],          // {seq, line} for the debug panel
  paletteIndex: 0,
  shownUsage: null,       // last usage object reflected in the context meter
  resumable: null,        // v0.8-S0 A6: {dangling,kind} for the current session's resume banner
  playbooks: [],          // v0.9-S2: playbook cards for the empty state (built-in ∪ user, with availability)
  // v1.0-S7 / 第77波(perf): message windowing. A high row count or heavy content budget makes renderCurrentSession
  // paint only a bounded tail (at most MSG_WINDOW_TAIL) and show「加载更早」. msgWindowStart is the index of
  // the FIRST rendered message (0 = fully expanded). Reset to null on session open so each session starts
  // windowed. Small sessions keep it null → zero behavior change.
  msgWindowStart: null,
  // 117s-G(27 号文 §11.13.1 ②):服务端对「这条会话此刻该走哪条递话通道」的判定，随
  // GET /api/sessions/:id 的 relay 键回来（单点在 13h stewardRelayChannelFor：answer > permission >
  // queued > steer > turn）。经典壳的发送门与发送键三态都读它 —— activeTurns 只认【本页自己起的流】，
  // 管家在服务端起的回合不在里面。形状 { sessionId, channel, wait } 或 null（服务端说这条线程空闲）。
  // 放 state 而不是各自的模块级变量：写在 session-experience（取信封的那一处），读在
  // chat-stream-runtime（发送门），两边拿到的是同一个 state 对象，无须往组合根加一条注入。
  sessionRelay: null,
};

// Count thresholds remain stable; turn-narrative.js adds a bounded content-weight budget so even a few giant
// tool results/answers cannot synchronously paint an unbounded DOM.「加载更早」still reaches every row.
export const MSG_WINDOW_THRESHOLD = 150;
export const MSG_WINDOW_TAIL = 120;
export const MSG_WINDOW_STEP = 120;

// 兼容层:保留 window.state(preview 控制台/调试历来可访问的全局符号)。见文件头说明。
window.state = state;
