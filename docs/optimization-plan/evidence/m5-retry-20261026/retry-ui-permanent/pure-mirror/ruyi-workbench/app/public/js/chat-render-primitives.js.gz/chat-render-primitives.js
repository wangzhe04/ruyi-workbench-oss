'use strict';

// 109b: 工具结果图内联缩略图。纯检测函数,零 DOM/deps 依赖,可独立单元测试。
// 白名单工具(剥离桥接 serverId 前缀后匹配) + 结果对象里任一路径字段扩展名命中图片格式,
// 且结果未显式标记失败(success/ok !== false)时,返回该图片的绝对路径;否则返回 null。
const TOOL_IMAGE_TOOL_NAMES = new Set([
  'chart_image',
  'desktop_screenshot',
  'window_screenshot',
  'screenshot',
  'screenshot_full',
  'screenshot_region',
  'get_clipboard_image',
  'image_resize',
]);
const TOOL_IMAGE_PATH_KEYS = ['path', 'output_path', 'outputPath', 'save_path', 'savePath'];
const TOOL_IMAGE_EXTENSIONS = new Set(['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp']);
// 桥接工具名形如 "acc__chart_image"(serverId__toolName);取最后一段 "__" 之后的部分参与白名单比对。
function stripBridgedToolPrefix(toolName) {
  const name = String(toolName || '');
  const idx = name.lastIndexOf('__');
  return idx >= 0 ? name.slice(idx + 2) : name;
}
export function detectToolImagePath(toolName, result) {
  if (!result || typeof result !== 'object') return null;
  if (result.success === false || result.ok === false) return null;
  if (!TOOL_IMAGE_TOOL_NAMES.has(stripBridgedToolPrefix(toolName))) return null;
  for (const key of TOOL_IMAGE_PATH_KEYS) {
    const value = result[key];
    if (typeof value !== 'string' || !value) continue;
    const match = /\.([a-z0-9]+)$/i.exec(value);
    if (match && TOOL_IMAGE_EXTENSIONS.has(match[1].toLowerCase())) return value;
  }
  return null;
}

// N11: 工具结果的「富渲染」判定。纯函数(零 DOM/deps),可独立单元测试。
// 结果是普通对象且含 ① 多行/很长的字符串字段(stdout/stderr/content/text/diff…)或 ② 内嵌图片时返回
// { meta, texts:[{key,text}], images:[{kind:'attachment',att}|{kind:'data',src,field}] },其余键进 meta(紧凑 JSON);
// 否则返回 null —— 调用方照旧把整份结果当 JSON 文本显示(小结果的外观逐字不变)。
// 图片来源:服务端 N3 落盘后的 imageAttachments[{id,name,…}](走既有 /api/upload/content 附件回显通路),
// 以及 N3 之前存下的老会话里直接内嵌的 image/image_base64/screenshot.image(按 data URI 直接画,不再当整墙 base64 文本)。
const RESULT_TEXT_LONG = 400;           // 单行但很长的字符串也当文本块
const RESULT_IMAGE_KEY_RE = /image|base64|screenshot|thumbnail|b64/i;
const RESULT_IMAGE_MIN_CHARS = 2000;
const RESULT_IMAGE_INLINE_MAX = 8000000; // 老会话里内嵌图超过这么大就不画了(只留占位说明)
const RESULT_OMITTED_IMAGE_RE = /^\[image omitted from stored result/;
function resultImageDataUri(key, v) {
  if (typeof v !== 'string' || v.length < RESULT_IMAGE_MIN_CHARS || !RESULT_IMAGE_KEY_RE.test(key)) return '';
  if (v.startsWith('data:image/')) return /^data:image\/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=\s]+$/i.test(v) ? v : '';
  const mime = v.startsWith('iVBOR') ? 'image/png' : v.startsWith('/9j/') ? 'image/jpeg' : v.startsWith('R0lGO') ? 'image/gif'
    : v.startsWith('UklGR') ? 'image/webp' : v.startsWith('Qk') ? 'image/bmp' : '';
  return mime && /^[A-Za-z0-9+/=\s]+$/.test(v) ? `data:${mime};base64,${v}` : '';
}
export function toolResultRichParts(result) {
  if (!result || typeof result !== 'object' || Array.isArray(result)) return null;
  const texts = [], images = [], meta = {};
  for (const [key, v] of Object.entries(result)) {
    if (key === 'imageAttachments' && Array.isArray(v)) {
      for (const att of v) if (att && typeof att === 'object' && att.id && att.name) images.push({ kind: 'attachment', att });
      continue;
    }
    if (typeof v === 'string') {
      const uri = resultImageDataUri(key, v);
      if (uri) { images.push({ kind: 'data', src: uri, field: key, tooBig: v.length > RESULT_IMAGE_INLINE_MAX }); continue; }
      if (RESULT_OMITTED_IMAGE_RE.test(v)) continue;
      if (v.includes('\n') || v.length >= RESULT_TEXT_LONG) { texts.push({ key, text: v }); continue; }
    } else if (v && typeof v === 'object' && !Array.isArray(v)) {
      let copy = null;
      for (const [k2, v2] of Object.entries(v)) {
        const uri = resultImageDataUri(k2, v2);
        if (!uri && !(typeof v2 === 'string' && RESULT_OMITTED_IMAGE_RE.test(v2))) continue;
        if (!copy) copy = { ...v };
        delete copy[k2];
        if (uri) images.push({ kind: 'data', src: uri, field: `${key}.${k2}`, tooBig: v2.length > RESULT_IMAGE_INLINE_MAX });
      }
      if (copy) { meta[key] = copy; continue; }
    }
    meta[key] = v;
  }
  if (!texts.length && !images.length) return null;
  return { meta, texts, images };
}

// 2026-10（用户实报：管家回复里「单核快 20%~25%，多核快 10%~15%」中间一大段被画成删除线）：marked 的 GFM
// 删除线把【单个】波浪线也当成一对（vendor 里 del 规则是 /^(~~?)…\1/），而中文里 `~` 是写区间的常用记号 ——
// 一句话里出现两个区间，两个 `~` 之间的字就全被划掉。这里只认 `~~成对双波浪~~`；落单的 `~` 原样当字。
// 用自己的 Marked 实例而不是 marked.use：不改全局的 marked（vendor 是全仓共享的那一份）。纯函数，入参是 marked
// 库本身（浏览器里是全局 marked，单测里 require vendor 那一份），建不出来返回 null（调用方回落 marked.parse）。
const TILDE_DEL = /^~~(?=[^\s~])([\s\S]*?[^\s~])~~(?=[^~]|$)/;
// breaks:单个换行是否画成 <br>。对话里默认 true(聊天口吻,一行一回车);手册这类按段落硬折行写的英文文档要 false,
// 否则每个源码折行都被画成断行(help-viewer.js 经 renderMarkdownInto 的 {breaks:false} 取用)。
export function createMarkdownParser(markedLib, { breaks = true } = {}) {
  if (!markedLib || typeof markedLib.Marked !== 'function') return null;
  try {
    return new markedLib.Marked({
      gfm: true,
      breaks,
      tokenizer: {
        del(src) {
          const cap = TILDE_DEL.exec(src);
          if (cap) return { type: 'del', raw: cap[0], text: cap[1], tokens: this.lexer.inlineTokens(cap[1]) };
          if (src[0] === '~') return { type: 'text', raw: '~', text: '~' };
          return false;
        },
      },
    });
  } catch { return null; }
}

// 安全走查 S8:Markdown 白名单曾对所有元素原样保留 `class`,于是模型输出 / 工具结果 / 网页转写里的
// `<div class="modal-backdrop">`、`.mermaid-lightbox`、`.attachment-viewer-backdrop` 会被渲染成应用自己的
// position:fixed 全屏覆盖层 —— 可以伪造「会话过期,请重新登录」的弹窗、挡住权限卡。现在 class 只放行
// 渲染管线真正会从 marked 输出里带出来的两族:围栏代码块的 `language-*`,以及高亮器的 `hljs` / `hljs-*`
// (都只改配色,不定位、不盖层)。其余(含应用自己的所有布局/弹层类)一律剥掉。纯函数,可单测。
const SAFE_MARKDOWN_CLASS_RE = /^(?:language-[A-Za-z0-9_+#.-]{1,40}|hljs(?:-[A-Za-z0-9_-]{1,40})?)$/;
export function sanitizeMarkdownClassValue(value) {
  return String(value == null ? '' : value).split(/\s+/).filter(token => SAFE_MARKDOWN_CLASS_RE.test(token)).join(' ');
}

export function createChatRenderPrimitives(deps = {}) {
  const {
    $,
    api,
    apiErrText,
    privacyFailure = () => null,
    privacyFailureCard = () => null,
    bindDisclosureSource = () => {},
    copyDisclosure = () => { toast(t("privacy.export.sourceMissing"), "err"); },
    // Agent CLI 登记表的查询函数（js/agent-cli-registry.js 的 agentCliMeta）。本模块零 import，由组合根注入。
    agentCliMeta,
    autoGrow,
    buildModal,
    currentEngineMeta,
    currentModelId,
    el,
    engineVisual,
    escapeHtml,
    // 109b: 工具结果图内联缩略图的取图函数。默认走既有 /api/file/preview 端点(与 file-browser.js 的
    // renderFilePreviewInto 同一鉴权 api() 封装),不新造事实源、不新增端点。deps 可覆盖以便单元测试打桩。
    // N11: 落盘后的截图(result.imageAttachments)经既有 /api/upload/content 取回,返回 objectURL 的 Promise。
    // 默认拒绝(=不画图,只留文字);组合根注入 app.js 的 attachmentImageUrl(带鉴权头的 fetch → blob)。
    fetchAttachmentImage = () => Promise.reject(new Error('no attachment loader')),
    fetchFilePreview = filePath => {
      const sessionId = state && state.currentSession && state.currentSession.id;
      const query = '?path=' + encodeURIComponent(filePath) + (sessionId ? '&sessionId=' + encodeURIComponent(sessionId) : '');
      return api('/api/file/preview' + query);
    },
    fmtTime,
    fmtTokens,
    hljs,
    humanizeToolName,
    icon,
    isProviderMode,
    marked,
    // 109b: 图片超过预览上限(image-toobig)时,「在侧栏预览」按钮的落点,由组合根注入(打开工具面板 +
    // 切到文件页签 + renderFilePreviewInto)。缺省空实现,按钮点了也不报错,只是静默无动作。
    openFilePreview = () => {},
    refreshPlaybooks,
    refreshSessions,
    // 128f-⑫（审计 D）：回溯之后右栏打开着的页签（变更）重读。组合根注入；缺省空实现。
    refreshToolPane = () => {},
    renderCurrentSession,
    // 109a: mermaid 图表运行时由组合根注入(js/mermaid-runtime.js)。这里保持依赖注入而不是顶部 import,
    // 是因为若干单元测试用 vm 直接跑本文件的函数体,顶部 ESM import 会让它们编译失败。
    renderMermaidBlocks = () => Promise.resolve(0),
    renderResumeBanner,
    // F9:「编辑重发」把原消息的附件放回托盘后重画托盘(组合根注入 app.js 的 renderAttachments;缺省空实现)。
    renderAttachments = () => {},
    saveAsMemory,
    sendPrompt,
    state,
    t,
    tCount,
    toast,
  } = deps;

  function iconTextBtn(btn, name, label, size = 16) {
    if (!btn) return;
    btn.textContent = '';
    const ic = icon(name, size);
    if (ic) btn.appendChild(ic);
    if (label) btn.appendChild(document.createTextNode(label));
  }

  /* ---------------- markdown rendering (XSS-safe) ---------------- */
  const ALLOWED_TAGS = new Set(['A','P','BR','HR','STRONG','B','EM','I','DEL','S','CODE','PRE','BLOCKQUOTE','UL','OL','LI','H1','H2','H3','H4','H5','H6','TABLE','THEAD','TBODY','TR','TH','TD','IMG','SPAN','DIV']);
  function sanitizeNode(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null);
    const toRemove = [];
    let node = walker.nextNode();
    while (node) {
      if (!ALLOWED_TAGS.has(node.tagName)) {
        toRemove.push(node);
      } else {
        for (const attr of [...node.attributes]) {
          const name = attr.name.toLowerCase();
          const val = attr.value;
          if (name.startsWith('on')) { node.removeAttribute(attr.name); continue; }
          if (name === 'href' || name === 'src') {
            // Strip control/whitespace chars (browsers ignore them in schemes, e.g. "java\tscript:")
            // then allowlist protocols: http/https/mailto + relative/fragment. Everything else out.
            const v = val.replace(/[\u0000-\u0020]+/g, '');
            let ok = false;
            try {
              const u = new URL(v, location.href);
              ok = ['http:', 'https:', 'mailto:'].includes(u.protocol);
            } catch { ok = false; }
            // allow pure relative/fragment refs (no scheme)
            if (!ok && /^[#/.?]/.test(v) && !/^[a-z][a-z0-9+.-]*:/i.test(v)) ok = true;
            if (!ok) { node.removeAttribute(attr.name); continue; }
          } else if (name === 'class') {
            // S8:只留 language-* / hljs*(见模块级 sanitizeMarkdownClassValue),其余剥掉,剥空了整条属性去掉。
            const kept = sanitizeMarkdownClassValue(val);
            if (kept) { if (kept !== val) node.setAttribute(attr.name, kept); }
            else node.removeAttribute(attr.name);
          } else if (name !== 'alt' && name !== 'title') {
            node.removeAttribute(attr.name);
          }
        }
      }
      node = walker.nextNode();
    }
    for (const n of toRemove) { while (n.firstChild) n.parentNode.insertBefore(n.firstChild, n); n.remove(); }
  }
  // P1-perf: renderMarkdown 结果 LRU 缓存。每次 marked.parse 都是全量解析 + sanitizeNode 树遍历；
  // 回合终态重取会话会使消息对象身份全变，renderCurrentSession 对窗口内全部消息（≤120 条）重渲染时
  // 会重复解析同一批文本。marked 输出只依赖原文（不含 locale 文案），按 text 键控缓存最近 128 项。
  // 超长文本（>64KB）跳过缓存：流式封段的累加前缀会产生大量近重复长键，缓存 128 条会把内存推到
  // 数百 MB；超长单条解析成本本就接近线性上限，不做缓存反而省内存。
  const MD_CACHE_MAX = 128;
  const MD_CACHE_MAX_CHARS = 64 * 1024;
  const mdCache = new Map();
  function prepareExternalLinks(root) {
    for (const link of root.querySelectorAll('a[href]')) {
      try {
        const url = new URL(link.getAttribute('href'), location.href);
        const isWebLink = url.protocol === 'http:' || url.protocol === 'https:';
        const isExternal = url.protocol === 'mailto:' || (isWebLink && url.origin !== location.origin);
        if (!isExternal) continue;
        // These attributes are added only after sanitization, so untrusted Markdown cannot
        // smuggle its own target/rel values through the attribute allowlist.
        link.setAttribute('target', '_blank');
        link.setAttribute('rel', 'noopener noreferrer');
      } catch { /* sanitizeNode already removed malformed/unsafe href values */ }
    }
  }
  // 2026-10:只认 ~~双波浪~~ 的删除线(理由见模块级 createMarkdownParser 头注)。建一次、按需建。
  let mdParser;
  let mdParserNoBreaks;
  function markdownParser(breaks = true) {
    if (breaks) {
      if (mdParser === undefined) mdParser = createMarkdownParser(typeof marked === 'undefined' ? null : marked);
      return mdParser;
    }
    if (mdParserNoBreaks === undefined) mdParserNoBreaks = createMarkdownParser(typeof marked === 'undefined' ? null : marked, { breaks: false });
    return mdParserNoBreaks;
  }
  // opts.breaks === false:单个换行不画成 <br>(手册用)。缓存键带上这一位 —— 同一段原文两种口径的输出不同,不能互相命中。
  function renderMarkdown(text, opts) {
    const key = String(text || '');
    const breaks = !(opts && opts.breaks === false);
    const cacheKey = breaks ? key : '\u0000nobr\u0000' + key;
    const cacheable = key.length > 0 && key.length <= MD_CACHE_MAX_CHARS;
    if (cacheable) {
      const hit = mdCache.get(cacheKey);
      if (hit !== undefined) {
        // Map 迭代序即插入序：命中后重插到末尾保持 LRU。
        mdCache.delete(cacheKey); mdCache.set(cacheKey, hit);
        return hit;
      }
    }
    let out;
    try {
      if (typeof marked === 'undefined') out = `<div class="plain">${escapeHtml(key)}</div>`;
      else {
        const parser = markdownParser(breaks);
        const html = parser ? parser.parse(key) : marked.parse(key, { gfm: true, breaks });
        const tpl = document.createElement('template');
        tpl.innerHTML = html;
        sanitizeNode(tpl.content);
        prepareExternalLinks(tpl.content);
        out = tpl.innerHTML;
      }
    } catch { out = `<div class="plain">${escapeHtml(key)}</div>`; }
    if (cacheable) {
      mdCache.set(cacheKey, out);
      if (mdCache.size > MD_CACHE_MAX) mdCache.delete(mdCache.keys().next().value); // 淘汰最久未用
    }
    return out;
  }
  function renderMarkdownInto(container, text, opts) {
    if (!container) return container;
    // renderMarkdown has already parsed and sanitized the markup. Keeping the
    // trusted HTML assignment inside this shared renderer prevents consumers
    // from growing their own, less consistent Markdown/XSS paths.
    container.innerHTML = renderMarkdown(text, opts);
    return container;
  }
  function addPlainCopyAction(host, sourceNode, options) {
    const menu = el('details', 'privacy-copy-options');
    const summary = el('summary', '', '⋯'); summary.setAttribute('aria-label', t('privacy.copy.options')); summary.title = t('privacy.copy.options');
    const plain = el('button', '', t('privacy.copy.plain')); plain.type = 'button';
    plain.title = t('privacy.copy.plainNotice');
    plain.onclick = event => { event.preventDefault(); event.stopPropagation(); menu.open = false; copyDisclosure(sourceNode, { ...options, plaintext: true }); };
    menu.append(summary, plain); host.appendChild(menu);
  }
  function highlightCodeBlock(block) {
    if (block.dataset.hl) return;
    const pre = block.parentElement;
    if (pre && !pre.querySelector('.copy-code')) {
      const btn = el('button', 'copy-code', t('common.copy'));
      btn.onclick = () => { copyDisclosure(block, { kind: 'code', localText: () => block.textContent }); };
      pre.appendChild(btn);
      const wrap = el('div', 'privacy-code-copy-wrap'); pre.parentNode.insertBefore(wrap, pre); wrap.appendChild(pre);
      addPlainCopyAction(wrap, block, { kind: 'code', localText: () => block.textContent });
    }
    // Highlight.js is synchronous. Very large individual blocks stay readable/copyable plain text;
    // smaller blocks are processed in idle slices when their combined weight is high.
    if (block.textContent.length > 16_000) { block.dataset.hl = 'plain'; return; }
    try { hljs.highlightElement(block); } catch { /* ignore */ }
    block.dataset.hl = '1';
  }
  // perf(长会话):列表渲染时行先在文档外建好、再整批挂进去 —— 调这里时容器还没连进文档。这种容器里的代码块交给
  // 一个共享的 IntersectionObserver,离可见区 800px 以内才高亮、才补复制按钮:打开长会话 / 「加载更早」时屏外那几十个
  // 代码块不再同步走 hljs(实测省 240–300 ms,hljs 的 span 占长会话 DOM 节点的 28%)。scrollMargin 让 #messages 这种
  // 滚动容器也按 800px 提前量算(不支持该选项的浏览器忽略它,退化成滚进可见区才高亮)。pre code 不换行,高亮前后高度相同。
  // 已经在文档里的容器(流式回合收尾、帮助页、文件预览……)照旧当场高亮。
  let lazyHighlightObserver = null;
  function lazyHighlight(blocks) {
    if (!lazyHighlightObserver) {
      lazyHighlightObserver = new IntersectionObserver(entries => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          lazyHighlightObserver.unobserve(entry.target);
          highlightCodeBlock(entry.target);
        }
      }, { rootMargin: '800px 0px', scrollMargin: '800px 0px' });
    }
    for (const block of blocks) lazyHighlightObserver.observe(block);
  }
  // opts.nearView:只把容器里还没高亮、且离视口 800px 以内的代码块当场高亮(调用方刚挂上一批在文档外画好的行、
  // 布局也刚算过时用 —— 懒高亮的 IntersectionObserver 回调晚于这一帧的绘制,不补这一下会闪一帧没着色的代码)。
  // 远处的照旧留给懒高亮;看不见的(display:none,矩形为零)不动。
  function highlightNearView(container, margin = 800) {
    if (typeof hljs === 'undefined' || container.isConnected === false) return;
    const viewport = globalThis.innerHeight || 0;
    for (const block of container.querySelectorAll('pre code:not([data-hl])')) {
      if (block.classList.contains('language-mermaid')) continue;
      const rect = block.getBoundingClientRect();
      if (!rect.width && !rect.height) continue;
      if (rect.bottom >= -margin && rect.top <= viewport + margin) highlightCodeBlock(block);
    }
  }
  function highlightIn(container, opts) {
    if (!container || typeof container.querySelectorAll !== 'function') return;
    if (opts && opts.nearView) { highlightNearView(container); return; }
    // 109a: 在同一趟里分流 mermaid 围栏: `pre > code.language-mermaid` 不进 hljs,交给懒加载的
    // 图表运行时;vendor/mermaid.min.js 缺失或渲染失败时它把原代码块留在原地并补一行提示。
    // 异步且不阻塞高亮;失败已在运行时内部收敛,这里只兜住 promise 防未处理拒绝。
    try { Promise.resolve(renderMermaidBlocks(container, { t, toast, renderMarkdownInto })).catch(() => {}); } catch { /* ignore */ }
    if (typeof hljs === 'undefined') return;
    const blocks = Array.from(container.querySelectorAll('pre code'))
      .filter(block => !block.dataset.hl && !(block.classList && block.classList.contains('language-mermaid')));
    if (!blocks.length) return;
    if (container.isConnected === false && typeof IntersectionObserver === 'function') { lazyHighlight(blocks); return; }
    const totalChars = blocks.reduce((sum, block) => sum + Math.min(16_001, block.textContent.length), 0);
    if (blocks.length <= 6 && totalChars <= 32_000) { blocks.forEach(highlightCodeBlock); return; }
    let cursor = 0;
    const scheduleIdle = globalThis.requestIdleCallback
      ? callback => globalThis.requestIdleCallback(callback, { timeout: 250 })
      : callback => setTimeout(() => callback({ timeRemaining: () => 8 }), 0);
    const run = deadline => {
      let painted = 0;
      while (cursor < blocks.length && (painted === 0 || deadline.timeRemaining() > 4)) {
        highlightCodeBlock(blocks[cursor++]); painted += 1;
      }
      if (cursor < blocks.length) scheduleIdle(run);
    };
    scheduleIdle(run);
  }

  /* ---------------- theme ---------------- */
  // 第50波(UI-DESIGN-V4 §5):主题三态 —— light/dark/system(跟随系统)。wcw.theme 存偏好值;
  // data-theme 落有效值(system 经 matchMedia 解析并监听变更)。切换循环 dark→light→system→dark。
  // themeToggle 由 emoji(🌙/☀️)换 SVG(icons.js theme/monitor,emoji 清零目标的高频控件首例)。
  function messageShell(role, whenIso, meta) {
    const row = document.createElement(role === 'assistant' ? 'article' : 'div');
    row.className = `message ${role}`;
    if (role === 'assistant') row.setAttribute('aria-label', t('chat.assistantTurnAria'));
    // v3 (§C4): 头像从字母方块升级为品牌 SVG —— 用户=中性人形剪影 / 助手=如意云头(引擎色底白标) / 系统=无底色 ⚙。
    const avatar = el('div', 'avatar');
    buildMsgAvatar(avatar, role);
    const main = el('div', 'msg-main');
    const head = el('div', 'msg-head');
    if (role === 'assistant') {
      const vis = engineVisual(meta);
      // 云头底色沿用引擎色(Claude=青花蓝 via --accent,Provider 各品牌色),多引擎会话一眼识别归属。
      avatar.style.background = vis.colorVar;
      // Badge = colored dot + engine name; the dot/tint color comes from --eng-color set inline here.
      const badge = el('span', 'eng-badge', vis.label);
      badge.style.setProperty('--eng-color', vis.colorVar);
      head.appendChild(badge);
      const model = meta && meta.model;
      if (model) head.append(el('span', 'eng-model', model));
    } else {
      head.append(el('span', 'who', role === 'user' ? t('chat.roleUser') : t('chat.roleSystem')));
    }
    if (whenIso) head.append(el('span', 'when', fmtTime(whenIso)));
    main.appendChild(head);
    row.append(avatar, main);
    return { row, main, head };
  }
  // v3 (§C4): 消息头像 SVG 构建器。全 createElementNS(不用 innerHTML,守 XSS 纪律)。图形为常量,无用户数据注入。
  function buildMsgAvatar(box, role) {
    const NS = 'http://www.w3.org/2000/svg';
    if (role === 'assistant') {
      // 如意云头(与 --ruyi-cloud 同一三瓣路径),fill=currentColor(=--accent-ink 白);底色由调用处按引擎色设。
      const svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('viewBox', '0 0 120 70'); svg.setAttribute('width', '22'); svg.setAttribute('height', '13');
      svg.setAttribute('aria-hidden', 'true'); svg.setAttribute('fill', 'currentColor');
      const cloud = document.createElementNS(NS, 'path');
      cloud.setAttribute('d', 'M60 62 C46 55 30 44 30 32 A13 13 0 0 1 53 24 A7.5 7.5 0 1 1 67 24 A13 13 0 0 1 90 32 C90 44 74 55 60 62 Z');
      svg.appendChild(cloud); box.appendChild(svg);
    } else if (role === 'user') {
      // 中性人形剪影(头 + 肩),fill=currentColor(=--ink)。
      const svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('width', '18'); svg.setAttribute('height', '18');
      svg.setAttribute('aria-hidden', 'true'); svg.setAttribute('fill', 'currentColor');
      const head = document.createElementNS(NS, 'circle');
      head.setAttribute('cx', '12'); head.setAttribute('cy', '8.5'); head.setAttribute('r', '3.9');
      const body = document.createElementNS(NS, 'path');
      body.setAttribute('d', 'M12 13.4c-4.3 0-7.6 2.7-7.6 6.3V21h15.2v-1.3c0-3.6-3.3-6.3-7.6-6.3Z');
      svg.append(head, body); box.appendChild(svg);
    } else {
      // 系统:无底色 ⚙ 弱化(CSS 把 .message.system .avatar 去底、着 --muted)。
      box.textContent = '⚙';
    }
  }
  // Derive an engine meta from a stored message. New messages carry engine/providerId/providerLabel/model
  // directly; older ones only have `source` ('provider:xxx' | 'claude-cli' | 'aborted'|…) — fall back to
  // that, resolving the provider label from the current config when possible.
  function metaFromMessage(msg) {
    if (!msg) return null;
    if (msg.engine === 'openai' || msg.providerId) {
      const pid = msg.providerId || '';
      const p = (state.config.providers || []).find(x => x.id === pid);
      return { engine: 'openai', providerId: pid, providerLabel: msg.providerLabel || (p && p.label) || pid, model: msg.model || '' };
    }
    if (msg.engine === 'claude') return { engine: 'claude', model: msg.model || '' };
    const src = String(msg.source || '');
    if (src.startsWith('provider:')) {
      const pid = src.slice('provider:'.length);
      const p = (state.config.providers || []).find(x => x.id === pid);
      return { engine: 'openai', providerId: pid, providerLabel: (p && p.label) || pid, model: msg.model || '' };
    }
    // 'claude-cli', 'fallback', 'aborted', 'stderr', or missing -> treat as Claude (the historical default).
    return { engine: 'claude', model: msg.model || '' };
  }
  // Count characters in a thinking transcript for the collapsed summary "思考过程 · N 字" (C2). Pure so
  // it can be unit-tested; counts JS string length (code units), which is fine for a rough CJK-ish size.
  function thinkingCharCount(text) { return String(text || '').length; }
  // The summary label for a SETTLED thinking panel: "思考过程 · N 字" (N = char count), or plain "思考过程"
  // when empty. The mid-stream "思考中…" + shimmer state is chosen by the caller (thinkingPanel/setLive),
  // not here. Pure helper for testing the collapsed-state text.
  function thinkingSummaryLabel(text) { const n = thinkingCharCount(text); return n > 0 ? `${t('chat.thinkingProcessCount', {count: n})}` : t('chat.thinkingProcess'); }
  // text (optional) seeds the body; `live` renders the streaming "思考中…" shimmer summary. Returns the
  // <details>, the body element, and setLive(on)/refreshLabel() so the streaming path can settle it.
  function thinkingPanel(text, live) {
    const d = el('details', 'thinking');
    const sum = el('summary', 'thinking-summary');
    const iconWrap = el('span', 'thinking-icon'); iconWrap.appendChild(icon('trace', 13));
    const label = el('span', 'thinking-label', live ? t('chat.thinkingLive') : thinkingSummaryLabel(text));
    const caret = el('span', 'thinking-caret');
    sum.append(iconWrap, label, caret);
    if (live) sum.classList.add('thinking-live');
    d.appendChild(sum);
    const body = el('div', 'think-body', text); d.appendChild(body);
    const setLive = on => {
      if (on) { sum.classList.add('thinking-live'); label.textContent = t('chat.thinkingLive'); }
      else { sum.classList.remove('thinking-live'); label.textContent = thinkingSummaryLabel(body.textContent); }
    };
    return { d, body, summary: sum, label, setLive, userToggled: false };
  }
  function settleLiveThinking(live) {
    if (!live) return;
    const panel = live.thinkingPanelObj;
    if (panel) {
      panel.setLive(false);
      if (!panel.userToggled) panel.d.open = false;
    }
    if (live.thinkingRafId) { cancelAnimationFrame(live.thinkingRafId); live.thinkingRafId = 0; }
    live.followThinkingPanel = false;
    live.thinkingActive = false;
    live.thinkingEl = null;
    live.thinkingNode = null;
  }
  // Pick the first present string field from a tool's input for the header summary (C1), in priority
  // order, then middle-ellipsize to ≤44 chars keeping head+tail. Returns '' when nothing usable. Pure.
  const TC_ARG_KEYS = ['path', 'url', 'command', 'pattern', 'root', 'query', 'title', 'text'];
  function toolArgSummary(input, max = 44) {
    if (!input || typeof input !== 'object') return '';
    let raw = '';
    for (const k of TC_ARG_KEYS) { const v = input[k]; if (typeof v === 'string' && v.trim() !== '') { raw = v; break; } }
    return toolArgSummaryText(raw, max);
  }
  // 117o-A7:把「归一空白 + 中间省略」这一步单独拎出来当【唯一的截断口径】。在途回合的工具卡拿不到
  // 完整 input(工具参数只以一行 inputPreview 下发,结果一律不下发),但它上屏的那一行必须与落盘消息
  // 的工具卡一模一样宽、一模一样省略 —— 两条路都走这一个函数,不许另写一套。
  function toolArgSummaryText(raw, max = 44) {
    return middleEllipsis(String(raw || '').replace(/\s+/g, ' ').trim(), max);
  }
  // Middle-ellipsize a string to at most `max` chars, keeping the head and tail (so long paths/urls stay
  // recognizable at both ends). Uses a single '…' in the middle. Pure.
  function middleEllipsis(s, max = 44) {
    s = String(s || '');
    if (s.length <= max) return s;
    if (max <= 1) return '…';
    const keep = max - 1; // room for the ellipsis
    const head = Math.ceil(keep / 2), tail = Math.floor(keep / 2);
    return s.slice(0, head) + '…' + (tail > 0 ? s.slice(s.length - tail) : '');
  }
  // Attach a floating "复制" button (reusing .copy-code) to a <pre>, wrapped so hover reveals it. Returns
  // the wrapper to append. copies the pre's textContent to the clipboard.
  function wrapPreWithCopy(pre) {
    const wrap = el('div', 'tc-pre-wrap');
    const btn = el('button', 'copy-code', t('common.copy')); btn.type = 'button';
    btn.onclick = e => { e.preventDefault(); e.stopPropagation(); copyDisclosure(pre, { kind: 'tool', localText: () => (typeof pre.copyText === 'function' ? pre.copyText() : pre.textContent) || '' }); };
    wrap.append(pre, btn); addPlainCopyAction(wrap, pre, { kind: 'tool', localText: () => (typeof pre.copyText === 'function' ? pre.copyText() : pre.textContent) || '' });
    return wrap;
  }
  // v1.0-S4: pull the unified-diff text out of a git_diff tool result (accepts an object with `.diff`, or a
  // JSON string, or an MCP content-array wrapper). Returns '' when there is no usable diff text.
  function gitDiffText(result) {
    let obj = result;
    if (Array.isArray(obj)) { obj = obj.map(p => (p && typeof p.text === 'string') ? p.text : '').join(''); }
    if (typeof obj === 'string') { try { obj = JSON.parse(obj); } catch { return obj.trim() ? obj : ''; } }
    if (obj && typeof obj === 'object' && typeof obj.diff === 'string') return obj.diff;
    return '';
  }
  // v1.0-S4: colorized unified-diff view. Builds a `.diff-view` block: one <div> per line, classed by the
  // first char (+ add / - del / @@ hunk / else default). SECURITY: every line goes in via textContent — NEVER
  // innerHTML (a diff can contain arbitrary source, including markup). Over 800 lines → collapse behind a
  // 「展开全部」 button (only the first 800 render until expanded), keeping huge diffs from freezing the DOM.
  const DIFF_COLLAPSE_LINES = 800;
  function renderDiffView(diffText) {
    const view = el('div', 'diff-view');
    const lines = String(diffText || '').split('\n');
    const total = lines.length;
    const collapsed = total > DIFF_COLLAPSE_LINES;
    const appendLines = (from, to) => {
      for (let i = from; i < to; i++) {
        const line = lines[i];
        let cls = 'diff-line';
        // File headers (+++/---) must be checked before the +/- add/del classes so they don't miscolor.
        if (line.startsWith('+++') || line.startsWith('---')) cls += ' diff-file';
        else if (line.startsWith('@@')) cls += ' diff-hunk';
        else if (line.startsWith('+')) cls += ' diff-add';
        else if (line.startsWith('-')) cls += ' diff-del';
        const row = el('div', cls);
        row.textContent = line.length ? line : ' '; // keep blank lines a visible height
        view.appendChild(row);
      }
    };
    appendLines(0, collapsed ? DIFF_COLLAPSE_LINES : total);
    if (collapsed) {
      const btn = el('button', 'diff-expand', t('chat.expandAll', { total })); btn.type = 'button';
      btn.onclick = e => {
        e.preventDefault(); e.stopPropagation();
        appendLines(DIFF_COLLAPSE_LINES, total);
        btn.remove();
      };
      view.appendChild(btn);
    }
    return view;
  }
  // tc: { name, input, result?, isError?, durationMs? }. Builds the upgraded card (C1): left status bar
  // (running/ok/err), arg summary, optional duration, copy buttons on both <pre>. All states stay collapsed
  // by default; failures remain visible through their red status and can be opened on demand.
  // Returns handles the streaming path uses to fill the result + timing + status bar post-render.
  function toolCard(tc, sourceLocator = null) {
    const d = el('details', 'tool-card');
    // 117o-A7:在途回合(经典壳「看全文」那张临时卡)走的是【同一张工具卡】,但它手上没有工具结果 ——
    // 服务端的 liveTurn 信封只送 {id,name,inputPreview,status},结果一律不下发(可能是整份文件、可能含密钥)。
    // 于是「这一步跑完没有」不能再只看 result 在不在:tc.status 是在途路径独有的一个【可选】字段
    // ('running'|'done'|'error'|'cancelled'),落盘消息的 toolCalls 上从来没有它 —— 既有三个调用点
    // (静态叙事 / 静态平铺组 / 流式 tool_use)传进来的对象都不带 status,所以它们的行为逐字节不变。
    const liveStatus = typeof tc.status === 'string' ? tc.status : '';
    const settled = liveStatus ? liveStatus !== 'running' : tc.result !== undefined;
    const isError = tc.isError === true || liveStatus === 'error';
    const statusbar = el('div', 'tc-statusbar' + (settled ? (isError ? ' err' : ' ok') : ' running'));
    d.appendChild(statusbar);
    const sum = el('summary');
    // v0.7d: bridged desktop-control tools carry the ai_computer_control__ prefix — badge them with 🖥.
    const isDesktopTool = typeof tc.name === 'string' && tc.name.startsWith('ai_computer_control__'); // v3 (§2.15): tc-icon emoji → 线性 SVG(monitor/wrench)
    // v0.9-S1 (C1): both a raw name (pro) and a plain-language verb (simple) ship; CSS shows one per uiMode
    // via [data-ui-mode]. The verb reuses humanizeToolName (the shared 人话 map, also used by permission popups).
    const tcIconEl = el('span', 'tc-icon'); tcIconEl.appendChild(icon(isDesktopTool ? 'monitor' : 'wrench', 13));
    const nameEl = el('span', 'tc-name', tc.name || 'tool');
    const verbEl = el('span', 'tc-verb', humanizeToolName(tc.name));
    sum.append(
      tcIconEl,
      nameEl,
      verbEl,
    );
    // 117o-A7:在途卡只有一行 inputPreview(服务端按与 TC_ARG_KEYS 逐字对齐的顺序挑出来的那个字段,
    // 只做 200 字传输上限);上屏的省略仍走上面那一个 toolArgSummaryText —— 截断口径只有一处。
    const argSource = typeof tc.inputPreview === 'string' && tc.inputPreview ? tc.inputPreview : '';
    const arg = argSource ? toolArgSummaryText(argSource) : toolArgSummary(tc.input);
    const argEl = el('span', 'tc-arg', arg); if (arg) argEl.title = arg;
    sum.appendChild(argEl);
    // Duration slot: filled now for static cards that carry durationMs; streaming fills it on tool_result.
    const dur = el('span', 'tc-dur'); if (settled && Number.isFinite(tc.durationMs)) dur.textContent = `· ${(tc.durationMs / 1000).toFixed(1)}s`;
    sum.appendChild(dur);
    // 125-P2(42 号文 §1 ③):抓不到时 web_fetch 会回落磁盘缓存,并且【仍然回 ok:true】—— 旧正文就这么
    // 进了模型与用户眼里,而 fromCache / ts 两个字段一直摆在返回值里没人读。徽标挂在【摘要行】上
    // (不展开就看得见),内容由结构化字段算出来,一个关键词都不匹配(同 124-P3 回执徽标的模具)。
    const staleHost = el('span', 'tc-stale');
    sum.appendChild(staleHost);
    if (settled && tc.result !== undefined) renderStaleBadgeInto(staleHost, tc.name, tc.result);
    const status = el('span', 'tc-status', settled ? (isError ? t('status.error') : t('status.done')) : t('status.running'));
    if (settled) status.classList.add(isError ? 'err' : 'ok');
    sum.appendChild(status);
    sum.appendChild(el('span', 'tc-caret'));
    d.appendChild(sum);
    const body = el('div', 'tc-body');
    // v1.0-S4: git_diff gets a colorized diff view at the TOP of the body (the 「改了什么」 primary view, useful
    // even in simple mode). The raw JSON still lives in the 详情 block below. diffHost is returned so the
    // streaming tool_result path can fill it once the result arrives.
    const diffHost = el('div', 'tc-diff-host');
    body.appendChild(diffHost);
    if (settled && !isError && tc.result !== undefined) renderGitDiffInto(diffHost, tc.name, tc.result);
    // v0.9-S1 (C1): the input/result JSON lives in a nested <details class="tc-detail"> (open by default). In
    // pro mode CSS hides the nested summary so it reads as a plain always-open body (unchanged look); in simple
    // mode the 「详情」summary shows so a 人人可用 user can collapse the raw JSON. It starts open either way,
    // so content is never hidden by default — simple users opt INTO folding.
    const detail = el('details', 'tc-detail'); detail.open = true;
    const detailSum = el('summary', 'tc-detail-sum'); detailSum.textContent = t('chat.details'); detail.appendChild(detailSum);
    detail.appendChild(el('div', 'tc-label', t('chat.input')));
    // 在途卡没有完整参数(只有那一行摘要)也没有结果:详情区如实写清楚,不留一个空框让人以为丢了东西。
    const inp = el('pre'); inp.textContent = safeStringify(tc.input) || argSource;
    if (sourceLocator && tc.input !== undefined) bindDisclosureSource(inp, { ...sourceLocator, slot: 'tool-input' }, safeStringify(tc.input));
    detail.appendChild(wrapPreWithCopy(inp));
    const resLabel = el('div', 'tc-label', t('chat.result')); detail.appendChild(resLabel);
    const resPre = el('pre');
    if (tc.result !== undefined) renderToolResultInto(resPre, tc.name, tc.result);
    else resPre.textContent = settled ? t('chat.liveTurn.resultOffEnvelope') : t('chat.waitingResult');
    if (sourceLocator && tc.result !== undefined) bindDisclosureSource(resPre, { ...sourceLocator, slot: 'tool-result' }, safeStringify(tc.result));
    detail.appendChild(wrapPreWithCopy(resPre));
    body.appendChild(detail);
    // 109b: 结果图内联缩略图,挂在含 result <pre> 的 detail 之后,只在终态(done)且非错误时懒请求预览。
    // imageHost 随卡片句柄一起返回,供流式路径在 tool_result 到达时再补一次(见 renderToolImageInto)。
    const imageHost = el('div', 'tc-image-host');
    body.appendChild(imageHost);
    if (settled && !isError && tc.result !== undefined) renderToolImageInto(imageHost, tc.name, tc.result);
    d.appendChild(body);
    return { d, status, inp, resPre, statusbar, dur, argEl, diffHost, imageHost, staleHost, nameEl, verbEl, name: tc.name };
  }
  // 125-P2:「这份资料是哪天抓的」由工作台印,不靠模型自觉。
  // 判据只看两个【结构化字段】:web_fetch 自己回的 fromCache 与 ts。返回 null = 不该印
  // (不是 web_fetch、或这次真的是现抓的);-1 = 是缓存但没记时间(如实说不知道多久,不瞎猜)。
  // 天数按【渲染时刻】算:回放一条三个月前的回合,那份缓存确实就是三个月前抓的 —— live 与回放
  // 两条路上这句话都成立,不必落盘第二个字段。
  function staleCacheDays(name, result) {
    if (name !== 'web_fetch') return null;
    const r = (result && typeof result === 'object') ? result : null;
    if (!r || r.fromCache !== true) return null;
    const at = Date.parse(String(r.ts || ''));
    if (!Number.isFinite(at)) return -1;
    return Math.max(0, Math.floor((Date.now() - at) / 86400000));
  }
  // 幂等(先清空 + 去掉标记):流式路径拿到结果后再调一次也不会画两枚。
  function renderStaleBadgeInto(host, name, result) {
    if (!host) return;
    host.textContent = '';
    delete host.dataset.stale;
    const days = staleCacheDays(name, result);
    if (days == null) return;
    host.dataset.stale = 'cache';
    host.textContent = days < 0 ? t('tool.staleCache.unknown') : t('tool.staleCache', { days: String(days) });
    host.title = t('tool.staleCache.hint');
  }
  // v1.0-S4: fill a tool card's diff-host with the colorized diff view IFF this is a git_diff result carrying
  // non-empty diff text. Idempotent (clears the host first) so the streaming path can call it after the result
  // lands. No-op for every other tool / empty diff — the host stays empty and collapses.
  function renderGitDiffInto(host, name, result) {
    if (!host) return;
    host.textContent = '';
    if (name !== 'git_diff') return;
    const text = gitDiffText(result);
    if (!text || !text.trim()) return;
    host.appendChild(el('div', 'tc-label', t('chat.changes')));
    host.appendChild(renderDiffView(text));
  }
  // 109b: 工具产出图内联缩略图。host.dataset.tiDone 是防重放闸门,同一个 host 只处理一次,不管是
  // toolCard() 创建时的首次调用,还是流式 tool_result 到达后 chat-stream-runtime 的第二次调用,都不会
  // 重复发 /api/file/preview 请求或重复插入 DOM。检测不中(非白名单工具/非图片路径/结果失败)时静默
  // 什么都不做,resPre 里的原始 JSON 仍是可信来源。
  async function renderToolImageInto(host, name, result) {
    if (!host || host.dataset.tiDone === '1') return;
    host.dataset.tiDone = '1';
    const filePath = detectToolImagePath(name, result);
    if (!filePath) return;
    let preview;
    try { preview = await fetchFilePreview(filePath); } catch { return; }
    if (!preview || preview.ok === false) return;
    const base = String(filePath).replace(/^.*[\\/]/, '');
    if (preview.kind === 'image' && typeof preview.dataUri === 'string' && preview.dataUri) {
      host.textContent = '';
      const wrap = el('div', 'tool-image');
      const img = el('img', 'tool-image-img'); img.src = preview.dataUri; img.alt = base; img.loading = 'lazy';
      wrap.appendChild(img);
      const toggle = el('button', 'tool-image-toggle', t('chat.toolImage.expand')); toggle.type = 'button';
      toggle.onclick = e => {
        e.preventDefault(); e.stopPropagation();
        const expanded = wrap.classList.toggle('expanded');
        toggle.textContent = expanded ? t('chat.toolImage.collapse') : t('chat.toolImage.expand');
      };
      wrap.appendChild(toggle);
      host.appendChild(wrap);
    } else if (preview.kind === 'image-toobig') {
      host.textContent = '';
      const wrap = el('div', 'tool-image tool-image-toobig');
      const btn = el('button', 'tool-image-openbtn', t('chat.toolImage.openInSidebar')); btn.type = 'button';
      btn.onclick = e => { e.preventDefault(); e.stopPropagation(); openFilePreview(filePath); };
      wrap.appendChild(btn);
      host.appendChild(wrap);
    }
    // 其它 kind(text/html/binary)对这几个白名单工具不应出现,但仍按契约静默降级,不渲染任何东西。
  }
  function safeStringify(v) {
    if (v == null) return '';
    if (typeof v === 'string') return v;
    try { return JSON.stringify(v, null, 2); } catch { return String(v); }
  }
  // N11: 把工具结果画进结果框。大多数结果仍是一段 JSON 文本(外观不变);含多行文本字段/截图的结果改画成
  // 真正的多行文本块(不再是一行转义的 "\n")+ <img> 缩略图,其余键紧凑 JSON;长文本默认只展开前若干行,可展开。
  // 全程 textContent / <img>.src(objectURL 或 data:image/…),不走 innerHTML。幂等:每次先清空再画。
  const RESULT_COLLAPSE_LINES = 40;
  const RESULT_VIEW_CHAR_CAP = 100000;
  function resultTextBlock(key, text) {
    const block = el('div', 'tc-res-block' + (/^(?:stderr|error)$/.test(key) ? ' err' : ''));
    let view = text, omitted = 0;
    if (text.length > RESULT_VIEW_CHAR_CAP) {
      omitted = text.length - RESULT_VIEW_CHAR_CAP;
      view = text.slice(0, RESULT_VIEW_CHAR_CAP / 2) + '\n…\n' + text.slice(text.length - RESULT_VIEW_CHAR_CAP / 2);
    }
    const lines = view.split('\n');
    const head = el('div', 'tc-res-key', key);
    head.appendChild(el('span', 'tc-res-len', t('chat.result.stats', { chars: text.length, lines: lines.length })
      + (omitted ? ' · ' + t('chat.result.viewTruncated', { omitted }) : '')));
    block.appendChild(head);
    const body = el('div', 'tc-res-text');
    block.appendChild(body);
    if (lines.length <= RESULT_COLLAPSE_LINES) { body.textContent = view; return block; }
    const first = lines.slice(0, RESULT_COLLAPSE_LINES).join('\n');
    let expanded = false;
    body.textContent = first;
    const more = el('button', 'tc-res-more', t('chat.result.showAll', { lines: lines.length })); more.type = 'button';
    more.onclick = e => {
      e.preventDefault(); e.stopPropagation();
      expanded = !expanded;
      body.textContent = expanded ? view : first;
      block.classList.toggle('expanded', expanded);
      more.textContent = expanded ? t('chat.result.collapse') : t('chat.result.showAll', { lines: lines.length });
    };
    block.appendChild(more);
    return block;
  }
  function resultImageBlock(img) {
    const wrap = el('div', 'tool-image tc-res-img');
    const label = img.kind === 'attachment' ? String(img.att.name || '') : String(img.field || '');
    const show = src => {
      const im = el('img', 'tool-image-img'); im.src = src; im.alt = label;   // objectURL/data URI 都是本地的,不用 lazy(卡片折叠时 lazy 图永远不解码)
      wrap.appendChild(im);
      const toggle = el('button', 'tool-image-toggle', t('chat.toolImage.expand')); toggle.type = 'button';
      toggle.onclick = e => {
        e.preventDefault(); e.stopPropagation();
        const expanded = wrap.classList.toggle('expanded');
        toggle.textContent = expanded ? t('chat.toolImage.collapse') : t('chat.toolImage.expand');
      };
      wrap.appendChild(toggle);
    };
    if (img.kind === 'data') {
      if (img.tooBig) wrap.appendChild(el('div', 'tc-res-key', t('chat.result.imageTooBig', { name: label })));
      else show(img.src);
    } else {
      wrap.appendChild(el('div', 'tc-res-key', label));
      Promise.resolve().then(() => fetchAttachmentImage(img.att)).then(url => { if (url) show(url); }, () => {
        wrap.appendChild(el('div', 'tc-res-key', t('chat.result.imageMissing')));
      });
    }
    return wrap;
  }
  function renderToolResultInto(resPre, name, result) {
    if (!resPre) return;
    const privacyErrorResult = result && typeof result === 'object' && result.ok !== true && result.isError !== false
      && (result.ok === false || result.isError === true || result.type === 'error' || result.resultUnavailable === true
        || result.errorInfo && typeof result.errorInfo === 'object' || result.error && typeof result.error === 'object');
    if (privacyErrorResult && privacyFailure(result)) { const card = privacyFailureCard(result); if (card) { resPre.textContent = ''; resPre.copyText = () => card.textContent; resPre.classList.add('tc-result-rich'); resPre.appendChild(card); return; } }
    const parts = toolResultRichParts(result);
    resPre.classList.toggle('tc-result-rich', Boolean(parts));
    resPre.copyText = parts ? () => safeStringify(result) : undefined;
    if (!parts) { resPre.textContent = safeStringify(result); return; }
    resPre.textContent = '';
    if (Object.keys(parts.meta).length) resPre.appendChild(el('div', 'tc-res-meta', safeStringify(parts.meta)));
    for (const img of parts.images) resPre.appendChild(resultImageBlock(img));
    for (const tx of parts.texts) resPre.appendChild(resultTextBlock(tx.key, tx.text));
  }
  /* ---------------- v1.0.2 (G4): 同回合多工具卡折叠成组 ---------------- */
  function toolGroupSummaryText(n) { return tCount('tool.group.completed', n); }
  // Static re-render (history): given an array of top-level tool-card elements, if there are >3, wrap them
  // ALL into a collapsed <details.tool-group> (summary = 「N 个工具调用」). Returns the group element, or null
  // when ≤3 (caller appends the cards individually). Sub-agent cards are handled by their own path and are
  // NOT passed here.
  function buildStaticToolGroup(cardEls) {
    if (!Array.isArray(cardEls) || cardEls.length <= 3) return null;
    const det = el('details', 'tool-group');
    const sum = el('summary', 'tool-group-sum');
    sum.append(el('span', 'tg-caret', '▸'), el('span', 'tg-label', tCount('tool.group.count', cardEls.length)));
    det.appendChild(sum);
    const body = el('div', 'tool-group-body');
    for (const c of cardEls) body.appendChild(c);
    det.appendChild(body);
    return det;
  }
  // meta (optional): engine identity so the line ends with a muted engine name (C3). Tokens go through
  // fmtTokens (↑in ↓out); duration/cost only appear when present (provider turns usually lack cost).
  function usageLine(u, meta) {
    const line = el('div', 'usage-line');
    const parts = [];
    const inp = u.usage?.input_tokens, out = u.usage?.output_tokens;
    // E4: providers that never send a usage frame get a server-side estimate flagged estimated:true — prefix
    // it with 约 (approx.) so the number does not read as an exact provider-reported count.
    // S12:本函数拼 innerHTML —— 凡不是自家常量的插值(翻译串、格式化数、来自 CLI 结果的 numTurns)一律过 escapeHtml。
    if (inp != null || out != null) parts.push(`<b>${u.estimated ? escapeHtml(t('common.about')) : ''}↑${escapeHtml(fmtTokens(inp ?? 0))} ↓${escapeHtml(fmtTokens(out ?? 0))}</b>`);
    if (u.durationMs != null) parts.push(`<b>${(u.durationMs / 1000).toFixed(1)}s</b>`);
    if (u.costUsd != null) parts.push(`<b>$${Number(u.costUsd).toFixed(4)}</b>`);
    if (u.numTurns != null) parts.push(escapeHtml(tCount('chat.usageTurnCount', u.numTurns)));
    let html = parts.join(' · ');
    // Trailing muted engine name from the message meta, or the current engine when rendered live.
    const engName = engineVisual(meta || currentEngineMeta()).label;
    if (engName) html += `${html ? ' · ' : ''}<span class="usage-eng">${escapeHtml(engName)}</span>`;
    line.innerHTML = html;
    return line;
  }
  /* ---------------- context-window meter (client-only; fed by per-turn usage) ---------------- */
  // v1.3-FE1:fmtTokens 已搬入 ./js/util.js(纯格式化,顶部 import 取回);此处 ctx-meter 族仍用同名调用。
  // Best-effort context limit by model name — LAST-RESORT fallback only (server's contextWindowResolved is
  // preferred, see ctxWindow). v1.0.2 返修三:此前 deepseek 一律 65536 —— 电量表分母恒为 64K,deepseek-v4(1M)
  // 被当 64K,「12K/64K·18%」而非真实「12K/1M·1%」,正是用户看到的 65.5k。此处只作服务端
  // 状态不可用时的最后兜底，具体窗口与服务端 MODEL_CONTEXT_TABLE 保持同序。
  function ctxWindowGuess(model) {
    const m = String(model || '').toLowerCase();
    if (/k3-256k/.test(m)) return 1000000;          // k3 的 256K 变体先于 1M 的 k3 命中
    if (/kimi-k3|(^|[\/-])k3$/.test(m)) return 1048576;
    if (/haiku/.test(m)) return 1000000;
    if (/opus-5|opus-4|sonnet-5|sonnet-4|fable|mythos/.test(m)) return 1000000;
    if (/deepseek-v4/.test(m)) return 1000000;   // deepseek-v4 = 1M(此前被并入 65536)
    if (/deepseek-flash/.test(m)) return 1000000; // deepseek-flash 也是 1M(与 MODEL_CONTEXT_TABLE 同序)
    if (/deepseek/.test(m)) return 1000000;        // 其余 deepseek(v3/chat/reasoner)= 128K
    if (/mimo-v2\.5-pro(?:$|[^a-z0-9])/.test(m) || /(?:^|\/)mimo-v2\.5$/.test(m)) return 1000000;
    if (/kimi|moonshot/.test(m)) return 1000000;
    if (/qwen3\.8|qwen3\.7/.test(m)) return 1000000;
    if (/qwen3\.6-max/.test(m)) return 1000000;
    if (/qwen3\.6-(plus|flash)/.test(m)) return 1000000;
    if (/qwen3\.6/.test(m)) return 1000000;
    if (/qwen3\.5-omni/.test(m)) return 1000000;
    if (/qwen3\.5-(plus|flash)/.test(m)) return 1000000;
    if (/qwen3\.5/.test(m)) return 1000000;
    if (/qwen3-coder-plus/.test(m)) return 1000000;
    if (/qwen3-coder-next|qwen3-max|qwen3(?:$|[^.0-9])/.test(m)) return 1000000;
    if (/qwen-plus-2025-01-25/.test(m)) return 1000000;
    if (/qwen-plus|qwen-flash/.test(m)) return 1000000;
    if (/qwen-turbo/.test(m)) return 1000000;
    if (/qwen-max/.test(m)) return 1000000;
    if (/qwen-long/.test(m)) return 10000000;
    if (/qwen|qwq/.test(m)) return 1000000;
    if (/glm-5\.3|glm-5\.2/.test(m)) return 1000000;
    if (/glm-5\.1|glm-5-turbo|glm-5|glm-4\.7|glm-4\.6/.test(m)) return 1000000;
    if (/glm-4-long/.test(m)) return 1000000;
    if (/glm-4\.5|glm-4/.test(m)) return 1000000;
    if (/glm/.test(m)) return 1000000;
    if (/minimax-m3/.test(m)) return 1000000;
    if (/minimax-m2\.7|minimax-m2\.5/.test(m)) return 1000000;
    if (/gemma4|minicpm5|whiskyakm/.test(m)) return 1000000;
    if (/gemini/.test(m)) return 1048576;
    if (/grok/.test(m)) return 1000000;
    if (/llama-4-scout/.test(m)) return 10000000;
    if (/llama/.test(m)) return 1000000;
    if (/mistral/.test(m)) return 1000000;
    if (/doubao/.test(m)) return 1000000;
    if (/hunyuan/.test(m)) return 1000000;
    if (/ernie/.test(m)) return 1000000;
    if (/step-5/.test(m)) return 1000000;
    if (/step/.test(m)) return 1000000;
    if (/yi-large|yi-medium/.test(m)) return 1000000;
    if (/gpt-6/.test(m)) return 1050000;
    if (/gpt-5\.6/.test(m)) return 1050000;
    if (/gpt-5\.5/.test(m)) return 1050000;
    if (/gpt-5\.4-pro/.test(m)) return 1050000;
    if (/gpt-5\.4-(mini|nano)/.test(m)) return 1000000;
    if (/gpt-5\.4/.test(m)) return 1050000;
    if (/gpt-5\.2-chat-latest/.test(m)) return 1000000;
    if (/gpt-5\.2/.test(m)) return 1000000;
    if (/gpt-5\.1-chat-latest/.test(m)) return 1000000;
    if (/gpt-5\.1/.test(m)) return 1000000;
    if (/gpt-5-chat-latest/.test(m)) return 1000000;
    if (/(^|\/)gpt-5(?:$|[^.0-9])/.test(m)) return 1000000;
    if (/gpt-4o|gpt-4\.1/.test(m)) return 1000000;
    if (/o3|o4/.test(m)) return 1000000;
    if (/claude/.test(m)) return 1000000;
    return 1000000; // 未知模型默认 1M（用户 2026-09-22 拍板，与服务端 CONTEXT_WINDOW_FALLBACK 同步）
  }
  // Persist manual limits by engine/provider/model so the meter and server-side auto-compaction agree.
  // Read old localStorage settings until they are migrated successfully, before sending the next turn.
  function ctxWindowKey(model) { const m = String(model || currentModelId() || '').trim(); return m ? 'wcw.ctxWindow::' + m : 'wcw.ctxWindow'; }
  function contextOverrideKey(model) {
    const route = currentContextRoute();
    return JSON.stringify([route.engine, route.providerId || route.agentCliType, String(model ?? route.model).trim()]);
  }
  function clampContextWindow(n) {
    return Number.isFinite(n) && n > 0 ? Math.round(Math.min(2000000, Math.max(8000, n))) : 0;
  }
  function ctxWindowManual(model) {
    const overrides = state.config?.contextWindowOverrides || {};
    const key = contextOverrideKey(model);
    if (Object.prototype.hasOwnProperty.call(overrides, key)) return clampContextWindow(overrides[key]);
    try {
      const k = parseInt(localStorage.getItem(ctxWindowKey(model)) || '0', 10);
      if (Number.isFinite(k) && k > 0) return clampContextWindow(k);
      const g = parseInt(localStorage.getItem('wcw.ctxWindow') || '0', 10); // 存量全局锁 → 迁移
      if (Number.isFinite(g) && g > 0) return clampContextWindow(g);
    } catch { /* ignore */ }
    return 0;
  }
  let contextWindowSave = Promise.resolve();
  function setCtxWindowManual(n, model) {
    const key = contextOverrideKey(model), legacyKey = ctxWindowKey(model), value = clampContextWindow(n);
    // Capture the route now, but merge at save time: two quick edits must not drop each other's keys.
    const save = contextWindowSave.catch(() => {}).then(async () => {
      const overrides = { ...state.config?.contextWindowOverrides, [key]: value };
      const result = await api('/api/config', { method: 'POST', body: JSON.stringify({ contextWindowOverrides: overrides }) });
      if (result?.ok === false) throw new Error(apiErrText(result.error) || 'Unable to save context window');
      state.config.contextWindowOverrides = result?.config?.contextWindowOverrides || overrides;
      // Status/manual usage from before this edit must not reappear after selecting Auto.
      if (state.status) state.status.contextWindowResolved = null;
      try { localStorage.removeItem(legacyKey); localStorage.removeItem('wcw.ctxWindow'); } catch { /* ignore */ }
      try {
        const statusUrl = state.currentSession?.id ? `/api/status?sessionId=${encodeURIComponent(state.currentSession.id)}` : '/api/status';
        const fresh = await api(statusUrl);
        if (state.status && contextOverrideKey() === key) state.status.contextWindowResolved = fresh.contextWindowResolved;
      } catch { /* The setting is already saved; a status refresh failure must not undo it. */ }
    });
    contextWindowSave = save;
    return save;
  }
  async function syncContextWindowManual() {
    try {
      await contextWindowSave;
      const overrides = state.config?.contextWindowOverrides || {};
      const value = ctxWindowManual();
      if (!Object.prototype.hasOwnProperty.call(overrides, contextOverrideKey()) && value > 0) await setCtxWindowManual(value);
    } catch (e) { contextWindowSave = Promise.resolve(); throw e; }
  }
  function currentContextRoute() {
    const meta = typeof currentEngineMeta === 'function' ? (currentEngineMeta() || {}) : {};
    const model = String(meta.model != null ? meta.model : currentModelId() || '').trim();
    if (meta.engine === 'openai' || meta.providerId || (typeof isProviderMode === 'function' && isProviderMode())) {
      return { engine: 'openai', providerId: String(meta.providerId || state.config?.activeProvider || ''), model };
    }
    return { engine: 'agent', agentCliType: agentCliMeta(meta.agentCliType || state.config?.agentCliType).id, model };
  }
  function sameContextModel(a, b) {
    const left = String(a || '').trim().toLowerCase(), right = String(b || '').trim().toLowerCase();
    // An empty current model means "CLI/provider default", so an agent-reported concrete model still
    // belongs to that route. The inverse is unsafe: an untagged/default reading must not survive after
    // the user explicitly switches to a different model.
    return !right || (!!left && left === right);
  }
  function usageMatchesCurrentRoute(usage) {
    if (!usage || typeof usage !== 'object') return false;
    const route = currentContextRoute();
    if (usage.contextEngine === 'openai') {
      return route.engine === 'openai'
        && String(usage.contextProviderId || '') === route.providerId
        && sameContextModel(usage.contextModel, route.model);
    }
    if (usage.contextEngine === 'agent') {
      return route.engine === 'agent'
        && String(usage.contextAgentCliType || '') === route.agentCliType
        && sameContextModel(usage.contextModel, route.model);
    }
    if (route.engine === 'agent' && agentCliMeta(route.agentCliType).legacyUsageSources.includes(String(usage.source || ''))) {
      return sameContextModel(usage.model, route.model);
    }
    // Backward compatibility for sessions written before route-tagged usage existed. New rows are always
    // tagged, so they take the strict branches above and cannot leak across an engine/model switch.
    return !usage.contextEngine;
  }
  // A usage row may outlive an engine/model switch. Only let a window tagged for the route that will
  // consume the NEXT prompt control the denominator. Legacy Kimi rows are identifiable by source/model;
  // legacy provider compact rows are intentionally rejected because they did not record a provider id.
  function usageWindowForCurrentRoute() {
    const usage = state.shownUsage;
    if (usage?.contextWindowSource === 'manual' || usage?.source === 'external-compact') return null;
    const value = Number(usage && usage.contextWindow);
    if (!Number.isFinite(value) || value <= 0 || !usageMatchesCurrentRoute(usage)) return null;
    const route = currentContextRoute();
    if (usage.contextEngine === 'openai') {
      if (route.engine !== 'openai' || String(usage.contextProviderId || '') !== route.providerId || !sameContextModel(usage.contextModel, route.model)) return null;
      return { value, source: 'usage' };
    }
    if (usage.contextEngine === 'agent') {
      if (route.engine !== 'agent' || String(usage.contextAgentCliType || '') !== route.agentCliType || !sameContextModel(usage.contextModel, route.model)) return null;
      return { value, source: 'usage' };
    }
    if (route.engine === 'agent' && agentCliMeta(route.agentCliType).legacyUsageSources.includes(String(usage.source || '')) && sameContextModel(usage.model, route.model)) {
      return { value, source: 'usage' };
    }
    return null;
  }
  function statusWindowForCurrentRoute() {
    const route = currentContextRoute();
    const r = state.status && state.status.contextWindowResolved;
    if (!r || !sameContextModel(r.model, route.model)) return null;
    if (route.engine === 'openai') {
      if (r.engine === 'agent' || String(r.provider || '') !== route.providerId) return null;
    } else if (r.engine !== 'agent' || String(r.agentCliType || '') !== route.agentCliType) return null;
    const value = Number(r.value);
    return Number.isFinite(value) && value > 0 ? { value, source: r.source } : null;
  }
  function automaticContextWindow() {
    // Provider status is recomputed from the current persisted provider/model and may include a learned
    // cap, so it wins there. Agent-reported native usage wins over a name-based status estimate.
    return (isProviderMode() ? statusWindowForCurrentRoute() || usageWindowForCurrentRoute() : usageWindowForCurrentRoute() || statusWindowForCurrentRoute())
      || { value: ctxWindowGuess(currentModelId()), source: 'guess' };
  }
  function ctxWindow() {
    const o = ctxWindowManual();
    const cap = Number(state.status?.contextWindowResolved?.learnedCap);
    if (o > 0 && isProviderMode() && statusWindowForCurrentRoute() && cap > 0) return Math.min(o, cap);
    return o > 0 ? o : automaticContextWindow().value;
  }
  // 当前上限读数的来源人话标签(供电量表 tooltip + 弹层)。「按名称推测」= 端点未报告真实上限、只能按模型名猜,可能不准。
  function ctxWindowSourceLabel() {
    if (ctxWindowManual() > 0) return t('ctx.sourceLabel.manual');
    const resolved = automaticContextWindow();
    if (resolved.source === 'usage' || resolved.source === 'probe') return t('ctx.sourceLabel.probe');
    if (resolved.source === 'manual') return t('ctx.sourceLabel.settingsFixed');
    return t('ctx.sourceLabel.guessed');
  }
  // Context "in play" after a turn. Prefer the server's accurate per-call figure (contextTokens);
  // fall back to summing raw usage fields only for older payloads that lack it.
  function ctxTokensOf(u) {
    if (u && Number.isFinite(u.contextTokens) && u.contextTokens > 0) return u.contextTokens;
    const g = u && u.usage;
    if (!g) return null;
    const n = (g.input_tokens || 0) + (g.cache_read_input_tokens || 0) + (g.cache_creation_input_tokens || 0) + (g.output_tokens || 0);
    return n > 0 ? n : null;
  }
  function latestUsage(session) {
    const msgs = session && session.messages;
    if (!Array.isArray(msgs)) return null;
    for (let i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i] && msgs[i].usage && usageMatchesCurrentRoute(msgs[i].usage)) return msgs[i].usage;
    }
    return null;
  }
  function ctxPlainMode() { return document.documentElement.getAttribute('data-ui-mode') === 'simple'; }
  function renderContextMeter(u) {
    const box = $('contextMeter');
    if (!box) return;
    const n = usageMatchesCurrentRoute(u) ? ctxTokensOf(u) : null;
    if (n == null) {
      state.shownUsage = null;
      if (box._ctxTween) { cancelAnimationFrame(box._ctxTween); box._ctxTween = null; }
      box._ctxShownN = null;
      const win = ctxWindow();
      const fill = box.querySelector('.batt-fill');
      if (fill) fill.setAttribute('width', '17.80');
      // 体验走查 #12：普通模式不给「— / 1M · 未开始」这种读数，说一句人话；数字留在悬停提示里。
      const plain = ctxPlainMode();
      box.querySelector('.ctx-text').textContent = plain ? t('ctx.plain.empty') : `— / ${fmtTokens(win)} · ${t('ctx.noUsage')}`;
      box.classList.remove('hidden', 'warn', 'crit');
      box.title = `${plain ? t('ctx.plain.hint') + '\n' : ''}${t('ctx.noUsageHint')}\n${t('ctx.tooltip.srcAuto', { src: ctxWindowSourceLabel() })}`;
      return;
    }
    state.shownUsage = u;
    const win = ctxWindow(), pct = win > 0 ? n / win : 0;
    // Keep this visible in both UI modes once usage exists. The manual compact action lives in this
    // meter's popover, so hiding low usage also made context occupancy and compaction disappear.
    // Battery drains as context fills: fill width = remaining capacity (1 - pct) of the 17.8px interior.
    const fill = box.querySelector('.batt-fill');
    if (fill) fill.setAttribute('width', (Math.max(0, Math.min(1, 1 - pct)) * 17.8).toFixed(2));
    // v1.0.2 返修三跟进:上限若被【手动锁定】(localStorage 覆盖),在读数后标一个 🔒 —— 否则用户看不出上限是
    // 手动固定的,一次误点 128K 预设就永久盖过自动探测(deepseek-v4-pro 真机撞出:显示 131k 而非 1M,查明是
    // 早先手动设过 128K)。有锁时提示可点「自动」解锁。
    const manual = ctxWindowManual();
    const locked = manual > 0;
    // 数字平滑过渡(与 .batt-fill 的 CSS width 过渡对齐):估算态(≈)与真实帧共用同一补间,流式估算上爬、
    // 自动压缩回落、真实 usage 校正都走 350ms ease-out,不再「数字猛跳」。
    const txt = box.querySelector('.ctx-text');
    const estMark = u.estimated === true;
    const plain = ctxPlainMode();
    const paint = shownN => {
      const p = win > 0 ? shownN / win : 0;
      txt.textContent = plain
        ? t('ctx.plain.used', { pct: Math.min(100, Math.round(p * 100)) })
        : `${estMark ? '≈' : ''}${fmtTokens(Math.round(shownN))} / ${fmtTokens(win)}${locked ? ' 🔒' : ''} · ${Math.round(p * 100)}%`;
    };
    if (box._ctxTween) { cancelAnimationFrame(box._ctxTween); box._ctxTween = null; }
    const targetN = Math.max(0, Math.round(n));
    const fromN = Number(box._ctxShownN);
    box._ctxShownN = targetN;
    if (Number.isFinite(fromN) && fromN !== targetN) {
      const t0 = performance.now(), dur = 350;
      const step = now => {
        const k = Math.min(1, (now - t0) / dur);
        paint(fromN + (targetN - fromN) * (1 - Math.pow(1 - k, 3)));
        box._ctxTween = k < 1 ? requestAnimationFrame(step) : null;
      };
      box._ctxTween = requestAnimationFrame(step);
    } else {
      paint(targetN);
    }
    box.classList.remove('warn', 'crit');
    if (pct >= 0.9) box.classList.add('crit'); else if (pct >= 0.7) box.classList.add('warn');
    const g = u.usage || {};
    const srcLabel = ctxWindowSourceLabel();
    // 千分位跟界面语言走（i18n.setLocale 把当前语言写在 <html lang> 上；本文件不顶部 import i18n，见上面 deps 注）。
    const uiLocale = document.documentElement.lang || undefined;
    const srcHint = locked
      ? t('ctx.tooltip.locked', { win: win.toLocaleString(uiLocale) })
      : t('ctx.tooltip.srcAuto', { src: srcLabel }) + (srcLabel === t('ctx.sourceLabel.guessed') ? ' ' + t('ctx.tooltip.srcGuessed') : '');
    box.title = (plain ? t('ctx.plain.hint') + '\n' : '') + t('ctx.tooltip.summary', { n: n.toLocaleString(uiLocale), win: win.toLocaleString(uiLocale) }) + '\n' +
      t('ctx.tooltip.usageLine', { input: g.input_tokens || 0, cacheRead: g.cache_read_input_tokens || 0, cacheWrite: g.cache_creation_input_tokens || 0, output: g.output_tokens || 0 }) + '\n' + srcHint;
    box.classList.remove('hidden');
  }
  function updateContextMeter() { renderContextMeter(state.shownUsage || latestUsage(state.currentSession)); }

  function msgActions(msg) {
    const bar = el('div', 'msg-actions');
    const copy = el('button', '', t('common.copy'));
    copy.onclick = () => { copyDisclosure(copy, { kind: 'message', localText: () => msg.content || '' }); };
    bar.appendChild(copy); addPlainCopyAction(bar, copy, { kind: 'message', localText: () => msg.content || '' });
    if (msg.role === 'user') {
      // F9:这条消息发出去时带的附件。重试 / 编辑重发都要带上 —— 修前只重发文字,附件丢了。
      // 去掉 previewUrl(托盘缩略图的 blob URL 只在原页面生命周期里有效,早被释放了)。
      const sentAttachments = () => (Array.isArray(msg.attachments) ? msg.attachments : [])
        .filter(a => a && (a.name || a.path))
        .map(a => { const { previewUrl: _dead, ...rest } = a; return rest; });
      const edit = el('button', '', t('chat.editResend'));
      edit.onclick = () => {
        const box = $('promptInput');
        // 输入框里已经有一段没发出去的草稿:不覆盖它(修前一点就整段盖掉,草稿没了)。说一句,把光标留给用户自己决定。
        if (String(box.value || '').trim()) { toast(t('chat.editResendKeepDraft'), ''); box.focus(); return; }
        box.value = msg.content || ''; autoGrow(box);
        const restored = sentAttachments();
        if (restored.length) {
          const key = a => String(a.id || a.path || a.name || '');
          const have = new Set((state.attachments || []).map(key));
          for (const a of restored) if (!have.has(key(a))) state.attachments.push(a);
          renderAttachments();
        }
        // 触发 input:草稿存盘、「发送 / 插话 / 停止」按钮按新内容切态(直接改 value 不会发 input)。
        box.dispatchEvent(new Event('input', { bubbles: true }));
        box.focus();
      };
      const retry = el('button', '', t('chat.retry'));
      retry.onclick = () => {
        // 回合还在跑时 sendPrompt 会把这句话当【插话】递进去(它判的是「此刻有回合在跑」)—— 那不是「重试」。
        const relay = state.sessionRelay;
        const busy = state.streaming || Boolean(relay && state.currentSession && relay.sessionId === state.currentSession.id && relay.live === true);
        if (busy) { toast(t('chat.retryWaitTurn'), ''); return; }
        // 显式给 attachments(哪怕是空数组):不去动、也不会误带输入框托盘里别的附件。
        sendPrompt(msg.content || '', { attachments: sentAttachments() });
      };
      bar.append(edit, retry);
      // v0.8-S4b B2: 「⏪ 回溯到此处」— rewind the conversation to just before this message.
      const rewind = el('button', '', t('chat.rewindHere'));
      rewind.onclick = () => openRewindModal(msg);
      bar.append(rewind);
    } else if (msg.role === 'assistant') {
      // v0.9-S2 (C2): 「存为 playbook」— turn this completed task into a reusable template. Provider engine
      // only (the draft uses the active provider). Hidden when no session or a turn is streaming.
      if (isProviderMode()) {
        const save = el('button', '', t('playbook.create.action'));
        save.onclick = () => saveAsPlaybook(save, '', msg);
        bar.append(save);
        // v2 跨会话记忆: 「存为记忆」(draft→编辑弹窗→保存)。draft 用 provider,故与「存为 playbook」同处 provider 分支。
        const mem = el('button', '', t('chat.saveMemory'));
        mem.onclick = () => saveAsMemory(mem);
        bar.append(mem);
      }
    }
    return bar;
  }

  /* ---------------- v0.9-S2: 存为 playbook ---------------- */
  // Select an accepted answer, corrections, inputs and checks before asking for a draft; then
  // open the existing editor/save flow. No Playbook is persisted until explicit confirmation.
  async function saveAsPlaybook(btn, sessionId = '', message = null) {
    const sid = String(sessionId || (state.currentSession && state.currentSession.id) || '');
    if (!sid) { toast(t('playbook.create.noSession'), 'err'); return; }
    const orig = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = t('playbook.create.drafting'); }
    try {
      const { createPlaybookReuseUi } = await import('./playbook-reuse.js');
      const isCurrent = () => state.currentSession?.id === sid;
      if (isCurrent()) await createPlaybookReuseUi({ api, apiErrText, el, buildModal, t, toast, refreshPlaybooks, isCurrent }).select(sid, message, openPlaybookEditModal);
    } catch (e) { toast(t('playbook.create.draftFailed', { reason: apiErrText(e) }), 'err'); }
    finally { if (btn) { btn.disabled = false; btn.textContent = orig; } }
  }
  // Edit modal for a drafted playbook: title / desc / promptTemplate are editable; on confirm, POST the
  // normalized object to /api/playbooks (server re-normalizes). XSS-safe — values via el/value, never innerHTML.
  function openPlaybookEditModal(draft) {
    if (draft.reuse) {
      const sid = state.currentSession?.id;
      void import('./playbook-reuse.js').then(({ createPlaybookReuseUi }) => { if (state.currentSession?.id === sid) createPlaybookReuseUi({ api, apiErrText, el, buildModal, t, toast, refreshPlaybooks }).edit(draft); }).catch(error => toast(apiErrText(error), 'err'));
      return;
    }
    const body = el('div', 'pb-form');
    const mkField = (label, value, rows) => {
      const field = el('div', 'pb-field');
      field.appendChild(el('label', 'pb-field-label', label));
      const ta = el(rows > 1 ? 'textarea' : 'input', 'pb-field-input');
      if (rows > 1) ta.rows = rows; else ta.type = 'text';
      ta.value = value || '';
      field.appendChild(ta);
      body.appendChild(field);
      return ta;
    };
    const titleEl = mkField(t('playbook.create.fieldTitle'), draft.title, 1);
    const descEl = mkField(t('playbook.create.fieldDescription'), draft.desc, 2);
    const tmplEl = mkField(t('playbook.create.fieldTemplate'), draft.promptTemplate, 8);
    // Show the detected input parameters read-only (they come from the draft; folder/file types preserved).
    if ((draft.inputs || []).length) {
      const info = el('div', 'pb-field-hint', t('playbook.create.inputs', { inputs: draft.inputs.map(i => `{${i.key}}` + (i.type !== 'text' ? `(${i.type})` : '')).join('  ') }));
      body.appendChild(info);
    }
    const foot = el('div'); foot.style.cssText = 'display:flex;gap:8px';
    const cancel = el('button', '', t('common.cancel'));
    const save = el('button', 'primary', t('common.save'));
    foot.append(cancel, save);
    const modal = buildModal(t('playbook.create.modalTitle'), body, foot);
    cancel.onclick = () => modal.close();
    save.onclick = async () => {
      const pb = { ...draft, title: titleEl.value.trim(), desc: descEl.value.trim(), promptTemplate: tmplEl.value };
      if (!pb.title || !pb.promptTemplate.trim()) { toast(t('playbook.create.required'), 'err'); return; }
      save.disabled = true; save.textContent = t('playbook.create.saving');
      try {
        const r = await api('/api/playbooks', { method: 'POST', body: JSON.stringify({ playbook: pb }) });
        modal.close();
        if (!r || !r.ok) { toast(t('playbook.create.saveFailed', { reason: apiErrText(r && r.error) || t('common.unknown') }), 'err'); return; }
        toast(t('playbook.create.saved'), 'ok');
        refreshPlaybooks(); // reflect the new card in the empty state
      } catch (e) { modal.close(); toast(t('playbook.create.saveFailed', { reason: apiErrText(e) }), 'err'); }
    };
  }

  /* ---------------- v0.8-S4b: conversation rewind ---------------- */
  // Resolve the turnSeq to rewind to for a user message. Primary: the message's own turnSeq (S4b stamps it).
  // Fallback for legacy messages: the turnSummary.turnSeq of the FOLLOWING assistant; else the 1-based
  // ordinal among user messages (matches the server's fallback ladder).
  function turnSeqForUserMessage(msg) {
    const session = state.currentSession;
    const msgs = (session && session.messages) || [];
    if (Number.isFinite(Number(msg.turnSeq))) return Number(msg.turnSeq);
    const idx = msgs.indexOf(msg);
    if (idx >= 0) {
      for (let j = idx + 1; j < msgs.length; j++) {
        const m = msgs[j];
        if (m && m.role === 'assistant' && m.turnSummary && Number.isFinite(Number(m.turnSummary.turnSeq))) return Number(m.turnSummary.turnSeq);
      }
    }
    // ordinal
    let n = 0; for (const m of msgs) { if (m && m.role === 'user') { n++; if (m === msg) return n; } }
    return null;
  }
  // Count the turns (user messages) and revertible files at/after the cut point, for the confirm modal.
  function rewindImpact(msg) {
    const session = state.currentSession;
    const msgs = (session && session.messages) || [];
    const idx = msgs.indexOf(msg);
    let turns = 0; const filePaths = new Set();
    if (idx >= 0) {
      for (let i = idx; i < msgs.length; i++) {
        const m = msgs[i];
        if (!m) continue;
        if (m.role === 'user') turns++;
        if (m.role === 'assistant' && m.turnSummary && Array.isArray(m.turnSummary.filesChanged)) {
          for (const f of m.turnSummary.filesChanged) { if (f && f.revertible && f.path) filePaths.add(f.path); }
        }
      }
    }
    return { turns, fileCount: filePaths.size };
  }
  // Post-rewind refresh. The truncation is already durable when this runs, so every step is
  // best-effort: a failed reload must still leave the truthful "rewound" toast on screen. The 2026-10
  // report ("rewind shows a failure but the messages are gone") came from one shared try/catch that
  // reported any refresh error as a rewind failure.
  async function refreshAfterRewind(sid) {
    try {
      // GET 期间切到了别的会话:别把回溯后的这条写回 state(会盖掉刚打开的那条)—— 取回来之后再判一次。
      if (state.currentSession?.id === sid) {
        const s = await api(`/api/sessions/${sid}`);
        if (state.currentSession?.id === sid) {
          state.currentSession = s.session; state.resumable = s.resumable || null; state.msgWindowStart = null;
          renderCurrentSession(); renderResumeBanner();
        }
      }
      await refreshSessions();
      try { refreshToolPane(); } catch { /* 128f-⑫：回溯连文件一起退的话，「变更」页签要当场跟上 */ }
    } catch (error) { console.warn('[rewind] refresh after a successful rewind failed', error); }
  }
  function openRewindModal(msg) {
    if (state.streaming) { toast(t("toast.rewindStopTurn"), ''); return; }
    const sid = state.currentSession?.id;
    const targetTurnSeq = turnSeqForUserMessage(msg);
    if (!sid || targetTurnSeq == null) { toast(t("toast.rewindNoTurn"), 'err'); return; }
    const { turns, fileCount } = rewindImpact(msg);
    const body = el('div');
    body.append(el('p', '', tCount('chat.rewindConfirm', turns, { turns })));   // 英文 1 turn / N turns
    const preview = el('div', 'rewind-preview'); preview.textContent = (msg.content || '').slice(0, 300);
    body.append(preview);
    let fileBox = null;
    if (fileCount > 0) {
      const wrap = el('label', 'check');
      fileBox = document.createElement('input'); fileBox.type = 'checkbox'; fileBox.checked = true; // default-on when M>0
      wrap.append(fileBox, document.createTextNode(t('chat.rewindFileCheck', { fileCount })));
      body.append(wrap);
    }
    const foot = el('div'); foot.style.cssText = 'display:flex;gap:8px';
    const cancel = el('button', '', t('common.cancel'));
    const go = el('button', 'danger', t('chat.rewind'));
    foot.append(cancel, go);
    const modal = buildModal(t('chat.rewindTitle'), body, foot);
    cancel.onclick = () => modal.close();
    go.onclick = async () => {
      go.disabled = true; go.textContent = t('chat.rewinding');
      let r;
      try {
        r = await api('/api/session/rewind', { method: 'POST', body: JSON.stringify({ sessionId: sid, targetTurnSeq, rollbackFiles: !!(fileBox && fileBox.checked) }) });
      } catch (e) {
        // Only the rewind request itself decides success: an error here means nothing was cut.
        go.disabled = false; go.textContent = t('chat.rewind');
        toast(t("toast.rewindFail", { p1: apiErrText(e) }), 'err');
        return;
      }
      modal.close();
      if (!r || !r.ok) {
        go.disabled = false; go.textContent = t('chat.rewind');
        toast(t("toast.rewindFail", { p1: apiErrText(r && r.error) || t('common.unknownError') }), 'err');
        return;
      }
      // The truncation is already on disk from here on: reload failures must not read as a failure.
      await refreshAfterRewind(sid);
      if (r.lastUserText != null) { $('promptInput').value = r.lastUserText; autoGrow($('promptInput')); $('promptInput').focus(); }
      const reverted = (r.filesReverted || []).length;
      const failed = (r.filesFailed || []).length;
      let m = t('chat.rewindToast', { removed: r.removedTurns || 0 });
      if (reverted) m += t('chat.rewindToastFiles', { reverted });
      if (failed) m += t('chat.rewindToastFailed', { failed });
      toast(m, failed ? '' : 'ok');
    };
  }
  return {
    buildStaticToolGroup,
    ctxTokensOf,
    ctxWindow,
    ctxWindowManual,
    ctxWindowSourceLabel,
    highlightIn,
    iconTextBtn,
    latestUsage,
    messageShell,
    metaFromMessage,
    msgActions,
    renderContextMeter,
    renderGitDiffInto,
    renderMarkdown,
    renderMarkdownInto,
    renderToolImageInto,
    renderToolResultInto,
    renderStaleBadgeInto,
    staleCacheDays,
    saveAsPlaybook,
    safeStringify,
    setCtxWindowManual,
    syncContextWindowManual,
    settleLiveThinking,
    thinkingPanel,
    toolCard,
    toolArgSummary,
    toolGroupSummaryText,
    updateContextMeter,
    usageLine,
    wrapPreWithCopy,
  };
}
