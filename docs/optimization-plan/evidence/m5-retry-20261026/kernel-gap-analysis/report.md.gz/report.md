# M3生产恢复内核：只读缺口与首片合同

当前生产无configure调用，13aq不存在；13am仅拒绝pending/stage，不能恢复。13aj receipt依赖进程WeakMap，跨崩溃不可认领。13ah传uploadId，13ai只接uploadFile/hash；restore当前验证新根后仍重启旧base。

首片建议M3-K1：将E2E中的真实native flush/DisposableTree/FullSnapshot/独立冷验证进程装配迁入产品kernel，并冻结实际child close/owner租约/永久unknown latch。先交真实adapter和verifier，不用ready:true冒充完整生产能力。首片不自动启用worker；若局部开放必须先改现单一capabilities.worker为精确operation门。

configure须在全模块定义后、角色分发及一切根/配置IO前只装配一次；OSowner取得之后、RootHooks.bind与ensureDirs之前执行恢复判断。successor嵌套正常serve复用已装配实例，不能二次configure。

后续顺序：K1真实adapters/verifier → K2durable claim/阶段恢复（先可证明published完成）→ K3真实票据file/hash租约及失钥恢复入口 → K4目标根持久激活和下次启动权威 → K5完整操作能力和取消回收 → K6特殊portable/全文族闭合/崩溃与包验收。

完整源锚、调用接口、serve/cold/successor owner生命周期、可证明与必须hold矩阵、已有测试边界见report.json。输入SHA见input-pins.json。本次未运行测试、server/build/native/socket/browser，未改仓库。
